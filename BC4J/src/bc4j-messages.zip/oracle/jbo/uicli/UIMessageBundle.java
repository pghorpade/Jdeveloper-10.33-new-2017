/*
 * @(#)UIMessageBundle.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli;

import oracle.jbo.common.StringManager;
import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;

public class UIMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Ranges:
   //   STR_ 02500 - 02699
   //   MSG_ 12500 - 12699
   //   EXC_ 34000 - 34999
   //

   static
   {
      Diagnostic.println("UIMessageBundle (language base) being initialized");
   }

   public static final String STR_DEF_APPLICATION               = "02500";
   public static final String STR_DEF_SESSION                   = "02501";
   public static final String STR_DEF_FORM_BINDING              = "02502";
   public static final String STR_DEF_ITER_BINDING              = "02503";
   public static final String STR_DEF_CONTROL_BINDING           = "02504";
   public static final String STR_VALIDATION_EVENTS             = "02505";
   public static final String STR_ROWSET_EVENTS                 = "02506";
   public static final String STR_NULL_VALUE                    = "02507";
   
   public static final String STR_APPLICATION                   = "02520";
   public static final String STR_SESSION                       = "02521";
   public static final String STR_FORM_BINDING                  = "02522";
   public static final String STR_ITER_BINDING                  = "02523";
   public static final String STR_CONTROL_BINDING               = "02524";
   public static final String STR_FIND_MODE                     = "02525";
   public static final String STR_DONE_EXECUTING                = "02526";
   public static final String STR_EXECUTING_QUERY               = "02527";
   public static final String STR_NAVIGATING                    = "02528";
   public static final String STR_BEFORE_COMMIT                 = "02529";
   public static final String STR_DONE_COMMIT                   = "02530";
   public static final String STR_ERROR_COMMIT                  = "02532";
   public static final String STR_BEFORE_ROLLBACK               = "02533";
   public static final String STR_DONE_ROLLBACK                 = "02534";
   public static final String STR_CANCEL_FIND_MODE              = "02535";
   
   public static final String STR_OK_BUTTON_TEXT                = "02600";
   public static final String STR_CANCEL_BUTTON_TEXT            = "02601";
   public static final String STR_HELP_BUTTON_TEXT              = "02602";

   public static final String STR_DETAILS_BUTTON_TEXT           = "02610";
   public static final String STR_HIDE_DETAILS_BUTTON_TEXT      = "02611";
   public static final String STR_STACK_TRACE_BUTTON_TEXT       = "02612";
   public static final String STR_HIDE_STACK_TRACE_BUTTON_TEXT  = "02613";
   public static final String STR_ERR_DLG_TITLE                 = "02614";
   public static final String STR_DETAIL_MSG_SEPARATOR1         = "02615";
   public static final String STR_DETAIL_MSG_SEPARATOR2         = "02616";
   public static final String STR_DETAIL_MSG_LEVEL              = "02617";
   public static final String STR_DETAIL_MSG_HEADER             = "02618";
   public static final String STR_DETAIL_MSG_INDENT             = "02619";
   public static final String STR_WARN_DLG_TITLE                = "02620";

   public static final String STR_LOGIN_TITLE                   = "02630";
   public static final String STR_USER_NAME                     = "02631";
   public static final String STR_PASSWORD                      = "02632";
   public static final String STR_NO_DATA_ACCESS                = "02633";

   public static final String STR_NAV_INVALID_BUTTON_INDEX      = "02639";
   public static final String STR_NAV_FIRST                     = "02640";
   public static final String STR_NAV_PREV                      = "02641";
   public static final String STR_NAV_NEXT                      = "02642";
   public static final String STR_NAV_LAST                      = "02643";
   public static final String STR_NAV_INSERT                    = "02644";
   public static final String STR_NAV_DELETE                    = "02645";
   public static final String STR_NAV_COMMIT                    = "02646";
   public static final String STR_NAV_ROLLBACK                  = "02647";
   public static final String STR_NAV_FIND                      = "02648";
   public static final String STR_NAV_CANCELFIND                = "02649";
   public static final String STR_NAV_EXECUTE                   = "02650";

   public static final String STR_INVALID_METHOD_CALL           = "02660";
   public static final String STR_LOV_NO_HELP                   = "02661";
   public static final String STR_LOV_TITLE_PREFIX              = "02662";
   public static final String STR_LOV_BUTTON_OK                 = "02663";
   public static final String STR_LOV_BUTTON_CANCEL             = "02664";
   public static final String STR_LOV_BUTTON_HELP               = "02665";

   public static final String STR_SB_EDITING                    = "02666";
   public static final String STR_SB_EDITING_ATTR               = "02667";
   // public static final String STR_SB_TIP_FIND                   = "02668";
   public static final String STR_SB_MODIFIED_LABEL             = "02669"; 
   public static final String STR_SB_MODIFIED_FALSE_STATE       = "02670"; 
   public static final String STR_SB_MODIFIED_TRUE_STATE        = "02671"; 
   public static final String STR_SB_CURRENT_ROW_FORMAT         = "02672"; 
   public static final String STR_SB_ROW_COUNT_FORMAT           = "02673"; 
   public static final String STR_AR_IMPROPER_EDIT              = "02674";
   public static final String STR_SB_UNBOUND                    = "02675";


   public static final String STR_TUI_TEST_TITLE                = "02700";
   public static final String STR_TUI_MENU_EXIT                 = "02701";
   public static final String STR_TUI_MENU_FILE                 = "02702";
   public static final String STR_TUI_MENU_DATABASE             = "02703";
   public static final String STR_TUI_MENU_FIRST                = "02704";
   public static final String STR_TUI_MENU_PREVIOUS             = "02705";
   public static final String STR_TUI_MENU_LAST                 = "02706";
   public static final String STR_TUI_MENU_NEXT                 = "02707";
   public static final String STR_TUI_MENU_INSERT               = "02708";
   public static final String STR_TUI_MENU_DELETE               = "02709";
   public static final String STR_TUI_MENU_COMMIT               = "02710";
   public static final String STR_TUI_MENU_ROLLBACK             = "02711";
   public static final String STR_TUI_MENU_QUERYMODE            = "02712";
   public static final String STR_TUI_MENU_QUERYEXECUTE         = "02713";
   public static final String STR_TUI_ERROR_JCLIENTPANEL        = "02714";

   public static final String STR_IMAGE_CONTROL_IMAGE_FILE_EXT  = "02721";
   public static final String STR_IMAGE_CONTROL_CHANGE          = "02722";
   public static final String STR_IMAGE_CONTROL_CLEAR           = "02723";

   //contect menu options for a vertical scrollbar
   public static final String STR_SCROLL_HERE                   = "02730";
   public static final String STR_SCROLL_TOP                    = "02731";
   public static final String STR_SCROLL_PREVIOUS               = "02732";
   public static final String STR_SCROLL_NEXT                   = "02733";
   public static final String STR_SCROLL_BOTTOM                 = "02734";

   /**
   ** <b>JBO-34000: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b>: Name of the definition Java class missing in the
   ** JClient XML file.
   ** <p>
   ** <b>Action:</b>: Every metaobject in JClient must have name
   ** of the definition object's Java class in the XML file.  Correct
   ** the error by regenerating XML file in the design time.
   */
   public static final String EXC_DEF_CLASS_NAME_MISSING        = "34000";

   /**
   ** <b>JBO-34001: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: The iterator binding is of the wrong Java class.
   ** Some controls expect to work with a JUIterRowBinding, while others
   ** with JUIterRangeBinding.  This error indicates that the supplied
   ** iterator binding is not of the expected class.
   ** <p>
   ** <b>Action:</b>: If the error is caused by some client code that
   ** supplies an iterator binding, correct the code to supply an
   ** iterator binding of the correct class.  If the error is caused
   ** by framework code, contact BC4J Technical Support with the
   ** stack trace.
   */
   public static final String EXC_ITER_BINDING_INVALID_CLASS    = "34001";

   /**
   ** <b>JBO-34002: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: The form binding has already been registered with
   ** an application (JUApplication) object.  It is illegal to try
   ** to set the form binding's application object again.
   ** <p>
   ** <b>Action:</b>: This error typically means a program error.
   ** Contact BC4J Technical Support with the stack trace.
   */
   public static final String EXC_APP_ALREADY_SET_FOR_FORM_BND  = "34002";

   /**
   ** <b>JBO-34003: JboException</b>
   ** <p>
   ** <b>Cause:</b>: No iterator binding found with the given name.
   ** <p>
   ** <b>Action:</b>: Fix the iterator binding name before attempting to
   ** change the iterator associated with it.
   */
   public static final String EXC_INVALID_ITER_BINDING_NAME = "34003";

   /**
   ** <b>JBO-34004: JboException</b>
   ** <p>
   ** <b>Cause:</b>: No matching row found for a selected value in a List binding.
   ** <p>
   ** <b>Action:</b>: Enter/Select a valid item from the list so that the matching row
   ** in the LOV iterator can be found.
   */
   public static final String EXC_NO_MATCHING_ROW_IN_LOV = "34004";
   
   /**
   ** <b>JBO-34005: JboException</b>
   ** <p>
   ** <b>Cause:</b>: Exceptions occured in synchronizing data from the client Application 
   ** into the Business Components tier.
   ** <p>
   ** <b>Action:</b>: Fix the exceptions displayed in the details list and then 
   ** reapply the changes.
   */
   public static final String EXC_SYNC_ERROR = "34005";

   /**
   ** <b>JBO-34006: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: Collection to which this iterator is bound returns null.
   ** <p>
   ** <b>Action:</b>: Fix the return value so that a valid collection is available
   ** for this iterator to bind to.
   */
   public static final String EXC_NULL_COLLECTION = "34006";
   
   /**
   ** <b>JBO-35004: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b>: Mandatory Parameter was not set by the calling
   ** code either programmatically or by overriding it in a nested
   ** container usecase.
   ** 
   ** <p>
   ** <b>Action:</b>: Set the mandatory parameter value
   */
   public static final String EXC_MANDATORY_PARAMETER = "34007";

   /**
   ** <b>JBO-35004: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b>: Mandatory Parameter was not set by the calling
   ** code either programmatically or by overriding it in a nested
   ** container usecase.
   ** 
   ** <p>
   ** <b>Action:</b>: Set the mandatory parameter value
   */
   public static final String EXC_FINAL_PARAMETER = "34008";

   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      { STR_DEF_APPLICATION            , "Application Definition" },
      { STR_DEF_SESSION                , "Session Definition" },
      { STR_DEF_FORM_BINDING           , "Form Binding Definition" },
      { STR_DEF_ITER_BINDING           , "Iterator Binding Definition" },
      { STR_DEF_CONTROL_BINDING        , "Control Binding Definition" },
      { STR_VALIDATION_EVENTS          , "Validation Events" },
      { STR_ROWSET_EVENTS              , "RowSet Events" },
      { STR_NULL_VALUE                 , "<null>" },
   
      { STR_APPLICATION                , "Application" },
      { STR_SESSION                    , "Session" },
      { STR_FORM_BINDING               , "Form Binding" },
      { STR_ITER_BINDING               , "Iterator Binding" },
      { STR_CONTROL_BINDING            , "Control Binding" },
      { STR_FIND_MODE                  , "Find Mode" },
      { STR_CANCEL_FIND_MODE           , "Find Mode Cancelled"},
      { STR_DONE_EXECUTING             , "Query Completed" },
      { STR_EXECUTING_QUERY            , "Executing Query..." },
      { STR_NAVIGATING                 , "Navigating: {0}" },
      { STR_BEFORE_COMMIT              , "Saving Changes"},
      { STR_DONE_COMMIT                , "Save Changes successful!"},
      { STR_ERROR_COMMIT               , "Error in Saving Changes!"},
      { STR_BEFORE_ROLLBACK            , "Rolling back Transaction"},
      { STR_DONE_ROLLBACK              , "Rollback Complete"},
      
      
      { STR_OK_BUTTON_TEXT             , "OK" },
      { STR_CANCEL_BUTTON_TEXT         , "Cancel" },
      { STR_HELP_BUTTON_TEXT           , "Help" },
      
      { STR_DETAILS_BUTTON_TEXT        , "Details" },
      { STR_HIDE_DETAILS_BUTTON_TEXT   , "No Details" },
      { STR_STACK_TRACE_BUTTON_TEXT    , "Stack" },
      { STR_HIDE_STACK_TRACE_BUTTON_TEXT, "No Stack" },
      { STR_ERR_DLG_TITLE              , "Error" },
      { STR_DETAIL_MSG_SEPARATOR1      , "----- " },
      { STR_DETAIL_MSG_SEPARATOR2      , " -----" },
      { STR_DETAIL_MSG_LEVEL           , "LEVEL " },
      { STR_DETAIL_MSG_HEADER          , ": DETAIL " },
      { STR_DETAIL_MSG_INDENT          , "   " },
      { STR_WARN_DLG_TITLE             , "Warning" },

      { STR_LOGIN_TITLE                , "Login" },
      { STR_USER_NAME                  , "User Name:" },
      { STR_PASSWORD                   , "Password:" },
      { STR_NO_DATA_ACCESS             , "Data access denied" },

      { EXC_DEF_CLASS_NAME_MISSING     , "Definition class name missing in XML file of type {0}" },
      { EXC_ITER_BINDING_INVALID_CLASS , "Iterator binding {0} is not of the expected class {1}" },
      { EXC_APP_ALREADY_SET_FOR_FORM_BND, "The application obj has already been set for form binding {0}.  Cannot do it again" },
      { EXC_INVALID_ITER_BINDING_NAME,   "No iterators bound with the given name :{0}"},
      { STR_NAV_INVALID_BUTTON_INDEX   , "Invalid Button Index"},
      { STR_NAV_FIRST                  , "Move to the first row"                },
      { STR_NAV_PREV                   , "Move to the previous row"             },
      { STR_NAV_NEXT                   , "Move to the next row"                 },
      { STR_NAV_LAST                   , "Move to the last row"                 },
      { STR_NAV_INSERT                 , "Insert a new row"                     },
      { STR_NAV_DELETE                 , "Delete the current row"               },
      { STR_NAV_COMMIT                 , "Save changes to the database"         },
      { STR_NAV_ROLLBACK               , "Discard all changes since last save"  },
      { STR_NAV_FIND                   , "Set to Find Mode for Query-By-Example"},
      { STR_NAV_CANCELFIND             , "Cancel Find Mode and switch to previously displayed data"},
      { STR_NAV_EXECUTE                , "Execute/Re-execute the query"         },
      { STR_LOV_NO_HELP                , "LOV - Help Not Implemented!\nRegister ActionListener with the LOV Binding to display custom help-text."         },
      { STR_LOV_TITLE_PREFIX           , "List Of Values Using "         },
      { STR_INVALID_METHOD_CALL        , "Improper Method Usage"         },
      { STR_LOV_BUTTON_OK              , "OK"},
      { STR_LOV_BUTTON_CANCEL          , "Cancel"},
      { STR_LOV_BUTTON_HELP            , "Help"},
      
      { STR_SB_EDITING                 , "Editing : {0}"},
      { STR_SB_EDITING_ATTR            , "Editing : {0} - {1}"},
      { STR_SB_MODIFIED_LABEL          , "Modified:" },
      { STR_SB_MODIFIED_FALSE_STATE    , "false"},
      { STR_SB_MODIFIED_TRUE_STATE     , "true"},
      { STR_SB_CURRENT_ROW_FORMAT      , "row ######"}, // Note to translators: the ###### marks in this string is not to be translated.  It is a format mask for displaying numbers. 
      { STR_SB_ROW_COUNT_FORMAT        , "###### rows"}, // Note to translators: the ###### marks in this string is not to be translated.  It is a format mask for displaying numbers.  
      { STR_SB_UNBOUND                 , "No iterator binding to render status on!"},

      { STR_TUI_TEST_TITLE             , "JClient panel"},
      { STR_TUI_MENU_EXIT              , "E&xit"},
      { STR_TUI_MENU_FILE              , "&File"},
      { STR_TUI_MENU_DATABASE          , "&Database"},
      { STR_TUI_MENU_FIRST             , "&First"},
      { STR_TUI_MENU_PREVIOUS          , "&Previous"},
      { STR_TUI_MENU_LAST              , "&Last"},
      { STR_TUI_MENU_NEXT              , "&Next"},
      { STR_TUI_MENU_INSERT            , "&Insert"},
      { STR_TUI_MENU_DELETE            , "&Delete"},
      { STR_TUI_MENU_COMMIT            , "&Commit"},
      { STR_TUI_MENU_ROLLBACK          , "&Rollback"},
      { STR_TUI_MENU_QUERYMODE         , "&Query Mode"},
      { STR_TUI_MENU_QUERYEXECUTE      , "&Execute Query"},
      { STR_TUI_ERROR_JCLIENTPANEL     , "This is not a JClient panel"},
      { STR_IMAGE_CONTROL_IMAGE_FILE_EXT, "(*.gif, *.jpeg)"},
      { STR_IMAGE_CONTROL_CHANGE       , "Change"},
      { STR_IMAGE_CONTROL_CLEAR        , "Clear"},

      { STR_SCROLL_HERE                , "Scroll here"},
      { STR_SCROLL_TOP                 , "Top"},
      { STR_SCROLL_PREVIOUS            , "Previous page"},
      { STR_SCROLL_NEXT                , "Next page"},
      { STR_SCROLL_BOTTOM              , "Bottom"},

      { EXC_MANDATORY_PARAMETER        , "Mandatory parameter value not passed for parameter :{0}."},
      { EXC_FINAL_PARAMETER            , "Final parameter {0} cannot be modified."},
      { STR_AR_IMPROPER_EDIT           , "Element rendered invalid as it was modified in the default ComboBoxEditor"},
      { EXC_NO_MATCHING_ROW_IN_LOV     , "No matching row found for entered or selected item in the LOV iterator for a list-binding." },
      { EXC_SYNC_ERROR                 , "Exceptions occurred in synchronizing updates from this application. Click Details to see the complete list." },
      { EXC_NULL_COLLECTION            , "Method that creates the iterator for this object returns null." }

   }  ;

   final static String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle"; 
   final public static String getResString(String id)
   {
      return StringManager.getString(MSG_BUNDLE, id, "", null); 
   }

}
