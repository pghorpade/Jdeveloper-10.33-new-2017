/*
 * @(#)JboResourceBundle.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

/**
 * A helper class to aid with keeping our NLSable resources
 * consistent. </P>
 *
 */
public class JboResourceBundle
   extends CheckedListResourceBundle
{

   public Object[][] getContents()
   {
      return new Object[0][];
   }
   /**
    * Returns the 2-D array containing key-value pairs.
    * Note: this method is protected in the superclass
    **/
   protected Object[][] getMergedArray(Object[][] mine, Object[][] base)
   {
      if (mine == null) 
      {
         return base;
      }

      int mineLength = mine.length;
      int baseLength = base.length;
      Object[][] ret = new Object[mineLength+baseLength][];
      System.arraycopy(base, 0, ret, 0, baseLength);
      System.arraycopy(mine, 0, ret, baseLength,  mineLength);
      return ret;
   }

} // class CheckedListResourceBundle

