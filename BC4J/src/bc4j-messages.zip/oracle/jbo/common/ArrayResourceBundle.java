/*
 * @(#)ArrayResourceBundle.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

import java.lang.reflect.Field;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * <code>ArrayResourceBundle</code> is an abstract subclass of
 * <code>ResourceBundle</code> that manages locale-dependent resources
 * in an array.  By using numeric references rather than string
 * references, it requires less overhead and provides better performance than
 * <code>ListResourceBundle</code> and <code>PropertyResourceBundle</code>.
 * See <code>ResourceBundle</code> for more information about resource
 * bundles in general.
 *
 * <P>
 * Subclasses must override <code>getContents</code> and provide an array,
 * where each item in the array is the resource value.  The key for each
 * resource value is its numeric offset in the array.  For example, the first
 * element in the array has the key 0.  It may be retrieved by
 * using either getObject(0) or getObject("0");
 *
 * <P>
 * Unlike ListResourceBundle and PropertyResourceBundle, where each
 * locale-specific variation of a bundle can override only selected resources,
 * with ArrayResourceBundle, each variation must provide the complete
 * set of Resources.  For example,if MyResources has three resources,
 * then MyResources_ja and MyResources_fr must also have three resources.
 *
 * <p>
 * The following example shows the structure of a ResourceBundle
 * based on ArrayResourceBundle.
 *
 * <blockquote>
 * <pre>
 * class MyResources extends ArrayResourceBundle {
 *   private static final Object[] contents = {
 *   // LOCALIZE THIS
 *     "Yes",    // Label for the YES button
 *     "No",     // Label for the NO button
 *     "Cancel"  // Label for the CANCEL button
 *   // END OF MATERIAL TO LOCALIZE
 *   };
 *   protected Object[] getContents() {
 *     return contents;
 *   }
 * }
 * </pre>
 * </blockquote>
 *
 * @see java.util.ResourceBundle
 * @see java.util.ListResourceBundle
 * @see java.util.PropertyResourceBundle
 */
public abstract class ArrayResourceBundle
  extends ResourceBundle
{
  private static final Logger LOG = Logger.getLogger( ArrayResourceBundle.class.getName() );

  /**
   * The autosyncmap maps indexes in the parent (assumed to be the default
   * or master resource) to indexes in this bundle.
   */
  private int[] _autoSyncMap;


  protected  Object[] contents;

  /**
   * Get an object from an ArrayResourceBundle.  This is a NON-STATIC version
   * of getString used interall by the ResourceManager
   * <BR>Convenience method to save casting.
   * @param key see class description.
   */
  final String getString2(int key)
  {
    return (String)getObject(key);
  }

  /**
   * Get an object from an ArrayResourceBundle.
   * <BR>Convenience method to save casting.
   * @param key see class description.
   */
  public final String[] getStringArray(int key)
  {
    return (String[])getObject(key);
  }

  /**
   * Get an object from an ArrayResourceBundle.
   * @param key see class description. ###
   */
  public final Object getObject(int key)
  {
    if (contents == null)
    {
      contents = getContents();
    }

    int mappedKey = getMappedIndex( key );

    if (mappedKey < contents.length && mappedKey >= 0 )
    {
      Object o = contents[mappedKey];
      //JOSE_TBD: if (o != null)
      return o;
    }
    if (parent == null)
    {
      throw new MissingResourceException("Can't find resource",
                                         getClass().getName(),
                                         String.valueOf(key));
    }
    if (parent instanceof ArrayResourceBundle)
    {
      return ((ArrayResourceBundle)parent).getObject(key);
    }
    return parent.getObject(String.valueOf(key));
  }


  protected abstract Object[] getContents();

  //
  // Superclass method overrides
  //

  public final Enumeration getKeys()
  {
    if (contents == null)
    {
      contents = getContents();
    }

    Vector result = new Vector(contents.length);
    final int contentsLen = contents.length;
    for (int i = 0; i < contentsLen; ++i)
    {
      result.addElement(String.valueOf(i));
    }
    return result.elements();
  }

  protected Object handleGetObject(String key)
  {
    return getObject(Integer.parseInt(key));
  }


  /**
  * Given the index of a resource in the default (parent) bundle, get the
  * index of the corresponding resource in this bundle, even if the bundles
  * are out of sync.
  *
  * @param index the index of a resource in the default bundle.
  * @return the index of the resource in the locale specific bundle. Will
  *  return -1 if the index is invalid.
  */
  private int getMappedIndex( int index )
  {
   if( parent == null || !(parent instanceof ArrayResourceBundle) )
   {
     return index;
   }

   if ( _autoSyncMap == null )
   {
     buildAutoSyncMap();
   }

   try
   {
     int mappedIndex = _autoSyncMap[ index ];
     if ( mappedIndex == -1 )
     {
       LOG.warning( "NLSSYNC: ARB key '" + getFieldNameForIndex( parent.getClass(), index ) +
         "' exists in " + parent.getClass() + " but not in " + getClass().getName() );
     }
     return mappedIndex;
   }
   catch ( ArrayIndexOutOfBoundsException oob )
   {
     LOG.warning( "NLSSYNC: Key " +
       getFieldNameForIndex( getClass(), index ) +
       " does not exist in " + getClass().getName() );
     return -1;
   }
  }

  private void buildAutoSyncMap()
  {
   Field[] myFields = getClass().getDeclaredFields();
   Map fieldValuesByName = new HashMap();
   for ( int i=0; i < myFields.length; i++ )
   {
     Field f = myFields[ i ];
     if ( f.getType() == Integer.TYPE )
     {
       try
       {
         int value = f.getInt( null );
         fieldValuesByName.put( f.getName(), new Integer( value ) );
       }
       catch (IllegalAccessException ille )
       {
         ille.printStackTrace();
       }
     }
   }

   Field[] parentFields = parent.getClass().getDeclaredFields();
   _autoSyncMap = new int[ parentFields.length ];
   Arrays.fill( _autoSyncMap, -1 );

   for ( int i=0; i < parentFields.length; i++ )
   {
     Field f = parentFields[ i ];
     if ( f.getType() == Integer.TYPE )
     {
       try
       {
         int parentValue = f.getInt( null );
         Integer myValue = (Integer) fieldValuesByName.get( f.getName() );
         if ( myValue != null )
         {
           _autoSyncMap[ parentValue ] = myValue.intValue();
         }
       }
       catch ( IllegalAccessException ille )
       {
         ille.printStackTrace();
       }
     }
   }


  }

  /**
  * Use reflection on this class to find the field name that corresponds to
  * the specified index.
  *
  * @param clazz the class to introspect.
  * @param index the index to look for.
  * @return the name of the field, or an empty string.
  */
  private static String getFieldNameForIndex( Class clazz, int index )
  {
   Field[] fields = clazz.getDeclaredFields();
   for ( int i=0; i < fields.length; i++ )
   {
     Field field = fields[ i ];
     if ( field.getType() == Integer.TYPE )
     {
       try
       {
         int value = field.getInt( null );
         if ( value == index )
         {
           return field.getName();
         }
       }
       catch ( IllegalAccessException ille )
       {
         // NOOP
       }
     }
   }
   return String.valueOf( index );
  }


}

