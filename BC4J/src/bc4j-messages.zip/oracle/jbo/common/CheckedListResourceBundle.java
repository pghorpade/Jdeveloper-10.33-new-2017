/*
 * @(#)CheckedListResourceBundle.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

import java.util.ListResourceBundle;

/**
 * A helper class to aid with keeping our NLSable resources
 * consistent. </P>
 *
 */
public abstract class CheckedListResourceBundle
   extends ListResourceBundle
{
   /**
    * Returns the 2-D array containing key-value pairs.
    * Note: this method is protected in the superclass
    **/
   public abstract Object[][] getContents();

} // class CheckedListResourceBundle

