/*
 * @(#)CommonMessageBundle.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.PropertyConstants;

public class CommonMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Ranges:
   //   STR_ 02300 - 02499
   //   MSG_ 12300 - 12499
   //   EXC_ 33000 - 33200
   //

   static
   {
      if (Diagnostic.isOn())
      {
         Diagnostic.println("CommonMessageBundle (language base) being initialized");
      }
   }

   public static final String STR_DEPLOY_PLATFORM                            = "02300";
   public static final String STR_CONNECTION_MODE                            = "02301";
   public static final String STR_HOST_NAME                                  = "02302";
   public static final String STR_CONNECTION_PORT                            = "02303";
   public static final String STR_APPLICATION_PATH                           = "02304";
   public static final String STR_ENV_USE_PERS_COLL                          = "02305";
   public static final String STR_ENV_PERS_MAX_ROWS_PER_NODE                 = "02306";
   public static final String STR_ENV_PERS_MAX_ACTIVE_NODES                  = "02307";
   public static final String STR_ENV_PCOLL_MGR                              = "02308";
   public static final String STR_STRINGMANAGER_FACTORY_CLASS                = "02309";
   public static final String STR_ENV_OBJ_MARSHALLER                         = "02310";
   public static final String STR_ENV_TXN_TABLE_NAME                         = "02311";
   public static final String STR_ENV_TXN_SEQ_NAME                           = "02312";
   public static final String STR_ENV_CONTROL_TABLE_NAME                     = "02313";
   public static final String STR_ENV_TXN_SEQ_INC                            = "02314";
   
   public static final String STR_DYNAMIC_PACKAGE_NAME                       = "02320";
   public static final String STR_MOM_CONTEXT_FACTORY                        = "02321";
   public static final String STR_INITIAL_CONTEXT_FACTORY                    = "02322";
   public static final String STR_INITIAL_CONTEXT                            = "02323";
   public static final String STR_LOAD_COMP_LAZILY                           = "02324";
   public static final String STR_JBO_323_COMPATIBLE                         = "02325";
   public static final String STR_JBO_903_COMPATIBLE                         = "02326";
   public static final String STR_MOM_USES_MDS                               = "02327";

   public static final String STR_IS_LAZY_LOADING_TRUE                       = "02330";
   public static final String STR_PN_SQLBUILDERIMPL                          = "02331";
   public static final String STR_PN_SQLTYPEMAP                              = "02332";
   public static final String STR_PN_JDBC_DRIVER_CLASS                       = "02333";
   public static final String STR_PN_DBTIME_QUERY                            = "02334";
   public static final String STR_PN_SQL92_LOCKTRAILER                       = "02335";

   public static final String STR_ENV_DEFAULT_LANGUAGE                       = "02340";
   public static final String STR_ENV_DEFAULT_COUNTRY                        = "02341";
   public static final String STR_ENV_FETCH_MODE                             = "02342";
   public static final String STR_SHARED_DATA_HANDLE                         = "02343";
   public static final String STR_HANDLE_NAME                                = "02344";
   public static final String STR_GLOBAL_SUBSTITUTION                        = "02345";
   public static final String STR_JBO_PROJECT                                = "02346";
   public static final String STR_ENV_MAX_CURSORS                            = "02347";
   public static final String STR_ENV_DO_FAILOVER                            = "02348";
   public static final String STR_ENV_MAX_JDBC_POOL_SIZE                     = "02349";
   public static final String STR_ENV_INIT_JDBC_POOL_SIZE                    = "02350";
   public static final String STR_ENV_ENTITYROWSET_MODE                      = "02351";
   public static final String STR_PN_POOL_MANAGER                            = "02352";
   public static final String STR_PN_JBO_JDBC_TRACE                          = "02353";
   public static final String STR_USE_DEFINE_COLUMN_LENGTH                   = "02354";
   public static final String STR_TEMPORARY_FILES_HOME                       = "02355";
   public static final String STR_INTERNAL_CONNECTION_PARAMS                 = "02356";
   public static final String STR_PN_DEBUG_TYPE                              = "02357";
   public static final String STR_PN_DEBUG_PREFIX                            = "02358";
   public static final String STR_PN_SHOW_TIMING                             = "02359";
   public static final String STR_PN_SHOW_FUNCTION                           = "02360";
   public static final String STR_PN_SHOW_LEVEL                              = "02361";
   public static final String STR_PN_SHOW_LINECOUNT                          = "02362";
   public static final String STR_PN_TRACE_THRESHOLD                         = "02363";
   public static final String STR_PN_JDBC_DRIVER_VERBOSE                     = "02364";
   public static final String STR_AM_RELEASE_MODE                            = "02365";
   public static final String STR_SECURITY_PRINCIPAL                         = "02366";
   public static final String STR_SECURITY_CREDENTIALS                       = "02367";
   public static final String STR_ENV_POOL_RECYCLE_THRESHOLD                 = "02368";
   public static final String STR_ENV_EJB_TRANSACTION_TIMEOUT                = "02369";
   public static final String STR_ENV_SESSION_CLASS                          = "02370";
   public static final String STR_ENV_DBTRANSACTION_FACTORY_CLASS            = "02371";
   public static final String STR_ENV_JDBC_POOL_REQUEST_TIMEOUT              = "02372";
   public static final String STR_ENV_PASSIVATION_STORE                      = "02373";
   public static final String STR_ENV_JBO_SCHEMA                             = "02374";
   public static final String STR_XSQL_NO_CONNECTION_FOUND                   = "02375";
   public static final String STR_XSQL_NO_VO_FOUND                           = "02376";
   public static final String STR_XSQL_MUST_GIVE_ATTR                        = "02377";
   public static final String STR_XSQL_MUST_GIVE_TWO_ATTRS                   = "02378";
   public static final String STR_MAX_POOL_COOKIE_AGE                        = "02379";
   public static final String STR_ENV_POOL_CLASS_NAME                        = "02380";
   public static final String STR_ENV_EJB_TXN_TYPE                           = "02381";
   public static final String STR_ENV_DO_CONNECTION_POOLING                  = "02382";
   public static final String STR_ENV_VIEWLINK_MODE                          = "02383";
   public static final String STR_JBO_XML_VALIDATION                         = "02385";
   public static final String STR_ENV_AMPOOL_RESET_NON_TRANS_STATE           = "02386";
   public static final String STR_ENV_AMPOOL_CONNECTION_STRATEGY_CLASS_NAME  = "02387";
   public static final String STR_ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME       = "02388";
   public static final String STR_ENV_AMPOOL_MAX_POOL_SIZE                   = "02389";
   public static final String STR_ENV_AMPOOL_INIT_POOL_SIZE                  = "02390";
   public static final String STR_ENV_AMPOOL_MONITOR_SLEEP_INTERVAL          = "02391";
   public static final String STR_ENV_AMPOOL_MIN_AVAIL_SIZE                  = "02392";
   public static final String STR_ENV_AMPOOL_MAX_AVAIL_SIZE                  = "02393";
   public static final String STR_ENV_AMPOOL_MAX_INACTIVE_AGE                = "02394";
   public static final String STR_ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL       = "02395";
   public static final String STR_ENV_JDBC_POOL_MIN_AVAIL_SIZE               = "02396";
   public static final String STR_ENV_JDBC_POOL_MAX_AVAIL_SIZE               = "02397";
   public static final String STR_ENV_JDBC_POOL_MAX_INACTIVE_AGE             = "02398";
   public static final String STR_PN_VIEWCRITERIA_ADAPTER                    = "02399";
   public static final String STR_PN_LOCKING_MODE                            = "02400";
   public static final String STR_ENV_VO_TRACK_INSERT                        = "02401";
   public static final String STR_ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS        = "02402";
   public static final String STR_APPMODULE_JNDI_NAME                        = "02403";
   public static final String STR_EJB_DISCONNECT_ON_TXN_COMPLETION           = "02404";
   public static final String STR_JBO_SERVER_USE_NULLDBTRANSACTION           = "02405";
   public static final String STR_ENV_PASSIVATION_SAVE_FOR_LATER             = "02406";
   public static final String STR_ENV_SNAPSHOT_STORE_UNDO                    = "02407";
   public static final String STR_ENV_MAX_PASSIVATION_STACK_SIZE             = "02408";
   public static final String STR_ENV_BC4J_CONNECT_FAILOVER                  = "02409";
   public static final String STR_ENV_TXN_HANDLE_AFTER_POST_EXC              = "02410";
   public static final String STR_ENV_DISCONNECT_LEVEL                       = "02411";
   public static final String STR_ENV_AMPOOL_TIME_TO_LIVE                    = "02412";
   public static final String STR_ENV_JDBC_POOL_TIME_TO_LIVE                 = "02413";
   public static final String STR_ENV_DOMAIN_DATE_SUPPRESS_ZERO              = "02414";
   public static final String STR_ENV_DOMAIN_BIND_SQL_DATE                   = "02415";
   public static final String STR_ENV_DEF_MGR_LISTENER                       = "02416";
   public static final String STR_ENV_JBO_EJB_USE_AMPOOL                     = "02418";
   public static final String STR_JDBC_DATA_BYTES_CONVERSION                 = "02419";

   public static final String STR_ORD_HTTP_MAX_MEMORY                        = "02420";
   public static final String STR_ORD_HTTP_TEMP_DIR                          = "02421";

   public static final String STR_ORD_WMP_CLASS_ID                           = "02423";
   public static final String STR_ORD_QP_CLASS_ID                            = "02424";
   public static final String STR_ORD_RP_CLASS_ID                            = "02425";

   public static final String STR_ORD_WMP_CODE_BASE                          = "02426";
   public static final String STR_ORD_QP_CODE_BASE                           = "02427";
   public static final String STR_ORD_RP_CODE_BASE                           = "02428";

   public static final String STR_ORD_WMP_PLUGINS_PAGE                       = "02429";
   public static final String STR_ORD_QP_PLUGINS_PAGE                        = "02430";
   public static final String STR_ORD_RP_PLUGINS_PAGE                        = "02431";
   
   public static final String STR_SECURITY_ENFORCE                           = "02432";
   public static final String STR_SECURITY_LOGINMODULE                       = "02433";
   public static final String STR_SECURITY_AUTHORIZED                        = "02434";
   public static final String STR_USER_PRINCIPAL                             = "02435";
   public static final String STR_ENV_AMPOOL_DO_AM_POOLING                   = "02436";
   public static final String STR_ENV_AMPOOL_IS_USE_EXCLUSIVE                = "02437";
   public static final String STR_SECURITY_CONFIG                            = "02438";
   public static final String STR_SIMULATE_REMOTE                            = "02439";
   public static final String STR_PN_ABSTRACT_BASE_CHECK                     = "02440";
   public static final String STR_ENV_DEFAULT_LOCALE_VARIANT                 = "02441";
   public static final String STR_PN_ASSOC_WHERE_EARLY_SET                   = "02442";
   public static final String STR_ENV_DOMAIN_STRING_AS_BYTES_FOR_RAW         = "02443";

   public static final String STR_ORD_RETRIEVE_PATH                          = "02450";
   public static final String STR_PN_JAAS_CONTEXT                            = "02451";

   public static final String STR_PN_BC4J_ORACLE_HOME                        = "02460";
   public static final String STR_PN_OC4J_INSTANCE_NAME                      = "02461";
   public static final String STR_ENV_AMPOOL_WRITE_COOKIE_TO_CLIENT          = "02462";

   public static final String MSG_UNABLE_TO_SET_SYSTEM_PROPERTY              = "12300";
   public static final String STR_JBO_BLOB_REOPEN_STREAM                     = "12301";
   
   /**
   ** <b>JBO-33000: ConfigException</b>
   ** <p>
   ** <b>Cause:</b> The requested configuration file could not be found.
   ** <p>
   ** <b>Action:</b> Provide a correct name for the configuration file.
   ** Or, make sure that the named configuration file can be found
   ** in one of the accessible paths.
   ** 
   */
   public static final String EXC_CONF_FILE_NOT_FOUND                        = "33000";

   /**
   ** <b>JBO-33001: ConfigException</b>
   ** <p>
   ** <b>Cause:</b> The requested configuration file could not be found
   ** in the class paths.
   ** <p>
   ** <b>Action:</b> Make sure that the named configuration file can
   ** be located in one of the class paths.
   ** 
   */
   public static final String EXC_CONF_NOT_IN_CLASS_PATH                     = "33001";

   // public static final String EXC_CONF_CONNECTION_MISSING                    = "33002";

   /**
   ** <b>JBO-33003: ConfigException</b>
   ** <p>
   ** <b>Cause:</b> The specified connection could not be found.  Or,
   ** an error occurred during processing of the specified connection.
   ** <p>
   ** <b>Action:</b> Make sure that the connection name is correct.
   ** If a detail exception is present, check the detail exception to
   ** see what caused the error.
   ** 
   */
   public static final String EXC_CONF_CONNECTION_NOT_FOUND                  = "33003";

   /**
   ** <b>JBO-33004: ConfigException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while parsing configuration file.
   ** <p>
   ** <b>Action:</b> Check to make sure that the configuration file is
   ** a valid XML file.  See the detail exception for further info.
   ** 
   */
   public static final String EXC_CONF_ERROR_PARSING                         = "33004";

   /**
   ** <b>JBO-33005: ConfigException</b>
   ** <p>
   ** <b>Cause:</b> The named configuration parameter was not found in
   ** the configuration.
   ** <p>
   ** <b>Action:</b> The system expects to find the named configuration
   ** parameter, but could not.  Check the configuration content to make
   ** sure that it contains the named configuration parameter.
   ** 
   */
   public static final String EXC_CONF_CONFIGURATION_NOT_FOUND               = "33005";

   /**
   ** <b>JBO-33006: JboException</b>
   ** <p>
   ** <b>Cause:</b> This error message indicates that the underlying SQLBuilder
   ** does not support datasource.
   ** <p>
   ** <b>Action:</b> For this SQLBuilder, do not use datasource.
   ** 
   */
   public static final String EXC_UNSUPPORTED_DATASOURCE                     = "33006";

   /**
   ** <b>JBO-33007: JboException</b>
   ** <p>
   ** <b>Cause:</b> The specified datasource could not be found.
   ** <p>
   ** <b>Action:</b> Make sure that the datasource name is correct.  See
   ** the detail exception for further info.
   ** 
   */
   public static final String EXC_DATASOURCE_NOT_FOUND                       = "33007";

   // public static final String EXC_NO_APPLICATION_CONTEXT                     = "33008";

   /**
   ** <b>JBO-33020: SQLStmtException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while getting the current time from database.
   ** <p>
   ** <b>Action:</b> If there is a detail exception, it will give further
   ** info as to what went wrong.  If no detail exception, that means the
   ** SQL statement to get the current time returned no result (no row).
   ** Check the SQL statemetn for correctness.
   ** 
   */
   public static final String EXC_GETCURTIME                                 = "33020";

   /**
   ** <b>JBO-33021: JboException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while authenticating the user.
   ** <p>
   ** <b>Action:</b> Make sure that the user's authentication info is
   ** correct.
   ** 
   */
   public static final String EXC_SECURITY                                   = "33021";

   /**
   ** <b>JBO-33022: JboException</b>
   ** <p>
   ** <b>Cause:</b> A thread timed out while waiting for a resource that
   ** was protected with an {@link oracle.jbo.common.Lock}.
   ** <p>
   ** <b>Action:</b> Verify that all threads that have acquired a Lock
   ** have properly released that lock in a finally block.
   **
   */
   public static final String EXC_LOCK_TIMEOUT = "33022";

   /**
   ** <b>JBO-33023: JboException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to release a
   ** {@link oracle.jbo.common.Lock} ** that it did not hold.
   ** <p>
   ** <b>Action:</b> Internal exception.  Please contact BC4J Technical Support.
   **
   */
   public static final String EXC_INVALID_LOCK_RELEASE = "33023";

   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      {STR_DEPLOY_PLATFORM                      , "Deployment Platform"},
      {STR_CONNECTION_MODE                      , "Connection Mode used for Visigenic ORB (1|2|3|4)"},
      {STR_HOST_NAME                            , "Name of the host machine"},
      {STR_CONNECTION_PORT                      , "Connection Port"},
      {STR_APPLICATION_PATH                     , "Application Path"},
      {STR_APPMODULE_JNDI_NAME                  , "Jndi name to lookup application module home"},
      {STR_ENV_USE_PERS_COLL                    , "Use persistent collection for view row spill-over?"},
      {STR_ENV_PERS_MAX_ROWS_PER_NODE           , "Maximum number of rows in a persistent collection node"},
      {STR_ENV_PERS_MAX_ACTIVE_NODES            , "Maximum number of active (in-memory) nodes in a persistent collection"},
      {STR_ENV_PCOLL_MGR                        , "Persistent collection manager"},
      {STR_STRINGMANAGER_FACTORY_CLASS          , "String Manager Factory Class"},
      {STR_ENV_OBJ_MARSHALLER                   , "Object marshaller class"},
      {STR_ENV_TXN_TABLE_NAME                   , "Persistent transaction table name"},
      {STR_ENV_TXN_SEQ_NAME                     , "Persistent transaction sequence name"},
      {STR_ENV_TXN_SEQ_INC                      , "Persistent transaction sequence increment"},
      {STR_ENV_CONTROL_TABLE_NAME               , "Persistent collection control table name"},
      {STR_DYNAMIC_PACKAGE_NAME                 , "Name of package to be loaded dynamically (no default)"},
      {STR_MOM_CONTEXT_FACTORY                  , "MetaObjectManager context factory class"},
      {STR_INITIAL_CONTEXT_FACTORY              , "Class name of BC4J server initial context factory"},
      {STR_INITIAL_CONTEXT                      , "MetaObjectManager XML initial context"},
      {STR_LOAD_COMP_LAZILY                     , "Lazy loading of Application Module components (true|false)"},
      {STR_JBO_323_COMPATIBLE                   , "Compatibility behavior with 3.2.3 (true|false)"},
      {STR_JBO_903_COMPATIBLE                   , "Compatibility behavior with 9.0.3 (true|false)"},
      {STR_MOM_USES_MDS                         , "MetaObjectManager should use MDS to read and parse metaobject documents (true|false)"},
      {STR_IS_LAZY_LOADING_TRUE                 , "Lazy loading of meta objects (true|false)"},
      {STR_PN_SQLBUILDERIMPL                    , "SQLBuilder implementation"},
      {STR_PN_SQLTYPEMAP                        , "TypeMap implementation"},
      {STR_PN_JDBC_DRIVER_CLASS                 , "Name of class implementing jdbc Driver"},
      {STR_PN_SQL92_LOCKTRAILER                 , "SQL Statement trailer clause for locking (eg: FOR UPDATE)"},
      {STR_ENV_DEFAULT_LANGUAGE                 , "The default BC4J session language - part of the Locale"},
      {STR_ENV_DEFAULT_COUNTRY                  , "The default BC4J session country - part of the Locale"},
      {STR_ENV_DEFAULT_LOCALE_VARIANT           , "The default BC4J session locale variant - part of the Locale"},
      {STR_ENV_FETCH_MODE                       , "Control fetch behavior of View Objects (" + PropertyConstants.ENV_FETCH_AS_NEEDED + "|" + PropertyConstants.ENV_FETCH_ALL + ")" },
      {STR_SHARED_DATA_HANDLE                   , "Use shared data handles for common metadata (true|false)" },
      {STR_HANDLE_NAME                          , "Name of shared data handle for common metadata" },
      {STR_GLOBAL_SUBSTITUTION                  , "Global substitution list" },
      {STR_JBO_PROJECT                          , "Project to use for global substitution" },
      {STR_ENV_MAX_CURSORS                      , "Maximum number of cursors to be used by the session" },
      {STR_ENV_DO_FAILOVER                      , "Determines whether failover should occur upon checkin to the application module pool" },
      {STR_ENV_MAX_JDBC_POOL_SIZE               , "Maximum size of a JDBC connection pool"},
      {STR_ENV_INIT_JDBC_POOL_SIZE              , "Initial size of a JDBC connection pool"},
      {STR_ENV_ENTITYROWSET_MODE                , "Are Entity rowset associations kept consistent?"},
      {STR_PN_POOL_MANAGER                      , "Which implementation of a connection pool manager to use"},
      {STR_PN_JBO_JDBC_TRACE                    , "Trace all JDBC activitity with lines flagged by '" + PropertyConstants.JDBC_MARKER + "'"},
      {STR_USE_DEFINE_COLUMN_LENGTH             , "Define column length for all JDBC CHAR or VARCHAR2 columns"},
      {STR_JDBC_DATA_BYTES_CONVERSION           , "Indicate whether to use jdbc default bytes conversion or perform such conversion in the framework."},
      {STR_TEMPORARY_FILES_HOME                 , "Declare a directory to create temporary files in."},
      {STR_INTERNAL_CONNECTION_PARAMS           , "Declares the jdbc-connect string to use to store AM state, VO spill-to-disk, etc"},
      {STR_PN_DEBUG_TYPE                        , "The type of diagnostic implementation to use"},
      {STR_PN_DEBUG_PREFIX                      , "Prefix prepended to DebugDiagnostic lines"},
      {STR_PN_SHOW_TIMING                       , "Show timing information between debug calls"},
      {STR_PN_SHOW_FUNCTION                     , "Show the name of the function in diagnostics (expensive)"},
      {STR_PN_SHOW_LEVEL                        , "Show the actual trace level of the diagnostic message (rarely used)"},
      {STR_PN_SHOW_LINECOUNT                    , "Increment a counter and display it at the beginning of each diagnostic line"},
      {STR_PN_TRACE_THRESHOLD                   , "Show only diagnostic messages with a trace level less than or equal to this threshold"},
      {STR_PN_JDBC_DRIVER_VERBOSE               , "Switch the underlying JDBC driver into verbose mode"},
      {STR_PN_LOCKING_MODE                      , "Default locking mode for an application module {pessimistic|optimistic}"},
      {STR_PN_DBTIME_QUERY                      , "Database system time SQL query string"},
      {STR_AM_RELEASE_MODE                      , "Release mode for Application Module pooling (Stateless|Stateful|Reserved)" },
      {STR_SECURITY_PRINCIPAL                   , "JNDI: Identity of principal (e.g. user) for the authentication scheme"},
      {STR_SECURITY_CREDENTIALS                 , "JNDI: Principal's credentials for the authentication scheme"},
      {STR_ENV_POOL_RECYCLE_THRESHOLD           , "Threshold application module pool size at which referenced application modules should be recycled"},
      {STR_ENV_EJB_TRANSACTION_TIMEOUT          , "Time after the application module session bean transaction expires"},
      {STR_EJB_DISCONNECT_ON_TXN_COMPLETION     , "Release and reacquire jdbc connection upon appmdule session bean transaction completion"},
      {STR_JBO_SERVER_USE_NULLDBTRANSACTION     , "Use 9.0.2 compatible oracle.jbo.server.NullDbtransactionImpl when not connected to database"},
      {STR_ENV_PASSIVATION_SAVE_FOR_LATER       , "Save snapshots for the lifetime of the transaction"},
      {STR_ENV_SNAPSHOT_STORE_UNDO              , "Target for undo snapshots {transient|persistent}"},
      {STR_ENV_MAX_PASSIVATION_STACK_SIZE       , "Maximum size of the passivation stack (default 10)"},
      {STR_ENV_TXN_HANDLE_AFTER_POST_EXC        , "Use passivation to restore transaction state if an exception occurs after post (default false)"},
      {STR_ENV_DISCONNECT_LEVEL                 , "Internal:  Mode that should be used to handle database state at disconnect"},
      {STR_ENV_AMPOOL_TIME_TO_LIVE              , "ApplicationPool time to live for ApplicationModule instances."},
      {STR_ENV_JDBC_POOL_TIME_TO_LIVE           , "ConnectionPool time to live for Connection instances."},
      {STR_ENV_BC4J_CONNECT_FAILOVER            , "BC4J transparent JDBC connection failover"},
      {STR_ENV_SESSION_CLASS                    , "Name of Session class in middle tier which implementing the oracle.jbo.Session interface"},
      {STR_ENV_DBTRANSACTION_FACTORY_CLASS      , "DatabaseTransactionFactory class to be used for creating DatabaseTransaction"},
      {STR_ENV_JDBC_POOL_REQUEST_TIMEOUT        , "Time a request should wait for a JDBC connection to be released to the connection pool"},
      {STR_ENV_PASSIVATION_STORE                , "The type of store, database or file, that should be used for application module passivation"},
      {STR_ENV_DOMAIN_DATE_SUPPRESS_ZERO        , "Suppress time bits in rendering Date as String when time bits are zero for a date value"},
      {STR_ENV_DOMAIN_BIND_SQL_DATE             , "When binding oracle.jbo.domain.Date, use oracle.sql.DATE"},
      {STR_ENV_DEF_MGR_LISTENER                 , "Name of the definition object manager listener"},
      {STR_ENV_JBO_SCHEMA                       , "Schema name in which BC4J runtime libraries are deployed"},
      {STR_XSQL_NO_CONNECTION_FOUND             , "Connection {0} not found in XSQLConfig.xml"},
      {STR_XSQL_NO_VO_FOUND                     , "View Object {0} not found"},
      {STR_XSQL_MUST_GIVE_ATTR                  , "You must supply the {0} attribute"},
      {STR_XSQL_MUST_GIVE_TWO_ATTRS             , "You must supply the {0} or {1} attribute"},
      {STR_MAX_POOL_COOKIE_AGE                  , "Maximum browser cookie age for pooled application module sessions"},
      {STR_ENV_POOL_CLASS_NAME                  , "Custom ApplicationPool implementation class"},
      {STR_ENV_EJB_TXN_TYPE                     , "EJB container transaction type"},
      {STR_ENV_DO_CONNECTION_POOLING            , "Determines whether the application pool should release the application module connection upon checkin"},
      {STR_ENV_VIEWLINK_MODE                    , "Are view links kept consistent by default?"},
      {STR_JBO_XML_VALIDATION                   , "Determines the validation mode for XML-parser"},
      {STR_ENV_AMPOOL_RESET_NON_TRANS_STATE     , "Determines if non-transactional application module state should be reset upon an unmanaged checkin"},
      {STR_ENV_AMPOOL_CONNECTION_STRATEGY_CLASS_NAME, "Specifies a custom connection strategy implementation"},
      {STR_ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME , "Specifies a custom session cookie factory implementation"},
      {STR_ENV_AMPOOL_MAX_POOL_SIZE             , "The maximum number of application module instances in a pool"},
      {STR_ENV_AMPOOL_INIT_POOL_SIZE            , "The initial number of application module instances in a pool"},
      {STR_ENV_AMPOOL_MONITOR_SLEEP_INTERVAL    , "The time (ms) that the application pool monitor should sleep between pool checks"},
      {STR_ENV_AMPOOL_MIN_AVAIL_SIZE            , "The minimum number of available application modules that should be referenced by an application pool"},
      {STR_ENV_AMPOOL_MAX_AVAIL_SIZE            , "The maximum number of available application modules that should be referenced by an application pool"},
      {STR_ENV_AMPOOL_MAX_INACTIVE_AGE          , "The maximum amount of time (ms) that an application module may remain inactive before it is removed from the pool"},
      {STR_ENV_AMPOOL_DO_AM_POOLING             , "Enable ApplicationModule pooling"},
      {STR_ENV_AMPOOL_IS_USE_EXCLUSIVE          , "ApplicationModule use is exclusive"},
      {STR_ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL , "The time (ms) that the connection pool monitor should sleep between pool checks"},
      {STR_ENV_JDBC_POOL_MIN_AVAIL_SIZE         , "The minimum number of available connections that should be referenced by a connection pool"},
      {STR_ENV_JDBC_POOL_MAX_AVAIL_SIZE         , "The maximum number of available connections that should be referenced by a connection pool"},
      {STR_ENV_JDBC_POOL_MAX_INACTIVE_AGE       , "The maximum amount of time (ms) that a connection may remain inactive before it is removed from the pool"},
      {STR_PN_VIEWCRITERIA_ADAPTER              , "ViewCritieraAdapter ClassName"},
      {STR_ENV_VO_TRACK_INSERT                  , "Track Insert during Passivation/Activation."},
      {STR_ORD_HTTP_MAX_MEMORY                  , "Restrict interMedia memory usage"},
      {STR_ORD_HTTP_TEMP_DIR                    , "interMedia temporary directory"},
      {STR_ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS  , "Declares that an application pool may support multiple JDBC users"},
      {STR_ORD_WMP_CLASS_ID                     , "Specifies a custom Windows Media Player's CLASS ID"},
      {STR_ORD_QP_CLASS_ID                      , "Specifies a custom Quicktime Player's CLASS ID"},
      {STR_ORD_RP_CLASS_ID                      , "Specifies a custom Realmedia Player's CLASS ID"},
      {STR_ORD_WMP_CODE_BASE                    , "Specifies a custom Windows Media Player's CODE BASE"},
      {STR_ORD_QP_CODE_BASE                     , "Specifies a custom Quicktime Player's CODE BASE"},
      {STR_ORD_RP_CODE_BASE                     , "Specifies a custom Realmedia Player's CODE BASE"},
      {STR_ORD_WMP_PLUGINS_PAGE                 , "Specifies a custom Windows Media Player's embed plugins download page"},
      {STR_ORD_QP_PLUGINS_PAGE                  , "Specifies a custom Quicktime Player's embed plugins download page"},
      {STR_ORD_RP_PLUGINS_PAGE                  , "Specifies a custom Realmedia Player's embed plugins download page"},
      {STR_ORD_RETRIEVE_PATH                    , "Specifies a custom retrieve path for the interMedia media delivery component"},
      {STR_SECURITY_ENFORCE                     , "JAAS Authentication (None|Test|Must|Auth). Default is None or no authentication "},
      {STR_SECURITY_LOGINMODULE                 , "LoginModule, default is JAZNUserManager"},
      {STR_SECURITY_AUTHORIZED                  , "Security authorization check"},
      {STR_SECURITY_CONFIG                      , "JAAS configuration file. Please specify the config file name with complete path"},
      {STR_USER_PRINCIPAL                       , "Authenticated user principal name"},
      {STR_SIMULATE_REMOTE                      , "Simulate remote operation in colocated mode"},
      {STR_PN_ABSTRACT_BASE_CHECK               , "Check for wrong use of abstract base row definition"},
      {STR_PN_ASSOC_WHERE_EARLY_SET             , "Controls whether the assoc/viewlink VO's where-clause is set early"},
      {STR_ENV_DOMAIN_STRING_AS_BYTES_FOR_RAW   , "When constructing a Raw from String, use String's byte array instead of using it as a hex dump"},
      {STR_ENV_JBO_EJB_USE_AMPOOL               , "Use application module pool on the server"},
      {STR_PN_JAAS_CONTEXT                      , "JAAS Context"},
      
      {STR_PN_BC4J_ORACLE_HOME                  , "Internal use only - BC4J oracle home"},
      {STR_PN_OC4J_INSTANCE_NAME                , "Internal use only - OC4J instance name"},
      {STR_ENV_AMPOOL_WRITE_COOKIE_TO_CLIENT    , "Write the SessionCookie value to the client browser"}, 

      {EXC_CONF_FILE_NOT_FOUND                  , "Cannot find the configuration file {0}"},
      {EXC_CONF_NOT_IN_CLASS_PATH               , "Cannot find the configuration file {0} in the classpath"},
      // {EXC_CONF_CONNECTION_MISSING              , "Connection name missing from the environment"},
      {EXC_CONF_CONNECTION_NOT_FOUND            , "Connection name {0} not defined"},
      {EXC_CONF_ERROR_PARSING                   , "Error parsing configuration file"},
      {EXC_CONF_CONFIGURATION_NOT_FOUND         , "Configuration {0} not found"},
      {EXC_UNSUPPORTED_DATASOURCE               , "Datasource {0} is not supported"},
      {EXC_DATASOURCE_NOT_FOUND                 , "Unable to lookup datasource {0}"},
      // {EXC_NO_APPLICATION_CONTEXT               , "Error finding application context"},
      {EXC_GETCURTIME                           , "Error getting current time.  SQL: {0}"},
      {EXC_SECURITY                             , "Failed authenticate user {0}"},
      
      {EXC_LOCK_TIMEOUT, "The thread, {0}, was timed out while waiting to acquire a lock."},
      {EXC_INVALID_LOCK_RELEASE, "The thread, {0}, attempted to release a session cookie lock that it had not acquired."},
      {MSG_UNABLE_TO_SET_SYSTEM_PROPERTY        , "Unable to set system property {0} to {1}"},
      {STR_JBO_BLOB_REOPEN_STREAM               , "Reopen the blob stream upon getInputStream() if the end of stream is reached (true|false)"},
   }  ;
}
