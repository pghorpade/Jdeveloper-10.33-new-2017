/*
 * @(#)CSMessageBundle.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo;

import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;

/**
 * Defines the error codes and default error messages for operations on business objects.
 * <p>
 * These error codes may be localized by extending this class, and overriding
 * <code>getContents()</code> to return a table in which the error codes are
 * associated with other message strings. The subclass should be given a name of the
 * form <code>CSMessageBundle_<em>locale</em></code>, where <em>Locale</em> is
 * the name of a language.
 * <p>
 * <code>CSMessageBundle_xx</code> is an example locale, for the toy language <em>Xx</em>.
 * see oracle.jbo.common.CSMessageBundle_xx
 * @since JDeveloper 3.0
 */
public class CSMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Messages are categorized into 3 groups:  Strings, Messages, and Exception-Messges.
   //
   // For each message bundle class, a range is reserved for each of these categories.
   // Please refrain from an id which is outside the range.
   //
   // See below for the range:
   //
   // MessageBundle class                           STR range      MSG range      EXC range
   // --------------------------------------------  -------------  -------------  -------------
   // oracle.jbo.CSMessageBundle                    00000 - 01999  10000 - 11999  20000 - 29999
   // oracle.jbo.common.ampool.AMPoolMessageBundle  02000 - 02299  12000 - 12299  30000 - 32999
   // oracle.jbo.common.CommonMessageBundle         02300 - 02499  12300 - 12499  33000 - 33999
   // oracle.jbo.uicli.UIMessageBundle              02500 - 02699  12500 - 12699  34000 - 34999
   // oracle.jbo.uicli.ADFMMessageBundle            03000 - 03499  13000 - 13399  35000 - 35999
   // 
   
   //
   // Ranges:
   //   STR_ 00000 - 01999
   //   MSG_ 10000 - 11999
   //   EXC_ 20000 - 29999
   //

   static
   {
      if (Diagnostic.isOn())
      {
         Diagnostic.println("CSMessageBundle (language base) being initialized");
      }
   }

   public static final String STR_DEF_APP_MODULE                = "01001";
   public static final String STR_DEF_VIEW_OBJECT               = "01011";
   public static final String STR_DEF_VIEW_LINK                 = "01012";
   public static final String STR_DEF_ENTITY_OBJECT             = "01021";
   public static final String STR_DEF_ENTITY_ASSOC              = "01022";
   public static final String STR_DEF_ATTRIBUTE                 = "01031";
   public static final String STR_DEF_DOMAIN                    = "01041";
   public static final String STR_DEF_PACKAGE                   = "01051";

   public static final String STR_APP_MODULE                    = "01101";
   public static final String STR_VIEW_OBJECT                   = "01111";
   public static final String STR_VIEW_ROW_SET                  = "01112";
   public static final String STR_VIEW_ROW_SET_ITERATOR         = "01113";
   public static final String STR_VIEW_ROW                      = "01114";
   public static final String STR_VIEW_LINK                     = "01115";
   public static final String STR_ENTITY_OBJECT                 = "01121";
   public static final String STR_ENTITY_ROW_SET                = "01122";
   public static final String STR_ENTITY_ROW_SET_ITERATOR       = "01123";
   public static final String STR_ENTITY_ROW                    = "01124";
   public static final String STR_ENTITY_ASSOC                  = "01125";
   public static final String STR_ENTITY_USAGE                  = "01126";
   public static final String STR_ATTRIBUTE                     = "01131";
   public static final String STR_VARIABLE                      = "01132";
   public static final String STR_VARIABLE_WHERE_CLAUSE         = "01133";
   public static final String STR_DOMAIN                        = "01141";
   public static final String STR_PACKAGE                       = "01151";
   public static final String STR_VALIDATOR_TYPE                = "01161";
   public static final String STR_TRANSACTION                   = "01162";
   public static final String STR_VIEW_CRITERIA                 = "01163";

   public static final String STR_DML_INSERT                    = "01221";
   public static final String STR_DML_UPDATE                    = "01222";
   public static final String STR_DML_DELETE                    = "01223";

   public static final String STR_DML_ROLLBACK                  = "01224";
   public static final String STR_DML_COMMIT                    = "01225";
   public static final String STR_DML_SAVEPOINT                 = "01226";
   public static final String STR_DML_ROLLBACK_TO_SAVEPOINT     = "01227";
   public static final String STR_DML_RELEASE_SAVEPOINT         = "01228";
   public static final String STR_DML_BATCH_POST                = "01229";

   public static final String STR_VAL_DESC_REGEXP_VALIDATOR     = "01299";
   public static final String STR_VAL_DESC_LENGTH_VALIDATOR     = "01300";
   public static final String STR_VAL_DESC_RANGE_VALIDATOR      = "01301";
   public static final String STR_VAL_DESC_COMPARE_VALIDATOR    = "01302";
   public static final String STR_VAL_DESC_LIST_VALIDATOR       = "01303";
   public static final String STR_VAL_DESC_METHOD_VALIDATOR     = "01304";
   public static final String STR_VAL_DESC_GENERIC_VALIDATOR    = "01305";
   public static final String STR_VAL_DESC_PRECISION_VALIDATOR  = "01306";
   public static final String STR_VAL_DESC_MANDATORY_VALIDATOR  = "01307";
   public static final String STR_VAL_SCALE_DECIMAL_CHAR        = "01308";

   public static final String STR_DATASOURCE                    = "01309";
   public static final String STR_TRANSACTION_MANAGER           = "01310";

   public static final String MSG_POOL_NUM_OF_INSTANCE_CREATIONS       = "10000";
   public static final String MSG_POOL_NUM_OF_INSTANCE_REMOVALS        = "10001";
   public static final String MSG_POOL_NUM_OF_CHECK_OUTS               = "10002";
   public static final String MSG_POOL_NUM_OF_CHECK_INS                = "10003";
   public static final String MSG_POOL_NUM_OF_INSTANCES                = "10004";
   public static final String MSG_POOL_MAX_NUM_OF_INSTANCES            = "10005";
   public static final String MSG_POOL_AVG_NUM_OF_INSTANCES            = "10006";
   public static final String MSG_POOL_NUM_OF_AVAIL_INSTANCES          = "10007";
   public static final String MSG_POOL_AVG_NUM_OF_AVAIL_INSTANCES      = "10008";
   public static final String MSG_POOL_AVG_NUM_OF_UNAVAIL_INSTANCES    = "10009";
   public static final String MSG_POOL_NUM_OF_UNUSED_INSTANCES         = "10010";
   public static final String MSG_POOL_NUM_OF_USED_INSTANCES           = "10011";
   public static final String MSG_POOL_INSTANCE_LIFETIME_STATS         = "10012";
   public static final String MSG_POOL_USE_STATS                       = "10013";
   public static final String MSG_POOL_INSTANCE_STATS                  = "10014";
   public static final String MSG_POOL_INSTANCE_AGE_STATS              = "10015";
   public static final String MSG_POOL_NUM_OF_CHECK_OUT_FAILURES       = "10016";

   public static final String EXC_JAAS_NO_CONTEXT                      = "24000";
   public static final String EXC_JAAS_NO_ROLE                         = "24001";
   public static final String EXC_JAAS_NO_USER                         = "24002";
   public static final String EXC_JAAS_ENTITY_ATTR_SET_FAILED          = "24003";
   
   /**
   ** <b>JBO-25000: UnknownSQLTypeException</b>
   ** <p>
   ** <b>Cause:</b> SQLType name passed to NullValue constructor is invalid.
   ** <p>
   ** <b>Action:</b> Provide a valid SQLType name. See <code> oracle.jbo.server.OracleTypeMapEntries </code>
   ** for a list of valid SQLType names. Names are like "VARCHAR", "CHAR",
   ** "NUMBER", etc.
   ** 
   */
   public static final String EXC_TYP_UNKNOWN_SQL_TYPE          = "25000";
   
   /**
   ** <b>JBO-25001: NameClashException</b>
   ** <p>
   ** <b>Cause:</b> A business component of this name already exists in the
   ** application module.
   ** <p>
   ** <b>Action:</b> Provide a different name for the business component. If you
   ** provide a null value or null string for the name, the framework will
   ** create a unique name within the scope of the application module.
   ** 
   */
   public static final String EXC_NAME_CLASH                    = "25001";
   
   /**
   ** <b>JBO-25002: NoDefException</b>
   ** <p>
   ** <b>Cause:</b> No business component definition found with the given name
   ** in the project classpath.
   ** <p>
   ** <b>Action:</b> Provide a correct name for the business component definition.
   ** If the definition is not in the classpath, you must include it there.
   ** Names are of the format <code>myProjectPackage.BusinessPackage.BusinessComponent</code>.
   ** This error can also occur if there is a case conflict, as when the database expects "DEPTNO"
   ** and receives "Deptno" instead.
   ** 
   */
   public static final String EXC_NO_DEFINITION                 = "25002";
   
   /**
   ** <b>JBO-25003: NoObjException</b>
   ** <p>
   ** <b>Cause:</b> No business component object found with the given name
   ** in the application module.
   ** <p>
   ** <b>Action:</b> Provide a different name for the business component object or create
   ** a new business component with the given name.
   ** 
   */
   public static final String EXC_NO_OBJECT                     = "25003";
   
   /**
   ** <b>JBO-25004: InvalidDefNameException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to associate a definition name with a
   ** type for which it is not valid.
   ** <p>
   ** <b>Action:</b> The name should be a valid Java identifier with no spaces or punctuation.
   ** Names are of the format <code>myProjectPackage.BusinessPackage.BusinessComponent</code>
   ** 
   */
   public static final String EXC_INVALID_DEFINITION_NAME       = "25004";
   
   /**
   ** <b>JBO-25005: InvalidObjNameException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to associate a business component name
   ** with an object for which it is not valid.
   ** <p>
   ** <b>Action:</b> The name should be a valid Java identifier with no spaces or punctuation.
   ** Names are of the format <code>myProjectPackage.BusinessPackage.BusinessComponent</code>
   ** 
   */
   public static final String EXC_INVALID_OBJECT_NAME           = "25005";
   
   /**
   ** <b>JBO-25006: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b> The parameters passed to a business component method are invalid.
   ** <p>
   ** <b>Action:</b> See the Javadoc for the method that throws this exception.
   ** Expand the call-stack for the correct parameters.
   ** E.g., <code>DBTransactionImpl.executeCommand()</code> throws this exception when
   ** command parameter is null or an empty String.
   ** 
   */
   public static final String EXC_INVALID_PARAMETER             = "25006";
   
   /**
   ** <b>JBO-25007: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> Resetting row validation for a default RowIterator of a
   ** view object or a RowSet is not permitted.
   ** <p>
   ** <b>Action:</b> Reset the RowValidation flag for the RowSet or view object.
   ** This will create another iterator for the RowSet or view object to navigate
   ** to another row without validating.
   ** 
   */
   public static final String EXC_INVALID_OPER_SET_ROW_VALIDATION = "25007";
   
   /**
   ** <b>JBO-25008: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to remove a view object that is
   ** participating in a view link.
   ** <p>
   ** <b>Action:</b> Remove the view link before removing the view object.
   ** 
   */
   public static final String EXC_CANNOT_REMOVE_REFERENCED_OBJ  = "25008";
   
   /**
   ** <b>JBO-25009: oracle.jbo.domain.DataCreationException</b>
   ** <p>
   ** <b>Cause:</b> A domain object could not be created with the given value. Either
   ** a domain constructor that accepts the given value does not exist, or
   ** there is no conversion method in the domain object for the given 
   ** value type, or the domain's constructor threw an unexpected exception.
   ** <p>
   ** <b>Action:</b> Confirm that the value being passed is valid with respect to
   ** the domain-type being created. E.g., passing a String value like
   ** "One" to the <code>oracle.jbo.domain.Number</code> constructor will throw this
   ** exception.
   ** 
   */
   public static final String EXC_DATA_CREATION_FROM_VALUE      = "25009";
   
   /**
   ** <b>JBO-25010: oracle.jbo.domain.DomainValidationException</b>
   ** <p>
   ** <b>Cause:</b> Validation failed with the given value in a domain constructor.
   ** This exception is thrown in the <code>validate()</code> method of a domain
   ** type.
   ** <p>
   ** <b>Action:</b> Provide a valid value for the domain type.
   ** 
   */
   public static final String EXC_VAL_DOMAIN_FAILED             = "25010";
   
   /**
   ** <b>JBO-25011: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to invoke an invalid navigation method
   ** for a forward-only view object or RowSet.
   ** <p>
   ** <b>Action:</b> Either remove the forward-only setting for the view object or
   ** RowSet, or do not invoke navigation methods other than <code>next()</code>
   ** on the forward-only view object or RowSet.
   ** 
   */
   public static final String EXC_INVALID_OPER_FORWARD_ROWSET   = "25011";
   
   /**
   ** <b>JBO-25012: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> The client has attempted to locate View rows that
   ** has the given entity row as the primary entity row.  However, it
   ** has been discovered that the entity row's entity definition does
   ** not match the entity definition of the view object's primary entity object base.
   ** <p>
   ** <b>Action:</b> The entity row used to locate View rows must
   ** be based on the same entity definition.
   */
   public static final String EXC_EO_NOT_PRIMARY_BASE           = "25012";
   
   /**
   ** <b>JBO-25013: TooManyObjectsException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to add a new entity to the cache with the primary key
   ** the same as an existing entity. This exception is thrown when uniquing
   ** a newly fetched/created entity with the cached set of entities.
   ** <p>
   ** <b>Action:</b> The primary key value may not be unique for this entity-type. 
   ** Fix by adding more attributes to the Key definition for this entity
   ** type, so that each row for this entity is uniquely identifiable.
   ** Or fix the primary key value so that this entity has a unique
   ** key identifier.
   ** 
   */
   public static final String EXC_TOO_MANY_OBJECTS              = "25013";
   
   /**
   ** <b>JBO-25014: RowInconsistentException</b>
   ** <p>
   ** <b>Cause:</b> The database value does not match the cached value for this entity object. 
   ** This could happen when another user
   ** or operation has committed modifications to the same entity-row
   ** in the database. This exception can also be thrown if the <code>equals()</code>
   ** method on one of the domain-type attributes in the entity fails.
   ** <p>
   ** <b>Action:</b> Choose from the following options:
   ** <p>
   ** <ul>
   ** <li>Verify that another user or operation has not modified the same
   ** row in the database. If this entity has attributes of a domain type
   ** verify that the <code>equals()</code> method on these domains do not fail
   ** when comparing the existing cached value with the newly fetched value.
   ** <li>For any attributes/columns that are updated by the database, modify the
   ** entity attribute definition by selecting <b>Refresh after update</b> on the
   ** Attribute Settings page of the Entity Object Wizard.
   ** <li>Use <code>view.executeQuery()</code> frequently, especially after any
   ** operations that result in data being changed.
   ** </ul>
   **
   */
   public static final String EXC_ROW_INCONSISTENT              = "25014";
   
   /**
   ** <b>JBO-25015: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to execute query or access a row from
   ** a view object or RowSet after closing or removing the view object or RowSet.
   ** <p>
   ** <b>Action:</b> Verify that the view object or RowSet is not removed or closed.
   ** 
   */
   public static final String EXC_QUERY_COLLECTION_CLOSED       = "25015";
   
   /**
   ** <b>JBO-25016: ReadOnlyViewObjectException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to modify data for a view object which is declared 
   ** to be read only. This includes creating a new row for this view object, removing
   ** a Row, or modifying attributes of a ViewRow for this view object.
   ** <p>
   ** <b>Action:</b> Create a view object with ReadOnly flag set to <code>false</code> to modify the data.
   ** 
   */
   public static final String EXC_VIEWOBJECT_READONLY           = "25016";
   
   /**
   ** <b>JBO-25017: RowCreateException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred while creating a new entity 
   ** instance.
   ** <p>
   ** <b>Action:</b> The entity may not have a public default constructor.
   ** Fix the cause for InstantiationException or IllegalAccessException
   ** that appears in the details of this exception.
   ** 
   */
   public static final String EXC_ENTITY_ROW_CREATE             = "25017";
   
   /**
   ** <b>JBO-25018: RowCreateException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred while creating a new ViewRow
   ** instance.
   ** <p>
   ** <b>Action:</b> The ViewRow may not have a public default constructor.
   ** Fix the cause for InstantiationException or IllegalAccessException
   ** that appears in the details of this exception.
   */
   public static final String EXC_VIEW_ROW_CREATE               = "25018";
   
   /**
   ** <b>JBO-25019: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to lock a non-existing row in the database. This could
   ** occur when the cache has an entity which was subsequently deleted
   ** from the database by another user or operation.
   ** <p>
   ** <b>Action:</b> Remove the current entity from the entity-cache by calling <code>remove()</code>.
   ** Or re-synchronize the cache with the database, by rolling-back the
   ** current transaction or by committing the existing set of changes and then
   ** dropping the entity-cache.
   */
   public static final String EXC_ENTITY_ROW_NOT_FOUND          = "25019";
   
   /**
   ** <b>JBO-25020: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to find a referenced entity in the ViewRow failed due to
   ** a changed foreign-key value.
   ** <p>
   ** <b>Action:</b> Provide a valid foreign-key value or remove the current one.
   ** 
   */
   public static final String EXC_VIEW_ROW_NOT_FOUND            = "25020";
   
   /**
   ** <b>JBO-25021: oracle.jbo.domain.DataCreationException</b>
   ** <p>
   ** <b>Cause:</b> A domain object could not be created with the given value. Either
   ** a domain-constructor that accepts the given value does not exist, or
   ** there is no conversion method in the domain object for the given
   ** value type, or the domain's constructor threw an unexpected exception.
   ** <p>
   ** <b>Action:</b> Confirm that the value being passed is valid with respect to
   ** the domain-type being created. E.g., passing a String value like
   ** "One" to <code>oracle.jbo.domain.Number</code> constructor will throw this
   ** exception.
   ** 
   */
   public static final String EXC_DATA_CREATION                 = "25021";
   
   /**
   ** <b>JBO-25022: ViewLinkAlreadyExistsException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to set the Master RowSet for this RowSet more than
   ** once.
   ** <p>
   ** <b>Action:</b> Do not invoke setMasterRowSetIterator more than once on a RowSet.
   **
   */
   public static final String EXC_VIEW_LINK_ALREADY_EXISTS      = "25022";
   
   /**
   ** <b>JBO-25023: oracle.jbo.domain.GenericDomainException</b>
   ** <p>
   ** <b>Cause:</b> An expected domain exception occurred.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support.
   **
   */
   public static final String EXC_DOMAIN_OPERATION              = "25023";
   
   /**
   ** <b>JBO-25024: JboException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to use an obsolete TypeMap constructor.
   ** <p>
   ** <b>Action:</b> Verify that the TypeMaps in use for this version of framework is 
   ** compatible. See example TypeMaps in <code>oracle.jbo.server.OracleTypeMapEntries</code>
   */
   public static final String EXC_OBSOLETE_METHOD               = "25024";
   
   /**
   ** <b>JBO-25025: ReadXMLException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred during reading the XML data for a view object. This
   ** exception may contain other ReadXMLExceptions.
   ** <p>
   ** <b>Action:</b> Fix the contained Row- or Attribute-level exceptions in the details for
   ** this exception.
   **
   */
   public static final String EXC_READ_ROWSET_XML               = "25025";
   
   /**
   ** <b>JBO-25026: RowReadXMLException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred during reading the XML data for a ViewRow. This 
   ** exception may contain other ReadXMLExceptions for contained
   ** RowSets or Attributes.
   ** <p>
   ** <b>Action:</b> Fix the RowSet- or Attribute-level exceptions in the details for
   ** this exception.
   ** 
   */
   public static final String EXC_READ_ROW_XML                  = "25026";
   
   /**
   ** <b>JBO-25027: AttributeReadXMLException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred during reading the XML data for an attribute of a ViewRow. This 
   ** exception may contain other JboExceptions thrown from the set method
   ** for this attribute.
   ** <p>
   ** <b>Action:</b> Fix the JboException in the details for this exception.
   ** 
   */
   public static final String EXC_READ_ATTRIBUTE_XML            = "25027";
   
   /**
   ** <b>JBO-25028: oracle.jbo.domain.DataCreationException</b>
   ** <p>
   ** <b>Cause:</b> A domain object could not be created with the given value. Either
   ** a domain-constructor that accepts the given value does not exist, or 
   ** there is no conversion method in the domain object for the given 
   ** value type, or the domain's constructor threw an unexpected exception.
   ** <p>
   ** <b>Action:</b> Confirm that the value being passed, is valid with respect to
   ** the domain-type being created. E.g., passing a String value like
   ** "One" to <code>oracle.jbo.domain.Number</code> constructor will throw this
   ** exception.
   ** 
   */
   public static final String EXC_DATA_CREATION_WITH_MSG        = "25028";

   /**
   ** <b>JBO-25029: oracle.jbo.domain.DataCreationException</b>
   ** <p>
   ** <b>Cause:</b> The named data class (may be a domain) could not be found.
   ** <p>
   ** <b>Action:</b> Make sure that the data class is accessible from
   ** the CLASSPATH and is a valid data class.
   ** 
   */
   public static final String EXC_DATA_CREATION_CLASS_NOT_FOUND = "25029";

   /**
   ** <b>JBO-25030: InvalidOwnerException</b>
   ** <p>
   ** <b>Cause:</b> This entity is a detail in a composition association and 
   ** no container entity could be found. This could occur
   ** while creating a new entity instance by passing a non-existing master
   ** key value, or when updating the foreign-key value in this entity
   ** and there is no master entity with that foreign-key value.
   ** <p>
   ** <b>Action:</b> Provide a valid foreign-key value to the <code>create()</code> 
   ** method or <code>setAttribute()</code>
   ** method so that an appropriate master row is found for this entity.
   ** 
   */
   public static final String EXC_NO_ENTITY_OWNER               = "25030";
   
   /**
   ** <b>JBO-25031: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> The client has attempted to access an attribute of a view
   ** which is mapped to an entity row, but the corresponding entity row
   ** is null.  If the view object consists of multiple entity object bases and if the secondary
   ** entity object bases are reference-only, the entity rows may be null if the foreign key
   ** linking the primary entity to the secondary entity object is null.
   ** <p>
   ** <b>Action:</b> In such a situation, the user is not allowed to access attributes
   ** of missing entity rows.
   */
   public static final String EXC_ENTITY_ROW_MISSING            = "25031";
   
   /**
   ** <b>JBO-25032: JboSerializationException</b>
   ** <p>
   ** <b>Cause:</b> Failure trying to make the application module state or transaction
   ** state passive.
   ** <p>
   ** <b>Action:</b> The passivation target store (Database, File or Memory) may have 
   ** reported an exception. See the details of this exception for errors
   ** from the target store. 
   ** 
   */
   public static final String EXC_AM_PASSIVATE                  = "25032";
   
   /**
   ** <b>JBO-25033: JboSerializationException</b>
   ** <p>
   ** <b>Cause:</b> Trying to activate the application module state or transaction
   ** state failed.
   ** <p>
   ** <b>Action:</b> The passivation target store (Database, File or Memory) may have
   ** reported an exception. See the details of this exception for errors
   ** from the target store. The given ID (in case of activation) may be
   ** invalid/not found.
   **
   */
   public static final String EXC_AM_ACTIVATE                   = "25033";

   /**
   ** <b>JBO-25034: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> The client has attempted to locate a row with a
   ** stale row handle.  This error may
   ** be raised if the client tries to take a row out of one query collection and
   ** use its handle to find a row in another query collection.  Note that if the
   ** client calls <code>executeQuery</code> on a RowSet, it may receive a 
   ** new query collection.  Thus, you may get this error if the client retrieves a row
   ** from a RowSet, takes its row handle, calls <code>executeQuery()</code>, and
   ** then tries to locate the row using the saved handle.
   ** <p>
   ** This exception may also be raised if a row reference is used across
   ** transaction boundaries and the row handle has become stale and hence
   ** the corresponding row cannot be found.
   ** <p>
   ** <b>Action:</b> Make sure that your row handle is not stale. Perhaps, find the row
   ** again using its primary key before attempting to act on the row.
   */
   public static final String EXC_ROW_OF_HANDLE_NOT_FOUND       = "25034";
   
   /**
   ** <b>JBO-25035: JboException</b>
   ** <p>
   ** <b>Cause:</b> An application attempted to change an application module's
   ** passivation store after it had been initialized.
   ** <p>
   ** <b>Action:</b>The passivation store (Database, File or Memory) may
   ** only be initialized once.  If the customer application logic has not
   ** specified a passivation store when the serialization framework is invoked,
   ** the passivation store is initialized by the BC4J framework.  Check the
   ** client application logic for invocations of
   ** <code>ApplicationModuleImpl.setStoreForPassiveState</code>
   ** which are invoked after the application module passivation store has been initialized.
   **
   */
   public static final String EXC_INVALID_PASSIVATION_STORE     = "25035";

   /**
   ** <b>JBO-25036: InvalidObjAccessException</b>
   ** <p>
   ** <b>Cause:</b> An application invoked an object operation that is not
   ** supported in the object's current state.
   ** <p>
   ** <b>Action:</b> Remove the invalid operation invocation or provide exception
   ** handling logic.
   **
   */
   public static final String EXC_INVALID_OBJECT_ACCESS         = "25036";

   /**
   ** <b>JBO-25037: NoObjException</b>
   ** <p>
   ** <b>Cause:</b> This row set is a detail in a master-detail relationship,
   ** but it is missing a master row set iterator.  Most likely, this occurred
   ** because a master row set iterator is removed through a call to
   ** <code>removeMasterRowSetIterator()</code> and has not be replaced with an appropriate one.
   ** <p>
   ** <b>Action:</b> Call <code>setMasterRowSetIterator()</code> to provide a valid
   ** master row set iterator.
   ** 
   */
   public static final String EXC_NO_MASTER_ROW_SET_ITERATOR    = "25037";
   
   /**
   ** <b>JBO-25038: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b> The parameters passed to a business component method are invalid.
   ** <p>
   ** <b>Action:</b> Refer to error message for EXC_INVALID_PARAMETER (JBO-25006) for info.
   ** Difference between this error msg and EXC_INVALID_PARAMETER is that this
   ** one does not include a reason.  In general, we recommend using EXC_INVALID_PARAMETER
   ** instead of EXC_INVALID_PARAM_NO_EXPL_GIVEN.
   */
   public static final String EXC_INVALID_PARAM_NO_EXPL_GIVEN   = "25038";
   
   /**
   ** <b>JBO-25039: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> The client attempted to work with the current row of
   ** a row set iterator, but the iterator has no current row.
   ** <p>
   ** <b>Action:</b> Position the iterator to the correct row and perform
   ** the operation.
   */
   public static final String EXC_NO_CURRENT_ROW                = "25039";
   
   /**
   ** <b>JBO-25040: JboException</b>
   ** <p>
   ** <b>Cause:</b> The row containing a large object was not locked 
   ** before attempting to call a method on the large object that
   ** could potentially change the data of the object.
   ** <p>
   ** <b>Action:</b> Lock the row before attempting to get an output
   ** stream or write into a large object domain instance.
   */
   public static final String EXC_LOCK_ROW_BEFORE_LOB_USE        = "25040";

   /**
   ** <b>JBO-25041: oracle.jbo.domain.DataCreationException</b>
   ** <p>
   ** <b>Cause:</b> TypeFactory determined it needs to ask the TypeMapEntries
   ** class to ask to convert data, but the TypeMapEntries did not
   ** know how to perform the conversion.
   ** <p>
   ** <b>Action:</b> This usual means problems in TypeMapEntries implementation.
   ** Contact BC4J Technical Support.
   ** 
   */
   public static final String EXC_TYPEMAP_CONVERION_ID_INVALID   = "25041";
   
   /**
   ** <b>JBO-25042: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Entity row of the given handle is not found in
   ** transaction post listener list.
   ** <p>
   ** Most likely cause of this error is as follows: the user
   ** requests certain operation.  The operation tries to get access
   ** the row in database.  This fails for whatever reason (this exception's
   ** detail may have further info).  The system tries to fix the problem
   ** at the entity level.  It looks for the entity row in the
   ** transaction post listener list.  The specified row is not found.
   ** <p>
   ** <b>Action:</b> Look at the details and see if the cause can be
   ** determined from them.  Check to see if concurrent updates to
   ** database could have caused the problem.
   */
   public static final String EXC_ENTITY_NOT_FOUND_IN_TPL_LIST   = "25042";
   
   /**
   ** <b>JBO-25043: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b> Extraneous key passed in to findByKey().  For example, suppose the
   ** View Object may expect no more than a two-part key, but the key passed
   ** into findByKey is a three-part key.  Then, this exception will thrown.
   ** <p>
   ** <b>Action:</b> Provide a valid key.
   ** 
   */
   public static final String EXC_EXTRANEOUS_KEY                = "25043";
   
   
   /**
   ** <b>JBO-25044: DefinitionChangedException</b>
   ** <p>
   ** <b>Cause:</b> Trying to activate the application module state or transaction
   ** with an older version of metadata into an application module with a later metadata 
   ** definition of the Business Components.
   ** <p>
   ** <b>Action:</b> A newer version of the application definitions objects is now
   ** running and trying to activate an Application state which was passivated with
   ** an earlier version.
   **
   */
   public static final String EXC_AM_ACTIVATE_DEF_CHANGED       = "25044";

   /**
   ** <b>JBO-25045: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt to synchronize iterator implicitly is detected in 3 tier
   ** running environment.  When ApplicationModule synchronization mode is SYNC_BATCH,
   ** iterator synchronization should only be done explictly.
   ** <p>
   ** <b>Action:</b> Remove code/operation that attempts to synchronize iterator
   ** implicitly.
   */
   public static final String EXC_INVALID_OPER_SYNCITERATOR     = "25045";
   
   /**
   ** <b>JBO-25046: RowNotAvailableException</b>
   ** <p>
   ** <b>Cause:</b> This exception is thrown when running in 3 tier SYNC_BATCH
   ** mode.  The user requested a row, but that row is not available in the cache.
   ** <p>
   ** <b>Action:</b> Make appropriate API calls to bring the required
   ** row into cache.  Then, try to get the row again.
   */
   public static final String EXC_ROW_NOT_AVAILABLE             = "25046";
   
   /**
   ** <b>JBO-25047: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt to make a call to server detected for an
   ** operation that is supposed to work only with client cache.
   ** <p>
   ** <b>Action:</b> Remove code/operation that attempts to call server.
   */
   public static final String EXC_INVALID_SERVER_CALL_FOR_BATCH = "25047";
   
   /**
   ** <b>JBO-25048: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> This operation is invalid for this working set object.
   ** It may be because the operation doesn't make sense in batch mode,
   ** or because the batch communication mode
   ** (WSApplicationModuleImpl.getBatchCommMode()) does not allow this
   ** operation.
   ** <p>
   ** <b>Action:</b> Remove code/operation that calls the named method
   ** of set the batch communication mode to allow this operation.
   */
   public static final String EXC_OPER_INVALID_FOR_WS_OBJ       = "25048";
   
   /**
   ** <b>JBO-25049: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to set an batch mode for an entity that has
   ** a primary key marked as Refresh-on-insert.
   ** <p>
   ** <b>Action:</b> Do not set this entity type into batch mode.
   ** 
   */
   public static final String EXC_OPER_BATCH_MODE               = "25049";

   /**
   ** <b>JBO-25050: BatchDMLException</b>
   ** <p>
   ** <b>Cause:</b> Posting entities in batch mode failed with a set of exceptions
   ** <p>
   ** <b>Action:</b> Fix the cause for each of the exception in the details array.
   ** 
   */
   public static final String EXC_DML_BATCH_MODE_POST           = "25050";


   /**
   ** <b>JBO-25051: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> The client has attempted to locate a row with a
   ** range index, but the Row Set Iterator's range does not have a row
   ** at the index.
   ** <p>
   ** It may be that the range index is too big (>= the range size), or
   ** that the range is at the bottom and the range index is beyond the
   ** last row of the Row Set.
   ** <p>
   ** Or, the Row Set may have been reset because of operations like
   ** rollback and clear-cache.  Hence, the range is empty and no row
   ** is found
   ** <p>
   ** <b>Action:</b> Make sure that your Row Set Iterator is open
   ** and has rows in its range.  Also, make sure that the range index
   ** falls between the first and the last row of the range.
   */
   public static final String EXC_ROW_OF_RANGE_INDEX_NOT_FOUND  = "25051";


   /**
   ** <b>JBO-25052: JboException</b>
   ** <p>
   ** <b>Cause:</b> A ViewObject with no key attributes has transient
   ** passivatable attributes. This type of ViewObject cannot participate
   ** in passivation/activation. 
   ** <p>
   ** <b>Action:</b> Set one or more attributes as key attributes for 
   ** this ViewObject
   */
   public static final String EXC_NO_KEY_ATTR_VO_ACTIVATED = "25052";


   
   /**
   ** <b>JBO-25053: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to navigate a rowset in Range Paging mode
   ** when the rowset has inserted/removed rows.
   ** <p>
   ** <b>Action:</b> Post this transaction before navigating.
   ** 
   */
   public static final String EXC_INVALID_OPER_DIRTY_PAGE   = "25053";

   /**
   ** <b>JBO-25054: JboException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to activate a stack snapshot which does not exist.  The specified snapshot may already have been activated or the stack may already have been cleared by a previous rollback/commit.
   ** <p>
   ** <b>Action:</b> Ensure that stack snapshot ids are maintained by the
   ** application across transaction boundaries.
   **
   */
   public static final String EXC_INVALID_STACK_SNAPSHOT_ID   = "25054";

   /**
   ** <b>JBO-25055: JboException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to remove a persistent snapshot which is referenced by the snapshot stack.
   ** <p>
   ** <b>Action:</b> Clear the snapshot stack before attempting to remove the
   ** the referenced snapshot.
   **
   */
   public static final String EXC_CANNOT_REMOVE_REFERENCED_SNAPSHOT   = "25055";

   /**
   ** <b>JBO-25056: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt has been made to call removeFromCollection()
   ** on an Entity row.  It is illegal to call removeFromCollection() on
   ** an Entity row.
   ** <p>
   ** <b>Action:</b> Remove code that calls removeFromCollection() on an
   ** Entity row.
   */
   public static final String EXC_ENTITY_ROW_REMOVE_FROM_COLL = "25056";

   /**
   ** <b>JBO-25057: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> In LOCK_OPTUPDATE locking mode, an attempt was made
   ** to update an Entity row.  The update operation failed to update
   ** any row.
   ** <p>
   ** <b>Action:</b> Another user may have modified the row and committed
   ** the changes.
   */
   public static final String EXC_ENTITY_UPDATE_FOUND_NO_MATCH = "25057";

   /**
   ** <b>JBO-25058: NoDefException</b>
   ** <p>
   ** <b>Cause:</b> No business component definition found with the given name
   ** in the project classpath.
   ** <p>
   ** <b>Action:</b> Provide a correct name for the business component definition.
   ** If the definition is not in the classpath, you must include it there.
   ** Names are of the format <code>myProjectPackage.BusinessPackage.BusinessComponent</code>.
   ** This error can also occur if there is a case conflict, as when the database expects "DEPTNO"
   ** and receives "Deptno" instead.
   */
   public static final String EXC_NO_DEFINITION_WITH_OWNER     = "25058";
   
   /**
   ** <b>JBO-25059: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> This View Object is not Entity based, and its ManageRowsByKey
   ** flag is <code>true</code>.  Yet, its key definition is empty.  Restated, the
   ** user has asked for the View rows to be managed by keys, but the key definition
   ** is empty (which would produce empty keys for all rows).
   ** <p>
   ** <b>Action:</b> In order to manage EO-less View Object by key, a meaningful
   ** (non-empty) key definition must be supplied.
   */
   public static final String EXC_MANAGE_ROWS_BY_KEY_BUT_EMPTY_KEY_DEF = "25059";
   
   /**
   ** <b>JBO-25060: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception was thrown when we tried to 
   ** retrieve the next row from JDBC ResultSet.
   ** <p>
   ** <b>Action:</b> Take a look at the detail exception for further information
   ** and fix underlying problems.
   */
   public static final String EXC_RETRIEVE_NEXT_FROM_RESULT_SET = "25060";
   
   /**
   ** <b>JBO-25061: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> ViewRowSetImpl.setPassivationEnabled called for internal rowset
   ** <p>
   ** <b>Action:</b> Create a datamodel ViewObject instance and use rowsets from that
   ** ViewObject to make them passivation enabled.
   */
   public static final String EXC_INVALID_ENABLE_PASSIVATION = "25061";

   /**
   ** <b>JBO-25062: NoObjException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to create detail RowSet.  However,
   ** no matching detail ViewObject could be found.
   ** <p>
   ** <b>Action:</b> You can create a detail RowSet only if a matching 
   ** ViewObject is present.  Make sure that an appropriate ViewObject is
   ** there before calling to create a detail RowSet.
   */
   public static final String EXC_NO_MATCHING_DETAIL_VIEWOBJECT = "25062";

   /**
   ** <b>JBO-25063: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> This operation is invalid for this working set object because
   ** the working set object is not bound to actual implementation object.
   ** <p>
   ** <b>Action:</b> This action must be performed after the working set
   ** object is bound.
   */
   public static final String EXC_OPER_WS_OBJ_NOT_BOUND         = "25063";
   
   /**
   ** <b>JBO-25064: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b> A call was made to define or set a named where-clause parameter
   ** value.  However, the named variable's "kind" is not "where".  That is,
   ** the variable is not a where-clause parameter.
   ** <p>
   ** <b>Action:</b> Make sure that the variable name is correct and that
   ** the named variable is a where-clause parameter.
   */
   public static final String EXC_INVALID_VAR_KIND_FOR_WHERE    = "25064";
   
   /**
   ** <b>JBO-25065: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to remove a named where-clause parameter.
   ** However, this where-clause parameter is owned by neither the RowSet
   ** nor the ViewObject.  Therefore, the parameter cannot be removed.
   ** <p>
   ** <b>Action:</b> It is illegal to try to remove a named where-clause parameter
   ** that does not belong to either the RowSet or the ViewObject.
   */
   public static final String EXC_NAMED_WHERE_PARAM_NOT_OWNED_BY_VO = "25065";
   
   /**
   ** <b>JBO-25066: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to include QUERY_MODE_SCAN_DATABASE_TABLES
   ** in the View Object's query mode (through a call to setQueryMode()).  However,
   ** this View Object can perform query only through Entity Object.  Hence,
   ** QUERY_MODE_SCAN_DATABASE_TABLES is inappropriate.
   ** <p>
   ** <b>Action:</b> The View Object is probably based on an Entity, which
   ** in turn is based on a RowSet (EntityDefOverRowSet).  It is illegal to
   ** use QUERY_MODE_SCAN_DATABASE_TABLES for a View Object built on top of
   ** an Entity which is built over a Row Set.  Do not include
   ** QUERY_MODE_SCAN_DATABASE_TABLES in the setQueryMode() invocation.
   */
   public static final String EXC_INVALID_QM_SCAN_DATABASE_TABLES = "25066";
   
   /**
   ** <b>JBO-25067: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to create a new instance of an Entity
   ** Row.  However, this Entity Definition has a subclass Entity Definition
   ** with no discriminator.  That is, this Entity Definition should really
   ** be abstract.
   ** <p>
   ** <b>Action:</b> Typically in this situation, the base class should not
   ** instantiate any row.  Use the subclass Entity to create the row
   */
   public static final String EXC_NEW_EO_INST_WITH_NO_DISCR_SUBCLASS = "25067";
   
   /**
   ** <b>JBO-25068: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to create a new instance of an Entity
   ** Row.  However, this Entity Definition isa subclass Entity Definition
   ** with no discriminator, and a base EO has a row already instantiated.
   ** We have a conflict because nothing discriminates this Entity from
   ** the base Entity.
   ** <p>
   ** <b>Action:</b> Typically in this situation, the base class should not
   ** instantiate any row.  Use the subclass Entity to create the row
   */
   public static final String EXC_NEW_EO_INST_WITH_NO_DISCR_BASE = "25068";
   
   /**
   ** <b>JBO-25069: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> Two sibling subclasses of a Row Definition are found,
   ** but the Row Definition has no discriminator.  This condition is disallowed
   ** because when a row is either retrieved or created, we cannot determine
   ** the correct row class.
   ** <p>
   ** <b>Action:</b> Either define discriminator attributes, or do not
   ** create siblings in the row class hierarchy.
   */
   public static final String EXC_SIBLING_SUBCLASS_WITHOUT_DISCR = "25069";
   
   /**
   ** <b>JBO-25070: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> This view object of entity is using Oracle number style
   ** binding (:1, :2, ... binding, not named binding) or JDBC style (? binding).
   ** A variable of where-clause-param kind is found, but the extended int array
   ** that designates where the value should be bound is missing.
   ** <p>
   ** <b>Action:</b> When defining a variable for where-clause param in conjunction
   ** with a binding style which is not Oracle named binding, you must specify
   ** an int array that designates where the value should be bound.
   */
   public static final String EXC_INVALID_VAR_WHERE_MISSING_EXT_INT_ARR = "25070";
   
   /**
   ** 
   ** <b>JBO-25200: NotConnectedException</b>
   ** <p>
   ** <b>Cause:</b> The application module is not connected to the database. 
   ** <p>
   ** <b>Action:</b> Provide a valid set of connection credentials to connect to a
   ** database.
   **
   */
   public static final String EXC_NOT_CONNECTED                 = "25200";
   
   /**
   ** <b>JBO-25201: AlreadyConnectedException</b>
   ** <p>
   ** <b>Cause:</b> Trying to re-establish a database connection.
   ** <p>
   ** <b>Action:</b> Disconnect the current database connection before trying to re-establish
   ** the JDBC connection.
   **
   */
   public static final String EXC_ALREADY_CONNECTED             = "25201";

   /**
   ** <b>JBO-25221: JboException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to call a method that is either not implemented or not
   ** supported.
   ** <p>
   ** <b>Action:</b> This method is not available on the called object. E.g. <code>setAttribute()</code>
   ** in <code>oracle.jbo.Key</code> class is not implemented and will throw this exception.
   ** 
   */
   public static final String EXC_INVALID_METHOD_CALL           = "25221";
   /**
   ** <b>JBO-25222: ApplicationModuleCreateException</b>
   ** <p>
   ** <b>Cause:</b> There are a number of reasons the application module could not be 
   ** created:
   ** <ul>
   ** <li>If your business components are deployed in local mode, they may not be on the classpath.
   ** <li>You may have unresolved classes on the server.
   ** <li>You may not have granted Java2 permissions.
   ** <li>Your Java pool size may be too small.
   ** </ul>
   ** <p>
   ** <b>Action:</b> Depending on the cause, chose from the following actions:
   ** <p><b>If your business components are deployed in local mode, they may not be on the classpath.</b>
   ** <br>If this is the cause of the error, the exception will usually be followed by a different exception,
   ** <code>JBO-25002: NoDefException</code>. If this occurs, make sure 
   ** you've done all of the following:
   ** <ol>
   ** <li>Made a library for your business components.
   ** <li>Added a library to your client's project properties.
   ** <li>Included the library on the "libraries" page when you created a deployment profile
   ** for your client (whether your client was a web application or a command-line application).
   ** <li>Copied the library with your client to the target platform (whether your client was a
   ** web application or a command-line application).
   ** <li>Included all the files you copied (including the library) when you set the classpath
   ** on the target platform.
   ** </ol>
   ** <p>
   ** <b>You may have unresolved classes on the server.</b>
   ** <br>Try the following procedure to resolve any unresolved classes on the database.
   ** <ol>
   ** <li>In the System Navigator, right-click the JDBC connection you used to deploy the Business Components project.
   ** <li>Choose Invoke SQL*Plus from the context menu.
   ** <li>Copy and paste the following SQL*Plus script into the SQL*Plus window.
   ** <code>
   ** <br>set termout off
   ** <br>set echo off
   ** <br>set heading off
   ** <br>set pages 999
   ** <br>set linesize 2000
   ** <br>set feedback off
   ** <br>select 'alter java class "'|| replace(dbms_java.longname(object_name),'/','.')||'" resolve;'
   ** <br>from user_objects
   ** <br>where object_type='JAVA CLASS' 
   ** <br>and status = 'INVALID' 
   ** <br>spool C:\temp\resolve.sql 
   ** <br>/
   ** <br>spool off
   ** <br>set echo on
   ** <br>set termout on
   ** <br>@C:\temp\resolve.sql 
   ** </code>
   ** </ol>
   ** <p><b>You may not have granted Java2 permissions.</b>
   ** <br>If this is the cause of the error, there will be permissions errors in the database trace file.
   ** To correct the problem, see the help topic "Granting Permissions on a Business Components EJB" for
   ** information on granting Java2 permissions.
   ** <p> Note: The location of the database trace file varies from installation to installation, but in a
   ** default Windows NT installation, the file will be in the directory <code>ORACLE_HOME\admin\orcl\ udump</code>
   ** and will have the form <code>orcl????.trc</code>.
   ** <p><b>Your Java pool size may be too small</b>
   ** <br>Business Components for Java deployed as EJBs work best with a Java pool size of at least 50MB. 
   ** Edit your <code>init.ora</code> file and check the <code>java_pool_size</code> parameter. If it is under 50MB, change it, 
   ** restart your database, and try your connection again.
   ** 
   */
   public static final String EXC_APPMODULE_CREATE              = "25222";
   
   /**
   ** <b>JBO-25223: ApplicationModuleCreateException</b>
   ** <p>
   ** <b>Cause:</b> When business components are running inside JServer, only one root application module
   ** may be created.  This is because JServer (already) provides one transaction
   ** context.
   ** <p>
   ** <b>Action:</b> It is illegal to attempt to create multiple root transactions when
   ** running inside JServer.
   **
   */
   public static final String EXC_ROOT_APPMOD_ALREADY_CREATED   = "25223";

   /**
   ** <b>JBO-25224: JboException</b>
   ** <p>
   ** <b>Cause:</b> Trying to retain the application module state during a transaction
   ** disconnect failed.
   ** <p>
   ** <b>Action:</b> The disconnect and retain application module state target requires that
   ** no database state exist before the transaction connection is closed.
   ** Examples of database state include open database cursors in non-forward
   ** only view objects, database locks, and uncommitted database changes.  The
   ** client should clean up this state by fetching or resetting any open view
   ** objects and committing any uncommitted changes.
   **
   */
   public static final String EXC_DATABASE_STATE_EXISTS         = "25224";

   /**
   ** <b>JBO-25226: ApplicationModuleCreateException</b>
   ** <p>
   ** <b>Cause:</b> This application module definition contains recursive
   ** references to child application modules. For example, if application
   ** module definition appMod1 contains a child application module of appMod2, and
   ** appMod2 contains appMod1, this error will be raised.
   ** <p>
   ** <b>Action:</b> Remove recursive application module definition references.
   */
   public static final String EXC_RECURSIVE_AM_INCLUSION        = "25226";

   /**
   ** <b>JBO-25227: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> The user has attempted to create a view link (in an application
   ** module) that will result in a recursive loop of view links.
   ** The error message should show a chain of recursive master-detail relationships.
   ** <p>
   ** <b>Action:</b> If a static view link is causing the recursion, remove the
   ** view link from the application module.  If a dynamic view link is causing the
   ** recursion, remove the code that creates the recursive view link.
   */
   public static final String EXC_RECURSIVE_VIEW_LINKS          = "25227";

   /**
   ** <b>JBO-25301: InvalidOwnerException</b>
   ** <p>
   ** <b>Cause:</b> While traversing the parenthood chain for application modules,
   ** a child application module was found with no container (parent)
   ** application module.
   ** <p>
   ** <b>Action:</b> If this application has added custom business component classes, it may be that
   ** the application code is attempting to access a child application
   ** module before it is fully initialized.  If this is not the case,
   ** this error probably represents some internal error in BC4J framework, in which case
   ** contact BC4J Technical Support.
   */
   public static final String EXC_CHILD_AM_WITH_NO_PARENT       = "25301";
   
   /**
   ** <b>JBO-25302: InvalidOwnerException</b>
   ** <p>
   ** <b>Cause:</b> A business component is found without a container (parent)
   ** application module.
   ** <p>
   ** <b>Action:</b> If this application has added custom business component classes,
   ** it may be that the application code is attempting to access a business component
   ** before it is fully initialized. If this is not the case,
   ** this error probably represents some internal error in BC4J framework, in which case
   ** contact BC4J Technical Support.
   */
   public static final String EXC_COMP_OBJ_WITH_NO_PARENT       = "25302";
   
   /**
   ** <b>JBO-25303: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> A dirty entity cache cannot be cleared.  The client asked to
   ** clear an entity cache but some rows in the entity cache have been
   ** modified.  An entity cache with modified rows cannot be cleared.
   ** <p>
   ** <b>Action:</b> Do not attempt to clear an entity cache with modified rows
   ** in it.
   */
   public static final String EXC_CANNOT_CLEAR_DIRTY_ECACHE     = "25303";
   
   /**
   ** <b>JBO-25305:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_UNKNOWN_FILE_ENCODING         = "25305";

   /**
   ** <b>JBO-25306: JTPersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Could not persist a design-time attribute into the XML file.
   ** <p>
   ** <b>Action:</b> Identify the offending design-time attribute and contact
   ** BC4J Technical Support.
   */
   public static final String EXC_CANNOT_PERSIST_DT_ATTR        = "25306";

   /**
   ** <b>JBO-25307: JTPersistenceException</b>
   ** <p>
   ** <b>Cause:</b> XML file is not open.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support with how you
   ** ran into the problem.
   */
   public static final String EXC_XML_FILE_NOT_OPEN             = "25307";

   /**
   ** <b>JBO-25308: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to modify the primary key of
   ** an existing entity bean.  This is disallowed by EJB.
   ** <p>
   ** <b>Action:</b> Do not modify primary key of an old (not-new)
   ** entity bean.
   */
   public static final String EXC_FACADE_CANNOT_MODIFY_PK       = "25308";

   /**
   ** <b>JBO-25309: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> The primary key of an entity bean is null.
   ** This is disallowed by EJB.
   ** <p>
   ** <b>Action:</b> Set the primary key to be not null.
   */
   public static final String EXC_FACADE_PK_CANNOT_BE_NULL      = "25309";

   // from cs\Persistence Bundle.java
   
   /**
   ** <b>JBO-26000: JboException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to load metadata objects failed. It may have unexpected
   ** data or the XML data may be corrupt.
   ** <p>
   ** <b>Action:</b> Verify that the XML metadata for various components is valid.
   ** 
   */
   public static final String EXC_GENERIC_PERSISTENCE           = "26000";
   
   /**
   ** <b>JBO-26001: NoXMLFileException</b>
   ** <p>
   ** <b>Cause:</b> Could not open the named XML file for reading.
   ** <p>
   ** <b>Action:</b> Try the following:
   ** <ul>
   ** <li> Make sure that the file is present.  In particular, if the file is
   ** to be found in a Zip/JAR file, make sure that the Zip/JAR file is
   ** included in the CLASSPATH.
   ** <li> This error is also reported if the name of the XML file does not
   ** match the object Name specified in the XML file.  If the file system
   ** support case insensitive file names (e.g., Windows NT), make sure
   ** that the file name matches the object Name in the XML file in
   ** case-sensitive fashion.
   ** <li>For a JPX file, this error is reported if the JPX file is missing
   ** the <code>JboProject</code> XML tag.  Check the JPX file to make sure that the valid
   ** tag is in there.
   ** <li>One XML file may be extending another XML file (specified by the
   ** Extends element in this XML file).  This error is reported if the
   ** base XML file is not found.
   ** <li>When loading the XML file for a package (JboPackage tag), this
   ** error is reported if some unexpected error occurs while loading
   ** a containee.
   ** </ul><p>
   ** In all of the above cases, a more descriptive message may be printed
   ** on Diagnostic.  If you are not seeing Diagnostic messages, you can
   ** run your application with Diagnostic turned on, as in
   ** "java -Djbo.debugoutput=console ...", to see Diagnostic messages.
   */
   public static final String EXC_LOCATING_XML_FILE             = "26001";
   
   /**
   ** <b>JBO-26002: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Some XML parsing exception (<code>oracle.xml.parser.v2.XMLParseException</code>) was thrown.
   ** <p>
   ** <b>Action:</b> The XMLParseException information is output to Diagnostic.
   ** If you are not seeing diagnostic messages, you can
   ** run your application with diagnostic turned on, as in
   ** "java -Djbo.debugoutput=console ...", to see diagnostic messages.
   */
   public static final String EXC_PARSING_XML_FILE              = "26002";
   
   /**
   ** <b>JBO-26003: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while loading entity object definitions.  
   ** An attribute index in the Java class for this entity
   ** has a mismatch with the index in the definition, or an attribute
   ** index is missing in the Java class.
   ** <p>
   ** <b>Action:</b> Ensure that the indices of attributes in the definition for this entity
   ** match the indices defined in the Java class for this entity.
   */
   public static final String EXC_ATTRIBUTE_INDEX_MISMATCH      = "26003";
   
   /**
   ** <b>JBO-26004: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to set the base definition of another definition
   ** object, e.g., setting B's base definition to A (i.e., B Extends A).  However,
   ** A already extends B.  Setting a recursive (circular) subclassing
   ** relationship among definition objects is illegal.
   ** <p>
   ** <b>Action:</b> Review your subclassing hierarchy of your definition objects and correct
   ** errors.
   **
   */
   public static final String EXC_RECURSIVE_BASE_DEF            = "26004";
   
   /**
   ** <b>JBO-26005: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> The fetch mode specified in the view definition XML file is
   ** not valid.
   ** <p>
   ** <b>Action:</b> Check the content of the XML file for the view definition.
   ** Look for an XML element named "FetchMode".  Make sure that the
   ** value for that element is valid.  Valid values are:  "FETCH_AS_NEEDED",
   ** "FETCH_ALL", and "FETCH_DEFAULT".
   **
   */
   public static final String EXC_INVALID_FETCH_MODE            = "26005";
   
   /**
   ** <b>JBO-26006: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> The fetch size specified in the view definition XML file is
   ** not valid.
   ** <p>
   ** <b>Action:</b> Check the content of the XML file for the view definition.
   ** Look for an XML element named "FetchSize".  Make sure that the
   ** value for the element is a positive integer.
   */
   public static final String EXC_INVALID_FETCH_SIZE            = "26006";
   
   /**
   ** <b>JBO-26007: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> The maximum fetch size specified in the view definition XML file is
   ** not valid.
   ** <p>
   ** <b>Action:</b> Check the content of the XML file for the view definition.
   ** Look for an XML element named "MaxFetchSize".  Make sure that the
   ** value for the element is a non-negative integer, or "MAX_FETCH_UNLIMITED",
   ** or "MAX_FETCH_DEFAULT".  A MaxFetchSize of 0 is the same as MAX_FETCH_UNLIMITED.
   */
   public static final String EXC_INVALID_MAX_FETCH_SIZE        = "26007";
   
   /**
   ** <b>JBO-26008: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> A problem is found in resolving a view link definition or an association.
   ** In case of a view link, this error may be caused by the fact that
   ** the source or destination view object cannot found.  Or, if the view
   ** link ends have attribute names, this error may indicate that the named
   ** attributes cannot be found.  Similarly, for an association, this error
   ** indicates that either source or destination entity object or attributes
   ** involved in the association cannot be found.
   ** <p>
   ** <b>Action:</b> Make sure the XML definition for the view link/association has correct
   ** view object/entity object/attribute names.
   */
   public static final String EXC_UNRESOLVED_REFERENCE          = "26008";
   
   /**
   ** <b>JBO-26009: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> This error occurs if the application uses meta object serialization
   ** files (.ser files) instead of XML files.  It indicates that after
   ** the .ser file is deserialized, the top level object returned from
   ** deserialization is not an instance of <code>oracle.jbo.server.xml.JboElementImpl</code>.
   ** <p>
   ** <b>Action:</b> This probably means that the .ser file is corrupt.
   */
   public static final String EXC_INVALID_SER_FILE              = "26009";
   
   /**
   ** <b>JBO-26010: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Entity attribute name in the view definition XML file is invalid
   ** or is not found.
   ** <p>
   ** <b>Action:</b>
   ** Make sure that the entity name is valid.  Also, check to make
   ** sure that the named attribute does exist in the entity object.
   ** The entity object is identified by the EntityUsage element.
   **
   */
   public static final String EXC_INVALID_ENTITY_ATTR_NAME      = "26010";
   
   /**
   ** <b>JBO-26011: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Attribute definition found in XML file is invalid.
   ** It is missing SQLType value.
   ** <p>
   ** <b>Action:</b> Correct the error in the XML file.
   */
   public static final String EXC_SQLTYPE_NOT_SPECIFIED         = "26011";
   
   /**
   ** <b>JBO-26012: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> The view link definition in the XML file is missing either the
   ** source or destination view link end.  For a view link XML file,
   ** two elements named ViewLinkDefEnd should be found.
   ** <p>
   ** <b>Action:</b> Correct the error in the XML file.
   */
   public static final String EXC_INVALID_VIEWLINK_DEFN         = "26012";
   
   /**
   ** <b>JBO-26013: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Meta object name passed for lookup is invalid.
   ** <p>
   ** <b>Action:</b> Normally, the meta object name is a dot-separated name of the
   ** meta object.  For an entity object named Emp in package1.example,
   ** the correct name would be <code>package1.example.Emp</code>. To correct, locate
   ** where the invalid name is coming from (could be meta object names
   ** mentioned in an XML file, or the name of the project, etc.) and
   ** change the name to a valid one.
   */
   public static final String EXC_XML_CONTEXT_LOOKUP            = "26013";
   
   /**
   ** <b>JBO-26014:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   **
   */
   public static final String EXC_XML_CONTEXT_BIND              = "26014";
   
   /**
   ** <b>JBO-26015: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> A view definition does not include a discriminator
   ** column of an entity base.  If an entity base has discriminator
   ** columns, it must include all of them in the view object's
   ** attribute mapping.
   ** <p>
   ** <b>Action:</b> Change the view definition to include discriminator column
   ** attributes.
   */
   public static final String EXC_DISCR_COL_NOT_MAPPED          = "26015";
   
   /**
   ** <b>JBO-26016: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> You cannot set customer query (calling <code>setQuery()</code>)
   ** on a view object if it is the detail view object in a master detail
   ** view link.
   ** <p>
   ** <b>Action:</b> Do not call <code>setQuery()</code> if the view object is a detail.
   */
   public static final String EXC_CANNOT_SET_USER_QUERY_WITH_VL = "26016";
   
   /**
   ** <b>JBO-26017: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> An entity association definition in an XML file is invalid.
   ** In particular, this error means that either of the two association
   ** ends ("AssociationEnd" elements in the XML file) are missing "Attributes",
   ** which lists source or destination attributes.
   ** <p>
   ** <b>Action:</b> Correct the error(s) in the XML file.
   */
   public static final String EXC_INVALID_ENTITYASSOC_DEFN      = "26017";
   
   /**
   ** <b>JBO-26018: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to post a row with no attribute set.
   ** Some databases (in particular Oracle) do not allow an INSERT
   ** statement with no VALUE specified.
   ** <p>
   ** <b>Action:</b> Set some attributes on the row before attempting to insert it
   ** into the database.
   */
   public static final String EXC_INSERT_WITH_NO_ATTR_SET       = "26018";
   
   /**
   ** <b>JBO-26019: JboException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to remove a master which has detail entities. In the case
   ** of a composition, a master cannot be removed if it has details.
   ** <p>
   ** <b>Action:</b> Remove all the details of this master by accessing the details via
   ** an association and removing all of them.
   */
   public static final String EXC_REMOVE_WITH_DETAILS           = "26019";
   
   /**
   ** <b>JBO-26020: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> The application code tried to take a row from one row set (or view object)
   ** and insert it into another row set (view object).  In response,
   ** the framework will make a "copy" of the row in the new row set.  This new
   ** row will share references to the underlying entity objects.
   ** However, if the source and destination row sets do not share any
   ** entity object bases at all, this operation will fail as it does not find
   ** any entity rows to share.
   ** <p>
   ** <b>Action:</b> When attempting to take a row from one row set and insert into
   ** another, make sure that they share at least one entity object base.
   **
   */
   public static final String EXC_NO_MATCHING_EO_BASE           = "26020";

   /**
   ** <b>JBO-26021: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> A NullPointerException was thrown while parsing an XML file.
   ** A possible cause for this is that the DTD file is missing
   ** (<code>oracle.jbo.dtd.jbo*.dtd</code>).
   ** <p>
   ** <b>Action:</b> Make sure the appropriate DTD file is present.
   **
   */
   public static final String EXC_XML_MISSING_DTD               = "26021";

   /**
   ** <b>JBO-26022: CustomClassNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Custom class could not be found and loaded. The custom class may
   ** be for a component (e.g., view object), a definition (e.g., view definition),
   ** or a row (e.g., View row, Entity row).
   ** <p>
   ** <b>Action:</b> Make sure that the named class is reachable from the CLASSPATH.
   ** The detail exception (if present) will give you more specific reasons why
   ** the attempt to locate and load the custom class failed.
   **
   */
   public static final String EXC_CUSTOM_CLASS_NOT_FOUND        = "26022";

   /**
   ** <b>JBO-26023: CustomClassNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Custom class was found and loaded, but it is invalid in that it
   ** is not assignable to a framework (super) class.
   ** <p>
   ** <b>Action:</b> Make sure that the custom class subclasses the appropriate framework
   ** (super) class.
   **
   */
   public static final String EXC_CUSTOM_CLASS_NOT_ASSIGNABLE   = "26023";

   /**
   ** <b>JBO-26024: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while creating initial context.
   ** This error usually carries a detail exception which will
   ** give further information on the cause of the error.
   ** <p>
   ** <b>Action:</b> If BC4J is running inside JServer, make sure that the database
   ** user (schema) has the setContextClassLoader permission.
   ** To grant this, the database system administrator can invoke the following PL/SQL procedure:
   ** <p><code>EXEC DBMS_JAVA.GRANT_PERMISSION('&&1', 'SYS:java.lang.RuntimePermission',
   ** 'setContextClassLoader', null);</code>
   */
   public static final String EXC_XML_CREATE_INITIAL_CONTEXT    = "26024";


 /**
   ** <b>JBO-26025: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while trying to get System properties.
   ** Specifically, System.getProperties() call failed.
   ** <p>
   ** <b>Action:</b> If BC4J is running inside JServer, make sure that the database
   ** user (schema) has the proper property permission.
   ** To grant this, database system can invoke the following PL/SQL procedure:
   ** <p><code>EXEC DBMS_JAVA.GRANT_PERMISSION('&&1', 'SYS:java.util.PropertyPermission',
   ** '*', 'read');</code>
   **
   */
   public static final String EXC_SYSTEM_GET_PROPERTIES         = "26025";

   /**
   ** <b>JBO-26026: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while trying to get load properties.
   ** <p>
   ** <b>Action:</b> Check to see if the named properties file contains
   ** valid Java properties.
   */
   public static final String EXC_LOADING_PROPERTIES            = "26026";


   /**
   ** <b>JBO-26027: JboException</b>
   ** <p>
   ** <b>Cause:</b> Unable to find a resource
   ** <p>
   ** <b>Action:</b> Check to see if the resource exists and the bc4j codebase 
   **    has adequate permissions to load the resource.
   ** 
   */
   public static final String EXC_RESOURCE_NOT_FOUND            = "26027";

   /**
   ** <b>JBO-26028: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> A view definition does not include a primary key
   ** attribute of an entity base.  When a view object uses an entity
   ** as one of its entity bases, it must include all primary key attributes
   ** of the underlying entity object.
   ** <p>
   ** <b>Action:</b> Change the view definition to include all primary key
   ** attributes.
   */
   public static final String EXC_PK_ATTR_NOT_MAPPED            = "26028";
   
   /**
   ** <b>JBO-26029: CustomClassNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Custom type map class could not be found and loaded.
   ** <p>
   ** <b>Action:</b> Make sure that the named class is reachable from the CLASSPATH.
   ** If jbo.TypeMapEntries property is specified, make sure that the
   ** property value is correct.  Also, though unlikely, this may be caused by
   ** an improper implementation of SQLBuilder where it is returning an incorrect 
   ** value for type map class name.
   ** <p>
   ** The detail exception (if present) will give you more specific reasons why
   ** the attempt to locate and load the custom class failed.
   */
   public static final String EXC_TYPEMAP_CLASS_NOT_BE_LOADED   = "26029";

   /**
   ** <b>JBO-26030: AlreadyLockedException</b>
   ** <p>
   ** <b>Cause:</b> This row has already been locked by another user or transaction.
   ** <p>
   ** <b>Action:</b> Try locking the row again and the operation should succeed after the 
   ** other user or transaction has released the lock.
   **
   */
   public static final String EXC_ALREADY_LOCKED                = "26030";

   /**
   ** <b>JBO-26031: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> Problem in secondary entity base definition in view definition.
   ** The named entity base is supposed to use the named entity association end
   ** to join it with another entity base, but, when resolved with the association
   ** definition, the association end does not resolve to the same entity.  For
   ** example, suppose one builds a view object with Dept and Emp.  Emp is supposed
   ** to join with Dept using the EmpEnd of the DeptEmp assocation.  For such
   ** a view definition, BC4J verifies that EmpEnd indeed is from Emp entity.
   ** If EmpEnd was from another entity, say Person (or Dept), it would not be
   ** correct to use that assocation end to perform join.
   ** <p>
   ** <b>Action:</b> Most commonly, this is caused by incorrect information
   ** in the view object's XML file.  Make sure that the 'AssociationEnd'
   ** for the named 'EntityUsage' is not pointing at the wrong (the other)
   ** end of assocation.
   */
   public static final String EXC_INVALID_ASSOC_END_FOR_ENTBASE = "26031";

   /**
   ** <b>JBO-26032: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> The attempted operation is invalid for a ViewCriteria or
   ** ViewCriteriaRow.
   ** <p>
   ** <b>Action:</b> Remove code that attempts this operation.
   */
   public static final String EXC_INVALID_OPER_VIEW_CRITERIA    = "26032";
   
   /**
   ** <b>JBO-26033: JboException</b>
   ** <p>
   ** <b>Cause:</b>: Cannot find application definition of the given name
   ** <p>
   ** <b>Action:</b>: Fix the application definition name or make the appropriate .cpx file
   ** available in the classpath.
   */
   public static final String EXC_NULL_APPDEF                   = "26033";

   /**
   ** <b>JBO-26034: JboException</b>
   ** <p>
   ** <b>Cause:</b>: Cannot find configuration information in the application definition file
   ** <p>
   ** <b>Action:</b>: Fix the Configuration name or make the appropriate .cpx file
   ** available in the classpath.
   */
   public static final String EXC_NULL_SESSDEF                  = "26034";
   
   /**
   ** <b>JBO-26035: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> A view definition is found with an entity usage definition
   ** where the secondary entity usage's association description
   ** is incomplete.
   ** <p>
   ** <b>Action:</b> Examine the view object's XML file.
   ** A secondary entity usage's association description should have the
   ** following elements: 'Association', 'AssociationEnd', and
   ** 'SourceUsage'.  Check to see if any of these are missing.
   */
   public static final String EXC_MISSING_EO_USAGE_ASSOC_INFO   = "26035";

   /**
   ** <b>JBO-26036: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to set up meta object subtitution
   ** that leads to recursion.  For example, suppose you set up substitution
   ** where C substitutes B, and B substitutes A, and A subsititutes C.
   ** This results in a recursive substitution and will cause this error.
   ** <p>
   ** <b>Action:</b> Review your meta object substitution and correct
   ** errors.
   */
   public static final String EXC_RECURSIVE_SUBSTITUTIONS       = "26036";
   
   /**
   ** <b>JBO-26037: RowCreateException</b>
   ** <p>
   ** <b>Cause:</b> While creating a new View row, the system found an
   ** entity object base with discriminator column attributes.  However, the discriminator
   ** column values coming from the View row does not match any of the
   ** entity objects (the entity for the entity object base or any of its extended entities).
   ** <p>
   ** <b>Action:</b> Make sure that the View row's discriminator column
   ** values match one and only one entity object.
   **
   */
   public static final String EXC_NO_EO_BASE_FOR_DISCR          = "26037";

   /**
   ** <b>JBO-26038: PersistenceException</b>
   ** <p>
   ** <b>Cause:</b> The view link definition is based on an entity association.
   ** One of its ends specifies the named entity definition, but the view
   ** definition for that view link end does not have an entity usage
   ** for that entity definition.
   ** <p>
   ** <b>Action:</b> Correct the error in the view link definition (XML file).
   ** In particular, check to see if the view link's source and destination 
   ** are not switched with those of the entity association.
   */
   public static final String EXC_VIEWLINK_NO_EO_DEF            = "26038";

   /**
   ** <b>JBO-26040:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_DML_BATCH_POST_ENTITY         = "26040";
   
   /**
   ** <b>JBO-26041: DMLException</b>
   ** <p>
   ** <b>Cause:</b> Some database error occurred while posting (writing) an entity to
   ** the database.  This error normally carries a detail exception from the database
   ** which will give further information about the database failure.
   ** <p>
   ** <b>Action:</b> Look at the details of the exception and address the database problem.
   **
   */
   public static final String EXC_DML_POST_ENTITY               = "26041";
   
   /**
   ** <b>JBO-26042: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A database failure occurred while trying to generate an object ID (OID) and
   ** object reference (REF).  When a new row is created on an entity which
   ** maps to an Oracle object table, an OID and REF for the
   ** new row are generated. This executes a SQL statement like
   ** <code>select a.oid, make_ref(&lt;table-name&gt;, a.oid) ...</code>
   ** Somehow, this statement is failing.
   ** <p>
   ** <b>Action:</b> Check the following:
   ** <ul>
   ** <li> Are you using the right version of Oracle database?
   ** <li> Is the table in question an object table?
   ** </ul>
   ** This error normally carries a detail exception from the database,
   ** which will give further information about the database failure.
   ** Take a look at the detail exception and address the database problem.
   **
   */
   public static final String EXC_DML_GENERATE_REF_AND_OID      = "26042";
   
   /**
   ** <b>JBO-26043: DMLException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to generate an object ID (OID) and/or a reference (REF) on a database
   ** system that does not support Oracle objects.
   ** <p>
   ** <b>Action:</b>
   ** Do not try to create OID or REF on a database system that does
   ** not support Oracle objects.
   */
   public static final String EXC_DML_REF_AND_OID_NOT_SUPPORTED = "26043";
   
   /**
   ** <b>JBO-26044: DMLException</b>
   ** <p>
   ** <b>Cause:</b> The application tried to get an estimated row count (<code>getEstimatedRowCount()</code>)
   ** on a row set.  While building the appropriate query statement, executing it,
   ** and retrieving the estimated count, an error occurred.
   ** This error is accompanied by the SQL statement that caused the error.
   ** Also, it normally carries a detail exception from database,
   ** which will give further information about the database failure.
   ** <p>
   ** <b>Action:</b> Take a look at the SQL statement and the detail exception and address
   ** the database problem.
   **
   */
   public static final String EXC_DML_GET_EST_ROW_COUNT         = "26044";
   
   /**
   ** <b>JBO-26045: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A database error occurred while trying to generate an object ID (OID) from
   ** the primary key.  This operation is valid only if the table
   ** in question is an object table and if the table specifies that
   ** the reference (REF) is PK based.
   ** <p>
   ** <b>Action:</b> Check the following:
   ** <ul>
   ** <li>Are you using the right version of Oracle database?
   ** <li>Is the table in question an object table?
   ** <li>Does this object table use a PK-based REF?
   ** </ul>
   ** This error normally carries a detail exception from database
   ** which will give further information about the database failure.
   ** Take a look at the detail exception and address the database problem.
   */
   public static final String EXC_DML_GENERATE_PK_BASED_REF     = "26045";
   
   /**
   ** <b>JBO-26046:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_DML_PK_BASED_REF_NOT_SUPPORTED = "26046";

   /**
   ** <b>JBO-26047: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b> An attempt was made to update a row in LOCK_OPTUPDATE
   ** mode and the change indicator attribute value is not present.
   ** <p>
   ** <b>Action:</b> Look at the attribute mapping of the View Object that
   ** read in this Entity row and make sure that the View Object includes
   ** the change indicator attribute.  The LOCK_OPTUPDATE mode requires
   ** the value to be present.
   */
   public static final String EXC_OPTUPDATE_ROW_MISSING_CHG_IND = "26047";
   
   /**
   ** <b>JBO-26048: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A constraint violation occured in the database while posting (writing) an entity to
   ** the database.  This error carries a detail exception from the database
   ** which will give further information about the database failure.
   ** <p>
   ** <b>Action:</b> Fix the cause for the constraint violation. 
   ** Look at the details of the exception and address the database problem.
   ** 
   **
   */
   public static final String EXC_DML_POST_ENTITY_CONSTRAINT_VIOLATION = "26048";
   
   /**
   ** <b>JBO-26000: JboException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to load metadata objects failed. It may have unexpected
   ** data or the XML data may be corrupt.
   ** <p>
   ** <b>Action:</b> Verify that the XML metadata for various components is valid.
   ** 
   */
   public static final String EXC_GENERIC_PERSISTENCE2          = "26049";

   /**
   ** <b>JBO-26060: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred while trying to register a JDBC driver.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   **
   */
   public static final String EXC_JDBC_REGISTER_DRIVER          = "26060";
   
   /**
   ** <b>JBO-26061: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred while trying to open a JDBC connection.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   */
   public static final String EXC_JDBC_OPEN_CONNECTION          = "26061";
   
   /**
   ** <b>JBO-26062: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred while trying to close a JDBC connection.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   **
   */
   public static final String EXC_JDBC_CLOSE_CONNECTION         = "26062";
   
   /**
   ** <b>JBO-26064: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred while trying to close a JDBC connection.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   ** 
   */
   public static final String EXC_JDBC_CLOSE_STATEMENT          = "26064";
   
   /**
   ** <b>JBO-26065: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred during the commit phase of this transaction.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   **
   */
   public static final String EXC_JDBC_COMMIT                   = "26065";

   
   /**
   ** <b>JBO-26066: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred during the rollback phase of this transaction.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException.
   */
   public static final String EXC_JDBC_ROLLBACK                 = "26066";
   

    /**
   ** <b>JBO-26067: JboException</b>
   ** <p>
   ** <b>Cause:</b> An exception occurred while adding a JDBC connection to a pool that was
   ** already full.
   ** <p>
   ** <b>Action:</b> Modify the class that is using the pool to check the pool size before
   ** adding a new connection to the pool.
   **
   */
   public static final String EXC_JDBC_POOL_SIZE_EXCEEDED       = "26067";

   /**
   ** <b>JBO-26068: JboException</b>
   ** <p>
   ** <b>Cause:</b> The user attempted to return a connection to a pool that was not
   ** responsible for managing that connection.
   ** <p>
   ** <b>Action:</b> Modify the class that is using the pool to ensure that the connection
   ** belongs to the pool before returning the connection to the pool.
   */
   public static final String EXC_INVALID_JDBC_POOL_CONNECTION  = "26068";

   /**
   ** <b>JBO-26069: JboException</b>
   ** <p>
   ** <b>Cause:</b> A client request was timed out while waiting for a connection
   ** to be returned to the pool.
   ** <p>
   ** <b>Action:</b> Increase the maximum pool size in order to accommodate 2x
   ** the maximum expected active request size.
   */
   public static final String EXC_CONNECTION_REQUEST_TIMED_OUT  = "26069";

  /**
   ** <b>JBO-26070: DMLException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred while setting up metadata JDBC statement.
   ** <p>
   ** <b>Action:</b> Fix the underlying SQLException. There might be a datatype mismatch
   ** between the attributes of the view object and columns in the SQL for it.
   ** 
   */
   public static final String EXC_JDBC_COLUMN_DEFN              = "26070";
   
   /**
   ** <b>JBO-26080: DMLException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred while executing the SQL to fetch data
   ** for an entity instance or lock it.
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException in the details of this exception.
   **
   */
   public static final String EXC_ENTITY_SELECT                 = "26080";
   
   /**
   ** <b>JBO-26081: SQLDatumException</b>
   ** <p>
   ** <b>Cause:</b> A SQLException occurred when converting data from JDBC to <code>oracle.jbo.domain.Struct</code>
   ** attributes.
   ** <p>
   ** <b>Action:</b> Fix the conversion errors as suggested in SQLException.
   **
   */
   public static final String EXC_JDBC_GET_SQL_DATUM            = "26081";
   
   /**
   ** <b>JBO-26082:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_JDBC_SET_SQL_DATUM            = "26082";

   
   /**
   ** <b>JBO-26100: AfterCommitException</b>
   ** <p>
   ** <b>Cause:</b> An exception occurred in the afterCommit notification phase of the transaction.
   ** <p>
   ** <b>Action:</b> Verify the exception in the details of this exception. Fix
   ** the failing <code>afterCommit()</code> overridden methods in the entities or
   ** transient TransactionListener objects registered with the
   ** transaction to listen into the commit/rollback cycle.
   ** 
   */
   public static final String EXC_AFTER_COMMIT                  = "26100";
   
   /**
   ** <b>JBO-26101: AfterPostException</b>
   ** <p>
   ** <b>Cause:</b> An exception occurred in the afterPost phase of the transaction.
   ** <p>
   ** <b>Action:</b> Verify the exception in the details of this exception. Fix
   ** the failing <code>afterPost()</code> overridden methods in the entities or
   ** transient TransactionPostListener objects registered with the
   ** transaction to listen into the post cycle.
   */
   public static final String EXC_AFTER_POST                    = "26101";
   
   /**
   ** <b>JBO-26102: AfterRollbackException</b>
   ** <p>
   ** <b>Cause:</b> An exception occurred in afterRollback notification phase of the transaction.
   ** <p>
   ** <b>Action:</b> Verify the exception in the details of this exception. Fix
   ** the failing <code>afterRollback()</code> overridden methods in the entities or
   ** transient TransactionListener objects registered with the
   ** transaction to listen into the commit/rollback cycle.
   **
   */
   public static final String EXC_AFTER_ROLLBACK                = "26102";

   
   /**
   ** <b>JBO-27001: ReadOnlyAttrException</b>
   ** <p>
   ** <b>Cause:</b> This association attribute is marked readonly.
   ** <p>
   ** <b>Action:</b> Cannot modify the value of the association attribute as it is marked readonly. 
   **
   */
   public static final String EXC_READONLY_ASSOC_ATTR           = "27001";
   
   /**
   ** <b>JBO-27002: AttrSetValException</b>
   ** <p>
   ** <b>Cause:</b> A custom validation rule failed to validate an attribute value.
   ** <p>
   ** <b>Action:</b> Fix the attribute value so that it passes the custom validation rule.
   */
   public static final String EXC_VAL_ENTITY_VALIDATE_FAILED    = "27002";
   
   /**
   ** <b>JBO-27003: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> Modified or new entities in this view object failed to validate.
   ** <p>
   ** <b>Action:</b> Fix the failing entity values and revalidate the view object.
   */
   public static final String EXC_VAL_VO_VALIDATE_FAILED        = "27003";
   
   /**
   ** <b>JBO-27004: ReadOnlyAttrException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to modify a read-only entity-attribute.
   ** <p>
   ** <b>Action:</b> Do not modify a readonly attribute value.
   **
   */
   public static final String EXC_VAL_ENTITY_ATTR_SET_FAILED    = "27004";
   
   /**
   ** <b>JBO-27005: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> Modified or new entities within this application module or nested
   ** application module failed to validate.
   ** <p>
   ** <b>Action:</b> Fix the failing entities and then re-validate this application module.
   **
   */
   public static final String EXC_VAL_APPMOD_VALIDATE_FAILED    = "27005";
   
   /**
   ** <b>JBO-27006: AttrValException</b>
   ** <p>
   ** <b>Cause:</b> An attribute cannot be found by the given name during validation.
   ** <p>
   ** <b>Action:</b> Entity metadata could be corrupt as there is an attribute which
   ** is to be validated but no definition could be found for that attribute
   ** in the metadata.
   **
   */
   public static final String EXC_VAL_ATTRIBUTE_NOT_FOUND       = "27006";
   
   /**
   ** <b>JBO-27007: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to validate a ViewRow failed.
   ** <p>
   ** <b>Action:</b> Fix the failing entities or attributes as found in the details
   ** of this exception.
   **
   */
   public static final String EXC_VAL_VR_VALIDATE_FAILED        = "27007";
   
   /**
   ** <b>JBO-27008: ReadOnlyAttrException</b> 
   ** <p>
   ** <b>Cause:</b> Attempting to modify a ViewRow attribute that is readonly
   ** <p>
   ** <b>Action:</b> Either change the Updateable flag for the View Attribute or
   ** do not attempt to update readonly attributes.
   ** 
   */
   public static final String EXC_VAL_VR_ATTR_SET_FAILED        = "27008";
   
   /**
   ** <b>JBO-27009: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> Attempting to validate entities and attributes failed during
   ** validation of buffered attributes in Deferred Validation mode.
   ** (Not available in 3.x)
   ** <p>
   ** <b>Action:</b> Fix the failure cases.
   **
   */
   public static final String EXC_VAL_VR_BATCH_ATTR_SET_FAILED  = "27009";
   
   /**
   ** <b>JBO-27010: ValidatonException</b>
   ** <p>
   ** <b>Cause:</b> For strings, the length of the string value provided for an attribute
   ** is more than the max-length this attribute expects. For Numeric values,
   ** the length of the value (in string form) is more than what the attribute
   ** expects.
   ** <p>
   ** <b>Action:</b> Fix the attribute value with respect to the precision and scale
   ** information for the failing attribute.
   **
   */
   public static final String EXC_VAL_PRECISION_VALIDATOR       = "27010";
   
   /**
   ** <b>JBO-27011: AttrSetValException</b>
   ** <p>
   ** <b>Cause:</b> A validation rule for an attribute failed either due to an unexpected
   ** exception in validating the attribute with that rule, or due to failure
   ** in evaluating the NOT operation on the rule.
   ** <p>
   ** <b>Action:</b> Fix the attribute value so that it validates against the failing rule.
   **
   */
   public static final String EXC_VAL_ATTR_SET_FAILED           = "27011";
   
   /**
   ** <b>JBO-27012: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> The custom method validator attached to an entity returned <code>false</code>, indicating
   ** a failure in the validation for that entity.
   ** <p>
   ** <b>Action:</b> Fix the cause for failure in the custom validation method for this attribute.
   **
   */
   public static final String EXC_VAL_METHOD_ON_ROW_FAILED      = "27012";
   
   /**
   ** <b>JBO-27013: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> The custom method validator attached to an attribute returned <code>false</code>
   ** indicating a failure in validation for that attribute in the custom method.
   ** <p>
   ** <b>Action:</b> Fix the cause for failure in the custom validator method for this attribute. 
   **
   */
   public static final String EXC_VAL_METHOD_ON_ATTR_SET_FAILED = "27013";
   
   /**
   ** <b>JBO-27014: AttrValException</b>
   ** <p>
   ** <b>Cause:</b> The attribute value cannot be null as it has been marked mandatory.
   ** <p>
   ** <b>Action:</b> Provide non-null values for mandatory attributes.
   **
   */
   public static final String EXC_VAL_ATTR_MANDATORY            = "27014";
   
   /**
   ** <b>JBO-27015: ValidationException</b>
   ** <p>
   ** <b>Cause:</b> In validating a master, some child entities were found that could not
   ** be validated. This occurs only in the case when there is a composition
   ** association between the master and detail entities.
   ** <p>
   ** <b>Action:</b> Fix the attribute values in the child entities so that they are
   ** valid when the child entities are validated by the master
   **
   */
   public static final String EXC_VAL_INVALID_CONTAINED_ENTITIES= "27015";
   
   /**
   ** <b>JBO-27016: InvalidAttrKindException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected attribute kind found in the definition for a view object.
   ** <p>
   ** <b>Action:</b> Fix the attribute kind information in the xml-metadata definition
   ** for attributes in this view object.
   **
   */
   public static final String EXC_INVALID_ATTRIBUTE_KIND        = "27016";
   
   /**
   ** <b>JBO-27017: KeyNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> While loading the metadata definition for this entity, there was
   ** no attribute marked as the primary key.
   ** <p>
   ** <b>Action:</b> Set at least one attribute as the primary key for this entity
   ** type, so that entities of this type can be uniquely identified.
   **
   */
   public static final String EXC_KEY_NOT_FOUND                 = "27017";
   
   /**
   ** <b>JBO-27018: AttrSetValException</b>
   ** <p>
   ** <b>Cause:</b> The type of attribute value provided as an argument to the <code>set()</code> method
   ** for this attribute is not an instance of the Java type that this
   ** attribute expects.
   ** <p>
   ** <b>Action:</b> Convert the argument to a proper Java type, such that it is an instance
   ** of the Java type that this attribute expects.
   **
   */
   public static final String EXC_VAL_ATTR_SET_TYPE_MISMATCH    = "27018";
   
   /**
   ** <b>JBO-27019: AttrGetValException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred in set<i>Attribute</i> method. Getter
   ** methods should throw a subclass of JboException so that custom
   ** exception messages are thrown/shown to the caller. This exception
   ** could also be thrown if the getter is not a public Java method.
   ** <p>
   ** <b>Action:</b> Do not throw any exception other than sub-classes of JboException 
   ** from any business logic code in the getter method for an attribute.
   ** Also verify that the getter method is a public Java method.
   ** 
   */
   public static final String EXC_VAL_ATTR_RESOLVEGET_FAILED    = "27019";
   
   /**
   ** <b>JBO-27020:</b> AttrSetValException
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred in set<i>Attribute</i> method. Setter
   ** methods should throw a subclass of JboException so that custom
   ** exception messages are thrown/shown to the caller. This exception
   ** could also be thrown if the setter is not a public Java method.
   ** <p>
   ** <b>Action:</b> Do not throw any exception other than sub-classes of JboException 
   ** from any business logic code in the setter method for an attribute.
   ** Also verify that the setter method is a public Java method.
   **
   */
   public static final String EXC_VAL_ATTR_RESOLVESET_FAILED    = "27020";
   
   
   /**
   ** <b>JBO-27021: AttributeLoadException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during fetching values from a 
   ** JDBC result set into an attribute for a row object. There could
   ** be conversion errors between the return type from JDBC for the
   ** attribute and its Java type.
   ** <p>
   ** <b>Action:</b> Verify that the JDBC-SQL type and Java type for the attribute are
   ** compatible. Fix any conversion errors or domain exceptions that
   ** are in the details of this exception.
   ** 
   */
   public static final String EXC_ATTR_LOAD_DATUM_EXCEPTION     = "27021";
   
   /**
   ** <b>JBO-27022: AttributeLoadException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during fetching values from a 
   ** JDBC result set into an attribute for a row object. There could
   ** be conversion errors between the return type from JDBC for the
   ** attribute and its Java type.
   ** <p>
   ** <b>Action:</b> Verify that the JDBC-SQL type and Java type for the attribute are
   ** compatible. Fix any conversion errors or domain exceptions that
   ** are in the details of this exception.
   ** 
   */
   public static final String EXC_ATTR_LOAD_EXCEPTION           = "27022";

   
   /**
   ** <b>JBO-27023: DeferredTxnValidationException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during validating
   ** changes in a transaction.
   ** <p>
   ** <b>Action:</b> Verify the details for DeferredRowValidationException
   ** and fix those errors.
   ** 
   */
   public static final String EXC_DEF_TXN_VAL_EXCEPTION           = "27023";

   
   /**
   ** <b>JBO-27024: DeferredRowValidationException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during validating
   ** a row.
   ** <p>
   ** <b>Action:</b> Verify the details for DeferredRowValidationException
   ** and fix those errors at the row level. The details can also contain
   ** DeferredAttrValidationExceptions which needs to be fixed as well.
   ** 
   */
   public static final String EXC_DEF_ROW_VAL_EXCEPTION           = "27024";
   
   
   /**
   ** <b>JBO-27025: DeferredAttrValidationException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during validating
   ** an attribute of a row.
   ** <p>
   ** <b>Action:</b> Verify the details for JboExceptions and 
   ** fix those errors at the row level. 
   ** 
   */
   public static final String EXC_DEF_ATTR_VAL_EXCEPTION           = "27025";

   
   /**
   ** <b>JBO-27026: AttrSetValException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during 
   ** a setter method for an attribute. This exception should
   ** not be seen outside of the framework.
   ** <p>
   ** <b>Action:</b> Verify the details for JboExceptions and 
   ** fix those errors 
   ** 
   */
   public static final String EXC_SET_ATTR_VAL_EXCEPTION           = "27026";

   /**
   ** <b>JBO-27027: DeferredAttrValidationException</b>
   ** <p>
   ** <b>Cause:</b> An unexpected exception occurred during validating
   ** attributes of a row for mandatory fields.
   ** <p>
   ** <b>Action:</b> Verify the details for JboExceptions and 
   ** fix those attributes with null values.
   ** 
   */
   public static final String EXC_DEF_MANDATORY_ATTR_EXCEPTION     = "27027";

   /**
   ** <b>JBO-27008: ReadOnlyAttrException</b> 
   ** <p>
   ** <b>Cause:</b> Attempting to set value of a variable that is not updateable.
   ** <p>
   ** <b>Action:</b> Either change the updateable flag of the variable or
   ** do not attempt to set the value of a non-updateable variable.
   */
   public static final String EXC_VAL_VAR_NOT_UPDATEABLE        = "27028";

   /**
   ** <b>JBO-27101: DeadEntityAccessException</b>
   ** <p>
   ** <b>Cause:</b> Trying to refer to an invalid/obsolete entity. This could occur
   ** if some business logic has held on to an entity reference which
   ** was removed and the transaction has been posted or committed.
   ** It could also occur if a reference entity has been removed 
   ** from the cache and any ViewRow is attempting to access it.
   ** <p>
   ** <b>Action:</b> Use <code>findByPrimaryKey</code> to find a valid entity of the desired key
   ** instead of holding on to a reference to an entity instance.
   ** 
   */
   public static final String EXC_DEAD_ENTITY_ACCESS            = "27101";
   
   /**
   ** <b>JBO-27102: DeadViewRowAccessException</b>
   ** <p>
   ** <b>Cause:</b> Trying to access a ViewRow which is part of an obsolete/invalid collection.
   ** This could happen if a reference to the ViewRow is held by some business logic
   ** while the containing view object was removed.
   ** <p>
   ** <b>Action:</b> Find the referenced ViewRow either by re-querying or using findByKey methods to 
   ** get a valid reference to the ViewRow.
   ** 
   */
   public static final String EXC_DEAD_VIEW_ROW_ACCESS          = "27102";

   /**
   ** <b>JBO-27120: SQLStmtException </b>
   ** <p>
   ** <b>Cause:</b> Failed to execute a query. This could occur when trying to 
   ** execute a query for a SQLValue domain class or a Sequence domain.
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException thrown by JDBC found in the
   ** details of this exception.
   **
   */
   public static final String EXC_SQL_EXECUTE_QUERY             = "27120";
   
   /**
   ** <b>JBO-27121: SQLStmtException</b>
   ** <p>
   ** <b>Cause:</b> Failed to execute a SQL statement.
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException thrown by JDBC found in the
   ** details of this exception.
   */
   public static final String EXC_SQL_EXECUTE_COMMAND           = "27121";
   
   /**
   ** <b>JBO-27122: SQLStmtException</b>
   ** <p>
   ** <b>Cause:</b> Failed to prepare a JDBC PreparedStatement. 
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException thrown by JDBC found in the
   ** details of this exception.
   **
   */
   public static final String EXC_SQL_PREPARE_STATEMENT         = "27122";
   
   /**
   ** <b>JBO-27123: SQLStmtException </b>
   ** <p>
   ** <b>Cause:</b> Failed to prepare a JDBC CallableStatement. 
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException thrown by JDBC found in the
   ** details of this exception.
   */
   public static final String EXC_SQL_PREPARE_CALL              = "27123";
   
   /**
   ** <b>JBO-27124: SQLStmtException</b>
   ** <p>
   ** <b>Cause:</b> Failed to create a JDBC Statement object with the given set of 
   ** parameters.
   ** <p>
   ** <b>Action:</b> Fix the cause for the SQLException thrown by JDBC found in the
   ** details of this exception.
   ** 
   */
   public static final String EXC_SQL_CREATE_STATEMENT          = "27124";

   
   /**
   ** <b>JBO-27125: JboException</b>
   ** <p>
   ** <b>Cause:</b> Failed to find a java type for a column-type in the given
   ** dynamic ViewObject query.
   ** <p>
   ** <b>Action:</b> Either provide a typemap that maps the selected columns
   ** in the query or leave out the erring column-type from the query.
   ** 
   */
   public static final String EXC_MISSING_TYPEMAP_ENTRY         = "27125";

   /**
   ** <b>JBO-27126: SQLStmtException</b>
   ** <p>
   ** <b>Cause:</b> Long running query is cancelled.
   ** <p>
   ** <b>Action:</b> The view object's query time-out has been reached
   ** or the user requested cancellation of a long query.
   **
   */
   public static final String EXC_EXECUTE_QUERY_CANCELLED       = "27126";


   public static final String EXC_SQL_JNDI_LOOKUP               = "27200";
   public static final String EXC_SQL_SUSPENDING_TXN            = "27201";
   public static final String EXC_SQL_RESUMING_TXN              = "27202";

  /**
   ** <b>JBO-27203: JboException</b> 
   ** <p>
   ** <b>Cause:</b> When using global transactions you cannot use the 
   **  transactional datasoource for acquiring the internal connection.
   ** <b>Action:</b> Explicitly specify the jdbc url that should be used for creating 
   ** the internal connection by setting the 
   ** <code>oracle.jbo.common.PropertyConstants.INTERNAL_CONNECTION_PARAMS</code> property
   ** 
   */

   public static final String EXC_SQL_NOCONNSTR_FOR_JTA      = "27203";


   // Temporary fix until the rts file generation issue is resolved.
   public static final String EXC_PCOLL_NOCONNSTR_FOR_JTA      = EXC_SQL_NOCONNSTR_FOR_JTA;


   
   /**
   ** <b>JBO-28000: PCollException</b>
   ** <p>
   ** <b>Cause:</b> The client specified a custom persistent collection
   ** through the <code>jbo.pcoll.mgr</code> property. However, the class
   ** specified could not be located or loaded.
   ** <p>
   ** <b>Action:</b> Make sure that the name specified for <code>jbo.pcoll.mgr</code>
   ** is for a valid class name. The class name should be fully qualified
   ** with the package name. A special keyword <code>None</code> represents
   ** no persistent collection manager, i.e., no spilling to disk will occur.
   **
   */
   public static final String EXC_PCOLL_NO_PERSIST_MGR_CLASS    = "28000";
   
   /**
   ** <b>JBO-28001: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to get a JDBC connection
   ** for persistent collection management.
   ** <p>
   ** <b>Action:</b> Make sure that the database connection URL is correct.
   ** The detail to this exception will give further information on the problem.
   **
   */
   public static final String EXC_PCOLL_CONNECT                 = "28001";
   
   /**
   ** <b>JBO-28002: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while creating "persistent collection
   ** control table."  Normally, the control table's name is PCOLL_CONTROL.
   ** <p>
   ** <b>Action:</b> Check to make sure that the connection has appropriate
   ** authority to create a table.  The detail to this exception will give
   ** further information on the problem.
   **
   */
   public static final String EXC_PCOLL_CREATE_CONTROL_TAB      = "28002";
   
   /**
   ** <b>JBO-28003: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while attempting to delete
   ** the persistent collection control row.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_DELETE_CONTROL_ROW      = "28003";
   
   /**
   ** <b>JBO-28004: PCollException</b>
   ** <p>
   ** <b>Cause:</b> An error occurred while trying to lock the persistent
   ** collection control row. This error is thrown in two situations:
   ** <ul>
   ** <li>An unexpected database error occurred while attempting to lock the
   ** row.
   ** <li>After the persistent collection
   ** manager committed changes to database, it tried to lock the control
   ** row. Between the time of commit and lock attempt, another user somehow
   ** managed to lock the row and not release it within a set time. In this
   ** case, the detail will be <code>null</code>.
   ** </ul>
   ** <p>
   ** <b>Action:</b> In the first case, see the details of this exception
   ** for further information on the database problem. In the second
   ** case, make sure that no other user locks the control rows outside the
   ** Business Components framework.
   **
   */
   public static final String EXC_PCOLL_LOCK_CONTROL_ROW        = "28004";
   
   /**
   ** <b>JBO-28005: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while attempting to update
   ** the persistent collection control row.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_UPDATE_CONTROL_ROW      = "28005";
   
   /**
   ** <b>JBO-28006: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to create a database
   ** table to store persistent collection material.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_CREATE_TAB              = "28006";
   
   /**
   ** <b>JBO-28007: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while attempting to commit
   ** persistent collection changes.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_COMMIT                  = "28007";
   
   /**
   ** <b>JBO-28008: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to create an index
   ** on a database table that stores persistent collection material.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_CREATE_INDEX            = "28008";
   
   /**
   ** <b>JBO-28009: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while attempting to get the
   ** system date from the database. For the Oracle persistent manager, the SQL
   ** statement used for this would be "select sysdate from dual".
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_GETCURTIME              = "28009";
   
   
   /**
   ** <b>JBO-28010: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to get the next value
   ** of a database sequence.
   ** <p>
   ** <b>Action:</b> Make sure that the sequence object exists in the database.
   ** Also look at the details of this exception for further
   ** information on the problem and how to address it.
   */
   public static final String EXC_PCOLL_SEQ_NEXTVAL             = "28010";
   
   
   /**
   ** <b>JBO-28011: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to query for the next id
   ** from a pers coll table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   */
   public static final String EXC_PCOLL_QUERY_NEXTID            = "28011";
   
   
   /**
   ** <b>JBO-28012: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to create add a
   ** key column on a database table that stores persistent collection material.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_ADD_KEY_COL             = "28012";
   
   
   /**
   ** <b>JBO-28013: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An error occurred while attempting to create a database
   ** table to store key info for persistent collection material.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   **
   */
   public static final String EXC_PCOLL_CREATE_KEYINFO_TAB      = "28013";
   
   
   /**
   ** <b>JBO-28020: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while passivating objects
   ** into the persistent store. An exception may have been thrown during
   ** serialization.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_PASSIVATE               = "28020";
   
   /**
   ** <b>JBO-28021: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while activating objects
   ** from the persistent store. An exception may have been thrown during
   ** deserialization.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_ACTIVATE                = "28021";
   
   
   /**
   ** <b>JBO-28030: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while inserting a
   ** passivation row into the persistent store table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_INSERT_ROW              = "28030";
   
   /**
   ** <b>JBO-28031: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while updating a
   ** passivation row in the persistent store table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_UPDATE_ROW              = "28031";
   
   /**
   ** <b>JBO-28032: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while deleting a
   ** passivation row from the persistent store table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_DELETE_ROW              = "28032";
   
   /**
   ** <b>JBO-28033: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while retrieving a
   ** passivation row from the persistent store table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_RETRIEVE_ROW            = "28033";
   
   /**
   ** <b>JBO-28034: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> The client attempted to retrieve a row in a persistent
   ** collection by an id, but the by-id access is not enabled on the persistent
   ** collection.
   ** <p>
   ** <b>Action:</b> Enable by-id access by calling
   ** <code>PCollection.enableIdAccess</code>.
   */
   public static final String EXC_PCOLL_RETRIEVE_BY_ID          = "28034";
   
   /**
   ** <b>JBO-28035: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> The client attempted to retrieve a row by an id, but
   ** the id value is invalid.  The id must be greater than 0.
   ** <p>
   ** <b>Action:</b> Give a valid id.
   */
   public static final String EXC_PCOLL_INVALID_ID              = "28035";
   
   /**
   ** <b>JBO-28036: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> While attempting to activate an object of a given id,
   ** an internal integrity problem was found. In particular, a node
   ** which was thought to be passivated was found to be active.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support with how you
   ** ran into the problem.
   */
   public static final String EXC_PCOLL_OBJ_ALREADY_ACTIVE      = "28036";
   
   /**
   ** <b>JBO-28037: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> While attempting to activate an object of a given id,
   ** an internal integrity problem was found. In particular, a child
   ** node/element expected to be found in a node is missing.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support with how you
   ** ran into the problem.
   */
   public static final String EXC_PCOLL_CHILD_ID_NOT_FOUND      = "28037";
   
   /**
   ** <b>JBO-28038: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while deleting all
   ** passivation rows from the persistent store table.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   ** 
   */
   public static final String EXC_PCOLL_DELETE_ALL              = "28038";
   
   /**
   ** <b>JBO-28039: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> While attempting to activate an object of a given id,
   ** an internal integrity problem was found. In particular, the root
   ** node of the persistent collection is no good. It is either (1) <code>null</code>,
   ** (2) has younger or older sibling, or (3) has a parent node.
   ** None of these should apply to the root node.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support with how you
   ** ran into the problem.
   ** 
   */
   public static final String EXC_PCOLL_INVALID_ROOT_NODE       = "28039";


   /**
   ** <b>JBO-28040: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> An unexpected error occurred while retrieving an
   ** array of persistent ids of rows from the persistent store table
   ** of given key hash code at the given key index.
   ** <p>
   ** <b>Action:</b> Look at the details of this exception for further 
   ** information on the problem and how to address it.
   */
   public static final String EXC_PCOLL_RETRIEVE_IDS_WITH_KEY   = "28040";

   
   /**
   ** <b>JBO-28041: PCollException</b> 
   ** <p>
   ** <b>Cause:</b> The system tried to update a row in the persistence
   ** store table, but it found either no row or more than one matching
   ** row.
   ** <p>
   ** <b>Action:</b> Contact BC4J Technical Support with how you
   ** ran into the problem.
   */
   public static final String EXC_PCOLL_UPDATE_BAD_ROW_COUNT    = "28041";

   
   /**
   ** <b>JBO-28100: ResourcePoolException</b>
   ** <p>
   ** <b>Cause:</b> Either the JDBC connection pool or the application pool were
   ** unable to create a new pooled JDBC connection or application module.
   ** <p>
   ** <b>Action:</b> If the exception details indicate that an exception occurred
   **  while creating a JDBC connection then check the JDBC connection description
   **  to ensure that it references a valid, live database instance.
   **  <p>If the exception details indicate that an exception occurred while
   **  creating an application module then check the application module configuration
   **  to ensure that it references a valid, live application server and application
   **  application module class.
   **
   */
   public static final String EXC_POOL_INSTANTIATION_FAILED    = "28100";

   /**
   ** <b>JBO-28101: ResourcePoolException</b>
   ** <p>
   ** <b>Cause:</b> The application attempted to mark a pooled resource which
   ** has already been available in the resource pool as available.
   ** <p>
   ** <b>Action:</b> Remove the application logic that invokes
   ** {@link oracle.jbo.pool.ResourcePool#setAvailable(Object)}, or move
   ** the application logic such that it occurs only once before the resource
   ** is made available. 
   **
   */
   public static final String EXC_POOL_RESOURCE_ALREADY_INITIALIZED = "28101";

   /**
   ** <b>JBO-28102: ResourcePoolException</b>
   ** <p>
   ** <b>Cause:</b> A client request was timed out while waiting for a resource
   ** to be returned to the resource pool.
   ** <p>
   ** <b>Action:</b> Increase the maximum resource pool size in order to
   ** accommodate the maximum expected active request size.  If the exception
   ** details indicate that the exception was thrown while waiting for an
   ** application module in the application pool then the maximum pool size
   ** may be increased with the BC4J property, jbo.ampool.maxpoolsize.  If the
   ** exception details indicate that the exception was thrown while waiting for
   ** a JDBC connection in the BC4J JDBC connection pool then the maximum pool size
   ** may be increased with the BC4J property, jbo.maxpoolsize.
   */ 
   public static final String EXC_POOL_WAIT_TIME_EXCEEDED           = "28102";

   /**
   ** <b>JBO-28103: ResourcePoolException</b>
   ** <p>
   ** <b>Cause:</b> A pool request was made for a resource that does not belong
   ** to the pool.
   ** <p>
   ** <b>Action:</b> Ensure that the pool request is accessing the same pool instance
   ** that was used to acquire the resource instance.
   */ 
   public static final String EXC_POOL_INVALID_RESOURCE             = "28103";



   /**
   ** <b>JBO-28200: JboException</b>
   ** <p>
   ** <b>Cause:</b> Invalid entities still found in the validation list of the transaction
   ** after attempting to validate all invalid entities for the VALIDATION_THRESHOLD
   ** 10 times (by default).
   ** <p>
   ** <b>Action:</b> Fix any logic that invalidates entity instances in the validation
   ** cycle (perhaps in overridden validateEntity() methods) such that
   ** all entities are valid before the VALIDATION_THRESHOLD limit is
   ** reached.
   ** 
   */
   public static final String EXC_VALIDATION_THRESHOLD_REACHED  = "28200";
   
   /**
   ** <b>JBO-28201: JboException</b>
   ** <p>
   ** <b>Cause:</b> There are invalid entities or entities in the post list of the
   ** transaction after trying to post all changes for the POST_THRESHOLD
   ** 10 times (by default).
   ** <p>
   ** <b>Action:</b> Fix any logic that places entities in the transaction's list of
   ** entities to be validated or posted in the post cycle, such that
   ** all entities get posted before the POST_THRESHOLD is reached.
   **
   */
   public static final String EXC_POST_THRESHOLD_REACHED        = "28201";
   
   /**
   ** <b>JBO-28202: JboException</b>
   ** <p>
   ** <b>Cause:</b> Invalid entity instances found in the transaction in the beforeCommit
   ** phase. 
   ** <p>
   ** <b>Action:</b> Fix any business logic that invalidates entity instances in postChanges()
   ** such that there are no more invalid entities after all changes are posted
   ** during the commit cycle.
   ** 
   */
   public static final String EXC_ENTITIES_INV_IN_B4_COMMIT     = "28202";

   /**
   ** <b>JBO-28203: RowNotFoundException</b>
   ** <p>
   ** <b>Cause:</b> Could not refresh the row because, value of Primary/Unique key is
   ** not set or are unknown.
   ** <p>
   ** <b>Action:</b> Set the values for any of primary/unique key that can fetch the
   ** row that is being updated. If that is not possible consider using a custom SQLBuilder,
   ** with doRefreshSQL(), defined to refresh the Row.
   **
   */
   public static final String EXC_ROW_NOT_FOUND_MISSING_KEY_VALUES     = "28203";

   // sbi:  These error codes are not actually used, but are listed here
   //       as comments to reserve error code numbers.
   // public static final String EXC_PIGGYBACK_READ_ERROR          = "28300";
   // public static final String EXC_PIGGYBACK_CREATE_STREAM_ERROR = "28301";
   // public static final String EXC_PIGGYBACK_WRITE_ERROR         = "28302";
   // public static final String EXC_DESERIALIZING_DETAIL_EXC      = "28303";
   
   /**
   ** <b>JBO-29000: JboException</b>
   ** <p>
   ** <b>Cause:</b> If an unexpected exception occurs during a framework operation, this 
   ** exception is thrown, with the unexpected exception included in the
   ** details of this exception.
   ** <p>
   ** <b>Action:</b> Fix the cause for the exception in the details for this JboException.
   **
   */
   public static final String EXC_UNEXPECTED_EXCEPTION          = "29000";

   public static final String EXC_TYPE_MISMATCH                 = "29001";

   public static final String EXC_OPER_NOT_SUPPORTED            = "29002";

   public static final String EXC_MARSHALLING_NO_SUCH_OBJECT         = "29003";

   public static final String EXC_NULL_SERVER_POOL_CONFIGURATION    = "29004";

   //from util message bundle
   
   /**
   ** <b>JBO-50001:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_STRING_MISMATCH               = "50001";
   
   /**
   ** <b>JBO-50002:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_IDENT_MISMATCH                = "50002";
   
   /**
   ** <b>JBO-50003:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_TOO_MANY_RIGHT_PARENS         = "50003";
   
   /**
   ** <b>JBO-50004:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   public static final String EXC_TOO_MANY_LEFT_PARENS          = "50004";

   
   /**
   ** <b>JBO-50100:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_VAL_GENERIC                   = "50100";
   
   /**
   ** <b>JBO-53103:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_VAL_BO_METHOD_VALIDATION      = "53103";
   
   /**
   ** <b>JBO-53104:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_VAL_ATTR_METHOD_VALIDATION    = "53104";
   
   /**
   ** <b>JBO-53107:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_VAL_QUERY_SAVE_ROW_FAILED     = "53107";
   
   /**
   ** <b>JBO-53108:</b> 
   ** <p>
   ** <b>Cause:</b>
   ** <p>
   ** <b>Action:</b>
   ** 
   */
   //public static final String EXC_VAL_VALIDATION_WITH_ERROR     = "53108";

   
   /**
   ** <b>JBO-55001: VariantException</b>
   ** <p>
   ** <b>Cause:</b> Unexpected type was provided to Variant utility.
   ** <p>
   ** <b>Action:</b> Provide an expected type as reported in the exception.
   **
   */
   public static final String EXC_VAR_UNEXPECTED_TYPE           = "55001";
   
   /**
   ** <b>JBO-55002: VariantException</b>
   ** <p>
   ** <b>Cause:</b> The data-type passed to the Variant utility from a Validation rule
   ** is invalid. This could be due to a corrupt XML-metadata definition
   ** in the component's XML file.
   ** <p>
   ** <b>Action:</b> Fix the component XML for the offending validation rule.
   ** 
   */
   public static final String EXC_VAR_INVALID_VARIANT_TYPE      = "55002";
   
   /**
   ** <b>JBO-55003: VariantException</b>
   ** <p>
   ** <b>Cause:</b> The name of the variant type passed to the Variant utility from a 
   ** Validation rule is invalid. This could be due to a corrupt XML meta
   ** data definition in the component's XML file.
   ** <p>
   ** <b>Action:</b> Fix the component XML for the offending validation rule.
   ** 
   */
   public static final String EXC_VAR_INVALID_VARIANT_NAME      = "55003";

   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      // from general Bundle.java
      {STR_DEF_APP_MODULE, "ApplicationModule Definition"},
      {STR_DEF_VIEW_OBJECT, "View Definition"},
      {STR_DEF_VIEW_LINK, "View Link Definition"},
      {STR_DEF_ENTITY_OBJECT, "Entity Definition"},
      {STR_DEF_ENTITY_ASSOC, "Entity Association Definition"},
      {STR_DEF_ATTRIBUTE, "Attribute Definition"},
      {STR_DEF_DOMAIN, "Domain Definition"},
      {STR_DEF_PACKAGE, "Package Definition"},

      {STR_APP_MODULE, "ApplicationModule"},
      {STR_VIEW_OBJECT, "View Object"},
      {STR_VIEW_ROW_SET, "View Row Set"},
      {STR_VIEW_ROW_SET_ITERATOR, "View Row Set Iterator"},
      {STR_VIEW_ROW, "View Row"},
      {STR_VIEW_LINK, "View Link"},
      {STR_ENTITY_OBJECT, "Entity Object"},
      {STR_ENTITY_ROW_SET, "Entity Row Set"},
      {STR_ENTITY_ROW_SET_ITERATOR, "Entity Row Set Iterator"},
      {STR_ENTITY_ROW, "Entity Row"},
      {STR_ENTITY_ASSOC, "Entity Association"},
      {STR_ENTITY_USAGE, "Entity Usage"},
      {STR_ATTRIBUTE, "Attribute"},
      {STR_VARIABLE, "Variable"},
      {STR_VARIABLE_WHERE_CLAUSE, "Where-Clause Bind Variable"},
      {STR_DOMAIN, "Domain"},
      {STR_PACKAGE, "Package"},
      {STR_VALIDATOR_TYPE, "Validator Type"},
      {STR_TRANSACTION, "Transaction"},
      {STR_VIEW_CRITERIA, "View Criteria"},

      // DML operations
      {STR_DML_INSERT, "Insert"},
      {STR_DML_UPDATE, "Update"},
      {STR_DML_DELETE, "Delete"},

      {STR_DML_ROLLBACK, "Rollback"},
      {STR_DML_COMMIT, "Commit"},

      {STR_DML_SAVEPOINT, "Savepoint"},
      {STR_DML_ROLLBACK_TO_SAVEPOINT, "Rollback to Savepoint"},
      {STR_DML_RELEASE_SAVEPOINT, "Release Savepoint"},
      {STR_DML_BATCH_POST, "BatchMode Post"},

      // from general bundle
      {EXC_TYP_UNKNOWN_SQL_TYPE, "Unknown SQL type: {0}"},
      {EXC_NAME_CLASH, "Name {1} of object type {0} already exists"},
      {EXC_NO_DEFINITION, "Definition {1} of type {0} not found"},
      {EXC_NO_OBJECT, "Object {1} of type {0} not found"},
      {EXC_INVALID_DEFINITION_NAME, "Definition name {1} for type {0} is invalid"},
      {EXC_INVALID_OBJECT_NAME, "Object name {1} for type {0} is invalid"},
      {EXC_INVALID_PARAMETER, "Invalid parameter value {2} for {1} passed to method {0}.  Explanation: {3}"},
      {EXC_INVALID_OPER_SET_ROW_VALIDATION, "Cannot reset validation flag for a default Iterator."},
      {EXC_INVALID_OPER_DIRTY_PAGE, "Cannot navigate with unposted rows in a RangePaging RowSet."},
      {EXC_INVALID_STACK_SNAPSHOT_ID, "Cannot locate the specified stack snapshot id:  {0}"},
      {EXC_CANNOT_REMOVE_REFERENCED_SNAPSHOT, "Cannot remove the referenced snapshot:  {0}"},
      {EXC_ENTITY_ROW_REMOVE_FROM_COLL, "Cannot call removeFromCollection() or removeAndRetain() on an Entity row:  Entity name {0}"},
      {EXC_ENTITY_UPDATE_FOUND_NO_MATCH, "Entity row update operation did not find matching row:  Entity name {0}, key {1}"},
      {EXC_NO_DEFINITION_WITH_OWNER, "Definition {1} of type {0} not found in {2}"},
      {EXC_MANAGE_ROWS_BY_KEY_BUT_EMPTY_KEY_DEF, "View Object {0} has ManageRowsByKey turned on, but its key definition is empty"},
      {EXC_RETRIEVE_NEXT_FROM_RESULT_SET, "Unexpected error encountered while trying to retrieve the next row from JDBC ResultSet for collection {0}"},

      {EXC_CANNOT_REMOVE_REFERENCED_OBJ, "Object {0} is referenced by {1}. Cannot be removed"},

      {EXC_DATA_CREATION_FROM_VALUE, "Cannot create an object of type:{0} with value:{1}"},

      {EXC_VAL_DOMAIN_FAILED, "Validation failure in creating:{0}"},


      {EXC_INVALID_OPER_FORWARD_ROWSET, "RowSet {0} is forward only."},

      {EXC_EO_NOT_PRIMARY_BASE, "View object {0} does not have entity {1} as its primary base."},

      {EXC_ATTR_LOAD_EXCEPTION, "Failed to load value at index {0} with java object of type {1} due to {2}."},
      {EXC_DEF_TXN_VAL_EXCEPTION, "Failed to validate all rows in a transaction."},
      {EXC_DEF_ROW_VAL_EXCEPTION, "Failed to validate a row with key {1} of type {0}"},
      {EXC_DEF_ATTR_VAL_EXCEPTION, "Failed to validate attribute {2} with value {3}"},
      {EXC_DEF_MANDATORY_ATTR_EXCEPTION, "Missing mandatory attributes for a row with key {1} of type {0}"},
      {EXC_VAL_VAR_NOT_UPDATEABLE, "Variable {2} in manager {1} is not updateable"},

      {EXC_ATTR_LOAD_DATUM_EXCEPTION, "Failed to load CustomDatum value at index {0} with java object of type {1} due to {2}."},

      {EXC_TOO_MANY_OBJECTS, "Too many objects match the primary key {0}."},

      {EXC_ROW_INCONSISTENT, "Another user has changed the row with primary key {0}."},

      {EXC_QUERY_COLLECTION_CLOSED, "Attempt to execute query or access a row from a closed query collection {0}"},

      {EXC_VIEWOBJECT_READONLY, "View object {0} is read only."},

      {EXC_ENTITY_ROW_CREATE, "Error while creating a new entity row for {0}."},
      {EXC_VIEW_ROW_CREATE, "Error while creating a new view row for {0}."},

      {EXC_ENTITY_ROW_NOT_FOUND, "Entity row of key {1} not found in {0}."},
      {EXC_VIEW_ROW_NOT_FOUND, "View row of key {1} not found in {0}."},

      {EXC_DATA_CREATION, "Cannot create an object of type:{0}"},
      
      {EXC_DATA_CREATION_WITH_MSG, "{0} Creation Error :{1}"},
      {EXC_DATA_CREATION_CLASS_NOT_FOUND, "Data class (a domain?) {0} not found"},

      {EXC_VIEW_LINK_ALREADY_EXISTS, "A view link {0} already exists between source view object {1} and destination view object {2}"},
      {EXC_DOMAIN_OPERATION, "Error while performing operation:{0} on domain value:{1} of class:{2}."},
      {EXC_OBSOLETE_METHOD, "Obsolete method:{0} invoked"},
      
      {EXC_READ_ROWSET_XML,    "RowSet with XML tag:{0} failed."},
      {EXC_READ_ROW_XML,       "Row:{1} with XML tag:{0} failed."},
      {EXC_READ_ATTRIBUTE_XML, "Attribute:{1} at index:{2} with XML tag:{0} failed."},
      {EXC_MISSING_TYPEMAP_ENTRY, "Cannot find matching type-map entries for all columns in a dynamic ViewObject-query"},


      {EXC_NO_ENTITY_OWNER, "Failed to find or invalidate owning entity: detail entity {0}, row key {1}."},

      {EXC_ENTITY_ROW_MISSING, "View row for view object {0} is missing entity row for {1}."},

      {EXC_AM_PASSIVATE, "Passivation to {1} Failed."},
      {EXC_AM_ACTIVATE, "Activating state from {1} at id {0} failed."},
      {EXC_AM_ACTIVATE_DEF_CHANGED, "Activating state from a previous version of Application definition."},
      {EXC_NO_KEY_ATTR_VO_ACTIVATED, "ViewObject {0} with with no key-attributes cannot be activated!"},

      {EXC_INVALID_OPER_SYNCITERATOR, "Attempt to synchronize iterator implicitly detected from row set iterator {0}."},
      {EXC_ROW_NOT_AVAILABLE, "Requested row not available in row set iterator {0}."},
      {EXC_INVALID_SERVER_CALL_FOR_BATCH, "Attempt to make call to server detected for application module {0}."},
      {EXC_OPER_INVALID_FOR_WS_OBJ, "Operation {0} is invalid for a working set object."},

      {EXC_ROW_OF_HANDLE_NOT_FOUND, "Row of handle {1} is not found in RowSet {0}."},
      {EXC_ROW_OF_RANGE_INDEX_NOT_FOUND, "Row of range index {1} is not found in RowSetIterator {0}."},

      {EXC_INVALID_PASSIVATION_STORE, "An invalid application module passivation store was specified"},

      {EXC_INVALID_OBJECT_ACCESS, "An invalid object operation was invoked on type {0} with name {1}"},
      {EXC_NO_MASTER_ROW_SET_ITERATOR, "Detail row set {0} is missing a master row set iterator for view link {1}, master view object {2}"},
      {EXC_INVALID_PARAM_NO_EXPL_GIVEN, "Invalid parameter value {2} for {1} passed to method {0}"},
      {EXC_NO_CURRENT_ROW, "No current row in row set iterator {0}"},
      {EXC_LOCK_ROW_BEFORE_LOB_USE, "Row should be locked before getting an output stream from an attribute."},
      {EXC_TYPEMAP_CONVERION_ID_INVALID, "TypeMapEntries did not know how to convert data from {1} to {0}, opId {2}."},
      {EXC_ENTITY_NOT_FOUND_IN_TPL_LIST, "Row of trans post listener handle {0} not found in list."},
      {EXC_EXTRANEOUS_KEY, "Extraneous key {0} of index {1} (in key-value array) passed to findByKey for view object {2}."},
      //{EXC_TOO_MANY_ENTITY_OWNERS, "Entity with key {1} in {0} has more than one owning entity"},

      {EXC_INVALID_METHOD_CALL, "Method {0} not supported"},
      {EXC_OPER_BATCH_MODE, "Entity {0} cannot be set to batch mode as one key attribute is marked Refresh-On-Insert or Refresh-on-Update."},
      {EXC_DML_BATCH_MODE_POST, "Batch mode post operation failed. See Exception details for a list of failures."},

      // {EXC_CANNOT_REMOVE_TRANS_APPMOD, "Application module {0} provides transaction context, may not be removed"},

      {EXC_CHILD_AM_WITH_NO_PARENT, "Application module {0} is not a root app module but has no parent"},
      {EXC_COMP_OBJ_WITH_NO_PARENT, "Component object {0} has no parent"},
      {EXC_CANNOT_CLEAR_DIRTY_ECACHE, "Cannot clear entity cache {0} because it has modified rows"},

      //from Persistence bundle
      {EXC_GENERIC_PERSISTENCE, "A Generic exception occurred during loading Customizations."},
      {EXC_GENERIC_PERSISTENCE2, "An error occurred during loading definition {0}."},

      {EXC_LOCATING_XML_FILE, "XML File not found for the Container {0}"},

      {EXC_PARSING_XML_FILE, "Error Parsing the XML file \"{0}\"."},

      {EXC_ATTRIBUTE_INDEX_MISMATCH, "Mismatch in the attribute indices declared in java versus the indices in the definition for entity {0}."},

      {EXC_RECURSIVE_BASE_DEF, "Recursive base definition found while attempting to set {0}'s base def to {1}"},

      // {EXC_INSTANCE_CLASS, "Error Loading Instance Class."},

      {EXC_INVALID_FETCH_MODE, "FetchMode must be either FETCH_AS_NEEDED, FETCH_ALL or FETCH_DEFAULT."},

      {EXC_INVALID_FETCH_SIZE, "FetchSize must be a positive integer."},

      {EXC_INVALID_MAX_FETCH_SIZE, "MaxFetchSize should be MAX_FETCH_UNLIMITED, MAX_FETCH_DEFAULT or integer."},

      {EXC_UNRESOLVED_REFERENCE, "Could not resolve reference to \"{0}\". "},

      {EXC_INVALID_SER_FILE, "Invalid Serialized file \"{0}\".  The root object is not a JBO Object."},

      {EXC_INVALID_ENTITY_ATTR_NAME, "Invalid Entity Attribute Name \"{1}\" specified for the View Attribute \"{0}\""},

      {EXC_SQLTYPE_NOT_SPECIFIED, "SQLType not specified for the View Attribute \"{0}\""},

      {EXC_INVALID_VIEWLINK_DEFN, "Invalid View Link Definition \"{0}\". View Link must have two ViewLinkDefEnds."},

      {EXC_DISCR_COL_NOT_MAPPED, "View object {0} does not include a discriminator column {2} of entity base {1}."},

      {EXC_UNKNOWN_FILE_ENCODING, "Unknown file encoding {0}"},

      {EXC_CANNOT_PERSIST_DT_ATTR, "Design-time attribute {0} of type {1} could not be persisted"},

      {EXC_XML_FILE_NOT_OPEN, "XML file not open"},

      {EXC_FACADE_CANNOT_MODIFY_PK, "The primary key of an existing entity bean may not be modified for entity facade {0}."},
      
      {EXC_FACADE_PK_CANNOT_BE_NULL, "The primary key of an entity bean cannot be null for entity facade {0}."},

      {EXC_PK_ATTR_NOT_MAPPED, "View object {0} does not include a primary key attribute {2} of entity base {1}."},

      {EXC_ALREADY_LOCKED, "Failed to lock the record, another user holds the lock."},
      
      {EXC_INVALID_ASSOC_END_FOR_ENTBASE, "Assocation end {0} of assoc {1} invalid for entity base {2} in view object {3}."},
      {EXC_INVALID_OPER_VIEW_CRITERIA, "Operation {0} is invalid for a ViewCriteria or ViewCriteriaRow."},
      {EXC_NULL_APPDEF, "Cannot find Application Data Model with name :{0}" },
      {EXC_NULL_SESSDEF, "Cannot find Configuration with name :{0}" },
      {EXC_MISSING_EO_USAGE_ASSOC_INFO, "Secondary entity usage {0} is missing parts of association description."},
      {EXC_RECURSIVE_SUBSTITUTIONS, "Recursive substituion for {0}."},
      {EXC_NO_EO_BASE_FOR_DISCR, "Cannot find matching EO from discriminator columns for view object {0}, entity base {1}, discr value {2}."},
      {EXC_VIEWLINK_NO_EO_DEF, "Cannot find an entity usage for entity {1} in view link definition {0}, view link end {2}."},
      {EXC_DML_BATCH_POST_ENTITY, "Failed to post entity {1} to database during \"{0}\" : SQL Statement \"{2}\"."},
      {EXC_DML_POST_ENTITY, "Failed to post data to database during \"{0}\": SQL Statement \"{1}\"."},
      
      {EXC_DML_GENERATE_REF_AND_OID, "Failed to generate REF and OID on entity {0}."},
      {EXC_DML_REF_AND_OID_NOT_SUPPORTED, "REF and OID not supported by this SQLBuilder on entity {0}."},
      {EXC_DML_GET_EST_ROW_COUNT, "Error while getting estimated row count for view object {0}, statement {1}."},
      {EXC_DML_GENERATE_PK_BASED_REF, "Failed to generate PK-Based REF on entity {0}."},
      {EXC_DML_PK_BASED_REF_NOT_SUPPORTED, "PK-Based REF not supported by this SQLBuilder on entity {0}."},
      {EXC_OPTUPDATE_ROW_MISSING_CHG_IND, "LOCK_OPTUPDATE mode update operation missing change indicator value: Entity {0}, key {1}."},
      {EXC_DML_POST_ENTITY_CONSTRAINT_VIOLATION, "Constraint \"{2}\" violated during post operation:\"{0}\" using SQL Statement \"{1}\"."},

      {EXC_JDBC_REGISTER_DRIVER, "Error while registering JDBC driver."},
      {EXC_JDBC_OPEN_CONNECTION, "Error while opening JDBC connection."},
      {EXC_JDBC_CLOSE_CONNECTION, "Error while closing JDBC connection."},
      {EXC_JDBC_CLOSE_STATEMENT, "Error while closing JDBC statement."},
      {EXC_JDBC_COMMIT, "Error during commit."},
      {EXC_JDBC_ROLLBACK, "Error during rollback."},
      {EXC_JDBC_COLUMN_DEFN, "Column definition retrieval from JDBC failed on view object {0}."},
      {EXC_ENTITY_SELECT, "Error while selecting entity for {0}"},
      {EXC_JDBC_GET_SQL_DATUM, "Error while getting datum for attribute {1} in {0}"},
      {EXC_JDBC_POOL_SIZE_EXCEEDED, "Failed to add JDBC connection to the connection pool, connection pool is full."},
      {EXC_INVALID_JDBC_POOL_CONNECTION, "Failed to return JDBC connection to the connection pool, connection does not belong to the pool."},
      {EXC_CONNECTION_REQUEST_TIMED_OUT, "Client request was timed out while waiting for a connection to be returned to the connection pool."},

      //{EXC_JDBC_SET_SQL_DATUM, "Error while setting datum for attribute {1} in {0} with value {2}"},

      {EXC_AFTER_COMMIT, "An error occurred after commit was performed."},
      {EXC_AFTER_POST, "An error occurred after posting was performed."},
      {EXC_AFTER_ROLLBACK, "An error occurred after rollback was performed."},

      {EXC_NOT_CONNECTED, "Application module is not connected to a database"},
      {EXC_ALREADY_CONNECTED, "Already connected to a database."},

      // {EXC_INIT_REMOTE_HOME, "Could not initialize remote home."},
      {EXC_APPMODULE_CREATE, "Unable to create application module."},
      {EXC_ROOT_APPMOD_ALREADY_CREATED, "Cannot create multiple root application modules."},
      {EXC_DATABASE_STATE_EXISTS, "Could not disconnect and retain application module state because database state exists for current connection."},
      {EXC_RECURSIVE_AM_INCLUSION, "Application module definition {0} contains recursive AM reference."},
      {EXC_RECURSIVE_VIEW_LINKS, "Recursive view links found.  Master-detail chain: {0}."},

      {EXC_XML_CONTEXT_LOOKUP, "Naming Exception occurred while looking up the object \"{0}\". "},
      {EXC_XML_CONTEXT_BIND, "Naming Exception occurred while binding the object \"{0}\". "},

      // {EXC_CANNOT_ADD_VL_WITH_USER_QUERY, "Cannot add view link \"{0}\" to the view \"{1}\" with a user-defined query"},
      {EXC_CANNOT_SET_USER_QUERY_WITH_VL, "Cannot set user query to view \"{0}\" because it is a destination in a view link"},
      {EXC_INVALID_ENTITYASSOC_DEFN, "Invalid EntityAssociation Definition \"{0}\". EntityAssociation must have attribute."},
      {EXC_INSERT_WITH_NO_ATTR_SET, "Cannot insert a new row with no attribute set in entity {0}"},
      {EXC_INVALID_ENABLE_PASSIVATION, "Cannot enable passivation for internal ViewObjects and rowsets." },
      {EXC_NO_MATCHING_DETAIL_VIEWOBJECT, "Cannot find a matching detail ViewObject.  Link definition: {0}, master row set iterator {1}." },
      {EXC_OPER_WS_OBJ_NOT_BOUND, "Operation {0} cannot be performed because the working set object is not bound."},
      {EXC_INVALID_VAR_KIND_FOR_WHERE, "Variable {1} in RowSet {0} is not a where-clause parameter.  It is of kind {2}."},
      {EXC_NAMED_WHERE_PARAM_NOT_OWNED_BY_VO, "Named where-clause parameter {0} does not belong to ViewObject {1}.  It belongs to an object of type {2}."},
      {EXC_INVALID_QM_SCAN_DATABASE_TABLES, "View Object {0} is based on an Entity built from Row Set.  For such a View Object, cannot include QUERY_MODE_SCAN_DATABASE_TABLES in its query mode."},
      {EXC_NEW_EO_INST_WITH_NO_DISCR_SUBCLASS, "Entity {0} has a subclass EO {1} and no discriminator.  Therefore this base Entity cannot be used to create an Entity Row."},
      {EXC_NEW_EO_INST_WITH_NO_DISCR_BASE, "Entity {0} has a base EO {1} with no discriminator, but base EO has rows in its cache.  Cannot populate both caches."},
      {EXC_SIBLING_SUBCLASS_WITHOUT_DISCR, "Row definition {0} has two sibling subclasses defs, {1} and {2}, but no discriminator to distinguish them."},
      {EXC_INVALID_VAR_WHERE_MISSING_EXT_INT_ARR, "Where-clause param variable {0} needs ordinal index array."},

      {EXC_REMOVE_WITH_DETAILS, "Attempting to remove a parent entity without removing all children entities"},
      {EXC_NO_MATCHING_EO_BASE, "Attempting to insert row with no matching EO base"},

      {EXC_XML_MISSING_DTD, "NullPointerException while parsing XML file \"{0}\".  Perhaps missing DTD file?"},

      {EXC_CUSTOM_CLASS_NOT_FOUND, "Could not find and load the custom class {0}"},
      {EXC_CUSTOM_CLASS_NOT_ASSIGNABLE, "Custom class {0} is not assignable to {1}"},
      {EXC_TYPEMAP_CLASS_NOT_BE_LOADED, "Could not find and load the type map class {0}"},

      {EXC_XML_CREATE_INITIAL_CONTEXT, "An error occurred while creating InitialContext"},

      {EXC_SYSTEM_GET_PROPERTIES, "An error occurred while trying to get System properties"},
      {EXC_LOADING_PROPERTIES, "An error occurred while loading properties from a properties file {0}"},
      {EXC_RESOURCE_NOT_FOUND, "Unable to find resource. {0}"},

      {EXC_READONLY_ASSOC_ATTR, "Association attribute {2} included in {0} {1} is not updatable"},
      {EXC_VAL_ENTITY_VALIDATE_FAILED, "Entity validation with key {1} failed in entity object {0}"},
      {EXC_VAL_VO_VALIDATE_FAILED, "Validation of rows in view object {0} failed"},
      {EXC_VAL_ENTITY_ATTR_SET_FAILED, "Attribute set for {2} in entity {1} failed"},
      {EXC_VAL_APPMOD_VALIDATE_FAILED, "Validation of rows in application module {0} failed"},
      {EXC_VAL_ATTRIBUTE_NOT_FOUND, "Validation failed because attribute {2} is not found in {0} {1}"},
      {EXC_VAL_VR_VALIDATE_FAILED, "Validation of a view row in view object {0} failed"},
      {EXC_VAL_VR_ATTR_SET_FAILED, "Attribute set for {2} in view object {1} failed"},
      {EXC_VAL_VR_BATCH_ATTR_SET_FAILED, "Batch set of attributes in view object {1} failed"},
      {EXC_VAL_PRECISION_VALIDATOR, "Attribute set with value {3} for {2} in {1} has invalid precision/scale"},
      {EXC_VAL_ATTR_SET_FAILED, "Attribute set with value {3} for {2} in {1} failed"},
      {EXC_VAL_METHOD_ON_ROW_FAILED, "Row validation method {2} failed for row with key {1} in {0}"},
      {EXC_VAL_METHOD_ON_ATTR_SET_FAILED, "Attribute set validation method {4} failed for attribute {2} in {1}"},
      {EXC_VAL_ATTR_MANDATORY, "Attribute {2} in {1} is required"},
      {EXC_VAL_INVALID_CONTAINED_ENTITIES, "{0} contained entity/s still invalid"},

      {EXC_INVALID_ATTRIBUTE_KIND, "Invalid attribute kind for column {0}."},

      {EXC_KEY_NOT_FOUND, "The primary key for Entity {0} could not be determined."},
      {EXC_VAL_ATTR_SET_TYPE_MISMATCH, "Attribute set with value {3} for {2} in {1} failed because of type mismatch"},

      {EXC_VAL_ATTR_RESOLVEGET_FAILED, "Get method for attribute \"{2}\" in {1} could not be resolved."},
      {EXC_VAL_ATTR_RESOLVESET_FAILED, "Set method for attribute \"{2}\" in {1} could not be resolved."},
      {EXC_SET_ATTR_VAL_EXCEPTION, "Set method threw an exception found in the details of this exception."},

      {EXC_DEAD_ENTITY_ACCESS, "Attempt to access dead entity in {0}, key={1}"},
      {EXC_DEAD_VIEW_ROW_ACCESS, "Attempt to access dead view row of persistent id {0}"},

      {EXC_SQL_EXECUTE_QUERY, "SQL error during query execution.  Statement: {0}"},
      {EXC_SQL_EXECUTE_COMMAND, "SQL error during statement execution.  Statement: {0}"},
      {EXC_SQL_PREPARE_STATEMENT, "SQL error during statement preparation.  Statement: {0}"},
      {EXC_SQL_PREPARE_CALL, "SQL error during call statement preparation.  Statement: {0}"},
      {EXC_SQL_CREATE_STATEMENT, "SQL error during empty statement creation"},
      {EXC_EXECUTE_QUERY_CANCELLED, "Long running query has been cancelled.  Statement: {0}"},

      {EXC_SQL_JNDI_LOOKUP, "JNDI failure. Unable to lookup {0} at context {1}"},
      {EXC_SQL_SUSPENDING_TXN, "Error suspending current transaction"},
      {EXC_SQL_RESUMING_TXN, "Error resuming current transaction"},
      {EXC_SQL_NOCONNSTR_FOR_JTA, "Cannot use the default connection for persistence with  global transactions."},

      {EXC_PCOLL_NO_PERSIST_MGR_CLASS, "PersistManager class {0} not found"},
      {EXC_PCOLL_CONNECT, "Cannot connect to database"},
      {EXC_PCOLL_CREATE_CONTROL_TAB, "Could not create persistence control table {0}"},
      {EXC_PCOLL_DELETE_CONTROL_ROW, "Could not delete row in control table for table {0}"},
      {EXC_PCOLL_LOCK_CONTROL_ROW, "Could not lock row in control table for table {0}"},
      {EXC_PCOLL_UPDATE_CONTROL_ROW, "Could not update row in control table for table {0}"},
      {EXC_PCOLL_CREATE_TAB, "Could not create persistence table {0}"},
      {EXC_PCOLL_COMMIT, "Could not commit while working on persistence table {0}"},
      {EXC_PCOLL_CREATE_INDEX, "Could not create an index {0} on table {1} for persistent collection"},
      {EXC_PCOLL_GETCURTIME, "Error while getting current time from database"},
      {EXC_PCOLL_SEQ_NEXTVAL, "Error while getting next sequence value for {0} from database"},
      {EXC_PCOLL_QUERY_NEXTID, "Error while querying for the next id from column {1} of table {0}, collection id {2}"},
      {EXC_PCOLL_ADD_KEY_COL, "Could not add key column {0} to table {1}"},
      {EXC_PCOLL_CREATE_KEYINFO_TAB, "Could not create key info table {0}"},
      
      {EXC_PCOLL_PASSIVATE, "Passivation error on collection {0}, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_ACTIVATE, "Activation error on collection {0}, collection id {1}, persistent id {2}"},
      
      {EXC_PCOLL_INSERT_ROW, "Could not insert row into table {0}, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_UPDATE_ROW, "Could not update row into table {0}, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_DELETE_ROW, "Could not delete row from table {0}, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_RETRIEVE_ROW, "Could not retrieve row from table {0}, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_RETRIEVE_BY_ID, "Retrieval by id not supported for collection {0}, collection id {1}.  Call enableAccessById()"},
      {EXC_PCOLL_INVALID_ID, "Persistent id {1} is invalid for a collection {0}, collection id {1}.  It should be > 0"},
      {EXC_PCOLL_OBJ_ALREADY_ACTIVE, "Object of id {2} is already active in its parent {3} in a persistent collection {0}, collection id {1}"},
      {EXC_PCOLL_CHILD_ID_NOT_FOUND, "Object of id {2} not found in its parent {3} in a persistent collection {0}, collection id {1}"},
      {EXC_PCOLL_DELETE_ALL, "Could not delete all rows for collection of id {1} from table {0}"},
      {EXC_PCOLL_INVALID_ROOT_NODE, "Root node for collection {0} is invalid, collection id {1}, persistent id {2}"},
      {EXC_PCOLL_RETRIEVE_IDS_WITH_KEY, "Could not retrieve ids of rows whose key id is {1} and hash is {2} from table {0}"},
      {EXC_PCOLL_UPDATE_BAD_ROW_COUNT, "Update found multiple rows or no matching row.  Persistence table {0}, collection id {1}, persistent id {2}"},

      {EXC_POOL_INSTANTIATION_FAILED, "The resource pool, {0}, failed to create a pooled resource instance."},
      {EXC_POOL_RESOURCE_ALREADY_INITIALIZED, "An application attempted to set a pooled resource that may be in use as available."},
      {EXC_POOL_WAIT_TIME_EXCEEDED, "A request was timed out while waiting for a resource to be returned to the resource pool, {0}."},
      {EXC_POOL_INVALID_RESOURCE, "A pool operation was specified for a pooled resource that does not belong to the resource pool."},
      

      {EXC_VALIDATION_THRESHOLD_REACHED, "Validation threshold limit reached. Invalid Entities still in cache"},
      
      {EXC_POST_THRESHOLD_REACHED, "Post threshold limit reached. Some entities yet to be posted."},
      
      {EXC_ENTITIES_INV_IN_B4_COMMIT, "Entities invalidated in beforeCommit(). Need to re-validate and post."},

      {EXC_UNEXPECTED_EXCEPTION, "Unexpected exception caught: {0}, msg={1}"},
      {EXC_TYPE_MISMATCH, "Type mismatch. Expected {0}. Actual {0}" },
      {EXC_OPER_NOT_SUPPORTED, "Operation {0} not supported for {1} platform"},
      {EXC_MARSHALLING_NO_SUCH_OBJECT, "Marshalling error. Object {0} doesn't exist"},
      {EXC_NULL_SERVER_POOL_CONFIGURATION, "Server side configuration for creating the pool not specified."},

      {EXC_STRING_MISMATCH, "Improperly closed string at index {0}" },
      {EXC_IDENT_MISMATCH, "Improperly closed identifier at index {0}" },
      {EXC_TOO_MANY_RIGHT_PARENS, "Too many right parentheses" },
      {EXC_TOO_MANY_LEFT_PARENS, "Too many left parentheses" },
      //{EXC_VAL_GENERIC, "A Generic exception occurred during validation\n  Exception: {0}"},
      //{EXC_VAL_BO_METHOD_VALIDATION, "Business Object \"{0}\" validation method failed."},
      //{EXC_VAL_ATTR_METHOD_VALIDATION, "Attribute {0} validation method failed to set {1}."},
      //{EXC_VAL_QUERY_SAVE_ROW_FAILED, "Failures in saving row data"},
      //{EXC_VAL_VALIDATION_WITH_ERROR, "Validation failed with error {0}."},
      {EXC_VAR_UNEXPECTED_TYPE,     "Attempt to set a {1} value to a {0} value." },
      {EXC_VAR_INVALID_VARIANT_TYPE, "Invalid variant type: {0}" },
      {EXC_VAR_INVALID_VARIANT_NAME, "Invalid variant name: {0}" },


      {STR_VAL_SCALE_DECIMAL_CHAR, "."},
      {STR_VAL_DESC_REGEXP_VALIDATOR, "Validates that the attribute value matches the given regular expression"},      
      {STR_VAL_DESC_LENGTH_VALIDATOR, "Validates that the length of the attribute value matches the given length value"},
      {STR_VAL_DESC_RANGE_VALIDATOR, "Validates that an attribute value lies within the given min & max values"},
      {STR_VAL_DESC_COMPARE_VALIDATOR, "Validates that an attribute value compares with the given comparator"},
      {STR_VAL_DESC_LIST_VALIDATOR, "Validates that an attribute value is one of the values in a list"},
      {STR_VAL_DESC_METHOD_VALIDATOR, "Validates an attribute by invoking the given method from the containing entity"},
      {STR_VAL_DESC_GENERIC_VALIDATOR, "An Example validator provided with JBO."},
      {STR_VAL_DESC_PRECISION_VALIDATOR, "Validates that an attribute value abides by precision & scale properties."},
      {STR_VAL_DESC_MANDATORY_VALIDATOR, "Validates the mandatory attribute properties for all attributes on an Entity."},

      {STR_DATASOURCE, "Data Source"},
      {STR_TRANSACTION_MANAGER, "Transaction Manager"},

      {MSG_POOL_NUM_OF_INSTANCE_CREATIONS, "Number of pooled resource creations"},
      {MSG_POOL_NUM_OF_INSTANCE_REMOVALS, "Number of pooled resource removals"},
      {MSG_POOL_NUM_OF_CHECK_OUTS, "Number of resource pool check outs"},
      {MSG_POOL_NUM_OF_CHECK_INS, "Number of resource pool check ins"},
      {MSG_POOL_NUM_OF_INSTANCES, "Total number of resources in the pool"},
      {MSG_POOL_MAX_NUM_OF_INSTANCES, "Maximum number of resources in the pool"},
      {MSG_POOL_AVG_NUM_OF_INSTANCES, "Average number of resources in the pool"},
      {MSG_POOL_NUM_OF_AVAIL_INSTANCES, "Total number of available resources in the pool"},
      {MSG_POOL_AVG_NUM_OF_AVAIL_INSTANCES, "Average number of available resources in the pool"},
      {MSG_POOL_AVG_NUM_OF_UNAVAIL_INSTANCES, "Average number of unavailable resources in the pool"},
      {MSG_POOL_NUM_OF_UNUSED_INSTANCES, "Number of resource unused for >{0} min"},
      {MSG_POOL_NUM_OF_USED_INSTANCES, "Number of resources used during last {0} min"},
      {MSG_POOL_INSTANCE_LIFETIME_STATS, "Resource lifetime statistics"},
      {MSG_POOL_USE_STATS, "Resource pool use statistics"},
      {MSG_POOL_INSTANCE_STATS, "Resource statistics"},
      {MSG_POOL_INSTANCE_AGE_STATS, "Resource age statistics"},
      {MSG_POOL_NUM_OF_CHECK_OUT_FAILURES, "Number of resource check out failures"},
      {EXC_JAAS_NO_CONTEXT, "No JAAS Context.  Permission information not available."},
      {EXC_JAAS_NO_ROLE, "Role {0} not found."},
      {EXC_JAAS_NO_USER, "User {0} not found."},
      {EXC_JAAS_ENTITY_ATTR_SET_FAILED, "No attribute set permission for {2} in entity {1} failed"},
       {EXC_ROW_NOT_FOUND_MISSING_KEY_VALUES, "Failed to refresh the row being updated. Values not set for Primary/Unique key or these keys are modified by databse triggers"},

   }  ;

} // class CSMessageBundle
