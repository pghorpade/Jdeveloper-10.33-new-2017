package oracle.jbo.domain;

import java.io.Serializable;
import oracle.jbo.Transaction;
//import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.DebugDiagnostic;

/**
* This class provides a lightweight wrapper for <code>java.sql.Date</code>,
* the native Java type for date objects. This wrapper allows an instance
* of the <code>java.sql.Date</code> to be used as a domain object.
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <code>java.sql.Date</code> class such that it returns
* an instance of an <tt>oracle.jbo.domain.Date</tt> object.
* @since JDevloper 3.1
*/
public class Date implements DomainInterface, Serializable
{
   static
   {
      DebugDiagnostic.println("Date: using Vanilla domain implementation");
   }
  
   // TODO: consider implementing this as an extension of
   // java.sql.Timestamp, instead of aggregating

   // TODO: fix serialID
   // private static final long serialVersionUID = 5600076615126868258L;

   private java.sql.Timestamp m_data;

   /**
    * Creates a default <code>Date</code> Domain object, representing
    * the time now.
    *
    */
   public Date()
   {
      java.util.Date now = new java.util.Date();
      m_data = new java.sql.Timestamp(now.getTime());
   }


   /**
    * Creates a <code>Date</code> identical to an
    * existing <code>Date</code>.
    *
    * @param value a <code>Date</code> Domain object.
    */
   public Date(Date value)
   {
      this(value.getTime());
   }

   
   public Date(long millis)
   {
      m_data = new java.sql.Timestamp(millis);
   }

   /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Date</code>.
    *
    * @param value a <code>DATE</code> SQL object.
    */
   public Date(java.sql.Date value)
   {
      this(value.getTime());
   }

   /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Time</code> object.
    *
    * @param value a <code>Time</code> SQL object.
    */
   //public Date(Time value)
   //{
   //   super(value);
   //}

   /**
    * Creates a <code>Date</code> Domain object from a JDBC
    * <code>Timestamp</code> object.
    *
    * @param value a <code>Time</code> SQL object.
    */
   //public Date(Timestamp value)
   //{
   //   super(value);
   //}

   /**
    * Creates a <code>Date</code> Domain object from a
    * JDBC <code>Object</code>.
    *
    * @param 	value   an <code>Object</code> that is an instance of
    * <code>Date</code>,
    * <code>Time</code>, <code>Timestamp</code>, or
    * <code>String</code>.
    * @throws	SQLException if the object is not of one of the recognized classes.
    */
   //public Date(Object value) throws SQLException
   //{
   //   super(value);
   //}

   /**
    * Creates a <code>Date</code> Domain object from a
    * Java <code>String</code>.
    * <p>
    * Note that we accept either a date string: "YYYY-MM-DD"
    * or a timestamp sting: "YYYY-MM-DD HH:MI:SS.D"
    * @param 	value   a textual representation of a <code>Date</code>.
    */
   public Date(String value)
   {
      // m_data = java.sql.Timestamp.valueOf(value);
      m_data=null;
      try
      {
         m_data = new java.sql.Timestamp(java.sql.Date.valueOf(value).getTime());
      }
      catch (Throwable e)
      {
         m_data = java.sql.Timestamp.valueOf(value);
      }
   }

   
   public Date(Object value)
   {
      this(value.toString());
   }
   
   
   public long getTime()
   {
      return m_data.getTime();
   }

  /**
   * Return a java.util.Date object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
   */
  public java.util.Date getValue()
  {
     return (java.util.Date)getData();
  }
  /**
    * @value The JDBC representation of <code>this</code>,
    */
  public Object getData() {
    return m_data;
  }

  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }

  /**
    * Converts <code>this</code> to a textual representation.
    */
  public String toString() {
      //DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
      //String formattedDate = df.format(m_data);
      //DebugDiagnostic.println("Formatted date: '" + formattedDate.toUpperCase() + "'");
     //return formattedDate.toUpperCase();

     // Use the JDBC default format as the most canonical
     // This is YYYY-MM-DD
     java.sql.Date temp = new java.sql.Date(m_data.getTime());
     return temp.toString();
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * The argument is cast to a <code>Date</code> object, if possible.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other)
  {
     if (other == null) 
     {
        return false;
     }

     if (this == other)
     {
        return true;
     }

     if (!other.getClass().equals(getClass()))
     {
        try
        {
           other = new Date(other);
        }
        catch(Exception sqle)
        {
           return false;
        }
     }

     return m_data.equals(((Date) other).m_data);
  }

  /*
  public boolean equals( Object obj )
  {
     if( obj instanceof Date )
     {
        return (compareTo((DATE)obj) == 0);
     }
     return false;
  }
  */

  /**
   * Returns -1 if Date is less than , 0 if Date and dt are equal (==),
   * 1 if Date is greater than dt.
   * @param     dt   input Oracle Date
   * @return integer result of comparison
   */
  public int compareTo(Date dt)
  {
     return (m_data.compareTo(dt.m_data));
  }


  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      return getData().hashCode();
   }

  /* serialization methods
  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
     byte[] bytes = getBytes();
     out.writeInt(bytes.length);
     out.write(bytes);
  }

  private void readObject(java.io.ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
     int size = in.readInt();
     byte[] bytes = new byte[size];
     in.read(bytes);
     setBytes(bytes);
  }
  */

  public java.sql.Date dateValue()
  {
     if (m_data != null) 
     {
        return new java.sql.Date(getTime());
     }
     else
     {
        return null;
     }
  }
}
