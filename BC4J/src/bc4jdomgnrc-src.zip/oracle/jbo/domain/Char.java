package oracle.jbo.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import oracle.jbo.Transaction;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.domain.KeyAttributeInterface;


/**
*
* This class provides a lightweight wrapper for <code>java.lang.Sting</code>,
* the native Java type for Char objects. This wrapper allows an instance
* of the <code>java.lang.String</code> to be used as a domain object.
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <code>java.lang.String</code> class such that it returns
* an instance of an <tt>oracle.jbo.domain.Char</tt> object.
* @since JDevloper 5.0
*/
public class Char implements DomainInterface, Serializable, KeyAttributeInterface
{

  static 
  {
     DebugDiagnostic.println("Char: using Vanilla domain implementation");
  }
   private String m_data;

  /**
    * Creates a default <code>Char</code> Domain object, representing
    * the time now.
    *
    */
  public Char() 
  {
  }


  /**
    * Creates a <code>Char</code> identical to an
    * existing <code>Char</code>.
    *
    * @param value a <code>Char</code> Domain object.
    */
  public Char(Char value) 
  {
     this(value.m_data);
  }

  /**
    * Creates a <code>Char</code> Domain object from a java
    * <code>String</code>.
    *
    * @param value a <code>String</code> object.
     */
  public Char(String value) 
  {
     m_data = value;
  }

  /**
    * Creates a <code>Char</code> Domain object from a
    * java <code>Object</code>.
    *
    * @param 	value   an <code>Object</code> that is convertible to String using toString()
    */
  public Char(Object value) 
  {
     m_data = ((value != null) ? value.toString() : null);
  }

  /**
    * @value The JDBC representation of <code>this</code>,
    */
  public Object getData() 
  {
    return m_data;
  }

  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) 
  {
  }

  /**
   * Return a java.lang.String object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
   */
  public String getValue()
  {
     return (String)getData();
  }

  /**
    * Converts <code>this</code> to a textual representation.
    */
  public String toString() 
  {
     return m_data;
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * The argument is cast to a <code>Char</code> object, if possible.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     // this is safe if other is null
     if (other instanceof Char)
     {
        Char oChar = (Char)other;
        if (m_data == null) 
        {
           return (m_data == oChar.m_data);
        }
        else
        {
           return m_data.equals(oChar.m_data);
        }
     }
     else if (other != null && other.toString().equals(m_data)) 
     {
        return true;
     }
     return false;
  }

  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      return (m_data != null) ? m_data.hashCode() : super.hashCode();
   }

 
   /**
    * Convert this data object into a int.
    *
    * @return        the data value in int representation.
    */
   public int intValue()
   {
      return Integer.getInteger(m_data).intValue();
   }

   /**
    * Converts this data object into a <tt>long</tt>.
    *
    * @return        the data value in long representation.
    */
   public long longValue()
   {
      return Long.getLong(m_data).longValue();
   }
 
 
   /**
    * Converts this data object into a float.
    *
    * @return        the data value in float representation.
    */
   public float floatValue()
   {
      try
      {
         return Float.parseFloat(m_data);
      }
      catch (java.lang.NumberFormatException e)
      {
         throw new DataCreationException("Char", e);
      }
   }
 
   /**
    * Converts this data object into a double.
    *
    * @return        the data value in double representation.
    */
   public double doubleValue()
   {
      try
      {
         return Double.parseDouble(m_data);
      }
      catch (java.lang.NumberFormatException e)
      {
         throw new DataCreationException("Char", e);
      }
   }
 
   /**
    * Converts this data object into a BigInteger.
    *
    * @return        the data value in BigInteger representation.
    */
   public BigInteger bigIntegerValue()
   {
      return (m_data != null) ? new BigInteger(m_data) : null;
   }
   
   /**
    * Converts this data object into a boolean.
    *
    * @return        the data value in boolean representation.
    */
   public boolean booleanValue()
   {
      return Boolean.getBoolean(m_data);
   }
 
  /**
   * Calls <tt>CHAR.bigDecimalValue()</tt> to convert this object into a Java
   * <tt>BigDecimal</tt>.
   *
   * @return	a Java BigDecimal value
   */
  public BigDecimal bigDecimalValue()
  {
     return (m_data != null) ? new BigDecimal(m_data) : null;
  } // bigDecimalValue()

  public Object toJdbc()
  {
     return m_data;
  }


   public byte[] getBytes()
   {
      if (m_data == null)
      {
         return new byte[0];
      }
      else
      {
         return m_data.getBytes();
      }
   }


   public void setBytes(byte[] bArr)
   {
      if (bArr == null)
      {
         m_data = null;
      }
      else
      {
         m_data = new String(bArr);
      }
   }
}
