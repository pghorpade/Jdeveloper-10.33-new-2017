/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.jbo.uicli.binding.JUCtrlHierDef;
import oracle.jbo.uicli.binding.JUIteratorBinding;


/**
 * This definition class provides instances of FacesCtrlHierBinding
 * for tree bindings.
 */
public final class FacesCtrlHierDef extends JUCtrlHierDef
{
  public FacesCtrlHierDef()
  {
  }

  protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
  {
    return new FacesCtrlHierBinding(control, 
                                    (JUIteratorBinding)getIterBinding(formBnd), 
                                    getAttrNames(),
                                    getTypeBindings());
  }
}