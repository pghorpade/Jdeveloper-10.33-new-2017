/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

/**
 * This definition class provides instances of FacesCtrlListBinding
 * for selectOne bindings.
 */
package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUCtrlListDef;

public final class FacesCtrlListDef extends JUCtrlListDef 
{
  public FacesCtrlListDef()
  {
  }

   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    int listOperMode)
   {
     return new FacesCtrlListBinding(control, iterBinding, attrNames, listOperMode);
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    Object[] valueList)
   {
     return new FacesCtrlListBinding(control, iterBinding, attrNames, valueList);
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    DCIteratorBinding listIterBinding,
    String[] listAttrNames,
    String[] listDisplayAttrNames)
   {
     return new FacesCtrlListBinding(control, iterBinding, attrNames, 
       listIterBinding, listAttrNames, listDisplayAttrNames);
   }

}