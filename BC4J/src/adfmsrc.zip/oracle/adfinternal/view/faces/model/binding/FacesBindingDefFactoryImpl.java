/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCDefBase;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUBindingDefFactoryImpl;
import oracle.jbo.uicli.mom.JUTags;

/**
 * Implements a BindingFactory that provides Faces specific bindings.
 */
public final class FacesBindingDefFactoryImpl extends JUBindingDefFactoryImpl
{
   public DCDefBase createDefinition(DefElement element)
   {
     String sElement = element.getElementName();
     if(sElement.equals(JUTags.PNAME_table))
     {
       return new FacesCtrlRangeDef();
     }
     else if(sElement.equals(JUTags.PNAME_tree))
     {
       return new FacesCtrlHierDef();
     }
     else if(sElement.equals(JUTags.PNAME_listOfValues) ||
             sElement.equals(JUTags.PNAME_list))
     {
       FacesCtrlListDef def = new FacesCtrlListDef();
       def.setSubType(DCDefBase.PNAME_ListSingleSel);
       def.setControlBindingClassName(FacesCtrlListBinding.class.getName());
//       def.setStaticList(false);
       return def;
     }
     else if(sElement.equals(JUTags.PNAME_attributeValues))
     {
       return new FacesCtrlAttrsDef();
     }
     else if(sElement.equals(JUTags.PNAME_methodAction) ||
             sElement.equals(JUTags.PNAME_action))
     {
       return new FacesCtrlActionDef();
     }
     return super.createDefinition(element);
   }
}
