/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import java.util.AbstractList;
import java.util.List;
import java.util.Map;
import javax.faces.model.SelectItem;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adfinternal.view.faces.util.IntegerUtils;
import oracle.jbo.uicli.binding.JUCtrlListBinding;

/**
 * This class provides a Faces SelectItem accessor for
 * the displayData of a JUCtrlListBinding
 */
public final class FacesCtrlListBinding extends JUCtrlListBinding 
{
  /**
   * *** For internal framework use only ***
   */
  protected FacesCtrlListBinding()
  {
  }

  /**
   * Uses the given static list of value objects to display data in the control.
   */
  public FacesCtrlListBinding(Object control, DCIteratorBinding iterBinding, String[] attrNames,
                              Object[] valueList)
  {
    super(control, iterBinding, attrNames, valueList);
  }
  
  /**
  * **For Testing purposes only***
  * Uses the same Iterator Binding to update as well as display values.
  */
  public FacesCtrlListBinding(Object control, DCIteratorBinding iterBinding,
                             String[] attrNames, int listOperMode)
  {
    super(control, iterBinding, attrNames, listOperMode);
  }

  /**
  * Uses the listIterBinding object to get the iterator and attribute names from
  * listDisplayAttrNames to display attributes from the BC4J Rows in the iterator.
  * Also maps values from listAttrNames attributes to the set of attributes (attrNames)
  * in the current row of the target iterator referred by iterBinding object 
  */
  protected FacesCtrlListBinding(Object control, DCIteratorBinding iterBinding,
                                 String[] attrNames, DCIteratorBinding listIterBinding,
                                 String[] listAttrNames, String[] listDisplayAttrNames)
  {
    super(control, iterBinding, attrNames, listIterBinding, 
          listAttrNames, listDisplayAttrNames);
  }
  
  /**
   * Gets a list of all the legal values for this SelectOne
   * @return each element in this list is a {@link SelectItem}
   */
  public List getItems()
  {
    return _items;
  }

  public Object getInputValue()
  {
    Object value = super.getInputValue();
    // if no value is set then super class returns -1.
    // in that case we should return null here:
    if ((value != null) &&
        (value.getClass() == Integer.class) &&
        (((Integer) value).intValue() < 0))
    {
      return null; // bug 4902453
    }
    return value;
  }
  
  protected Object internalGet(String key)
  {
    if ("items".equals(key)) // bug 4588228
      return getItems();
    return super.internalGet(key);
  }
  
  private final List _items = new AbstractList()
  {
    public int size()
    {
      return getDisplayData().size();
    }
    
    public Object get(int index)
    {
      Map map = (Map) getDisplayData().get(index);
      // do not use the following: it returns a String. However,
      // getInputValue returns an Integer:
      //Object value = map.get(LISTITEM_Index);
      Object value = IntegerUtils.getInteger(index);
      String label = map.get(LISTITEM_Prompt).toString();
      SelectItem item = new SelectItem(value, label);
      return item;
    }
  };
}