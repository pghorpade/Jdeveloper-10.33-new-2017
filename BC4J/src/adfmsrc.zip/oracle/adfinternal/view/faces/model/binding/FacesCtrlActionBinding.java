/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;

import java.util.List;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.faces.event.ActionEvent;

import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.faces.util.MessageFactory;

import oracle.jbo.uicli.binding.JUCtrlActionBinding;

/**
 * This class extends a JUCtrlActionBinding to provides a faces action method.
 */
public final class FacesCtrlActionBinding extends JUCtrlActionBinding
{
   public FacesCtrlActionBinding(
    Object control,
    DCBindingContainer formBnd,
    DCInvokeMethodDef methodInfo)
   {
      super(control, formBnd, methodInfo);
   }
   
   public FacesCtrlActionBinding(
    Object control,
    DCDataControl dataControl,
    int action)
   {
      super(control, dataControl, action);
   }
   
   public FacesCtrlActionBinding(
    Object control,
    DCIteratorBinding iterBinding,
    int action)
   {
      super(control, iterBinding, action);
   }

  /**
   * Calls the underlying method and returns the 
   * {@link #toString()} of the
   * result as the outcome.
   * If an error is reported by the binding container, then null
   * is returned.
   */
  public String outcome()
  {
    try
    {
      // bug 4518775:
      Object result = execute();
      
      return _getOutcome(result);
    }
    catch (RuntimeException e)
    {
      _handleError(e, null);
    }
    // if there are errors, return null to prevent navigation:
    // bug 4143742:
    return null;
  }
  
  /**
   * Calls the underlying method
   */
  public void execute(ActionEvent event) 
  {
    try
    {
      _execute(event);
    }
    catch (RuntimeException e) // bug 4335314
    {
      FacesContext context = FacesContext.getCurrentInstance();
      String id = event.getComponent().getClientId(context);
      _handleError(e, id);
    }
  }

  /**
   * Delegates to the PageController for execution.
   * @return the result from the PageController.
   */
  public Object execute() 
  {
    return _execute(null);
  }
  
  /**
   * Delegates to the PageController for execution.
   * bug 4681281.
   * @return the result from the PageController.
   */
  private Object _execute(ActionEvent event) 
  {
    FacesContext fc = FacesContext.getCurrentInstance();
    try
    {
      if (_methods == null)
      {
        Application app = fc.getApplication();
        _methods = new Methods(app);
      }
      
      Methods m = _methods;
      m._actionEvent.setValue(fc, event); // bug 4713996
      Object pageLifecycleContext = m._lifecycleContext.getValue(fc);
      // bug 4871695:
      m._executeEvent.invoke(fc, 
                             new Object[] {pageLifecycleContext, getName(), this});

      // we used to clear the event after execution (see bug 4703245).
      // however, this is nolonger needed because we are calling the new
      // executeEvent api. (see bug 4871695).
      // however, we still need to clear the faces ActionEvent from the
      // lifecycle context:
      m._actionEvent.setValue(fc, null);


      // getResult() caches the previous result. so even if there was an
      // exception when executing the method, getResult may still return a
      // value (the old value). This is bad behaviour, so test for errors
      // and only return the result if there were no errors:
      if (!_hasErrors())
      {
        return getResult();
      }
      
      return null;
    }
    catch (ClassNotFoundException e)
    {
      // databinding cannot work if the controller classes are missing:
      _LOG.severe(e);
    }
    
    return super.execute();    
  }

  private boolean _hasErrors()
  {
    List errs = getBindingContainer().getExceptionsList();
    if ((errs == null) || (errs.isEmpty()))
    {
      return false;
    }
    return true;
  }

  private String _getOutcome(Object result)
  {
    if (result != null)
      return result.toString();

    if (_hasErrors())
      return null;

    // methods that return void must not be treated as if they return null, as
    // this causes faces navigation to fail even if there are no errors.
    //
    // it is not easy to detect whether a custom method returns void.
    // however, it is easy to detect that the method is a built-in method
    // (and all built-in methods return void), and this is the common case.
    // so return a non-null result for any built-in method:
    // bug 5086806:
    int actionType = getActionId();
    if (actionType != JUCtrlActionBinding.ACTION_INVOKE_METHOD)
    {
      // this method is not a custom method. Therefore, it must be a
      // built-in method that returns void.
      // so return a fake outcome:
      return "_adf_SUCCESS";
    }
    
    return null;
  }

  private void _handleError(RuntimeException e, String componentId)
  {
    _LOG.fine(e);
    FacesMessage message = MessageFactory.getMessage(e); 
    FacesContext context = FacesContext.getCurrentInstance();
    context.addMessage(componentId, message);
    context.renderResponse();
  }

  // this class is needed because we can't have a build dependency
  // on adf controller. If we could depend on adfc then this
  // class (and its indirect methods) can be removed.
  //
  // adfc builds after adf faces and has a dependency on adf faces.
  private static final class Methods // not serializable
  {
    public Methods(Application app) throws ClassNotFoundException
    {
      _lifecycleContext = app.createValueBinding("#{ADFLifecycleContext}");
      Class lifecycleClass = 
        Thread.currentThread().getContextClassLoader().loadClass(
          "oracle.adf.controller.v2.context.PageLifecycleContext");
      _executeEvent = app.createMethodBinding(
        "#{ADFLifecycleContext.pageController.executeEvent}",
        new Class[] {lifecycleClass, String.class, OperationBinding.class});
      
      _actionEvent = app.createValueBinding("#{ADFLifecycleContext.actionEvent}");
    }

    private final MethodBinding _executeEvent;
    private final ValueBinding _lifecycleContext;
    private final ValueBinding _actionEvent;
  }
  
  private transient Methods _methods = null;
  
  private static final ADFLogger _LOG = 
    ADFLogger.createADFLogger(FacesCtrlActionBinding.class);
}
