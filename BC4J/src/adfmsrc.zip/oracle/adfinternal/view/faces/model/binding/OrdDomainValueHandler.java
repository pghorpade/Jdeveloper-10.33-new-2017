/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;

import java.io.IOException;

import java.sql.SQLException;

import java.util.AbstractMap;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Set;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.faces.model.UploadedFile;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jbo.uicli.binding.JUCtrlValueHandler;

import oracle.ord.html.OrdURLBuilder;
import oracle.ord.im.OrdDomainIOInterface;
import oracle.ord.im.OrdImageDomain;


/**
 * A OrdDomainValueHandler class serves as the custom handler for
 * intermedia objects in BC4J/Faces usage scenario. For those attributes 
 * that can't directly get value from the associated ViewObject, this class
 * provides APIs to return value for each of them. These attributes includes:
 * <ul>
 * <li>"source"
 * <li>"innerHeight"
 * <li>"innerWidth"
 * <li>"shortDesc"
 * </ul>
 * <p>
 * 
 * MetaData example for displaying an intermedia object is:
 * <PRE>
 *   &lt;af:objectMedia 
 *     source="#{bindings.Image.source}"
 *     innerHeight="#{bindings.Image.innerHeight}"
 *     innerWidth="#{bindings.Image.innerWidth}"
 *     contentType="#{bindings.Image.inputValue.media.mimeType}"/&gt;
 * </PRE>
 * 
 * This class also provide update functionality for intermedia objects, in
 * BC4J/Faces case, the Faces component for uploading intermedia object is 
 * &lt;af:inputFile&gt;
 *
 * MetaData example for uploading an intermedia object is:
 *    &lt;af:inputFile label="upload" value="#{bindings.Image.inputValue}"/&gt;
 *
 * @javabean.class name=OrdDomainValueHandler
 */ 
public final class OrdDomainValueHandler implements JUCtrlValueHandler
{
  
  //----------------------------Constructor-- -------------------------------
  public OrdDomainValueHandler()
  {
  }
  
  
  //----------------------------Public methods-------------------------------
  public Object getInputValue(final JUCtrlValueBinding  binding, int  index)
  {
    return new AbstractMap()
      {
        public Object get(Object objKey)
        {
          if ( _SOURCE_ATTR.equals(objKey) )
          {
            return getSource(binding);
          }
          else if ( _MEDIA_ATTR.equals(objKey) )
          {
            return binding.getAttribute();
          }
          else if ( _INNERHEIGHT_ATTR.equals(objKey))            
          {
            return getInnerValue(binding, _HEIGHT_ATTR);
          }
          else if ( _INNERWIDTH_ATTR.equals(objKey) )
          {
            return getInnerValue(binding, _WIDTH_ATTR);
          }
          else if ( _SHORTDESC_ATTR.equals(objKey) )
          {
            return binding.getAttributeNames()[0];
          } 
          
          return null;
        }
        
        public Set entrySet(){return Collections.EMPTY_SET;}
      };
  }
  
  
  /**
   * Implements the method defined in interface JUCtrlInputValueHandler.
   * 
   * @see oracle.jbo.uicli.binding.JUCtrlInputValueHandler
   */
  public boolean isNewInputValue(JUCtrlValueBinding binding, 
                                 int                index, 
                                 Object             value)
  {
    if (binding != null)
    {
      return true;
    }
    
    return false;
  }
  
  
  /**
   * Implements the method defined in interface JUCtrlInputValueHandler.
   * @see oracle.jbo.uicli.binding.JUCtrlInputValueHandler
   */
  public void setInputValue(JUCtrlValueBinding binding, 
                            int                index, 
                            Object             value)
  {
    if (value instanceof UploadedFile)
    {
      UploadedFile fileValue = (UploadedFile)value;
      value = getOrdObject(fileValue , binding);
    }
    
    if (value != null)
    {
      binding.setInputValue(binding, index, value);
    }
  }
  
  
  //--------------------------Private methods -------------------------------    
  /**
   * Get the value of source
   * 
   * @param binding    the instance of JUCtrlValueBinding 
   * @return value for source attribute of af:objectMedia
   * 
   * NOTE: EL expression format in metaData is like this:
   * "#{bindings.bindingName.inputValueHandler['bindings.bindingName.source']}"
   */    
  private String getSource(JUCtrlValueBinding binding)  
  {
    if ( binding == null )
    {
      return null;
    }
    
    String attrName = binding.getAttributeNames()[0];
    String mimeType = getMimeType(binding);
    
    if ( mimeType == null )
    {
      return null;
    }
    
    ViewObject vo = binding.getViewObject();
    Row row = (Row)binding.get(_CURRENT_ROW);
    String result = getSrcInternal(binding.getDCIteratorBinding(), 
                                   vo, 
                                   row, 
                                   attrName);
    return result;
  }
  
  
  private Object getInnerValue(JUCtrlValueBinding binding, String attrName)
  {
    String mimeType = getMimeType(binding);
    if ( (mimeType != null) && mimeType.toString().startsWith("image/") )
    {
      OrdImageDomain obj = (OrdImageDomain)binding.getAttribute();
      int res = 0;
      try
      {
        if ( attrName.equals(_WIDTH_ATTR) )
        {
          res = obj.getWidth();
        }
        else if ( attrName.equals(_HEIGHT_ATTR) )
        {
          res = obj.getHeight();
        }
      }
      catch (SQLException e)
      {
        _LOG.severe(e);
      }        
      
      // if res is zero, we must return null. 
      // otherwise image content will be rendered with zero width:
      return (res > 0) ? new Integer(res) : null;
    }
    
    return null;        
  }
  
  
  private Object getOrdObject(UploadedFile       file,
                              JUCtrlValueBinding binding)
  {
    if ( file != null )
    {
      String filename = file.getFilename();
      String contentType = file.getContentType();
      if (filename.length() > 0 && file.getLength() >= 0)
      {
        try
        {
          return DCUtil.getOrdObject(file.getInputStream(),
                                     contentType,
                                     binding);
        }
        catch (IOException e)
        {
          throw new JboException(e);
        }
      }
    }
    
    return null;  
  }
  
  
  private String getMimeType(JUCtrlValueBinding binding)
  {
    if ( binding == null )  
    {
      return null;
    }
    
    OrdDomainIOInterface media = 
    (OrdDomainIOInterface)binding.getAttribute();
    
    if ( media == null )
    {
      return null;
    }
    
    String mimeType = null;
    
    try
    {
      mimeType = media.getMimeType();
    }
    catch (SQLException e)
    {
      _LOG.severe(e);
    }        
    
    return mimeType;
  }
  
 
  private String getSrcInternal(DCIteratorBinding iterBinding,
                                ViewObject        vo, 
                                Row               row,
                                String            attrName)
  {
    if ( vo == null )
    {
      return null;
    }
    
    ApplicationModule am = vo.getApplicationModule();
    String appId = iterBinding.getDataControl().getName();      
    String viewObjectFullName = vo.getFullName();
    
    //
    // Get the ord.RetrievePath property from BC4J config
    //
    Hashtable env = am.getSession().getEnvironment();
    String retrPath = (String)env.get(PropertyConstants.ORD_RETRIEVE_PATH);
    
    if( retrPath == null || retrPath.length() == 0 )
    {
      retrPath = PropertyMetadata.ORD_RETRIEVE_PATH.getProperty();
    }
    
    OrdURLBuilder builder = new OrdURLBuilder(appId, 
                                              viewObjectFullName, 
                                              row, 
                                              attrName,
                                              retrPath, 
                                              null /*amConfig*/);
    
    
    // Fix for bug4492525, we need to return value starting with "/"
    // thus it can reenter the ADFBindingFilter to initialize the 
    // datacontrol correctly to fetch the intermedia object.
    String url = builder.getOrdDomainURL();
    if ( !url.startsWith("/") )
    {
       return "/" + url;
    }
    
    return url;    
  }
  
  private static String _SOURCE_ATTR      = "source";
  private static String _MEDIA_ATTR       = "media";
  private static String _INNERHEIGHT_ATTR = "innerHeight";
  private static String _INNERWIDTH_ATTR  = "innerWidth";
  private static String _SHORTDESC_ATTR   = "shortDesc";
  
  private static String _HEIGHT_ATTR = "height";
  private static String _WIDTH_ATTR  = "width";
  private static String _CURRENT_ROW = "currentRow";
  
  static private final ADFLogger _LOG =
    ADFLogger.createADFLogger(OrdDomainValueHandler.class);
}