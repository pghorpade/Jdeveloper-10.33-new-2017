/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import java.io.Serializable;


import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.faces.util.MessageFactory;

import oracle.adfinternal.view.faces.model.ModelUtils;

import oracle.jbo.AttributeDef;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * This class extends a JUCtrlAttrsBinding to provides a faces Validator.
 */
public final class FacesCtrlAttrsBinding extends JUCtrlAttrsBinding
{
  public FacesCtrlAttrsBinding(Object control, 
                               DCIteratorBinding iterBinding, 
                               String[] attrNames)
  {
    super(control, iterBinding, attrNames);
  }

  /**
    * This Validator performs binding level validations.
    */
  public Validator getValidator()
  {
    return _validator;
  }

  /**
   * Gets the clientId of the component that is bound to this binding.
   * This is useful when queueing {@link FacesMessage}s.
   * @return may return null if it is not possible to determine the 
   * component.
   * @see UIComponent#getClientId
   */
  public String getComponentClientId()
  {
    // this is to support bug 4449724:
    return _clientId;
  }

  /**
   * gets the type of an attribute keeping in mind that the type
   * must be string for find mode, and when formatting hints are
   * present.
   */
  public Class getType()
  {
    AttributeDef def = getAttributeDef();
    return getType(this, def);
  }

  /**
   * gets the type of an attribute keeping in mind that the type
   * must be string for find mode, and when formatting hints are
   * present.
   */
  public static Class getType(JUCtrlValueBinding binding, AttributeDef def)
  {
    if (_isFindMode(binding))
    {
      // we need to support SQL query strings like: > 80
      return String.class;
    }

    // When formats are set on the binding, the type of the
    // attribute is string. bug 4620622:
    if (def.getUIHelper().hasFormatInformation(binding.getLocaleContext()))
    {
      return String.class;
    }
    return def.getJavaType();
  }
  
  public void setInputValue(Object value)
  {
    // note that validators do not run if the value is null:
    if (_isNull(value))
    {
      // we need to do the following test here, because the jsf spec
      // components do not treat the empty string and null as being
      // the same:
      if (_isNull(getInputValue()))
        return; // bug 4268807
    }
    // if the value is not null, then see if our validator has indicated
    // that the value has not changed: bug 4602898
    else if (_unmodified)
    {
      // we use "unmodified" instead of "modified" because sometimes
      // validators may not run (eg: if the validator is not bound in the JSP).
      _unmodified = false;
      return;       
    }

    super.setInputValue(value);
    
    // if there are errors then throw them.
    // this way the error will get associated with the input component.
    // bug 4697437:
    // actually don't throw them. This causes bug 4859261.
    // instead, the controller will report them with the correct clientId.
    //JboException error = getError();
    //if (error != null)
    //  throw error;
  }

  /**
    * Does this binding support find mode?
    * @return this implementation always returns true.
    */
  protected boolean isControlQueriable()
  {
    return true; // we support find mode.
  }

  private static boolean _isFindMode(JUCtrlValueBinding binding)
  {
    JUIteratorBinding iter = binding.getIteratorBinding();
    boolean findMode = (iter != null) 
      ? iter.isFindMode() 
      : binding.getBindingContainer().isFindMode();
    return findMode;
  }

  private boolean _isNull(Object v)
  {
    return (v == null) || ("".equals(v));
  }

  protected Object internalGet(String key)
  {
    // small optimization to avoid using introspection:
    if ("validator".equals(key))
     return getValidator();
    if ("componentClientId".equals(key))
     return getComponentClientId();
    return super.internalGet(key);
  }

  private transient boolean _unmodified = false;
  private String _clientId = null;
  private final Validator _validator = new AttrValidator(this);
   
  // this inner class must be serializable.
  // therefore, mark it static so that we don't serialize the binding class.
  // bug 4352633.
  private static final class AttrValidator implements Validator, Serializable
  {
    public AttrValidator()
    {
      // no arg contructor needed for Serializable
    }
    
    public AttrValidator(FacesCtrlAttrsBinding binding)
    {
      _binding = binding;
    }
  
    public void validate(FacesContext context, UIComponent component, Object value)
    {
      FacesCtrlAttrsBinding binding = _getBinding(context, component);
      binding._clientId = component.getClientId(context);
      boolean isModified = binding.processNewInputValue(value);
      // JSF spec components update the model even though the values have
      // not changed. Therefore, we need to do something here to prevent
      // the transaction from getting dirty in this case:
      binding._unmodified = !isModified;
      if (isModified)
      {
        Object isValid = binding.validateInputValue(value);
        if (isValid != null)
        {
          final FacesMessage message;
          // see bug 4342632:
          if (isValid instanceof Throwable)
          {
            Throwable t = (Throwable) isValid;
            message = MessageFactory.getMessage(t);
          }
          else
          {
            String detail = isValid.toString();
            message = 
             new FacesMessage(FacesMessage.SEVERITY_ERROR, detail, detail);
          }
          throw new ValidatorException(message);
        }
      }
    }
    
    private FacesCtrlAttrsBinding _getBinding(FacesContext context, UIComponent component) 
    {
      // binding might be null if we've just been restored from a 
      // passivated session:
      if (_binding == null)
      {
        _binding = (FacesCtrlAttrsBinding) ModelUtils.getBinding(context, component);
      }
      return _binding;
    }
    
    // we do not want to serialize the binding classes:
    private transient FacesCtrlAttrsBinding _binding = null;
  }
}
