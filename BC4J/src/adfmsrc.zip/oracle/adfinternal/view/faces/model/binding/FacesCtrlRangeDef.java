/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.jbo.uicli.binding.JUCtrlRangeDef;

/**
 * This definition class creates FacesCtrlRangeBindings
 */
public final class FacesCtrlRangeDef extends JUCtrlRangeDef 
{
  public FacesCtrlRangeDef()
  {
    super();
  }

  protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
  {
    return new FacesCtrlRangeBinding(control, getIterBinding(formBnd), getAttrNames());
  }
}
