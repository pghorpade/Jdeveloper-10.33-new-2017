/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.faces.event.SelectionEvent;
import oracle.adf.view.faces.model.CollectionModel;
import oracle.adf.view.faces.model.CurrencySet;
import oracle.adf.view.faces.model.RowKeySet;
import oracle.adf.view.faces.model.SortCriterion;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.Key;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.SortCriteria;
import oracle.jbo.SortCriteriaImpl;
import oracle.jbo.uicli.binding.JUCtrlRangeBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBindingRef;

/**
 * This class provides a Faces CollectionModel accessor for
 * JUCtrlRangeBindings
 */
public final class FacesCtrlRangeBinding extends JUCtrlRangeBinding
{
   /**
   * This constructor passes on the control, iterator, and attribute binding information
   * to its super.
   */
   public FacesCtrlRangeBinding(Object control, DCIteratorBinding iterBinding,
                                String[] attrNames)
   {
      super(control, iterBinding, attrNames);
   }

   /**
     * Gets a CollectionModel interface to this range binding.
     */
   public CollectionModel getCollectionModel()
   {
     return _model;
   }

  /**
   * Provides a map from column name to AttributeDef.
   * This makes it easier to write EL expressions for the various
   * column properties (like mandatory, queriable, etc...).
   * @return A map. Each key is of type {@link String}. Each value is of type
   * {@link AttributeDef}.
   */
  public Map getAttrDefs()
  {
    return new AttrMap()
    {
      public Object get(Object key)
      {
        Object def = findAttributeDef(key.toString());
        if (def == null)
          _LOG.warning("AttributeDef not found for property:{0}", key);
        return def;
      }
    };
  }

  /**
   * Provides a Map from column name to attribute hint information.
   * This makes it easier to write EL expressions for the various
   * column UIHint properties (like toolTip, displayWidth, etc...).
   * @return A Map or Maps. The first Map takes a {@link String} key
   * and returns a second {@link Map}. The second Map supports the
   * following keys:<ul>
   * <li>toolTip
   * <li>label
   * <li>format
   * <li>displayWidth
   * <li>displayHint
   * </ul>
   */
  public Map getAttrHints()
  {
    return new AttrMap()
    {
      public Object get(Object skey)
      {
        AttributeHints attrhints = getAttributeUIHelper((String) skey);
        if (attrhints == null)
        {
          _LOG.warning("AttributeHints not found for property:{0}", skey);
          return null;
        }
        
        final AttributeHints hints = attrhints; // store on the heap
        return new AbstractMap()
        {
          public Object get(Object key)
          {
            String k = key.toString();
            LocaleContext lc = getLocaleContext();
            if ("format".equals(k))
              return hints.getFormat(lc);
            if ("displayWidth".equals(k))
              return new Integer(hints.getDisplayWidth(lc));
            if ("toolTip".equals(k))
              return hints.getTooltip(lc);
            if ("displayHint".equals(k))
              return hints.getDisplayHint(lc);
            if ("label".equals(k))
              return hints.getLabel(lc);

            _LOG.warning("Property '{0}' not supported on AttributeHints", k);
            return null;
          }
        
          public Set entrySet()
          {
            return Collections.EMPTY_SET;
          }
        };
      }

    };
  }

  /**
     * Internal map implementation to speed up EL property resolution
     */
  protected Object internalGet(String key)
  {
    // small optimization to avoid using introspection:
    if ("collectionModel".equals(key))
      return getCollectionModel();
    if ("attrDefs".equals(key))
      return getAttrDefs();
    if ("attrHints".equals(key))
      return getAttrHints();

    return super.internalGet(key);
  }

  static boolean __isSortable(JUCtrlRangeBinding binding, String property)
  {
    AttributeDef def = binding.findAttributeDef(property);
    if (def == null)
      return false;
      
    return binding.getDCIteratorBinding().isAttributeSortable(def);
  }
  
  static void __setSortCriteria(JUCtrlRangeBinding binding, List criteria)
  {
    if ((criteria == null) || (criteria.isEmpty()))
      return;

    List current = __getSortCriteria(binding);
    if (current.equals(criteria)) // bug 4529819
      return;
  
    int sz = criteria.size();
    SortCriteria[] sort = new SortCriteria[sz];
    for(int i=0; i<sz; i++)
    {
      SortCriterion criterion = (SortCriterion) criteria.get(i);
      sort[i] = new SortCriteriaImpl(criterion.getProperty(),
                                     !criterion.isAscending());
    }
    DCIteratorBinding iterBinding = binding.getIteratorBinding();
    iterBinding.applySortCriteria(sort);
    iterBinding.executeQuery();
    binding.getBindingContainer().refreshControl(); // bug 4460968
  }

  static List __getSortCriteria(JUCtrlRangeBinding binding)
  {
    SortCriteria[] sort = binding.getIteratorBinding().getSortCriteria();
    if ((sort == null) || (sort.length == 0))
      return Collections.EMPTY_LIST;
    SortCriterion[] cr = new SortCriterion[sort.length];
    for(int i=0; i<sort.length; i++)
    {
      SortCriteria sc = sort[i];
      cr[i] = new SortCriterion(sc.getAttributeName(), !sc.isDescending());
    }
    if (cr != null) 
    {
      return Collections.unmodifiableList(Arrays.asList(cr));  
    }
    else
      return Collections.unmodifiableList(Collections.EMPTY_LIST);
  }
   
   public final class FacesModel extends CollectionModel
   {
      public FacesModel()
      {
      }

      /**
       * Gets a RowKeySet where the currency row is selected.
       */
      public RowKeySet getSelectedRow()
      {
        RowKeySet set = _selectedSet;
        RowIterator iter = _getRowIterator();
        if (iter != null) // bug 4456513
        {
          Row row = iter.getCurrentRow();
          if (row != null)
          {
            // bug 4743281:
            Object key = _getRowKey(row, true);
            if (key == null)
            {
              if (set.getSize() > 0)
              {
                set.clear();
                _currentRowKey = null;
              }
            }
            else if ((_currentRowKey == null) || (!_currentRowKey.equals(key)))
            {
              _currentRowKey = key;
              set.clear();
              Set keySet = set.getKeySet();
              keySet.add(key);
            }
          }
        }
        else
          _LOG.warning("rowIterator is null");

        return set;
      }

      private Object _getRowKey(Row row, boolean dontScroll)
      {
        Key key = row.getKey();
        // bug 4141026: when in findMode the key can be null:
        // bug 4743281: when readOnly VOs are used there may be no
        // primary key columns:
        if ((key != null) && (key.getAttributeCount() > 0)) 
        {
          return key;
        }
        
        int index = _getRowIndex(row, dontScroll);
        // if dontScroll==false, then index must be non-negative:
        assert (dontScroll) || (index >= 0);

        return (index >= 0) ? new Integer(index) : null;
      }

      /**
       * Makes the row that the user selected the current row in this
       * row iterator.
       */
      public void makeCurrent(SelectionEvent event)
      {
        // clear the cached key - bug 4588486
        _currentRowKey = null;
        RowIterator iter = _getRowIterator();
        if (iter == null)
        {
          return; // bug 4456513
        }

        CurrencySet selectedSet = event.getSelectedKeys();
        Iterator selection = selectedSet.getKeySet().iterator();
        if (selection.hasNext())
        {
          Object rowKey = selection.next();
          Object oldKey = getRowKey();
          setRowKey(rowKey);
          if (_row != null)
            iter.setCurrentRow(_row);
          else
            _LOG.warning("No row found for rowKey:{0}", rowKey);
          setRowKey(oldKey);
        }
      }
    
      /**
       * tests to see if the row returned by {@link #getRowData}
       * is the current row in this RangeBinding.
       */
      public boolean isRowCurrent()
      {
        if (isRowAvailable())
        {
          assert _row != null;
          
          Row currentRow = getCurrentRow();
          if (_row.equals(currentRow))
            return true;
          
          if (currentRow != null)
          {
            Object currKey = currentRow.getKey();
            // bug 4469897:
            if (currKey != null)
              return currKey.equals(_row.getKey());
              
            int currIndex = getCurrentRowIndex(); // this is an absolute index
            return currIndex == _getRowIndex(_row, false);
          }
        }
        return false;
      }

      /**
        * Gets the range binding that this CollectionModel is bound to
        */
      public FacesCtrlRangeBinding getRangeBinding()
      {
        return FacesCtrlRangeBinding.this;
      }

      /**
        * Tests to see if this collection is sortable by the given property
        */
      public boolean isSortable(String property)
      {
        return __isSortable(FacesCtrlRangeBinding.this, property);
      }

      public void setSortCriteria(List criteria)
      {
        __setSortCriteria(FacesCtrlRangeBinding.this, criteria);
      }

      public List getSortCriteria()
      {
        return __getSortCriteria(FacesCtrlRangeBinding.this);
      }

      public Object getRowKey()
      {
        if (_row == null)
          return null;
        Object key = _getRowKey(_row, false);
        return key;
      }

      public void setRowKey(Object rowKey)
      {
        if (rowKey == null)
          _setRowData(null);
        else if (rowKey instanceof Integer)
        {
          int rowIndex = ((Integer) rowKey).intValue();
          setRowIndex(rowIndex);
        }
        else
        {
          try
          {
            RowIterator iter = _getRowIterator();
            if (iter == null)
            {
              _setRowData(null);
              return;
            }
            Key key = (Key) rowKey;
            Row row = iter.getRow(key);
            if (_LOG.isWarning() && (row == null))
              _LOG.warning("row is null for rowKey:{0}", key);
              
            _setRowData(row);
          }
          catch (Exception e)
          {
            _LOG.severe(e);
            _setRowData(null);
          }
        }
      }

      public int getRowCount()
      {
        long rows = getEstimatedRowCount();
        return (rows > Integer.MAX_VALUE) ? Integer.MAX_VALUE : (int) rows;
      }

      public Object getRowData()
      {
        if (_row == null)
          return null;
          
        if (_rowData == null)
        {
          RowIterator rowIterator = _getRowIterator();
          if (rowIterator == null)
          {
            return null;
          }
          int rangeIndex = _getRangeIndex(_row, rowIterator, false);
          _rowData = 
            createValueBindingRef(FacesCtrlRangeBinding.this, rangeIndex, _row);
        }
        return _rowData;
      }

      public int getRowIndex()
      {
        return _getRowIndex(_row, false);
      }

      private int _getRowIndex(Row row, boolean dontScroll)
      {
        if (row == null)
          return -1;

        RowIterator rowIterator = _getRowIterator();
        if (rowIterator == null)
        {
          return -1;
        }
        int rangeIndex = _getRangeIndex(row, rowIterator, dontScroll);
        // if dontScroll==false then rangeIndex must be non-negative:
        assert dontScroll || (rangeIndex >= 0);
        return (rangeIndex >= 0)
        ? rangeIndex + rowIterator.getRangeStart()
        : -1;
      }

      /**
       * gets the range index of a particular row.
       * @param row the row to search for
       * @param dontScroll normally the range will scroll until the
       * corresponding row is in range. Set this to true, if the range should not
       * scroll.
       * @return -1 if the row could not be found in the current range, and the
       * range could not be scrolled.
       */
      private int _getRangeIndex(Row row, RowIterator rowIterator, boolean dontScroll)
      {
        int rangeIndex = rowIterator.getRangeIndexOf(row);
        if ((rangeIndex < 0) && (!dontScroll))
        {
          // row was not in range. scroll range:
          rowIterator.scrollRangeTo(row, 0);
          rangeIndex = rowIterator.getRangeIndexOf(row);
          // at this point the row must be in range:
          assert rangeIndex >= 0;
        }
        return rangeIndex;
      }

      private RowIterator _getRowIterator()
      {
        DCIteratorBinding iter = getDCIteratorBinding();
        // Must not call getRowIterator() if the binding has not been 'refreshed' yet. 
        // Otherwise, this ends up executing a method that was protected by a refresh condition.
        // so test to see if the RSI exists before making the call:
        // bug 4566686:
        if (!iter.hasRSI())
          return null;
        RowIterator rowIterator = getRowIterator();
        if (rowIterator == null)
        {
          _LOG.warning("rowIterator is null");
        }
        return rowIterator;
      }

      public Object getWrappedData()
      {
        return FacesCtrlRangeBinding.this;
      }

      public boolean isRowAvailable()
      {
        return (_row != null);
      }

      public boolean isRowAvailable(int rowIndex)
      {
        // optimization. prevents calls to setRowIndex(rowIndex).
        // as a result it prevents bug 4514562:
        return ((rowIndex >= 0) && (rowIndex < getRowCount()));
      }

      public void setRowIndex(int rowIndex)
      {
        if ((rowIndex < 0) || (rowIndex >= getRowCount()))
          _setRowData(null);
        else
        {
          Row row = _bringInToRange(rowIndex);
          _setRowData(row);
        }
      }

      private void _setRowData(Row row)
      {
        _row = row;
        _rowData = null;
      }

      private Row _bringInToRange(int rowIndex)
      {
        boolean execute = false;
        int start = getRangeStart();
        if (rowIndex < start)
        {
          execute = true;
        }
        else if (rowIndex > start)
        {
          int size = getRangeSize();
          if (size > 0)
          {
            if ((start + size) <= rowIndex)
            {
              execute = true;
            }
          }
        }
        if (execute)
        {
          setRangeStart(rowIndex);
          getBindingContainer().refreshControl();
          start = getRangeStart();
        }
        int rangeIndex = rowIndex - start;
        Row row = getRowIterator().getRowAtRangeIndex(rangeIndex);
        return row;
      }


      public void setWrappedData(Object data)
      {
        throw new UnsupportedOperationException();
      }

      private transient JUCtrlValueBindingRef _rowData = null;
      private transient Row _row = null;
      private transient Object _currentRowKey = null;
      private final RowKeySet _selectedSet = new RowKeySet();
   }

   private final FacesModel _model = new FacesModel();

  private abstract class AttrMap extends AbstractMap
  {
    protected AttrMap()
    {
    }
  
    public final int size()
    {
      return getAttributeCount();
    }

    public abstract Object get(Object key);

    public Set entrySet()
    {
      return Collections.EMPTY_SET;
    }
  }

   private static final ADFLogger _LOG =
    ADFLogger.createADFLogger(FacesCtrlRangeBinding.class);
}
