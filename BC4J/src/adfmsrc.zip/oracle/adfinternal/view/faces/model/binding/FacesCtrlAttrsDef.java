/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.uicli.binding.JUCtrlAttrsDef;

/**
 * This definition class creates FacesCtrlAttrsBindings
 */
public final class FacesCtrlAttrsDef extends JUCtrlAttrsDef 
{
  public FacesCtrlAttrsDef()
  {
    super();
  }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      //kava creates bindings with null iterators as well.
      return new FacesCtrlAttrsBinding(control, 
                                       (getIterBindingName() != null)
                                       ? this.getIterBinding(formBnd)
                                       : null, 
                                       getAttrNames());
   }
}
