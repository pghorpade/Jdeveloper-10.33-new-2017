/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import oracle.adf.view.faces.model.TreeModel;
import oracle.jbo.uicli.binding.JUCtrlHierBinding;
import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements a JUCtrlHierBinding that provides an accessor for a faces
 * specific TreeModel instance.
 */
public final class FacesCtrlHierBinding extends JUCtrlHierBinding
{
  public FacesCtrlHierBinding(Object control, JUIteratorBinding iterBinding,
                              String[] attrNames, JUCtrlHierTypeBinding[] typeBindings)
  {
    super(control, iterBinding, attrNames, typeBindings);
  }
  
  public TreeModel getTreeModel()
  {
    return new FacesModel();
  }

  protected Object internalGet(String key)
  {
    // small optimization to avoid using introspection:
    if ("treeModel".equals(key))
      return getTreeModel();
    return super.internalGet(key);
  }
  
  public final class FacesModel extends TreeModel
  {
    public FacesModel()
    {
      _currentCollection = _getRootCollection();
      _rowIndex = -1;
    }
  
    public FacesCtrlHierBinding getHierBinding()
    {
      return FacesCtrlHierBinding.this;
    }

    public boolean isSortable(String property)
    {
      return FacesCtrlRangeBinding.__isSortable(FacesCtrlHierBinding.this, property);
    }

    public void setSortCriteria(List criteria)
    {
      FacesCtrlRangeBinding.__setSortCriteria(FacesCtrlHierBinding.this, criteria);
    }

    public List getSortCriteria()
    {
      return FacesCtrlRangeBinding.__getSortCriteria(FacesCtrlHierBinding.this);
    }
  
    private List _getRootCollection()
    {
      return _getKids(getRootNodeBinding());
    }
  
    private List _getKids(JUCtrlHierNodeBinding binding)
    {
      if (binding != null) // bug 4874238
      {
        List kids = binding.getChildren();
        if (kids != null)
          return kids;
      }
      return Collections.EMPTY_LIST;
    }
  
    public Object getRowData()
    {
      if (isRowAvailable())
        return _getRowData();
      return null;
    }

    private JUCtrlHierNodeBinding _getRowData()
    {
      return (JUCtrlHierNodeBinding) _currentCollection.get(_rowIndex);
    }

    public int getRowCount()
    {
      return _currentCollection.size();
    }
    
    public int getRowIndex()
    {
      return _rowIndex;
    }
    
    public void setRowIndex(int index)
    {
      _rowIndex = index;
    }
        
    public boolean isRowAvailable()
    {
      return (_rowIndex >= 0) && (_rowIndex < _currentCollection.size());
    }
    
    public Object getWrappedData()
    {
      return FacesCtrlHierBinding.this;
    }
    
    public void setWrappedData(Object data)
    {
      throw new UnsupportedOperationException();
    }
    
    public Object getRowKey()
    { 
      int sz = _path.size();
      List result = new ArrayList(sz + 1);
      for(int i=0; i<sz; i++)
      {   
        NodeData data = (NodeData) _path.get(i);
        result.add(String.valueOf(data.index));
      }
      result.add(_getRowKey());
      return Collections.unmodifiableList(result);
    }
    
    public void setRowKey(Object rowKey)
    {
      _currentCollection = _getRootCollection();
      _rowIndex = -1;
      _path.clear();
      
      if (rowKey == null)
        return;

      List path = (List) rowKey;
      int sz = path.size();          
        
      if (sz > 0)
      {
        for(int i=0; i<sz-1; i++)
        {
          String key = (String) path.get(i);
          _setRowKey(key);;
          enterContainer();
        }
        
        String key = (String) path.get(sz-1);
        _setRowKey(key);
      }
    }
    
    private String _getRowKey()
    {
      return (_rowIndex >= 0) ? String.valueOf(_rowIndex) : null;
    }
    
    private void _setRowKey(String key)
    {
      _rowIndex = (key != null) ? Integer.parseInt(key) : -1;
    }
    
    public Object getContainerRowKey(Object childKey)
    {
      List path = (List) childKey;
      if (path != null)
      {
	int sz = path.size();
	if (sz > 1)
	{
	  return path.subList(0, sz - 1);
	}
      }
      return null;
    }
    
    public void enterContainer()
    {
      JUCtrlHierNodeBinding node = _getRowData();
      if (node == null)
        throw new IllegalStateException("There is no container available");
      _path.add(new NodeData(_currentCollection, _rowIndex));
      _currentCollection = _getKids(node);
      _rowIndex = -1;
    }
    
    public void exitContainer()
    {
      if (_path.size() == 0)
        throw new IllegalStateException("Not inside a container");
      NodeData data = (NodeData) _path.removeLast();
      _currentCollection = data.collection;
      _rowIndex = data.index;
    }
    
    public boolean isContainer()
    {
      // the following is too expensive at the moment: bug 4597193
//      JUCtrlHierNodeBinding node = _getRowData();
//      return node.getChildren() != null;
      return true;
    }
    
    private List _currentCollection;
    private int _rowIndex;
    private final LinkedList _path = new LinkedList();
  }
  
  private static final class NodeData
  {
    public final List collection;
    public final int index;
    
    public NodeData(List collection, int rowIndex)
    {
      this.collection = collection;
      index = rowIndex;
    }
  }
}
