/*
** Copyright (c) 2005, Oracle Corporation. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

package oracle.adfinternal.view.faces.model.binding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlActionDef;

/**
 * This definition class creates FacesCtrlActionBindings
 */
public final class FacesCtrlActionDef extends JUCtrlActionDef 
{
  public FacesCtrlActionDef()
  {
    super();
  }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createInvokeActionBinding(
    Object control,
    DCBindingContainer formBnd,
    DCInvokeMethodDef methodInfo)
   {
      return new FacesCtrlActionBinding(control, formBnd, methodInfo);
   }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createDataControlActionBinding(
    Object control,
    DCDataControl dataControl,
    int action)
   {
      return new FacesCtrlActionBinding(control, dataControl, action);
   }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createIteratorActionBinding(
    Object control,
    DCIteratorBinding iterBinding,
    int action)
   {
      return new FacesCtrlActionBinding(control, iterBinding, action);
   }
}
