/*
 * @(#)JUActionBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultButtonModel;
import javax.swing.JPanel;
import javax.swing.event.ChangeListener;
import java.util.ArrayList;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlActionBindingEvent;
import oracle.jbo.uicli.binding.JUCtrlActionDef;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCInvokeMethodDef;

/**
 * Implements binding for a JButton to one of the commonly-used methods on the associated
 * RowSet. The super class JUCtrlActionBinding has all the necessary logic to bind to 
 * a BC4J RowSet. This class is a public facade to allow a Swing JButton to work with
 * the logic in the superclass.  
 * <p>
 * This class also implements Swing ButtonModel to allow design time to associate a binding
 * editor with a JButton. 
 * @see oracle.jbo.uicli.binding.JUCtrlActionBinding
 */
public class JUActionBinding extends JUCtrlActionBinding implements ActionListener, ButtonModel
{
   private ButtonModel mButtonModel = null;

   
   /**
   * This constructor binds the given JButton object (control) with an enumerated action
   * in the RowSet identified by the given iterator binding. Also adds this binding
   * class as an ActionListener on the given control.
   */
   public JUActionBinding(Object control, JUIteratorBinding iterBinding, int action)
   {
      this(control, iterBinding, action, true);
   }

   /**
   * This constructor binds the given JButton object (control) with an enumerated action
   * in the RowSet identified by the given iterator binding. Optionally adds this binding
   * class as an ActionListener on the given control.
   */
   public JUActionBinding(Object control, JUIteratorBinding iterBinding, int action, boolean addAsActionListener)
   {
      super(control, iterBinding, action);

      init(control, addAsActionListener);
   }
      


   public JUActionBinding(Object control, DCBindingContainer form, DCInvokeMethodDef methodInfo)
   {
      super(control, form, methodInfo);
      init(control, true);
   }

   private void init(Object control, boolean addAsActionListener)
   {
      if (control instanceof AbstractButton)
      {
         AbstractButton button = (AbstractButton) control;

         mButtonModel = getModelImpl(button, addAsActionListener);

         if (mButtonModel != button.getModel())
         {
            button.setModel(mButtonModel);
         }
         
         //if not added to bindingContainer add it.
         if (getBindingContainer() == null && getIteratorBinding() != null) 
         {
            //tested in gvbasic si23
            setBindingContainer(getIteratorBinding().getBindingContainer());
         }
      }
   }

   ButtonModel getModelImpl(Object control, boolean addAsActionListener)
   {
      ButtonModel buttonModel = null;

      if (control instanceof AbstractButton)
      {
         AbstractButton button = (AbstractButton) control;

         if (button != null)
         {
            buttonModel = button.getModel();
         }

         if (buttonModel == null)
         {
            buttonModel = new DefaultButtonModel();
         }
         
         if (addAsActionListener)
         {
            //precaution as this method may be called more than once.
            try
            {
               buttonModel.removeActionListener(this);
            }
            catch (Exception e)
            {
               //ignore.
            }

            buttonModel.addActionListener(this);
         }
         
         if (getDef() != null)
         {
            JUCtrlActionDef def = (JUCtrlActionDef)getDef();
            if (def.getText () != null)
            {
               //this is for decl based jclient texts.
               button.setText(def.getText());
            }
         }
      }

      return buttonModel;
   }
   
   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {
      setControl(control);
      mButtonModel = getModelImpl(control);
      return mButtonModel;
   }

   /**
   * Returns the button model to which this binding class and the given control are
   * associated. If control is null and there is no button model associated with
   * this binding object, it creates a new instance of DefaultButtonModel and returns it.
   * <p>
   * Framework uses this method to get the button model for the associated control.
   */
   protected ButtonModel getModelImpl(Object control)
   {
      return getModelImpl(control, true);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
    * Calls JUCtrlActionBinding.invoke() method to perform this action
    * invoke() routes this call to a datacontrol just in case the associated
    * datacontrol overrides the implementation for this action. Default datacontrol
    * gets back to this action's doIt() method for the action implementation.
   */
   public void actionPerformed(ActionEvent evt)
   {
      invoke();
   }

   protected JUCtrlActionBindingEvent createActionBindingEvent()
   {
      return new JUActionBindingEvent (this); 
   }


   /**
    * Override to implement ActionBinding events.
    */
   /*
   public void doIt()
   {
      int i;
      JUActionBindingEvent ev = null;
      ArrayList al = null;
      int count = 0;
      if (mListeners != null && mListeners.size() > 0)
      {
         ev = new JUActionBindingEvent (this);
         al = (ArrayList)mListeners.clone();
         count = al.size(); 
         for (i = 0; i < count; i++) 
         {
            ((JUActionBindingListener)al.get(i)).beforeActionPerformed(ev);
         }
      }
      
      //no need to stopediting here. if an action leads to rangerefereshed,
      //table binding will clean/remove it's editor. If an action needs
      //stopEdit - like commit/navigation, their events handler on the panel 
      //binding will perform stopEdit.
      super.doIt();

      //int id = getActionId();

      if (ev != null)
      {
         for (i = 0; i < count; i++) 
         {
            ((JUActionBindingListener)al.get(i)).afterActionPerformed(ev);
         }
      }
   }
   */


   //
   // ButtonModel implementation
   //

   public boolean isArmed()
   {
      return mButtonModel.isArmed();
   }


   public boolean isSelected()
   {
      return mButtonModel.isSelected();
   }


   public boolean isEnabled()
   {
      return mButtonModel.isEnabled();
   }


   public boolean isPressed()
   {
      return mButtonModel.isPressed();
   }


   public boolean isRollover()
   {
      return mButtonModel.isRollover();
   }


   public void setArmed(boolean b)
   {
      mButtonModel.setArmed(b);
   }


   public void setSelected(boolean b)
   {
      mButtonModel.setSelected(b);
   }


   public void setEnabled(boolean b)
   {
      mButtonModel.setEnabled(b);
   }


   public void setPressed(boolean b)
   {
      mButtonModel.setPressed(b);
   }


   public void setRollover(boolean b)
   {
      mButtonModel.setRollover(b);
   }


   public void setMnemonic(int key)
   {
      mButtonModel.setMnemonic(key);
   }


   public int getMnemonic()
   {
      return mButtonModel.getMnemonic();
   }


   public void setActionCommand(String s)
   {
      mButtonModel.setActionCommand(s);
   }


   public String getActionCommand()
   {
      return mButtonModel.getActionCommand();
   }


   public void setGroup(ButtonGroup group)
   {
      mButtonModel.setGroup(group);
   }


   public void addActionListener(ActionListener l)
   {
      mButtonModel.addActionListener(l);
   }


   public void removeActionListener(ActionListener l)
   {
      mButtonModel.removeActionListener(l);
   }


   public void addItemListener(ItemListener l)
   {
      mButtonModel.addItemListener(l);
   }


   public void removeItemListener(ItemListener l)
   {
      mButtonModel.removeItemListener(l);
   }


   public void addChangeListener(ChangeListener l)
   {
      mButtonModel.addChangeListener(l);
   }


   public void removeChangeListener(ChangeListener l)
   {
      mButtonModel.removeChangeListener(l);
   }

   
   public Object[] getSelectedObjects()
   {
      return mButtonModel.getSelectedObjects();
   }


   public void release(int flags)
   {
      if ((flags < 0)
         || ((flags & oracle.adf.model.binding.DCDataControl.REL_ALL_REFS) > 0)
         || ((flags & oracle.adf.model.binding.DCDataControl.REL_VIEW_REFS) > 0))
      {

         if (mButtonModel != null)
         {
            mButtonModel.removeActionListener(this);
            mButtonModel = null;
         }
      }

      super.release(flags);
   }

   protected void setupMethodInfo(DCBindingContainer form, DCInvokeMethodDef def)
   {
      super.setupMethodInfo(form, def);
   }

   /**
   * Adds the given listener to this Action Binding's listeners list.    
   */
   public final void addActionBindingListener(JUActionBindingListener l)
   {
      super.addActionBindingListener(l);
   }
   
   /**
   * Removes the given listener from this Action Binding's listeners list.
   */
   public final void removeActionBindingListener(JUActionBindingListener l)
   {
      super.removeActionBindingListener(l);
   }

}
