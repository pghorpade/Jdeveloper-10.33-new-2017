/*
 * @(#)JUDefFactoryImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.adf.model.binding.DCDefBase;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUBindingDefFactoryImpl;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.jui.JUTreeAccessorTypeBinding;
import java.util.HashMap;
import org.w3c.dom.Element;

public class JUDefFactoryImpl extends JUBindingDefFactoryImpl
{
	
   private HashMap mSubTypeMap;

   private void initSubTypeMap()
   {
      if (mSubTypeMap == null) 
      {
         mSubTypeMap = new HashMap(30);

         mSubTypeMap.put(JUTags.PNAME_label,                         DCDefBase.PNAME_Label);
         mSubTypeMap.put(JUTags.PNAME_buttonGroup,                   DCDefBase.PNAME_ButtonGroup);
         mSubTypeMap.put(JUTags.PNAME_formattedTextField,            DCDefBase.PNAME_FormattedTextField);
         mSubTypeMap.put(JUTags.PNAME_list,                          DCDefBase.PNAME_ListSingleSel);
         mSubTypeMap.put(JUTags.PNAME_combobox,                      DCDefBase.PNAME_ComboBox);
         mSubTypeMap.put(JUTags.PNAME_lovButton,                     DCDefBase.PNAME_LovButton);
         mSubTypeMap.put(JUTags.PNAME_progressBarAttr,               DCDefBase.PNAME_ProgressBarAttr);
         mSubTypeMap.put(JUTags.PNAME_progressBar,                   DCDefBase.PNAME_ProgressBar);
         mSubTypeMap.put(JUTags.PNAME_scrollBarAttr,                 DCDefBase.PNAME_ScrollBarAttr);
         mSubTypeMap.put(JUTags.PNAME_scrollBar,                     DCDefBase.PNAME_ScrollBar);
         mSubTypeMap.put(JUTags.PNAME_sliderAttr,                    DCDefBase.PNAME_SliderAttr);
         mSubTypeMap.put(JUTags.PNAME_slider,                        DCDefBase.PNAME_Slider);
         mSubTypeMap.put(JUTags.PNAME_spinner,                       DCDefBase.PNAME_Spinner);
      }
   }
	
   public String getSubTypeForElement(Element element)
   {
      initSubTypeMap();
      String subtypeName = (String)mSubTypeMap.get(element.getLocalName());
      if (subtypeName == null) 
      {
          return super.getSubTypeForElement(element);
      }
      return subtypeName;
   }

   public DCDefBase createDefinition(DefElement element)
   {
      initSubTypeMap();
      String elemName = element.getLocalName();
      String subtype = (String)mSubTypeMap.get(elemName);
      if (subtype == null) 
      {
         return super.createDefinition(element);
      }
      
      DCDefBase ctrlDef= createControlDef(subtype);
      if (elemName.equals(JUTags.PNAME_staticList)) 
      {
         JUCtrlListDef def = (JUCtrlListDef)ctrlDef;
         def.setStaticList(true);
      }
      return ctrlDef;
   }
    
   public DCDefBase createControlDef(String subType)
   {
      DCDefBase ctrlDef = null;
      if (subType.equals(DCDefBase.PNAME_TextField))
      {
         ctrlDef = new JUTextFieldDef();
      }
      else if (subType.equals(DCDefBase.PNAME_Action))
      {
         ctrlDef = new JUActionDef();
      }
      else if (subType.equals(DCDefBase.PNAME_MethodAction))
      {
         ctrlDef = new JUActionDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Label))
      {
         ctrlDef = new JULabelDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Button))
      {
         ctrlDef = new JUButtonDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ComboBox))
      {
         ctrlDef = new JUComboBoxDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ButtonGroup))
      {
         ctrlDef = new JUButtonGroupDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_DefaultControl))
      {
         ctrlDef = new JUDefaultControlDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_FormattedTextField))
      {
        ctrlDef = new JUFormattedTextFieldDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ListSingleSel))
      {
         ctrlDef = new JUListSingleSelDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ScrollBar))
      {
         ctrlDef = new JUScrollBarDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ScrollBarAttr))
      {
         ctrlDef = new JUScrollBarAttrDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Table))
      {
         ctrlDef = new JUTableDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Tree))
      {
         ctrlDef = new JUTreeDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ProgressBar))
      {
         ctrlDef = new JUProgressBarDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ProgressBarAttr))
      {
         ctrlDef = new JUProgressBarAttrDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Slider))
      {
         ctrlDef = new JUSliderDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_SliderAttr))
      {
         ctrlDef = new JUSliderAttrDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Spinner))
      {
        ctrlDef = new JUSpinnerDef();
      }
      else if (subType.equals(DCDefBase.PNAME_Panel))
      {
         ctrlDef = new JUPanelDef();
      }
      else if (subType.equals(DCDefBase.PNAME_LovButton))
      {
         ctrlDef = new JULovButtonDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Graph))
      {
         ctrlDef = new JUSingleTableGraphDef();
      }
      
      else if (subType.equals(JUTags.PNAME_treeNodeDefinition)) 
      {
         ctrlDef = new JUTreeAccessorTypeBinding();
      }
      else
      {
         ctrlDef = super.createControlDef(subType);
      }
      return ctrlDef;
   }
}
