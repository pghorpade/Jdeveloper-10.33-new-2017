/*
 * @(#)JUEnvInfoProvider.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.Hashtable;
import oracle.jbo.common.ampool.EnvInfoProvider;
import oracle.jbo.JboContext;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.ampool.DefaultConnectionStrategy;
import oracle.jbo.uicli.controls.JULoginDlg;

public class JUEnvInfoProvider implements EnvInfoProvider
{
   String mUsername = null; 
   String mPassword = null;

   public Object getInfo(String info, Object environment)
   {
      RuntimeException exc = ((RuntimeException)((Hashtable)environment).get(DefaultConnectionStrategy.LAST_EXCEPTION));

      if (!JboEnvUtil.isAuthenticateUser((Hashtable)environment)) {
          return null;
      }

      String username = (String) ((Hashtable) environment).get(JboContext.SECURITY_PRINCIPAL);
      String password = (String) ((Hashtable) environment).get(JboContext.SECURITY_CREDENTIALS);

      boolean isUsernameEmpty 
         = ((username == null) || (username.length() <= 0));

      boolean isPasswordEmpty 
         = ((password == null) || (password.length() <= 0));

      if (isUsernameEmpty)
      {
         username = mUsername;
         isUsernameEmpty = ((username == null) || (username.length() <= 0));
      }

      if (isPasswordEmpty)
      {
         password = mPassword;
         isPasswordEmpty = ((password == null) || (password.length() <= 0));
      }

      // Only show the login dialog when the request is made for any property
      // and the mUsername and mPassword are not specified.
      if (isUsernameEmpty || isPasswordEmpty || exc != null)
      {
         JULoginDlg dlg = new JULoginDlg();

         dlg.setUserName(username);
         dlg.setPassword(password);

         dlg.setVisible(true);

         if (!dlg.isCancelled())
         {
            mUsername = dlg.getUserName();
            mPassword = dlg.getPassword();

            ((Hashtable) environment).put(JboContext.SECURITY_PRINCIPAL, mUsername);
            ((Hashtable) environment).put(JboContext.SECURITY_CREDENTIALS, mPassword);
         }
      }

      return null;
   }


   public void modifyInitialContext(Object environment)
   {
   }

   public int getNumOfRetries()
   {
      return 2; 
   }
}
