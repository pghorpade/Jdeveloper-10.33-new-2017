/*
 * @(#)JUDefaultControlInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.FocusAdapter;

/**
 * Implemented by "custom" Controls like JUImageControl that bind
 * to BC4J attributes using JUDefaultControlBinding and have no default
 * Swing model to work with. The controls are themselves responsible
 * for updating the binding with their edited/updated data, so that the
 * binding can update the associated Attribute in a BC4J Row.
 * 
 * @see JUDefaultControlBinding
 * @see oracle.jbo.uicli.controls.JUImageControl
 */
public interface JUDefaultControlInterface
{
   /**
   * This method is invoked by the binding to notify the control to 
   * update the display with the new data.
   * @param dataItem Use this data to update the control's display
   */
   void dataChanged(Object dataItem);

   /**
   * This method is invoked by the binding to add a focus listener
   * to the control such that JClient Panelbinding can update its status
   * based on control's focus. 
   */
   void addFocusListener(FocusAdapter e);
}
