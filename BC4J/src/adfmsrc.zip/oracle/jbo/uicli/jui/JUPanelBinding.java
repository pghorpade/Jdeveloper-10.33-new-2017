/*
 * @(#)JUPanelBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.Component;
import java.awt.LayoutManager;
import java.util.ArrayList;
import javax.swing.JPanel;
import oracle.jbo.ApplicationModule;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.JboException;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NoObjException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JUNavigationBar;

import oracle.adf.model.BindingContext;
import oracle.adf.model.layout.DCLayoutConsDef;
import oracle.adf.model.binding.DCBindingContainerReference;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;

import oracle.adf.model.binding.DCDataControl;
/**
 * A container class that manages JUIteratorBindings, etc.
 * by extending the JUFormBinding class. It provides:
 * <ul>
 * <li> Management of JUNavigationBarInterfaces bound to the iterators behind the iterator binding objects.
 * <li> Management of JUIteratorChangedListeners like NavigationBars, StatusBars and Menus.
 * <li> Management of JUPanelValidationListeners that perform attribute, panel and 
 * transaction level validations.
 * <li> Switching of iterators behind iterator-binding objects so that all relevant controls in this
 * form are updated with new data from the new iterator.
 * </ul>
 */
public class JUPanelBinding extends JUFormBinding
{
   protected String mAppName = "";
   String mAMName = null;

   protected ArrayList mIteratorChangedListeners;
   ArrayList mRowSetListeners;
   ArrayList mBindingsWithCellEditor;
   DCControlBinding mBindingInFocus;

   boolean mEditingStopped = true; //only used during stopEdit()

   boolean mRequestRefreshControl = false;
   Runnable mRunLater = null;

   /**
   * *** For internal framework use only ***
   */
   public JUPanelBinding()
   {
   }

   public JUPanelBinding setup(BindingContext ctx, Object panel)
   {
      JUPanelBinding panelBinding = this;
      
      //only invoke setup for toplevel binding containers.
      if (getRegionContainer() == null)
      {
         Object ctxObj = ctx.get(getName());
         if (ctxObj instanceof DCBindingContainerReference)
         {
           panelBinding = (JUPanelBinding)((DCBindingContainerReference)ctxObj).getBindingContainer();
         }
         else if (ctxObj == null)
         {
            if (!JUIUtil.inDesignTime())
            {
               ctx.put(getName(), this);
            }
            else
            {
               panelBinding = JUIUtil.createNewDTPanelBinding(this);
               panelBinding.setup(ctx, panel);
            }
         }
         else if (ctxObj != this)
         {
            panelBinding = (JUPanelBinding)ctxObj;
         }
      }

      //for frame/mdpanel this is set as frame.
      if(panelBinding.getPanel() == null)
      {
         panelBinding.setPanel(panel);
      }

      //direct access to avoid initalizeApplicationModule() in getDataControl()
      if (panelBinding.mDataControl == null)
      {
         panelBinding.useDefaultDataControl(ctx);
      }
      return panelBinding;
   }
   
   /**
   * Applications should use this constructor to create a panel binding and associate it
   * with a swing JPanel object. The binding thus created needs to be added to a JUApplication
   * object and is not completely usable until then.
   */
   public JUPanelBinding(JPanel panel)
   {
      super(panel);
   }

   /**
    * Temporary placeholder panelBinding created by wizard.
    */
   public JUPanelBinding(String name)
   {
      // Do we really need this? DT to decide.
      super(null);
      setName(name);
   }

   /**
   * Creates an instance of this class, associating it with a JPanel object and a JUApplication
   * identified by appName. This constructor is used in the JClient design time generated code
   * to pass in the name of the Application Model definition name that identifies the middle-tier
   * (BC4J) connection and configuration information.
   */
   public JUPanelBinding(String appName, JPanel panel)
   {
      this(appName, null, panel);
   }

   /**
   * Creates an instance of this class, associating it with a JPanel object and a JUApplication
   * identified by appName. This constructor is used in the JClient design time generated code
   * to pass in the name of the Application Model definition name that identifies the middle-tier
   * (BC4J) connection and configuration information. This constructor also takes in the application
   * module name in case the BC4J application module for this panel is a nested application module.
   */
   public JUPanelBinding(String appName, String amName, JPanel panel)
   {
      super(panel);
      mAppName = appName;
      mAMName = amName;
   }

   /**
   * *** For internal framework use only ***
   * Sets the ApplicationModule reference
   */
   public void setApplication(JUApplication app)
   {
      super.setApplication(app);

      if (app != null)
      {
          app.setClientApp(BindingContext.CLIENT_TYPE_JCLIENT);
      }
   }


   /**
   * Sets up the JUApplication and Application Module references based on name passed to 
   * this object via the constructors or various setter methods.
   */
   protected void initializeApplicationModule()
   {
      if (mDataProvider == null) 
      {
         
         ApplicationModule am = null;

         if(mDataControl == null)
         {
            ArrayList al = getIterBindingList();
            if (al.size() > 0)
            {
               DCIteratorBinding iter;
               for (int i = 0; i < al.size(); i++)
               {
                  iter = (DCIteratorBinding)al.get(i);
                  //am = iter.getDataControl().getApplicationModule();
                  //if (am != null)
                  {
                     //assume the first data control as mine!
                     setDataControl(iter.getDataControl());
                     if(mDataControl != null)
                     {
                        break;
                     }
                  }
               }
            }
         }
         
         DCDataControl juApp = mDataControl;

         if (juApp == null && getBindingContext() != null)
         {
            juApp = getBindingContext().getDefaultDataControl();
         }

         if (juApp == null)
         {
            if (JboEnvUtil.isEmptyString(mAppName))
            {
               throw new InvalidObjNameException(JUMetaObjectBase.TYP_APPLICATION, mAppName);
            }
         
            juApp = JUMetaObjectManager.findApplicationObject(mAppName);
            if (juApp == null)
            {
               throw new NoObjException(JUMetaObjectBase.TYP_APPLICATION, mAppName);
            }

            setDataControl(juApp);
            if (!juApp.isJClientApp())
            {
               juApp.setClientApp(DCDataControl.JCLIENT);
            }
            juApp.addBindingContainer(this);
         }
         
         am = juApp.getApplicationModule();
         if (!JboEnvUtil.isEmptyString(mAMName))
         {
            am = am.findApplicationModule(mAMName);
            if (am == null)
            {
               throw new NoObjException(NoObjException.TYP_APP_MODULE, mAMName);
            }
         }

         setApplicationModule(am);
      }
      else if (mDataControl == null) 
      {
         setDataControl(new oracle.jbo.uicli.binding.JUApplication(mDataProvider));
         mDataControl.setClientApp(DCDataControl.JCLIENT);
      }
   }

   /**
   * *** For internal framework use only ***
   */
   public void initializePanel(ArrayList controls)
   {
      JPanel jPanel = (JPanel) getPanel();
      if(jPanel != null)
      {
         LayoutManager layout = (LayoutManager) getDef().getLayoutDef().createLayout();

         jPanel.setLayout(layout);

         for (int j = 0; j < controls.size(); j++)
         {
            JUControlBinding controlBnd = (JUControlBinding) controls.get(j);
            Object layoutObj = controlBnd.getLayoutObject();
            DCLayoutConsDef layoutConsDef = controlBnd.getDef().getLayoutCons();
            Object layoutCons = null;

            if (layoutConsDef != null)
            {
               layoutCons = layoutConsDef.createLayoutCons();
            }

            controlBnd.addControlToPanel(jPanel, layoutObj, layoutCons);
         }
      }
   }

   /**
   * Binds the iterator identified by iterBindingName in this panel with another ViewObject
   * in the current application module identified by the given voInstanceName.
   */
   public void bindRowSetIterator(String iterBindingName, String voInstanceName)
   {
      //do we need another flavor that binds a rowset name as well?
      bindRowSetIterator(iterBindingName, getApplicationModule().findViewObject(voInstanceName));
   }

   /**
   * Binds the iterator identified by iterBindingName in this panel with another iterator.
   * This method notifies all JUIteratorChangeListeners in this panel of the change
   * so that various NavigationBars, Menus, and Status bars can adjust their displays.
   * Applications could register their own JUIteratorChangeListeners so that they 
   * get notified of data changes resulting from a change in iterator, thus allowing them to update
   * the displays (like change button enabled state).
   */
   public void bindRowSetIterator(String iterBindingName, RowSetIterator rsi)
   {
      JUIteratorBinding iterBnd = findIterBinding(iterBindingName);
      if (iterBnd == null) 
      {
         reportException(new JboException(UIMessageBundle.class, 
                                          UIMessageBundle.EXC_INVALID_ITER_BINDING_NAME, 
                                          new String[] {iterBindingName}));  

      }
      else
      {
         //force the rangeSize from the binding on this iterator, so that
         //grid/other-controls display proper number of rows instead of
         //whatever the setting is on the rsi itself.
         iterBnd.bindRowSetIterator(rsi, true);
         notifyIteratorChanged(iterBnd, true);
      }
   }  

   /**
   * *** For internal framework use only ***
   * <p>
   * Notifies all JUIteratorChangedListeners and JUNavigationBarInterface objects registered
   * with this panel of the change in iterator binding. If refresh parameter is true,
   * like when there is a change in the iterator behind the iterator binding instance or a
   * change in data/find mode of the panel, then this method raises a rangeRefreshed event
   * on the iteratorBinding object so that all controls also adjust/udpate their displays.
   * <p>
   * Called internally by the framework also when an iterator that was bound is no more
   * bound due to some button action. In this case iterBnd is null so that all navbars
   * can disable themselves.
   */
   public final void notifyIteratorChanged(DCIteratorBinding iterBnd, boolean refresh)
   {
      //force an event so that all controls are tickled to 
      //redisplay their data.
      ArrayList al;
      if (iterBnd != null)
      {
         if (refresh) 
         {
            iterBnd.rangeRefreshed(null);
         }

         al = mIteratorChangedListeners;

         NavigatableRowIterator rsi = iterBnd.getNavigatableRowIterator();
         String rsiBindingName = iterBnd.getName();
         if (al != null)
         {
            JUIteratorChangedListener l;
            for (int i = 0; i < al.size(); i++) 
            {
               l = ((JUIteratorChangedListener)al.get(i));
               l.iteratorChanged(rsiBindingName, rsi);
            }
         }
      }

      //notify navigationbar of the iterator change.
      al = mNavigationBarList;
      if (al != null)
      {
         oracle.jbo.uicli.binding.JUNavigationBarInterface l;
         for (int i = 0; i < al.size(); i++) 
         {
            l = ((oracle.jbo.uicli.binding.JUNavigationBarInterface)al.get(i));
            l.iteratorBindingChanged((JUIteratorBinding)iterBnd);
         }
      }
   }

   /**
   * Adds a listener that should be notified when the iterator behind an iterator
   * binding object changes or the display mode changes from find to data mode or
   * the reverse.
   */
   public final void addIteratorChangedListener(JUIteratorChangedListener l)
   {
      if (mIteratorChangedListeners == null) 
      {
         mIteratorChangedListeners = new ArrayList(5);
      }
      mIteratorChangedListeners.add(l);
   }

   /**
   * Remove a listener from this list.
   */
   public final void removeIteratorChangedListener(JUIteratorChangedListener l)
   {
      if (mIteratorChangedListeners != null) 
      {
         mIteratorChangedListeners.remove(l);
      }
   }


   /**
   * Notifies the JUApplication object of focusGained event so that it could pass it on to
   * its StatusBarInterface listeners (like JUStatusBar to update status message).
   * Then this method notifies each JUNavigationBarInterface object in this object's list of
   * the change in focus, so that the NavigationBars can adjust their display based on 
   * the current iterator binding.
   */
   public void focusGained(DCIteratorBinding iterBinding, DCControlBinding binding, int attrIndex)
   {
      //pass this on to navigation bar, status bar.
      if (mDataControl != null)
      {
         //once JClient App takes over the control of creating PanelBindings,
         //this if check should go away.
         mDataControl.focusGained(iterBinding, binding, attrIndex); 
      }

      if (mNavigationBarList != null)
      {
         JUIteratorBinding currentIter = null;
         ArrayList al = getIterBindingList();
         int size = al.size();
         if (size > 0 && iterBinding instanceof JUIteratorBinding)
         {
            //this could be optimized by keeping track of current iterator.
            al = mNavigationBarList;
            for (int i = 0; i < al.size(); i++) 
            {
               ((oracle.jbo.uicli.binding.JUNavigationBarInterface)al.get(i)).iteratorBindingChanged((JUIteratorBinding)iterBinding);
            }
         }
         /*
         else if (!mNavBarInit && size > 0) 
         {
            mNavBarInit = true;
            currentIter = (JUIteratorBinding)al.get(0);
         }
         if (currentIter != null) 
         {
            al = mNavigationBarList;
            for (int i = 0; i < al.size(); i++) 
            {
               ((JUNavigationBarInterface)al.get(i)).iteratorBindingChanged(currentIter);
            }
         }
         */
      }
      mBindingInFocus = binding;
   }

   /**
   * Returns the name of the JUApplication object in which this Panel binding was created.
   */
   public final String getApplicationName()
   {
      return mAppName;
   }

   /**
   * Returns the Application Module instance name to which this Panel binding is connected.
   */
   public final String getAppModuleName()
   {
      return mAMName;
   }

   /**
   * Returns true, if the Transaction behind the associated ApplicationModule has pending changes
   * In three-tier, this method will go across the tier boundary to get the actual middle-tier transaction
   * status.
   */
   public final boolean isTransactionDirty()
   {
      if (mDataControl != null)
      {
         return getDataControl().isTransactionDirty();
      }
      else
      {
         try
         {
            return getDataControl().isTransactionDirty();
         }
         catch (oracle.jbo.InvalidObjNameException ione)
         {
            //ignore. no datacontrol created in this panel binding. return false
         }
      }
      return false;
   }

   /**
   * Sets the given object as the JPanel object associated with this panel binding.
   */
   public final void setPanel(Object panel)
   {
      super.setPanelInternal(panel);
   }

   /**
   * Returns a list of JUPanelRowSetListeners (returns an empty list if no such listener was registered).
   */
   public final ArrayList getRowSetListeners()
   {
      return (mRowSetListeners != null) ? (ArrayList)mRowSetListeners.clone() : new ArrayList(0);
   }
   
   /**
   * Adds the given listener to this panel's RowSet listeners list.
   */
   public final void addRowSetListener(JUPanelRowSetListener l)
   {
      if (mRowSetListeners == null) 
      {
         mRowSetListeners = new ArrayList(4);
      }
      if (!mRowSetListeners.contains(l)) 
      {
         mRowSetListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this panel's RowSet listeners list.
   */
   public final void removeRowSetListener(JUPanelRowSetListener l)
   {
      if (mRowSetListeners != null) 
      {
         mRowSetListeners.remove(l);
      }
   }

   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeRowNavigated() method to notify all validation listeners.
   */
   public void callBeforeRowNavigated(DCIteratorBinding iter)
   {
      stopEditing();
      super.callBeforeRowNavigated(iter);
   }
   
   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeSaveTransaction() method to notify all validation listeners.
   */
   public void callBeforeSaveTransaction(DCDataControl dc)
   {
      stopEditing();
      super.callBeforeSaveTransaction(dc);
   }

   /**
    * Available for backward compatiblity only.
    * @deprecated since 9.0.5, Use callBeforeSaveTransaction(DCDataControl)
   */
   public void callBeforeSaveTransaction(oracle.jbo.Transaction txn)
   {
   }

   /**
    * Invoked when a JUIteratorBinding receives a rangeRefreshed Event from BC4J RowSetIterator
    * @param iter that received the rangeRefreshed event.
    * @param event a description of the new ranges.
    */
   protected void rangeRefreshed(DCIteratorBinding iter, RangeRefreshEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rangeRefreshed((JUIteratorBinding)iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rangeScrolled Event from BC4J RowSetIterator
    * @param iter that received the rangeScrolled event.
    * @param event a description of the new range.
    */
   protected void rangeScrolled(DCIteratorBinding iter, ScrollEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rangeScrolled((JUIteratorBinding)iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowInserted Event from BC4J RowSetIterator
    * @param iter that received the rowInserted event.
    * @param event a description of the new Row object.
    */
   protected void rowInserted(DCIteratorBinding iter, InsertEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowInserted((JUIteratorBinding)iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowDeleted Event from BC4J RowSetIterator
    * @param iter that received the rowDeleted event.
    * @param event a description of the deleted Row object.
    */
   protected void rowDeleted(DCIteratorBinding iter, DeleteEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowDeleted((JUIteratorBinding)iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a rowUpdated Event from BC4J RowSetIterator
    * @param iter that received the rowUpdated event.
    * @param event a description of the modified Row object.
    */
   protected void rowUpdated(DCIteratorBinding iter, UpdateEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).rowUpdated((JUIteratorBinding)iter, event);
         }
      }
   }

   /**
    * Invoked when a JUIteratorBinding receives a navigated Event from BC4J RowSetIterator
    * @param iter that received the navigated event.
    * @param event a description of the new and previous current rows.
    */
   protected void navigated(DCIteratorBinding iter, NavigationEvent event)
   {
      if (mRowSetListeners != null) 
      {
         ArrayList al = (ArrayList)mRowSetListeners.clone();
         int count = al.size();
         for (int i = 0; i < count; i++) 
         {
            ((JUPanelRowSetListener)al.get(i)).navigated((JUIteratorBinding)iter, event);
         }
      }
   }

   
   /**
   * Sets this panel and all its associated iterators into find mode.
   */
   public void setFindMode(boolean mode)
   {
      stopEditing();
      super.setFindMode(mode);
   }
   
   
   /**
   * Adds a listener that is interested in notification such that it stops its control's edit process
   * before the panel is moved to a different set of data.
   */
   public void addBindingWithCellEditor(JUPanelStopEditingListener binding)
   {
      if (mBindingsWithCellEditor == null) 
      {
         mBindingsWithCellEditor = new ArrayList(6);
      }
      if (!mBindingsWithCellEditor.contains(binding))
      {
         mBindingsWithCellEditor.add(binding);
      }
   }
   
   
   /**
   * Removes a listener from the list.
   */
   public void removeBindingWithCellEditor(JUPanelStopEditingListener binding)
   {
      if (mBindingsWithCellEditor != null) 
      {
         mBindingsWithCellEditor.remove(binding);
      }
   }
   
   /**
   * Notifies all JUPanelStopEditingListeners to stop editing, so that their values
   * can be updated with new set of data. This method is invoked before changing
   * the find/data mode, or switching iterators behind an iterator binding, or
   * before committing/rolling back the database transaction.
   */
   public void stopEditing()
   {

      //component bindings may set this flag false to indicate that stopEdit
      //failed.
      mEditingStopped = true;
      
      if (mBindingsWithCellEditor != null) 
      {
         ArrayList bndList = mBindingsWithCellEditor;
         int size = bndList.size();
         for (int j = 0; j < bndList.size(); j++)
         {
            JUPanelStopEditingListener bnd = (JUPanelStopEditingListener) bndList.get(j);
            bnd.stopEditing();
         }
      }
      if (mBindingInFocus != null && mBindingInFocus.getControl() != null)
      {
         Component comp = (Component)mBindingInFocus.getControl();
         {
            FocusListener[] l = comp.getFocusListeners();
            if (l != null)
            {
               for (int i = 0; i < l.length; i++)
               {
                  if (l[i] instanceof JUSVUpdateableFocusAdapter)
                  {
                     oracle.jbo.common.Diagnostic.println("Force tranfer of focus for applying last focused control changes!");
                     FocusEvent ev = new FocusEvent(comp, FocusEvent.FOCUS_LOST);
                     ((JUSVUpdateableFocusAdapter)l[i]).focusLost(ev);
                  }
               }
            }
         }
      }
   }

   public boolean isEditingStopped()
   {
      return mEditingStopped;
   }

   /**
    * Component/control bindings should set this flag false to indicate
    * that stopEditing() call on them failed. This flag is reset on the
    * beginning of panelBinding's stopEditing method.
    */
   public void setEditingStopped(boolean flag)
   {
      mEditingStopped = flag;
   }

   /**
    * Used by generated code to bind a ui control to the defined binding object
    * in this container identified by 'controlBindingName'. The return value
    * is a Swing model object for that given control.
    * @return controlbinding.getControlModel(Object control) from the controlBinding object
    */
   public Object bindUIControl(String controlBindingName, Object control)
   {
      return findCtrlBinding(controlBindingName).getControlModel(control);
   }
   
   public JUPanelBinding findNestedPanelBinding(String name)
   {
      return (JUPanelBinding)findRegionBinding(name);
   }

   public void releaseDataControl()
   {
      if (mDataControl != null)
      {
         mDataControl.release();
      }
   }

   /**
    * Applications should release the DataControl which
    * will end up calling this method for all binding 
    * containers in the datacontrol.
    * 
    * @param flags could be one of the enumerations in DCDataControl. See DCDataControl.release()
    **/
   public void release(int flags)
   {
      if (flags != DCDataControl.REL_DATA_REFS)
      {
         if (mNavigationBarList != null)
         {
            ArrayList al = (ArrayList)mNavigationBarList.clone();
            Object nav;
            for (int i = 0; i < al.size(); i++) 
            {
               nav = al.get(i);
               if (nav instanceof JUNavigationBar) 
               {
                  ((JUNavigationBar)nav).release();
               }
            }
         }
         mNavigationBarList = null;
         mIteratorChangedListeners = null;
         mRowSetListeners = null;
         mBindingsWithCellEditor = null;
         mBindingInFocus = null;
         mRequestRefreshControl = false;
         mRunLater = null;
      }
      super.release(flags);
   }

   protected void useDefaultDataControl(BindingContext ctx)
   {
      ArrayList al = getIterBindingList();
      if (al!= null)
      {
         DCIteratorBinding iter;
         for (int i = 0; i < al.size(); i++)
         {
            iter = (DCIteratorBinding)al.get(i);
            if (iter.getDataControl() != null)
            {
               setDataControl(iter.getDataControl());
               break;
            }
         }
      }
      if (mDataControl == null)
      {
         setDataControl(ctx.getDefaultDataControl());
      }
   }

   /**
    * Called by bindings that may have changed model properties
    * and need a refresh of the model/whole bindingContainer.
    * Useful in batchmode where after a panel is layed out and
    * it's data is fetched, it may determine that several components
    * need more rows/less rows, change rangesize etc. If so, 
    * the components may request refreshControl and then
    * controller may call refreshControl again.
    */
   public void requestRefreshControl()
   {
      if (!mRequestRefreshControl)
      {
         if (mRunLater == null)
         {
            mRunLater = new Runnable()
            {
               public void run() 
               {
                  refreshControl();
                  mRequestRefreshControl = false;
               }
            };
         }
         mRequestRefreshControl = true;
         javax.swing.SwingUtilities.invokeLater(mRunLater);
      }
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String attrName, LocaleContext locale)
   {
      if (JUIUtil.inDesignTime())
      {
          return attrName;
      }
      else
      {
          return super.getTooltip(voName, attrName, locale);
      }
   }


   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
      if (JUIUtil.inDesignTime())
      {
         return objectAttrName;
      }
      else
      {
         return super.getTooltip(voName, voAttrName, objectAttrName, locale);
      }

   }

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String attrName, LocaleContext locale)
   {
      if (JUIUtil.inDesignTime())
      {
         return attrName;
      }
      else
      {
         return super.getLabel(voName, attrName, locale);
      }

   }

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
       if (JUIUtil.inDesignTime())
      {
         return objectAttrName;
      }
      else
      {
         return super.getLabel(voName, voAttrName, objectAttrName, locale);
      }
   }

}
