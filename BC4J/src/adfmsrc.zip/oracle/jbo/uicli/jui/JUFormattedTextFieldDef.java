/*
 * @(#)JUFormattedTextFieldDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import java.text.SimpleDateFormat;

import javax.swing.JFormattedTextField;
import javax.swing.text.DateFormatter;
import javax.swing.text.NumberFormatter;
import javax.swing.text.MaskFormatter;
import javax.swing.text.DefaultFormatter;


import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUCtrlAttrsDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.mom.xml.DefElement;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCDefBase;
import java.text.NumberFormat;
import java.text.DecimalFormat;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class JUFormattedTextFieldDef extends JUCtrlAttrsDef
{
   public final static String PNAME_ActiveFormatter = "ActiveFormatter";

   public final static int DATE_FORMATTER= 0;

   public final static int MASK_FORMATTER= 1;
   
   public final static int DEFAULT_FORMATTER= 2;
   
   public final static int NUMBER_FORMATTER= 3;

   public final static int REGEXP_FORMATTER= 4; 

   DateFormatDef mDateFormatDef = new DateFormatDef();

   MaskFormatDef mMaskFormatDef = new MaskFormatDef();
   
   NumberFormatDef mNumberFormatDef = new NumberFormatDef();
    
   RegExpFormatDef mRegExpFormatDef = new RegExpFormatDef();
    
   int mActiveFormatter = MASK_FORMATTER;
   
   public JUFormattedTextFieldDef()
   {
      setControlBindingClassName(JUFormattedTextFieldBinding.class.getName());

	  //setControlClassName(JFormattedTextField.class.getName());
   }


   public JUFormattedTextFieldDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? 
                controlBindingClassName : JUFormattedTextFieldBinding.class.getName(),
            iterBindingName, attrNames);
   }

   public JUFormattedTextFieldDef(String name, String iterBindingName, String[] attrNames)
   {
      this(name, JUFormattedTextFieldDef.class.getName(), null, iterBindingName, attrNames);
   }
   
   public int getActiveFormatter()
   {
        return mActiveFormatter;
   }

   protected void initSubType()
   {
      setSubType(PNAME_FormattedTextField);
   }

   public DateFormatDef getDateFormatDef()
   {
       return mDateFormatDef;
   }

   public MaskFormatDef getMaskFormatDef()
   {
       return mMaskFormatDef;
   }
   
   public NumberFormatDef getNumberFormatDef()
   {
       return(mNumberFormatDef);
   }
    
   public RegExpFormatDef getRegExpFormatDef()
   {
       return(mRegExpFormatDef);
   }
    
   public Object createControl()
   {
      JFormattedTextField jTxtFld = (JFormattedTextField) super.createControl();

      if (jTxtFld != null)
      {
        Object initValue = getInitialValue();
  
        if (initValue != null)
        {
           jTxtFld.setText(initValue.toString());
        }
      }
      return jTxtFld;
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
    
      Object val;

      if ((val = initValues.get(PNAME_ActiveFormatter)) != null)
      {
          mActiveFormatter = ((Integer)val).intValue();
      }
   }

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
       super.retrieveFromXML(xmlElement, valueTab);

       readXMLInt(xmlElement, PNAME_ActiveFormatter, valueTab);
   }
   
   protected DCControlBinding createControlBindingInstance(Object control, 
                                                           DCBindingContainer formBnd)
   {
      JFormattedTextField ftf = (JFormattedTextField) control;

      JUIteratorBinding iterBind = getIterBinding((JUFormBinding)formBnd);

      String attrname  = getFirstAttrName();
     
      JUControlBinding bind = null;

      switch (getActiveFormatter())
      {
      case DATE_FORMATTER:
      {
          SimpleDateFormat sdf = new SimpleDateFormat();
          
          DateFormatDef dfd = getDateFormatDef();
          
          if (dfd.getFormatString() != null && ! (dfd.getFormatString().equals("")))
          {
              sdf.applyPattern(dfd.getFormatString());
          }
          
          bind = new JUFormattedTextFieldBinding(ftf, iterBind, new DateFormatter(sdf), attrname);
      }
      break;

      case MASK_FORMATTER:
      {
          MaskFormatter mf = new MaskFormatter();
          
          MaskFormatDef mfd = getMaskFormatDef();
          
          // For empty string as FormatString use DefaultFormatter.
          
          try
          {
              mf.setMask(mfd.getFormatString());
          }
          catch(java.text.ParseException pex)
          {
              formBnd.reportException(pex);
          }

          bind = new JUFormattedTextFieldBinding(ftf, iterBind, mf, attrname);
      }
      break;

      case NUMBER_FORMATTER:
      {
          NumberFormatDef nfd = getNumberFormatDef();
          
          NumberFormat nf = null;
          
          try
          {
              String formatString = nfd.getFormatString();
              nf = new DecimalFormat(formatString==null? "":formatString);
          }
          catch (Exception e)
          {
              formBnd.reportException(e);
          }
          bind = new JUFormattedTextFieldBinding(ftf, iterBind, new javax.swing.text.DefaultFormatterFactory(new NumberFormatter(nf)),
                                                 attrname, new NumericConvertor());
      }    
      break;
          
      case DEFAULT_FORMATTER :
      {
          DefaultFormatter df= new DefaultFormatter();
          bind = new JUFormattedTextFieldBinding(ftf, iterBind,df, attrname);
          break;		
      }

      
      case REGEXP_FORMATTER :
      {
          RegExpFormatter rf = new RegExpFormatter();
          
          RegExpFormatDef mfd = getRegExpFormatDef();

          String patternStr = mfd.getPattern();
          int regExpFlag = mfd.getFlag();
          
          try
          {
              Pattern pattern = null;
              
              if (regExpFlag != 0)
              {
                  pattern = Pattern.compile(patternStr, regExpFlag);
              }
              else 
              {
                  pattern = Pattern.compile(patternStr);
              }
              
              rf.setPattern(pattern);
          }
          catch(java.util.regex.PatternSyntaxException pex)
          {
              formBnd.reportException(pex);
          }

          bind = new JUFormattedTextFieldBinding(ftf, iterBind, rf, attrname);
      }
      
      }
          
      bind.setName(getName());

      return bind;
   }


   
   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);

      loadDateFormatDef(xmlElement);

      loadMaskFormatDef(xmlElement);
	  
      loadNumberFormatDef(xmlElement);

      loadRegExpFormatDef(xmlElement);
   }

   void loadNumberFormatDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList numberDefs = 
            xmlElement.getChildrenList(NumberFormatDef.ELEMENT_NAME);

      if (numberDefs.size() > 0)
      {
         DefElement dateDefXML = (DefElement) numberDefs.get(0);

   	 	 mNumberFormatDef = new NumberFormatDef();

         mNumberFormatDef.loadFromXML(dateDefXML);
      }
   }
   
   void loadDateFormatDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList dateDefs = 
            xmlElement.getChildrenList(DateFormatDef.ELEMENT_NAME);

      if (dateDefs.size() > 0)
      {
         DefElement dateDefXML = (DefElement) dateDefs.get(0);

		 mDateFormatDef = new DateFormatDef();

         mDateFormatDef.loadFromXML(dateDefXML);
      }
   }

   void loadMaskFormatDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList maskDefs = 
            xmlElement.getChildrenList(MaskFormatDef.ELEMENT_NAME);

      if (maskDefs.size() > 0)
      {
         DefElement maskDefXML = (DefElement) maskDefs.get(0);

         mMaskFormatDef = new MaskFormatDef();

		 mMaskFormatDef.loadFromXML(maskDefXML);
      }
   }

   void loadRegExpFormatDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList regExpDefs = 
            xmlElement.getChildrenList(RegExpFormatDef.ELEMENT_NAME);

      if (regExpDefs.size() > 0)
      {
         DefElement regExpDefXML = (DefElement) regExpDefs.get(0);

         mRegExpFormatDef = new RegExpFormatDef();

         mRegExpFormatDef.loadFromXML(regExpDefXML);
      }
   }
    

   public static class DateFormatDef extends DCDefBase
   {
       String mFormatString;

       public static final String PNAME_FormatString = "FormatString";

       public static final String ELEMENT_NAME = "DateFormatDef";

       public DateFormatDef()
       {
       }

       public String getFormatString()
       {
           return mFormatString;
       }

       public void setFormatString(String fmtString)
       {
           mFormatString = fmtString;
       }

       public void init(HashMap initValues)
       {
          super.init(initValues);
        
          Object val;
        
          if ((val = initValues.get(PNAME_FormatString)) != null)
          {
              mFormatString = val.toString();
          }
       }
       
       public String getXMLElementTag()
       {
           return ELEMENT_NAME;
       }

       protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
       {
           super.retrieveFromXML(xmlElement, valueTab);
            
           readXMLString(xmlElement, PNAME_FormatString, valueTab);

           readXMLInt(xmlElement, PNAME_ActiveFormatter, valueTab);
       }
   }
    
   public static class NumberFormatDef extends DCDefBase
   {
   	   public static final String PNAME_FormatString = "FormatString"; // NOTRANS

       public static final String ELEMENT_NAME = "NumberFormatDef"; // NOTRANS
   	    
       String mFormatString;
   	
       public String getFormatString()
   	   {
   	      return mFormatString;
   	   }

       public void setFormatString(String fmtString)
       {
           mFormatString = fmtString;
       }
   	
       public void init(HashMap initValues)
   	   {
   	       super.init(initValues);

   	       Object val;
   
       	   if ((val = initValues.get(PNAME_FormatString)) != null)
       	   {
       	      mFormatString = val.toString();
       	   }
   	   }

   	public String getXMLElementTag()
   	{
   	    return ELEMENT_NAME;
   	}

   	protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   	{
   	    super.retrieveFromXML(xmlElement, valueTab);
   	     
   	    readXMLString(xmlElement, PNAME_FormatString, valueTab);
   	}
   
   }

   public static class MaskFormatDef extends DCDefBase
   {
       String mFormatString;

       boolean mUSPhoneNumberSelected;

       boolean mSocSecurityNumberSelected;

       public static final String PNAME_FormatString = "FormatString";

       public static final String PNAME_USPhoneNumberSelected  = "USPhoneNumberSelected";
       
       public static final String PNAME_SocSecNumberSelected  = "SocSecNumberSelected";

       public static final String ELEMENT_NAME = "MaskFormatDef";

       public MaskFormatDef()
       {

       }

       public String getFormatString()
       {
           return mFormatString;
       }
       
       public void setFormatString(String fmtString)
       {
           mFormatString = fmtString;
       }

       public boolean isSocSecurityNumberSelected()
       {
           return mSocSecurityNumberSelected;
       }

       public void setSocSecurityNumberSelected(boolean b)
       {
           mSocSecurityNumberSelected = b;
       }

       public boolean isUSPhoneNumberSelected()
       {
           return mUSPhoneNumberSelected;
       }

       public void setUSPhoneNumberSelected(boolean b)
       {
           mUSPhoneNumberSelected=b;
       }
       
       public boolean isCustomFormatStringSelected()
       {
          boolean b = !mUSPhoneNumberSelected && ! mSocSecurityNumberSelected;

          return b;
       }

       public void init(HashMap initValues)
       {
          super.init(initValues);

          Object val;
      
          if ((val = initValues.get(PNAME_FormatString)) != null)
          {
             mFormatString = val.toString();
          }

          if ((val = initValues.get(PNAME_USPhoneNumberSelected)) != null)
          {
             mUSPhoneNumberSelected = convertToBoolean(val.toString());
          }

          if ((val = initValues.get(PNAME_SocSecNumberSelected)) != null)
          {
             mSocSecurityNumberSelected = convertToBoolean(val.toString());
          }
       }

       public String getXMLElementTag()
       {
           return ELEMENT_NAME;
       }

       protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
       {
           super.retrieveFromXML(xmlElement, valueTab);
            
           readXMLString(xmlElement, PNAME_FormatString, valueTab);

           readXMLString(xmlElement, PNAME_USPhoneNumberSelected, valueTab);

           readXMLString(xmlElement, PNAME_SocSecNumberSelected, valueTab);
       }

   }

   public static class RegExpFormatDef extends DCDefBase
   {
       public static final String PNAME_Pattern = "Pattern"; // NOTRANS
       public static final String PNAME_Flag = "Flag"; // NOTRANS

       public static final String ELEMENT_NAME = "RegExpFormatDef"; // NOTRANS
   	    
       String mPattern;
       int mFlag;
   	
       public String getPattern()
       {
           return mPattern;
       }

       public void setPattern(String pattern)
       {
           mPattern = pattern;
       }

       public int getFlag()
       {
           return mFlag;
       }

       public void setFlag(int flag)
       {
           mFlag = flag;
       }

       public void init(HashMap initValues)
       {
           super.init(initValues);

           Object val;
   
       	   if ((val = initValues.get(PNAME_Pattern)) != null)
       	   {
       	      mPattern = val.toString();
       	   }

           if ((val = initValues.get(PNAME_Flag)) != null)
           {
               mFlag = ((Integer)val).intValue();
           }
       }

       public String getXMLElementTag()
       {
           return ELEMENT_NAME;
       }

       protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
       {
           super.retrieveFromXML(xmlElement, valueTab);
           
           readXMLString(xmlElement, PNAME_Pattern, valueTab);

           readXMLInt(xmlElement, PNAME_Flag, valueTab);
       }
   }
   
}
