/*
 * @(#)JUActionBindingListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;
import oracle.jbo.uicli.binding.JUCtrlActionBindingListener;

/**
 * Implemented by classes that are interested in performing 
 * typically lightweight, client-side preparation of data or update of 
 * display before or after an action binding performs it's action.
 */
public interface JUActionBindingListener  extends JUCtrlActionBindingListener
{
   /**
    * Notifies all listeners, so that they may prepare any necessary data
    * for the current action, before the action is performed
    */
   void beforeActionPerformed(JUActionBindingEvent ev);

   /**
    * Notifies all listeners, so that they may implement necessary updates
    * and invalidations on the UI side as a reaction to a performed action.
    */
   void afterActionPerformed(JUActionBindingEvent ev);
}

