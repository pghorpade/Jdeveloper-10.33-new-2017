/*
 * @(#)JUActionBindingAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.jbo.uicli.binding.JUCtrlActionBindingEvent;
import oracle.jbo.uicli.binding.JUCtrlActionBindingAdapter;

/**
 * Default adapter for JUActionBindingListener event.
 */
public class JUActionBindingAdapter extends JUCtrlActionBindingAdapter implements JUActionBindingListener
{
   public void beforeActionPerformed(JUActionBindingEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeActionPerformed :" + ev.getActionBinding().getName());
   }

   public void afterActionPerformed(JUActionBindingEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("afterActionPerformed :" + ev.getActionBinding().getName());
   }

   public void beforeActionPerformed(JUCtrlActionBindingEvent ev)
   {
      if (ev instanceof JUActionBindingEvent) 
      {
         beforeActionPerformed((JUActionBindingEvent)ev);
      }
      else
      {
         oracle.jbo.common.DebugDiagnostic.println("beforeActionPerformed :" + ev.getBinding().getName());
      }
   }

   public void afterActionPerformed(JUCtrlActionBindingEvent ev)
   {
      if (ev instanceof JUActionBindingEvent) 
      {
         afterActionPerformed((JUActionBindingEvent)ev);
      }
      else
      {
         oracle.jbo.common.DebugDiagnostic.println("afterActionPerformed :" + ev.getBinding().getName());
      }
   }
}
