/*
 * @(#)JULoginDialog.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Frame;

/**
 * A sample implemenation of log in dialog in the JClient framework.
 * @deprecated since 9.0.3 use oracle.jbo.uicli.controls.JULoginDialog instead.
 * @see oracle.jbo.uicli.controls.JULoginDlg
 */
public class JULoginDialog extends oracle.jbo.uicli.controls.JULoginDlg
{
   /**
   * @deprecated since 9.0.3 use oracle.jbo.uicli.controls.JULoginDialog instead.
   * @see oracle.jbo.uicli.controls.JULoginDlg
   */
   public JULoginDialog()
   {
      super();
   }


   /**
   * @deprecated since 9.0.3 use oracle.jbo.uicli.controls.JULoginDialog instead.
   * @see oracle.jbo.uicli.controls.JULoginDlg
   */
   public JULoginDialog(Frame parent, String title, boolean modal)
   {
      super(parent, title, modal);
   }
}
