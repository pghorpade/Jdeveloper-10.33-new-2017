/*
 * @(#)JULabelDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.JLabel;
import oracle.jbo.uicli.binding.JUCtrlAttrsDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JULabelDef extends JUCtrlAttrsDef
{
   public JULabelDef()
   {
      setControlBindingClassName(JULabelBinding.class.getName());
   }


   public JULabelDef(String name, String controlClassName,
                     String controlBindingClassName, String iterBindingName,
                     String[] attrNames)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JULabelBinding.class.getName(),
            iterBindingName, attrNames);
   }


   public JULabelDef(String name, String iterBindingName, String[] attrNames)
   {
      this(name, JLabel.class.getName(), null, iterBindingName, attrNames);
   }

   
   protected void initSubType()
   {
      setSubType(PNAME_Label);
   }

   public Object createControl()
   {
      JLabel jLabel = (JLabel) super.createControl();
      Object initValue = getInitialValue();

      if (initValue != null && jLabel != null)
      {
         jLabel.setText(getInitialValue().toString());
      }

      return jLabel;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      return new JULabelBinding((JLabel)control, 
                                    (getIterBindingName() != null)
                                       ? this.getIterBinding((JUFormBinding)formBnd)
                                       : null, 
                                    getFirstAttrName());

   }
}
