/*
 * @(#)JUTextFieldDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.JTextField;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUCtrlAttrsDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JUTextFieldDef extends JUCtrlAttrsDef
{
   public JUTextFieldDef()
   {
      //setControlClassName(JTextField.class.getName());
      setControlBindingClassName(JUTextFieldBinding.class.getName());
   }


   public JUTextFieldDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUTextFieldBinding.class.getName(),
            iterBindingName, attrNames);
   }


   public JUTextFieldDef(String name, String iterBindingName, String[] attrNames)
   {
      this(name, JTextField.class.getName(), null, iterBindingName, attrNames);
   }

   protected void initSubType()
   {
      setSubType(PNAME_TextField);
   }

   public Object createControl()
   {
      JTextField jTxtFld = (JTextField) super.createControl();
      if (jTxtFld != null)
      {
        Object initValue = getInitialValue();
  
        if (initValue != null)
        {
           jTxtFld.setText(initValue.toString());
        }
      }
      return jTxtFld;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUControlBinding bind = new JUTextFieldBinding((JTextField) control, getIterBinding((JUFormBinding)formBnd),
                                    getFirstAttrName());
      bind.setName(getName());
      return bind;
   }
}
