/*
 * @(#)JUFormatEditorPropDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import java.text.NumberFormat;
import java.text.DecimalFormat;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import javax.swing.text.NumberFormatter;
import javax.swing.text.DefaultFormatter;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.jui.JUTableDef;

public class JUFormatEditorPropDef extends JUTableDef.JUEditorPropDef
{
    public final static String PNAME_ActiveFormatter = "ActiveFormatter";    //NO TRANS
    public final static int DATE_FORMATTER= 0;
    public final static int MASK_FORMATTER= 1;
    public final static int DEFAULT_FORMATTER= 2;
    public final static int NUMBER_FORMATTER = 3;
    public final static int REGEXP_FORMATTER = 4;

    String mEditorName = "Formatted TextField";    //NO TRANS

    JUFormattedTextFieldDef.DateFormatDef mDateFormatDef = new JUFormattedTextFieldDef.DateFormatDef();
    JUFormattedTextFieldDef.MaskFormatDef mMaskFormatDef = new JUFormattedTextFieldDef.MaskFormatDef();
    JUFormattedTextFieldDef.NumberFormatDef mNumberFormatDef = new JUFormattedTextFieldDef.NumberFormatDef();
    JUFormattedTextFieldDef.RegExpFormatDef mRegExpFormatDef = new JUFormattedTextFieldDef.RegExpFormatDef();
    JUFormattedTextFieldBinding.Convertor mConvertor = null;

    int mActiveFormatter = MASK_FORMATTER;

    String mFormatString=null;
    private JUTableFormatEditor mTableCellFormatEditor;

    public JUFormatEditorPropDef()
    {

    }

    public void setAttrName(String attrName)
    {

    }

    public JUTableCellRenderer getTableCellRenderer()
    {
        return null;
    }

    //
    // return the editor to be used as used set as cell editor for the
    // selected attribute.
    //
    public JUTableCellEditor  getTableCellEditor()
    {
        DefaultFormatterFactory dff;

        //
        // Depending on the ActiveFormatted sets the TableCellEditor
        // properties which will be applied on the editor component
        //
        switch (getActiveFormatter())
        {
            case DATE_FORMATTER:
            {
                SimpleDateFormat sdf = new SimpleDateFormat();
                if (getDateFormatDef().getFormatString() != null &&
                           ! (getDateFormatDef().getFormatString().equals("")))
                {
                    sdf.applyPattern(getDateFormatDef().getFormatString());
                }
                DateFormatter dateFormatter = new DateFormatter(sdf);
                dff = new DefaultFormatterFactory(dateFormatter);
                mConvertor = new DateConvertor();
                mTableCellFormatEditor = new JUTableFormatEditor(dff,mConvertor);
            }
            break;
            case MASK_FORMATTER:
            {
                MaskFormatter mf = new MaskFormatter();
                //For empty string as FormatString use DefaultFormatter.
                try
                {
                    mf.setMask(getMaskFormatDef().getFormatString());
                    dff = new DefaultFormatterFactory(mf);
                    mTableCellFormatEditor = new JUTableFormatEditor(dff,mConvertor);
                }
                catch(java.text.ParseException pex)
                {

                }
            }
            break;
            case DEFAULT_FORMATTER :
            {
                DefaultFormatter df= new DefaultFormatter();
                dff = new DefaultFormatterFactory(df);
                mTableCellFormatEditor = new JUTableFormatEditor(dff,mConvertor);
            }
            break;
            case NUMBER_FORMATTER:
            {

                String formatString = getNumberFormatDef().getFormatString();
                NumberFormat nf = null;
                try
                {
                    nf = new DecimalFormat(formatString==null? "":formatString);
                } catch (Exception e)
                {

                }
                NumberFormatter nfmtr = new NumberFormatter(nf);
                dff = new DefaultFormatterFactory(nfmtr);
                mConvertor = new NumericConvertor();
                mTableCellFormatEditor = new JUTableFormatEditor(dff,mConvertor);
            }
            break;
            case REGEXP_FORMATTER:
            {
                RegExpFormatter rf = new RegExpFormatter();
          
                String patternStr = getRegExpFormatDef().getPattern();
                int regExpFlag = getRegExpFormatDef().getFlag();
                
                try
                {
                    Pattern pattern = null;
              
                    if (regExpFlag != 0)
                    {
                        pattern = Pattern.compile(patternStr, regExpFlag);
                    }
                    else 
                    {
                        pattern = Pattern.compile(patternStr);
                    }
                    
                    rf.setPattern(pattern);
                }
                catch(PatternSyntaxException pex)
                {
                }
                dff = new DefaultFormatterFactory(rf);
                mTableCellFormatEditor = new JUTableFormatEditor(dff, mConvertor);
            }
        }
        return mTableCellFormatEditor;
    }

    //
    // returns the name of the editor
    //
    public String getEditorName()
    {
        return  mEditorName;
    }

    public void setEditorName(String name)
    {
        mEditorName = name;
    }

    public int getActiveFormatter()
    {
        return mActiveFormatter;
    }

    public void setActiveFormatter(int activeFormatter)
    {
        mActiveFormatter = activeFormatter;
    }

    public JUFormattedTextFieldDef.DateFormatDef getDateFormatDef()
    {
        return mDateFormatDef;
    }

    public void setDateFormatDef(JUFormattedTextFieldDef.DateFormatDef def)
    {
        mDateFormatDef = def;
    }

    public JUFormattedTextFieldDef.MaskFormatDef getMaskFormatDef()
    {
        return mMaskFormatDef;
    }

    public void setMaskFormatDef(JUFormattedTextFieldDef.MaskFormatDef def)
    {
        mMaskFormatDef= def;
    }

    public JUFormattedTextFieldDef.NumberFormatDef getNumberFormatDef()
    {
        return mNumberFormatDef;
    }

    public JUFormattedTextFieldDef.RegExpFormatDef getRegExpFormatDef()
    {
        return mRegExpFormatDef;
    }

    public void setNumberFormatDef(JUFormattedTextFieldDef.NumberFormatDef def)
    {
       mNumberFormatDef = def;
    }

    public void init(HashMap initValues)
    {
         super.init(initValues);

         Object val;
         if ((val = initValues.get(PNAME_ActiveFormatter)) != null)
         {
              mActiveFormatter = ((Integer)val).intValue();
         }
         if ((val = initValues.get(PNAME_EditorName)) != null)
         {
              mEditorName = ((String)val).toString();
         }

    }

    public void loadChildrenFromXML(DefElement xmlElement)
    {
        super.loadChildrenFromXML(xmlElement);
        loadDateFormatDef(xmlElement);
        loadMaskFormatDef(xmlElement);
        loadNumberFormatDef(xmlElement);
        loadRegExpFormatDef(xmlElement);
    }

    void loadDateFormatDef(DefElement xmlElement)
    {
        com.sun.java.util.collections.ArrayList dateDefs =
            xmlElement.getChildrenList(JUFormattedTextFieldDef.DateFormatDef.ELEMENT_NAME);

        if (dateDefs.size() > 0)
        {
            DefElement dateDefXML = (DefElement) dateDefs.get(0);
                mDateFormatDef = new JUFormattedTextFieldDef.DateFormatDef();
            mDateFormatDef.loadFromXML(dateDefXML);
        }
    }

    void loadMaskFormatDef(DefElement xmlElement)
    {
        com.sun.java.util.collections.ArrayList maskDefs =
            xmlElement.getChildrenList(JUFormattedTextFieldDef.MaskFormatDef.ELEMENT_NAME);

        if (maskDefs.size() > 0)
        {
            DefElement maskDefXML = (DefElement) maskDefs.get(0);
            mMaskFormatDef = new JUFormattedTextFieldDef.MaskFormatDef();
            mMaskFormatDef.loadFromXML(maskDefXML);
        }
    }

    void loadNumberFormatDef(DefElement xmlElement)
    {
        com.sun.java.util.collections.ArrayList numDefs =
            xmlElement.getChildrenList(JUFormattedTextFieldDef.NumberFormatDef.ELEMENT_NAME);

        if (numDefs.size() > 0)
        {
            DefElement numDefXML = (DefElement) numDefs.get(0);
            mNumberFormatDef = new JUFormattedTextFieldDef.NumberFormatDef();
            mNumberFormatDef.loadFromXML(numDefXML);
        }
    }

    void loadRegExpFormatDef(DefElement xmlElement)
    {
        com.sun.java.util.collections.ArrayList regexpDefs =
            xmlElement.getChildrenList(JUFormattedTextFieldDef.RegExpFormatDef.ELEMENT_NAME);

        if (regexpDefs.size() > 0)
        {
            DefElement regexpDefXML = (DefElement) regexpDefs.get(0);
            mRegExpFormatDef = new JUFormattedTextFieldDef.RegExpFormatDef();
            mRegExpFormatDef.loadFromXML(regexpDefXML);
        }
    }
    
    protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
    {
         super.retrieveFromXML(xmlElement, valueTab);
         readXMLInt(xmlElement, PNAME_ActiveFormatter, valueTab);
         readXMLString(xmlElement, PNAME_EditorName, valueTab);
    }
}
