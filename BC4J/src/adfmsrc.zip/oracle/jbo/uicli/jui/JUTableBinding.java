/*
 * @(#)JUTableBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.lang.reflect.Constructor;
import java.util.Enumeration;
import java.util.HashMap;
import javax.swing.BoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.SortCriteria;
import oracle.jbo.SortCriteriaImpl;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.uicli.binding.JUCtrlRangeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCDataControl;
import javax.swing.JMenuItem;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;

import oracle.jbo.uicli.UIMessageBundle;
import javax.swing.DefaultBoundedRangeModel;

/**
 * A lightweight TableModel that implements
 * binding a <code>javax.swing.JTable</code> to a RowIterator for a BC4J ViewObject.
 * <p>
 * Applications should subclass this binding and return a subclass of
 * JUTableModel that can:
 * <ul>
 * <li>Perform application-specific sorting of rows displayed in a JTable.</li>
 * <li>Dynamically display/hide certain columns based on user preferences or application logic.</li>
 * </ul>
 * <p>
 * This class creates a runtime instance of JUTableModel to interact with
 * a JTable instance. It is responsible for:
 * <ul>
 * <li>Managing Row and iterator events from BC4J layer and calls appropriate JTableModel
 * methods to update JTable display.</li>
 * <li>Manages edits using the current Cell Editor by cancelling/accepting edits from the
 * current cell editor.</li>
 * </ul>
 * <p>
 *
 *
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.ViewObject
 * @see javax.swing.JTable
 * @see javax.swing.table.TableModel
 * @see javax.swing.table.AbstractTableModel
 */
public class JUTableBinding extends JUCtrlRangeBinding
   implements TableModel, JUPanelStopEditingListener, HierarchyListener
{
   private static final String SYNC_FROM_TABLE_SORT = "JUTableBinding.sort"; //nonls
   private JUTableModel mTableModel;
   private JScrollPane mScrollPane;
   private JUTableScrollBarListener mScrollBarListener;
   private int mScrollUnit;
   private boolean mParentSearched = false;
   private int mNumVisRows = 0;
   private JboException mError = null;
   int     mScrollMode;
   HashMap mColumnProperties = null;
   boolean mTrackScrolling = false;

   static int DEF_TABLE_ROW_COUNT = 10;
   public static final int TBL_SCROLL_ACTIVE     = 0; //shows populated rows
   private static final int TBL_SCROLL_NOUPDATE  = 1; //shows empty rows (obsolote, can be removed)
   private static final int TBL_SCROLL_CYCLEROWS = 2; //shows fake data (obsolete, can be removed)
   public static final int TBL_SCROLL_PASSIVE    = 3; //ignore changes while scrolling

   public static final int CS_FULL  = 0;
   public static final int CS_NONE  = -1;
   public static final int CS_RANGE = 1;

   JUPanelBinding mPanelBinding;

   public boolean mSortAscending = false;
   public int     mSortColumn = -1;

   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {

      setControl(control);

      JUTableModel model = getModelImpl((JTable)control);
      JUTableDef def = (JUTableDef)getDef();
      switch (def.getColumnSortMode())
      {
         case CS_RANGE:
         {
            TableModel model1 = JUTableSortModel.enableColumnSorting((JTable)control, this, null);
            updateColumnModel((JTable)control);
            return model1;
         }

         case CS_FULL:
         {
            MouseAdapter listMouseListener = new MouseAdapter() 
            {
               public void mouseClicked(MouseEvent e) 
               {
                  JTable tableView = (JTable)getControl();
                  TableColumnModel columnModel = tableView.getColumnModel();
                  int viewColumn = columnModel.getColumnIndexAtX(e.getX()); 
                  int column = tableView.convertColumnIndexToModel(viewColumn); 
                  if(e.getClickCount() == 1 && column != -1) 
                  {
                     int shiftPressed = e.getModifiers()&InputEvent.SHIFT_MASK; 
                     boolean ascending = (shiftPressed == 0); 
                     DCIteratorBinding iter = getIteratorBinding();
                     if (ascending == mSortAscending && column == mSortColumn)
                     {
                        mSortAscending = true;
                        mSortColumn = -1;
                     }
                     else if (iter.isAttributeSortable(getAttributeDef(column))) 
                     {
                        mSortAscending = ascending;
                        mSortColumn = column;
                     }
                     else
                     {
                        //column not sortable.
                        return;
                     }


                     SwingUtilities.invokeLater(new Runnable() {
                        public void run() 
                        {
                           DCIteratorBinding iter = getIteratorBinding();
                           if (iter.isAlive() && iter.isBound()) 
                           {
                              SortCriteria sc[];
                              if (mSortColumn == -1) 
                              {
                                 sc = new SortCriteria[0];
                              }
                              else
                              {
                                 sc = new SortCriteria[]
                                    {
                                      new SortCriteriaImpl(getAttributeDef(mSortColumn).getName(), !mSortAscending)
                                    };
                              }
                              
                              //cache the currentrow key.
                              Row row = iter.getCurrentRow();
                              oracle.jbo.Key key = null;
                              if (row != null) 
                              {
                                 key = row.getKey();
                              }
                              iter.applySortCriteria(sc); 

                              if (iter.getRowSetIterator().getRowSet() != null) 
                              {
                                 //bc4j. need to execute to apply sort on
                                 //the full collection.
                                 iter.executeQuery();
                              }
                              
                              //reset currency on the row that had it before sort.
                              if (key != null) 
                              {
                                 iter.getDataControl().setCurrentRowWithKey(iter, key);
                              }
                              iter.getDataControl().syncIfNeeded(SYNC_FROM_TABLE_SORT);

                           }
                        }
                     });

                  }
               }
            };
            JTable tableView = (JTable)getControl();
            JTableHeader th = tableView.getTableHeader(); 
            th.addMouseListener(listMouseListener); 
         }
      }
      return model;
   }

   /**
   * Creates an instance of JUTableBinding to return. Registers this binding as a binding that
   * has its own cell-editor that needs to be notified for stopping/cancelling edits when
   * the panel needs to invoke a panel-level operation like changing find/data mode and so forth.
   */
   public static TableModel createAttributeListBinding(JUPanelBinding formBinding,
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames)
   {
      return createAttributeListBinding(formBinding, control,
                                        voInstanceName, voIterName,
                                        voIterBindingName, attrNames,
                                        false, null);
   }

   /**
   * Creates an instance of JUTableBinding to return. Registers this binding as a binding that
   * has it's own cell-editor that needs to be notified for stopping/cancelling edits when
   * the panel needs to invoke a panel-level operation like change find/datamode etc.
   */
   public static TableModel createAttributeListBinding(JUPanelBinding formBinding,
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames,
                                                  boolean       columnSort,
                                                  JUTableSortModel        sorter
                                                  )
   {
      if (!JUIUtil.inDesignTime())
      {
         JUTableBinding bind = new JUTableBinding(control,
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrNames);
         bind.refreshControl();
         bind.mPanelBinding = formBinding;

         bind.findParent();

         JUTableModel model = bind.getModel();
         if (columnSort)
         {
            return JUTableSortModel.enableColumnSorting(control, bind, sorter);
         }
         return model;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTableBinding");
            Constructor [] cons = clazz.getConstructors();
            Constructor constructor = null;
            for (int i=0; i < cons.length; i++)
            {
               if (cons[i].getParameterTypes().length == 2)
               {
                  constructor = cons[i];
                  continue;
               }
            }

            String firstAttribute = "";
            if (attrNames != null && attrNames.length != 0)
               firstAttribute = attrNames[0];
            int size = attrNames == null ? 0 : attrNames.length;
            StringBuffer stbuf = new StringBuffer(firstAttribute);
            for (int i=1; i<size; i++)
            {
               stbuf.append(",");
               stbuf.append(attrNames[i]);
            }


            Object [] args = { voInstanceName + "." + stbuf.toString(), new Boolean(columnSort) };
            Object object = constructor.newInstance(args);
            return (TableModel)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }


   /**
   * @deprecated since 9.0.2
   */
   public static TableModel getInstance(JUPanelBinding formBinding,
                                                  JTable        control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String[]      attrNames)
   {
      return createAttributeListBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrNames);
   }


   /**
   * Creates an instance of JUTableModel that performs the binding of a BC4J ViewObject with
   * a JTable. This binding class performs the role of an intermediary between the JUTableModel
   * which implements a TableModel to work with the JTable object and the BC4J framework.
   * <p>
   * This class is responsible for:
   * <ul>
   * <li>Calculating how many rows to display in a JTable (based on JTable size).</li>
   * <li>Reacting to the BC4J row and iterator events to update display and currency.</li>
   * </ul>
   */
   public JUTableBinding(JTable control, JUIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);
       mPanelBinding = (JUPanelBinding)getBindingContainer();

      setControl(control);
   }

   /**
    * Bind this binding to a control.
    */
   public void setControl(Object ctrl)
   {
      JTable control = (JTable)ctrl;
      super.setControl(control);
      if (control != null)
      {
         if (mTableModel != control.getModel())
         {
            mTableModel = getModelImpl(control);
         }
         updateColumnModel(control);
         control.addHierarchyListener(this);
         findParent();
      }
      else if (getControl() != null)
      {
         control = (JTable)getControl();
         control.removeHierarchyListener(this);
         control.setModel(new DefaultTableModel());
      }
   }

   public void setColumnProperties(HashMap columnProperties)
   {
       mColumnProperties = columnProperties;
   }

   protected void updateColumnModel(JTable control)
   {
       if ( control == null || mColumnProperties == null)
           return;

       TableColumnModel tcm = control.getColumnModel();

       // Set the customized column properties
       Enumeration enumer = tcm.getColumns();
       while ( enumer.hasMoreElements() )
       {
           TableColumn tc = (TableColumn)enumer.nextElement();
           // get the model index for this table column
           // and get the column name based on model index to see if the
           // customized properties exist.

           int colIndex = tc.getModelIndex();
           TableColumn tmp = (TableColumn)mColumnProperties.get(getColumnName(colIndex));
           if ( tmp == null )
               continue;

           if ( tmp.getPreferredWidth() > tc.getPreferredWidth() )
               tc.setPreferredWidth(tmp.getPreferredWidth());

           if ( tmp.getCellEditor() != null )
               tc.setCellEditor(tmp.getCellEditor());

           if ( tmp.getCellRenderer() != null )
               tc.setCellRenderer(tmp.getCellRenderer());
       }
   }

   /**
   * Notified by NavigationBar to stop any edits on the current control.
   * Primarily for grid and tree to notify their cell editors to stop
   * editing.
   */
   boolean inStopEditing = false;   //to break event cycles.
   public void stopEditing()
   {
      if (inStopEditing)
      {
         return ;
      }

      JTable table = (JTable)getControl();
      if (table == null)
      {
         return;
      }
      TableCellEditor editor = table.getCellEditor();

      if (editor != null)
      {
         DCBindingContainer form = getBindingContainer();
         boolean errorHandlerActive = form.isErrorHandlerActive();
         try
         {
            inStopEditing = true;
            //this will end up in setValueAt() which should trap and
            //display the exception so catch JboException and ignore it.
            editor.stopCellEditing();
         }
         catch (JboException ex)
         {
            ((JUPanelBinding)getFormBinding()).setEditingStopped(false);
            if (errorHandlerActive)
            {
               Diagnostic.println("Ignoring handled exception :"+ex.getMessage());
            }
            else
            {
               //this should endup in invoke() which should raise the exception.
               throw ex;
            }
         }
         finally
         {
            inStopEditing = false;
         }
      }
   }

   public JUTableModel getModel()
   {
      return mTableModel;
   }

   /**
   * Returns an instance of JUTableModel that this binding works with and is
   * applied as the JTableModel to the given JTable control.
   * <p>
   * Override this method to return a subclass of JUTableModel to perform
   * customizations on the table model like:
   * <ul>
   * <li>Implementing client-side sorting of rows in the grid.</li>
   * <li>Relay out the column order based on some user-preference.</li>
   * <li>Hide some columns from the display.</li>
   * <li>Provide custom renderers or change default renderers.</li>
   * </ul>
   */
   protected JUTableModel getModelImpl(JTable control)
   {
      JUTableModel model = mTableModel;
      if (model == null)
      {
         model = new JUTableModel(control);
         ((JUPanelBinding)getFormBinding()).addBindingWithCellEditor(this);
      }
      return model;
   }

   /**
   * Returns true by default to imply that this binding supports Find mode.
   * Subclasses can override this method to return false if this binding should
   * not display ViewCriteria rows in Find mode.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }

   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Returns the scrollpane object in which the JTable control is displayed. If
   * JTable is not displayed in a scrollpane, then this method returns the JTable
   * control instance.
   */
   public Object getLayoutObject()
   {
      if (mScrollPane == null)
      {
         return getControl();
      }
      else
      {
         return mScrollPane;
      }
   }


   /**
   * *** For internal framework use only ***
   */
   void findParent()
   {
      if (mScrollPane == null && !mParentSearched)
      {
         mParentSearched = true;
         JTable control = (JTable) getControl();

         if (control != null)
         {
            Component parent = control.getParent();

            while (parent != null)
            {
               if (parent instanceof JScrollPane)
               {
                  break;
               }

               parent = parent.getParent();
            }

            if (parent != null)
            {
               setLayoutObject((JScrollPane) parent);
            }
         }
      }
   }


   /**
   * *** For internal framework use only ***
   */
   public void setLayoutObject(JScrollPane scrollPane)
   {
      if (mScrollPane != null)
      {
         mScrollPane.getViewport().removeChangeListener(mTableModel);

         if (mScrollBarListener != null)
         {
            mScrollPane.getVerticalScrollBar().getModel().removeChangeListener(mScrollBarListener);
            mScrollBarListener = null;
         }
      }

      boolean diff = (mScrollPane != scrollPane);
      mScrollPane = scrollPane;
      mNumVisRows = 0;

      if (mScrollPane != null)
      {
         mScrollPane.getViewport().addChangeListener(mTableModel);

         mScrollBarListener = new JUTableScrollBarListener();
         final JScrollBar scrollBar = mScrollPane.getVerticalScrollBar();
         scrollBar.getModel().addChangeListener(mScrollBarListener);
         scrollBar.addMouseListener(new PassiveScrollListener());
       
         //once we use jdk15 we can simply assign the popupMenu
         //for the time being, we'll need a mouse listener
         //jdk15         scrollBar.setComponentPopupMenu(new ScrollPopupMenu(scrollBar));
         scrollBar.addMouseListener(new ScrollPopupListener(new ScrollPopupMenu(scrollBar)));//jdk14
                  
         if (diff)
         {
            mTableModel.stateChanged(null);
         }
      }
   }

   int getScrollUnit()
   {
      return mScrollUnit;
   }

   /**
    * Subclasses may override this to provide a default visible row count
    * for a table binding where the table is not in a scrollpane or
    * the table has not been appropriately sized yet and table
    * needs to know the visible row count.
    */
   protected int getDefaultVisibleRowCount()
   {
      return 10;
   }


   /**
   * Updates the JTable's display with the given set of rows after optionally
   * clearing out the current rows (if clear is true).
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      //calling super starts setting value back into rows which
      //is not desirable as this method is for updating values
      //in the control.

      //super.updateValuesFromRows(rows, clear);
      //this leads to double - painting in the beginning - one from paint processing
      //and one from RowIterator event. We need to solve this problem post-beta.

      //handling of rangeRefreshed event turns

/*
      // sim 12/17/01 -- Commenting out the hack.  The problem was caused
      //                 by the fact that setRangeSize() causes rangeRefreshed
      //                 event.  This event in 3 tier reset the RSI pos (by
      //                 calling resetCrack()) even when MT didn't reset pos.
      //                 Fixed the problem by adding an additional piggyback info
      //                 on PiggybackEventEntry.  Don't need this block any more.

      if (clear)
      {
         //testcases basic\si17-18-19
         //this is a pure hack. this has to be looked into post 902 to
         //fix by sending in the currency in refreshRange event itself.
         //as of now it's being sent in the next piggyback entry but
         //that's a bit late.

         //rangeRefreshed event in 3tier resets the currency to -1, so
         //try if there's a current row and if not set the first row as current.
         RowIterator iter = getRowIterator();
         Row r = iter.getCurrentRow();
         if (r == null)
         {
            iter.first();
         }
      }
*/
      if (mTableModel != null)
      {
         //clean out error here as this method is called
         //only when new set of rows come in for display.
         mError = null;
         mTableModel.refresh(clear); //if clear reselect the current row.
      }
   }


   /**
   * Adjusts the scrollbar of the associated JTable and also refreshes the display
   * with the current set of rows in range in the associated RowIterator. This method
   * does not change the currency of the iterator.
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
      if (mTableModel != null)
      {
         mTableModel.updateRangeScrolled(event);
      }
   }

   /**
   * When a new row is inserted into the associated Iterator, this method gets invoked
   * by the framework. This binding stops the current cell editing (if there is a current
   * cell being edited) and then refreshes the JTable's display to accommodate the new row.
   */
   public void updateRowInserted(InsertEvent event)
   {
      JTable jTab = (JTable) getControl();
      if (jTab != null && jTab.isEditing())
      {
         jTab.getCellEditor().stopCellEditing();
      }

      super.updateRowInserted(event);

      if (mTableModel != null)
      {
         mTableModel.refresh(true /*selectRow*/);
      }
   }


   /**
   * When a row is deleted in the associated iterator, this method gets invoked by
   * the framework, so that this binding can update the displayed rows in the JTable
   * after stopping the edit function on the current cell (if a cell was being edited).
   */
   public void updateRowDeleted(DeleteEvent event)
   {
      JTable jTab = (JTable) getControl();

      //remove and not stop as this stopping will call setAttribute again
      //leading to cycles in case of master/detail and details's FK change
      //see bug 2383961 for example.
      if (jTab != null && jTab.isEditing())
      {
         jTab.removeEditor();
      }

      super.updateRowDeleted(event);

      if (jTab != null)
      {
         jTab.clearSelection();
         if (mTableModel != null)
         {
            mTableModel.refresh(true /*selectRow*/);
         }
      }
   }


   /**
   * Adjusts the display to move the current row selection to the new current row.
   * This method removes/cancels the current cell being edited (if any) before moving
   * the row selection to the new current row.
   */
   public void updateNavigated(NavigationEvent event)
   {
      JTable jTab = (JTable) getControl();

      if (jTab != null && jTab.isEditing())
      {
         jTab.removeEditor();
      }

      if (mTableModel != null)
      {
         mTableModel.updateNavigated(event);
      }
   }


   //
   // HierarchyListener implementation
   //

   public void hierarchyChanged(HierarchyEvent e)
   {
      Object layoutObject = getLayoutObject();
      Object ctrl = getControl();
      boolean redoRange = false;
      if (layoutObject == ctrl)
      {
         //jTable was not added to a parent thus far.
         //so find the parent again and redo stateChanged
         //if it's parent is a scrollpane.
         mParentSearched = false;
         redoRange  = true;
      }
      findParent();

      redoRange= (redoRange && getLayoutObject() != ctrl);
      if ((mTableModel != null) && (redoRange || (mNumVisRows == 0)))
      {
         mTableModel.stateChanged(null);
      }
   }


   //
   // TableModel implementation
   //

   public int getRowCount()
   {
      if (mTableModel != null) 
      {
         return mTableModel.getRowCount();
      }
      return (int)getEstimatedRowCount();
   }


   public int getColumnCount()
   {
      if (mTableModel != null) 
      {
         return mTableModel.getColumnCount();
      }
      return super.getAttributeCount();
   }


   public String getColumnName(int columnIndex)
   {
      if (mTableModel != null) 
      {
         return mTableModel.getColumnName(columnIndex);
      }
      return getLabel(getAttributeDef(columnIndex).getName(), null);
   }


   public Class getColumnClass(int columnIndex)
   {

      if (mTableModel != null) 
      {
         return mTableModel.getColumnClass(columnIndex);
      }
      return getAttributeDef(columnIndex).getJavaType();
   }


   public boolean isCellEditable(int rowIndex, int columnIndex)
   {
      if (mTableModel != null) 
      {
         return mTableModel.isCellEditable(rowIndex, columnIndex);
      }
      return false;
   }


   public Object getValueAt(int rowIndex, int columnIndex)
   {
      if (mTableModel != null) 
      {
         return mTableModel.getValueAt(rowIndex, columnIndex);
      }
      return super.getValueAt(rowIndex, columnIndex);
   }


   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
   {
       if (mTableModel != null) 
       {
           mTableModel.setValueAt(aValue, rowIndex, columnIndex);
       }
       else
       {
           super.setValueAt(aValue, rowIndex, columnIndex);
       }
   }


   public void addTableModelListener(TableModelListener l)
   {
      if (mTableModel != null) 
      {
         mTableModel.addTableModelListener(l);
      }
   }

   public void removeTableModelListener(TableModelListener l)
   {
      if (mTableModel != null) 
      {
         mTableModel.removeTableModelListener(l);
      }
   }

   public void release(int flags)
   {
      if ((flags < 0)
         || ((flags & DCDataControl.REL_ALL_REFS) > 0)
         || ((flags & DCDataControl.REL_VIEW_REFS) > 0))
      {

         setLayoutObject(null);
         mTableModel = null;
      }

      super.release(flags);
   }


   JUTableBinding getMyBinding()
   {
      return this;
   }

   void forceSync()
   {
      DCDataControl dc = getIteratorBinding().getDataControl();
      if (dc != null && dc.syncNeeded())
      {
         //this would mean rountrip per table.
         ((JUPanelBinding)getBindingContainer().getRootBindingContainer()).requestRefreshControl();
      }
   }



   /**
   * This TableModel is used by JUTableBinding to perform updates of the JTable
   * control to which it is bound. This class is responsible for:
   * <ul>
   * <li>Updating the displayed data in JTable.</li>
   * <li>Accepting edits from the JTable and passing it to the appropriate Row in the BC4J layer.</li>
   * <li>Managing the scrollbar associated with the associated JTable's display.</li>
   * <li>Passing the class of the data in each column thats displayed to the JTable
   * so that it can use an appropriate display renderer or cell editor.</li>
   * <li>Editability of cells based on whether the current attribute in the current row
   * is editable or not.</li>
   * </ul>
   */
   protected class JUTableModel extends AbstractTableModel
                                implements ListSelectionListener, ChangeListener
   {
      private boolean mSelRowInProg = false;
      private boolean mBatchMode = false;
      private boolean mDataAccessible  = true;

      JUTableModel(JTable control)
      {
         mScrollUnit = control.getScrollableUnitIncrement(null, SwingConstants.VERTICAL, 0);

         TableModel oldModel = control.getModel();

         if (oldModel instanceof JUTableBinding)
         {
            //we set the model to be JUTableBinding after returning from this method
            //so the old model should be of that type.
            ListSelectionModel oldListSelectModel = control.getSelectionModel();
            oldListSelectModel.removeListSelectionListener(((JUTableBinding)oldModel).mTableModel);
         }
         if (oldModel instanceof JUTableModel)
         {
            //oldModel is never an instanceof JUTableModel, but I'm still checking
            //to be sure. -sjv
            ListSelectionModel oldListSelectModel = control.getSelectionModel();
            oldListSelectModel.removeListSelectionListener((JUTableModel)oldModel);
         }

         ((JTable)getMyBinding().getControl()).setModel(this);

         /*
         //this causes problems in basic\si17.
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //this leads to other deadlocks.
                //synchronized(getTreeLock())
                {
                   //control.setModel(this);
                   ((JTable)getMyBinding().getControl()).setModel(getMyBinding().getModel());
                }
            }
         });
         */

         ListSelectionModel selectModel = control.getSelectionModel();

         selectModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         selectModel.addListSelectionListener(this);
      }


      void fireTableDataChangedRestoreSelection(boolean restoreSelection)
      {
         JTable jTable = (JTable) getControl();
         if (jTable == null)
         {
            return;
         }
         int rowSel = jTable.getSelectedRow();
         int colSel = jTable.getSelectedColumn();

         //Bug 5557627
         // The isAdjusting flag in the selection models are altered in fireTableDataChanged()
         // because of a change in JTable.tableValueChanged code in JDK1.5.0_06.
         // This causes the other events in JTable to be suppressed. Hence while restoring the selection
         // we restore the isAdjusting flags as well.
         boolean isSelModelValAdjusting = jTable.getSelectionModel().getValueIsAdjusting();
         boolean isColModelValAdjusting = jTable.getColumnModel().getSelectionModel().getValueIsAdjusting();

         mSelRowInProg = true;

         try
         {
            fireTableDataChanged();

            if (restoreSelection && (rowSel >= 0 || colSel >= 0) && getRowCount() > 0)
            {
               if (jTable.getSelectedRow() < 0 && rowSel >= 0)
               {
                  //Bug 5557627 Restoring isAdjusting flag.
                  if(jTable.getSelectionModel().getValueIsAdjusting() != isSelModelValAdjusting)
                      jTable.getSelectionModel().setValueIsAdjusting(isSelModelValAdjusting);

                  //si21 -M3 needs this to be inside SelRowInProg loop.
                  selectRowOfIndex(rowSel);
               }
               if (jTable.getSelectedColumn() < 0 && colSel >= 0)
               {
                  //Bug 5557627 Restoring isAdjusting flag.
                  if(jTable.getColumnModel().getSelectionModel().getValueIsAdjusting() != isColModelValAdjusting)
                      jTable.getColumnModel().getSelectionModel().setValueIsAdjusting(isColModelValAdjusting);

                  jTable.setColumnSelectionInterval(colSel, colSel);
               }
            }
         }
         finally
         {
            mSelRowInProg = false;
         }
      }


      void updateRangeScrolled(ScrollEvent event)
      {
         if (mScrollBarListener != null && mScrollBarListener.isInScrollBarStateChange() == false)
         {
            mScrollPane.getVerticalScrollBar().setValue(event.getRangeStart() * mScrollUnit);
         }

         fireTableDataChangedRestoreSelection(true /*restoreSelection*/);
      }


      private UpdateNavigatedRunnableImpl mRunnableUpdateNavigated = null; //cache the runnable thread.
      class UpdateNavigatedRunnableImpl implements Runnable
      {
         int rowIndex;
         UpdateNavigatedRunnableImpl(int idx)
         {
            rowIndex = idx;
         }

         void setRowIndex(int idx)
         {
            rowIndex = idx;
         }

         public void run()
         {
            mRunnableUpdateNavigated = null;
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Navigating to "+rowIndex);
            }

            JTable jTable = (JTable) getControl();

            if (jTable != null)
            {
               java.awt.Rectangle cellRect = jTable.getCellRect(rowIndex, 0, false);
               if (cellRect != null)
               {
                  jTable.scrollRectToVisible(cellRect);
               }

               //donot call setCurrentRowAtRangeIndex since navigation should
               //have resulted in current row already. Table should simply
               //highlight it's row.
               mSelRowInProg = true;
               try
               {
                  selectRowOfIndex(rowIndex);
               }
               finally
               {
                  mSelRowInProg = false;
               }
            }
         }
      }


      void updateNavigated(NavigationEvent event)
      {
         DebugDiagnostic.println("Navigated to " + event.getRowIndex());
         // This is to go through the case the navigation event arrive first.
         // Since we are navigating there is at least one row.
         // if (rowCount == 0)
         // {
         //    rowCount++;
         // }
         int index = event.getRowIndex();
         RowIterator iter = getRowIterator();
         if (iter != null)
         {
            int rangeStart = iter.getRangeStart();

            //if rangeStart is less than zero or
            //if I'm only displaying rangeful of rows (batchmode)
            if (rangeStart < 0 || mBatchMode)
            {
               rangeStart = 0;
            }

            int rowIndex = (index < 0) ? -1 : index + rangeStart;

            JTable jTable = (JTable) getControl();
            if (jTable.getAutoscrolls())
            {
               if (mRunnableUpdateNavigated != null)
               {
                 mRunnableUpdateNavigated.setRowIndex(rowIndex);
               }
               else if (jTable != null && rowIndex >= 0 && jTable.getSelectedRow() != rowIndex)
               {
                  mRunnableUpdateNavigated = new UpdateNavigatedRunnableImpl(rowIndex);
                  SwingUtilities.invokeLater(mRunnableUpdateNavigated);
               }
            }
         }
      }

      private void selectRowOfIndex(int rowIndex)
      {
         //if this is set to true here, then, when a scrollbar is moved using arrow keys,
         //then list-selection moves but fails to set focus to currently selected row
         //mSelRowInProg = true;
         //try
         //{
            JTable jTable = (JTable) getControl();

            if (jTable == null)
            {
               return;
            }
            if (rowIndex >= 0)
            {
               DebugDiagnostic.println("Selecting " + rowIndex);
               jTable.getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
            }
            else
            {
               jTable.getSelectionModel().clearSelection();
            }
         //}
         //finally
         //{
            //mSelRowInProg = false;
         //}
      }

      private boolean mRunnableRefreshLaterSelectRow;
      private Runnable mRunnableRefeshLater;


      private void refresh(boolean selectRow)
      {
         mRunnableRefreshLaterSelectRow = selectRow;

         JTable jTab = (JTable)getControl();
         final int editColAtRefresh = jTab.getEditingColumn();
         final int editRowAtRefresh = jTab.getEditingRow();

         if (mRunnableRefeshLater == null)
         {
            mRunnableRefeshLater = new Runnable()
            {
               public void run()
               {
                  //this leads to other deadlocks.
                  //synchronized(getTreeLock())
                  {
                     JTable jTab = (JTable)getControl();

                     //Bug 5708644
                     // If this thread was invoked while editing another cell,
                     // we need to restoreback the editor after refresh.
                     boolean isEdit = jTab.isEditing();
                     int curEditRow = jTab.getEditingRow();
                     int curEditCol = jTab.getEditingColumn();

                     if (jTab != null && jTab.isEditing())
                     {
                        //remove the editor as we need to redisplay
                        //all the rows in the table in response
                        //and applying value during refresh may lead
                        //to conflicts/erasing refreshed data.
                        jTab.removeEditor();
                     }
                     mRunnableRefeshLater = null;
                     _refreshLater(mRunnableRefreshLaterSelectRow);

                     if(isEdit) {
                         //Restore the editor only if the editing cell has changed in between.
                         if(editColAtRefresh != curEditCol || editRowAtRefresh != curEditRow)
                            jTab.editCellAt(curEditRow,curEditCol);
                     }
                  }
               }
            };

            SwingUtilities.invokeLater(mRunnableRefeshLater);
         }
      }

      private Runnable mRunnableReportException;

      private void reportExceptionLater()
      {
         if (mRunnableReportException == null)
         {
            mRunnableReportException = new Runnable()
            {
               public void run()
               {
                   {
                      if (mError != null)
                      {
                         mRunnableReportException = null;
                         reportException(mError);
                      }
                   }
               }
            };
            SwingUtilities.invokeLater(mRunnableReportException);
         }
      }

      private void _refreshLater(boolean selectRow)
      {
         RowIterator iter = getRowIterator();

         //if mError is not null that means we do not have valid rows to display
         //so leave the display alone.
         if (iter != null  && mError == null)
         {
            DCBindingContainer form = getBindingContainer();
            boolean errorHandlerActive = form.isErrorHandlerActive();

            try
            {
               if (errorHandlerActive)
               {
                  form.setErrorHandlerActive(false);
               }
               
               mDataAccessible = true;

               JTable jTable = (JTable)getControl();
               int colSel = jTable.getSelectedColumn();
               fireTableDataChangedRestoreSelection(!selectRow);
             

               if (selectRow && iter.getCurrentRowSlot() != RowSetIterator.SLOT_DELETED)
               {
                  int selectIndex = -1;
                  int rowIndex = iter.getCurrentRowIndex();
                  if (rowIndex >= 0)
                  {
                     int rangeStart = iter.getRangeStart();

                     //if rangeStart is less than zero or
                     //if I'm only displaying rangeful of rows (batchmode)
                     if (rangeStart < 0)
                     {
                        rangeStart = 0;
                     }
                     if (mBatchMode)
                     {
                        rowIndex = rowIndex - rangeStart;
                     }

                     selectIndex = (rowIndex > 0) ? rowIndex : rangeStart;
                     mSelRowInProg = true;
                     try
                     {
                        selectRowOfIndex(selectIndex);
                        if( colSel > 0)
                        {
                           jTable.setColumnSelectionInterval(colSel, colSel);
                        }
                     }
                     finally
                     {
                        mSelRowInProg = false;
                     }
                  }
               }
            }
            catch (JboException e)
            {
               form.setErrorHandlerActive(errorHandlerActive);
               if (mError == null)
               {
                  mError = e;
                  reportExceptionLater();
               }

            }
            finally
            {
               form.setErrorHandlerActive(errorHandlerActive);
            }
         }
      }



      //
      // TableModel overrides
      //

      public String getColumnName(int attrIndex)
      {
         AttributeDef ad = getAttributeDef(attrIndex);
         return (ad != null) ? getLabel(ad.getName(), null) : Integer.toString(attrIndex);
      }


      public Class getColumnClass(int attrIndex)
      {
         if (!getIteratorBinding().isFindMode())
         {
            AttributeDef ad = getAttributeDef(attrIndex);

            //if format information is available, use default text editor
            //as format service will worry about proper casting.
            if (ad != null && !ad.getUIHelper().hasFormatInformation(null))
            {
               //to workaround the issue of native types not supported in Swing Table,
               //returning corresponding Object type for primitive types
               //bug 4120474
               return oracle.jbo.common.JBOClass.getObjectClass(ad.getJavaType());
            }
         }
         return java.lang.String.class;
      }


      public int getColumnCount()
      {
         return getAttributeCount();
      }


      public int getRowCount()
      {
         if (mError != null)
         {
            //this is the case when an error dialog needs to popup due to
            //some error, but Swing's trying to paint the table as well.
            // draw no rows till the error is cleaned out.
            return 0;
         }
         JUIteratorBinding iter  = getIteratorBinding();
         if ((iter != null) && (iter.isIteratorMadeVisible() || iter.isFindMode()))
         {
            DCBindingContainer form = getBindingContainer();
            {
               boolean errorHandlerActive = form.isErrorHandlerActive();
               try
               {
                  if (!(mBatchMode =
                       (!iter.isFindMode()
                         && iter.getRangeSize() != -1
                         && iter.getDataControl() != null
                         && iter.getDataControl().syncNeeded())))
                  {
                     return (int)getEstimatedRowCount();
                  }

                  //if count of rows in range is less than range size, then
                  //return this count else return rangeSize.
                  int rangeSize = iter.getNavigatableRowIterator().getRangeSize();
                  int rowCountInRange = iter.getNavigatableRowIterator().getRowCountInRange();
                  return (rangeSize > rowCountInRange) ? rowCountInRange : rangeSize;
               }
               catch (JboException e)
               {
                  if (mError == null)
                  {
                     mError = e;
                     reportExceptionLater();
                  }
                  //ignore exception.
                  return 0;
               }
               finally
               {
                  //form.setErrorHandlerActive(errorHandlerActive);
               }
            }
         }
         return 0;
      }


      private int rowIndexToRangeIndex(int rowIndex)
      {
         RowIterator iter = getRowIterator();

         if (iter != null && !mBatchMode)
         {
            int rangeStart = iter.getRangeStart();

            if (rangeStart <= 0)
            {
               return rowIndex;
            }

            return rowIndex - rangeStart;
         }
         else
         {
            return rowIndex;
         }
      }


      public boolean isCellEditable(int rowIndex, int attrIndex)
      {
         JUIteratorBinding iter = getIteratorBinding();
         //where else can we notify which cell has focus
         if (mPanelBinding != null)
         {
            //this is getting called more than once. However, we could keep
            //track of current cell and in that case NOT notify.
            //that may lead to bugs where row # is also displayed as one could
            //change (programmatically) what's displayed and effect the data
            //while keeping the same physical cell editable :)
            mPanelBinding.focusGained(iter, getMyBinding(), JUSVFocusAdapter.MULTI_ATTRIBUTE);
         }

         if (!iter.getDataControl().isOperationSupported(iter, DCDataControl.OPER_DATA_ROW_UPDATE))
         {
            return false;
         }

         int rangeIndex = rowIndexToRangeIndex(rowIndex);
         synchronized(iter.getSyncLock())
         {
            try
            {
               Row[] rows = getAllRowsInRange();
               if (rows == null || rows.length == 0) 
               {
                  return false;
               }

               AttributeDef ad = getAttributeDef(attrIndex);
               if (ad != null && rangeIndex >= 0 && rangeIndex < rows.length)
               {
                  return rows[rangeIndex].isAttributeUpdateable(ad.getIndex());
               }
            }
            catch(Exception ex)
            {
               reportException(ex);
            }
         }

         return true;
      }

      void unlockRSI()
      {
         mDataAccessible = true;
      }


      public Object getValueAt(int rowIndex, int attrIndex)
      {
         JUIteratorBinding iter  = getIteratorBinding();
         NavigatableRowIterator rsi = iter.getNavigatableRowIterator();
         if (mDataAccessible && rsi != null)
         {
            if (!iter.isFindMode())
            {
               oracle.jbo.RowSet rs = ((RowSetIterator)rsi).getRowSet();
               if ((rs != null && !rs.isExecuted()))
               {
                  //do not want to perform eager execution of RS.
                  return null;
               }
            }

            int rangeSize = rsi.getRangeSize();
            int rangeIndex = rowIndexToRangeIndex(rowIndex);

            if (mTrackScrolling)
            {
               if (mScrollMode == TBL_SCROLL_CYCLEROWS && rangeSize > 0) 
               {
                  if (rangeIndex >= rangeSize)
                  {
                     rangeIndex = rangeIndex % rangeSize;
                  }
                  else if (rangeIndex < 0)
                  {
                     rangeIndex = (-1 * rangeIndex) % rangeSize;
                  }
               }
            }
               
            if (rangeIndex >= 0)
            {
               boolean errorHandlerActive = false;
               try
               {
                  if (iter.getBindingContainer().isErrorHandlerActive())
                  {
                     errorHandlerActive = true;
                     iter.getBindingContainer().setErrorHandlerActive(false);
                  }
                  return getAttributeFromRow(rangeIndex, attrIndex);
               }
               catch (JboException e)
               {
                  //lock this table so that it doesn't go for getAttribute again
                  //till it gets a refresh event.
                  mDataAccessible  = false;
                  if (errorHandlerActive)
                  {
                     iter.getBindingContainer().setErrorHandlerActive(errorHandlerActive);
                  }
                  reportException(e);

               }
               finally
               {
                  if (errorHandlerActive)
                  {
                     iter.getBindingContainer().setErrorHandlerActive(errorHandlerActive);
                  }
               }
            }
         }
         return null;
      }


      public void setValueAt(Object value, int rowIndex, int attrIndex)
      {
          Object oldValue =  getValueAt(rowIndex, attrIndex);
          
          if((value == null && oldValue != null)
             || (oldValue == null && value != null)
             || (value !=null && oldValue != null && (! value.toString().equals(oldValue.toString()))))
          {
              int rangeIndex = rowIndexToRangeIndex(rowIndex);
                  
              try
              {
                  setAttributeInRow(rangeIndex, attrIndex, value, false);
              }
              catch (JboException e)
              {
                  //JTable table = (JTable)getControl();
                  reportException(e, true);
                  //table.grabFocus();
                  throw e;
              }
          }
      }


      //
      // ListSelectionListener implementation
      //

      public void valueChanged(ListSelectionEvent event)
      {
          ListSelectionModel listSelModel = (ListSelectionModel) event.getSource();

          if (mSelRowInProg || listSelModel.getValueIsAdjusting())
          {
              return;
          }
            
          if (!listSelModel.isSelectionEmpty())
          {
              resetRSICurrency(listSelModel.getMinSelectionIndex());
          }
      }

      protected void resetRSICurrency(int selectTabRowIndex)
      {
          try
          {
              RowIterator iter = getRowIterator();
              if (iter == null)
              {
                  return;
              }
          
              int rangeSize = iter.getRangeSize();
              int rangeStart = iter.getRangeStart();
              
              //if rangeStart is less than zero or
              //if I'm only displaying rangeful of rows (batchmode)
              if (rangeStart < 0 || mBatchMode)
              {
                  rangeStart = 0;
              }
              int idx = selectTabRowIndex - rangeStart;
              
              if (rangeSize > 0)
              {
                  if (idx >= rangeSize)
                  {
                      idx = idx - iter.getRangeSize() + 1;
                      iter.scrollRange(idx);
                      //idx = selectTabRowIndex - rangeStart;
                      idx = selectTabRowIndex - iter.getRangeStart();
                  }
                  else if (idx < 0)
                  {
                      iter.scrollRange(idx);
                      idx = 0;
                  }
              }

              int currRowIndex = iter.getRangeIndexOf(iter.getCurrentRow());

              //Bug 5702783
              //Saving edit state of table cell before the editor is removed. 
              JTable jTab = (JTable)getControl();
              int editC = jTab.getEditingColumn();
              int editR = jTab.getEditingRow();
              boolean isCellEdit = jTab.isEditing();
              
              //if current row is out of range, then we do want to set the focus
              //to another current row in response to valueChanged event
              //which is generated when Table wants to select a row.
              //gvbasic si18/si19
              {
                  if (currRowIndex != idx && getFormBinding() != null)
                  {
                      ((JUPanelBinding)getFormBinding()).callBeforeRowNavigated(getIteratorBinding());
                  }
                  iter.setCurrentRowAtRangeIndex(idx);
              }

              //Bug 5702783 - Restoring the edit state in case it was changed
              if(isCellEdit && jTab.getSelectedColumn() == editC && jTab.getSelectedRow() == editR) {
                  jTab.editCellAt(editR,editC);
              }

          }
          catch(Exception ex)
          {
              reportException(ex);
              refresh(true /*selectRow*/);
          }
      }

      //
      // ChangeListener implementation
      //    (of the scroll pane's viewport changes, 'mScrollPane.getViewport()'
      //

      public void stateChanged(ChangeEvent event)
      {
         /*
         //this leads to improper calculation.
         if (!getIteratorBinding().isIteratorMadeVisible())
         {
           return;
         }
         */
         int numVisRows = -1;
         int height = 0;
         JTable jTable = (JTable) getControl();

         JUIteratorBinding it = getIteratorBinding();
         if (mScrollPane != null)
         {
            height = mScrollPane.getViewport().getHeight();
         }
         else if (jTable != null)
         {
            height = jTable.getHeight();
         }

         if (height == 0)
         {
            //if table does not have height yet, leave the number
            //of rows equal to the rangeSize or set the rangeSize
            //to max_value so that all rows are fetched.

            if (it != null && it.getRangeSize() > 1)
            {
               numVisRows = it.getRangeSize();
            }
            else if (mScrollPane == null)
            {
               numVisRows = getDefaultVisibleRowCount();
            }
            else
            {
               numVisRows = 0;
            }
         }
         else
         {
            int rowHeight = mScrollUnit;

            // Check to see if the view port shows partial row.
            //mPartialRowVisible = ((height % rowHeight) != 0);
            numVisRows = height / rowHeight;

            if ((height % rowHeight) != 0)
            {
               numVisRows++;
            }
         }
         if (numVisRows != 0 && it != null)
         {
            resolveRangeSize(numVisRows);
         }
      }

      void resolveRangeSize(int numVisRows)
      {
         JUIteratorBinding it = getIteratorBinding();
         int curSize = it.getRangeSize();
         if (curSize != numVisRows)
         {
            it.resolveRangeSize(numVisRows);
            forceSync();
            mNumVisRows = it.getRangeSize();//numVisRows;
         }

      }
   }

   public int rowIndexToRangeIndex(int rowIndex)
   {
       return getModel().rowIndexToRangeIndex(rowIndex);
   }

   public int getScrolMode()
   {
      return mScrollMode ;
   }

   public void setScrollMode(int x)
   {
      //saved opposite value
      mScrollMode  = x;
   }


   //
   // JUTableScrollBarListener inner class
   //

   class JUTableScrollBarListener implements ChangeListener
   {
      // private int mPrevScrollPos = 0;
      private boolean mInScrollBarStateChange = false;


      boolean isInScrollBarStateChange()
      {
         return mInScrollBarStateChange;
      }


      public void stateChanged(ChangeEvent event)
      {
         if (mScrollMode != TBL_SCROLL_ACTIVE 
             && ((javax.swing.BoundedRangeModel)event.getSource()).getValueIsAdjusting()) 
         {
            mTrackScrolling = true;
            return;
         }
         mTrackScrolling = false;

         JUIteratorBinding iterBinding = getIteratorBinding();
         if (iterBinding == null || !iterBinding.isIteratorMadeVisible())
         {
           return;
         }

         //if I do not have all the rows.
         if (!iterBinding.isFindMode()
              && (iterBinding.getRangeSize() != -1)
                && (iterBinding.getDataControl() != null && !iterBinding.getDataControl().syncNeeded()))
         {
            BoundedRangeModel model = (BoundedRangeModel) event.getSource();
            /*
            if (model.getValueIsAdjusting())
            {
              return;
            }
            */
            int value = model.getValue();
//            int extent = model.getExtent();
            int newRangeStart = value / mScrollUnit;
            RowIterator iter = getRowIterator();

            if (iter == null)
            {
               return;
            }

            int rangeStart = iter.getRangeStart();

            if (rangeStart < 0)
            {
               rangeStart = 0;
            }
            int scrollAmount = newRangeStart - rangeStart;

            if (scrollAmount == 0)
            {
               return;
            }

            if (mInScrollBarStateChange)
            {
               return;
            }

            /*
            if (iter.getCurrentRowSlot() == RowIterator.SLOT_BEFORE_FIRST)
            {
               return;
            }
            */

            mInScrollBarStateChange = true;

            try
            {
               iter.scrollRange(scrollAmount);
            }
            finally
            {
               mInScrollBarStateChange = false;
            }
         }
      }
   }
   
  private class ScrollPopupListener extends MouseAdapter {
      private JPopupMenu popupMenu;
      
      public ScrollPopupListener(JPopupMenu popupMenu) {
          this.popupMenu = popupMenu;
      }
      
      public void mousePressed(MouseEvent e) {
          showPopup(e);
      }
      
      public void mouseReleased(MouseEvent e) {
          showPopup(e);
      }
      
      private void showPopup(MouseEvent e) {
          if(e.isPopupTrigger()) {
              popupMenu.show(e.getComponent(),e.getX(),e.getY());
          }
      }
  }//ScrollPopupListener
    
  private class PassiveScrollListener extends MouseAdapter {
    /*
     * Add this listener to the scrollbar to support passive scrolling.
     * If we run in TBL_SCROLL_PASSIVE mode, we don't want continuous data refresh. 
     * To accomplish this we remove the listeners during scrolling. 
     * When the user releases the mouse, we reset the scrollbar model (not the UI!) 
     * to its old value, hook the listeners up again and set the model's new value.
     * Thus we trigger the change listeners just once.
     */
        private ChangeListener[] listeners = null;
        private int oldValue = 0;
        
        public PassiveScrollListener() {
        }
        
        public void mousePressed(MouseEvent e) {
            if(!e.isPopupTrigger() && mScrollMode==TBL_SCROLL_PASSIVE) {
                BoundedRangeModel model = ((JScrollBar)e.getComponent()).getModel();
                if(model instanceof DefaultBoundedRangeModel) {
                    oldValue = ((JScrollBar)e.getComponent()).getValue();
                    DefaultBoundedRangeModel m = (DefaultBoundedRangeModel)model;
                    listeners = (ChangeListener[])m.getChangeListeners().clone();
                    for(int i=0;i<listeners.length;i++) {
                        model.removeChangeListener(listeners[i]);
                    }
                }
            }
        }
        
        public void mouseReleased(MouseEvent e) {
            if(!e.isPopupTrigger() && mScrollMode==TBL_SCROLL_PASSIVE) {
                BoundedRangeModel model = ((JScrollBar)e.getComponent()).getModel();
                if(listeners!=null) {
                    int newValue = ((JScrollBar)e.getComponent()).getValue();
                    model.setValueIsAdjusting(true);
                    model.setValue(oldValue);
                    for(int i=0;i<listeners.length;i++) {
                        model.addChangeListener(listeners[i]);
                    }
                    listeners = null;
                    model.setValueIsAdjusting(false);
                    model.setValue(newValue);                  
                }
            }
        }
  }//PassiveScrollListener
      
  private class ScrollPopupMenu extends JPopupMenu {
        private static final String PROPERTY_VISIBLE = "visible";//NO TRANSLATION
        private final String MENU_TOP = UIMessageBundle.getResString(UIMessageBundle.STR_SCROLL_TOP);
        private final String MENU_PREVIOUS = UIMessageBundle.getResString(UIMessageBundle.STR_SCROLL_PREVIOUS);
        private final String MENU_HERE = UIMessageBundle.getResString(UIMessageBundle.STR_SCROLL_HERE);
        private final String MENU_NEXT = UIMessageBundle.getResString(UIMessageBundle.STR_SCROLL_NEXT);
        private final String MENU_BOTTOM = UIMessageBundle.getResString(UIMessageBundle.STR_SCROLL_BOTTOM);

        private JScrollBar scrollBar;
        private double currentY;

        public ScrollPopupMenu(JScrollBar scrollBar) {
            super();
            this.scrollBar = scrollBar;
            //note that we use a property change listener instead of just subscribing to the 
            //'popupmenuWillBecomeVisible' event. That event is fired before the location is known
            //and it doesn't give the mouse location either. We need to wait until we have 
            //a known location, which we will if we listen for the property 'visible' being switched to true
            registerChangeListener();
            buildMenu();
        }

        private void registerChangeListener() {
            final JPopupMenu menu = this;
            this.addPropertyChangeListener(PROPERTY_VISIBLE, new PropertyChangeListener() {
                    public void propertyChange(PropertyChangeEvent e) {
                        if (menu.isVisible()) {
                            currentY = menu.getLocationOnScreen().getY() - scrollBar.getLocationOnScreen().getY();
                        }
                    }
                }
            );
        }

        private void buildMenu() {
            JMenuItem scrollHere = new JMenuItem();
            scrollHere.setText(MENU_HERE);
            scrollHere.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double relativeY = currentY / scrollBar.getBounds().getHeight();
                        double newValue = relativeY * (scrollBar.getMaximum() - scrollBar.getMinimum());
                        scrollBar.setValue((int)Math.round(newValue));
                    }
                }
            );
            this.add(scrollHere);
            
            this.addSeparator();

            JMenuItem scrollTop = new JMenuItem();
            scrollTop.setText(MENU_TOP);
            scrollTop.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        scrollBar.setValue(scrollBar.getMinimum());
                    }
                }
            );
            this.add(scrollTop);
            
            JMenuItem scrollPrevious = new JMenuItem();
            scrollPrevious.setText(MENU_PREVIOUS);
            scrollPrevious.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        scrollPage(-1);
                    }
                }
            );
            this.add(scrollPrevious);

            JMenuItem scrollNext = new JMenuItem();
            scrollNext.setText(MENU_NEXT);
            scrollNext.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        scrollPage(+1);
                    }
                }
            );
            this.add(scrollNext);

            JMenuItem scrollBottom = new JMenuItem();
            scrollBottom.setText(MENU_BOTTOM);
            scrollBottom.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        scrollBar.setValue(scrollBar.getMaximum());
                    }
                }
            );
            this.add(scrollBottom);
        }
        
        private void scrollPage(int pages) {
            JTable jTable = (JTable) getControl();
            int allRows = getRowCount();
            double pageRows = jTable==null?0:jTable.getVisibleRect().height/jTable.getRowHeight();
            
            if(pageRows>0 && allRows>0)
            {
                double singlePage = (pageRows/allRows) * (scrollBar.getMaximum() - scrollBar.getMinimum());
                double newValue = scrollBar.getValue() + singlePage * pages;                
                scrollBar.setValue((int)Math.round(newValue));
            }
        }
    }//ScrollPopupMenu
}
