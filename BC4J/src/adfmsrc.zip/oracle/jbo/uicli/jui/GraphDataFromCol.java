/*
 * @(#)GraphDataFromCol.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.dss.graph.Graph;
import oracle.jbo.uicli.binding.JUIteratorBinding;

public class GraphDataFromCol
       extends oracle.jbo.uicli.graph.GraphDataFromCol
{
    public GraphDataFromCol(Graph control, 
            JUIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            int numberOfColumnValuesPerMarker,
            String seriesLabel)
    {
        super(control, iterBinding, dataValueAttrNames, 
                numberOfColumnValuesPerMarker, seriesLabel);
    } 

}



