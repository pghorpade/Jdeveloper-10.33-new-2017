/* $Header: JUCtrlListBindingChangeAdapter.java 25-jul-2006.13:42:19 pillanch Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    provides a default implementation for JUCtrlListBindingChangeListener

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    pillanch    07/25/06 - bug 5404116
    rvangri     08/26/05 - rvangri_bug-4358971_20050826
    rvangri     08/26/05 - Creation
 */

package oracle.jbo.uicli.jui;

/**
 *  @version $Header: JUCtrlListBindingChangeAdapter.java 25-jul-2006.13:42:19 pillanch Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */

public class JUCtrlListBindingChangeAdapter extends oracle.jbo.uicli.binding.JUCtrlListBindingChangeAdapter
                                            implements JUCtrlListBindingChangeListener
{
  public void valueNotFound(JUCtrlListBindingChangeEvent e)
  {
      super.valueNotFound(e);
  }
}

