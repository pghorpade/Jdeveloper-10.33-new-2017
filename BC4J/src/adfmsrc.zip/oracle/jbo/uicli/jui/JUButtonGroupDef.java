/*
 * @(#)JUButtonGroupDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlBoolDef;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.JURadioButtonGroupPanel;

public class JUButtonGroupDef extends JUCtrlBoolDef
{
   private String[] mTexts;

   public static final String PNAME_Texts = "Texts";
   
   
   public JUButtonGroupDef()
   {
      setControlBindingClassName(JUButtonGroupBinding.class.getName());
   }

   
   public JUButtonGroupDef(String name, String controlClassName,
                           String controlBindingClassName, String iterBindingName,
                           String[] attrNames, Object[] valueList)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUButtonGroupBinding.class.getName(),
            iterBindingName,
            attrNames, valueList, true /*boolVal*/);
   }

   protected void initSubType()
   {
      setSubType(PNAME_ButtonGroup);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_Texts)) != null)
      {
         mTexts = (String[]) val;
      }
   }

   
   public String[] getTexts()
   {
      return mTexts;
   }

   
   public void setTexts(String[] texts)
   {
      mTexts = texts;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUButtonGroupBinding retVal = null;
      JUIteratorBinding iterBnd = (JUIteratorBinding)getIterBinding(formBnd);

      if (getListOperMode() == JUCtrlListBinding.LIST_OPER_NAVIGATE)
      {
         retVal = new JUButtonGroupBinding((JURadioButtonGroupPanel)control, iterBnd, getAttrNames(), getListOperMode());
      }
      else if (isStaticList())
      {
         Object[] valueList = getValueList();

         retVal = new JUButtonGroupBinding((JURadioButtonGroupPanel)control, iterBnd, getAttrNames(), valueList);

         //retVal.convertValueList();
      }
      else
      {
         retVal = new JUButtonGroupBinding((JURadioButtonGroupPanel)control, iterBnd, getAttrNames(), (JUIteratorBinding)findListIteratorBinding(formBnd), getListAttrNames(), getListDisplayAttrNames());
      }
      retVal.setName(getName());

      return retVal;
      
      /*
      JUButtonGroupBinding bnd = new JUButtonGroupBinding((AbstractButton[]) control,
                                                          getIterBinding((JUFormBinding)formBnd),
                                                          getFirstAttrName(), getValueList());

      bnd.convertValueList();

      return bnd;
      */
   }


   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(2);
      Object val;
      
      readXMLStringArray(xmlElement, PNAME_Texts, valueTab);

      init(valueTab);
   }

   
   
}
