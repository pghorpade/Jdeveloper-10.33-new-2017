/*
 * @(#)JUPanelBindingBeanInfo.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.beans.BeanDescriptor;
import java.beans.EventSetDescriptor;
import java.beans.SimpleBeanInfo;
import oracle.jbo.common.StringManager;
import oracle.jbo.uicli.UIMessageBundle;

import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;

import java.lang.reflect.Method;

//NOTRANS
public class JUPanelBindingBeanInfo extends SimpleBeanInfo
{
   private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
   private final static Class myClass = JUPanelBinding.class;

   public EventSetDescriptor[] getEventSetDescriptors()
   {
      try
      {
         EventSetDescriptor evVal = new EventSetDescriptor(myClass,
                                                      "JUPanelValidationEvent" ,
                                                      JUPanelValidationListener.class,
                                                      new String[]
                                                      {
                                                         "beforeSetAttribute",
                                                         "beforeCurrencyChange",
                                                         "beforeSaveTransaction",
                                                      },
                                                      "addValidationListener",
                                                      "removeValidationListener"
                                                     );
         evVal.setDisplayName(StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_VALIDATION_EVENTS, "Validation Events", null)); //NOTRANS
         
         Class cls = JUPanelRowSetAdapter.class;
         Class[] params = new Class[2];
         params[0] = JUIteratorBinding.class;

         try
         {
            Method methods[]  = new Method[6];
            params[1] = RangeRefreshEvent.class;
            methods[0] = cls.getDeclaredMethod("rangeRefreshed", params);
            params[1] = ScrollEvent.class;
            methods[1] = cls.getDeclaredMethod("rangeScrolled", params);
            params[1] = InsertEvent.class;
            methods[2] = cls.getDeclaredMethod("rowInserted", params);
            params[1] = DeleteEvent.class;
            methods[3] = cls.getDeclaredMethod("rowDeleted", params);
            params[1] = UpdateEvent.class;
            methods[4] = cls.getDeclaredMethod("rowUpdated", params);
            params[1] = NavigationEvent.class;
            methods[5] = cls.getDeclaredMethod("navigated", params);

            Class listener = JUPanelRowSetListener.class;

            //seems like an IDE bug where if you have event methods that have more than one parameter, IDE won't accept it as a valid event.
            EventSetDescriptor evRS = new EventSetDescriptor(
                                                         "JUPanelRowSetEvent" ,
                                                         listener,
                                                         methods,
                                                         myClass.getDeclaredMethod("addRowSetListener", new Class[]{JUPanelRowSetListener.class}),
                                                         myClass.getDeclaredMethod("removeRowSetListener", new Class[]{JUPanelRowSetListener.class})
                                                        );
            evVal.setDisplayName(StringManager.getString(MSG_BUNDLE, UIMessageBundle.STR_ROWSET_EVENTS, "RowSet Events", null)); //NOTRANS
            return new EventSetDescriptor[] {evVal, evRS};
         }
         catch (java.lang.NoSuchMethodException nsme)
         {
            oracle.jbo.common.Diagnostic.printStackTrace(nsme);
            return new EventSetDescriptor[] {evVal};
         }
         //return new EventSetDescriptor[] {evVal};
      }
      catch(java.beans.IntrospectionException ie )
      {
         throw new Error(ie.toString());
      }
   }

  /**
   * Identifies this bean's validator and customizer classes.
   * @return a bean descriptor.
   */
  public BeanDescriptor getBeanDescriptor() {
     return new BeanDescriptor (myClass);
  }
}

