/*
 * @(#)JUButtonDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.AbstractButton;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlBoolDef;
import oracle.jbo.uicli.binding.JUFormBinding;

public class JUButtonDef extends JUCtrlBoolDef
{
   private String mText;

   public static final String PNAME_Text = "Text";

   
   public JUButtonDef()
   {
      setControlBindingClassName(JUButtonBinding.class.getName());
   }

   protected void initSubType()
   {
      setSubType(PNAME_Button);
   }
   
   public JUButtonDef(String name, String controlClassName,
                      String controlBindingClassName, String iterBindingName,
                      String[] attrNames, Object[] valueList, boolean boolVal)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUButtonBinding.class.getName(),
            iterBindingName, attrNames, valueList, boolVal);
   }


   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_Text)) != null)
      {
         mText = val.toString();
      }
   }

   
   public String getText()
   {
      return mText;
   }
   
   
   public void setText(String text)
   {
      mText = text;
   }

   
   public Object createControl()
   {
      AbstractButton jButton = (AbstractButton) super.createControl();

      if (mText != null && jButton != null)
      {
         jButton.setText(mText);
      }

      return jButton;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUButtonBinding bnd = new JUButtonBinding((AbstractButton) control, getIterBinding((JUFormBinding)formBnd),
                                                getFirstAttrName(), getValueList(), isBoolVal());

      bnd.convertValueList();

      return bnd;
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_Text, valueTab);
   }

}
