package oracle.jbo.uicli.jui;


import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.adf.model.binding.DCUtil;
//import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.jui.JUPanelBinding;
import oracle.jbo.uicli.jui.JUTreeNodeBinding;

/**
 * A sample mouse adapter that could be wired up with a JUTreeBinding to
 * handle double-click on the tree nodes: The selected row is made current
 * in the associated row iterator. This is used to allow JTree to be used
 * as a row-navigation control.
 */
public class JUTreeDefaultMouseListener extends MouseAdapter 
{
  // the panelBinding containing the iterators you need to sync with
  JUPanelBinding panelBinding;
  // hashmap used to store node information and target iterator names
  HashMap hm = new HashMap(10);
  // a list of keys already being used, necessary to avoid recursion in a tree containing selfreference joins.
  ArrayList usedKeys = null;
  // by default only double click enforces navigation
  int clickCount = 2;
  //iterators that are in the selection path
  ArrayList itersBound = new ArrayList();

  /**
  *
  *  Constructor.
  *  
  *  @param panelBinding The panelBinding containing the iterators for which the tree needs to sync.
  *  @param rulesactions defines an target iterator per rule.
  *  <p>
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  *  </p>
  */                    
  public JUTreeDefaultMouseListener (JUPanelBinding panelBinding, String [][] rulesactions)
  {  
     this.panelBinding = panelBinding;
     for (int i=0; i < rulesactions.length; i++)
     {
        hm.put(rulesactions[i][0], rulesactions[i][1]);
     }
  }

  /**
  *
  *  Constructor
  *  
  *  @param panelBinding The panelBinding containing the iterators for which the tree needs to sync.
  *  @param rulesactions defines an target iterator per rule.
  *  <p>
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  *  </p>
  *  @param doubleClick defining doubleclick or not (true is  the default)
  */   
  public JUTreeDefaultMouseListener (JUPanelBinding panelBinding, String [][] rulesactions, boolean doubleClick)
  {
    this(panelBinding, rulesactions);
    setDoubleClick(doubleClick);
  }

  /**
  *
  *  Sets the panelBinding containing the iterators for which the tree needs to sync.
  *
  *  @param panelBinding The panelBinding.
  *
  *  @see #getPanelBinding
  */
  public void setPanelBinding(JUPanelBinding panelBinding)
  {
     this.panelBinding = panelBinding;
  }

  /**
  *
  *  Gets the panelBinding containing the  iterators for which tree needs to sync.
  *
  *  @return panelBinding The panelBinding.
  *  
  *  @see #setPanelBinding
  */
  public JUPanelBinding getPanelBinding()
  {
     return panelBinding;
  }

  /**
  *  Defines one target iterator per rule.
  *
  *  @param rulesactions Defines an target iterator per rule.
  *  example : new String [][] { { "NodeRule1", "DeptViewIter" }, { "NodeRule2", "EmpView1Iter" } } });
  *
  *  @see #getRulesActions
  */  
  public void setRulesActions(String [][] rulesactions)
  {  
     hm.clear();
  }

  /**
  *  Defines the target iterator per rule definition.
  *
  *  @return <B>rulesactions Defines an target iterator per rule.</B>
  *
  *  @see #setRulesActions
  */  
  public String [][] getRulesActions()
  {
    Iterator it  = hm.keySet().iterator();
    String [][] retvalue = new String [hm.size()][2];
    
    for (int i=0; it.hasNext(); i++)
    {
       Object o = it.next();
       retvalue[i][0] = o.toString();
       retvalue[i][1] = hm.get(o).toString();
    }

    return retvalue;
  }

  /**
  * 
  *  Controls whether a double-click will activate the events (true is the default).
  *
  *  @param doubleClick Specifies whether double-clicking is required.
  *
  *  @see #isDoubleClick
  */
  public void setDoubleClick(boolean doubleClick)
  {
     clickCount = doubleClick ? 2 : 1;
  }

  /**
  * 
  *   will a double click activate the events ? 
  *
  *  @return doubleClick Specifies whether double-clicking is required.
  * 
  *  @see #setDoubleClick
  */
  public boolean isDoubleClick()
  {
     return (clickCount == 2);
  }


  protected JUIteratorBinding lookupIterBinding(String name)
  {
     if (name != null && name.indexOf('.') > -1)
     {
        //do a global lookup.
        return (JUIteratorBinding)DCUtil.findSpelObject(panelBinding.getBindingContext(), name, false);
     }
     return panelBinding.findIterBinding(name);
  }

  /*
  *
  *  Invoked when a mouse button has been pressed on a component.
  *
  *  @param An event which indicates that a mouse action occurred in a component. 
  *
  *  @see java.awt.event.MouseListener
  */
  public void mousePressed(MouseEvent e) 
  {
      JTree tree = (JTree)e.getComponent();
        
      int selRow = tree.getRowForLocation(e.getX(), e.getY());
      TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
      
      if(selRow != -1) 
      {
         if(e.getClickCount() == clickCount) 
         {
            usedKeys = new ArrayList(5);
            ArrayList newIters = new ArrayList();
            
            for(int i=0; i < selPath.getPathCount(); i++)
            {
               JUTreeNodeBinding tnb = (JUTreeNodeBinding)((DefaultMutableTreeNode)selPath.getPathComponent(i)).getUserObject();
               
               if (tnb != null)
               {
                  //if this node in the path is root, skip as we do not have currency on the root.
                  if (tnb.getTreeNode().isRoot())
                  {
                     continue;
                  }
                  
                  RowSetIterator rsi = tnb.getParentRowSetIterator();
                  if (rsi == null)
                  {
                     continue;
                  }
                  
                  if (rsi != null)
                  {
                     Object obj = tnb.getHierTypeBinding().getName();
                     
                     //if this node in the selection path is one of what this listener is setup
                     //to act on, 
                     if (obj != null && hm.containsKey(obj) && !usedKeys.contains(obj))
                     {
                        usedKeys.add(obj);
                        String iterName = (String)hm.get(obj);
                        
                        //find the iterator to coordinate in this panel binding
                        //or globally - when the name provided is global.
                        JUIteratorBinding iter = lookupIterBinding(iterName);
                        
                        if (iter == null) 
                        {
                           continue;
                        }
                      
                        boolean needToBind = true;
                        
                        //If during previous selection this node was selected,
                        //check if the RSI should be the same between two
                        //selections.
                        if (itersBound.contains(iter))
                        {
                           itersBound.remove(iter);
                           if (iter.getNavigatableRowIterator() != rsi)
                           {
                              //rsi is a new rsi, so different node at the same level
                              //is selected.
                              needToBind = true;
                           }
                           else
                           {
                              //Same node is part of the selection path. add it to 
                              //newly selected nodes.
                              needToBind = false;
                              newIters.add(iter);
                           }
                        }
                        
                        if (needToBind)
                        {
                           iter.bindRowSetIterator(rsi, false);
                           newIters.add(iter);
                        }
                        
                        if (tnb.getRowKey() != null)
                        {
                           Row rows[] = rsi.findByKey(tnb.getRowKey(), 1);
                           if (rows.length == 1)
                           {
                              //set currency in the RSI on the row with key equal
                              //to the key saved on the node.
                              rsi.setCurrentRow(rows[0]);
                           }
                        }
                     }
                  }
               }         
            }
            
            /*
            JUIteratorBinding iterB;
            NavigatableRowIterator rsi;
            boolean reset = false;
            for (int x = 0; x < itersBound.size(); x++)
            {
               //these RSIs are no more part of the selected nodes. Reset the currency
               //back to slot before first.
               iterB = (JUIteratorBinding)itersBound.get(x);
               rsi = iterB.getNavigatableRowIterator();
               try
               {
                  reset = iterB.isSuspendRowSetEventsHandling();
                  iterB.suspendRowSetEventsHandling(true);
                  rsi.first();
                  rsi.previous();
               }
               finally
               {
                  iterB.suspendRowSetEventsHandling(reset);
               }
            }
            */
            itersBound = newIters;
         }     
      }
    
  }
}
  
