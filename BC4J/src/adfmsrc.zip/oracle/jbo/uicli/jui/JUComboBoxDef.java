/*
 * @(#)JUComboBoxDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.JComboBox;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

public class JUComboBoxDef extends JUCtrlListDef
{
   private boolean mEditable;

   public static final String PNAME_Editable = "Editable";

   
   public JUComboBoxDef()
   {
      //dt does this. setControlClassName(JComboBox.class.getName());
      setControlBindingClassName(JUComboBoxBinding.class.getName());
   }

   
   public JUComboBoxDef(String name, String controlClassName,
                        String controlBindingClassName, String iterBindingName,
                        String[] attrNames, boolean staticList,
                        String listVOName, String listRSIName, String[] listAttrNames,
                        Object[] valueList, boolean editable)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUComboBoxBinding.class.getName(),
            iterBindingName, attrNames, staticList,
            listVOName, listRSIName, listAttrNames, valueList);

      mEditable = editable;
   }


   public JUComboBoxDef(String name, String iterBindingName,
                        String[] attrNames, boolean staticList,
                        String listVOName, String listRSIName, String[] listAttrNames,
                        Object[] valueList, boolean editable)
   {
      this(name, JComboBox.class.getName(), null, iterBindingName,
           attrNames, staticList, listVOName, listRSIName, listAttrNames, valueList, editable);
   }

   
   protected void initSubType()
   {
      setSubType(PNAME_ComboBox);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_Editable)) != null)
      {
         mEditable = convertToBoolean(val);
      }
   }

   
   public boolean isEditable()
   {
      return mEditable;
   }

   
   public Object createControl()
   {
      Object control = super.createControl();

      if (control instanceof JComboBox)
      {
         ((JComboBox) control).setEditable(mEditable);
      }

      return control;
   }

   
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    int listOperMode)
   {
     return new JUComboBoxBinding((JComboBox) control, (JUIteratorBinding)iterBinding, attrNames, listOperMode);
     //JUComboBoxBinding retVal = new JUComboBoxBinding((JComboBox) control, iterBinding, attrNames, listOperMode);
     //retVal.setName(getName());
     //return retVal;
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    Object[] valueList)
   {
     return new JUComboBoxBinding((JComboBox) control, (JUIteratorBinding)iterBinding, attrNames, valueList);
     //retVal.setName(getName());
     //return retVal;
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    DCIteratorBinding listIterBinding,
    String[] listAttrNames,
    String[] listDisplayAttrNames)
   {
     return new JUComboBoxBinding((JComboBox) control, (JUIteratorBinding)iterBinding, attrNames, 
                                  (JUIteratorBinding)listIterBinding, listAttrNames, listDisplayAttrNames);
     //retVal.setName(getName());
     //return retVal;
   }

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_Editable, valueTab);
   }

   
}
