/*
 * @(#)JUPanelValidationEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;


import oracle.adf.model.binding.DCBindingContainerValidationEvent;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

import oracle.jbo.Row;
import oracle.jbo.Transaction;

/**
 * Implements EventObject that is passed to the JUPanelValidationListeners
 * in the various event methods. This class provides access to the current iterator binding,
 * panel binding, current row, attribute being edited, and its new value, etc as the
 * case may be for a particular event method.
 */
public class JUPanelValidationEvent extends DCBindingContainerValidationEvent
{

   public JUPanelValidationEvent(JUControlBinding source,
                                 JUFormBinding panel,
                                 JUIteratorBinding iterBinding,
                                 Row         row,
                                 String      attrName,
                                 Object      value)
   {
      super(source, panel, iterBinding, row, attrName, value);
   }

   public JUPanelValidationEvent(JUFormBinding source,
                                 JUIteratorBinding iterBinding,
                                 Row         row)
   {
      super(source, iterBinding, row);
   }

   /**
    * @deprecated since 9.0.5. use the constructor with datacontrol instead.
    */
   public JUPanelValidationEvent(JUFormBinding source, Transaction txn)
   {
      super (source, null);
   }

   public JUPanelValidationEvent(JUFormBinding source, DCDataControl dc)
   {
      super(source, dc);
   }

   JUPanelValidationEvent(DCBindingContainerValidationEvent ev)
   {
      super(ev);
   }

   public final JUPanelBinding getPanelBinding()
   {
      DCBindingContainer ctr = getBindingContainer();
      return (ctr instanceof JUPanelBinding) ? (JUPanelBinding)ctr : null;
   }
}
