/*
 * @(#)JUSliderDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.JSlider;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlScrollDef;
import oracle.jbo.uicli.binding.JUFormBinding;

public class JUSliderDef extends JUCtrlScrollDef
{
   private boolean mHorizontal;

   public static final String PNAME_Horizontal = "Horizontal";
   
   
   public JUSliderDef()
   {
      //dt does this. setControlClassName(JSlider.class.getName());
      setControlBindingClassName(JUSliderBinding.class.getName());
   }

   
   public JUSliderDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         boolean scrollCurrRow, boolean deferAssignValues,
                         boolean useEstRC, boolean horizontal)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUSliderBinding.class.getName(),
            iterBindingName, scrollCurrRow, deferAssignValues, useEstRC);

      mHorizontal = horizontal;
   }


   public JUSliderDef(String name, String iterBindingName,
                         boolean scrollCurrRow, boolean deferAssignValues,
                         boolean useEstRC, boolean horizontal)
   {
      this(name, JSlider.class.getName(), null, iterBindingName,
           scrollCurrRow, deferAssignValues, useEstRC, horizontal);
   }


   protected void initSubType()
   {
      setSubType(PNAME_Slider);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_Horizontal)) != null)
      {
         mHorizontal = convertToBoolean(val);
      }
   }

   
   public boolean isHorizontal()
   {
      return mHorizontal;
   }

   
   public Object createControl()
   {
      Object control = super.createControl();

      if (control instanceof JSlider)
      {
         ((JSlider) control).setOrientation((mHorizontal) ? JSlider.HORIZONTAL : JSlider.VERTICAL);
      }

      return control;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      return new JUSliderBinding((JSlider) control, getIterBinding((JUFormBinding)formBnd),
                                    isScrollCurrRow(), isDeferAssignValues(), isUseEstRC());
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_Horizontal, valueTab);
   }

  
}
