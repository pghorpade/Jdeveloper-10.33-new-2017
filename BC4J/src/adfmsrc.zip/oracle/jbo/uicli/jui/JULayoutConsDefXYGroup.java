/*
 * @(#)JULayoutConsDefXYGroup.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.layout.JULayoutConsDef;

import oracle.jdeveloper.layout.XYConstraints;

public class JULayoutConsDefXYGroup extends JULayoutConsDef
{
   private int mXs[];
   private int mYs[];
   private int mWidths[];
   private int mHeights[];

   public static final String PNAME_Xs = "Xs";
   public static final String PNAME_Ys = "Ys";
   public static final String PNAME_Widths = "Widths";
   public static final String PNAME_Heights = "Heights";
   

   public JULayoutConsDefXYGroup()
   {
   }


   public JULayoutConsDefXYGroup(int[] xs, int[] ys, int[] widths, int[] heights)
   {
      mXs = xs;
      mYs = ys;
      mWidths = widths;
      mHeights = heights;
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object[] valArr;

      if ((valArr = (Object[]) initValues.get(PNAME_Xs)) != null)
      {
         mXs = convertToIntArray(valArr);
      }
      
      if ((valArr = (Object[]) initValues.get(PNAME_Ys)) != null)
      {
         mYs = convertToIntArray(valArr);
      }
      
      if ((valArr = (Object[]) initValues.get(PNAME_Widths)) != null)
      {
         mWidths = convertToIntArray(valArr);
      }
      
      if ((valArr = (Object[]) initValues.get(PNAME_Heights)) != null)
      {
         mHeights = convertToIntArray(valArr);
      }
   }


   public int[] getXs()
   {
      return mXs;
   }


   public int[] getYs()
   {
      return mYs;
   }


   public int[] getWidths()
   {
      return mWidths;
   }

   
   public int[] getHeights()
   {
      return mHeights;
   }

   
   public Object createLayoutCons()
   {
      XYConstraints[] consArr = new XYConstraints[mXs.length];

      for (int j = 0; j < consArr.length; j++)
      {
         consArr[j] = new XYConstraints(mXs[j], mYs[j], mWidths[j], mHeights[j]);
      }

      return consArr;
   }


   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(2);
      Object val;
      
      readXMLStringArray(xmlElement, PNAME_Xs, valueTab);
      readXMLStringArray(xmlElement, PNAME_Ys, valueTab);
      readXMLStringArray(xmlElement, PNAME_Widths, valueTab);
      readXMLStringArray(xmlElement, PNAME_Heights, valueTab);

      init(valueTab);
   }

   
  
}
