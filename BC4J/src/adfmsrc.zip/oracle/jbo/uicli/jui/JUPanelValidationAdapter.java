/*
 * @(#)JUPanelValidationAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.adf.model.binding.DCBindingContainerValidationAdapter;
import oracle.adf.model.binding.DCBindingContainerValidationEvent;
/**
 * Default implementation for JUPanelValidationListener interface.
 * This implementation simply prints a diagnostic message for each
 * event it receives. JClient design time creates a subclass of this
 * adapter with overridden methods as per an application's choice
 * when the Event Inspector is used to generate JUPanelValidationEvent
 * listener code.
 */
public class JUPanelValidationAdapter extends DCBindingContainerValidationAdapter
{
   /**
   * Calls beforeSetAttribute(JUPanelValidationEvent)
   */
   public void beforeSetAttribute(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSetAttribute(DCBindingContainerValidationEvent)");
      beforeSetAttribute(new JUPanelValidationEvent(ev));
   }
   
   /**
   * Calls beforeCurrencyChange(JUPanelValidationEvent)
   */
   public void beforeCurrencyChange(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeCurrencyChange(DCBindingContainerValidationEvent)");
      beforeCurrencyChange(new JUPanelValidationEvent(ev));
   }

   /**
   * Calls beforeSaveTransaction(JUPanelValidationEvent)
   */
   public void beforeSaveTransaction(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSaveTransaction(DCBindingContainerValidationEvent)");
      beforeSaveTransaction(new JUPanelValidationEvent(ev));
   }

   public void beforeSetAttribute(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSetAttribute");
   }
   
   public void beforeCurrencyChange(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeCurrencyChange");
   }

   public void beforeSaveTransaction(JUPanelValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSaveTransaction");
   }
}
