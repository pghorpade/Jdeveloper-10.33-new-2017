/*
 * @(#)JULayoutDefXY.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.layout.JULayoutDef;

import oracle.jdeveloper.layout.XYConstraints;
import oracle.jdeveloper.layout.XYLayout;

public class JULayoutDefXY extends JULayoutDef
{
   private int mWidth = 0;
   private int mHeight = 0;
   public static final String PNAME_Width = "Width";
   public static final String PNAME_Height = "Height";
   
   
   public JULayoutDefXY()
   {
      super(XYLayout.class.getName(), XYConstraints.class.getName());
   }


   public JULayoutDefXY(String layoutClassName, String layoutConsClassName)
   {
      super(layoutClassName, layoutConsClassName);
   }


   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_Width)) != null)
      {
         mWidth = convertToInt(val);
      }
      
      if ((val = initValues.get(PNAME_Height)) != null)
      {
         mHeight = convertToInt(val);
      }
   }
   
   
   public int getWidth()
   {
      return mWidth;
   }

   
   public void setWidth(int width)
   {
      mWidth = width;
   }

   
   public int getHeight()
   {
      return mHeight;
   }

   
   public void setHeight(int height)
   {
      mHeight = height;
   }

   
   public Object createLayout()
   {
      XYLayout layout = new XYLayout();


      if (mWidth > 0)
      {
         layout.setWidth(mWidth);
      }
      if (mHeight > 0)
      {
         layout.setHeight(mHeight);
      }

      return layout;
   }

   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLString(xmlElement, PNAME_Width, valueTab);
      readXMLString(xmlElement, PNAME_Height, valueTab);
   }

   

}
