/*
 * @(#)JUSingleTableGraphDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.dss.graph.Graph;

import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.uicli.binding.JUIteratorBinding;

public class JUSingleTableGraphDef 
        extends oracle.jbo.uicli.graph.JUSingleTableGraphDef
{
   public JUSingleTableGraphDef()
   {
      super();
   }
   
   public JUSingleTableGraphDef(String name, String controlClassName, 
                     String controlBindingClassName, String iterBindingName, 
                     String seriesLabelAttrName,
                     String[] attrNames, String[] colLabels, 
                     String graphPropertiesFileName)
   {
        super(name, controlClassName, controlBindingClassName, iterBindingName, 
              seriesLabelAttrName, attrNames, colLabels, graphPropertiesFileName);

   }

   protected Object createSingleTableGraphBinding(Graph control, 
                DCIteratorBinding iterBinding, String[] dataValueAttrNames,
                String   seriesLabelAttrName, String[] colLabels)
   {
       return  new JUSingleTableGraphBinding(control, 
               (JUIteratorBinding)iterBinding, dataValueAttrNames, 
               seriesLabelAttrName, colLabels);
   }

   protected Object createSingleTableGraphBinding(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            String   seriesLabelAttrName,
			String[] colLabels,
            String   graphDefFileName)
   {
       return new JUSingleTableGraphBinding (control, 
              (JUIteratorBinding)iterBinding, dataValueAttrNames,
              seriesLabelAttrName, colLabels, graphDefFileName);
   }

   protected Object createMasterDetailGraphBinding(Graph control, 
        DCIteratorBinding iterBinding, 
        String seriesLabelAttrName, String childAccessorName,
        String[] dataValueAttrNames, int numberOfColumnValuesPerMarker)
   {
       return new JUMasterDetailGraphBinding(control, 
                  (JUIteratorBinding)iterBinding,   seriesLabelAttrName,
                  childAccessorName, dataValueAttrNames, 
                  numberOfColumnValuesPerMarker);
   }

   protected Object createMasterDetailGraphBinding(Graph control, 
                  DCIteratorBinding seriesBinding, 
				  String  seriesLabelAttrName,
				  String childAccessorName,
				  String[] dataValueAttrNames,
				  int numberOfColumnValuesPerMarker,
				  String graphPropertiesFileName)
   {
       return new JUMasterDetailGraphBinding(control, 
              (JUIteratorBinding)seriesBinding, 
              seriesLabelAttrName, childAccessorName, dataValueAttrNames,
              numberOfColumnValuesPerMarker, graphPropertiesFileName);
   }
}
