/*
 * @(#)JUSpinnerDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.c
 */

package oracle.jbo.uicli.jui;

import java.util.Date;
import java.util.HashMap;

import java.text.SimpleDateFormat;
import java.text.ParseException;

import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;


import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

import oracle.adf.model.binding.DCDefBase;
import java.text.DecimalFormat;


public class JUSpinnerDef extends JUCtrlListDef
{
   // possible Swing Spinner model to use in Enumeration mode

   // Enum mode, user specifies list of values to use
   public final static int ENUM_USE_LIST_MODEL= 0;

   // Enum mode, use Spinner Date Model
   public final static int ENUM_USE_DATE_MODEL = 1;

   // Enum mode, use Spinner Number Model
   public final static int ENUM_USE_NUMBER_MODEL= 2;

   public static final String PNAME_EnumerationSpinnerModelType = "EnumerationSpinnerModelType"; // NOTRANS

   int mEnumSpinnerModelType = ENUM_USE_LIST_MODEL;

   SpinnerDateModelDef mSpinnerDateModelDef;

   SpinnerNumberModelDef mSpinnerNumberModelDef;
   
   public JUSpinnerDef()
   {
      setControlBindingClassName(JUSpinnerBinding.class.getName());
   }
   
   
   //Added the constructor to use it in Kava tests.   
   public JUSpinnerDef(String name, String controlClassName,
                        String controlBindingClassName, String iterBindingName,
                        String[] attrNames, boolean staticList,
                        String listVOName, String listRSIName, String[] listAttrNames,
                        Object[] valueList)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName, attrNames,staticList,listVOName, listRSIName,listAttrNames,valueList);
   }
   
   protected void initSubType()
   {
      setSubType(PNAME_Spinner);
   }

   /**
   * Used in Enumeration mode to determine which SpinnerModel to use
   */
   public void setEnumModeSpinnerModelType(int smt)
   {
		mEnumSpinnerModelType = smt;
   }

   public int getEnumModeSpinnerModelType()
   {
	   return mEnumSpinnerModelType;
   }

   public SpinnerDateModelDef getSpinnerDateModelDef()
   {
       return mSpinnerDateModelDef;
   }

   public SpinnerNumberModelDef getSpinnerNumberModelDef()
   {
       return mSpinnerNumberModelDef;
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_EnumerationSpinnerModelType)) != null)
      {
          mEnumSpinnerModelType = ((Integer)val).intValue();
      }
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JSpinner spinner  = (JSpinner) control;

      JUSpinnerBinding spinnerBnd  = null;

      JUIteratorBinding iterBnd = (JUIteratorBinding)getIterBinding(formBnd);

      int listOperMode = getListOperMode() ;

      if (listOperMode == JUCtrlListBinding.LIST_OPER_NAVIGATE)
      {
          spinnerBnd = new JUSpinnerBinding(spinner,  iterBnd, 
                             getAttrNames(), listOperMode);
      }
      else
      {
          if (isStaticList())
          {
			  switch(getEnumModeSpinnerModelType())
			  {
				  case ENUM_USE_LIST_MODEL:
				  {
				  
					Object[] valueList = getValueList();

					spinnerBnd = new JUSpinnerBinding(spinner, iterBnd, getAttrNames(), valueList);
              
					//spinnerBnd.convertValueList();
				  };
				  break;

				  case ENUM_USE_DATE_MODEL :
				  {
                      spinnerBnd = new JUSpinnerBinding(spinner, iterBnd, 
									getAttrNames(),  createSpinnerDateModel(),getSpinnerDateModelDef().getFormatStringForConversion()); 
            	  };
				  break;

				  case 	ENUM_USE_NUMBER_MODEL:
				  {
					  spinnerBnd = new JUSpinnerBinding(spinner, iterBnd, 
									getAttrNames(),  createSpinnerNumberModel()); 
				  };
				  break;
			  }
          }
          else
          {
              	
            spinnerBnd = new JUSpinnerBinding(spinner, iterBnd, getAttrNames(),
                           (JUIteratorBinding)findListIteratorBinding(formBnd),
                            getListAttrNames(), getListDisplayAttrNames());

          }
      }
      
      spinnerBnd.setName(getName());
      
      return spinnerBnd;
   }

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLInt(xmlElement, PNAME_EnumerationSpinnerModelType, valueTab);
   }

   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);

      loadSpinnerDateModelDef(xmlElement);

      loadSpinnerNumberModelDef(xmlElement);
   }

   void loadSpinnerDateModelDef(DefElement xmlElement)
   {
       com.sun.java.util.collections.ArrayList dateDefs = 
            xmlElement.getChildrenList(SpinnerDateModelDef.ELEMENT_NAME);

      if (dateDefs.size() > 0)
      {
         DefElement dateDefXML = (DefElement) dateDefs.get(0);

		 mSpinnerDateModelDef = new SpinnerDateModelDef();

         mSpinnerDateModelDef.loadFromXML(dateDefXML);
      }

   }

   void loadSpinnerNumberModelDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList numberDefs = 
            xmlElement.getChildrenList(SpinnerNumberModelDef.ELEMENT_NAME);

      if (numberDefs.size() > 0)
      {
         DefElement numberDefXML = (DefElement) numberDefs.get(0);

		 mSpinnerNumberModelDef = new SpinnerNumberModelDef();

         mSpinnerNumberModelDef.loadFromXML(numberDefXML);
      }
   }

   SpinnerDateModel createSpinnerDateModel()
   {
       if (mSpinnerDateModelDef != null)
       {
           Date start = mSpinnerDateModelDef.convertToDate(mSpinnerDateModelDef.getStartDate());

           Date end = mSpinnerDateModelDef.convertToDate(mSpinnerDateModelDef.getEndDate());

           Date current = mSpinnerDateModelDef.convertToDate(mSpinnerDateModelDef.getCurrentDate());
		   

           return new SpinnerDateModel(current, start, end, mSpinnerDateModelDef.getCalendarField());
       }
       else
       {
            return new SpinnerDateModel();
       }
   }


   SpinnerNumberModel createSpinnerNumberModel()
   {
       if (mSpinnerNumberModelDef != null)
       {
           Comparable min = mSpinnerNumberModelDef.convertToComparable(mSpinnerNumberModelDef.getMin());

           Comparable max = mSpinnerNumberModelDef.convertToComparable(mSpinnerNumberModelDef.getMax());

           Number current = mSpinnerNumberModelDef.convertToNumber(mSpinnerNumberModelDef.getCurrent());

           Number step = mSpinnerNumberModelDef.convertToNumber(mSpinnerNumberModelDef.getStepSize());

           return new SpinnerNumberModel(current, min, max, step);
       }
       else
       {
           return new SpinnerNumberModel();
       }
	   
   }

   public static class SpinnerDateModelDef extends DCDefBase
   {
       public static final String ELEMENT_NAME = "SpinnerDateModelDef";

	   public static final String PNAME_StartDate = "StartDate";

	   public static final String PNAME_EndDate = "EndDate";

	   public static final String PNAME_CurrentDate = "CurrentDate";

	   public static final String PNAME_FormatStringForConversion = "FormatStringForConversion";

	   public static final String PNAME_CalendarField = "CalendarField";

       String mStartDate;

	   String mEndDate;

	   String mCurrentDate;

	   String mFormatStringForConversion;

	   int mCalendarField;
    
       public SpinnerDateModelDef()
       {
       }
    
	   public void setStartDate(String date)
	   {
		   mStartDate = date;
	   }

	   public String getStartDate()
	   {
		   return mStartDate;
	   }

	   public void setEndDate(String date)
	   {
		   mEndDate = date;
	   }

	   public String getEndDate()
	   {
		   return mEndDate;
	   }

	   public void setCurrentDate(String date)
	   {
		   mCurrentDate = date;
	   }

	   public String getCurrentDate()
	   {
		   return mCurrentDate;
	   }

	   public void setFormatStringForConversion(String fmt)
	   {
		   mFormatStringForConversion = fmt;
	   }

	   public String getFormatStringForConversion()
	   {
			return mFormatStringForConversion;
	   }

	   /**
	   * @param field : constant defined in java.util.Calendar
	   *                Calendar.Year etc.,
       */
	   public void setCalendarField(int field)
	   {
		   mCalendarField = field;
	   }

	   public int getCalendarField()
	   {
		   return mCalendarField;
	   }


//	  loadFromXML

       public void init(HashMap initValues)
       {
           super.init(initValues);
    
           Object val;

           if ((val = initValues.get(PNAME_FormatStringForConversion)) != null)
           {
               mFormatStringForConversion = val.toString();
           }
          
           if ((val = initValues.get(PNAME_StartDate)) != null)
           {
                mStartDate = val.toString();
           }
            
           if ((val = initValues.get(PNAME_EndDate)) != null)
           {
                mEndDate = val.toString();
           }

           if ((val = initValues.get(PNAME_CurrentDate)) != null)
           {
                mCurrentDate = val.toString();
           }

           if ((val = initValues.get(PNAME_CalendarField)) != null)
           {
                mCalendarField = ((Integer)val).intValue();
           }

       }

       Date convertToDate(String dateStr)
       {
           try
           {
               return convertToDate(dateStr, mFormatStringForConversion);
           }
           catch(ParseException exc)
           {
               // report excetpion 

               return new Date();
           }
       }

       Date convertToDate(String dateStr, String fmtStr)
            throws ParseException
       {
            SimpleDateFormat sdf = new SimpleDateFormat(fmtStr);
			sdf.setLenient(false);
            return sdf.parse(dateStr);
       }

    
       public String getXMLElementTag()
       {
            return ELEMENT_NAME;
       }
    
       protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
       {
            super.retrieveFromXML(xmlElement, valueTab);

            readXMLString(xmlElement, PNAME_FormatStringForConversion, valueTab);
    
            readXMLString(xmlElement, PNAME_StartDate, valueTab);

            readXMLString(xmlElement, PNAME_CurrentDate, valueTab);

			readXMLString(xmlElement, PNAME_EndDate, valueTab);

			readXMLInt(xmlElement, PNAME_CalendarField, valueTab);
       }
   }

   public static class SpinnerNumberModelDef extends DCDefBase
   {
       public static final String ELEMENT_NAME = "SpinnerNumberModelDef";

	   public static final String PNAME_Min = "Min";

	   public static final String PNAME_Max = "Max";

	   public static final String PNAME_Current = "Current";

       public static final String PNAME_StepSize = "StepSize";

	   public static final String PNAME_NumberClassName = "NumberClassName";

       String mMin;

	   String mMax;

	   String mCurrent;

       String mStepSize;

       String mNumberClassName;
       
       public SpinnerNumberModelDef()
       {
       }

       public void setMin(String min)
       {
          mMin = min;
       }

       public String getMin()
       {
           return mMin;
       }

       public void setMax(String max)
       {
           mMax = max;
       }

       public String getMax()
       {
           return mMax;
       }

       public void setCurrent(String current)
       {
           mCurrent = current;
       }

       public String getCurrent()
       {
           return mCurrent;
       }

       public void setStepSize(String stepSize)
       {
           mStepSize = stepSize;
       }

       public String getStepSize()
       {
           return mStepSize;
       }

       public void setNumberClassName(String classname)
       {
           mNumberClassName = classname;
       }

       public String getNumberClassName()
       {
           return mNumberClassName;
       }
       
       public void init(HashMap initValues)
       {
           super.init(initValues);
    
           Object val;
           
           if ((val = initValues.get(PNAME_Min)) != null)
           {
                mMin = val.toString();
           }
        
           if ((val = initValues.get(PNAME_Max)) != null)
           {
                mMax = val.toString();
           }
       
           if ((val = initValues.get(PNAME_Current)) != null)
           {
                mCurrent = val.toString();
           }
       
           if ((val = initValues.get(PNAME_StepSize)) != null)
           {
                mStepSize = val.toString();
           }
        
           if ((val = initValues.get(PNAME_NumberClassName)) != null)
           {
                mNumberClassName = val.toString();
           }

       }
       
       public String getXMLElementTag()
       {
            return ELEMENT_NAME;
       }
    
    
       protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
       {
            super.retrieveFromXML(xmlElement, valueTab);
            
            readXMLString(xmlElement, PNAME_Min, valueTab);

            readXMLString(xmlElement, PNAME_Max, valueTab);
            
            readXMLString(xmlElement, PNAME_Current, valueTab);
            
            readXMLString(xmlElement, PNAME_StepSize, valueTab);

            readXMLString(xmlElement, PNAME_NumberClassName, valueTab);
       }

       Comparable convertToComparable(String number)
       {
           return (Comparable)converToNumber(number, mNumberClassName);
       }

       Number convertToNumber(String number)
       {
           return (Number)converToNumber(number, mNumberClassName);
       }

       Object converToNumber(String number, String numClassName)
       {
			try
			{
				Class valueClass = Class.forName(numClassName);
				
				
				DecimalFormat df = new DecimalFormat();
	
	
				// returns Long or Double., see javadoc
				Number numberVal = df.parse(number); 
				

				if (valueClass.isAssignableFrom(Float.class))
				{
				    return new Float(number);
				}

				if (valueClass.isAssignableFrom(Double.class))
				{
				    return new Double(number);
				}

				if (valueClass.isAssignableFrom(Integer.class))
				{
				     return new Integer(number);
				}

				if (valueClass.isAssignableFrom(Long.class))
				{
				     return new Long(number);
				}
				if (valueClass.isAssignableFrom(oracle.jbo.domain.Number.class))
				{
				    return new Double(number);
				}
				if (valueClass.isAssignableFrom(Byte.class))
				{
				     return new Byte(number);
				}
				if (valueClass.isAssignableFrom(Short.class))
				{
				     return new Short(number);
				}

			} 
			catch (Exception e)
			{
				new Double(number);
			}
			
			return(new Double(number));
       }


   }

}
