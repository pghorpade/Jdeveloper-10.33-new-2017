/*
 * @(#)JUSliderAttrBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a JSlider control with an Attribute in a BC4J RowSet.
 * <p>
 * This binding sets the minimum, maximum, and the extent values of the slider. When the currency
 * changes in the associated rowset, it displays the associated value by adjusting the slider between the minimum
 * and maximum values. Note that the minimum and maximum values should be provided such that all possible
 * values of the associated attribute in a RowSet can be displayed in the slider.
 */
public class JUSliderAttrBinding extends JUCtrlAttrsBinding implements BoundedRangeModel, ChangeListener 
{
   private BoundedRangeModel mSBModel = null;
   boolean mSettingValue = false;
   int mMax = 100;
   int mMin = 0;
   int mExt = 1;

   /**
   * Binds the given slider control to display and update values from the given attribute
   * in a BC4J RowSet.
   * @param control JSlider control with which to bind a BC4J attribute.
   * @param iterBinding Iterator binding that provides the RowSet with which this binding should work.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JSlider displays (what the starting value should be in
   * the JSlider control).
   * @param max Maximum value that the JSlider displays (what the end value should be in the control).
   * @param ext Determines the Extent value for the JSlider control.
   */
   public JUSliderAttrBinding(JSlider control, JUIteratorBinding iterBinding, String attrName,
                              int min, int max, int ext)
   {
      super(control, iterBinding, new String[] { attrName });

      mMin = min;
      mMax = max;
      mExt = ext;
      init(control);

   }


   private void init(JSlider sb)
   {
      mSBModel = getModelImpl(sb);

      if (sb != null)
      {
         if (mSBModel != sb.getModel())
         {
            sb.setModel(mSBModel);
         }
         // this set has no effect as subsequent setModel cleans it up.
         sb.setMinimum(mMin);
         sb.setMaximum(mMax);
         sb.setExtent(mExt);
         sb.setPaintTicks(true);
         sb.setMajorTickSpacing(mExt);
         sb.setSnapToTicks(true);
         // this set has no effect as subsequent setModel cleans it up.


         sb.addChangeListener(this);
         sb.addFocusListener(new JUSVUpdateableFocusAdapter(this, 0));
      }
   }

   /**
   * Registers the BoundedRangeModel that this binding works with. If the slider
   * has a model, this method registers that with this binding and returns the model.
   * If the control or model is null, then this method creates a DefaultBoundedRangeModel
   * and returns that.
   */
   protected BoundedRangeModel getModelImpl(JSlider sb)
   {
      BoundedRangeModel sbModel = mSBModel;

      if (sbModel == null)
      {
         if (sb != null)
         {
            sbModel = sb.getModel();
         }

         if (sbModel == null)
         {
            sbModel = new DefaultBoundedRangeModel();
         }
      }

      return sbModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   /**
   * Returns true, so that Slider can participate in a query in the Find Mode of the
   * containing panel. When the containing panel Binding object is set to Find mode, it queries
   * all control-bindings in it and disables those controls whose bindings return false
   * for this method during the Find mode. The return value from this method indicates 
   * whether to consult an attribute definition for queriability.
   * <p>
   * An application could create a subclass of this binding object and return false from this
   * method to prevent the associated control from participating in find mode. Additionally, a
   * BC4J attribute itself can control whether that attribute can participate in Query or
   * not. That property takes precedence over this method's return, if this method returns true.
   * In other words, if this binding is bound to a CLOB attribute type and the attribute
   * definition for that attribute indicates that it is not queriable, then the default behavior
   * of JUPanelBinding in Find mode will be to disable this binding's control, even though
   * this method returns true.
   */
   protected boolean isControlQueriable()
   {
      return true;
   }
   
   /**
   * Returns the current value indicated by the JSlider control.
   */
   public Object getValueAt(int attrIndex)
   {
      return new Integer(((JSlider) getControl()).getValue());
   }


   boolean mInit = false;
   /**
   * Sets the current value in the JSlider control. This method adjusts the position of the JSlider 
   * current value indicator based on the input value and the minimum and maximum value the JSlider
   * is set to handle.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      if (mSBModel != null) 
      {
         try
         {
            mSettingValue = true;
            if (!mInit) 
            {
               mInit = true;
               JSlider sb  = (JSlider)getControl();
               sb.setMinimum(mMin);
               sb.setMaximum(mMax);
               sb.setExtent(0);
               sb.setPaintTicks(true);
               sb.setMajorTickSpacing(mExt);
               sb.setSnapToTicks(true);
            }
   
            Integer integerVal = (Integer)oracle.jbo.domain.TypeFactory.getInstance(java.lang.Integer.class, value);
            if (integerVal != null) 
            {
                  
               JSlider sb  = (JSlider)getControl();
               if (sb != null) 
               {
                  sb.setValue(integerVal.intValue());
               }
               else
               {
                  mSBModel.setValue(integerVal.intValue());
               }
            }
         }
         finally
         {
            mSettingValue = false;
         }
      }
      //((JSlider) getControl()).setText(value == null ? "" : value.toString());
   }


   /**
   * Use this method to update the slider value, as well as the value in the associated BC4J attribute.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }

   /**
   * Sets the BC4J attribute value based on the change in the JSlider current value.
   */
   public void stateChanged(ChangeEvent e) 
   {
      if (!mSettingValue && !mSBModel.getValueIsAdjusting() && !((JSlider)e.getSource()).getValueIsAdjusting())
      {
          //setAttribute(0, getValueAt(0));
          // Fix for bug 3567676
          compareAndSetAttribute(0, getValueAt(0));
      }
   }

   //
   // BoundedRangeModel implementation
   //
   
   public int getMinimum()
   {
      return mSBModel.getMinimum();
   }


   public void setMinimum(int newMinimum)
   {
      mSBModel.setMinimum(newMinimum);
   }


   public int getMaximum()
   {
      return mSBModel.getMaximum();
   }


   public void setMaximum(int newMaximum)
   {
      mSBModel.setMaximum(newMaximum);
   }


   public int getValue()
   {
      return mSBModel.getValue();
   }


   public void setValue(int newValue)
   {
      mSBModel.setValue(newValue);
   }


   public void setValueIsAdjusting(boolean b)
   {
      mSBModel.setValueIsAdjusting(b);
   }


   public boolean getValueIsAdjusting()
   {
      return mSBModel.getValueIsAdjusting();
   }


   public int getExtent()
   {
      return mSBModel.getExtent();
   }


   public void setExtent(int newExtent)
   {
      mSBModel.setExtent(newExtent);
   }


   public void setRangeProperties(int value, int extent, int min, int max, boolean adjusting)
   {
      mSBModel.setRangeProperties(value, extent, min, max, adjusting);
   }


   public void addChangeListener(ChangeListener x)
   {
      mSBModel.addChangeListener(x);
   }


   public void removeChangeListener(ChangeListener x)
   {
      mSBModel.removeChangeListener(x);
   }

   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {
      setControl(control);
      init((JSlider)control);
      refreshControl();
      return getModelImpl((JSlider)control);
   }

   /**
   * Creates a binding for the JSlider control.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control JSlider control to bind a BC4J attribute with.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JSlider displays (what the starting value should be in
   * the JSlider control).
   * @param max Maximum value that the JSlider displays (what the end value should be in the control).
   * @param ext Determines the Extent value for the JSlider control.
   */
   public static BoundedRangeModel createAttributeBinding(JUFormBinding formBinding, 
                                                  JSlider control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  int           min,
                                                  int           max,
                                                  int           ext)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUSliderAttrBinding bind = new JUSliderAttrBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName, min, max, ext);
         bind.refreshControl();
         BoundedRangeModel model = bind.getModelImpl(null);
         return model;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSliderAttrBinding");
			
			java.lang.reflect.Constructor[] constructors = clazz.getConstructors();

            for (int i=0; i < constructors.length; i++)
            {
                java.lang.reflect.Constructor constructor = constructors[i];

                Class[] paramTypes = constructor.getParameterTypes();

                if (paramTypes.length ==4)
                {
                    // constructor with four arg
                    
					Object [] args = {(new StringBuffer(voInstanceName)
                                  .append('.').append(attrName)).toString(),
                              Integer.toString(min), 
                              Integer.toString(max), 
                              Integer.toString(ext)};

					Object object = constructor.newInstance(args);
					
					return (BoundedRangeModel)object;
                }
            }
			return null;
         }
         catch (Exception e)
         {
            oracle.jbo.common.DebugDiagnostic.printStackTrace(e);

            return null;
         }
      }
   }

   /**
   * @deprecated use createAttributeBinding method instead.
   */
   public static BoundedRangeModel getInstance(JUFormBinding formBinding, 
                                                  JSlider control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  int           min,
                                                  int           max,
                                                  int           ext)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName,
                                 attrName, min, max, ext);
   }
}
