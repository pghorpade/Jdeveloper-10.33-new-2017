/* $Header: JUTableComboBoxRenderer.java 05-oct-2005.03:16:32 pillanch Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    pillanch    10/05/05 - fix for bug 4625095 
    pillanch    10/05/05 - Creation
 */

/**
 *  @version $Header: JUTableComboBoxRenderer.java 05-oct-2005.03:16:32 pillanch Exp $
 *  @author  pillanch
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.jbo.uicli.jui;

import java.util.ArrayList;

import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.AttributeDef;

public class JUTableComboBoxRenderer extends DefaultTableCellRenderer implements JUTableCellRenderer
{
    DCBindingContainer mBindingContainer = null;
    JUTableBinding mTableBinding = null;
    JUComboBoxBinding  listBinding = null;
    String             mBindingName = null;

    AttributeDef mDisplayAttrDefs[];
    int          mAttrCount = -1;
    int          mAttrIndices[];
    Dimension    mAttrSizes[];
    JLabel       mLabels[];
    JPanel       mLabelPane;
    

    public JUTableComboBoxRenderer(String lovBindingName)
    {
        mBindingName = lovBindingName;
    }

    public void setBindingContainer(DCBindingContainer container)
    {
        mBindingContainer = container;
    }
    
    public void setTableBinding(JUTableBinding tableBinding)
    {
        mTableBinding = tableBinding;
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) 
    {
        initControlBinding();        
        if(value != null && listBinding != null)
        {
            boolean isSingleAttrList = listBinding.isSingleAttrList();
            String[] displayAttrNames = ((JUCtrlListDef)listBinding.getDef()).getListDisplayAttrNames();        
            if((displayAttrNames != null) && (! isSingleAttrList))
            {
                DCIteratorBinding sourceIterBinding = listBinding.getListIterBinding();
                if(mDisplayAttrDefs == null)
                {
                    mDisplayAttrDefs = sourceIterBinding.getAttributeDefs(displayAttrNames);
                }
                
                //the following call populates the list with the values
                listBinding.getDisplayData();

                int targetRowIndex = mTableBinding.rowIndexToRangeIndex(row);
                RowSetIterator targetRSI = listBinding.getIteratorBinding().getRowSetIterator();
                if(targetRSI != null)
                {
                    Row targetRow = targetRSI.getRowAtRangeIndex(targetRowIndex);
                    Object sourceValue = listBinding.findValue(targetRow);
                    if(sourceValue != null && sourceValue instanceof Row)
                    {
                        return getDisplayUI(table, (Row)sourceValue, isSelected, hasFocus, row);
                    }
                }
            }
        }
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }

   public void initControlBinding()
   {
       if(listBinding == null)
       {
           ArrayList controlList = mBindingContainer.getCtrlBindingList();
           Object bind;
           for (int i=0, j=controlList.size(); i<j; i++)
           {
               bind = controlList.get(i);
               if (bind instanceof JUComboBoxBinding)
               {
                   if (((JUComboBoxBinding)bind).getName().equals(mBindingName))
                   {
                       listBinding = (JUComboBoxBinding)bind;
                       break;
                   }
               }
           }
       }
   }

   private Component getDisplayUI(JTable table, Object value, boolean isSelected, boolean hasFocus, int modelIndex)
   {
       class CellLabel extends JLabel
       {
           private Dimension preferredSize;
           
           CellLabel(JTable table, Object value, boolean isSelected, boolean cellHasFocus, int modelIndex)
           {
               if (table != null)
               {
                   setFont( table.getFont() );
                   setComponentOrientation(table.getComponentOrientation());
               }

               if (value != null)
               {
                   setText(value.toString()); 
               }
           }
           
           public void updateUI() 
           {
               super.updateUI(); 
           }
           
           public void revalidate() {}
           
           public void repaint(long tm, int x, int y, int width, int height) {}
           
           public void repaint(Rectangle r) {}
           
           protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) 
           {  
               if (propertyName=="text")
               {
                   super.firePropertyChange(propertyName, oldValue, newValue);
               }
           }
           
           public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {}
           
           protected void setValue(Object value) 
           {
               setText((value == null) ? "" : value.toString());
           }
       }

       if (mLabelPane == null)
       {
           JPanel pane = new JPanel()
           {
               public void setFont(java.awt.Font font)
               {
                   java.awt.Component c[] = getComponents();
                   for (int i = 0; i < c.length; i++)
                   {
                       c[i].setFont(font);
                   }
               }
               
               public void setForeground (java.awt.Color color)
               {
                   java.awt.Component c[] = getComponents();
                   for (int i = 0; i < c.length; i++)
                   {
                       c[i].setForeground(color);
                   }
               }
           };
           pane.setOpaque(true);
           mLabelPane = pane;
       }

       if (table != null)
       {
           if ( isSelected )
           {
               mLabelPane.setBackground( table.getSelectionBackground() );
               mLabelPane.setForeground( table.getSelectionForeground() );
           }
           else
           {
               mLabelPane.setBackground( table.getBackground() );
               mLabelPane.setForeground( table.getForeground() );
           }
       }
       
       if (value instanceof Row)
       {
           Row row = (Row)value;
           int count = mAttrCount;
           Object attr;
           CellLabel lbl = null;
           int i;
           if (count != -1)
           {
               Object val;
               for (i = 0; i < count; i++)
               {
                   val = row.getAttribute(mAttrIndices[i]);
                   mLabels[i].setText((val != null) ? val.toString() : "");
                   mLabels[i].setSize(mAttrSizes[i]);
               }
           }
           else
           {
               mLabelPane.setLayout(new GridLayout());
               AttributeDef ad;
               AttributeDef ads[] = mDisplayAttrDefs;
               mAttrCount = count = mDisplayAttrDefs.length;
               mAttrIndices = new int[count];
               mAttrSizes = new Dimension[count];
               CellLabel lbls[] = new CellLabel[count];

               int idx;
               for (i = 0; i < count; i++)
               {
                   ad = (AttributeDef)ads[i];
                   mAttrIndices[i] = idx = ad.getIndex();
                   lbl = new CellLabel(table, row.getAttribute(idx), isSelected, hasFocus, modelIndex);
                   mLabelPane.add(lbl);
                   lbls[i] = lbl;
               }

               int columnWidth = 5;
               int columnHeight = 20;
               if (lbl != null)
               {
                   FontMetrics metrics = lbl.getFontMetrics(lbl.getFont());
                   columnWidth = metrics.charWidth('M');
                   columnHeight = metrics.getHeight();
               }
               for (i = 0; i < count; i++)
               {
                   mAttrSizes[i] = new Dimension(columnWidth * lbls[i].getText().length(), columnHeight);
               }
               mLabels  = lbls;
           }
       }
       else
       {
           //getting a null row or a null value from the null-value-enabled binding.
           return new CellLabel(table, value, isSelected, hasFocus, modelIndex);
       }
       return mLabelPane;
   }
}
