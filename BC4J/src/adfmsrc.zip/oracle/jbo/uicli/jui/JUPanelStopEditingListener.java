/*
 * @(#)JUPanelStopEditingListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Bindings that need to send notifications to their controls to stop a current cell edit
 * like for JTable or JTree, should implement this interface. PanelBinding makes a call
 * to each listener that implements this interface and is registered with the PanelBinding
 * to notify it to stop editing the current cell, if the panel needs to change the display
 * mode, or apply all the changes via a NavigationBar button, etc.
 */
public interface JUPanelStopEditingListener extends java.util.EventListener
{
   /**
   * Notification method to this listener to stop editing.
   */
   void stopEditing();
}
