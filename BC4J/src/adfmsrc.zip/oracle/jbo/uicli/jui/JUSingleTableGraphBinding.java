/*
 * @(#)JUSingleTableGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.io.InputStream;

import oracle.dss.graph.Graph;
import oracle.jbo.uicli.binding.JUIteratorBinding;


/**
 *  Data source for the BI Graph bean. This binding may be used
 *  for Graph which requires one value per marker. A Pie chart 
 *  for example requires one value per marker. Each column in the 
 *  table (ViewObject) represents a Group in the Graph. Each row in
 *  table (ViewObject) represents a series in the Graph.
 * 
 *  @see JUMasterDetailGraphBinding
 */
public class JUSingleTableGraphBinding
    extends oracle.jbo.uicli.graph.JUSingleTableGraphBinding
{

    public static JUSingleTableGraphBinding getInstance(
                                        JUPanelBinding formBinding, 
                                        Graph         control,
										int           graphType,
                                        String        voInstanceName,
                                        String        voIterName, 
                                        String        voIterBindingName,
                                        String[]      dataValueAttrNames,
                                        String        seriesLabelAttrName)
	{

		JUSingleTableGraphBinding bind =
			    getInstance(formBinding, control, graphType, voInstanceName, voIterName, 
				voIterBindingName, dataValueAttrNames, seriesLabelAttrName,
						   dataValueAttrNames);

        return bind;
	}

	public static JUSingleTableGraphBinding  getInstance(
                                        JUPanelBinding formBinding, 
                                        Graph         control,
										int           graphType,
                                        String        voInstanceName,
                                        String        voIterName, 
                                        String        voIterBindingName,
                                        String[]      dataValueAttrNames,
                                        String        seriesLabelAttrName,
										String[]        colLabels)
   {
	    control.setGraphType( graphType );

        JUIteratorBinding iterBinding = (JUIteratorBinding)formBinding.getIteratorBinding(
            voInstanceName, voIterName, voIterBindingName, -1);
        
        JUSingleTableGraphBinding bind = new JUSingleTableGraphBinding(control, 
              iterBinding, dataValueAttrNames, seriesLabelAttrName, colLabels);

        return bind;
   }

    public JUSingleTableGraphBinding(
                                    Graph control,
                                    JUIteratorBinding iterBinding, 
                                    String[] dataValueAttrNames,
                                    String   seriesLabelAttrName,
                                    String[] colLabels)
    {
        super(control, iterBinding, dataValueAttrNames, 
                    seriesLabelAttrName, colLabels);
    }

    /**
    * graphDefFileName should be of form 
    *
    * mypackage1/BIGraphDef.xml
    *
    */
    public JUSingleTableGraphBinding(Graph control,
                                    JUIteratorBinding iterBinding, 
                                    String[] dataValueAttrNames,
                                    String   seriesLabelAttrName,
                                    String[] colLabels,
                                    String   graphDefFileName)
    {
        super(control, iterBinding, dataValueAttrNames, seriesLabelAttrName, 
                colLabels, graphDefFileName);
    }

    public JUSingleTableGraphBinding(Graph control, 
                                     JUIteratorBinding iterBinding, 
                                     String[] dataValueAttrNames /* last column serves as Series label*/,
                                     String[] colLabels)
    {
        super(control, iterBinding, dataValueAttrNames, colLabels, (InputStream)null);
    }

    public JUSingleTableGraphBinding(Graph control, 
                                     JUIteratorBinding iterBinding, 
                                     String[] dataValueAttrNames /* last column serves as Series label*/,
                                     String[] colLabels,
                                     InputStream graphPropertiesStream)
    {
        super(control, iterBinding, dataValueAttrNames, colLabels);
    } 

    /**
    * Gets the associated View's model object.
    */
    public Object getControlModel(Object control)
    {
        super.init((Graph)control, mGraphPropertiesStream);
	    
        return this;
    }


}

