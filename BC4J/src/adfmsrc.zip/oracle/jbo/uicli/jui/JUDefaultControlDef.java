/*
 * @(#)JUDefaultControlDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import oracle.jbo.uicli.binding.JUCtrlAttrsDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JUDefaultControlDef extends JUCtrlAttrsDef
{
   public JUDefaultControlDef()
   {
      setControlBindingClassName(JUDefaultControlBinding.class.getName());
   }


   public JUDefaultControlDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUDefaultControlBinding.class.getName(),
            iterBindingName, attrNames);
   }

   protected void initSubType()
   {
      setSubType(PNAME_DefaultControl);
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUDefaultControlBinding bind = new JUDefaultControlBinding((JUDefaultControlInterface)control,
                                                                 getIterBinding((JUFormBinding)formBnd),
                                                                 getFirstAttrName());
      
      Object initValue = getInitialValue();

      if (initValue != null)
      {
         bind.setValueAt(initValue, 0);
      }
      return bind;
   }
   
   public Object createControl()
   {
   	return(null);
   	
   }
 
}
