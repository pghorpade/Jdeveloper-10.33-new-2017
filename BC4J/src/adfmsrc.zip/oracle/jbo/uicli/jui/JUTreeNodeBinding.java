/*
 * @(#)JUTreeNodeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import oracle.jbo.DeleteEvent;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.uicli.binding.JUCtrlHierBinding;
import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * This class implements rules that govern display of each node in a JTree
 * that is bound to a JUTreeBinding. It also governs what to display when the associated
 * node is expanded. The framework creates instances of this class for each
 * node in the tree.
 *
 * @see oracle.jbo.Row
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.uicli.jui.JUTreeBinding
 * @see javax.swing.JTree
 */
public class JUTreeNodeBinding extends JUCtrlHierNodeBinding
{
   private DefaultMutableTreeNode mTreeNode;
   private static String PLACE_HOLDER="$place-holder$";

   private static boolean mChangingCurrency = false;

   /**
   * *** For internal framework use only ***
   */
   protected JUTreeNodeBinding(JTree tr, JUTreeBinding treeBinding, JUTreeNodeBinding parent,
                            JUIteratorBinding iterBinding, String attrName, Object nodeVal,
                            boolean expandable)
   {
      this (treeBinding, parent, iterBinding, null, null, expandable);
   }


   protected JUTreeNodeBinding 
                           (JTree tr, 
                            JUTreeBinding treeBinding, 
                            JUTreeNodeBinding parent,
                            JUIteratorBinding iterBinding, 
                            JUCtrlHierTypeBinding typeBinding, 
                            Row row,
                            boolean expandable)
   {
      this (treeBinding, parent, iterBinding, typeBinding, row, expandable);
   }
   /**
   * *** For internal framework use only ***
   */
   protected JUTreeNodeBinding 
                           (JUCtrlHierBinding treeBinding, 
                            JUCtrlHierNodeBinding parent,
                            JUIteratorBinding iterBinding, 
                            JUCtrlHierTypeBinding typeBinding, 
                            Row row,
                            boolean expandable)
   {
      super(treeBinding, parent, iterBinding, typeBinding, row, expandable);

      mTreeNode = new DefaultMutableTreeNode(this);

      if (parent != null)
      {
         if (expandable) 
         {
            mTreeNode.add(new DefaultMutableTreeNode(PLACE_HOLDER));
         }
         DefaultMutableTreeNode parentNode = ((JUTreeNodeBinding)parent).getTreeNode();
         if (parentNode != null) 
         {
            parentNode.insert(mTreeNode, parentNode.getChildCount());
            if (mTreeNode.getParent() != parentNode) 
            {
               mTreeNode.setParent(parentNode);
            }
         }
      }
   }

   protected void setupAccessors(Row row)
   {
      super.setupAccessors(row);
      if (row != null && mChildIterBinding == null) 
      {
         String acc[] = getHierTypeBinding().getAccessorNames();
         if (acc != null && acc.length > 1 )
         {
            mTreeNode.remove(0);
         }
      }
   }


   
   /**
   * Finds the row that this node represents in the associated iterator by asking this
   * node's parent node for the iterator and then sets that row as current row in the
   * RowIterator.
   */
   public void nodeSelected()
   {
      if (mParentNode != null)
      {
         DefaultMutableTreeNode parentTreeNode = (DefaultMutableTreeNode)mTreeNode.getParent();

         if (parentTreeNode != null) 
         {
            JUTreeNodeBinding parentNode = (JUTreeNodeBinding)parentTreeNode.getUserObject();

            if (parentNode != null && mRowKey != null)
            {
               RowIterator rsi = getRowIterator();

               Row[] rows = rsi.findByKey(mRowKey, 1);

               if (rows.length > 0)
               {
                  JUPanelBinding panel = (JUPanelBinding)getFormBinding();
                  panel.notifyIteratorChanged(getIteratorBinding(), false);
                  panel.callBeforeRowNavigated(parentNode.getIteratorBinding());
		  try
		  {
                     mChangingCurrency = true;
                     rsi.setCurrentRow(rows[0]);
		  }
		  finally
		  {
                     mChangingCurrency = false;
		  }
               }
            }
         }
      }
   }


   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
   }

   public boolean removeChild(JUCtrlHierNodeBinding child)
   {
      if (super.removeChild(child) && ((JUTreeNodeBinding)child).mTreeNode != null)
      {
         DefaultMutableTreeNode node = ((JUTreeNodeBinding)child).mTreeNode;
         node.removeFromParent();
         node.setUserObject(null);
         ((JUTreeNodeBinding)child).mTreeNode = null;
         return true;
      }
      return false;
   }



   
   /**
   * Collapses the detail nodes of this node and closes this node.
   */
   public void collapse()
   {
      if (mTreeNode != null)
      {
         ((JTree) getControl()).collapsePath(new TreePath(mTreeNode));
      }
   }

   
   /**
   * Expands this node if this node has child-rows to display.
   */
   public void expand()
   {
      JTree jTree = (JTree) getControl();
      if (jTree != null)
      {
         TreePath path = getTreePath();
         if (path.getLastPathComponent() != null)
         {
            jTree.collapsePath(path);
         }

         ArrayList children = getChildren();
         if (children != null)
         {
            for (int j = 0; j < children.size(); j++)
            {
               JUTreeNodeBinding child = (JUTreeNodeBinding) children.get(j);
               if (child.getTreePath().getLastPathComponent() != null)
               {
                  jTree.expandPath(child.getTreePath());
               }
            }
         }
      }
   }
   
   protected JUCtrlHierNodeBinding findChildNode(oracle.jbo.Key key)
   {
      return super.findChildNode(key);
   }

   /**
   * Returns the value that this node displays.
   */
   public Object getValueAt(int rowIndex, int attrIndex)
   {
      return mNodeValue;
   }

   
   /**
   * Sets the value that this node is displaying. Note that this method only changes
   * the display and does not actually update the value of the attribute that this
   * row is displaying.
   */
   public void setValueAt(Object value, int rowIndex, int attrIndex)
   {
      mNodeValue = value;
   }
   
   
   /**
   * Returns the Swing TreeNode object to which this node is associated.
   */
   public DefaultMutableTreeNode getTreeNode()
   {
      return mTreeNode;
   }

   
   /**
   * Returns the TreePath that represents this node in the containing JTree hierarchy.
   * This treepath can be used to work with the JTree/TreeModel APIs that expect a
   * tree path for a node.
   */
   public TreePath getTreePath()
   {
      JUTreeNodeBinding parent = (JUTreeNodeBinding) getParent();

      if (parent == null)
      {
         return new TreePath(mTreeNode);
      }
      else
      {
         Object[] pathComp = parent.getTreePath().getPath();
         Object[] newPathComp = new Object[pathComp.length + 1];

         System.arraycopy(pathComp, 0, newPathComp, 0, pathComp.length);
         
         newPathComp[newPathComp.length - 1] = mTreeNode;

         return new TreePath(newPathComp);
      }
   }


   public void updateNavigated(oracle.jbo.NavigationEvent event)
   {
      if( mChangingCurrency )
      {
         return;
      }
      JUIteratorBinding iter = getIteratorBinding();
      if (iter == null || iter.isFindMode())
      {
         return;
      }

      if (!iter.hasRSI())
      {
         return;
      }

      Row row = event.getRow();
      if (row != null)
      {
         JUTreeNodeBinding node = (JUTreeNodeBinding)findMatchingNode(row.getKey());

         if (node == null)
         {
           //rvgrins bug 4408354
           //If we have a range size less than the total collection size,
           //we may be showing only part of the tree
           //Check if the last row and first row are shown, if not refresh the tree
           Row[] rows = getHierBinding().getAllRowsInRange();
           DefaultMutableTreeNode root = (DefaultMutableTreeNode)((JTree)getControl()).getModel().getRoot();
           if(findMatchingNode(root,rows[rows.length-1].getKey())==null || 
              findMatchingNode(root,rows[0].getKey())==null)
           {         
             getHierBinding().updateValuesFromRows(getAllRowsInRange(), true);
             node = (JUTreeNodeBinding)findMatchingNode(row.getKey());
           }           
         }

         if (node != null) 
         {
            ((JTree)getControl()).setSelectionPath(node.getTreePath());
         }
      }
   }
   
   /**
   * Removes a child node that displays the deleted row from amongst this node's children.
   */
   public void updateRowDeleted(DeleteEvent event)
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (iter == null || iter.isFindMode())
      {
         return;
      }

      Row row = event.getRow();
      if (row != null)
      {
         JUTreeNodeBinding node = (JUTreeNodeBinding)findMatchingNode(row.getKey());
         if (node != null) 
         {
            JUTreeNodeBinding parentNode = (JUTreeNodeBinding)node.getParent();
            node.mTreeNode.removeFromParent();
            if (parentNode == null) 
            {
               ((JUTreeBinding)getHierBinding()).getModelImpl((JTree)getControl()).nodeStructureChanged(mTreeNode);
            }
            else
            {
               ((JUTreeBinding)getHierBinding()).getModelImpl((JTree)getControl()).nodeStructureChanged(parentNode.mTreeNode);
            }
         }
      }
   }

   /**
   * Finds the child node that displays this row and updates its display.
   */
   public void updateValuesFromRow(Row row)
   {
      
      if (getIteratorBinding() == null || getIteratorBinding().isFindMode())
      {
         return;
      }
      if (getParent() == null || row == null)
      {
         //I'm a root node ignore the update call from row.
         return;
      }
      
      //since a node is both in node's iterator as well as on child node's Iterator,
      //we need to ignore the event from the child node's iterator as that is for update of
      //child rows.  Compare def type to avoid such scenarios.
      //this may conflict in cases of 'self-joins where the key is index based (nonbc4j)'
      //as the def fullname will be same. The only way to fix that is to pass in 
      //iterator binding as well in this method and then compare this node's iteratorbinding
      //with what comes in.
      if (!getHierTypeBinding().getStructureDefName().equals(row.getStructureDef().getDefFullName()))
      {
         return;
      }
      
      JUTreeNodeBinding node = (JUTreeNodeBinding)findMatchingNode(row.getKey());
      if (node != null) 
      {
         JTree tree = ((JTree)getControl());

         //we can factor this super method out so that we do not need to findMatchingNode
         //more than once. But lets do that if performance is a concern here.
         super.updateValuesFromRow(row);
         
         node = (JUTreeNodeBinding)findMatchingNode(row.getKey());
         if (node != null)
         {
            TreePath path = node.getTreePath();
            TreeModel model = tree.getModel();
         
            model.valueForPathChanged(path, node);
            //tree.updateUI();
         }
      }
   }

   public void myUpdateValuesFromRows(Row[] rows, boolean clear)
   {
      JTree tree = ((JTree) getControl());
      if (clear)
      {
         mTreeNode.removeAllChildren();
      }

      super.myUpdateValuesFromRows(rows, clear);

      TreePath path = getTreePath();
      
      ((JUTreeBinding)getHierBinding()).getModelImpl(tree).nodeStructureChanged(mTreeNode);
      if (path != null && tree.getModel().isLeaf(path.getLastPathComponent()))
      {
        path = path.getParentPath();
      }
      tree.expandPath(path);
      
      //rvgrins bug 3938889
      //select the first node - only for the root node.
      if ((getHierBinding().getRootNodeBinding() == this)
         && tree.getRowCount()>1 && tree.getSelectionCount()==0 && rows.length>0)
      {
          JUTreeNodeBinding firstNode = (JUTreeNodeBinding)findMatchingNode(rows[0].getKey());
          if (firstNode != null)
          {
             tree.addSelectionPath(firstNode.getTreePath());
          }
      }
   }
   
  private JUTreeNodeBinding findMatchingNode(DefaultMutableTreeNode root, Key key)
  {     
    Enumeration enumeration = root.breadthFirstEnumeration();
    while(enumeration.hasMoreElements())
    {
      Object object = enumeration.nextElement();
      if(object!=null && object instanceof DefaultMutableTreeNode)
      {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)object;
        Object userObject = node.getUserObject();
        if(userObject!=null && userObject instanceof JUTreeNodeBinding)
        {
          JUTreeNodeBinding nodeBinding = (JUTreeNodeBinding)userObject;
          if(nodeBinding!=null && nodeBinding.getRowKey()!=null && nodeBinding.getRowKey().equals(key))
          {
            return nodeBinding;
          }
        }
      }
    }
    return null;
  }   
}
