/*
 * @(#)JUFormattedTextFieldBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.InputVerifier;
import javax.swing.text.Document;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.DateFormatter;
import javax.swing.text.NumberFormatter;
import javax.swing.text.MaskFormatter;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.ApplicationModule;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import javax.swing.text.DefaultFormatter;

/**
 * JUI binding for JFormattedTextField
 *
 * @see oracle.jbo.uicli.jui.JUTextFieldBinding
 * @see javax.swing.JFormattedTextField
 */
public class JUFormattedTextFieldBinding extends JUTextFieldBinding
{
   private Convertor mConvertor;

   private JFormattedTextField.AbstractFormatterFactory mFormatterFactory;

     
   /**
   * Creates an instance of this binding object that binds a swing JFormattedTextField with an attribute
   * for rows in a given Iterator binding. 
   * <p>
   * <p>
   * @param control JFormattedTextField control which should be bound to an attribute of a BC4J row.
   * @param iterBinding JUIteratorBinding object that contains a reference to the RowIterator that contains Rows to display.
   * @param attrName Name of the attribute in the BC4J Row object to display.
   * @param formatterFactory Factory object to create AbstractFormatter
   */
   public JUFormattedTextFieldBinding(JFormattedTextField control, 
                JUIteratorBinding iterBinding, 
                JFormattedTextField.AbstractFormatterFactory formatterFactory,
                String attrName )
   {
      this(control, iterBinding, formatterFactory, attrName, null);
   }

   public JUFormattedTextFieldBinding(JFormattedTextField control, 
             JUIteratorBinding iterBinding, 
             MaskFormatter maskFormatter,
             String attrName)
   {
        this(control, iterBinding, 
            new DefaultFormatterFactory(maskFormatter), attrName, null);

        maskFormatter.setValueContainsLiteralCharacters(false);
   }

   public JUFormattedTextFieldBinding(JFormattedTextField control, 
             JUIteratorBinding iterBinding, 
             DefaultFormatter defaultFormatter,
             String attrName)
   {
        this(control, iterBinding, 
            new DefaultFormatterFactory(defaultFormatter), attrName, null);

   }

   public JUFormattedTextFieldBinding(JFormattedTextField control, 
             JUIteratorBinding iterBinding, 
             DateFormatter dateFormatter,
             String attrName)
   {
        this(control, iterBinding, 
            new DefaultFormatterFactory(dateFormatter), attrName, new DateConvertor());
   }


   public JUFormattedTextFieldBinding(JFormattedTextField control, 
                JUIteratorBinding iterBinding, 
                JFormattedTextField.AbstractFormatterFactory formatterFactory,
                String attrName, Convertor c)
   {
      super(control, iterBinding, attrName);

      init(control, formatterFactory, c);
   }

   
   private void init(JFormattedTextField control, 
                     JFormattedTextField.AbstractFormatterFactory factory, Convertor c)
   {
       setFormatterFactory(factory);

	   setConvertor(c);

	   setControl(control);
   }

   protected void setConvertor(Convertor c)
   {
      mConvertor = c;
   }

   protected Convertor getConvertor()
   {
      return mConvertor;
   }

   protected void setFormatterFactory(JFormattedTextField.AbstractFormatterFactory f)
   {
	   mFormatterFactory = f;
   }

   protected JFormattedTextField.AbstractFormatterFactory getFormatterFactory()
   {
	   return mFormatterFactory;
   }

   protected void registerVerifier(JFormattedTextField ftf)
   {
      ftf.setInputVerifier(new JUFormattedFieldVerifier(isMandatoryAttribute()));
   }
   
   private boolean isMandatoryAttribute()
   {
	   String [] attrs = getAttributeNames();
	   
	   if (attrs==null || attrs.length<=0)
	   	return (false);
	 
	   String attrName = attrs[0];
	   AttributeDef attrDef = findAttributeDef(attrName);
	   
	   if (attrDef==null)
	   {
	   	return(false);
	   }
	   else
	   {
	   	return(attrDef.isMandatory());
	   }
	   
   }

   /**
   * Fetches the text contained in the associated control. This method is used by the
   * framework to get the current value associated with this binding to update into the
   * associated attribute of a BC4J Row. This method calls the JTextComponent.getText()
   * to get the value.
   * @param attrIndex ignored for this control binding.
   * @see javax.swing.text.JTextComponent#getText()
   */
   public Object getValueAt(int attrIndex)
   {
       JFormattedTextField ftf = ((JFormattedTextField) getControl());

       Convertor c = getConvertor();

       if (c != null) 
       {
           return c.objectToDomain(getLatestValue(ftf));
       }
       else
       {
          return getLatestValue(ftf);
       }
   }


   /**
   * Sets the given String representation of value (using value.toString()) into the
   * associated text control. Calls JTextComponent.setText() to set the value. If the
   * value is null, sets "" (an empty string) into the text control. 
   * @param value The value to display in the associated text control.
   * @param attrIndex Ignored for this control binding.
   * @see javax.swing.text.JTextComponent#setText(String)
   */
   public void setValueAt(Object value, int attrIndex)
   {
	   JFormattedTextField ftf = ((JFormattedTextField) getControl());


	   if (ftf==null)
	   	  return;

   	   if (value==null)	
	   {
			ftf.setValue(null);

		    return;
	   }
	   	   
       Convertor c = getConvertor();

       if (c != null) 
       {
           ftf.setValue(c.domainToObject(value));
       }
       else
       {
           ftf.setValue(value);
       }
       
   }
   
   private Object getLatestValue(JFormattedTextField ftf)
   {
       if (ftf.getText().equals(""))
       {
           ftf.setValue(null);
       }
       
       try
       {
           ftf.commitEdit();
       }
       catch(java.text.ParseException exc)
       {
           //
       }

       return ftf.getValue();
   }

   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              MaskFormatter maskFormatter,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {
            maskFormatter.setValueContainsLiteralCharacters(false);

            return createAttributeBinding( formBinding, 
              control, (JFormattedTextField.AbstractFormatter)maskFormatter, 
              null,
              voInstanceName, voIterName, voIterBindingName, attrName);
   }

   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              NumberFormatter numberFormatter,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {
            return createAttributeBinding( formBinding, 
              control, (JFormattedTextField.AbstractFormatter)numberFormatter,
              new NumericConvertor(),
              voInstanceName, voIterName, voIterBindingName, attrName);
   }

   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              DateFormatter dateFormatter,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {
            return createAttributeBinding( formBinding, 
              control, (JFormattedTextField.AbstractFormatter)dateFormatter, 
              new DateConvertor(),
              voInstanceName,
              voIterName, voIterBindingName, attrName);
   }


   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              JFormattedTextField.AbstractFormatter formatter,
              Convertor     convertor,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {

       return createAttributeBinding(formBinding,
                 control, 
                 new DefaultFormatterFactory(formatter),
                 convertor,
                 voInstanceName,
                 voIterName,
                 voIterBindingName,
                 attrName);
   }

   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              JFormattedTextField.AbstractFormatter defaultFormatter,
              JFormattedTextField.AbstractFormatter displayFormatter,
              JFormattedTextField.AbstractFormatter editFormatter,
              JFormattedTextField.AbstractFormatter nullFormatter,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {


       DefaultFormatterFactory formatterFactory = new DefaultFormatterFactory(
           defaultFormatter, displayFormatter, editFormatter, nullFormatter);

       return createAttributeBinding(formBinding,
                 control, 
                 formatterFactory,     
                 voInstanceName,
                 voIterName,
                 voIterBindingName,
                 attrName);
   }

   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              JFormattedTextField.AbstractFormatterFactory formatterFactory,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {
       return createAttributeBinding(formBinding,
          control, 
          formatterFactory,     
          null,
          voInstanceName,
          voIterName,
          voIterBindingName,
          attrName);
   }

   

   /**
   * This method is used by the JDeveloper designtime wizards for binding a text component
   * with an attribute of rows of a ViewObject/RowIterator.
   * This method calls JUFormBinding.getRowIterBinding to get the iterator binding using
   * the given parameters and then registers a new JUTextFieldBinding with the iterator
   * binding object so as to display/edit the current row's attribute of the given name.
   * <p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance to bind to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject rows that contains data
   * to display/edit in the associated text control.
   * @return Document object bound to the given text control.
   */
   public static Document createAttributeBinding( JUFormBinding formBinding, 
              JFormattedTextField  control,
              JFormattedTextField.AbstractFormatterFactory formatterFactory,
              Convertor convertor,
              String        voInstanceName,
              String        voIterName, /*temporarily taking nulls for this*/
              String        voIterBindingName,
              String        attrName)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUFormattedTextFieldBinding bind = new JUFormattedTextFieldBinding(control, 
                formBinding.getRowIterBinding(voInstanceName, 
                                              voIterName, voIterBindingName),
                formatterFactory, 
                attrName);

         bind.setConvertor(convertor);

         bind.refreshControl();
         
         return bind.getModelImpl(null);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJTextFieldBinding"); // NOTRANS

            java.lang.reflect.Constructor [] constructors = clazz.getConstructors();

			for (int i=0; i < constructors.length; i++)
			{
				java.lang.reflect.Constructor constructor = constructors[i];
			
				Class[] paramTypes = constructor.getParameterTypes();
			
				if (paramTypes.length ==1)
				{
					// constructor with one args

					Object [] args = { voInstanceName + "." + attrName };

					Object object = constructor.newInstance(args);

				    return (Document)object;
				}
			}
			
			return null;

         }
         catch (Exception e)
         {
            oracle.jbo.common.DebugDiagnostic.printStackTrace(e);  

            return null;
         }
      }
   }

   public void setControl(Object control)
   {
 		super.setControl(control);

		if (control != null)
	    {
		   JFormattedTextField ftf = (JFormattedTextField)control;

		   ftf.setFormatterFactory(mFormatterFactory);         

		   registerVerifier(ftf);
	    }

        Convertor c = getConvertor();

        if ((c != null) && (control != null))
        {
            c.updateFormatHint(getFormatString(super.getAttributeNames()[0]));
        }
   }

   String getFormatString(String attrName)
   {
         AttributeDef def = findAttributeDef(attrName);
    
         String fmt = null;
    
         if (def != null)
         {
             AttributeHints hints = def.getUIHelper();
    
             ApplicationModule am = getApplicationModule();

             if (am != null)
             {
                 LocaleContext locale = am.getSession().getLocaleContext();
    
                if (hints.hasFormatInformation(locale))
                {
                     fmt = hints.getFormat(locale);
                }
             }
         }
    
         return fmt;
   }
   
   interface Convertor
   {
       void updateFormatHint(String fmtHint);

       // convert domainObject to object type which formatter accepts
       Object domainToObject(Object domainObject);

       /**
       * convert object to domain specific type
       */
       Object objectToDomain(Object object);
   }

}

class ConvertorBase
{
    String mDefaultFormatString;

    String mFormatHint;

    ConvertorBase(String defaultFormatString)
    {
        mDefaultFormatString = defaultFormatString;
    }

    String getFormatString()
    {
        String fmt = getFormatHint();

        return (fmt == null) ? mDefaultFormatString : fmt;
    }

    String getFormatHint()
    {
        return mFormatHint;
    }

    void setFormatHint(String s)
    {
        mFormatHint = s;
    }

    
}


class DateConvertor
    extends ConvertorBase
    implements JUFormattedTextFieldBinding.Convertor
{
   static final String DEFAULT_DATE_FMT_STR = "MM-dd-yyyy";  // NOTRANS

   DateConvertor()
   {
        super(DEFAULT_DATE_FMT_STR);
   }

   public void updateFormatHint(String formatHint)
   {
        setFormatHint(formatHint);
   }
    // convert domainObject to object type which formatter accepts
   public Object domainToObject(Object value) 
   {
       if (value instanceof Date)
       {
            return (Date)value;
       }

       if (value instanceof oracle.jbo.domain.Date)
       {
            Date date = ((oracle.jbo.domain.Date)value).dateValue();

            return date;
       }
        
       if (value instanceof oracle.jbo.domain.Timestamp)
       {
	   		try
	   		{
		   		Date date = ((oracle.jbo.domain.Timestamp)value).dateValue();

		   		return date;
	   		} 
			catch (java.sql.SQLException sqlExc)
	   		{
				return(null);
	   		}
       }
		
       if (value instanceof String)
       {
            return getDateValue((String)value);
       }
        
        return value;
   }

   private Date getDateValue(String s)
   {
       try
       {
           String fmt = super.getFormatString();

           SimpleDateFormat sdf = new SimpleDateFormat(fmt); 

           return (Date)sdf.parse(s);
       }
       catch(java.text.ParseException pe)
       {
           return null;
       }
    }


   /**
   * convert object to domain specific type
   */
   public Object objectToDomain(Object obj) 
   {
        
       if (obj instanceof java.util.Date) 
       {
            java.util.Date dateObj = (java.util.Date)obj;

            if ( dateObj != null )
            {
                Calendar calendar = Calendar.getInstance();

                calendar.setTime(dateObj);
    
                Timestamp timeStampObject =  new Timestamp(dateObj.getTime());

                return  timeStampObject;
            }

            return dateObj;
       }
       
       return obj;
   }
}


class NumericConvertor 
    extends ConvertorBase
    implements JUFormattedTextFieldBinding.Convertor
{
   static final String DEFAULT_NUMBER_FMT_STR = "#0.00"; // NOTRANS

   public NumericConvertor()
   {
       super(DEFAULT_NUMBER_FMT_STR);
   }

   public void updateFormatHint(String formatHint)
   {
       setFormatHint(formatHint);
   }

   // convert domainObject to object type which formatter accepts
   public Object domainToObject(Object domainObject) 
   {
       return toNumber(domainObject);
   }
   
   Number toNumber(Object value)
   {
       if (value instanceof Number)
       {
            return (Number)value;
       }
       else if (value instanceof oracle.jbo.domain.Number)
       {
           Object datum = ((oracle.jbo.domain.Number)value).getData();
           
           if (datum instanceof Number) 
               return (Number)datum;
       }
       else if (value instanceof String)
       {
            Number n =  getNumericValue((String)value);

            if (n != null) 
                return n;
       }
        
       return null;
    }

    Number getNumericValue(String s)
    {
        try
        {
           DecimalFormat df = new DecimalFormat();

           String fmtString = super.getFormatString();

           if (fmtString != null) 
           {
               df.applyPattern(fmtString);
           }

           return  df.parse(s); 

        }
        catch(java.text.ParseException pe)
        {
            return null;
        }
    }


   /**
   * convert object to domain specific type
   */
   public Object objectToDomain(Object object) 
   {
       return object;
   }
}

/**
* Prevent focus change if there is a invalid value
* in the FormattedTextField
*/
class JUFormattedFieldVerifier 
    extends InputVerifier
{
	boolean isAttrMandatory = false;
	
    JUFormattedFieldVerifier()
    {
		this(false);

    }
	
	
    JUFormattedFieldVerifier(boolean isAttrMandatory)
    {
		this.isAttrMandatory = isAttrMandatory;
    }
    
	
    /**
     * Checks whether the JComponent's input is valid. This method should
     * have no side effects. It returns a boolean indicating the status
     * of the argument's input.
     *
     * @param input the JComponent to verify
     * @return <code>true</code> when valid, <code>false</code> when invalid
     * @see JComponent#setInputVerifier
     * @see JComponent#getInputVerifier
     *
     */
    
    public boolean verify(JComponent input) 
    {
        if (input instanceof JFormattedTextField) 
        {
             JFormattedTextField ftf = (JFormattedTextField)input;

             JFormattedTextField.AbstractFormatter formatter = ftf.getFormatter();

             if (formatter != null) 
             {
                 String text = ftf.getText();
				 
				 if (text==null)
				 	text="";
				 
				 if (isAttrMandatory && text.equals(""))
				 {
				 	return(false);
				 }
				 
				 if (text.equals(""))
				 	return(true);

                 try 
                 {
                      formatter.stringToValue(text);
                      return true;
					  
                  } catch (ParseException pe) 
                  {
                      return false;
                  }
              }
          }

          return true;
    }
}
