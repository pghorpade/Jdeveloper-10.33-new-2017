/*
 * @(#)JUBoundedRangeAttrDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlAttrsDef;

public class JUBoundedRangeDef extends JUCtrlAttrsDef
{
   public static final String PNAME_Horizontal = "Horizontal";
   public final static String PNAME_Ext = "Ext";
   public final static String PNAME_Min = "Min";
   public final static String PNAME_Max = "Max";
   int mMin = 0;
   int mMax = 100;
   int mExt = 1;
   boolean mHorizontal = false;

   protected JUBoundedRangeDef()
   {
   }


   protected JUBoundedRangeDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames, int min, int max, int ext)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUBoundedRangeBinding.class.getName(),
            iterBindingName, attrNames);

      mMin = min;
      mMax = max;
      mExt = ext;
   }



   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_Min)) != null)
      {
         mMin = convertToInt(val);
      }
      if ((val = initValues.get(PNAME_Max)) != null)
      {
         mMax = convertToInt(val);
      }
      if ((val = initValues.get(PNAME_Ext)) != null)
      {
         mExt = convertToInt(val);
      }
      if ((val = initValues.get(PNAME_Horizontal)) != null)
      {
         mHorizontal = convertToBoolean(val);
      }
   }

   public boolean isHorizontal()
   {
      return mHorizontal;
   }

   public int getMin()
   {
      return mMin;
   }
   
   public int getMax()
   {
      return mMax;
   }

   public int getExt()
   {
      return mExt;
   }



   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLInt(xmlElement, PNAME_Min, valueTab);
      readXMLInt(xmlElement, PNAME_Max, valueTab);
      readXMLInt(xmlElement, PNAME_Ext, valueTab);
      readXMLBoolean(xmlElement, PNAME_Horizontal, valueTab);
   }
}
