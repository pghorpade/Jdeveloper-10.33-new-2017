/*
 * @(#)JUTableCellEditor.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.table.TableCellEditor;
import oracle.adf.model.binding.DCBindingContainer;

public interface JUTableCellEditor extends TableCellEditor
{
    void setBindingContainer(DCBindingContainer bindingContainer);
    void setTableBinding(JUTableBinding tableBinding);
}
