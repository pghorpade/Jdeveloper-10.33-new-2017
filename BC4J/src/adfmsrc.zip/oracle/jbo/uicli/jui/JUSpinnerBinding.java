/*
 * @(#)JUSpinnerBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;

import java.lang.reflect.Constructor;


import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SpinnerDateModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.ApplicationModule;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.NavigationEvent;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import java.awt.Color;

/**
* Implements binding for JSpinner control.
*
* JSpinner can be bound in the following ways:
* <ul>
* <li>Display a single attribute for rows in a RowSet and iterate the rowset currency</li>
* <li>Display a single attribute from rows in a RowSet and update another attribute
* in the same ViewObject</li>
* <li>Display single attribute from rows in a RowSet and update another attribute in a different ViewObject (similar to an LOV).
* <li>Display a static LOV and update an attribute in a BC4J row.</li>
* </ul>
* <p>
*/
public class JUSpinnerBinding extends JUCtrlListBinding
{
    protected SpinnerModel modelImpl;

    protected boolean mValueUpdating = false;
    protected boolean settingUpList = false;

	protected JComponent mEditor;

    static private String DEFAULT_DATE_FORMAT_STR = "MM-dd-yyyy";
    static private String DEFAULT_NUMERIC_FORMAT_STR = "#0.##";

	private String mFormatStringForConversion = null;

   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {
	  setControl(control);

      return getModelImpl();
   }
    /**
    * Use this binding when the JSpinner control is used as a navigation control to
    * iterate through a range of rows in a RowSet.
    *
    * <p>
    * @param formBinding The containing JUPanelBinding in which the given iterator binding
    * would be found/created.
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
    * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
    * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
    * iterator binding object used to read data in this given JUPanelBinding instance.
    * @param voAttrNames The names of the attributes of this ViewObject rows that contain data
    * to display/edit in the associated text control.
    * @return JUSpinnerBinding An instance of control binding that works with the given JSpinner.
    */
    public static SpinnerModel createNavigationBinding(
                JUFormBinding    formBinding,
                JSpinner         control,
                String           voInstanceName,
                String           voIterName, // temporarily taking nulls for this
                String           voIterBindingName,
                String[]         voAttrNames
            )
    {

        if (!JUIUtil.inDesignTime())
        {

            JUIteratorBinding iterBinding =
                formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName);


            JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding, voAttrNames,
                                                        LIST_OPER_NAVIGATE);


            SpinnerModel m = binding.getModelImpl();

            control.setModel(m);

            binding.refreshNow();

            return m;
        }
        else
        {
            try
            {
                Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerNavigationBinding"); // NOTRANS

				String firstAttribute = "";

                if (voAttrNames != null && voAttrNames.length != 0)
                   firstAttribute = voAttrNames[0];

                int size = (voAttrNames == null) ? 0 : voAttrNames.length;

                StringBuffer stbuf = new StringBuffer(firstAttribute);

                for (int i=1; i<size; i++)
                {
                   stbuf.append(",");
                   stbuf.append(voAttrNames[i]);
                }

                Object [] args = { voInstanceName + "." + stbuf.toString() };

 				java.lang.reflect.Constructor [] constructors = clazz.getConstructors();

				for (int i=0; i < constructors.length; i++)
				{
					java.lang.reflect.Constructor constructor = constructors[i];

					Class[] paramTypes = constructor.getParameterTypes();

					if (paramTypes.length ==1)
					{
					   Object object = constructor.newInstance(args);

					   return (SpinnerModel)object;
					}
				}

				return null;

            }
            catch (Exception e)
            {
                return null;
            }
        }
    }

    /**
    * Use this binding when the JSpinner control is used in LOV mode to update another
    * attribute in a BC4J View Object.
    *
    * <p>
    * @param formBinding The containing JUPanelBinding in which the given iterator binding
    * would be found/created.
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
    * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
    * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
    * iterator binding object used to read/write data in this given JUPanelBinding instance.
    * @param attrNames The name of the attribute of this ViewObject rows that contain data
    * to display/edit in the associated control.
    * @param listVOInstanceName list View Object instance name
    * @return JUSpinnerBinding An instance of control binding that works with the given JSpinner.
    */
    public static SpinnerModel createLovBinding(
                JUFormBinding formBinding,
                JSpinner      control,
                String        voInstanceName,
                String        voIterName, // temporarily taking nulls for this
                String        voIterBindingName,
                String[]      attrNames,
                String        listVOInstanceName )
    {
         return createLovBinding(
                 formBinding, control, voInstanceName, voIterName,
                 voIterBindingName, attrNames, listVOInstanceName, attrNames, null);

    }

    /**
    * Use this binding when two ViewObjects are to be used in this Spinner control: one for displaying
    * of values and the other ViewObject whose rows are updated.
    */
    public static SpinnerModel createLovBinding(
            JUFormBinding    formBinding,
            JSpinner         control,
            String           voInstanceName,
            String           voIterName, // temporarily taking nulls for this
            String           voIterBindingName,
            String[]         voAttrNames, //target vo attribute names
            String           lovVOInstanceName,
            String[]         lovVOAttrNames, //source vo attribute names
            String[]         lovVODisplayedAttrNames)
    {

    	if (!JUIUtil.inDesignTime())
        {
    	    JUIteratorBinding binding = (voInstanceName != null)
    				       ? formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName)
    				       : null;

    	    JUIteratorBinding listValuesBinding = (lovVOInstanceName != null)
    				       ? formBinding.getRangeIterBinding(lovVOInstanceName, null, null, -1)
    				       : null;


    	    JUSpinnerBinding spBinding = new JUSpinnerBinding(
        		control, binding, voAttrNames,
        		listValuesBinding, lovVOAttrNames,
        		lovVODisplayedAttrNames);

            SpinnerModel m = spBinding.getModelImpl();

            spBinding.refreshNow();

    	    return m;

    	}// if (!JUIUtil.inDesignTime())
        else
    	{
    	     try
    	     {
    			   Class defClazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJLovBindingDef");  // NOTRANS

				   java.lang.reflect.Constructor defConstructor = defClazz.getConstructors()[0];

				   Object [] defArgs = { lovVOInstanceName, lovVODisplayedAttrNames, voInstanceName, lovVOAttrNames, voAttrNames };

				   Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerLovBinding");//NOTRANS

				   java.lang.reflect.Constructor [] constructors = clazz.getConstructors();

				   for (int i=0; i < constructors.length; i++)
				   {
						java.lang.reflect.Constructor constructor = constructors[i];

						Class[] paramTypes = constructor.getParameterTypes();

						if (paramTypes.length ==1)
						{
							// constructor with one args
							Object [] args = { defConstructor.newInstance(defArgs) };

							Object object = constructor.newInstance(args);

							return (SpinnerModel)object;
						}
				    }

				   return null;


    	     }
    	     catch (Exception e)
    	     {
                 oracle.jbo.common.DebugDiagnostic.printStackTrace(e);

                 return null;
    	     }
    	}
    }

   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The values for the spinner is specified as a static list of values. The control is used to
   * display/update a particular attribute in a ViewObject.
   *</p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param values   static list of values for the spinner
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding(
            JUFormBinding formBinding,
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            Object        values[] )
    {

       if (!JUIUtil.inDesignTime())
       {

    	 JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                       voInstanceName, voIterName, voIterBindingName);


    	 JUSpinnerBinding binding = new JUSpinnerBinding(
                control, iterBinding, new String[]{attrName},values);

         SpinnerModel m = binding.getModelImpl();

         binding.refreshNow();

         return m;
       }
       else
       {
         try
         {
            String bndClassName =
		        "oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJSpinnerEnumBinding"; // NOTRANS

            Class clazz = Class.forName(bndClassName);

			java.lang.reflect.Constructor[] constructors = clazz.getConstructors();

            for (int i=0; i < constructors.length; i++)
            {
                java.lang.reflect.Constructor constructor = constructors[i];

                Class[] paramTypes = constructor.getParameterTypes();

                if (paramTypes.length ==2)
                {
                    // constructor with two arg
                    StringBuffer buf = new StringBuffer(voInstanceName).append(".").append(attrName);

					Object [] args = { buf.toString(), values };

					Object object = constructor.newInstance(args);

					return (SpinnerModel)object;
                }

            }
			return null;
         }
         catch (Exception e)
         {
            oracle.jbo.common.DebugDiagnostic.printStackTrace(e);

            return null;
         }
       }

    }

   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerListModel. The list of values for the JSpinner
   * is specified through an instance of SpinnerListModel.
   * </p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param slm instance of SpinnerNumberModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding(
            JUFormBinding formBinding,
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerListModel slm )
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
             voInstanceName, voIterName, voIterBindingName);


        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding,
                                                 new String[]{ attrName},
                                                 slm);
        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

        binding.refreshNow();


        return m;
    }

    /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerDateModel. This method also sets an instance of
   * JSpinner.DateEditor as the editor for the control. The format string UI hint defined in the
   * middle tier is used as default format for the editor. The range of values for the JSpinner and
   * the step size is specified through an instance of SpinnerDateModel.
   *</p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param sdm instance of SpinnerDateModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */

    public static SpinnerModel createEnumerationBinding(
            JUFormBinding    formBinding,
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerDateModel sdm )
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                                   voInstanceName, voIterName, voIterBindingName);


        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding,
                                                        new String[]{ attrName},
                                                        sdm);


        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

		binding.refreshNow();

        return m;
    }


   /**
   * Use this method to bind a JSpinner control to a ViewObject/RowSet, identified by voInstanceName.
   * The model object returned extends SpinnerNumberModel. This method also sets an instance of
   * JSpinner.NumberEditor as the editor for the control. The format string UI hint defined in the
   * middle tier is used as default format for the editor. The range of values for the JSpinner and
   * the step size is specified through an instance of SpinnerNumberModel.
   *<p></p>
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control The control instance which should be bound to a ViewObject's attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read data in this given JUPanelBinding instance.
   * @param attrName The name of the attribute of this ViewObject to update
   * @param snm instance of SpinnerNumberModel which provides the range of value
   * for the spinner as well as the step size.
   *
   * @return Object that can be used as model for JSpinner and can display/update
   *         attribute in BC4J ViewOject.
   */
   public static SpinnerModel createEnumerationBinding
        (
            JUFormBinding formBinding,
            JSpinner      control,
            String        voInstanceName,
            String        voIterName, // temporarily taking nulls for this
            String        voIterBindingName,
            String        attrName,
            SpinnerNumberModel snm)
    {
        JUIteratorBinding iterBinding = formBinding.getRowIterBinding(
                   voInstanceName, voIterName, voIterBindingName);


        JUSpinnerBinding binding = new JUSpinnerBinding(control, iterBinding,
                                                        new String[]{ attrName},
                                                        snm);

        SpinnerModel m = binding.getModelImpl();

        control.setModel(m);

        binding.refreshNow();

        return binding.getModelImpl();
    }


    /**
    * JUSpinnerBinding to be used in Navigation mode.
    *
    * <p>
    * @param control The control instance which should be bound to a ViewObject's attribute.
    * @param iterBinding iterator binding to use
    * @param attrNames The names of the attributes of this ViewObject to display
    */
    public JUSpinnerBinding(JSpinner control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            int listOperMode )
    {
        super(control, iterBinding, attrNames,  listOperMode);

        modelImpl = new JUNavigableSpinnerModel();

		setControl(control);
    }

    public JUSpinnerBinding(JSpinner control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            Object[] valueList )
    {
        super(control, iterBinding, attrNames, valueList);

        if(valueList == null)
        {
           valueList = new Object[0];
        }

        modelImpl = new JUStaticUpdateableSpinnerModel(valueList);

		setControl(control);
    }

    public JUSpinnerBinding(JSpinner control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            SpinnerListModel slm )
    {
        super(control, iterBinding, attrNames, (slm.getList()).toArray());

        modelImpl = new JUStaticUpdateableSpinnerModel(slm);

		setControl(control);
    }

    public JUSpinnerBinding(JSpinner  control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            SpinnerDateModel sdm )
    {
		this(control,iterBinding,attrNames,sdm,null);
    }


    public JUSpinnerBinding(JSpinner  control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            SpinnerDateModel sdm,
    		String formatString )
    {
        super(control, iterBinding, attrNames, LIST_OPER_SET_ATTRIBUTE);

        modelImpl = new JUSpinnerDateModel(sdm);

        //List is still Static
        setStaticList(true);

        setControl(control);
    	mFormatStringForConversion = formatString;
    }


    public JUSpinnerBinding(
            JSpinner control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            SpinnerNumberModel snm)
    {

		this(control,iterBinding,attrNames,snm,null);

	}


    public JUSpinnerBinding(
            JSpinner control,
            JUIteratorBinding iterBinding,
            String[] attrNames,
            SpinnerNumberModel snm, String formatString)
    {
        super(control, iterBinding, attrNames, LIST_OPER_SET_ATTRIBUTE);

        modelImpl = new JUSpinnerNumberModel(snm);

        //List is still Static
        setStaticList(true);

        setControl(control);

		mFormatStringForConversion = formatString;
    }



    /**
    * Binds separate ViewObject/RowSets for display and updates to the same listbox.
    * Use this binding constructor to provide a separate iterator binding for update
    * and a separate iterator binding which provides rows for display in the listbox.
    * Optionally, the attributes displayed can be different from the attributes that
    * should be used to update a corresponding set of attributes in the target/updateable
    * ViewObject.
    * <p>
    * @param control JSpinner control instance to associate this binding with.
    * @param iterBinding Provides the RowSet in which the current row is updated
    * based on selection in the listbox.
    * @param attrNames An ordered array of attribute names to update
    * in a ViewObject. This list should have the same number of attributes as
    * in listAttrNames which provides the corresponding attribute names from the
    * display ViewObject/RowSet.
    * @param listRSI Provides the RowSet that is used to display data in the
    * listbox.
    * @param listAttrNames An ordered list of attribute names which are used to
    * get the values to update into the attributes from the attrNames list in the
    * target ViewObject. If this list is null, the attribute names for display
    * are set to the same as attrNames.
    * @param listDisplayedAttrNames An ordered list of attribute names that specify
    * the attributes to display from rows in the display ViewObject/RowSet.
    * If this list is null, attribute names are assumed to be same as in attrNames.
    */
    public JUSpinnerBinding(
           JSpinner control,
           JUIteratorBinding iterBinding,
           String[] attrNames,
           JUIteratorBinding listRSI,
           String[] listAttrNames,
           String[] listDisplayedAttrNames )
    {
        super(control, iterBinding, attrNames, listRSI, listAttrNames,
                        listDisplayedAttrNames);

        modelImpl = new JUDynamicUpdateableSpinnerModel();

        setControl(control);
    }


    protected SpinnerModel getModelImpl()
    {
        return modelImpl;
    }

	public void refreshControl()
	{
		super.refreshControl();

		refreshNow();
	}

	void refreshNow()
    {
        if (getIteratorBinding() != null)
        {
            Row r = getCurrentRow();

            if (r != null)
            {
               updateValuesFromRow(r);
            }
       }
    }


    /**
    * *** For internal framework use only ***
    */
    public void addControlToPanel(Object panel, Object layoutObject,
                                  Object layoutCons)
    {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
    }

	public void setControl(Object control)
	{
		super.setControl(control);

		if (control != null)
		{
			JSpinner spinner = (JSpinner)control;

			if (isNavigationBinding())
			{
				spinner.addChangeListener( new SpinnerChangeListener());
			}
			else if (isLovBinding())
            {
				mEditor = new JUSpinnerEditor(spinner, getListDisplayAttrNames());
			}
            else
            {
                // static binding
                Object model = getModelImpl();

                if (model instanceof SpinnerDateModel)
                {
                    String fmt = getDateFormatString(getFirstAttrName());

                    // so that date format editor can be set
                    spinner.setModel((SpinnerModel)model);

                    mEditor = new JSpinner.DateEditor(spinner, fmt);
                }
                else if (model instanceof SpinnerNumberModel)
                {
                    String fmt = getNumericFormatString(getFirstAttrName());

                    // so that Number format editor can be set
                    spinner.setModel((SpinnerModel)model);

                    mEditor =  new JSpinner.NumberEditor(spinner, fmt);
                }
            }

			if (mEditor != null)
			{
				spinner.setEditor(mEditor);
			}

            spinner.addFocusListener(new JUSVFocusAdapter(this));
		}
	}

    private String getFirstAttrName()
    {
        String[] attrnames = getAttributeNames();

        if (attrnames == null || attrnames.length == 0)
        {
            return null;
        }
        else
        {
            return attrnames[0];
        }
    }

	private boolean isNavigationBinding()
	{
		Object model = getModelImpl();

		if (model instanceof JUNavigableSpinnerModel)
			return true;

		return false;
	}

	private boolean isLovBinding()
	{
		Object model = getModelImpl();

		if (model instanceof JUDynamicUpdateableSpinnerModel)
			return true;

		return false;

	}



    /**
   * Gets the value from the control for the attribute at the given index.
   * (The index is calculated from the list of attributes this control binding is
   * bound to as passed in the constructor).
   * Framework uses this method to get the attribute value from the control
   * and pass it on to the Row object on the BC4J side.
   */
    public Object getValueAt(int attrIndex)
    {
        Object value = modelImpl.getValue();

        if (value == null)
        {
            value =  super.getAttribute(0);
        }

        return value;
    }

	private void setSpinnerEditable(JSpinner spinner, boolean b)
	{
		JComponent editor = spinner.getEditor();

		if (editor instanceof JSpinner.DefaultEditor)
		{
			((JSpinner.DefaultEditor)editor).getTextField().setEditable(b);
			((JSpinner.DefaultEditor)editor).getTextField().setBackground(Color.WHITE);
		}

		else if (editor instanceof JSpinner.DateEditor )
		{
			((JSpinner.DateEditor)editor).getTextField().setEditable(b);
			((JSpinner.DateEditor)editor).getTextField().setBackground(Color.WHITE);
		}
		else if (editor instanceof JSpinner.ListEditor )
		{
			((JSpinner.ListEditor)editor).getTextField().setEditable(b);
			((JSpinner.ListEditor)editor).getTextField().setBackground(Color.WHITE);
		}

		else if (editor instanceof JSpinner.NumberEditor)
		{
			((JSpinner.NumberEditor)editor).getTextField().setEditable(b);
			((JSpinner.NumberEditor)editor).getTextField().setBackground(Color.WHITE);
		}
	}

    /**
    * Updates the control/control-binding with the latest value of the
    * attribute at the given index with the given value. This method is used
    * by the framework to update the control with attribute values from a BC4J row.
    */
    public void setValueAt(Object value, int attrIndex)
    {
	    // BUG # 3620496
	    // When user inserts a new record, a new row with null data is created.
	    // Now if user tries to type a key in the spinner
	    // NPE was thrown at javax.swing.SpinnerListModel.findNextMatch(String)
	    // Prevent user from entering data for navigation mode

	    if (isNavigationBinding() && getControl()!=null)
	    {
	    	setSpinnerEditable((JSpinner)getControl(), false);
	    }

		if (getControl() == null)
		{
			return;
		}

		if (attrIndex > 0)
		{
			//only look up by first attribute.
			return;
		}

		Object val = findMatchingListValue(value);
		
		try
		{
			mValueUpdating = true;

			if (val != null) //
			{
				modelImpl.setValue(val);
			}

			else
			{
				if (modelImpl instanceof JUNavigableSpinnerModel)
				{
					modelImpl.setValue(val);
				}
			}
		}

		finally
		{
			mValueUpdating = false;
		}
		
    }


    public Object findMatchingListValue(Object value)
    {
        Object bnd = getModelImpl();

        if ((bnd instanceof JUSpinnerDateModel) ||
                (bnd instanceof JUSpinnerNumberModel))
        {
            // no enumerated list for these models
            return value;
        }
        else
            return super.findMatchingListValue(value);
    }



    public void setDataValueAt(Object value, int attrIndex)
    {
        // no op.
    }

    /**
    * *** For internal framework use only ***
    */
    public void navigated(NavigationEvent event)
    {
        setupListItems(true, true);
    }

    boolean containsNull(Object[] valueList)
    {
        if (valueList == null)
        {
            return true;
        }
        else
        {
            for (int i=0 ; i < valueList.length; i++)
            {
                if (valueList[i] == null)
                {
                    return true;
                }
            }
        }

        return false;
    }

    protected boolean isViewInitialized()
    {
       if (modelImpl != null)
       {
          //if combomodel's size is zero that means this view needs
          //synchronization with the model.
          if (((ModelHelper)modelImpl).getSize() == 0)
          {
             return (mValueList != null && mValueList.length == 0 );
          }
       }
       return true;
    }

    void callSuperSetupListItems(boolean clean, boolean keepSelectedIndex)
    {
       super.setupListItems(clean, keepSelectedIndex);
    }
  
    protected void setupListItems(boolean clean, boolean keepSelectedIndex)
    {
        settingUpList = true;
        
        if (mValueList == null || clean)
        {
            super.setupListItems(clean, keepSelectedIndex);
        }
        
        Object []valueList = getValueList();
        if (valueList != null)
        {
            ((ModelHelper)modelImpl).setListInternal(valueList);
        }
        
        if (getIteratorBinding() != null)
        {
            Row curRow = getCurrentRow();
            if (curRow != null)
            {
                updateValuesFromRow(curRow);
            }
        }
        settingUpList = false;
    }

    protected void updateAttributeValue(Object value)
    {
        if (!mValueUpdating)
        {
            //super.setAttribute(0, value);
            // Fix for bug 3567676
            compareAndSetAttribute(0, value);
        }
    }

    // update from lov list
    protected void updateTargetFromSelectedValue(Object val)
    {
        if (!mValueUpdating)
        {
            super.updateTargetFromSelectedValue(val);
        }
    }


    protected void navigateTo(ChangeEvent e)
    {
        Object value = null;

        Object source = e.getSource();

        if (source instanceof SpinnerModel)
        {
            value = ((SpinnerModel)source).getValue();
        }
        else if (source instanceof JSpinner)
        {
            value = ((JSpinner)source).getValue();
        }

        int index = findListIndex(value);

        if (index != -1)
        {
            navigateTo(index);
        }
    }

    protected void navigateTo(int rangeIndex)
    {
        RowIterator rsi = getRowIterator();

        if (rsi != null)
        {
           JUPanelBinding panelBinding = ((JUPanelBinding)getFormBinding());

           panelBinding.callBeforeRowNavigated(getIteratorBinding());

           rsi.setCurrentRowAtRangeIndex(rangeIndex);
        }
    }

    String getNumericFormatString(String attrName)
    {
	    if (mFormatStringForConversion == null)
	    	mFormatStringForConversion = getFormatString(attrName);

	    if (mFormatStringForConversion == null)
			mFormatStringForConversion = DEFAULT_NUMERIC_FORMAT_STR;

	    return mFormatStringForConversion;
    }

    String getDateFormatString(String attrName)
    {
	    if (mFormatStringForConversion==null)
	    	mFormatStringForConversion = getFormatString(attrName);

	    if (mFormatStringForConversion == null)
            mFormatStringForConversion = DEFAULT_DATE_FORMAT_STR;

	    return mFormatStringForConversion;
    }



    String getFormatString(String attrName)
    {
        AttributeDef def = findAttributeDef(attrName);

        String fmt = null;

        if (def != null)
        {
            AttributeHints hints = def.getUIHelper();

            ApplicationModule am = getApplicationModule();

            if (am != null)
             {
                 LocaleContext locale = am.getSession().getLocaleContext();

                if (hints.hasFormatInformation(locale))
                {
                     fmt = hints.getFormat(locale);
                }
             }
        }

        return fmt;
    }

    protected String getDefaultDateFormatString()
    {
        return DEFAULT_DATE_FORMAT_STR;
    }

    protected String getDefaultNumericFormatString()
    {
        return DEFAULT_NUMERIC_FORMAT_STR;
    }

    interface ModelHelper
    {
        void setListInternal(Object[] l);
        int  getSize();
    }

    class JUNavigableSpinnerModel
        extends SpinnerListModel
            implements ModelHelper
    {
        JUNavigableSpinnerModel()
        {
            super();
        }

        public void setListInternal(Object[]  l)
        {
            java.util.List list = Arrays.asList(l);

            if (list.size() > 0)
              setList(list);

			else
			{
				java.util.ArrayList al = new java.util.ArrayList(1);
				al.add(null); // user can't set null list as model of JSpinner.
				setList(al);
			}

        }

        public void setValue(Object value)
        {
            //  if ((!isEmptyList()) && ( value != null) && getList().indexOf(value)>=0)
            if ((!isEmptyList()) && getList().indexOf(value)>=0)
            {
                super.setValue(value);
            }
        }

        // when empty argument constructor is used, Swing SpinnerListModel
        // initialize with one aelement list named 'empty'
        //
        // This method checks for this special case

        // see java.swing.SpinnerListModel
        boolean isEmptyList()
        {
          java.util.List elemList = getList();

          int size = elemList.size();

          if (size == 1)
          {
            Object o = elemList.get(0);

            if (( o != null) && ( o.toString().equals("empty")))	//NOTRANS
            {
              return true;
            }
          }

          return (size == 0) ? true : false;
        }

        public int getSize()
        {
          java.util.List elemList = getList();
          return (elemList != null) ? elemList.size() : -1;
        }

    }

    class JUSpinnerDateModel
        extends SpinnerDateModel
            implements ModelHelper
    {
        JUSpinnerDateModel()
        {
            super();
        }

        JUSpinnerDateModel(SpinnerDateModel sdm)
        {
            super.setStart(sdm.getStart());

            super.setEnd(sdm.getEnd());

            super.setCalendarField(sdm.getCalendarField());

            super.setValue(sdm.getValue());
        }

        // implement  ModelHelper
        public void setListInternal(Object[]  l)
        {
            // no op
        }

        public int getSize()
        {
           return 1;
        }

        public void setValue(Object value)
        {

            if (!mValueUpdating)
            {
               if (value instanceof Date)
               {
                   updateAttributeValue(toTimeStamp((Date)value));
               }
               else
               {
                   updateAttributeValue(value);
               }
            }
            else
            {
                // from setValueAt(..)
                Date date = toDate(value);

                if (date != null)
                {
                    super.setValue(date);
                }
            }
        }

        private Date toDate(Object value)
        {
            if (value instanceof Date)
            {
                return (Date)value;
            }

            if (value instanceof oracle.jbo.domain.Date)
            {
                Date date = ((oracle.jbo.domain.Date)value).dateValue();

                return date;
            }


            if (value instanceof String)
            {
                return getDateValue((String)value);
            }

            return null;
        }

        private Date getDateValue(String s)
        {
            String attrName = getAttributeNames()[0];

            String fmtString = getDateFormatString(attrName);

            try
            {
               SimpleDateFormat sdf = new SimpleDateFormat(fmtString);

               return (Date)sdf.parse(s);
            }
            catch(java.text.ParseException pe)
            {
                return null;
            }
        }

        Timestamp toTimeStamp(java.util.Date dateObj)
        {
            if ( dateObj != null )
            {
                Calendar calendar = Calendar.getInstance();

                calendar.setTime(dateObj);

                Timestamp timeStampObject =  new Timestamp(dateObj.getTime());

                return  timeStampObject;
            }
            return null;
        }
    }

    class JUSpinnerNumberModel
        extends SpinnerNumberModel
            implements ModelHelper
    {
        Class valueClass;

        JUSpinnerNumberModel()
        {
            super();
        }

        JUSpinnerNumberModel(SpinnerNumberModel snm)
        {
            super();

            super.setMaximum(snm.getMaximum());

            super.setMinimum(snm.getMinimum());

            super.setStepSize(snm.getStepSize());

            super.setValue(snm.getValue());

            valueClass = snm.getValue().getClass();
        }

        // implement  ModelHelper
        public void setListInternal(Object[]  l)
        {
            // no op
        }

        public int getSize()
        {
           return 1;
        }

        public void setValue(Object value)
        {
            if (!mValueUpdating)
            {
                // from spinner setValue(..)
                updateAttributeValue(value);
            }
            else
            {
                // from setValueAt(..)
                Number number  = toNumber(value);

                if (number != null)
                {
                    super.setValue(number);
                }
            }
        }

        Number toNumber(Object value)
        {
            if (value instanceof Number)
            {
                return (Number)value;
            }

            if (value instanceof oracle.jbo.domain.Number)
            {
				double d = ((oracle.jbo.domain.Number)value).doubleValue();

				return new Double(d);
            }

            if (value instanceof String)
            {
                return getNumericValue((String)value);
            }

            return null;
        }

        Number getNumericValue(String s)
        {
            String attrName = getAttributeNames()[0];

            String fmtString = getNumericFormatString(attrName);

            try
            {

               DecimalFormat df = new DecimalFormat();

               if (fmtString != null)
               {
                   df.applyPattern(fmtString);
               }

               // returns Long or Double., see javadoc
               Number number = df.parse(s);

               if (valueClass.isAssignableFrom(Float.class))
               {
                   return new Float(number.floatValue());
               }

               if (valueClass.isAssignableFrom(Double.class))
               {
                   return new Double(number.doubleValue());
               }

               if (valueClass.isAssignableFrom(Integer.class))
               {
                    return new Integer(number.intValue());
               }

               if (valueClass.isAssignableFrom(Long.class))
               {
                    return new Long(number.longValue());
               }

               return number;

            }
            catch(java.text.ParseException pe)
            {
                return null;
            }
        }
    }

    class JUUpdateableSpinnerModel
        extends SpinnerListModel
    {
        JUUpdateableSpinnerModel()
        {
            super();
        }

        JUUpdateableSpinnerModel(Object[] values)
        {
            super();

            setList(Arrays.asList(values));
        }

        JUUpdateableSpinnerModel(SpinnerListModel slm)
        {
            super();

            setList(slm.getList());
        }

        // implement  ModelHelper

        public int getSize()
        {
          java.util.List elemList = getList();
          return (elemList != null) ? elemList.size() : -1;
        }

        public void setValue(Object value)
        {
            if (value != null && getList().indexOf(value)>=0)
            {
                super.setValue(value);
            }
        }
    }

    class JUStaticUpdateableSpinnerModel
        extends JUUpdateableSpinnerModel
            implements ModelHelper
    {
        JUStaticUpdateableSpinnerModel(Object[] values)
        {
            super(values);
        }

        JUStaticUpdateableSpinnerModel(SpinnerListModel slm)
        {
            super(slm);
        }

        public int getSize()
        {
           return 1;
        }

        public void setListInternal(Object[]  l)
        {
            //no op
        }

        public void setValue(Object value)
        {
            if (!mValueUpdating)
            {
                // from spinner setValue(..)
                updateAttributeValue(value);
            }
            else 
            {
                // from setValueAt(..)
                if (value != null && getList().indexOf(value)>=0)
                {
                    super.setValue(value);
                }
            } 
        }
    }

    class JUDynamicUpdateableSpinnerModel
        extends JUUpdateableSpinnerModel
            implements ModelHelper
    {

        JUDynamicUpdateableSpinnerModel()
        {
            super();
        }

        public int getSize()
        {
          java.util.List elemList = getList();
          return (elemList != null) ? elemList.size() : -1;
        }

        public void setListInternal(Object[]  l)
        {
            java.util.List list = Arrays.asList(l);

            //super.setList(Arrays.asList(l));

            if (list.size() > 0)
                super.setList(list);
            else
            {
              java.util.ArrayList al = new java.util.ArrayList(1);
              al.add(null); // user can't set null list as model of JSpinner.
              super.setList(al);
            }

        }

        public void setValue(Object value)
        {
            if (!mValueUpdating)
            {
                // from spinner setValue(..)
                updateTargetFromSelectedValue(value);
            }
            else 
            {
                // from setValueAt(..)
	        if (value != null && getList().indexOf(value)>=0)
	        {
	            super.setValue(value);
	        }
            } 
        }
    }

    //public static class JUSpinnerEditor extends JSpinner.DefaultEditor
    public static class JUSpinnerEditor extends javax.swing.JTextField
            implements ChangeListener
    {
        String[] displayAttrNames = null;

        JUSpinnerEditor(JSpinner spinner, String[] displayAttrNames)
        {
            spinner.addChangeListener(this);

            this.displayAttrNames = displayAttrNames;

            this.setPreferredSize( new java.awt.Dimension(100,25));
        }

        public void stateChanged(ChangeEvent e)
        {
	        JSpinner spinner = (JSpinner)(e.getSource());

            Object value = spinner.getValue();

            if (value instanceof Row)
            {
                Row row = (Row)value;

                StringBuffer display = new StringBuffer();

                for (int i=0; i < displayAttrNames.length; i++)
                {
                    Object attrValue  = row.getAttribute(displayAttrNames[i]);

                    if (attrValue != null)
                    {
                        display.append(attrValue);
                    }
                }
                setText(display.toString());
            }
            else
            {
				Object obj = spinner.getValue();
	            String text = obj==null? "":obj.toString();
	            setText(text);
             }
        }
    }

    /**
    * Spinner list used to navigate
    */
    class SpinnerChangeListener implements ChangeListener
    {
        public void stateChanged(ChangeEvent e)
        {
            if (!mValueUpdating && !settingUpList)
            {
                navigateTo(e);
            }
        }
    }
}

