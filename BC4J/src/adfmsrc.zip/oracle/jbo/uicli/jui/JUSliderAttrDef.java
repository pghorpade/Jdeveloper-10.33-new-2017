/*
 * @(#)JUSliderAttrDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.JSlider;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JUSliderAttrDef extends JUBoundedRangeDef
{

   public JUSliderAttrDef()
   {
      setControlBindingClassName(JUSliderAttrBinding.class.getName());
   }


   public JUSliderAttrDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames, int min, int max, int ext)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUSliderAttrBinding.class.getName(),
            iterBindingName, attrNames, min, max, ext);
   }


   public JUSliderAttrDef(String name, String iterBindingName, String[] attrNames, int min, int max, int ext)
   {
      this(name, JSlider.class.getName(), null, iterBindingName, attrNames, min, max, ext);
   }

   protected void initSubType()
   {
      setSubType(PNAME_SliderAttr);
   }

   public Object createControl()
   {
      JSlider jCtrl = (JSlider) super.createControl();
      if (jCtrl != null)
      {
        Object initValue = getInitialValue();
  
        if (initValue != null)
        {
           jCtrl.setValue(convertToInt(initValue));
        }
        
        jCtrl.setOrientation((mHorizontal) ? JSlider.HORIZONTAL : JSlider.VERTICAL);
      }
      return jCtrl;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUSliderAttrBinding bind = new JUSliderAttrBinding((JSlider)control, 
                                    getIterBinding((JUFormBinding)formBnd),
                                    getFirstAttrName(), getMin(), getMax(), getExt());

      bind.setName(getName());
      return bind;
   }

}
