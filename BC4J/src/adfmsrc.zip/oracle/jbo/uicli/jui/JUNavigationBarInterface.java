/*
 * @(#)JUNavigationBarInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Implemented by all controls similar to NavigationBar that are interested in 
 * knowing which iterator is currently in focus in a PanelBinding, so that
 * they can update their display of currency, etc. based on the
 * current iterator's position.
 */
public interface JUNavigationBarInterface extends oracle.jbo.uicli.binding.JUNavigationBarInterface
{
}
