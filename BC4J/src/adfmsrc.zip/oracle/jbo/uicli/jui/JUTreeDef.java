/*
 * @(#)JUTreeDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.JScrollPane;
import javax.swing.JTree;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlHierDef;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUUtil;

public class JUTreeDef extends JUCtrlHierDef
{
   private String mScrollPaneClassName;
   private boolean mShowsRootHandles;

   public static final String PNAME_ScrollPaneClass = "ScrollPaneClass";
   public static final String PNAME_ShowsRootHandles = "ShowsRootHandles";
   

   public JUTreeDef()
   {
      //dt does this. setControlClassName(JTree.class.getName());
      setControlBindingClassName(JUTreeBinding.class.getName());
      
      mScrollPaneClassName = JScrollPane.class.getName();
   }
   
   public JUTreeDef(String name, String controlClassName,
                    String controlBindingClassName, String iterBindingName,
                    JUCtrlHierTypeBinding[] typeBindings,
                    String scrollPaneClassName, boolean showsRootHandles)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUTreeBinding.class.getName(),
            iterBindingName, new String[] {}, typeBindings);

      mScrollPaneClassName = scrollPaneClassName;
      mShowsRootHandles = showsRootHandles;
   }

   
   public JUTreeDef(String name, String iterBindingName,
                    JUCtrlHierTypeBinding[] typeBindings,
                    String scrollPaneClassName, boolean showsRootHandles)
   {
      this(name, JTree.class.getName(), null, iterBindingName, 
           typeBindings, scrollPaneClassName, showsRootHandles);
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_ScrollPaneClass)) != null)
      {
         mScrollPaneClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_ShowsRootHandles)) != null)
      {
         mShowsRootHandles = convertToBoolean(val);
      }
   }

   
   public String getScrollPaneClassName()
   {
      return mScrollPaneClassName;
   }

   
   public boolean isShowsRootHandles()
   {
      return mShowsRootHandles;
   }

   
   public Object createControl()
   {
      Object control;

      if (JTree.class.getName().equals(getControlClassName()))
      {
         control = new JTree(new Object[] {});
      }
      else
      {
         control = super.createControl();
      }

      if (control instanceof JTree)
      {
         ((JTree) control).setShowsRootHandles(mShowsRootHandles);
      }

      return control;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JTree jTree = (JTree) control;
      String[] attrNames = getAttrNames();
      String attrName = null;

      if (attrNames != null && attrNames.length > 0)
      {
         attrName = attrNames[0];
      }

      JUTreeBinding jTreeBnd = new JUTreeBinding((JTree) control, getIterBinding((JUFormBinding)formBnd),
                                                 attrName, getTypeBindings());

      if (mScrollPaneClassName != null)
      {
         JScrollPane jScrollPane = (JScrollPane) JUUtil.createNewInstance(mScrollPaneClassName);

         jScrollPane.setViewportView(jTree);
         jTreeBnd.setLayoutObject(jScrollPane);
      }

      return jTreeBnd;
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_ScrollPaneClass, valueTab);
      readXMLBoolean(xmlElement, PNAME_ShowsRootHandles, valueTab);
   }

   
 
}
