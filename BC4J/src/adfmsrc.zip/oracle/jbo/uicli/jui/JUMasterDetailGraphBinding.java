/*
 * @(#)JUMasterDetailGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;


import java.io.InputStream;
import oracle.dss.graph.Graph;

import oracle.dss.util.DataSource;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Data source for the BI Graph bean. This binding should be used for
 * Graphs which require multiple values per marker. High-Low-Close stock
 * chart is one example, which needs three values per marker. 
 *
 * The detail table contains series data for the Graph. Each row represents one 
 * marker. The number of columns in the detail should match the number of 
 * values required for a marker. The detail table represents one 'series' 
 * of data in the Graph. 
 *
 * @see JUSingleTableGraphBinding
 */
public class JUMasterDetailGraphBinding
	extends oracle.jbo.uicli.graph.JUMasterDetailGraphBinding
	implements DataSource
{

    public static JUMasterDetailGraphBinding  getInstance(
                        JUPanelBinding formBinding, 
                        Graph         control,
                        int           graphType,
                        String        voInstanceName,
                        String        voIterName, 
                        String        voIterBindingName,
                        String        seriesLabelAttributeName,
                        String        childAccessorAttributeName,
                        String[]      dataValueAttrNames,
                        String        groupLabelAttrName)
    {
        control.setGraphType(graphType);
    
        return getInstance(formBinding, control, voInstanceName, voIterName, 
                           voIterBindingName, seriesLabelAttributeName,
                           childAccessorAttributeName,dataValueAttrNames,
                           groupLabelAttrName, getNumberOfColumnPerMarker(graphType));
    }
    
    public static JUMasterDetailGraphBinding  getInstance(
                        JUPanelBinding formBinding, 
                        Graph         control,
                        String        voInstanceName,
                        String        voIterName, 
                        String        voIterBindingName,
                        String        seriesLabelAttributeName,
                        String        childAccessorAttributeName,
                        String[]      dataValueAttrNames,
                        String        groupLabelAttrName,
                        int numberOfColumnValuesPerMarker)
    {
        String attrNames[] = buildAttributeListWithLabel(dataValueAttrNames, 
                                                         groupLabelAttrName);
    
        JUIteratorBinding iterBinding = (JUIteratorBinding)formBinding.getIteratorBinding(
                                          voInstanceName, 
                                          voIterName, 
                                          voIterBindingName, -1);
    
        JUMasterDetailGraphBinding bind = new JUMasterDetailGraphBinding(control, 
                                            iterBinding,
                                            seriesLabelAttributeName,
                                            childAccessorAttributeName,
                                            attrNames,
                                            numberOfColumnValuesPerMarker );
        return bind;
    }

	public JUMasterDetailGraphBinding(Graph control, 
				  /* master dataset supplies series values*/
				  JUIteratorBinding seriesBinding, 
				  String  seriesLabelAttributeName,
				  String childAccessorName,
				  String[] dataValueAttrNames,
				  int numberOfColumnValuesPerMarker)
	{
		super(control, seriesBinding, seriesLabelAttributeName, childAccessorName, 
			   dataValueAttrNames, numberOfColumnValuesPerMarker);
			  
	} 

	public JUMasterDetailGraphBinding(Graph control, 
				  /* master dataset supplies series values*/
				  JUIteratorBinding seriesBinding, 
				  String  seriesLabelAttributeName,
				  String childAccessorName,
				  String[] dataValueAttrNames,
				  int numberOfColumnValuesPerMarker,
				  String graphPropertiesFileName)
	{
		super(control, seriesBinding, seriesLabelAttributeName, childAccessorName, 
			   dataValueAttrNames, numberOfColumnValuesPerMarker, 
               graphPropertiesFileName);
	}


	public JUMasterDetailGraphBinding(Graph control, 
				  /* master dataset supplies series values*/
				  JUIteratorBinding seriesBinding, 
				  String  seriesLabelAttributeName,
				  String childAccessorName,
				  String[] dataValueAttrNames,
				  int numberOfColumnValuesPerMarker,
				  InputStream is)
	{
		super(control, seriesBinding, seriesLabelAttributeName, childAccessorName, 
              dataValueAttrNames, numberOfColumnValuesPerMarker, is);
	} 

    public Object getControlModel(Object control)
    {
        init((Graph)control, mGraphPropertiesStream);

        return this;
    }

    

}

