/*
 * @(#)JUMasterDetailGraphDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.dss.graph.Graph;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlRangeDef;
import oracle.jbo.uicli.binding.JUFormBinding;

public class JUMasterDetailGraphDef extends JUCtrlRangeDef
{
   public static final String PNAME_ColumnLabels = "ColumnLabels";

   public static final String PNAME_SeriesLabelName  = "SeriesLabel";

   public static final String PNAME_ChildAccessorAttrName  = "ChildAccessorAttrName";

   public static final String PNAME_GroupLabel  = "GroupLabel";
   
   public static final String PNAME_NumberOfValuesPerMarker  = "NumberOfValuesPerMarker";
   
   private String[] mColumnLabels = null;

   private String mSeriesLabelAttrName;

   private String mChildAccessorAttrName;

   private String mGroupLabel;

   private int mNumberOfValuesPerMarker=1;

   /**
    * For internal use only
    */
   public JUMasterDetailGraphDef()
   {
      super();
   }

   public JUMasterDetailGraphDef(String name, String controlClassName, 
                     String controlBindingClassName, String iterBindingName, 
                     String seriesLabelAttrName,
                     String childAccessorAttrName,
                     String[] attrNames, int numberOfValuesPerMarker)
   {
        super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : 
                        JUMasterDetailGraphBinding.class.getName(),
            iterBindingName, attrNames);

        mSeriesLabelAttrName = seriesLabelAttrName;

        mChildAccessorAttrName = childAccessorAttrName;

        mNumberOfValuesPerMarker = numberOfValuesPerMarker;
   }


   public String[] getColumnLabels()
   {
        return mColumnLabels;
   }

   public String getSeriesLabelAttrName()
   {
       return mSeriesLabelAttrName;
   }

   public String getGroupLabel()
   {
       return mGroupLabel;
   }

   int getNumberOfValuesPerMarker()
   {
       return mNumberOfValuesPerMarker;
   }

   public String getChildAccessorAttrName()
   {
       return this.mChildAccessorAttrName;
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_ColumnLabels)) != null)
      {
         mColumnLabels = (String[]) val;
      }

      if ((val = initValues.get(PNAME_SeriesLabelName)) != null)
      {
        mSeriesLabelAttrName = (String) val;
      }

      if ((val = initValues.get(PNAME_ChildAccessorAttrName)) != null)
      {
        mChildAccessorAttrName = (String) val;
      }

      if ((val = initValues.get(PNAME_GroupLabel)) != null)
      {
         this.mGroupLabel = (String) val;
      }

      if ((val = initValues.get(PNAME_NumberOfValuesPerMarker)) != null)
      {
         String v = (String) val;

         mNumberOfValuesPerMarker = Integer.valueOf(v).intValue();
      }
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      Graph graph = (Graph)control;
      

      JUMasterDetailGraphBinding graphBinding =  
            new JUMasterDetailGraphBinding((Graph)control,
                    /* master dataset supplies series values*/
                 getIterBinding((JUFormBinding)formBnd),
				 getSeriesLabelAttrName(),
                 getChildAccessorAttrName(),
                 getAttrNames(), 
                 getNumberOfValuesPerMarker());

      graphBinding.setName(getName());

      return graphBinding;
   }
   
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(2);
      Object val;
      
      readXMLStringArray(xmlElement, PNAME_ColumnLabels, valueTab);

      if ((val = valueTab.get(PNAME_ColumnLabels)) != null)
      {
         mColumnLabels  = (String[]) val;
      }
   }

  
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_SeriesLabelName, valueTab);

      Object val;

      if ((val = valueTab.get(PNAME_SeriesLabelName)) != null)
      {
         this.mSeriesLabelAttrName = (String) val;
      }

      if ((val = valueTab.get(PNAME_ChildAccessorAttrName)) != null)
      {
          mChildAccessorAttrName = (String) val;
      }

      if ((val = valueTab.get(PNAME_GroupLabel)) != null)
      {
          this.mGroupLabel = (String) val;
      }

      if ((val = valueTab.get(PNAME_NumberOfValuesPerMarker)) != null)
      {
         String v = (String) val;

         mNumberOfValuesPerMarker = Integer.valueOf(v).intValue();
      }
   }
   
  
}
