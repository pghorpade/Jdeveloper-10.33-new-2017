/*
 * @(#)JUGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;


import oracle.dss.graph.Graph;

import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 *  Data source for the Perspective chart bean.
 *
 */
public abstract class JUGraphBinding
      extends oracle.jbo.uicli.graph.JUGraphBinding
    
{
    /**
    *  Constructor
    *
    *  @param iterBinding Supplies label for columns and data values for 
    *         the chart. Last column is treated as label.
    */
    public JUGraphBinding(Graph control, 
            JUIteratorBinding iterBinding, 
            String[] dataValueAttrNames)
    {
        super(control, iterBinding, dataValueAttrNames);
    } 

}






