/*
 * @(#)JUProgressBarAttrDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.JProgressBar;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JUProgressBarAttrDef extends JUBoundedRangeDef
{

   public JUProgressBarAttrDef()
   {
      setControlBindingClassName(JUProgressBarAttrBinding.class.getName());
   }


   public JUProgressBarAttrDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames, int min, int max, int ext)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUProgressBarAttrBinding.class.getName(),
            iterBindingName, attrNames, min, max, ext);
   }


   public JUProgressBarAttrDef(String name, String iterBindingName, String[] attrNames, int min, int max, int ext)
   {
      this(name, JProgressBar.class.getName(), null, iterBindingName, attrNames, min, max, ext);
   }

   protected void initSubType()
   {
      setSubType(PNAME_ProgressBarAttr);
   }

   public Object createControl()
   {
      JProgressBar jCtrl = (JProgressBar) super.createControl();
      if (jCtrl != null)
      {
        Object initValue = getInitialValue();
  
        if (initValue != null)
        {
           jCtrl.setValue(convertToInt(initValue));
        }
        
        jCtrl.setOrientation((mHorizontal) ? JProgressBar.HORIZONTAL : JProgressBar.VERTICAL);
      }
      return jCtrl;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUProgressBarAttrBinding bind = new JUProgressBarAttrBinding((JProgressBar)control, 
                                    getIterBinding((JUFormBinding)formBnd),
                                    getFirstAttrName(), getMin(), getMax());

      bind.setName(getName());
      return bind;
   }

}
