/*
 * @(#)JUTableFormatEditor.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.text.ParseException;
import javax.swing.AbstractCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.text.DefaultFormatterFactory;

import oracle.adf.model.binding.DCBindingContainer;

public class JUTableFormatEditor extends AbstractCellEditor implements JUTableCellEditor
{

   JFormattedTextField mJFormattedTextField = new JFormattedTextField();
   JUFormattedTextFieldBinding.Convertor mConvertor = null;


    public JUTableFormatEditor(DefaultFormatterFactory formatterFactory,
                               JUFormattedTextFieldBinding.Convertor convertor)
    {
        mJFormattedTextField.setFormatterFactory(formatterFactory);
        mConvertor = convertor;
    }

    public Object getCellEditorValue()
    {
       if (mJFormattedTextField.getText().equals(""))
       {
           mJFormattedTextField.setValue(null);
       }

       try
       {
           mJFormattedTextField.commitEdit();
       }
       catch(java.text.ParseException exc)
       {
           //
       }
       if (mConvertor != null)
       {
           return mConvertor.objectToDomain(mJFormattedTextField.getValue());
       }
       else
       {
          return mJFormattedTextField.getValue();
       }

    }

    //
    // returnt the formatted textfile with the attributes set
    // as the editor component
    //
    public Component getTableCellEditorComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   int row,
                                                   int column)
    {
       if ( mConvertor != null )
           mJFormattedTextField.setValue(mConvertor.domainToObject(value));
       else
           mJFormattedTextField.setValue(value);

       return mJFormattedTextField;
   }

   public void setBindingContainer(DCBindingContainer bindingContainer)
   {
       //does nothing;
   }

   public void setTableBinding(JUTableBinding tableBinding)
   {
       //does nothing;
   }
}
