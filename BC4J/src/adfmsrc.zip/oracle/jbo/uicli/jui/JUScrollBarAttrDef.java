/*
 * @(#)JUScrollBarAttrDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.JScrollBar;

import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

public class JUScrollBarAttrDef extends JUBoundedRangeDef
{

   public JUScrollBarAttrDef()
   {
      setControlBindingClassName(JUScrollBarAttrBinding.class.getName());
   }


   public JUScrollBarAttrDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames, int min, int max, int ext)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUScrollBarAttrBinding.class.getName(),
            iterBindingName, attrNames, min, max, ext);
   }


   public JUScrollBarAttrDef(String name, String iterBindingName, String[] attrNames, int min, int max, int ext)
   {
      this(name, JScrollBar.class.getName(), null, iterBindingName, attrNames, min, max, ext);
   }

   protected void initSubType()
   {
      setSubType(PNAME_ScrollBarAttr);
   }


   public Object createControl()
   {
      JScrollBar jCtrl = (JScrollBar) super.createControl();
      if (jCtrl != null)
      {
        Object initValue = getInitialValue();
  
        if (initValue != null)
        {
           jCtrl.setValue(convertToInt(initValue));
        }
        
        jCtrl.setOrientation((mHorizontal) ? JScrollBar.HORIZONTAL : JScrollBar.VERTICAL);
      }
      return jCtrl;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUScrollBarAttrBinding bind = new JUScrollBarAttrBinding((JScrollBar)control, 
                                    getIterBinding((JUFormBinding)formBnd),
                                    getFirstAttrName(), getMin(), getMax(), getExt());

      bind.setName(getName());
      return bind;
   }

}
