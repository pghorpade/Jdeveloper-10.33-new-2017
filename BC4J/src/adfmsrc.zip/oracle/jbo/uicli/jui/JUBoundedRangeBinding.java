/*
 * @(#)JUBoundedRangeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import javax.swing.BoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.event.ChangeListener;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUCtrlScrollBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements interaction with Swing's BoundedRangeModel and the corresponding JClient binding class
 * for controls that support scrolling, such as JUCtrlScrollBinding. 
 * <p>
 * Apart from the Swing BoundedRangeModel functionality, this class also implements resetting
 * of the control/model values when a BC4J iterator is changed for a JUIteratorBinding via
 * a bindRowSetIterator() method. This class listens to JUIteratorChanged event and resets
 * the current values and range on the associated model.
 */
abstract class JUBoundedRangeBinding extends JUCtrlScrollBinding implements BoundedRangeModel, JUIteratorChangedListener
                                                                  
{
   BoundedRangeModel mSBModel = null;
   boolean mSettingValue = false;

   /**
   * This constructor passes all parameters to it's super.
   */
   public JUBoundedRangeBinding(Component sb, JUIteratorBinding iterBinding,
                             boolean scrollCurrRow, boolean deferAssignValues, boolean useEstRC)
   {
      super(sb, iterBinding, scrollCurrRow, deferAssignValues, useEstRC);
   }
   

   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   //
   // BoundedRangeModel implementation
   //
   
   public int getMinimum()
   {
      return mSBModel.getMinimum();
   }


   public void setMinimum(int newMinimum)
   {
      mSBModel.setMinimum(newMinimum);
   }


   public int getMaximum()
   {
      return mSBModel.getMaximum();
   }


   public void setMaximum(int newMaximum)
   {
      mSBModel.setMaximum(newMaximum);
   }


   public int getValue()
   {
      return mSBModel.getValue();
   }


   public void setValue(int newValue)
   {
      mSBModel.setValue(newValue);
   }


   public void setValueIsAdjusting(boolean b)
   {
      mSBModel.setValueIsAdjusting(b);
   }


   public boolean getValueIsAdjusting()
   {
      return mSBModel.getValueIsAdjusting();
   }


   public int getExtent()
   {
      return mSBModel.getExtent();
   }


   public void setExtent(int newExtent)
   {
      mSBModel.setExtent(newExtent);
   }


   public void setRangeProperties(int value, int extent, int min, int max, boolean adjusting)
   {
      mSBModel.setRangeProperties(value, extent, min, max, adjusting);
   }


   public void addChangeListener(ChangeListener x)
   {
      mSBModel.addChangeListener(x);
   }


   public void removeChangeListener(ChangeListener x)
   {
      mSBModel.removeChangeListener(x);
   }


   /**
   * When the RowSetIterator that this control was working with via its associated
   * IteratorBinding is changed, this method resets the current values and range that
   * this control is working with to reflect the values from the new iterator.
   */
   public void iteratorChanged(String rsiName, NavigatableRowIterator rsi)
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (iter.getName().equals(rsiName)) 
      {
         if (rsi instanceof RowSetIterator) 
         {
            RowSetIterator rsIter = (RowSetIterator)rsi;
            bindRowSetIterator(rsIter);
            if (rsIter.getRowSet() == null || rsIter.getRowSet().isExecuted())
            {
               assignValues();
            }
         }
      }
   }

   //needs to fetch estimated row count eagerly.
   protected boolean needsEstimatedRowCount()
   {
      return true;
   }
}

