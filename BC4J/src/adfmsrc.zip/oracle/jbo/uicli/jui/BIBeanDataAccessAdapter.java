/*
 * @(#)BIBeanDataAccessAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

/**
 * Internal class used to define data source of BI Graph bean.
 * 
 */
class BIBeanDataAccessAdapter
    extends  oracle.jbo.uicli.graph.BIBeanDataAccessAdapter
{
    BIBeanDataAccessAdapter(JUGraphBinding owner)
    {
        super(owner);
    }
}