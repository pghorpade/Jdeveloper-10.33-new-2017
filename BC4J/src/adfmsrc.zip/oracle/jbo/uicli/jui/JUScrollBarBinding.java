/*
 * @(#)JUScrollBarBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JScrollBar;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a JScrollBar control with a BC4J RowSetIterator/ViewObject. Use this binding to
 * use JScrollBar to navigate the current row in a RowSetIterator/ViewObject.
 */
public class JUScrollBarBinding extends JUBoundedRangeBinding implements AdjustmentListener
{

   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {
      setControl(control);
      init((JScrollBar)control);
      refreshControl();
      if (getFormBinding() != null)
      {
         ((JUPanelBinding)getFormBinding()).addIteratorChangedListener(this);
      }
      return getModelImpl((JScrollBar)control);
   }

   /**
   * Binds a JScrollBar control to a BC4J ViewObject such that JScrollBar can be used to 
   * navigate rows in the ViewObject. Optionally, an application can control the
   * scrolling of current row into the current range of rows and use estimated
   * row count APIs to calculate the maximum row count for the display.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control JScrollBar control with which to bind a BC4J ViewObject.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param scrollCurrentRow When true, scrolls the current row into the current range of the ViewObject.
   * @param useEstRC When true, uses getEstimatedRowCount() to calculate the max value for the control.
   */
   public static BoundedRangeModel createViewBinding(JUFormBinding formBinding, 
                                               JScrollBar    control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               boolean       scrollCurrentRow,
                                               boolean       useEstRC)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUScrollBarBinding bind = new JUScrollBarBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       scrollCurrentRow, true, useEstRC);
         bind.refreshControl();
         return bind.getModelImpl(control);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJScrollBarBinding");
            
			java.lang.reflect.Constructor[] constructors = clazz.getConstructors();

            for (int i=0; i < constructors.length; i++)
            {
                java.lang.reflect.Constructor constructor = constructors[i];

                Class[] paramTypes = constructor.getParameterTypes();

                if (paramTypes.length ==3)
                {
                    // constructor with three arg
                    Object [] args = { voInstanceName, new Boolean(scrollCurrentRow), new Boolean(useEstRC) };

					Object object = constructor.newInstance(args);

					return (BoundedRangeModel)object;
                }
            }
			return null;
         }
         catch (Exception e)
         {
            oracle.jbo.common.DebugDiagnostic.printStackTrace(e);  

            return null;
         }
      }
   }
   
   /**
   * @deprecated since 9.0.2 use createViewBinding method instead.
   */
   public static BoundedRangeModel getInstance(JUFormBinding formBinding, 
                                               JScrollBar    control,
                                               String        voInstanceName,
                                               String        voIterName, /*temporarily taking nulls for this*/
                                               String        voIterBindingName,
                                               boolean       scrollCurrentRow,
                                               boolean       useEstRC)
   {
      return createViewBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, scrollCurrentRow, useEstRC);
   }

   /**
   * Binds a JScrollBar control to a BC4J ViewObject such that JScrollBar can be used to 
   * navigate rows in the ViewObject. Optionally, an application can control the
   * scrolling of current row into the current range of rows and use estimated
   * row count APIs to calculate the maximum row count for the display.
   * @param sb JScrollBar control with which to bind a BC4J ViewObject.
   * @param iterBinding An iterator Binding with which this control is associated.
   * @param scrollCurrRow When true, scrolls the current row into the current range of the ViewObject.
   * @param deferAssignValues When true, defers the assignement of JScrollBar values to when the ViewObject query is executed
   * @param useEstRC When true, uses getEstimatedRowCount() to calculate the max value for the control.
   */
   public JUScrollBarBinding(JScrollBar sb, JUIteratorBinding iterBinding,
                             boolean scrollCurrRow, boolean deferAssignValues, boolean useEstRC)
   {
      super(sb, iterBinding, scrollCurrRow, deferAssignValues, useEstRC);

      init(sb);
   }


   private void init(JScrollBar sb)
   {
      mSBModel = getModelImpl(sb);

      if (sb != null)
      {
         if (mSBModel != sb.getModel())
         {
            sb.setModel(mSBModel);
         }
         
         sb.addAdjustmentListener(this);
         sb.addFocusListener(new JUSVFocusAdapter(this));
      }
   }

   
   /**
   * Registers the BoundedRangeModel that this binding works with. If the ScrollBar
   * has a model, this method registers that with this binding and returns the model.
   * If the control or model is null, then this method creates a DefaultBoundedRangeModel
   * and returns that.
   */
   protected BoundedRangeModel getModelImpl(JScrollBar sb)
   {
      BoundedRangeModel sbModel = null;

      if (sb != null)
      {
         sbModel = sb.getModel();
      }

      if (sbModel == null)
      {
         sbModel = new DefaultBoundedRangeModel();
      }

      return sbModel;
   }

   
   /**
   * Sets the current value, extent, minimum, and maximum values for the ScrollBar. 
   */
   public void setValues(int val, int ext, int minVal, int maxVal)
   {
      JScrollBar sb = (JScrollBar) getControl();
      if (sb == null)
      {
         return;
      }
      boolean changeValue = false;

      if (val != sb.getValue())
      {
         changeValue = true;
      }
      if (!changeValue && ext != sb.getVisibleAmount())
      {
         changeValue = true;
      }
      if (!changeValue && minVal != sb.getMinimum())
      {
         changeValue = true;
      }
      if (!changeValue && minVal != sb.getMaximum())
      {
         changeValue = true;
      }
      
      if (!changeValue)
      {
         return;
      }
      
      try
      {
         mSettingValue = true;

         //scrollbar always has an extent of one (when in viewbinding mode).
         ((JScrollBar) getControl()).setValues(val, 1, minVal, maxVal);
      }
      finally
      {
         mSettingValue = false;
      }
   }

   
   /**
   * Sets the current values for this ScrollBar.
   */
   public void setRangeScrollValue(int val)
   {
      ((JScrollBar) getControl()).setValue(val);
   }

   
   /**
   * Sets the current value, extent, minimum, and maximum values for the ScrollBar. 
   */
   public void setRangeScrollValues(int val, int ext, int minVal, int maxVal)
   {
      ((JScrollBar) getControl()).setValues(val, ext, minVal, maxVal);
   }

   
   /**
   * When the current value in the ScrollBar changes, this event handler method updates
   * the associated ViewObject's currency.
   */
   public void adjustmentValueChanged(AdjustmentEvent e) 
   {
      //check for control's valueIsAdjusting to not change the rows till the
      //scrollbar is released. This avoids changing displayed data while
      //the scrollbar is in motion.
      if (!mSettingValue && !mSBModel.getValueIsAdjusting())
      {
         super.setRangeScrollValue(e.getValue());
      }
   }


}

