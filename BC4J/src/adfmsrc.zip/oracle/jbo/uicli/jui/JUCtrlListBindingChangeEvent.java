/* $Header: JUCtrlListBindingChangeEvent.java 25-jul-2006.12:50:24 pillanch Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    pillanch    07/25/06 - bug 5404116
    rvangri     08/26/05 - rvangri_bug-4358971_20050826
    rvangri     08/26/05 - Creation
 */

package oracle.jbo.uicli.jui;

import oracle.jbo.uicli.binding.JUCtrlListBinding;

/**
 * JUCtrlListBinding will notify registered listeners when
 * an unknown value is encountered. This will happen if the UI
 * allows the user to enter free text, rather than pick from a list.
 * The binding will ignore the data by default. It is up to 
 * the listeners to validate the data and potentially add the data.
 *  @version $Header: JUCtrlListBindingChangeEvent.java 25-jul-2006.12:50:24 pillanch Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
public class JUCtrlListBindingChangeEvent extends oracle.jbo.uicli.binding.JUCtrlListBindingChangeEvent
{
  public JUCtrlListBindingChangeEvent(JUCtrlListBinding binding, Object value)
  {
    super(binding, value);
  }
}
