/*
 * @(#)JULOVEditorPropDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import javax.swing.table.TableCellEditor;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.jui.JUTableDef;

public class JULOVEditorPropDef extends JUTableDef.JUEditorPropDef
{
     public final static String PNAME_Lovbinding = "binding";    //NO TRANS
     private String mLovBinding= null;
     JUTableLOVEditor mTableCellLovEditor = null;
     String mAttrName = null;
     String mEditorName = null;

     public JULOVEditorPropDef()
     {

     }

     public void setAttrName(String attrName)
     {
         mAttrName = attrName;
     }

     //
     // Creates and initializes the TableCellEditor for editor of type
     // Spinner, ComboBox
     //
     public JUTableCellEditor  getTableCellEditor()
     {
          if ( mTableCellLovEditor == null )
              mTableCellLovEditor = new JUTableLOVEditor(mAttrName,
                                                              getLovBinding());
          return mTableCellLovEditor;
     }

     public JUTableCellRenderer getTableCellRenderer()
     {
         if(getEditorName().equalsIgnoreCase(JUTableDef.JUEditorPropDef.PNAME_COMBOBOX_TYPE))
         {
             return new JUTableComboBoxRenderer(getLovBinding());
         }
         return null;
     }

     public void init(HashMap initValues)
     {
         super.init(initValues);
         Object val;

         if ((val = initValues.get(PNAME_Lovbinding)) != null)
         {
             mLovBinding = val.toString();
         }

         if ((val = initValues.get(PNAME_EditorName)) != null)
         {
             mEditorName = val.toString();
         }
     }

     public String getEditorName()
     {
          return mEditorName;
     }

     public String getLovBinding()
     {
          return mLovBinding;
     }

     public void setLovBinding(String lovBinding)
     {
        mLovBinding = lovBinding;
     }
     protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
     {
         super.retrieveFromXML(xmlElement, valueTab);
         readXMLString(xmlElement, PNAME_Lovbinding, valueTab);
         readXMLString(xmlElement, PNAME_EditorName, valueTab);

     }
}
