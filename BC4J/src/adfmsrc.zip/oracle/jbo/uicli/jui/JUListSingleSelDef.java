/*
 * @(#)JUListSingleSelDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.JList;
import javax.swing.JScrollPane;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUUtil;

public class JUListSingleSelDef extends JUCtrlListDef
{
   private boolean mShouldScroll = false;
   private String mScrollPaneClassName;

   public static final String PNAME_ShouldScroll = "ShouldScroll";
   public static final String PNAME_ScrollPaneClass = "ScrollPaneClass";
   
   
   public JUListSingleSelDef()
   {
      //dt does this. setControlClassName(JList.class.getName());
      setControlBindingClassName(JUListSingleSelBinding.class.getName());

      mScrollPaneClassName = JScrollPane.class.getName();
   }

   
   public JUListSingleSelDef(String name, String controlClassName,
                             String controlBindingClassName, String iterBindingName,
                             String[] attrNames, boolean staticList,
                             String listVOName, String listRSIName, String[] listAttrNames,
                             Object[] valueList, boolean shouldScroll, String scrollPaneClassName)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUListSingleSelBinding.class.getName(),
            iterBindingName, attrNames, staticList,
            listVOName, listRSIName, listAttrNames, valueList);

      mShouldScroll = shouldScroll;
      mScrollPaneClassName = scrollPaneClassName;
   }


   public JUListSingleSelDef(String name, String iterBindingName,
                             String[] attrNames, boolean staticList,
                             String listVOName, String listRSIName, String[] listAttrNames,
                             Object[] valueList, boolean shouldScroll)
   {
      this(name, JList.class.getName(), null, iterBindingName,
           attrNames, staticList, listVOName, listRSIName, listAttrNames,
           valueList, shouldScroll, JScrollPane.class.getName());
   }

   protected void initSubType()
   {
      setSubType(PNAME_ListSingleSel);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_ShouldScroll)) != null)
      {
         mShouldScroll = convertToBoolean(val);
      }

      if ((val = initValues.get(PNAME_ScrollPaneClass)) != null)
      {
         mScrollPaneClassName = val.toString();
      }
   }

   
   public boolean isShouldScroll()
   {
      return mShouldScroll;
   }

   
   public String getScrollPaneClassName()
   {
      return mScrollPaneClassName;
   }

   
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    int listOperMode)
   {
     return new JUListSingleSelBinding((JList) control, (JUIteratorBinding) iterBinding, attrNames, listOperMode, mShouldScroll);
     //JUComboBoxBinding retVal = new JUComboBoxBinding((JComboBox) control, iterBinding, attrNames, listOperMode);
     //retVal.setName(getName());
     //return retVal;
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    Object[] valueList)
   {
     return new JUListSingleSelBinding((JList)control, (JUIteratorBinding) iterBinding, attrNames, valueList, mShouldScroll);
     //retVal.setName(getName());
     //return retVal;
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    DCIteratorBinding listIterBinding,
    String[] listAttrNames,
    String[] listDisplayAttrNames)
   {
     return new JUListSingleSelBinding((JList)control, (JUIteratorBinding) iterBinding, attrNames, 
                                  (JUIteratorBinding) listIterBinding, listAttrNames, listDisplayAttrNames, mShouldScroll);
     //retVal.setName(getName());
     //return retVal;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JList jList = (JList) control;
      JUListSingleSelBinding jListBnd = null;
      /*
      JUIteratorBinding iterBnd = (JUIteratorBinding)getIterBinding(formBnd);
      if (getListOperMode() == JUListSingleSelBinding.LIST_OPER_NAVIGATE)
      {
         jListBnd = new JUListSingleSelBinding((JList) control, iterBnd, getAttrNames(), getListOperMode(), mShouldScroll);
      }
      else  if (isStaticList())
      {
         Object[] valueList = getValueList();
         String[] labelList = getLabelList();
         
         jListBnd = new JUListSingleSelBinding((JList) control, iterBnd, getAttrNames(), valueList,
                                               mShouldScroll);

         //jListBnd.convertValueList();
      }
      else
      {
         //the List/Lov attribute name should be a plural list of names and not just one attribute.
         jListBnd = new JUListSingleSelBinding((JList) control, iterBnd, getAttrNames(),
                                               (JUIteratorBinding)findListIteratorBinding(formBnd), getListAttrNames(), getListDisplayAttrNames(),
                                               mShouldScroll);
      }
      */
      jListBnd = (JUListSingleSelBinding)super.createControlBindingInstance(control, formBnd);
      jListBnd.setName(getName());

      if (mScrollPaneClassName != null)
      {
         JScrollPane jScrollPane = (JScrollPane) JUUtil.createNewInstance(mScrollPaneClassName);

         jScrollPane.setViewportView(jList);
         jListBnd.setLayoutObject(jScrollPane);
      }

      return jListBnd;
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_ShouldScroll, valueTab);
      readXMLString(xmlElement, PNAME_ScrollPaneClass, valueTab);
   }

 
}
