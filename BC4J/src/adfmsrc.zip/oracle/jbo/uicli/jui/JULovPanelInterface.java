/*
 * @(#)JULovPanelInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import oracle.jbo.RowSetIterator;
import oracle.jbo.Row;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCDataControl;

/**
 * Implements creation of a LOV dialog bound to a BC4J RowSet to display data.
 * Also performs the display of help on the Lov Dialog (if the default LOV dialog is used).
 * In the framework, an inner class implements this interface and displays itself in 
 * a JULovDialog. Applications should create their own implementation of this interface
 * to customize the LOV Dialog display/functionality.
 */
public interface JULovPanelInterface
{
   /**
   * Sets display using data from this RowSet Iterator.
   * Note that on LOV action, this RowSet Iterator's current Row will
   * be used to set the target Row's attributes.
   */
   void bindRowSetIterator(DCDataControl dc, RowSetIterator rsi, String[] lovVODisplayedAttrNames);

   DCIteratorBinding getLovIteratorBinding();

   /**
   * Returns an instance of JPanel to add into an LOV dialog. This method may return
   * null if createLovDialog() is creating and adding a LOV panel into itself.
   */
   JPanel getPanel();

   /**
   * This method is invoked by the framework to display help on the LOV dialog.
   * If applications customize the Lov Panel interface and not the dialog, then this
   * method will get invoked if no helpActionListener is established with the
   * LovButtonBinding to control the help display.
   */
   void helpAction(ActionEvent ev);

   /**
   * Creates a JDialog and returns a JULovDialogInterface that performs interaction
   * with the JULovButtonBinding for display of LOV data.
   */
   JULovDialogInterface createLovDialog(javax.swing.JComponent control);

   /**
   * Returns a String that is displayed in the default JULovDialog as the title
   * of the LOV dialog.
   */
   String getPanelTitle();

   /**
    * Returns the currently selected Row in the Lov Panel, so that the binding
    * uses this row to update the target values.
    */
   Row getSelectedRow();

   /**
    * @deprecated since 9.0.5
    */
   void bindRowSetIterator(RowSetIterator rsi, String[] lovVODisplayedAttrNames);
}
