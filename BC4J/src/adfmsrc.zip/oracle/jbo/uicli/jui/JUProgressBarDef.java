/*
 * @(#)JUProgressBarDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.JProgressBar;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlScrollDef;
import oracle.jbo.uicli.binding.JUFormBinding;

public class JUProgressBarDef extends JUCtrlScrollDef
{
   private boolean mHorizontal;

   public static final String PNAME_Horizontal = "Horizontal";
   
   
   public JUProgressBarDef()
   {
      //dt does this. setControlClassName(JProgressBar.class.getName());
      setControlBindingClassName(JUProgressBarBinding.class.getName());
   }

   
   public JUProgressBarDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         boolean scrollCurrRow, boolean deferAssignValues,
                         boolean useEstRC, boolean horizontal)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUProgressBarBinding.class.getName(),
            iterBindingName, scrollCurrRow, deferAssignValues, useEstRC);

      mHorizontal = horizontal;
   }


   public JUProgressBarDef(String name, String iterBindingName,
                         boolean scrollCurrRow, boolean deferAssignValues,
                         boolean useEstRC, boolean horizontal)
   {
      this(name, JProgressBar.class.getName(), null, iterBindingName,
           scrollCurrRow, deferAssignValues, useEstRC, horizontal);
   }


   protected void initSubType()
   {
      setSubType(PNAME_ProgressBar);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_Horizontal)) != null)
      {
         mHorizontal = convertToBoolean(val);
      }
   }

   
   public boolean isHorizontal()
   {
      return mHorizontal;
   }

   
   public Object createControl()
   {
      Object control = super.createControl();

      if (control instanceof JProgressBar)
      {
         ((JProgressBar) control).setOrientation((mHorizontal) ? JProgressBar.HORIZONTAL : JProgressBar.VERTICAL);
      }

      return control;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      return new JUProgressBarBinding((JProgressBar) control, getIterBinding((JUFormBinding)formBnd),
                                    isScrollCurrRow(), isDeferAssignValues(), isUseEstRC());
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_Horizontal, valueTab);
   }

  
}
