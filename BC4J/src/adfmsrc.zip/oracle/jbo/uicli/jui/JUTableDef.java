/*
 * @(#)JUTableDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.adf.model.binding.DCDefBase;
import oracle.jbo.JboException;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlRangeDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUUtil;
import oracle.jbo.common.Diagnostic;

public class JUTableDef extends JUCtrlRangeDef
{
   private String mScrollPaneClassName;
   private ArrayList mAttrPropList;
   private int mColumnSort = JUTableBinding.CS_RANGE;
   private int mScrollMode;

   public static final String PNAME_ScrollPaneClass = "ScrollPaneClass";
   public static final String PNAME_ColumnSort = "ColumnSort";
   public static final String PNAME_ColumnSort_currentRange = "currentRange";
   public static final String PNAME_ColumnSort_entireCollection = "entireCollection";
   public static final String PNAME_ScrollMode = "Scrolling";

   public static final String PNAME_ScrollMode_ACTIVE_STR     = "active";
   private static final String PNAME_ScrollMode_CYCLE_ROWS_STR = "cyclerows"; //obsolete
   private static final String PNAME_ScrollMode_NO_UPDATE_STR  = "noupdate"; //obsolete
   public static final String PNAME_ScrollMode_PASSIVE_STR     = "passive";
   public static final String DEFAULT = "Default";

   public JUTableDef()
   {
      setControlBindingClassName(JUTableBinding.class.getName());
   }


   public JUTableDef(String name, String controlClassName,
                     String controlBindingClassName, String iterBindingName,
                     String[] attrNames, String scrollPaneClassName)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUTableBinding.class.getName(),
            iterBindingName, attrNames);

      mScrollPaneClassName = scrollPaneClassName;
   }


   public JUTableDef(String name, String iterBindingName, String[] attrNames,
                     String scrollPaneClassName)
   {
      this(name, JTable.class.getName(), null, iterBindingName, attrNames, scrollPaneClassName);
   }


   protected void initSubType()
   {
      setSubType(PNAME_Table);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      if ((val = initValues.get(PNAME_ColumnSort)) != null)
      {
         //for backward compatiblity also compare true/false.
         if (PNAME_ColumnSort_entireCollection.equals(val)) 
         {
            mColumnSort = JUTableBinding.CS_FULL;
         }
         else if (PNAME_ColumnSort_currentRange.equals(val))
         {
            mColumnSort = JUTableBinding.CS_RANGE;
         }
         else
         {
            mColumnSort = (convertToBoolean(val)) ? JUTableBinding.CS_RANGE : JUTableBinding.CS_NONE;
         }
      }

      if ((val = initValues.get(PNAME_ScrollMode)) != null)
      {
         mScrollMode = convertScrollingModeValue(val.toString());
      }

      if ((val = initValues.get(PNAME_ScrollPaneClass)) != null)
      {
         mScrollPaneClassName = val.toString();
      }
   }

   int convertScrollingModeValue(String str)
   {
      if (str != null) 
      {
       /*  if (PNAME_ScrollMode_CYCLE_ROWS_STR.equals(str)) 
         {
            return JUTableBinding.TBL_SCROLL_CYCLEROWS;
         }
         if (PNAME_ScrollMode_NO_UPDATE_STR.equals(str)) 
         {
            return JUTableBinding.TBL_SCROLL_NOUPDATE;
         }*/
         if(PNAME_ScrollMode_PASSIVE_STR.equals(str)){
             return JUTableBinding.TBL_SCROLL_PASSIVE;
         }
      }
      return JUTableBinding.TBL_SCROLL_ACTIVE;
   }

   public String getScrollPaneClassName()
   {
      return mScrollPaneClassName;
   }

   public ArrayList getAttrPropList()
   {
     return mAttrPropList;
   }

   public void setAttrPropList(ArrayList list)
   {
      mAttrPropList = list;
   }

   public void setScrollMode(int mode)
   {
      switch (mode) 
      {
//      case JUTableBinding.TBL_SCROLL_NOUPDATE:
//      case JUTableBinding.TBL_SCROLL_CYCLEROWS:
      case JUTableBinding.TBL_SCROLL_PASSIVE:
      case JUTableBinding.TBL_SCROLL_ACTIVE:
         mScrollMode = mode;
         break;

      default:
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("Warning! JUTableDef: Improper scroll mode value ingored.");
         }
      }
   }

   int getColumnSortMode()
   {
      return mColumnSort;
   }

   public int getScrollMode()
   {
      return mScrollMode;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JTable jTable = (JTable) control;
      JUTableBinding jTabBnd = new JUTableBinding((JTable) control,
                                                  getIterBinding((JUFormBinding)formBnd),
                                                  getAttrNames());
      jTabBnd.setScrollMode(mScrollMode);
      jTabBnd.setName(getName());

      if ( mAttrPropList != null )
      {
         Iterator iter = mAttrPropList.iterator();
         HashMap columnProperties = new HashMap(getAttrNames().length);
         while(iter.hasNext())
         {
             JUTableAttrPropDef attrProp = (JUTableAttrPropDef)iter.next();
             TableColumn tc = new TableColumn();
             tc.setMinWidth(attrProp.getWidth());
             JUEditorPropDef editorProp = attrProp.getEditorPropDef();
             //
             //  If editor prop is not null for the Attribute then get
             //  the TableCellEditor and set it for the column.
             //
             if ( editorProp != null )
             {
                 JUTableCellEditor editor = editorProp.getTableCellEditor();
                 editor.setBindingContainer(formBnd);
                 editor.setTableBinding(jTabBnd);
                 tc.setCellEditor(editor);
                 JUTableCellRenderer renderer = editorProp.getTableCellRenderer();
                 if(renderer != null)
                 {
                     renderer.setBindingContainer(formBnd);
                     renderer.setTableBinding(jTabBnd);
                     tc.setCellRenderer(renderer);
                 }
             }
             columnProperties.put(attrProp.getAttrName(),tc);
         }
         jTabBnd.setColumnProperties(columnProperties);
         jTabBnd.updateColumnModel(jTable);
      }

      if (mScrollPaneClassName != null)
      {
         JScrollPane jScrollPane = (JScrollPane) JUUtil.createNewInstance(mScrollPaneClassName);

         jScrollPane.setViewportView(jTable);
         jTabBnd.setLayoutObject(jScrollPane);
      }
      return jTabBnd;
   }

   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      // load the attribute property
      loadAttrPropList(xmlElement);
   }

   public void loadAttrPropList(DefElement xmlElement)
   {
     com.sun.java.util.collections.ArrayList propList =
            xmlElement.getChildrenList(JUTableAttrPropDef.ELEMENT_NAME);

     if ( propList == null || propList.size() == 0)
        return;

     //
     // iterate thru the list of AttrProp def and populate the list.
     //
     com.sun.java.util.collections.Iterator iter = propList.iterator();
     mAttrPropList = new ArrayList(getAttrNames().length);
     while(iter.hasNext())
     {
         DefElement attrPropDefXML = (DefElement)iter.next();
         JUTableAttrPropDef attrProp = new JUTableAttrPropDef();
         attrProp.loadFromXML(attrPropDefXML);
         mAttrPropList.add(attrProp);
     }
   }

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      readXMLString(xmlElement, PNAME_ScrollPaneClass, valueTab);
      readXMLString(xmlElement, PNAME_ColumnSort, valueTab);
      readXMLString(xmlElement, PNAME_ScrollMode, valueTab);
   }

   //
   public static class JUTableAttrPropDef extends DCDefBase
   {
      public static final String ELEMENT_NAME = "AttrProp";  //NO TRANS
      public static final String PNAME_AttrName = "name";    //NO TRANS
      public static final String PNAME_Width = "width";      //NO TRANS

      String mAttrName = null;
      int mWidth = 0;
      JUEditorPropDef mEditorDef;

      public JUTableAttrPropDef()
      {

      }

      public JUTableAttrPropDef(String attrName, int width)
      {
        mWidth = width;

        mAttrName = attrName;
      }

      public String getXMLElementTag()
      {
          return ELEMENT_NAME;
      }

      public String getAttrName()
      {
          return mAttrName;
      }

      public int getWidth()
      {
            return mWidth;
      }

      public void init(HashMap initValues)
      {
            super.init(initValues);

           Object val;
           if ((val = initValues.get(PNAME_AttrName)) != null)
           {
               mAttrName = val.toString();
           }
           if ((val = initValues.get(PNAME_Width)) != null)
           {
                if ( val.equals(DEFAULT) )
                {
                    mWidth = 0;
                }
                else
                try
                {
                    mWidth = convertToInt(val.toString());
                }
                catch(NumberFormatException nfe)
                {
                    mWidth = 0;
                }
           }
      }

      protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
      {
          super.retrieveFromXML(xmlElement, valueTab);

          readXMLString(xmlElement, PNAME_AttrName, valueTab);

          readXMLString(xmlElement, PNAME_Width, valueTab);
      }

      public JUEditorPropDef getEditorPropDef()
      {
        return mEditorDef;
      }

      public void setEditorPropDef(JUEditorPropDef editorDef)
      {
         mEditorDef = editorDef;
      }


      public void loadChildrenFromXML(DefElement xmlElement)
      {
          super.loadChildrenFromXML(xmlElement);

          loadEditorDef(xmlElement);
      }

      //
      // Load the editor prop def
      //
      public void loadEditorDef(DefElement xmlElement)
      {
          DefElement editorDefXML =  xmlElement.findChildElement(JUEditorPropDef.ELEMENT_NAME);
          if ( editorDefXML != null )
          {
              try
              {
                  //
                  // read the runtime class name from and instantiate the call
                  // to load the corresponding the Editor Def
                  //
                  String rtClassName =
                       editorDefXML.getAttribute(JUEditorPropDef.PNAME_RTClass);
                  Class clz = Class.forName(rtClassName);
                  JUEditorPropDef editorDef = (JUEditorPropDef)clz.newInstance();
                  editorDef.loadFromXML(editorDefXML);
                  editorDef.setAttrName(mAttrName);
                  mEditorDef = editorDef;
              }
              catch(InstantiationException iex)
              {
                  throw new JboException(iex.getMessage());
              }
              catch(ClassNotFoundException ex)
              {
                  throw new JboException(ex.getMessage());
              }
              catch (IllegalAccessException iAex)
              {
                  throw new JboException(iAex.getMessage());
              }
          }
      }

   }

   public abstract static class JUEditorPropDef extends DCDefBase
   {
        public static final String ELEMENT_NAME = "EditorDef";  //NO TRANS
        public static final String PNAME_DTClass = "DTClass";   //NO TRANS
        public static final String PNAME_RTClass = "RTClass";   //NO TRANS
        public static final String PNAME_EditorName = "Name";   //NO TRANS

        public static final String PNAME_FORMATTTED_TEXTFIELD_TYPE = "Formatted TextField";
        public static final String PNAME_COMBOBOX_TYPE = "ComboBox";
        public static final String PNAME_SPINNER_TYPE = "Spinner";

        String mDTClassName = null;
        String mRTClassName = null;

        public abstract JUTableCellEditor  getTableCellEditor();
        public abstract JUTableCellRenderer  getTableCellRenderer();
        public abstract void setAttrName(String attrName);
        public abstract String getEditorName();

        public String getRTClassName()
        {
            return mRTClassName;
        }

        public String getDTClassName()
        {
          return mDTClassName;
        }

        public String getXMLElementTag()
        {
          return ELEMENT_NAME;
        }

        public void init(HashMap initValues)
        {
            super.init(initValues);
            Object val;

            if ((val = initValues.get(PNAME_DTClass)) != null)
            {
                mDTClassName = val.toString();
            }
            if ((val = initValues.get(PNAME_RTClass)) != null)
            {
                 mRTClassName = val.toString();
            }
        }

        protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
        {
            super.retrieveFromXML(xmlElement, valueTab);
            readXMLString(xmlElement, PNAME_DTClass, valueTab);
            readXMLString(xmlElement, PNAME_RTClass, valueTab);
        }
   }

}
