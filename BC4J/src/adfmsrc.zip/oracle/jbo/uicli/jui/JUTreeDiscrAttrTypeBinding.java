/*
 * @(#)JUTreeDiscrAttrTypeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import javax.swing.Icon;
import oracle.jbo.uicli.binding.JUCtrlHierTypeBinding;

/**
 * Implements rules that govern the display of rows of a given ViewObject type in a JTree.
 * This class determines:
 * <ul>
 * <li>The attribute to display for each row that matches the discriminator
 * columnValue for the discriminator attribute in that row.</li>
 * <li>The accessor (if any) to expand when the coresponding node is expanded.</li>
 * </ul>
 *
 * @see oracle.jbo.RowIterator
 * @see oracle.jbo.uicli.jui.JUTreeBinding
 * @see javax.swing.JTree
 */
public class JUTreeDiscrAttrTypeBinding
       extends JUCtrlHierTypeBinding
{
   public JUTreeDiscrAttrTypeBinding()
   {
   }
   
   /*
   * Constructor without any custom icons.
   *
   * @param voTypeName Fully qualified name of the definition/type of the ViewObject for this node.
   * @param childAttrName Name of the attribute of this viewobject to display in the tree node.
   * @param discrColumnName Name of the attribute of this viewobject which acts as a discriminator column.
   * @param discrColumnValue Value of the discriminator attribute which should match for a row of this ViewObject type to be displayed as a node in the tree.
   * @param childAccessorName Name of the Accessor attribute of this viewobject to execute to display child nodes of this node.
   */
   public JUTreeDiscrAttrTypeBinding(String typeBindingName, 
                                     String voTypeName,
                                     String childAttrName,
                                     String discrColumnName, 
                                     String discrColumnValue,
                                     String childAccessorName
                                     )
   {
      this(typeBindingName, voTypeName, childAttrName, discrColumnName, discrColumnValue, childAccessorName, null, null, null);
   }

   /*
   * @deprecate since 5.0 use the constructor with typeBindingName instead
   */
   public JUTreeDiscrAttrTypeBinding(String voTypeName,
                                     String childAttrName,
                                     String discrColumnName, 
                                     String discrColumnValue,
                                     String childAccessorName
                                     )
   {
      this(null, voTypeName, childAttrName, discrColumnName, discrColumnValue, childAccessorName, null, null, null);
   }

   /*
   * Constructor with any custom icons. Use this method to create an instance of this node-type
   * if custom-icons are to be displayed when rendering nodes of this node type.
   *
   * @param voTypeName Fully qualified name of the definition/type of the ViewObject for this node.
   * @param childAttrName Name of the attribute of this viewobject to display in the tree node.
   * @param discrColumnName Name of the attribute of this viewobject which acts as a discriminator column.
   * @param discrColumnValue Value of the discriminator attribute which should match for a row of this ViewObject type to be displayed as a node in the tree.
   * @param childAccessorName Name of the Accessor attribute of this viewobject to execute to display child nodes of this node.
   * @param leafIcon Used to display nodes when it is the leaf node.
   * @param openIcon Used to display nodes when they are in expanded state.
   * @param closedIcon Used to display nodes when they are in closed state.
   */
   public JUTreeDiscrAttrTypeBinding(String typeBindingName, 
                                     String voTypeName,
                                     String childAttrName,
                                     String discrColumnName, 
                                     String discrColumnValue,
                                     String childAccessorName,
                                     Icon leafIcon, 
                                     Icon openIcon, 
                                     Icon closedIcon)
   {
      super(voTypeName, discrColumnName, discrColumnValue, 
            childAccessorName, childAttrName, 
            leafIcon, openIcon, closedIcon);
      setName(typeBindingName);
   }

   /**
   * Returns false
   */
   public boolean matchViewObjectType(String str)
   {
      return false;
   }

   /**
   * Returns true to indicate that this node type supports discriminator attribute types.
   */
   public boolean isDiscrColumnType()
   {
      return true;
   }

   /**
   * Returns true if the given object matches the discriminator attribute value for this node type.
   */
   public boolean isSameDiscrValue(Object val)
   {
      return (mDiscrColumnValue.equals(val));
   }

}
