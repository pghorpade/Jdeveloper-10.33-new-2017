/*
 * @(#)JUIUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Window;
import java.lang.reflect.Constructor;
import oracle.jbo.common.JBOClass;

public class JUIUtil
{
   public final static String DESIGNTIME_PROPERTY = "inJUIDesigntime";

   public static Frame getParentFrame(Component parentComponent)
   {
      while (true)
      {
         if (parentComponent == null)
         {
            return null;
         }

         if (parentComponent instanceof Frame)
         {
            return (Frame) parentComponent;
         }

         parentComponent = parentComponent.getParent();
      }
   }

   public static Window getParentWindow(Component parentComponent)
   {
      while (true)
      {
         if (parentComponent == null)
         {
            return null;
         }

         if (parentComponent instanceof Window)
         {
            return (Window) parentComponent;
         }

         parentComponent = parentComponent.getParent();
      }
   }

   public static boolean inDesignTime()
   {
      try
      {
         if (System.getProperty(DESIGNTIME_PROPERTY) != null)
         {
            return true;
         }
      }
      catch(Exception e)
      {
         return false;
      }

      return false;
   }

   public static JUPanelBinding createNewDTPanelBinding(JUPanelBinding pb)
   {
      if (inDesignTime())
      {
         try
         {
            Class clz = JBOClass.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTPanelBinding");
            Constructor ctr = clz.getConstructor(new Class[] {java.lang.String.class});
            return (JUPanelBinding)ctr.newInstance(new Object[]{pb.getName()});
         }
         catch (Exception e)
         {
            throw new oracle.jbo.JboException(e);
         }
      }
      return pb;
   }
}
