/*
 * @(#)JUPanelDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
//import javax.swing.JPanel;
import oracle.jbo.JboException;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.uicli.binding.JUControlDef;
import oracle.jbo.uicli.binding.JUFormDef;
import oracle.jbo.uicli.layout.JULayoutConsDef;
import oracle.jbo.uicli.layout.JULayoutDef;
import oracle.adf.model.binding.DCDefBase;

public class JUPanelDef extends JUFormDef
{
   public JUPanelDef()
   {
      this(null, null, JUPanelBinding.class.getName());
   }


   public JUPanelDef(DefPersistable outer)
   {
      super(outer);
   }

   
   public JUPanelDef(JULayoutDef layoutDef, String formClassName, String formBindingClassName)
   {
      super(layoutDef, formClassName, formBindingClassName);
   }


   protected void initSubType()
   {
      setSubType(PNAME_Panel);
   }
   
   public JULayoutDef createLayoutDef(String subType, HashMap initValues)
   {
      JULayoutDef layoutDef = null;

      if (subType.equals("JULayoutDefXY"))
      {
         layoutDef = new JULayoutDefXY();
      }
      else
      {
         throw new JboException("Unknown layout type " + subType);
      }

      layoutDef.init(initValues);

      return layoutDef;
   }
   
   
   public JUControlDef createControlDef(String subType, HashMap initValues)
   {
      JUControlDef ctrlDef = null;

      if (subType.equals(DCDefBase.PNAME_Action))
      {
         ctrlDef = new JUActionDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Button))
      {
         ctrlDef = new JUButtonDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ButtonGroup))
      {
         ctrlDef = new JUButtonGroupDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ComboBox))
      {
         ctrlDef = new JUComboBoxDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_DefaultControl))
      {
         ctrlDef = new JUDefaultControlDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Label))
      {
         ctrlDef = new JULabelDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ListSingleSel))
      {
         ctrlDef = new JUListSingleSelDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ScrollBar))
      {
         ctrlDef = new JUScrollBarDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Table))
      {
         ctrlDef = new JUTableDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_TextField))
      {
         ctrlDef = new JUTextFieldDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Tree))
      {
         ctrlDef = new JUTreeDef();
      }
      else
      {
         throw new JboException("Unknown control type " + subType);
      }

      ctrlDef.init(initValues);
      
      return ctrlDef;
   }

   
   public JULayoutConsDef createLayoutConsDef(String subType, HashMap initValues)
   {
      JULayoutConsDef layoutConsDef = null;

      if (subType.equals("JULayoutConsDefXY"))
      {
         layoutConsDef = new JULayoutConsDefXY();
      }
      else  if (subType.equals("JULayoutConsDefXYGroup"))
      {
         layoutConsDef = new JULayoutConsDefXYGroup();
      }
      else
      {
         throw new JboException("Unknown layout constraint type " + subType);
      }

      layoutConsDef.init(initValues);

      return layoutConsDef;
   }
}
