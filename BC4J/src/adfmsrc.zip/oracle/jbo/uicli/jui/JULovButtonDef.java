/*
 * @(#)JULovButtonDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;
import javax.swing.JButton;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlListDef;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import java.awt.Point;
import java.awt.Dimension;

public class JULovButtonDef extends JUCtrlListDef
{
   private boolean mSearchFlag;
   private String  mTitle;
   private boolean mTestFlag = false;
   private Point mLocation = null;
   private Dimension mDimension = null;
   private String mCustomPanelClassName;

   public static final String PNAME_SearchFlag  = "AllowSearch";
   public static final String PNAME_Title       = "Title";
   public static final String PNAME_TestFlag    = "TestFlag";
   public static final String PNAME_LocationX    = "LocationX";
   public static final String PNAME_LocationY    = "LocationY";
   public static final String PNAME_Width    = "Width";
   public static final String PNAME_Height    = "Height";
   public static final String PNAME_CustomPanel = "CustomPanel";
   
   
   

   public JULovButtonDef()
   {
      //dt does this. setControlClassName(JComboBox.class.getName());
      setControlBindingClassName(JULovButtonBinding.class.getName());
   }

   protected void initSubType()
   {
      setSubType(PNAME_LovButton);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_SearchFlag)) != null)
      {
         mSearchFlag = convertToBoolean(val);
      }
      if ((val = initValues.get(PNAME_Title)) != null)
      {
         mTitle = (String)val;
      }
      //simply the existence of TestFlag will lead to modeless lov dialog 
      if ((val = initValues.get(PNAME_TestFlag)) != null)
      {
         mTestFlag = convertToBoolean(val);
      }
	  
	  Object val1;
      if ((val = initValues.get(PNAME_LocationX)) != null && (val1 = initValues.get(PNAME_LocationY)) != null )
      {
         double xCor =  convertToDouble(val);
		 double yCor =  convertToDouble(val1);
		 mLocation = new Point();
		 mLocation.setLocation(xCor, yCor);
		 
      }
	  
      if ((val = initValues.get(PNAME_Width)) != null && (val1 = initValues.get(PNAME_Height)) != null )
      {
	  	double width =  convertToDouble(val);
       	double height =  convertToDouble(val1);
       	mDimension = new Dimension();
		mDimension.setSize(width,height);
      }

	  if ((val = initValues.get(PNAME_CustomPanel)) != null)
      {
         mCustomPanelClassName = (String)val;
      }
	  
   }
	
   public String getCustomPanelClassName()
   {
      return mCustomPanelClassName;
   }
   
   public boolean isSearchable()
   {
      return mSearchFlag;
   }

   public String getTitle()
   {
      return mTitle;
   }

   public void setTitle(String title)
   {
       mTitle = title;
   }
   
   public boolean isTestFlag()
   {
      return mTestFlag;
   }

   
   public Point getLocation()
   {
      return mLocation;
   }

   public void setLocation(Point location)
   {
       mLocation = location;
   }

   public Dimension getDimension()
   {
   	  return mDimension;
   }

   public void setDimension(Dimension d)
   {
       mDimension = d;
   }
   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JULovButtonBinding retVal = null;
      JUIteratorBinding iterBnd = (JUIteratorBinding)getIterBinding(formBnd);
	  if (mCustomPanelClassName == null)
    {	
      retVal = new JULovButtonBinding((JButton) control, iterBnd, getAttrNames(),
                                      (JUIteratorBinding)findListIteratorBinding(formBnd), 
                                      getListAttrNames(), getListDisplayAttrNames(),
                                      mSearchFlag, mTitle, mLocation);
	  } else
    {
		 try
      {
       JULovPanelInterface panel = (JULovPanelInterface)JBOClass.newInstance(JBOClass.forName(mCustomPanelClassName));
          
			/*retVal = new JULovButtonBinding((JButton) control, iterBnd, getAttrNames(),
                                            (JUIteratorBinding)findListIteratorBinding(formBnd), 
                                            getListAttrNames(), getListDisplayAttrNames(), 
                                            true, null, null);
		 	*/
		 	retVal = new JULovButtonBinding((JButton) control, iterBnd, getAttrNames(),
                                            (JUIteratorBinding)findListIteratorBinding(formBnd), 
                                            getListAttrNames(), getListDisplayAttrNames(), 
                                            mSearchFlag, mTitle, null);
      retVal.mLovPanel = panel;

			
			/*retVal = new JULovButtonBinding((JButton) control, iterBnd, getAttrNames(),(JUIteratorBinding)findListIteratorBinding(formBnd), getListAttrNames(), getListDisplayAttrNames(),panel);	
			*/
			
     }
     catch (JboException je)
     {
        throw je;
     }
		 catch(ClassNotFoundException ex)
     {
         formBnd.reportException(ex);
     } 
     catch (Exception e)
     {
          throw new JboException(e);
     }
    }
      //set the lov button to bring up the lov dialog as modeless 
      retVal.mModalTestFlag = mTestFlag;
	    retVal.setDimension(mDimension);
      retVal.setName(getName());

      return retVal;
   }


   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_SearchFlag, valueTab);
      readXMLString(xmlElement, PNAME_Title, valueTab);
      readXMLString(xmlElement, PNAME_TestFlag, valueTab);
	  readXMLString(xmlElement, PNAME_LocationX, valueTab);
	  readXMLString(xmlElement, PNAME_LocationY, valueTab);
	  readXMLString(xmlElement, PNAME_Width, valueTab);
	  readXMLString(xmlElement, PNAME_Height, valueTab);
      readXMLString(xmlElement, PNAME_CustomPanel, valueTab);
	  
   }
   
   static private double convertToDouble(Object val)
   {
      if (val instanceof Double)
      {
         return ((Integer) val).doubleValue();
      }
      else
      {
         return new Double((String) val).doubleValue();
      }
   }
   
}
