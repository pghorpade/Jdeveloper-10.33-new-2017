/* $Header: JUCtrlListBindingChangeListener.java 25-jul-2006.12:50:43 pillanch Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Listener interface used to publish changes from JUCtrlListBinding

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    pillanch    07/25/06 - bug 5404116
    rvangri     08/26/05 - rvangri_bug-4358971_20050826
    rvangri     08/26/05 - Creation
 */

package oracle.jbo.uicli.jui;

/**
 * Implementers of this interface can register with a JUCtrlListBinding
 * to be notified about events.
 * 
 *  @version $Header: JUCtrlListBindingChangeListener.java 25-jul-2006.12:50:43 pillanch Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
public interface JUCtrlListBindingChangeListener extends oracle.jbo.uicli.binding.JUCtrlListBindingChangeListener
{
}
