/*
 * @(#)JUTableLOVEditor.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTable;

import javax.swing.SpinnerModel;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.jbo.uicli.binding.JUCtrlListBinding;
import oracle.adf.model.binding.DCDefBase;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;

public class JUTableLOVEditor extends AbstractCellEditor implements JUTableCellEditor
{
  String mBindingName = null;
  String mAttrName = null;
  DCBindingContainer mBindingContainer = null;
  JUTableBinding mTableBinding = null;
  Component mComponent = null;
  Object mValue = null;

  public JUTableLOVEditor(String attrName, String bindingName)
  {
      mAttrName = attrName;
      mBindingName = bindingName;
  }

  public void setBindingContainer(DCBindingContainer bindingContainer)
  {
      mBindingContainer = bindingContainer;
  }

  public void setTableBinding(JUTableBinding tableBinding)
  {
      mTableBinding = tableBinding;
  }
    
 //
 // returns the value set by the editor when requestd by the JTable.
 //
  public Object getCellEditorValue()
  {
       Object obj = getControlBinding().getCurrentRow().getAttribute(mAttrName);
       return obj;
  }

   public Component getTableCellEditorComponent(JTable table,
                                                Object value,
                                                boolean isSelected,
                                                int row,
                                                int column)
    {
        mTableBinding.getModel().resetRSICurrency(row);
        Component comp = getComponent();
        return comp;
    }

   public Component getComponent()
   {
       JUCtrlListBinding binding = getControlBinding();

       if ( binding == null )
           return null;

      //
      // sets and returns the control depending on the binding.
      //
      JUCtrlInputValueHandler inputHandler = binding.getInputValueHandler();
      if ( inputHandler instanceof JUComboBoxBinding )
      {
           JComboBox cb;
           if ( ((JUComboBoxBinding)binding).getControl() == null )
           {
               cb = new JComboBox();
               ((JUComboBoxBinding)binding).setControl(cb);
           }
           cb = (JComboBox)((JUComboBoxBinding)binding).getControl();
           cb.setModel(((JUComboBoxBinding)binding).getModelImpl(cb));
           ((JUComboBoxBinding)binding).refreshControl();
           return cb;
     }
     else if ( inputHandler instanceof JUSpinnerBinding )
     {
         JSpinner spinner;
         if(  ((JUSpinnerBinding)binding).getControl() == null )
         {
             spinner  = new JSpinner();
             spinner.setModel((SpinnerModel)((JUSpinnerBinding)binding).getControlModel(spinner));
         }
         spinner = (JSpinner)((JUSpinnerBinding)binding).getControl();
         ((JUSpinnerBinding)binding).refreshControl();
         return spinner;
     }
     return null;

   }
   public JUCtrlListBinding getControlBinding()
   {
       //
       // returns the Binding from the Binding container
       //
       ArrayList controlList = mBindingContainer.getCtrlBindingList();
       int size = controlList.size();
       Object bind;

       for (int i = 0; i < size; i++)
       {
           bind = controlList.get(i);
           if (bind instanceof JUCtrlListBinding)
           {
                if ( ((JUCtrlListBinding)bind).getName().equals(mBindingName) )
                {
                    return ((JUCtrlListBinding)bind);
                }
           }
        }
        return null;
   }
}
