/*
 * @(#)JUScrollBarAttrBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.awt.Component;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.event.ChangeListener;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

/**
 * Implements binding a JScrollBar control with an Attribute in a BC4J RowSet.
 * <p>
 * This binding sets the minimum, maximum, and the extent values of the ScrollBar. When currency changes
 * in the associated rowset, it displays the associated value by adjusting the ScrollBar between the minimum
 * and maximum values. Note that the minimum and maximum values should be provided such that all possible
 * values of the associated attribute in a RowSet can be displayed in the ScrollBar.
 */
public class JUScrollBarAttrBinding extends JUCtrlAttrsBinding implements BoundedRangeModel, AdjustmentListener 
{
   private BoundedRangeModel mSBModel = null;
   boolean mSettingValue = false;
   int mMax = 100;
   int mMin = 0;
   int mExt = 1;

   /**
   * Binds the given ScrollBar control to display and update values from the given attribute
   * in a BC4J RowSet.
   * @param control JScrollBar control to bind a BC4J attribute with.
   * @param iterBinding Iterator binding that provides the RowSet with which this binding should work.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JScrollBar displays (what the starting value should be in
   * the JScrollBar control).
   * @param max Maximum value that the JScrollBar displays (what the end value should be in the control).
   * @param ext Determines the Extent value for the JScrollBar control.
   */
   public JUScrollBarAttrBinding(JScrollBar control, JUIteratorBinding iterBinding, String attrName,
                              int min, int max, int ext)
   {
      super(control, iterBinding, new String[] { attrName });

      mMin = min;
      mMax = max;
      mExt = ext;
      init(control);

   }


   private void init(JScrollBar sb)
   {
      mSBModel = getModelImpl(sb);

      if (sb != null)
      {
         if (mSBModel != sb.getModel())
         {
            sb.setModel(mSBModel);
         }
         // this set has no effect as subsequent setModel cleans it up.
         sb.setMinimum(mMin);
         sb.setMaximum(mMax);
         //sb.setUnitIncrement(mExt);
         
         /*
         sb.setExtent(mExt);
         sb.setPaintTicks(true);
         sb.setMajorTickSpacing(mExt);
         sb.setSnapToTicks(true);
         */
         // this set has no effect as subsequent setModel cleans it up.


         sb.addAdjustmentListener(this);
         sb.addFocusListener(new JUSVUpdateableFocusAdapter(this, 0));
      }
   }


   /**
   * Registers the BoundedRangeModel that this binding works with. If the ScrollBar
   * has a model, this method registers that with this binding and returns the model.
   * If the control or model is null, then this method creates a DefaultBoundedRangeModel
   * and returns that.
   */
   protected BoundedRangeModel getModelImpl(JScrollBar sb)
   {
      // BoundedRangeModel sbModel = null;
      BoundedRangeModel sbModel = mSBModel;

      if (sbModel == null)
      {
         if (sb != null)
         {
            sbModel = sb.getModel();
         }

         if (sbModel == null)
         {
            sbModel = new DefaultBoundedRangeModel();
         }
      }

      return sbModel;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
      ((JPanel) panel).add((Component) layoutObject, layoutCons);
   }

   
   /**
   * Returns the current value indicated by the JScrollBar control.
   */
   public Object getValueAt(int attrIndex)
   {
      return new Integer(((JScrollBar) getControl()).getValue());
   }


   boolean mInit = false;
   /**
   * Sets the current value in the JScrollBar control. This method adjusts the position of JScrollBar 
   * current value indicator based on the input value and the minimum and maximum value the JScrollBar
   * is set to handle.
   */
   public void setValueAt(Object value, int attrIndex)
   {
      JScrollBar sb  = (JScrollBar)getControl();
      if (mSBModel != null && sb != null) 
      {
         try
         {
            mSettingValue = true;
            if (!mInit) 
            {
               mInit = true;
               sb.setMinimum(mMin);
               sb.setMaximum(mMax);
            }
   
            Integer integerVal = (Integer)oracle.jbo.domain.TypeFactory.getInstance(java.lang.Integer.class, value);
            if (integerVal != null) 
            {
                  
               if (sb != null) 
               {
                  sb.setValue(integerVal.intValue());
               }
               else
               {
                  mSBModel.setValue(integerVal.intValue());
               }
            }
         }
         finally
         {
            mSettingValue = false;
         }
      }
      //((JScrollBar) getControl()).setText(value == null ? "" : value.toString());
   }


   /**
   * Use this method to update the ScrollBar value, as well as the value in the associated BC4J attribute.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setValueAt(value, attrIndex);

      setAttribute(0, value);
   }

   /**
   * Sets the BC4J attribute value based on the change in the JScrollBar current value.
   */
   public void adjustmentValueChanged(AdjustmentEvent e) 
   {
      //check for control's valueIsAdjusting to not change the rows till the
      //scrollbar is released. This avoids changing displayed data while
      //the scrollbar is in motion.
      if (!mSettingValue && !mSBModel.getValueIsAdjusting() && !((JScrollBar)e.getSource()).getValueIsAdjusting())
      {
         try
         {
            setAttribute(0, getValueAt(0));
         }
         catch (oracle.jbo.JboException ex)
         {
            reportException(ex, true);
            //rethrow to abort the scrollbar operation.
            throw ex;
         }
      }
   }

   //
   // BoundedRangeModel implementation
   //
   
   public int getMinimum()
   {
      return mSBModel.getMinimum();
   }


   public void setMinimum(int newMinimum)
   {
      mSBModel.setMinimum(newMinimum);
   }


   public int getMaximum()
   {
      return mSBModel.getMaximum();
   }


   public void setMaximum(int newMaximum)
   {
      mSBModel.setMaximum(newMaximum);
   }


   public int getValue()
   {
      return mSBModel.getValue();
   }


   public void setValue(int newValue)
   {
      mSBModel.setValue(newValue);
   }


   public void setValueIsAdjusting(boolean b)
   {
      mSBModel.setValueIsAdjusting(b);
   }


   public boolean getValueIsAdjusting()
   {
      return mSBModel.getValueIsAdjusting();
   }


   public int getExtent()
   {
      return mSBModel.getExtent();
   }


   public void setExtent(int newExtent)
   {
      mSBModel.setExtent(newExtent);
   }


   public void setRangeProperties(int value, int extent, int min, int max, boolean adjusting)
   {
      mSBModel.setRangeProperties(value, extent, min, max, adjusting);
   }


   public void addChangeListener(ChangeListener x)
   {
      mSBModel.addChangeListener(x);
   }


   public void removeChangeListener(ChangeListener x)
   {
      mSBModel.removeChangeListener(x);
   }


   /**
   * Gets the associated View's model object.
   */
   public Object getControlModel(Object control)
   {
      setControl(control);
      init((JScrollBar)control);
      refreshControl();
      return getModelImpl((JScrollBar)control);
   }



   /**
   * Creates a binding for the JScrollBar control.
   * @param formBinding The containing JUPanelBinding in which the given iterator binding
   * would be found/created.
   * @param control JScrollBar control with which to bind a BC4J attribute.
   * @param voInstanceName Name of the instance of the ViewObject in a BC4J ApplicationModule.
   * @param voIterName Runtime instance name of the iterator in the ViewObject (optional).
   * @param voIterBindingName Instance name of the iterator binding that uniquely identifies an
   * iterator binding object used to read/write data in this given JUPanelBinding instance.
   * @param attrName The attribute name in the RowSet with which this binding works.
   * @param min Minimum value that the JScrollBar displays (what the starting value should be in
   * the JScrollBar control).
   * @param max Maximum value that the JScrollBar displays (what the end value should be in the control).
   * @param ext Determines the Extent value for the JScrollBar control.
   */
   public static BoundedRangeModel createAttributeBinding(JUFormBinding formBinding, 
                                                  JScrollBar control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  int           min,
                                                  int           max,
                                                  int           ext)
   {
      if (!JUIUtil.inDesignTime())
      {
         JUScrollBarAttrBinding bind = new JUScrollBarAttrBinding(control, 
                                       formBinding.getRowIterBinding(voInstanceName, voIterName, voIterBindingName),
                                       attrName, min, max, ext);
         bind.refreshControl();
         BoundedRangeModel model = bind.getModelImpl(control);
         return model;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTJScrollBarAttrBinding");
            
			java.lang.reflect.Constructor[] constructors = clazz.getConstructors();

            for (int i=0; i < constructors.length; i++)
            {
                java.lang.reflect.Constructor constructor = constructors[i];

                Class[] paramTypes = constructor.getParameterTypes();

                if (paramTypes.length ==4)
                {
                    // constructor with four arg
                    
					Object [] args = {(new StringBuffer(voInstanceName)
                                  .append('.').append(attrName)).toString(),
                              Integer.toString(min), 
                              Integer.toString(max), 
                              Integer.toString(ext)};

					Object object = constructor.newInstance(args);
					
					return (BoundedRangeModel)object;
                }
            }
			return null;
         }
         catch (Exception e)
         {
            oracle.jbo.common.DebugDiagnostic.printStackTrace(e);

            return null;
         }
      }
   }

   /**
   * @deprecated since 9.0.2 use createAttributeBinding method instead.
   */
   public static BoundedRangeModel getInstance(JUFormBinding formBinding, 
                                                  JScrollBar control,
                                                  String        voInstanceName,
                                                  String        voIterName, /*temporarily taking nulls for this*/
                                                  String        voIterBindingName,
                                                  String        attrName,
                                                  int           min,
                                                  int           max,
                                                  int           ext)
   {
      return createAttributeBinding(formBinding, control, voInstanceName, voIterName, voIterBindingName, attrName, min, max, ext);
   }
}
