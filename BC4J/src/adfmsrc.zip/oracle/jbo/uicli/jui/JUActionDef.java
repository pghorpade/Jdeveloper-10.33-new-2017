/*
 * @(#)JUActionDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.jui;

import java.util.HashMap;

import javax.swing.AbstractButton;
import javax.swing.JButton;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlActionDef;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUIteratorBinding;

public class JUActionDef extends JUCtrlActionDef
{
   //private String mText;

   //public static final String PNAME_Text = "Text";
   
   
   public JUActionDef()
   {
      //dt does this. setControlClassName(JButton.class.getName());
      setControlBindingClassName(JUActionBinding.class.getName());
   }

   
   public JUActionDef(String name, String controlClassName,
                      String controlBindingClassName, String iterBindingName,
                      int action)
   {
      super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : JUActionBinding.class.getName(),
            iterBindingName, action);
   }

   
   public JUActionDef(String name, String iterBindingName, int action)
   {
      super(name, JButton.class.getName(), null, iterBindingName, action);
   }

   
   protected void initSubType()
   {
      setSubType(PNAME_Action);
   }

   /*
   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_Text)) != null)
      {
         mText = val.toString();
      }
   }
   */

   
   public void setText(String text)
   {
      super.setText(text);
   }

   
   public Object createControl()
   {
      Object control = super.createControl();

      if (control instanceof AbstractButton)
      {
         AbstractButton jButton = (AbstractButton) control;

         if (getText() != null)
         {
            jButton.setText(getText());
         }
         else
         {
            String btnText = jButton.getText();
            if (btnText == null || btnText.length() == 0)
            {
               jButton.setText(getName());
            }
         }
      }

      return control;
   }

   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      int action = getAction();
      JUActionBinding bind;
      if (action != JUActionBinding.ACTION_INVOKE_METHOD)
      {
         JUIteratorBinding iter = (getIterBindingName() != null) 
                                  ? getIterBinding((JUFormBinding)formBnd)
                                  : null;
         bind = new JUActionBinding(control, iter, action);
         if (mMethodInfo != null) 
         {
            bind.setupMethodInfo(formBnd, mMethodInfo);
         }
      }
      else
      {
         bind = new JUActionBinding(control, 
                                    formBnd,
                                    mMethodInfo);
      }
      bind.setBindingContainer(formBnd);
      return bind;
   }

   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      //readXMLString(xmlElement, PNAME_Text, valueTab);
   }

 
}
