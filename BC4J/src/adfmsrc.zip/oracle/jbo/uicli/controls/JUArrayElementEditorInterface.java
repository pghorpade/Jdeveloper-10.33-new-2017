/*
 * @(#)JUArrayElementEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import oracle.jbo.uicli.binding.JUControlBinding;
import java.awt.event.KeyEvent;
import java.awt.Component;

/**
* This interface defines the methods that is required
* by JUArrayComboBox to communicate with an editor that 
* can edit an element/item in the JUArrayComboBox.
* <p>
* Implementing classes can define their own key combinations
* that ends in call to the edit method in this interface, by
* returning true for hasCustomEditKey() method and returning
* true for isEditKey(KeyEvent) after matching the key with
* a editor specific key combination. By default if hasCustomEditKey()
* returns false, then pressing Ctrl+Enter in the combo box editor
* invokes this edit() method.
*/
public interface JUArrayElementEditorInterface
{
   /**
   * Edits the given element (could be null), which is part of the
   * array attribute in the given JUControlBinding being edited by 
   * the given combo UI component.
   * @param element An element from the Array that is to be edited. This value
   * could be null indicating that the ComboBox is expecting a new value to 
   * be created in the editor.
   * @param ctrlBinding The JUControlBinding object that provides JClient context
   * to the editor
   * @param combo A Swing component that should be used to locate the editor dialog.
   * @return The new value for an element in an Array.
   */
   Object edit(Object element, JUControlBinding ctrlBinding, Component combo);

   /**
   * Returns true if this editor is interested in parsing/matching the user keys
   * as typed in the combobox editor.
   */
   boolean hasCustomEditKey();

   /**
   * Returns true, if the key in the KeyEvent matches the key desired by this
   * editor as the invocation key.
   */
   boolean isEditKey(KeyEvent e);
}

