/*
 * @(#)JUErrorHandlerDlg.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.InterruptedException;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import oracle.jbo.JboException;
import oracle.jbo.common.StringManager;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUErrorHandler;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.jui.JUIUtil;

import oracle.adf.model.binding.DCErrorHandler;
import oracle.adf.model.binding.DCBindingContainer;

class JUErrorDialog extends JDialog
{
   private JPanel mPanel = new JPanel();
   private JButton mOKButton = new JButton(StringManager.getString(UIMessageBundle.class.getName(),
                                                                   UIMessageBundle.STR_OK_BUTTON_TEXT, null, null));
   private JButton mDetailsButton;
   private JButton mStackTracesButton;

   private JTextArea mTextArea = new JTextArea(5, 80);

   private String mErrorMessage;
   private Exception  mEx;
   private boolean mShowDetails;
   private boolean mShowStackTraces;

   private String mDetailsButtonText = StringManager.getString(UIMessageBundle.class.getName(),
                                                               UIMessageBundle.STR_DETAILS_BUTTON_TEXT, null, null);
   private String mNoDetailsButtonText = StringManager.getString(UIMessageBundle.class.getName(),
                                                                 UIMessageBundle.STR_HIDE_DETAILS_BUTTON_TEXT, null, null);
   
   private String mStackTracesButtonText = StringManager.getString(UIMessageBundle.class.getName(),
                                                                   UIMessageBundle.STR_STACK_TRACE_BUTTON_TEXT, null, null);
   private String mNoStackTracesButtonText = StringManager.getString(UIMessageBundle.class.getName(),
                                                                     UIMessageBundle.STR_HIDE_STACK_TRACE_BUTTON_TEXT, null, null);
   
   private String mDetailSep1 = StringManager.getString(UIMessageBundle.class.getName(),
                                                        UIMessageBundle.STR_DETAIL_MSG_SEPARATOR1, null, null);
   private String mDetailSep2 = StringManager.getString(UIMessageBundle.class.getName(),
                                                        UIMessageBundle.STR_DETAIL_MSG_SEPARATOR2, null, null);
   private String mDetailLevel = StringManager.getString(UIMessageBundle.class.getName(),
                                                         UIMessageBundle.STR_DETAIL_MSG_LEVEL, null, null);
   private String mDetailHeader = StringManager.getString(UIMessageBundle.class.getName(),
                                                          UIMessageBundle.STR_DETAIL_MSG_HEADER, null, null);
   private String mDetailIndent = StringManager.getString(UIMessageBundle.class.getName(),
                                                          UIMessageBundle.STR_DETAIL_MSG_INDENT, null, null);

   JUErrorDialog(Frame parent, String title, boolean modal, Exception ex)
   {
      super(parent, title, modal);

      mEx = ex;
      
      jbInit();
      pack();
   }

   void formErrorMessage(int num, int lev, StringBuffer buff, Exception ex)
   {
      String indent = "";

      for (int j = 1; j < lev; j++)
      {
         indent += mDetailIndent;
      }

      if (lev > 0)
      {
         buff.append(indent).append(mDetailSep1).append(mDetailLevel).append(lev).
              append(mDetailHeader).append(num).append(mDetailSep2).append("\n");
      }
      
      if (mShowStackTraces)
      {
         StringWriter stkWriter = new StringWriter();

         ex.printStackTrace(new PrintWriter(stkWriter));

         stkWriter.flush();

         buff.append(indent).append(stkWriter.toString()).append("\n");
      }
      else
      {
         /*
         String strmsg = (ex instanceof JboException) 
                      ? ((JboException)ex).getLocalizedMessage(java.util.Locale.getDefault())
                      : ex.getLocalizedMessage();
         */
         String strmsg = ex.getLocalizedMessage(); 
         buff.append(indent).append("(").append(ex.getClass().getName()).
              append(") ").append(strmsg).append("\n");
      }
      
      if (mShowDetails)
      {
         if (ex instanceof JboException)
         {
            Object[] nextLevDetails = ((JboException) ex).getDetails();
   
            if (nextLevDetails != null)
            {
               for (int j = 0; j < nextLevDetails.length; j++)
               {
                  formErrorMessage(j, lev + 1, buff, (Exception) nextLevDetails[j]);
               }
            }
         }
      }
   }


   String getErrorMessage()
   {
      StringBuffer msgBuff = new StringBuffer();
      
      formErrorMessage(0, 0, msgBuff, mEx);

      return msgBuff.toString();
   }

   
   boolean hasDetails()
   {
      if (mEx instanceof JboException)
      {
         Object[] details = ((JboException) mEx).getDetails();

         return (details != null && details.length > 0);
      }

      return false;
   }

   
   void jbInit()
   {
      mPanel.add(mOKButton);

      if (mEx != null)
      {
         mDetailsButton = new JButton(mDetailsButtonText);
         
         mDetailsButton.setEnabled(hasDetails());
         mPanel.add(mDetailsButton);

         mStackTracesButton = new JButton(mStackTracesButtonText);

         mStackTracesButton.setEnabled(true);
         mPanel.add(mStackTracesButton);
      }

      getRootPane().setDefaultButton(mOKButton);

      mTextArea.setEditable(false);
      mTextArea.setWrapStyleWord(true);
      mTextArea.setLineWrap(true);
      mTextArea.setBackground(getBackground());

      mOKButton.addActionListener(new ActionListener()
                                  {
                                     public void actionPerformed(ActionEvent e)
                                     {
                                        setVisible(false);
                                        dispose();
                                     }
                                  }) ;

      if (mDetailsButton != null)
      {
         mDetailsButton.addActionListener(new ActionListener()
                                          {
                                             public void actionPerformed(ActionEvent e)
                                             {
                                                if (mShowDetails == false)
                                                {
                                                   mShowDetails = true;
                                                   mDetailsButton.setText(mNoDetailsButtonText);
                                                   mTextArea.setText(getErrorMessage());
                                                }
                                                else
                                                {
                                                   mShowDetails = false;
                                                   mDetailsButton.setText(mDetailsButtonText);
                                                   mTextArea.setText(getErrorMessage());
                                                }
                                             }
                                          }) ;
      }

      if (mStackTracesButton != null)
      {
         mStackTracesButton.addActionListener(new ActionListener()
                                              {
                                                 public void actionPerformed(ActionEvent e)
                                                 {
                                                    if (mShowStackTraces == false)
                                                    {
                                                       mShowStackTraces = true;
                                                       mStackTracesButton.setText(mNoStackTracesButtonText);
                                                       mTextArea.setText(getErrorMessage());
                                                    }
                                                    else
                                                    {
                                                       mShowStackTraces = false;
                                                       mStackTracesButton.setText(mStackTracesButtonText);
                                                       mTextArea.setText(getErrorMessage());
                                                    }
                                                 }
                                              }) ;
      }

      getContentPane().add(new JScrollPane(mTextArea), BorderLayout.CENTER);
      getContentPane().add(mPanel, BorderLayout.SOUTH);
   }


   public void showError()
   {
      getParent().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

      mTextArea.setText(getErrorMessage());

      setLocationRelativeTo(getParent());
      
      setVisible(true);
   }
}


/**
* Dialog that implements JUErrorHandler interface in the framework.
* This is the dialog that comesup by default on an exception in the framework.
* Applications should provide their own implementation of JUErrorHandler to 
* customize error displays.
*/
public class JUErrorHandlerDlg implements JUErrorHandler, DCErrorHandler
{
   boolean inReportException = false;
   public JUErrorHandlerDlg()
   {
   }

   public void reportException(JUFormBinding formBnd, Exception ex)
   {
      reportException((DCBindingContainer)formBnd, ex);
   }

   public void reportException(JUFormBinding formBnd, Exception ex, boolean reportExceptionNow)
   {
      reportException((DCBindingContainer)formBnd, ex, reportExceptionNow);
   }

   public void reportException(DCBindingContainer formBnd, Exception ex)
   {
		reportException(formBnd, ex, false);
   }

  public void reportException(DCBindingContainer formBnd, Exception ex, boolean reportErrorNow)
   {
      if (inReportException)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Warning JUErrorHandlerDlg ignoring "+ex.getClass().getName()+" while in reportException");
         }
         return;
      }
      try
      {
         inReportException = true;
         if (Diagnostic.isOn())
         {
            Diagnostic.println("JUErrorHandlerDlg.reportException("+ex.getClass().getName()+")");
         }
         Object panel = (formBnd != null) ? formBnd.getViewComponent() : null;
         Frame frm = null;
         
         if (panel instanceof JPanel)
         {
           frm = JUIUtil.getParentFrame((JPanel) panel);
         }
         
         oracle.jbo.ApplicationModule am = null;
         if (ex instanceof JboException && formBnd != null)
         {
           try
           {
              am = formBnd.getApplicationModule();
           }
           catch (Exception ioe)
           {
              //ignore this exception as we're only interested in reporting the
              //actual exception
              oracle.jbo.common.Diagnostic.println("JUErrorHandlerDlg.reportException ignoring :"+ioe);
           }
         }
         
         if (am != null)
         {
           try
           {
              oracle.jbo.ViewObject[] vos = ((JUFormBinding)formBnd).getOrderedVOUsageList();
              ((JboException)ex).doEntityToVOMapping(formBnd.getApplicationModule(), vos);
           }
           catch (JboException e)
           {
              oracle.jbo.common.Diagnostic.print("Warning! Ignoring exception in JUFormBinding.getOrderedVOUsageList");
              oracle.jbo.common.Diagnostic.printStackTrace(e);
           }
         }
         
         class myRunnable implements Runnable
         {
            Frame mFrame;
            Exception mEx;
            public void run() 
            {
               JUErrorDialog dlg = new JUErrorDialog(mFrame, StringManager.getString(UIMessageBundle.class.getName(),
                                                                                 UIMessageBundle.STR_ERR_DLG_TITLE, null, null),
                                                    true /*modal*/, mEx);

               dlg.showError();
            }
         };

         myRunnable runnable = new myRunnable();
         runnable.mFrame = frm;
         runnable.mEx = ex;

		 if (reportErrorNow)
		 {
			try
			{
				SwingUtilities.invokeAndWait(runnable);
			}
			catch(InvocationTargetException ite)
			{
			   oracle.jbo.common.Diagnostic.println("JUErrorHandlerDlg.reportException ignoring :"+ ite.getMessage()); 
			}
			catch(InterruptedException ie)
			{
			   oracle.jbo.common.Diagnostic.println("JUErrorHandlerDlg.reportException ignoring :"+ ie.getMessage()); 
			}
		 }
		 else
		 {
			SwingUtilities.invokeLater(runnable);
		 }
         
      }
      finally
      {
         inReportException = false;
      }
   }
  

}
