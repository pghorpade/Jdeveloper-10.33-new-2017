/*
 * @(#)JUMultiAttrListEditor.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import javax.swing.plaf.basic.BasicComboBoxEditor;
import oracle.jbo.Row;
import oracle.jbo.uicli.binding.JUCtrlListBinding;

public class JUMultiAttrListEditor extends BasicComboBoxEditor
{
    int mAttrIndex;
    JUCtrlListBinding mBinding;

    public JUMultiAttrListEditor(JUCtrlListBinding binding, int attrIndex) 
    {
       mAttrIndex = (attrIndex > -1) ? attrIndex : 0;
       mBinding = binding;
    }

    public void setItem(Object anObject) 
    {
       if (anObject instanceof Row) 
       {
          anObject = ((Row)anObject).getAttribute(mAttrIndex);
          //mCurObject = anObject;
       }
       super.setItem(anObject);
    }

    public Object getItem() 
    {
       //we need to fix this so that we match the value in the textfield
       //with the attribute from the rows.
       Object sel = mBinding.getSelectedValue();
       String editText = editor.getText();

       if (sel instanceof oracle.jbo.Row) 
       {
          Object val = ((oracle.jbo.Row)sel).getAttribute(mAttrIndex);
          if (val != null) 
          {
             if (val.toString().equals(editText))
             {
                return val;
             }
          }
          else
          {
             if (editText.trim().length() == 0) 
             {
                return val;
             }
          }
       }

       return mBinding.findMatchingListValue(editor.getText());
    }
}

