/*
 * @(#)JULoginDlg.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import oracle.jbo.common.StringManager;
import oracle.jbo.uicli.UIMessageBundle;

/**
 * A sample implemenation of log in dialog in the JClient framework.
 */
public class JULoginDlg extends JDialog 
{
   private JPanel mTopPanel = new JPanel();
   private JPanel mBottomPanel = new JPanel();
   
   private String mUserName = null;
   private String mPassword = null;
   private boolean mIsCancelled = false;
   
   private JLabel mUserNameLabel = new JLabel();
   private JLabel mPasswordLabel = new JLabel();
   private JTextField mUserNameEdit = new JTextField();
   private JPasswordField mPasswordEdit = new JPasswordField();
   private JButton mOKButton = new JButton();
   private JButton mCancelButton = new JButton();

   private String mLoginTitleStr = StringManager.getString(UIMessageBundle.class.getName(),
                                                           UIMessageBundle.STR_LOGIN_TITLE, null, null);
   private String mUserNameStr = StringManager.getString(UIMessageBundle.class.getName(),
                                                         UIMessageBundle.STR_USER_NAME, null, null);
   private String mPasswordStr = StringManager.getString(UIMessageBundle.class.getName(),
                                                         UIMessageBundle.STR_PASSWORD, null, null);


   public JULoginDlg()
   {
      this(null, "Login", true);

      setTitle(mLoginTitleStr);
   }


   public JULoginDlg(Frame parent, String title, boolean modal)
   {
      super(parent, title, modal);

      try
      {
         jbInit();
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
   }


   private void jbInit() // throws Exception
   {
      this.setSize(new Dimension(400, 200));

      mUserNameLabel.setText(mUserNameStr);
      mPasswordLabel.setText(mPasswordStr);

      mOKButton.setText(StringManager.getString(UIMessageBundle.class.getName(),
                                                UIMessageBundle.STR_OK_BUTTON_TEXT, null, null));
      mOKButton.addActionListener(new ActionListener()
                                  {
                                     public void actionPerformed(ActionEvent e)
                                     {
                                        mUserName = mUserNameEdit.getText();
                                        mPassword = new String(mPasswordEdit.getPassword());

                                        setVisible(false);
                                        dispose();
                                     }
                                  }) ;

      getRootPane().setDefaultButton(mOKButton);

      mCancelButton.setText(StringManager.getString(UIMessageBundle.class.getName(),
                                                UIMessageBundle.STR_CANCEL_BUTTON_TEXT, null, null));
      mCancelButton.addActionListener(new ActionListener()
                                      {
                                         public void actionPerformed(ActionEvent e)
                                         {
                                            mIsCancelled = true;
                                            setVisible(false);
                                            dispose();
                                         }
                                      }) ;

      Container contPane = getContentPane();
      
      contPane.setLayout(new BorderLayout());
      contPane.add(mTopPanel,BorderLayout.CENTER);
      contPane.add(mBottomPanel,BorderLayout.SOUTH);
      
      mTopPanel.setLayout(new GridBagLayout());
      mBottomPanel.setLayout(new GridBagLayout());

      mTopPanel.add(mUserNameLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
         GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 8, 10, 0), 15, 0));
      mTopPanel.add(mUserNameEdit, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0,
         GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(10, 11, 10, 12), 0, 0));
      mTopPanel.add(mPasswordLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
         GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 8, 10, 0), 15, 0));
      mTopPanel.add(mPasswordEdit, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0,
         GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(10, 11, 10, 12), 0, 0));
            
      mBottomPanel.add(mOKButton, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0,
         GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(10, 12, 10, 12), 0, 0));
      mBottomPanel.add(mCancelButton, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0,
         GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 12, 10, 12), 0, 0));

      setLocationRelativeTo(getParent());
   }


   public String getUserName()
   {
      return mUserName;
   }

   
   public void setUserName(String str)
   {
      mUserName = str;
      mUserNameEdit.setText(str);
   }


   public String getPassword()
   {
      return mPassword;
   }

   
   public void setPassword(String str)
   {
      mPassword = str;
      mPasswordEdit.setText(str);
   }


   public boolean isCancelled()
   {
      return mIsCancelled;
   }
}
