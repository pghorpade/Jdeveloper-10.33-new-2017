/*
 * @(#)JUImageControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.jui.JUDefaultControlBinding;
import oracle.jbo.uicli.jui.JUDefaultControlInterface;

/**
 *  Implements a data-aware Image Control. JUImageControl can be bound to BC4J row attributes.
 *  The ImageControl treats the data stream as an image (JPEG or GIF) and displays it.
 *
 *  @version PUBLIC
 */
public class JUImageControl
    extends JPanel
    implements ActionListener, FocusListener, JUDefaultControlInterface   
{
    protected BorderLayout _mainPanelLayout = new BorderLayout();
    protected GridBagLayout _buttonPanelLayout = new GridBagLayout();

    protected JScrollPane _imageAggregate;
    protected JLabel  _imageDisplay = new JLabel();
    protected JPanel  _buttonPanel  = new JPanel();

    protected Dimension _buttonPreferredSize = new Dimension(80,25);

    protected JButton _newButton =
        new JButton( UIMessageBundle.getResString(UIMessageBundle.STR_IMAGE_CONTROL_CHANGE));
    protected JButton _clearButton =
        new JButton( UIMessageBundle.getResString(UIMessageBundle.STR_IMAGE_CONTROL_CLEAR));

    protected JFileChooser _fileChooser = new JFileChooser();
    private boolean _readOnly = false;
    private boolean _showUpdateButtons=true;

    private FocusAdapter mFocusAdapter;

    private JUDefaultControlBinding _ctrlBinding = null;

    /**
    * Constructs a JUImageControl.
    */
    public JUImageControl()
    {
        //if (DesignTime.inDesignTime())
        //    return;

        setLayout(_mainPanelLayout);
//        setBorder(BorderFactory.createEtchedBorder());

        _imageAggregate = new JScrollPane(_imageDisplay);     
        _imageAggregate.setBorder(null);
        _imageAggregate.setPreferredSize(_getDefaultPreferredSize());
        add(_imageAggregate, BorderLayout.CENTER);
        _buttonPanel = _createButtonPanel();
        add(_buttonPanel, BorderLayout.EAST);
        _fileChooser.setFileFilter( new ImageFileFilter());
        _imageDisplay.addFocusListener(this);
    }


    public void addFocusListener(FocusAdapter f)
    {
       if (mFocusAdapter != null) 
       {
          //what should be done here?
       }
       this.mFocusAdapter = f;
    }

    /**
    * Gets the panel used to display buttons.
    */
    public JPanel getButtonsPanel()
    {
        return _buttonPanel;
    }

    /*
    * Gets the button that allows selection of a new image.
    * Use this method to gain access to the button and provide
    * it with mnemonics for ADA support.
    */
    public JButton getNewButton()
    {
       return _newButton;
    }

    /*
    * Gets the button that allows clearing the current image.
    * Use this method to gain access to the button and provide
    * it with mnemonics for ADA support.
    */
    public JButton getClearButton()
    {
       return _clearButton;
    }

    /**
    * Gets the label control used to display the image.
    */
    public JLabel getLabel()
    {
        return _imageDisplay;
    }

    /**
    *  Scroll pane used to display the image.
    */
    public JScrollPane getScrollPane()
    {
        return _imageAggregate;
    }

    public void setShowUpdateButtons(boolean bShowButtons)
    {
        _showUpdateButtons = bShowButtons;
        if (_showUpdateButtons)
           add( _buttonPanel, BorderLayout.EAST );
        else
           remove(_buttonPanel);

    }

    public boolean getShowUpdateButtons()
    {
        return _showUpdateButtons;
    }

    public void setReadOnly(boolean readOnly)
    {
        _readOnly = readOnly;
        _enableButtons(!_readOnly);
		
		
    }

    public boolean getReadOnly()
    {
        return _readOnly;
    }

    //FocusListener implementation
    /**
    * This method is an implementaion side effect.
    */
    public void focusLost(FocusEvent event)
    {
    }

    /**
    * This method is an implementaion side effect.
    */
    public void focusGained(FocusEvent event)
    {
       if (!event.isTemporary()) 
       {
          if (mFocusAdapter != null) 
          {
             mFocusAdapter.focusGained(event);
          }
       }
        //if (isFocusValidated())
        //{
        //    NavigationManager nm = NavigationManager.getNavigationManager();
        //    nm.validateFocusChange(this);
        //}
    }

    // ControlEnabledListener interface
    public void enabledChanged(boolean b)
    {
        super.setEnabled(b);
        setReadOnly(_readOnly);
    }

    // InfoBusManagerListener interface implementation
    public void releaseResources()
    {
      _imageDisplay.removeFocusListener(this);
      _newButton.removeActionListener(this);
      _clearButton.removeActionListener(this);
      _newButton.removeFocusListener(this);
      _clearButton.removeFocusListener(this);
    }

    // Control Interface

    /**
    ** An override of java.awt.Component.setEnabled.
    **
    ** @param b Indicates whether the control is enabled.
    */
    public void setEnabled(boolean b)
    {
        super.setEnabled(b);
        setReadOnly(_readOnly);

    } // setEnabled

    /**
    *  Binds the control to the infobus and implements lazy loading, by using the 
    *  DACRTManager, to lookup the RowSet and DataItemName.
    *
    *  @param binding  Format is &lt;Data Definition name&gt;.&lt;ViewObject name&gt;.&lt;Attribute name&gt;.
    */
    public void setModel(JUDefaultControlBinding binding)
    {
       _ctrlBinding = binding;
    }

    /**
    *  Returns the bindName and provides the hook into property editors/customizers.
    */
    public JUDefaultControlBinding getModel()
    {
       return _ctrlBinding;
    }


    /**
    * Returns the AWT component associated with this control. <P>
    * @return  The AWT component for this control.
    */
    public final Component getComponent()
    {
        return(this);
    }

    /**
    *  execute the clear button action
    */
    public void doClearButtonAction()
    {
       _setImage(null);

       oracle.adf.model.binding.DCDataControl dc = _ctrlBinding.getIteratorBinding().getDataControl();
       if ( dc.syncNeeded())
       {
           dc.sync("JUImageControl.doClearButtonAction");
       }
    }

    /**
    *  execute the new button action
    */
    public void doNewButtonAction()
    {
       int rc = _fileChooser.showOpenDialog(this);
       if (rc  == JFileChooser.APPROVE_OPTION)
       {
           File file = _fileChooser.getSelectedFile();
           byte[] imageData = _readImageData(file.getAbsolutePath());
           _setImage(imageData);

           _refreshImage(imageData);
       }
    }

    /**
    *  In three tier mode, if sync mode is not SYNC_IMMEDIATE, user will
    *  not see the image when it is changed. This method is used to refresh
    *  the image.
    */
    protected void _refreshImage(byte[] imageData)
    {
        if (_ctrlBinding != null)
        {
           ApplicationModule am = _ctrlBinding.getApplicationModule();

           if (am.getSyncMode() != ApplicationModule.SYNC_IMMEDIATE)
           {
               _displayImage(imageData);
           }
        }
    }

    // ActionListener
    public void actionPerformed(ActionEvent e)
    {
        Object src = e.getSource();
        if (src == _clearButton)
        {
           doClearButtonAction();
        }
        else
        {
           doNewButtonAction();
        }
    }

    // protected methods
    /**
    *  Gets the preferred size for the image scroll pane.
    */
    protected Dimension  _getDefaultPreferredSize()
    {
        return new Dimension(400,200);
    }

    // Private Methods
    /**
    * Updates the image based on the new value of the dataitem.
    *
    * @param dataItem The dataitem to which the control is bound.
    */
    /*
    private void _updateImageLater(final Object dataItem)
    {
        SwingUtilities.invokeLater(
                                   new Runnable()
                                   {
                                       public void run()
                                           {
                                               _updateImage(dataItem);
                                           }
                                   }
                                   );
    }
    */
    public void dataChanged(final Object dataItem)
    {
       SwingUtilities.invokeLater(
                                  new Runnable()
                                  {
                                      public void run()
                                          {
                                              _updateImage(dataItem);
                                          }
                                  }
                                  );
    }

    /**
    * Updates the image now.
    *
    * @param dataItem The dataitem to which the control is bound.
    */
    private void _updateImage(Object dataItem)
    {
         // enable/disable buttons
         if (_ctrlBinding != null && _ctrlBinding.getIteratorBinding() != null) 
         {
		 	Class javaType = _ctrlBinding.getAttributeDef(0).getJavaType();
			if (!isAllowedDataType(javaType))
            {
               setReadOnly(true);
               _newButton.setEnabled(false);
			   return;
            }

            setReadOnly((_ctrlBinding != null) ? !_ctrlBinding.isAttributeUpdateable(0) : true);

            Object o = _ctrlBinding.getValueAt(0);
            if ( o instanceof oracle.jbo.domain.BlobDomain ) 
            {
               o = ((oracle.jbo.domain.BlobDomain)o).toByteArray();
            }
            else
            if (o instanceof oracle.ord.im.OrdImageDomain) 
            { 
               try
               {
                  Object content = ((oracle.ord.im.OrdImageDomain)o).getContentSource();
                  if (content instanceof oracle.ord.im.OrdByteArraySource) 
                  {
                     o = ((oracle.ord.im.OrdByteArraySource)content).getByteArray();
                  }
                  else
                  {
                     o = ((oracle.ord.im.OrdImageDomain)o).getDataInByteArray();
                  }
               }
               catch (JboException je)
               {
                  throw je;
               }
               catch (Exception e)
               {
                  throw new JboException(e);
               }

            }
            else
            if (o instanceof oracle.sql.Datum) 
            { 
               o = ((oracle.sql.Datum)o).getBytes();
            }
            if ( o instanceof byte[])
            {
                _displayImage((byte[]) o);    

                return;
            }
         }
         else
         {
            setReadOnly(true);
         }
        _imageDisplay.setIcon(null);
    }
	
	private boolean isAllowedDataType(Class javaType)
	{
		if(oracle.ord.im.OrdImageDomain.class.isAssignableFrom(javaType))
			return(true);
			
		if (oracle.jbo.domain.BlobDomain.class.isAssignableFrom(javaType))	
			return(true);
		
		if (oracle.sql.Datum.class.isAssignableFrom(javaType))
			return(true);
		
//		if (byte[].class.isAssignableFrom(javaType))
//			return(true);
		return(false);
	
	}

    private void _displayImage(byte[] imageData)
    {
        _imageDisplay.setIcon(new ImageIcon( imageData));
    }

    protected JPanel _createButtonPanel()
    {
        JPanel panel = new JPanel();
        panel.setLayout(_buttonPanelLayout);

        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.NORTH;

        gc.gridx = gc.gridy = 0;
        panel.add(_newButton,gc);
        gc.gridx=0; gc.gridy=1;
        panel.add(_clearButton,gc);
        _newButton.setPreferredSize(_buttonPreferredSize);
        _clearButton.setPreferredSize(_buttonPreferredSize);

        _newButton.addActionListener(this);
        _clearButton.addActionListener(this);
        _newButton.addFocusListener(this);
        _clearButton.addFocusListener(this);
		
		_enableButtons(false);

        return(panel);
    }

    protected void _enableButtons(boolean bEnable)
    {
		
        _newButton.setEnabled(bEnable);
        _clearButton.setEnabled(bEnable);
    }

    private byte[] _readImageData(String filename)
    {
        try
        {
            FileInputStream fi =  new FileInputStream(filename);
            BufferedInputStream bi = new  BufferedInputStream(fi);

            byte[] imageData = new byte[bi.available()];
            bi.read(imageData, 0, imageData.length);
            return imageData;
        }
        catch (Exception e)
        {
            return null;
        }

    }

    private void _setImage(byte[] data)
    {
       if (_ctrlBinding != null)
       {
          Class imageClass = oracle.ord.im.OrdImageDomain.class;
          if (data != null 
                 && imageClass.isAssignableFrom(_ctrlBinding.getAttributeDef(0).getJavaType())) 
          {
             try
             {
                oracle.ord.im.OrdImageDomain ordImage = (oracle.ord.im.OrdImageDomain)imageClass.newInstance();
                ordImage.setContentSource(new oracle.ord.im.OrdByteArraySource(data));
                _ctrlBinding.setDataValueAt(ordImage, 0);
                return;
             }
             catch (oracle.jbo.JboException jboEx)
             {
                throw jboEx;
             }
             catch (Exception e)
             {
                //eat it and retry typefactory.
             }
          }
          _ctrlBinding.setDataValueAt(data, 0);
       }
    }
}

class ImageFileFilter
    extends FileFilter
{
    private String _imageFileExt =
        UIMessageBundle.getResString(UIMessageBundle.STR_IMAGE_CONTROL_IMAGE_FILE_EXT);

    public ImageFileFilter()
    {
    }

    public boolean accept(File f)
    {
        if (f.isDirectory() ||
            _isImageFile(_getExtension(f)))
            return true;

        return false;
    }

    public String getDescription()
    {
        return _imageFileExt;
    }

    private String _getExtension(File f)
    {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 && i < s.length() - 1)
            ext = s.substring(i+1).toLowerCase();

        return ext;
    }

    private boolean _isImageFile(String ext)
    {

        if (ext != null)
        {
            if (ext.equals("gif") || ext.equals("jpeg"))
                return true;
        }
        return false;
    }
}

