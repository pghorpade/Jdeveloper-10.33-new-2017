/*
 * @(#)JURadioButtonGroupPanel.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.AbstractButton;
import javax.swing.JRadioButton;
import oracle.jbo.Row;
import oracle.jbo.AttributeDef;
import oracle.jbo.uicli.jui.JUButtonGroupBinding;
import oracle.jbo.uicli.jui.JUButtonGroupControlInterface;

/*
 * Implements a JPanel that places the radio buttons for each value in the list given in createButtons()
 * method, and lays the controls out in one column vertically. To change the layout,
 * call setRowCount() or setColumnCount() with appropriate values to indicate how
 * many rows/columns should be used to display the buttons.
 * Note that the setting for row/col needs to be done prior to calling createButtons().
 */
public class JURadioButtonGroupPanel extends javax.swing.JPanel 
             implements JUButtonGroupControlInterface
{
  private JUButtonGroupBinding mBinding;
  private int mRows = 0;
  private int mCols = 1;
  private int mVGap = 0;
  private int mHGap = 0;
  private String DISPLAY_DELIMITER = ",";

  public AbstractButton[] createButtons(Object values[])
  {
     Component child[] = getComponents();
     if (child != null) 
     {
        for (int i = 0; i < child.length; i++) 
        {
           if (child[i] instanceof JRadioButton) 
           {
              remove(child[i]);
           }
        }
     }

     AbstractButton[] buttons = null;
     if (values != null)
     {
        if (mRows == 0 && mCols == 0)
        {
           mCols = 1;
        }
        int length = values.length;
        buttons = new AbstractButton[length];

        setLayout(new GridLayout(mRows, mCols, mHGap, mVGap));
        
        JRadioButton btn;
        StringBuffer buf;
        for (int i = 0; i < length; i++)
        {
           btn = new JRadioButton();
           btn.setContentAreaFilled(false);           
           buf = new StringBuffer();
           buf.append(getDisplayValue(values[i]));
           btn.setText(buf.toString());
           add(btn);
           buttons[i] = btn;
        }
     }
     revalidate();
     return buttons;
  }

  private Object getDisplayValue(Object dispObj)
  {
     if (mBinding == null || mBinding.isSingleAttrList())
     {
        return dispObj;
     }
     Row row = (Row)dispObj;
     AttributeDef defs[] = mBinding.getDisplayAttributeDefs();
     if (defs != null)
     {
        StringBuffer buf = new StringBuffer("").append(row.getAttribute(defs[0].getIndex()));
        for (int i = 1; i < defs.length; i++)
        {
           buf.append(DISPLAY_DELIMITER).append(row.getAttribute(defs[i].getIndex()));
        }
        return buf;
     }
     return null;
  }

  public JURadioButtonGroupPanel()
  {
  }
  
  public void setRowCount(int value)
  {
     mRows = (value < 0) ? 0 : value;
  }

  public int getRowCount()
  {
     return mRows;
  }
  
  public void setColumnCount(int value)
  {
     mCols = (value < 0) ? 0 : value; 
  }

  public int getColumnCount()
  {
     return mCols;
  }

  public void setVerticalGap(int value)
  {
     mVGap = (value < 0) ? 0 : value; 
  }

  public int getVerticalGap()
  {
     return mVGap;
  }

  public void setHorizontalGap(int value)
  {
     mHGap = (value < 0) ? 0 : value;
  }

  public int getHorizontalGap()
  {
     return mHGap;
  }

  public void setModel(JUButtonGroupBinding binding)
  {
     mBinding = binding;
  }

  public JUButtonGroupBinding getModel()
  {
     return mBinding;
  }

  public String getDisplayDelimiter()
  {
     return DISPLAY_DELIMITER;
  }

  /**
   * Use this String or character as a delimiter between
   * attribute values if more than one attribute are
   * displayed per entry in this group control.
   * Default delimiter character is ',' (COMMA).
   */
  public void setDisplayDelimiter(String str)
  {
     DISPLAY_DELIMITER = str;
  }
}