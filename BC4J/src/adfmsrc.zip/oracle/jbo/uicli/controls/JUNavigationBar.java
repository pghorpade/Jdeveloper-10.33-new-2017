/*
 * @(#)JUNavigationBar.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.controls;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Insets;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import java.lang.reflect.Constructor;

import java.net.URL;

import javax.swing.border.Border;
import javax.swing.BorderFactory;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

import oracle.adf.model.binding.DCDataControl;

import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.RowSetListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.binding.JUTransactionStateListener;
import oracle.jbo.uicli.jui.JUActionBinding;
import oracle.jbo.uicli.jui.JUIUtil;
import oracle.jbo.uicli.jui.JUNavigationBarInterface;
import oracle.jbo.uicli.jui.JUPanelBinding;
import oracle.jbo.uicli.jui.JUSVFocusAdapter;

/**
 * Implements a data-aware toolbar. Can be bound to a RowSetIterator
 * and can be used:
 * to: <P>
 * <UL>
 * <LI>Iterate back and forth over the bound dataitem.</LI>
 * <LI>Insert a new row in the bound dataitem. </LI>
 * <LI>Delete an existing row from the bound item. </LI>
 * <LI>Commmit/Rollback changes made to the bound item. </LI>
 * </UL>
 *
 * @version  PUBLIC
 *
 * @see      #setHasNavigationButtons(boolean)
 * @see      #setHasInsertButton(boolean)
 * @see      #setHasDeleteButton(boolean)
 * @see      #setHasTransactionButtons(boolean)
 */
public class JUNavigationBar 
    extends JToolBar
    implements ActionListener, RowSetListener, JUNavigationBarInterface, JUTransactionStateListener
{
  private final class ButtonFocusListener implements FocusListener
  {
    Icon focusIcon;
    Icon regularIcon;
    JButton button;
    
    public ButtonFocusListener(JButton button)
    {
      this.focusIcon = button.getRolloverIcon();
      this.regularIcon = button.getIcon();
      this.button = button;
    }
    
    public void focusGained(FocusEvent e)
    {
      if(!e.isTemporary())
      {
        button.setIcon(focusIcon);
      }
    }
    
    public void focusLost(FocusEvent e)
    {
      button.setIcon(regularIcon);
    }
  }

   public static final int BUTTON_FIRST    = 0;
   public static final int BUTTON_PREV     = 1;
   public static final int BUTTON_NEXT     = 2;
   public static final int BUTTON_LAST     = 3;
   public static final int BUTTON_INSERT   = 4;
   public static final int BUTTON_DELETE   = 5;
   public static final int BUTTON_COMMIT   = 6;
   public static final int BUTTON_ROLLBACK = 7;
   public static final int BUTTON_FIND     = 8;
   public static final int BUTTON_EXECUTE  = 9;
   
   public static final int BUTTON_NORMAL   = 0;
   public static final int BUTTON_PRESSED  = 1;
   public static final int BUTTON_DISABLED = 2;
   public static final int BUTTON_ROLLOVER = 3;
      
   private ChangeListener buttonChangeListener = new ChangeListener()
   {
     public void stateChanged(ChangeEvent e)
     {
        final JButton button = (JButton)e.getSource();
        if(!button.isEnabled() && button.hasFocus())
        {
          //the focus cycle is trapped at the current button
          //we can't focus on the next component yet; it may still become disabled
          //so we post the request for focus on the queue
          SwingUtilities.invokeLater(new Runnable()
          {
            public void run()
            {
              KeyboardFocusManager.getCurrentKeyboardFocusManager().focusNextComponent(button);
            }
          });
        }
     }
   };
   
   private FocusAdapter mFocusAdapter;
   private JButton _buttons[];
   
   private ImageIcon _buttonCancelIcon = null;
   private ImageIcon _buttonIcons[] = null;
   private ImageIcon _onButtonIcons[] = null;
   private ImageIcon _disButtonIcons[] = null;
   private ImageIcon _rollButtonIcons[] = null;
   //private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
   
   private boolean noRSIEvents = true;
   
   static final String _IMAGES_DIR = "images/";
   static final String _IMAGES[] =
   {
     "first", "prev", "next", "last",
     "insert", "delete", "commit", "rollback", "find", "execute"
   };
   private static final ImageIcon _IMAGEICONS[] = new ImageIcon[4*_IMAGES.length + 1];

   static {
      Class cl = JUNavigationBar.class;
      int   index = -1;
      for (int i = 0; (i < _IMAGES.length); i++)
      {
         URL img, onimg, disimg, rollimg;
         img = cl.getResource(_IMAGES_DIR + _IMAGES[i] + ".gif");
         _IMAGEICONS[++index] = (img != null ? new ImageIcon(img) : null);
      
         onimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "on.gif");
         _IMAGEICONS[++index] = (onimg != null ? new ImageIcon(onimg) : null);
      
         disimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "dis.gif");
         _IMAGEICONS[++index] = (disimg != null ? new ImageIcon(disimg) : null);
      
         rollimg = cl.getResource(_IMAGES_DIR + _IMAGES[i] + "roll.gif");
         _IMAGEICONS[++index] = (rollimg != null ? new ImageIcon(rollimg) : null);
      }
      
      URL cancel = cl.getResource(_IMAGES_DIR + "findcancel.gif");
      _IMAGEICONS[++index] = (cancel != null ? new ImageIcon(cancel) : null);
   }

   private static final String _TOOLTIP[] =
   {
     UIMessageBundle.getResString(UIMessageBundle.STR_NAV_FIRST)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_PREV)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_NEXT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_LAST)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INSERT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_DELETE)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_COMMIT)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_ROLLBACK)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_FIND)
     ,UIMessageBundle.getResString(UIMessageBundle.STR_NAV_EXECUTE)
   };
   
   static String _tooltipCancelFind = UIMessageBundle.getResString(UIMessageBundle.STR_NAV_CANCELFIND);
   
   
   //private static final boolean _DEBUG = true;
   
   private boolean _hasFindButton = true;
   private boolean _hasExecuteButton = true;
   
   private boolean mViewBound = false;
   private boolean mTxnBound = false;
   private boolean mDirty = false;
   private boolean mFindMode = false;
   private boolean mIgnoreIteratorChange = false;
   private Cursor _busyCursor= Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
   private Cursor _defaultCursor= Cursor.getDefaultCursor();
   private boolean _isShowingBusyCursor = false;
   JUIteratorBinding _iterBinding;
   JUActionBinding _bindings[] = new JUActionBinding[BUTTON_EXECUTE+1];
   
   /**
   * Creates a default instance.
   */
   public JUNavigationBar()
   {
      this(true, true, true, true, true);
   }
   
   /**
   * @deprecated since 9.0.3 use the constructor that also takes execute flag.
   */
   public JUNavigationBar(boolean navigation, boolean modify, boolean txn, boolean find)
   {
      this(navigation, modify, txn, find, true);
   }

   /**
   * This constructor takes flags to indicate which buttons to show or hide in the navigationbar.
   */
   public JUNavigationBar(boolean navigation, boolean modify, boolean txn, boolean find, boolean execute)
   {
      _loadImages();
      
      //same adapter used by buttons on this toolbar.
      mFocusAdapter = new FocusAdapter()
         {
            public void focusGained(FocusEvent e)
            {
               if (!e.isTemporary())
               {
                  //so that status bar reflects which iterator is in focus
                  JUIteratorBinding iterBinding = getModel();
                  if (iterBinding != null) 
                  {
                     JUPanelBinding panelBinding = (JUPanelBinding)iterBinding.getFormBinding();
                     if (panelBinding != null) 
                     {
                        panelBinding.focusGained(iterBinding, null, JUSVFocusAdapter.MULTI_ATTRIBUTE);
                     }
                  }
               }
            }
            
            public void focusLost(FocusEvent e) {}
         };
      
      _buttons = new JButton[_buttonIcons.length];
      for (int i = 0; (i < _buttonIcons.length); i++)
      {
        JButton b = new JButton(_buttonIcons[i]);
        b.setRolloverEnabled(true);
        b.setPressedIcon(_onButtonIcons[i]);
        b.setRolloverIcon(_rollButtonIcons[i]);
        b.setDisabledIcon(_disButtonIcons[i]);
        b.setToolTipText(_TOOLTIP[i]);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setMargin(new Insets(0, 0, 0, 0));
        b.setBorder(BorderFactory.createLineBorder(java.awt.Color.lightGray, 0));
        b.setEnabled(false);
        _buttons[i] = b;

        b.addActionListener(this);
        b.addChangeListener(this.buttonChangeListener);
        b.addFocusListener(new ButtonFocusListener(b));
      }
      
      setHasInsertButton(modify);
      setHasDeleteButton(modify);
      setHasNavigationButtons(navigation);
      setHasTransactionButtons(txn);
      setHasFindButton(find);
      setHasExecuteButton(execute);
      
   }

   /**
    * Applications should override this method to perform custom Action based on a button click/press.
    * Calling super will perform the default button actions.
    * <p>
    * For example, if an application needs to override commit and rollback operations so that they
    * can hold on to some application state before commit/rollback occurs, this method could be
    * overriden to cache the application state, call the super.actionPerformed() to do the
    * button action and then restore the application state.
   **/
   public void actionPerformed(ActionEvent ev)
   {
      Object source = ev.getSource();

      for (int i = 0; i <= BUTTON_EXECUTE; i++) 
      {
         if (source == _buttons[i]) 
         {
            doAction(i);
            return;
         }
      }
   }

   /**
   *  public method to call the NavigationBar button actions programmatically
   *
   *  expected values are BUTTON_FIRST, BUTTON_PREV, BUTTON_NEXT, BUTTON_LAST,
   *  BUTTON_INSERT, BUTTON_DELETE, BUTTON_COMMIT, BUTTON_ROLLBACK, BUTTON_FIND, BUTTON_EXECUTE 
   *
   *  @param action the action value, see expected values mentioned above
   */
   public void doAction(int action)
   {
      JUIteratorBinding iter = getModel();
      boolean hadValidIter = false;
      JUPanelBinding bc = null;
      if (iter != null && iter.isBound())
      {
         hadValidIter = true;
         bc = (JUPanelBinding)iter.getFormBinding();
      }

      switch (action) 
      {
      case BUTTON_FIND:
         // JRS 3294931 - Moved toggling logic from JUCtrlActionBinding to
         // here.  The toggling logic was causing unexpected behaviour for
         // web applications that may set the find mode more than once
         /*if (mFindMode)
         {
            doExecuteButtonAction();
         }
         else
         */
         {
            doFindButtonAction();
         }
         break;

      case BUTTON_EXECUTE:
         doExecuteButtonAction();
         break;
      default:
         if (action < BUTTON_FIND && _bindings[action] != null)
         {
            _bindings[action].invoke();
         }
      }

      iter = getModel();

      if (hadValidIter && iter != null && !iter.isBound() && bc != null)
      {
         //was bound to a valid iterator but not anymore.
         //disable all buttons.
         bc.notifyIteratorChanged (null, false);
      }
   }

   /**
    * Override this method to perform any application logic before or after the panel is set to Find Mode
    * or cancelling out of find mode.
    **/
   public void doFindButtonAction()
   {
      if (_iterBinding != null) 
      {
         JUPanelBinding panelBinding = (JUPanelBinding)_iterBinding.getFormBinding();
         boolean findMode = !mFindMode;
         try
         {
            mIgnoreIteratorChange = true;
            _bindings[BUTTON_FIND].invoke();
            panelBinding.displayStatus(_iterBinding, (findMode) ? UIMessageBundle.STR_FIND_MODE : UIMessageBundle.STR_CANCEL_FIND_MODE, null);
         }
         finally
         {
            mIgnoreIteratorChange = false;
         }
         mFindMode = findMode;
         /*
         if (_iterBinding.getDataControl().syncNeeded())
         {
            _iterBinding.getBindingContainer().refreshControl();
         }
         */
         _updateButtonStatesLater();
      }
   }

   /**
    * Override this method to perform any application logic before or after the ViewObjects referenced in 
    * this panel are executed.
    **/
   public void doExecuteButtonAction()
   {
      //cannot use the action binding because we need to ignore iteratorchange event
      //till the query is executed to avoid multiple refreshes..
      JUPanelBinding panelBinding = (JUPanelBinding)_iterBinding.getFormBinding();
      panelBinding.displayStatus(_iterBinding, UIMessageBundle.STR_EXECUTING_QUERY, null);
      try
      {
         boolean active = panelBinding.isErrorHandlerActive();
         try
         {
            panelBinding.setErrorHandlerActive(false);
            panelBinding.stopEditing();
         }
         catch (Exception e)
         {
            if (active)
            {
               panelBinding.setErrorHandlerActive(active);
            }
            panelBinding.reportException(e);
            return;
         }
         finally
         {
            if (active)
            {
               panelBinding.setErrorHandlerActive(active);
            }
         }
         mIgnoreIteratorChange = true;
         _bindings[BUTTON_EXECUTE].invoke();
      }
      finally
      {
         mIgnoreIteratorChange = false;
      }
      mFindMode = panelBinding.isFindMode();
      /*
      if (_iterBinding.getDataControl().syncNeeded())
      {
         _iterBinding.getBindingContainer().refreshControl();
      }
      */
      panelBinding.displayStatus(_iterBinding, UIMessageBundle.STR_DONE_EXECUTING, null);
      _updateButtonStatesLater();
   }
   
   public static JUIteratorBinding createViewBinding(JUPanelBinding formBinding, JUNavigationBar control,  
                                             String voInstanceName, String voRSIName, String voRSIBindingName)
   {
      if (!JUIUtil.inDesignTime())
      {
         if (control != null) 
         {
            formBinding.addNavigationBar(control);
            control.mViewBound = true;
         }
         return formBinding.getRowIterBinding(voInstanceName, voRSIName, voRSIBindingName);
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorBinding");

			Constructor[] constructors = clazz.getConstructors();

            java.lang.reflect.Constructor cons = null;

            for (int i = 0; i < constructors.length; i++)
            {
               int argCount = constructors[i].getParameterTypes().length;

               if (argCount == 2)
               {
                  cons = constructors[i];

                  break;
               }
            }

            Object [] args = { voInstanceName, voRSIBindingName};

			Object object = cons.newInstance(args);

            return (JUIteratorBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }
   
   // deprecated
   public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding,  
                                             String voInstanceName, String voRSIName, String voRSIBindingName)
   {
      return createViewBinding(formBinding, null, voInstanceName, voRSIName, voRSIBindingName);
   }
   
   public static JUIteratorBinding createPanelBinding(JUPanelBinding formBinding, JUNavigationBar control)
   {
      if (!JUIUtil.inDesignTime())
      {
         formBinding.addNavigationBar(control);
         if (control.getModel() == null)
         {
            java.util.ArrayList al = formBinding.getAllIterBindingList();
            if (al.size() > 0)
            {
               //set the first iterator in the panelBinding as the infocus iterator
               return (JUIteratorBinding)al.get(0);
            }
         }
         return null;
      }
      else
      {
         try
         {
            Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorPanelBinding");
            Object object = clazz.newInstance(); 
            return (JUIteratorBinding)object;
         }
         catch (Exception e)
         {
            return null;
         }
      }
   }
   
   public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding, JUNavigationBar control)
   {
      return createPanelBinding(formBinding, control);
   }
   
   public void setModel(JUIteratorBinding bind)
   {
      if (JUIUtil.inDesignTime())
      {
        _iterBinding = bind;
        return;
      }
                           
      iteratorBindingChanged(bind);
      addFocusListener(mFocusAdapter);
   }
   
   public void transactionStateChanged(boolean state)
   {
      mDirty = state;
      _updateButtonStatesLater();
   }
   
   public void iteratorBindingChanged(JUIteratorBinding bind)
   {
      if (_bindings[0] == null)
      {
         _bindings[BUTTON_FIRST]     = new JUActionBinding(_buttons[BUTTON_FIRST]   , bind, JUActionBinding.ACTION_FIRST, false);
         _bindings[BUTTON_PREV]      = new JUActionBinding(_buttons[BUTTON_PREV]    , bind, JUActionBinding.ACTION_PREVIOUS, false); 
         _bindings[BUTTON_NEXT]      = new JUActionBinding(_buttons[BUTTON_NEXT]    , bind, JUActionBinding.ACTION_NEXT, false); 
         _bindings[BUTTON_LAST]      = new JUActionBinding(_buttons[BUTTON_LAST]    , bind, JUActionBinding.ACTION_LAST, false); 
         _bindings[BUTTON_INSERT]    = new JUActionBinding(_buttons[BUTTON_INSERT]  , bind, JUActionBinding.ACTION_CREATE_INSERT_ROW, false);   
         _bindings[BUTTON_DELETE]    = new JUActionBinding(_buttons[BUTTON_DELETE]  , bind, JUActionBinding.ACTION_REMOVE_CURRENT_ROW, false);   
         _bindings[BUTTON_COMMIT]    = new JUActionBinding(_buttons[BUTTON_COMMIT]  , bind, JUActionBinding.ACTION_COMMIT_TRANSACTION, false);   
         _bindings[BUTTON_ROLLBACK]  = new JUActionBinding(_buttons[BUTTON_ROLLBACK], bind, JUActionBinding.ACTION_ROLLBACK_TRANSACTION, false);     
         _bindings[BUTTON_FIND]  = new JUActionBinding(_buttons[BUTTON_FIND], bind, JUActionBinding.ACTION_FIND, false);     
         _bindings[BUTTON_EXECUTE]  = new JUActionBinding(_buttons[BUTTON_EXECUTE], bind, JUActionBinding.ACTION_EXECUTE, false);     
      }
      if (mIgnoreIteratorChange)
      {
         return;
      }
      if (bind == _iterBinding && bind != null)
      {
         boolean iterFindMode = bind.isFindMode();
         if (mFindMode != iterFindMode) 
         {
            //move listener from ViewCriteria to RowSet or vice-versa.
            NavigatableRowIterator rsi = (iterFindMode) ? bind.getRowSetIterator() : bind.getNavigatableRowIterator() ;
            if (rsi != null) 
            {
               rsi.removeListener(this);
            }
            
            rsi = (iterFindMode) ? bind.getNavigatableRowIterator() : bind.getRowSetIterator() ;
            
            if (rsi != null) 
            {
               rsi.addListener(this);
            }
         
         }
         mFindMode = iterFindMode;
         _updateButtonStatesLater();
         return;
      }
      
      
      if (mViewBound) 
      {
         //IF this navbar is bound via a ViewBinding - each navbar is bound to one view/iterator
         //then, see if the new binding has the same name as my old one and if so, there
         //must be an RSI switch that led to this call or when the iterator binding is initially set.
         //This should simply bail out if other binding comes in due to change in focus from panel
         //binding, to avoid tracking current iterator in focus for navbars bound as a ViewBinding.
         if (_iterBinding != null) 
         {
            if (bind != null) 
            {
               if (!_iterBinding.getName().equals(bind.getName()))
               {
                  _updateButtonStatesLater();
                  return;
               }
            }
         }
      }
      
      if (_iterBinding != null && _iterBinding.hasRSI()) 
      {
         //Iterator.addActionBinding does the remove.

         NavigatableRowIterator rsi = _iterBinding.getRowSetIterator();
         
         if (rsi != null) 
         {
            rsi.removeListener(this);
            noRSIEvents = true;
         }
      }
      
      if (bind != null) 
      {
         //only when current iter binding is null, we could be in a state
         //when there's no transactionlistening going on.
         if (!mTxnBound) 
         {
            DCDataControl app = bind.getApplication();
            if (app != null) 
            {
               app.addTransactionStateListener(this);
            }
            mTxnBound = true;
         }
         
         /*
         _bindings[BUTTON_FIRST]     = new JUActionBinding(_buttons[BUTTON_FIRST]   , bind, JUActionBinding.ACTION_FIRST, false);
         _bindings[BUTTON_PREV]      = new JUActionBinding(_buttons[BUTTON_PREV]    , bind, JUActionBinding.ACTION_PREVIOUS, false); 
         _bindings[BUTTON_NEXT]      = new JUActionBinding(_buttons[BUTTON_NEXT]    , bind, JUActionBinding.ACTION_NEXT, false); 
         _bindings[BUTTON_LAST]      = new JUActionBinding(_buttons[BUTTON_LAST]    , bind, JUActionBinding.ACTION_LAST, false); 
         _bindings[BUTTON_INSERT]    = new JUActionBinding(_buttons[BUTTON_INSERT]  , bind, JUActionBinding.ACTION_CREATE_INSERT_ROW, false);   
         _bindings[BUTTON_DELETE]    = new JUActionBinding(_buttons[BUTTON_DELETE]  , bind, JUActionBinding.ACTION_REMOVE_CURRENT_ROW, false);   
         _bindings[BUTTON_COMMIT]    = new JUActionBinding(_buttons[BUTTON_COMMIT]  , bind, JUActionBinding.ACTION_COMMIT_TRANSACTION, false);   
         _bindings[BUTTON_ROLLBACK]  = new JUActionBinding(_buttons[BUTTON_ROLLBACK], bind, JUActionBinding.ACTION_ROLLBACK_TRANSACTION, false);     
         */
         for (int i = 0;  i <= BUTTON_EXECUTE; i++) 
         {
            bind.addActionBinding(_bindings[i]);
         }
         
         mFindMode = bind.isFindMode();
      }
      else
      {
         if (_iterBinding != null)
         {
            for (int i = 0;  i <= BUTTON_EXECUTE; i++) 
            {
               _iterBinding.removeActionBinding(_bindings[i]);
            }
         }

         for (int j = 0; j < _bindings.length; j++)
         {
            _bindings[j] = null;
         }
      }
      
      _iterBinding = bind;
      _updateButtonStatesLater();
   }
   
   
   public JUIteratorBinding getModel()
   {
      return _iterBinding;
   }
   
   /**
   *  Sets the icon to be used for a button. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new icon.
   *  @deprecated
   */
   public void setButtonIcon(int button, Icon icon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setPressedIcon(null);
      _buttons[button].setDisabledIcon(null);
      _buttons[button].setRolloverEnabled(false);
      _buttons[button].setRolloverIcon(null);
      _buttons[button].setIcon(icon);
      _buttonIcons[button] = (ImageIcon)icon;
      revalidate();
   }
   
   /**
   *  Gets the icon being used for a button. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @return The icon being used by button.
   *  @deprecated
   */
   
   public Icon getButtonIcon(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _buttons[button].getIcon();
   }
   
   /**
   *  Sets the icon to be used for a button. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new button icon.
   *  @param  pressedIcon The new button pressed icon.
   *  @param  disabledIcon The new button disabled icon.
   *  @param  rolloverIcon The new button rollover icon.
   */
   public void setButtonIcons(int button, Icon icon, Icon pressedIcon,
                            Icon disabledIcon, Icon rolloverIcon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setIcon(icon);
      _buttons[button].setPressedIcon(pressedIcon);
      _buttons[button].setDisabledIcon(disabledIcon);
	  
	  //Maintain the buttons in the array also.
      _buttonIcons[button] = (ImageIcon)icon;
       _onButtonIcons[button] = (ImageIcon)pressedIcon;
      _disButtonIcons[button] = (ImageIcon)disabledIcon;
      _rollButtonIcons[button] = (ImageIcon)rolloverIcon;
	  
	  if (button == BUTTON_FIND)
	  {
	  	_buttonCancelIcon = (ImageIcon)pressedIcon;
	  }
	  
      if (rolloverIcon != null)
      {
         _buttons[button].setRolloverEnabled(true);
      }
      else
      {
         _buttons[button].setRolloverEnabled(false);
      }
      _buttons[button].setRolloverIcon(rolloverIcon);
      revalidate();
   }
   
   /**
   *  Gets the icon being used for a button. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  type The icon type. Allowed values are BUTTON_NORMAL, BUTTON_PRESSED,
   *          BUTTON_DISABLED, and BUTTON_ROLLOVER.
   *  @return The icon being used by button.
   */
   
   public Icon getButtonIcons(int button, int type)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      switch (type)
      {
      case BUTTON_NORMAL:
         return _buttons[button].getIcon();
      case BUTTON_PRESSED:
         return _buttons[button].getPressedIcon();
      case BUTTON_DISABLED:
         return _buttons[button].getDisabledIcon();
      case BUTTON_ROLLOVER:
         return _buttons[button].getRolloverIcon();
      default:
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
   }
   
   /**
   *  Sets the icon to be used when a button is pressed. <P>
   *  @param  button The button whose icon should be changed.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @param  icon The new icon.
   *  @deprecated
   */
   
   public void setButtonPressedIcon(int button, Icon icon)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      _buttons[button].setDisabledIcon(null);
      _buttons[button].setPressedIcon(icon);
      _disButtonIcons[button] = (ImageIcon)icon;
      revalidate();
   }
   
   /**
   *  Gets the icon displayed when a navigation bar button is pressed. <P>
   *  @param  button The button whose icon is being requested.
   *           Allowed values should be one of defined by the BUTTON_XXX
   *           constants.
   *  @return The icon being used by the button in the pressed button.
   *  @deprecated
   */
   
   public Icon getButtonPressedIcon(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
   
      return _buttons[button].getPressedIcon();
   }
   
   /**
   * displays a busy cursor
   */
   public void showBusyCursor()
   {
      if (!_isShowingBusyCursor)
      {
         Container p = getTopLevelAncestor();
         if ( p != null )
         {
             _defaultCursor = p.getCursor();
             _isShowingBusyCursor = true;
             p.setCursor(getBusyCursor());
         }
      }
   }
   
   /**
   * Shows default cursor.
   *
   */
   public void restoreDefaultCursor()
   {
      if (_isShowingBusyCursor)
      {
         Container p = getTopLevelAncestor();
         if ( p != null )
         {
             _isShowingBusyCursor = false;
             p.setCursor(_defaultCursor);
         }
      }
   }
   
   /**
   * Changes the cursor used to indicate busy status.
   *
   * @param busyCursor Cursor used to indicate busy status.
   */
   public void setBusyCursor(Cursor busyCursor)
   {
      _busyCursor = busyCursor;
   }
   
   /**
   * Gets the cursor currently used to indicate busy status.
   *
   * @return get The busy cursor.
   */
   public Cursor getBusyCursor()
   {
      return _busyCursor;
   }
   
   /**
   *  Gets the button object used in the toolbar.
   *
   *  @param  button A constant indicating which button is requested.
   *          Allowed values should be one of defined by the BUTTON_XXX
   *          constants.
   *  @return The button object.
   
   */
   public JButton getButton(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _buttons[button];
   }
   
   /**
   *  Checks if the button both exists and is enabled.
   *  if it does not existe, because the appropriate setHas... method is set to false, or if the
   *  button is disabled, this method returns false, otherwise it returns true.
   *
   *  @param buttonid  A constant indicating which button is requested.
   *          Allowed values should be one of defined by the BUTTON_XXX
   *          constants.
   *  @return true or false to indicate if this button can be used
   */
   public boolean isButtonActive(int buttonid)
   {
      try
      {
         if (buttonid == BUTTON_FIRST || buttonid == BUTTON_PREV || buttonid == BUTTON_NEXT || buttonid == BUTTON_LAST)
            return (getHasNavigationButtons() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_INSERT)
            return (getHasInsertButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_DELETE)
            return (getHasDeleteButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_COMMIT || buttonid == BUTTON_ROLLBACK)
            return (getHasTransactionButtons() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_FIND)
            return (getHasFindButton() && getButton(buttonid).isEnabled());
         if (buttonid == BUTTON_EXECUTE)
            return (getHasExecuteButton() && getButton(buttonid).isEnabled());

         return false;
      }
      catch(Exception exp)
      {
         return false;
      }
   }
   // Attributes
   
   /**
   * Determines if the toolbar has the buttons that are used to change the
   * current row of the bound ViewObject.
   * @return True if the currency can be changed, otherwise returns false.
   */
   public boolean getHasNavigationButtons()
   {
      return(getComponentIndex(_buttons[BUTTON_FIRST]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the navigation buttons or not.
   *
   * @param b If true, the navigation buttons are included in the bar,
   *          else the navigation buttons are not included.
   */
   public void setHasNavigationButtons(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_FIRST);
         _addButton(BUTTON_PREV);
         _addButton(BUTTON_NEXT);
         _addButton(BUTTON_LAST);
      
      }
      else
      {
         _removeButton(BUTTON_FIRST);
         _removeButton(BUTTON_PREV);
         _removeButton(BUTTON_NEXT);
         _removeButton(BUTTON_LAST);
      
      }
   }
   
   /**
   * Determines if the toolbar has the button that can be used to
   * insert a new row in the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   public boolean getHasInsertButton()
   {
      return(getComponentIndex(_buttons[BUTTON_INSERT]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the insert button or not.
   * @param b If true, the insert button is be included, else the button is
   * removed.
   */
   public void setHasInsertButton(boolean b)
   {
   
      if (b)
      {
         _addButton(BUTTON_INSERT);
      }
      else
      {
         _removeButton(BUTTON_INSERT);
      }
   }
   
   /**
   * Determines if the toolbar has the button that can be used to
   * delete an existing row from the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasDeleteButton()
   {
      return(getComponentIndex(_buttons[BUTTON_DELETE]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the delete button or not.
   * @param b If true, the delete button is be included, otherwise the button is
   * removed.
   */
   
   public void setHasDeleteButton(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_DELETE);
      }
      else
      {
         _removeButton(BUTTON_DELETE);
      }
   }
   
   /**
   * Determines if the toolbar has the buttons that can be used to
   * commit/rollback the changes made to the bound Transaction.
   * @return True if the buttons are included, otherwise returns false.
   */
   public boolean getHasTransactionButtons()
   {
      return(getComponentIndex(_buttons[BUTTON_COMMIT]) != -1);
   }
   
   /**
   * Tells the toolbar whether to include the commit/rollback buttons or not.
   * @param b If true the buttons are included, otherwise the buttons are removed.
   */
   public void setHasTransactionButtons(boolean b)
   {
      if (b)
      {
         _addButton(BUTTON_COMMIT);
         _addButton(BUTTON_ROLLBACK);
      }
      else
      {
         _removeButton(BUTTON_COMMIT);
         _removeButton(BUTTON_ROLLBACK);
      }
   }
   
   
   
   /**
   * Determines if the toolbar has the button that can be used to
   * run a restricted query (using ViewCriteria) on the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasFindButton()
   {
      return _hasFindButton;
   }
   
   /**
   * Tells the toolbar whether to include the 'Find' button or not.
   * @param b If true, the 'Find' button is included, otherwise the button is
   * removed.
   */
   public void setHasFindButton(boolean b)
   {
      _hasFindButton = b; 
      if (b)
      {
         _addButton(BUTTON_FIND);
      }
      else
      {
         _removeButton(BUTTON_FIND);
      }
   }
   
   
   
   /**
   * Determines if the toolbar has the button that can be used to
   * execute the viewobject query on the bound ViewObject.
   * @return True if the button is included, otherwise returns false.
   */
   
   public boolean getHasExecuteButton()
   {
      return _hasExecuteButton;
   }
   
   /**
   * Tells the toolbar whether to include the 'Execute' button or not.
   * @param b If true, the 'Execute' button is included, otherwise the button is
   * removed.
   */
   public void setHasExecuteButton(boolean b)
   {
      _hasExecuteButton = b; 
      if (b)
      {
         _addButton(BUTTON_EXECUTE);
      }
      else
      {
         _removeButton(BUTTON_EXECUTE);
      }
   }
   
   // Private Methods
   
   private boolean _addButton(int buttonPosition)
   {
   
     if (getComponentIndex(_buttons[buttonPosition]) == -1)
     {
         int pos ;
         if ((buttonPosition + 1) <= getComponentCount())
         {
            pos = buttonPosition;
         }
         else
         {
            pos = -1;
         }
         
         _buttons[buttonPosition].addFocusListener(mFocusAdapter);
         _buttons[buttonPosition].setVisible(true);
         _buttons[buttonPosition].setEnabled(false);
         _buttons[buttonPosition].setOpaque(false);
         add(_buttons[buttonPosition],pos);
         
         revalidate();
         return true;
     }
     return false;
   }
   
   private boolean _removeButton(int buttonPosition)
   {
     _buttons[buttonPosition].removeFocusListener(mFocusAdapter);
     if (getComponentIndex(_buttons[buttonPosition]) != -1)
     {
         remove(_buttons[buttonPosition]);
         revalidate();
         return true;
     }
     return false;
   }
   
   //cache one instance of runnable for this navbar.
   Runnable buttonStatesRunnableInstance = new Runnable() 
   {
      public void run() 
      {
         buttonStatesRunnable = null;
         _updateButtonStates();
      }
   };

   //use this as a transient variable to hold runnable.
   //if not null then no need to create yet another runnable
   //thread.
   Runnable buttonStatesRunnable;

   protected void _updateButtonStatesLater()
   {
      if (buttonStatesRunnable == null) 
      {
         buttonStatesRunnable = buttonStatesRunnableInstance;
         SwingUtilities.invokeLater(buttonStatesRunnable);
      }
   }
   
   protected void _updateButtonStates()
   {
      JUIteratorBinding iter = getModel();
      
      // JRS 3292112.  Make the condition less conservative.  Sometimes
      // the iterator is not yet "visible" during intialization.
      // SJV-> Taking out the above fix from JR as it leads to eager
      // execution of method iterators.
      boolean iterValid = (iter != null);
      //boolean iterValid = (iter != null && iter.isIteratorMadeVisible());

      if (noRSIEvents)
      {
         if (iterValid && iter.isRowSetEventsEnabled() && (iter.hasRSI() || iter.isFindMode()))
         {
            //for bc4j, go over and register for RSI events.
            NavigatableRowIterator rsi = iter.getNavigatableRowIterator();
            if (rsi != null) 
            {
               rsi.addListener(this);
            }
         }
      }

      JButton btn = _buttons[BUTTON_FIND];
      if (mFindMode) 
      {
         btn.setIcon(_buttonCancelIcon);
         btn.setRolloverIcon(_buttonCancelIcon);
         btn.setToolTipText(_tooltipCancelFind);
      }
      else
      {
         btn.setIcon(_buttonIcons[BUTTON_FIND]);
         btn.setRolloverIcon(_buttonIcons[BUTTON_FIND]);
         btn.setToolTipText(_TOOLTIP[BUTTON_FIND]);
      }
      
      //if (!(iterValid && iter.isIteratorMadeVisible())) 
      if (!(iterValid)) 
      {
         //disable all buttons.
         for (int i = 0; (i < _buttons.length); i++)
         {
            _buttons[i].setEnabled(false);
            _buttons[i].setBorderPainted(false);
            _buttons[i].setRolloverEnabled(false);
         }
         return;
      }
      boolean state;
      for (int i = 0; (i < _buttons.length); i++)
      {
         state = _isEnabled(i);
         _buttons[i].setEnabled(state);
         _buttons[i].setBorderPainted(false);
         _buttons[i].setRolloverEnabled(state);
      }
   }

   private boolean _isEnabled(int indx)
   {
      if (_bindings[indx] != null)
      {
         return _bindings[indx].isActionEnabled();
      }
      switch (indx)
      {
         case BUTTON_COMMIT:
         case BUTTON_ROLLBACK:
            return getHasTransactionButtons() && _isDirty();
      }
      return false;
   }
   
   
   /*
   private int _findButton(JButton button)
   {
     for(int i = 0 ; i < _buttons.length ; i++)
     {
         if (_buttons[i] == button)
             return i;
     }
     return -1;
   }
   */
   private synchronized void _loadImages()
   {
      if (_buttonIcons != null)
      {
         return;
      }
      
      _buttonIcons = new ImageIcon[_IMAGES.length];
      _onButtonIcons = new ImageIcon[_IMAGES.length];
      _disButtonIcons = new ImageIcon[_IMAGES.length];
      _rollButtonIcons = new ImageIcon[_IMAGES.length];
      
      for (int i = 0; (i < _IMAGES.length); i++)
      {
         int index = i * 4;
         if (_IMAGEICONS[index] != null)
             _buttonIcons[i] = _IMAGEICONS[index];
      
         if (_IMAGEICONS[++index] != null)
             _onButtonIcons[i] = _IMAGEICONS[index];
      
         if (_IMAGEICONS[++index] != null)
             _disButtonIcons[i] = _IMAGEICONS[index];
      
         if (_IMAGEICONS[++index] != null)
             _rollButtonIcons[i] = _IMAGEICONS[index];
      }
      
      _buttonCancelIcon = _IMAGEICONS[_IMAGEICONS.length - 1];
   }
   
   /**
   *  check if the transaction is dirty
   */
   private boolean _isDirty()
   {
      DCDataControl app = (_iterBinding != null) ? _iterBinding.getDataControl() : null;
      return (app != null) ? app.isTransactionModified() : false;
   }
   
   //
   // RowSet listener
   //
   public void navigated(NavigationEvent event)
   {
      _updateButtonStatesLater();
   }
   
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      _updateButtonStatesLater();
   }
   
   public void rangeScrolled(ScrollEvent event)
   {
   }
   
   public void rowDeleted(DeleteEvent event)
   {
      if (!mDirty) 
      {
         _internalUpdateState();
      }
      else
      {
         //bug 2510912 NavBar delete button not disabled when
         //no more rows. This should force delete button to get repainted.
         if (_iterBinding != null) 
         {
            _updateButtonStatesLater();
         }
      }

   }
   
   public void rowInserted(InsertEvent event)
   {
      _internalUpdateState();
   }
   
   public void rowUpdated(UpdateEvent event)
   {
      _internalUpdateState();
   }

   void _internalUpdateState()
   {
      //DO NOT SEND DIRTY EVENT IF THE CURRENT ITERATOR IS IN FIND MODE.
      if (!mDirty && (_iterBinding != null && !_iterBinding.isFindMode()))
      {
         _iterBinding.getApplication().transactionStateChanged(true);
         _updateButtonStatesLater();
      }
   }
   
   public FocusListener getDefaultFocusListener()
   {
      return mFocusAdapter;
   }
   
   /**
   *  Get the button binding for a given button. <P>
   */
   
   public JUActionBinding getButtonActionBinding(int button)
   {
      if (button < BUTTON_FIRST || button > BUTTON_EXECUTE)
      {
         throw new JboException(UIMessageBundle.getResString(UIMessageBundle.STR_NAV_INVALID_BUTTON_INDEX));
      }
      return _bindings[button];
   }

   public void release()
   {
      if (_iterBinding != null) 
      {
         DCDataControl app = _iterBinding.getApplication();
         if (app != null) 
         {
            app.removeTransactionStateListener(this);
         }
         for (int i = 0; i < _buttons.length; i++) 
         {
            if (_buttons[i] != null) 
            {
               _buttons[i].setEnabled(false);
            }
         }
         iteratorBindingChanged(null);
      }
   }
}


