 /*
  * @(#)JUStatusBar.java
  *
  * Copyright 2001-2002 by Oracle Corporation,
  * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
  * All rights reserved.
  *
  * This software is the confidential and proprietary information
  * of Oracle Corporation.
  */

 package oracle.jbo.uicli.controls;

 import java.awt.Color;
 import java.awt.Dimension;
 import java.awt.Font;
 import java.awt.GridBagConstraints;
 import java.awt.GridBagLayout;
 import java.awt.Insets;
 import java.awt.LayoutManager;
 import java.lang.reflect.Constructor;
 import javax.swing.BorderFactory;
 import javax.swing.ImageIcon;
 import javax.swing.Icon;
 import javax.swing.JLabel;
 import javax.swing.JPanel;
 import javax.swing.JProgressBar;
 import javax.swing.SwingUtilities;
 import javax.swing.border.Border;
 import oracle.jbo.DeleteEvent;
 import oracle.jbo.InsertEvent;
 import oracle.jbo.NavigatableRowIterator;
 import oracle.jbo.NavigationEvent;
 import oracle.jbo.RangeRefreshEvent;
 import oracle.jbo.RowSetIterator;
 import oracle.jbo.RowSetListener;
 import oracle.jbo.ScrollEvent;
 import oracle.jbo.UpdateEvent;
 import oracle.jbo.common.StringManager;
 import oracle.jbo.format.DefaultNumberFormatter;
 import oracle.jbo.format.Formatter;
 import oracle.jbo.uicli.UIMessageBundle;
 import oracle.adf.model.binding.DCIteratorBinding;
 import oracle.adf.model.binding.DCControlBinding;
 import oracle.jbo.uicli.binding.JUCtrlValueBinding;
 import oracle.jbo.uicli.binding.JUIteratorBinding;
 import oracle.jbo.uicli.binding.JUStatusBarInterface;
 import oracle.jbo.uicli.binding.JUTransactionStateListener;
 import oracle.jbo.uicli.jui.JUIUtil;
 import oracle.jbo.uicli.jui.JUPanelBinding;

 // imports
 /**
  **    JUStatusBar<P>
  **
  **    Implements the JUStatusBar control to display the status of a rowset.<p>
  **
  **    When a dataItemName is specified, it tracks the status
  **    of the rowset to which it is bound; otherwise, it tracks the
  **    status of the data bound control (Rowset) which currently has
  **    the focus.<p>
  **
  **    The JUStatusBar has six indicators:
  **    <ul>
  **    <li>Progress bar: current row's percent "through" the result set
  **    <li>Current row number: row number of the current row
  **    <li>Row count: number of rows in the result set
  **    <li>Fetched count: number of rows fetched from the database
  **    <li>Modified flag: true if one or more rows has been changed
  **    <li>Message area: displays the name of the current result set
  **    <li>Working icon: a graphic that is display when a long running activity
  **                      begins
  **    </ul>
  **
  **    Each of these indicators can be hidden or shown by using the appropriate
  **    method call. The format of text displayed in each indicator can be
  **    controlled setting the value of the appropriate format string and
  **    formatter.<p>
  **
  **    The default display state for each indicator is:
  **    <ul>
  **    <li>Progress bar: true
  **    <li>Current row number: true
  **    <li>Row count: true
  **    <li>Fetched count: false
  **    <li>Modified flag: true
  **    <li>Message area: true
  **    <li>Working icon: true
  **    </ul>
  **
  **    @version PUBLIC
  */
 public class JUStatusBar
     extends JPanel
     implements RowSetListener, JUStatusBarInterface, JUTransactionStateListener 
 {
     private static final int DEFAULT_PROGRESS_HEIGHT = 21; // pixels
     private static final int DEFAULT_PROGRESS_WIDTH = 100; // pixels
     private static final String BLANK = " ";

     private Color _foreGround = null;
     private Color _backGround = null;
     private Font _font = null;
     private Dimension _progressBarSize =
         new Dimension(DEFAULT_PROGRESS_WIDTH, DEFAULT_PROGRESS_HEIGHT);

     private boolean _hasModeIcon = true;
     private boolean _hasMessageArea = true;
     private boolean _hasCurrentRow = true;
     private boolean _hasRowCount = false; //do not need to display the maxRowCount
                                           //by default as it slows down due to extra query.
     private boolean _hasModifiedFlag = true;
     private boolean _hasPercentDone = false;

     private boolean _modeIconShown = false;
     private boolean _messageAreaShown = false;
     private boolean _currentRowShown = false;
     private boolean _rowCountShown = false;
     private boolean _modifiedFlagShown = false;
     private boolean _percentDoneShown = false;

     private JLabel _modeIcon;
     private StatusBarLabelControl _currentRow;
     private StatusBarLabelControl _rowCount;
     private StatusBarLabelControl _modifiedFlag;
     private StatusBarLabelControl _messageArea;
     private StatusBarProgressControl _percentDone;

     private String _currentRowFormatString;
     private String _rowCountFormatString;
     private String _modifiedFlagFormatString;
     private String _messageAreaFormatString;
     private String _percentDoneFormatString;

     private Formatter _currentRowFormatter;
     private Formatter _rowCountFormatter;
     private Formatter _modifiedFlagFormatter;
     private Formatter _messageAreaFormatter;
     private Formatter _percentDoneFormatter;

     private Border _labelBorder;
     private Border _barBorder;
     private GridBagLayout _barLayout;
     private int _preferredHeight = DEFAULT_PROGRESS_HEIGHT;

     private String mMsgStr = BLANK;
     NavigatableRowIterator mCurrentRSI;
     DCIteratorBinding mIterBinding;
     private boolean mDirty = false;
     private static final String MSG_BUNDLE = "oracle.jbo.uicli.UIMessageBundle";
     private String _dirtyStr;
     private String _cleanStr;

     private Icon _imgData;
     private Icon _imgFind;

     private boolean mNotInited = true;
     private JUPanelBinding mFormBinding;
     
     /**
     ** Create a new StatusBar. <P>
     **
     **
     */
     public JUStatusBar()
     {
         _barBorder = BorderFactory.createEmptyBorder();
         _labelBorder = BorderFactory.createLoweredBevelBorder();

         _barLayout = new GridBagLayout();

         setBorder(_barBorder);
         super.setLayout(_barLayout);

         _currentRowFormatString = UIMessageBundle.getResString(UIMessageBundle.STR_SB_CURRENT_ROW_FORMAT);
         _rowCountFormatString = UIMessageBundle.getResString(UIMessageBundle.STR_SB_ROW_COUNT_FORMAT);
         _modifiedFlagFormatString = UIMessageBundle.getResString(UIMessageBundle.STR_SB_MODIFIED_LABEL);
         _dirtyStr = UIMessageBundle.getResString(UIMessageBundle.STR_SB_MODIFIED_TRUE_STATE);
         _cleanStr = UIMessageBundle.getResString(UIMessageBundle.STR_SB_MODIFIED_FALSE_STATE);
         
         _currentRowFormatter = new DefaultNumberFormatter();

         _rowCountFormatter = _currentRowFormatter;
         _updateIndicatorsLater();

         JLabel t = new JLabel("test");
         if (t != null)
         {
             super.setForeground(t.getForeground());
             super.setBackground(t.getBackground());
         }
     } // JUStatusBar

     
     public static JUIteratorBinding createViewBinding(JUPanelBinding formBinding,  
                                                 String voInstanceName, String voRSIName, String voRSIBindingName)
     {
        if (!JUIUtil.inDesignTime())
        {
           return formBinding.getRowIterBinding(voInstanceName, voRSIName, voRSIBindingName);
        }
        else
        {
           try
           {
              Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorBinding");
              
              Constructor[] constructors = clazz.getConstructors();

             
              for (int i = 0; i < constructors.length; i++)
              {
                 int argCount = constructors[i].getParameterTypes().length;

                 if (argCount == 1)
                 {
                    Object [] args = { voInstanceName };
                   
                                    Object object = constructors[i].newInstance(args);
              
                                    return (JUIteratorBinding)object;
                 }
              }
                      return null;
           }
           catch (Exception e)
           {
              return null;
           }
        }
     }

     public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding,  
                                                 String voInstanceName, String voRSIName, String voRSIBindingName)
     {
        return createViewBinding(formBinding, voInstanceName, voRSIName, voRSIBindingName);
     }

     public static JUIteratorBinding createPanelBinding(JUPanelBinding formBinding, JUStatusBar control)
     {
        if (!JUIUtil.inDesignTime())
        {
           //formBinding.getDataControl().addTransactionStateListener(control);

           control.mNotInited = true;
           control.mFormBinding = formBinding;
           formBinding.addStatusBarInterface(control);

           java.util.ArrayList al = formBinding.getAllIterBindingList();
           if (al.size() > 0) 
           {
              //return the first iterator in this form if binding to the panel.
              //so that focus status bar is tracking atleast some iterator.
              return (JUIteratorBinding)al.get(0);
           }
           return null;
        }
        else
        {
           try
           {
              Class clazz = Class.forName("oracle.jbo.dt.ui.jui.propertyeditors.dtmodels.DTIteratorPanelBinding");
              Object object = clazz.newInstance(); 
              return (JUIteratorBinding)object;
           }
           catch (Exception e)
           {
              return null;
           }
        }
     }

     public static JUIteratorBinding getModelInstance(JUPanelBinding formBinding, JUStatusBar control)
     {
        return createPanelBinding(formBinding, control);
     }

     public DCIteratorBinding getModel()
     {
        return mIterBinding;
     }

     public void setModel(JUIteratorBinding bind)
     {
        setModel((DCIteratorBinding)bind);
     }

     public void setModel(DCIteratorBinding bind)
     {
        //simply for DT purposes.
        if (bind == null || JUIUtil.inDesignTime())
        {
           displayStatus(mIterBinding, UIMessageBundle.STR_SB_UNBOUND, new Object[0]);
           mIterBinding = bind;
           if (mCurrentRSI != null) 
           {
              mCurrentRSI.removeListener(this);
           }
           mCurrentRSI = null;
        }
        else
        {

           if (bind.isIteratorMadeVisible())
           {
              mIterBinding = bind;
              NavigatableRowIterator rsi = bind.getNavigatableRowIterator();

              if (mCurrentRSI != rsi)
              {
                 if (mCurrentRSI != null) 
                 {
                    mCurrentRSI.removeListener(this);
                 }

                 mCurrentRSI = rsi;
                 if (rsi != null) 
                 {
                    rsi.addListener(this);
                 }
              }
           }

           displayStatus(bind, UIMessageBundle.STR_SB_EDITING, new Object[]{bind.getDisplayName()}); 
        }
     }


     /**
     **  Returns the LayoutManger used by the StatusBar.<P>
     **
     **  The StatusBar only uses a GridBag layout manager defined in
     **  its constructor.
     **
     **  @return The LayoutManger used by the StatusBar.
     */
     public LayoutManager getLayout()
     {
         return(_barLayout);
     }

     /**
     **  An override of the setLayout() inherited from java.awt.Container.<P
     **
     **  The StatusBar uses a GridBag layout manager. Any call to this
     **  method with a layout manager will be ignored. The StatusBar
     **  only uses a GridBag layout manager defined in its constructor.
     **
     **  @param l A LayoutManger that will be ignored by the StatusBar.
     */
     public void setLayout(LayoutManager l)
     {
     }

     /**
     ** Sets the progress indicator's size. <P>
     **
     ** @param progressBarSize The desired size of the progress indicator.
     ** @see #getProgressBarSize()
     */
     public void setProgressBarSize(Dimension progressBarSize)
     {
         _progressBarSize = progressBarSize;
         if (_percentDone != null)
         {
             _progressBarSize.height = _percentDone.getMinimumSize().height;
             _percentDone.setPreferredSize(_progressBarSize);
             _percentDone.setMinimumSize(_progressBarSize);
             _percentDone.setMaximumSize(_progressBarSize);
         }
     } // setProgressBarSize

     /**
     ** Returns the progress indicator's size. <P>
     **
     ** @return The progress indicator's size.
     ** @see #setProgressBarSize(Dimension progressBarSize)
     */
     public Dimension getProgressBarSize()
     {
         return(_progressBarSize);
     } // getProgressBarSize

     /**
     ** Sets the border sytle for the status bar's indicators.<P>
     **
     ** @param indicatorBorderStyle The border sytle for the status bar's
     **                             indicators.
     ** @see #getIndicatorBorderStyle()
     */
     public void setIndicatorBorderStyle(Border indicatorBorderStyle)
     {
         _labelBorder = indicatorBorderStyle;
         if (_currentRow != null)
         {
             _currentRow.setBorder(_labelBorder);
         }
         if (_rowCount != null)
         {
             _rowCount.setBorder(_labelBorder);
         }
         if (_modifiedFlag != null)
         {
             _modifiedFlag.setBorder(_labelBorder);
         }
         if (_messageArea != null)
         {
             _messageArea.setBorder(_labelBorder);
         }
         if (_percentDone != null)
         {
             _percentDone.setBorder(_labelBorder);
         }
         if (_modeIcon != null)
         {
             _modeIcon.setBorder(_labelBorder);
         }
     } // setIndicatorBorderStyle

     /**
     ** Returns the border sytle used by the status bar's indicators.<P>
     **
     ** @return The border sytle used by the status bar's indicators.
     ** @see #setIndicatorBorderStyle(Border indicatorBorderStyle)
     */
     public Border getIndicatorBorderStyle()
     {
         return(_labelBorder);
     } // getIndicatorBorderStyle

     /**
     ** StatusBar override. <P>
     **
     ** Sets the font for the status bar and all contained components.
     **
     ** @param nuFont The font to use for the status bar and all contained
     **               components
     ** @see #getFont()
     */
     public void setFont(Font nuFont)
     {
         _font = nuFont;
         super.setFont(_font);

         if (_currentRow != null)
         {
             _currentRow.setFont(_font);
         }
         if (_rowCount != null)
         {
             _rowCount.setFont(_font);
         }
         if (_modifiedFlag != null)
         {
             _modifiedFlag.setFont(_font);
         }
         if (_messageArea != null)
         {
             _messageArea.setFont(_font);
         }
         if (_modeIcon != null)
         {
             _modeIcon.setFont(_font);
         }
     } // setFont

     /**
     ** StatusBar override. <P>
     **
     ** Returns the font for the status bar and all contained conponents.
     **
     ** @return The font used for the status bar and all contained components.
     ** @see #setFont(Font nuFont)
     */
     public Font getFont()
     {
         return(_font);
     } // getFont

     /**
     ** StatusBar override. <P>
     **
     ** @param icon The icon to use to display Data mode status
     */
     public void setDataModeIcon(Icon icon)
     {
        _imgData = icon;
     }

     /**
     ** StatusBar override. <P>
     **
     ** @param icon The icon to use to display Find mode status
     */
     public void setFindModeIcon(Icon icon)
     {
        _imgFind = icon;
     }

     /**
     ** StatusBar override. <P>
     **
     ** @param c The foreground color for the StatusBar.
     */
     public void setForeground(Color c)
     {
         _foreGround = c;
         super.setForeground(c);
         if (_currentRow != null)
         {
             _currentRow.setForeground(c);
         }
         if (_rowCount != null)
         {
             _rowCount.setForeground(c);
         }
         if (_modifiedFlag != null)
         {
             _modifiedFlag.setForeground(c);
         }
         if (_messageArea != null)
         {
             _messageArea.setForeground(c);
         }
         if (_modeIcon != null)
         {
             _modeIcon.setForeground(c);
         }
     } // setForeground

     /**
     ** StatusBar override. <P>
     **
     ** @param c The background color for the StatusBar.
     */
     public void setBackground(Color c)
     {
         _backGround = c;
         super.setBackground(c);
         if (_currentRow != null)
         {
             _currentRow.setBackground(c);
         }
         if (_rowCount != null)
         {
             _rowCount.setBackground(c);
         }
         if (_modifiedFlag != null)
         {
             _modifiedFlag.setBackground(c);
         }
         if (_messageArea != null)
         {
             _messageArea.setBackground(c);
         }
         if (_modeIcon != null)
         {
             _modeIcon.setBackground(c);
         }
     } // setBackground

     /**
     ** StatusBar override. <P>
     **
     ** @return The maximum dimensions of the StatusBar.
     */
     public Dimension getMaximumSize()
     {
         return(getPreferredSize());
     } // getPreferredSize

     public void setMaximumSize(Dimension dim)
     {
         dim.height = _preferredHeight;
         super.setMaximumSize(dim);
     }

     /**
     ** StatusBar override. <P>
     **
     ** @return The minimum Dimensions of the StatusBar.
     */
     public Dimension getMinimumSize()
     {
         return(getPreferredSize());
     } // getPreferredSize

     public void setMinimumSize(Dimension dim)
     {
         dim.height = _preferredHeight;
         super.setMinimumSize(dim);
     } // getPreferredSize

     /**
     ** StatusBar override. <P>
     **
     ** @return The preferred dimensions of the StatusBar.
     */
     public Dimension getPreferredSize()
     {
        try
        {
           return(new Dimension(getParent().getSize().width, _preferredHeight));
        }
        catch (Exception e)
        {
           return new Dimension(50, 350);
        }
     } // getPreferredSize

     public void setPreferredSize(Dimension dim)
     {
         dim.height = _preferredHeight;
         super.setPreferredSize(dim);
     } // getPreferredSize
     
     /**
     ** Sets the formatter for formatting the CurrentRow status label. <P>
     **
     ** @param currentRowFormatter Formatter for formatting the CurrentRow
     **                            status label.
     ** @see #getCurrentRowFormatter()
     */
     public void setCurrentRowFormatter(Formatter currentRowFormatter)
     {
         _currentRowFormatter = currentRowFormatter;
         _updateStatusBarControl(_currentRow,_currentRowFormatter);
         _updateIndicatorsLater();
     } // setCurrentRowFormatter

     /**
     ** Returns the formatter for formatting the CurrentRow status label. <P>
     **
     ** @return The formatter for formatting the CurrentRow status label.
     ** @see #setCurrentRowFormatter(Formatter currentRowFormatter)
     */
     public Formatter getCurrentRowFormatter()
     {
         return(_currentRowFormatter);
     } // getCurrentRowFormatter

     /**
     ** Sets the formatter for formatting the RowCount status label. <P>
     **
     ** @param rowCountFormatter Formatter for formatting the RowCount
     **                            status label.
     ** @see #getRowCountFormatter()
     */
     public void setRowCountFormatter(Formatter rowCountFormatter)
     {
         _rowCountFormatter = rowCountFormatter;
         _updateStatusBarControl(_rowCount,_rowCountFormatter);
         _updateIndicatorsLater();
     } // setRowCountFormatter

     /**
     ** Returns the formatter for formatting the RowCount status label. <P>
     **
     ** @return The formatter for formatting the RowCount status label.
     ** @see #setRowCountFormatter(Formatter RowCountFormatter)
     */
     public Formatter getRowCountFormatter()
     {
         return(_rowCountFormatter);
     } // getRowCountFormatter

     /**
     ** Sets the formatter for formatting the ModifiedFlag status label. <P>
     **
     ** @param modifiedFlagFormatter Formatter for formatting the ModifiedFlag
     **                            status label.
     ** @see #getModifiedFlagFormatter()
     */
     public void setModifiedFlagFormatter(Formatter modifiedFlagFormatter)
     {
         _modifiedFlagFormatter = modifiedFlagFormatter;
         _updateStatusBarControl(_modifiedFlag,_modifiedFlagFormatter);
         _updateIndicatorsLater();
     } // setModifiedFlagFormatter

     /**
     ** Returns the formatter for formatting the ModifiedFlag status label. <P>
     **
     ** @return The formatter for formatting the ModifiedFlag status label.
     ** @see #setModifiedFlagFormatter(Formatter ModifiedFlagFormatter)
     */
     public Formatter getModifiedFlagFormatter()
     {
         return(_modifiedFlagFormatter);
     } // getModifiedFlagFormatter

     /**
     ** Sets the formatter for formatting the MessageArea status label. <P>
     **
     ** @param messageAreaFormatter Formatter for formatting the MessageArea
     **                            status label.
     ** @see #getMessageAreaFormatter()
     */
     public void setMessageAreaFormatter(Formatter messageAreaFormatter)
     {
         _messageAreaFormatter = messageAreaFormatter;
         _updateStatusBarControl(_messageArea,_messageAreaFormatter);
         _updateIndicatorsLater();
     } // setMessageAreaFormatter

     /**
     ** Returns the formatter for formatting the MessageArea status label. <P>
     **
     ** @return The formatter for formatting the MessageArea status label.
     ** @see #setMessageAreaFormatter(Formatter messageAreaFormatter)
     */
     public Formatter getMessageAreaFormatter()
     {
         return(_messageAreaFormatter);
     } // getMessageAreaFormatter

     /**
     ** Sets the formatter for formatting the PercentDone status label. <P>
     **
     ** @param percentDoneFormatter Formatter for formatting the PercentDone
     **                            status label.
     ** @see #getPercentDoneFormatter()
     */
     public void setPercentDoneFormatter(Formatter percentDoneFormatter)
     {
         _percentDoneFormatter = percentDoneFormatter;
         _updateStatusBarControl(_percentDone,_percentDoneFormatter);
         _updateIndicatorsLater();
     } // setPercentDoneFormatter

     /**
     ** Returns the formatter for formatting the PercentDone status label. <P>
     **
     ** @return The formatter for formatting the PercentDone status label.
     ** @see #setPercentDoneFormatter(Formatter percentDoneFormatter)
     */
     public Formatter getPercentDoneFormatter()
     {
         return(_percentDoneFormatter);
     } // getPercentDoneFormatter


     /**
     ** Sets the format string for formatting the CurrentRow status label. <P>
     **
     ** @param currentRowFormatString Format string for formatting the
     **                               CurrentRow status label.
     ** @see #getCurrentRowFormatString()
     */
     public void setCurrentRowFormatString(String currentRowFormatString)
     {
         _currentRowFormatString = currentRowFormatString;
         _updateStatusBarControl(_currentRow,_currentRowFormatString);
         _updateIndicatorsLater();
     } // setCurrentRowFormatString

     /**
     ** Returns the format string for formatting the CurrentRow status label.<P>
     **
     ** @return The format string for formatting the CurrentRow status label.
     ** @see #setCurrentRowFormatString(String currentRowFormatString)
     */
     public String getCurrentRowFormatString()
     {
         return(_currentRowFormatString);
     } // getCurrentRowFormatString

     /**
     ** Sets the format string for formatting the RowCount status label. <P>
     **
     ** @param rowCountFormatString Format string for formatting the RowCount
     **                             status label.
     ** @see #getRowCountFormatString()
     */
     public void setRowCountFormatString(String rowCountFormatString)
     {
         _rowCountFormatString = rowCountFormatString;
         _updateStatusBarControl(_rowCount,_rowCountFormatString);
         _updateIndicatorsLater();
     } // setRowCountFormatString

     /**
     ** Returns the format string for formatting the RowCount status label. <P>
     **
     ** @return The format string for formatting the RowCount status label.
     ** @see #setRowCountFormatString(String RowCountFormatString)
     */
     public String getRowCountFormatString()
     {
         return(_rowCountFormatString);
     } // getRowCountFormatString

     /**
     ** Sets the format string for formatting the ModifiedFlag status label. <P>
     **
     ** @param modifiedFlagFormatString Format string for formatting the
     **                                 ModifiedFlag status label.
     ** @see #getModifiedFlagFormatString()
     */
     public void setModifiedFlagFormatString(String modifiedFlagFormatString)
     {
         _modifiedFlagFormatString = modifiedFlagFormatString;
         _updateStatusBarControl(_modifiedFlag,_modifiedFlagFormatString);
         _updateIndicatorsLater();
     } // setModifiedFlagFormatString

     /**
     ** Returns the format string for formatting the ModifiedFlag status label.
     **
     ** @return The format string for formatting the ModifiedFlag status label.
     ** @see #setModifiedFlagFormatString(String ModifiedFlagFormatString)
     */
     public String getModifiedFlagFormatString()
     {
         return(_modifiedFlagFormatString);
     } // getModifiedFlagFormatString

     /**
     ** Sets the format string for formatting the MessageArea status label. <P>
     **
     ** @param messageAreaFormatString Format string for formatting the
     **                                MessageArea status label.
     ** @see #getMessageAreaFormatString()
     */
     public void setMessageAreaFormatString(String messageAreaFormatString)
     {
         _messageAreaFormatString = messageAreaFormatString;
         _updateStatusBarControl(_messageArea,_messageAreaFormatString);
         _updateIndicatorsLater();
     } // setMessageAreaFormatString

     /**
     ** Returns the format string for formatting the MessageArea status label.
     **
     ** @return The format string for formatting the MessageArea status label.
     ** @see #setMessageAreaFormatString(String messageAreaFormatString)
     */
     public String getMessageAreaFormatString()
     {
         return(_messageAreaFormatString);
     } // getMessageAreaFormatString

     /**
     ** Sets the format string for formatting the PercentDone status label. <P>
     **
     ** @param percentDoneFormatString Format string for formatting the
     **                                PercentDone status label.
     ** @see #getPercentDoneFormatString()
     */
     public void setPercentDoneFormatString(String percentDoneFormatString)
     {
         _percentDoneFormatString = percentDoneFormatString;
         _updateStatusBarControl(_percentDone,_percentDoneFormatString);
         _updateIndicatorsLater();
     } // setPercentDoneFormatString

     /**
     ** Returns the format string for formatting the PercentDone status label.
     **
     ** @return The format string for formatting the PercentDone status label.
     ** @see #setPercentDoneFormatString(String percentDoneFormatString)
     */
     public String getPercentDoneFormatString()
     {
         return(_percentDoneFormatString);
     } // getPercentDoneFormatString

     /**
     ** Reports whether the modified flag is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** message area of the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the modified flag is displayed.
     ** @see #setHasModifiedFlag(boolean showIt)
     */
     public boolean getHasModifiedFlag()
     {
         return(_hasModifiedFlag);
     } // hasMessageArea

     /**
     ** Determines whether the modified flag is visible. <P>
     **
     ** Allows the caller to show or hide the message area in the StatusBar.
     **
     ** @param showIt If <TT>TRUE</TT>, then the modified flag will be shown.
     ** @see #getHasModifiedFlag()
     */
     public void setHasModifiedFlag(boolean showIt)
     {
         if (_hasModifiedFlag != showIt)
         {
             _hasModifiedFlag = showIt;
             _updateIndicatorsLater();
         }
     } // showMessageArea

     /**
     ** Reports whether the Message Area is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** message area of the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the message area is displayed.
     ** @see #setHasMessageArea(boolean showIt)
     */
     public boolean getHasMessageArea()
     {
         return(_hasMessageArea);
     } // hasMessageArea

     /**
     ** Determines whether the message are is visible. <P>
     **
     ** Allows the caller to show or hide the message area in the StatusBar.
     **
     ** @param showIt If <TT>TRUE</TT>, then the message area will be shown.
     ** @see #getHasMessageArea()
     */
     public void setHasMessageArea(boolean showIt)
     {
         if (_hasMessageArea != showIt)
         {
             _hasMessageArea = showIt;
             _updateIndicatorsLater();
         }
     } // showMessageArea

     /**
     ** Indicates whether the Current Row indicator is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** Current Row indicator on the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the current row indicator is shown.
     ** @see #setHasCurrentRow(boolean showIt)
     */
     public boolean getHasCurrentRow()
     {
         return(_hasCurrentRow);
     } // hasCurrentRow

     /**
     ** Determines whether the current row indicator is visible. <P>
     **
     ** Allows the caller to show or hide the current row indicator in the
     ** StatusBar.
     **
     ** @param showIt if <TT>TRUE</TT>, then the current row indicator is shown
     ** @see #getHasCurrentRow()
     */
     public void setHasCurrentRow(boolean showIt)
     {
         if (_hasCurrentRow != showIt)
         {
             _hasCurrentRow = showIt;
             _updateIndicatorsLater();
         }
     } // showCurrentRow
     /**
     ** Indicates whether the Row Count indicator is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** Row Count indicator on the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the row count indicator is shown.
     ** @see #setHasRowCount(boolean showIt)
     */
     public boolean getHasRowCount()
     {
         return(_hasRowCount);
     } // hasRowCount

     /**
     ** Determines whether the row count indicator is visible. <P>
     **
     ** Allows the caller to show or hide the row count indicator in the
     ** StatusBar.
     **
     ** @param showIt if <TT>TRUE</TT>, then the row count indicator is shown
     ** @see #getHasRowCount()
     */
     public void setHasRowCount(boolean showIt)
     {
         if (_hasRowCount != showIt)
         {
             _hasRowCount = showIt;
             _updateIndicatorsLater();
         }
     } // showRowCount

     /**
     ** Indicates whether the Percent Done indicator is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** Percent Done indicator on the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the percent done indicator is shown.
     ** @see #setHasPercentDone(boolean showIt)
     */
     public boolean getHasPercentDone()
     {
         return(_hasPercentDone);
     } // hasPercentDone

     /**
     ** Determines whether the percent done indicator is visible. <P>
     **
     ** Allows the caller to show or hide the percent done indicator in the
     ** StatusBar.
     **
     ** @param showIt if <TT>TRUE</TT>, then the percent done indicator is shown.
     ** @see #getHasPercentDone()
     */
     public void setHasPercentDone(boolean showIt)
     {
         if (_hasPercentDone != showIt)
         {
             _hasPercentDone = showIt;
             _updateIndicatorsLater();
         }
     } // showPercentDone

     /**
     ** Reports whether the Message Area is shown. <P>
     **
     ** A status reporting method that informs the caller whether or not the
     ** message area of the StatusBar is displayed.
     **
     ** @return <TT>TRUE</TT> if the message area is displayed.
     ** @see #setHasModeIcon(boolean showIt)
     */
     public boolean getHasModeIcon()
     {
         return(_hasModeIcon);
     } // hasModeIcon

     /**
     ** Determines whether the message are is visible. <P>
     **
     ** Allows the caller to show or hide the message area in the StatusBar.
     **
     ** @param showIt If <TT>TRUE</TT>, then the message area will be shown.
     ** @see #getHasModeIcon()
     */
     public void setHasModeIcon(boolean showIt)
     {
         if (_hasModeIcon != showIt)
         {
             _hasModeIcon = showIt;
             _updateIndicatorsLater();
         }
     } // showModeIcon

     
     public void transactionStateChanged(boolean state)
     {
        mDirty = state;
        _updateIndicatorsLater();
     }

     public void focusGained(DCIteratorBinding iterBinding, DCControlBinding binding, int attrIndex)
     {
        if (binding != null)
        {
           DCIteratorBinding ctrlIterBinding = binding.getDCIteratorBinding();
           if (ctrlIterBinding != null) 
           {
              if (attrIndex > -1) 
              {
                 displayStatus(iterBinding, UIMessageBundle.STR_SB_EDITING_ATTR, 
                                     new Object[]
                                     { 
                                        ctrlIterBinding.getDisplayName(),
                                        ((JUCtrlValueBinding)binding).getAttributeDef(attrIndex).getName()
                                     });
              }
              else
              {
                 displayStatus(iterBinding, UIMessageBundle.STR_SB_EDITING, 
                                     new Object[]{ctrlIterBinding.getDisplayName()});
              }
           }
           else
           {
              mMsgStr = null;
           }
        }

        //now set this iterator as current.
        if (iterBinding == null)
        {
           return;
        }
        NavigatableRowIterator iter = iterBinding.getNavigatableRowIterator();
        if (mCurrentRSI != iter) 
        {
           setModel(iterBinding);
           _updateIndicatorValuesLater();
        }
        else
        {
           if (_messageArea != null) 
           {
              _messageArea._updateValueLater(mMsgStr);
           }
        }
     }


     /*
     * Returns the message text that is currently displayed in
     * this status bar's message area.
     */
     public String getStatusMessageText()
     {
        return mMsgStr;
     }

     /*
     * Display the given message from the default message bundle.
     * 
     * @param iterBinding Current iterator binding.
     * @param msgId Message identifier in the default message bundle.
     * @param params Variables that are passed in the bundle to format a message.
     */
     public void displayStatus(DCIteratorBinding iterBinding, String msgId, Object[] params)
     {
        if (iterBinding != null 
            && iterBinding.isIteratorMadeVisible() 
            && (iterBinding.hasRSI() || iterBinding.isFindMode())
            && iterBinding.getNavigatableRowIterator() != mCurrentRSI)
        {
           setModel(iterBinding);
        }

        if (_messageArea != null) 
        {
           mMsgStr = StringManager.getString(MSG_BUNDLE, msgId, BLANK, params);
           _updateIndicatorValuesLater();
        }
     }
     
     /*
     * Displays the given msg in this status bar's message area (if message area is shown).
     */
     public void displayStatus(String msg)
     {
        if (_messageArea != null) 
        {
           mMsgStr = msg;
           _updateIndicatorValuesLater();
        }
     }
     
     //
     // RowSet listener
     //
     public void navigated(NavigationEvent event)
     {
        _updateIndicatorValuesLater();
     }
  
     public void rangeRefreshed(RangeRefreshEvent event)
     {
        //why is this check?
        if (event.getRowCountInRange() <= 0)
        {
           _updateIndicatorValuesLater();
        }
     }
  
     public void rangeScrolled(ScrollEvent event)
     {
     }
  
     public void rowDeleted(DeleteEvent event)
     {
        _updateIndicatorValuesLater();
     }
  
     public void rowInserted(InsertEvent event)
     {
        _updateIndicatorValuesLater();
     }
  
     public void rowUpdated(UpdateEvent event)
     {
        _updateIndicatorValuesLater();
     }
     
     private StatusBarLabelControl _createStatusLabel(String formatString,
                                                      Formatter formatter,
                                                      Border border)
     {
         StatusBarLabelControl label =
             new StatusBarLabelControl(formatString, formatter);

         label.setBorder(border);
         if (_font != null)
         {
             label.setFont(_font);
         }
         if (_foreGround != null)
         {
             label.setForeground(_foreGround);
         }
         if (_backGround != null)
         {
             label.setBackground(_backGround);
         }
         return(label);
     } // _createStatusLabel

     private JLabel _createModeIcon(Border border)
     {
         JLabel label = new JLabel();

         label.setBorder(border);
         if (_font != null)
         {
             label.setFont(_font);
         }
         if (_foreGround != null)
         {
             label.setForeground(_foreGround);
         }
         if (_backGround != null)
         {
             label.setBackground(_backGround);
         }
         return(label);
     } 

     private StatusBarProgressControl _createProgressBar(String formatString,
                                                         Formatter formatter,
                                                         Border border)
     {
         StatusBarProgressControl progressBar =
             new StatusBarProgressControl(formatString, formatter);

         progressBar.setBorder(border);
         if (_font != null)
         {
             progressBar.setFont(_font);
         }
         if (_foreGround != null)
         {
             progressBar.setForeground(_foreGround);
         }
         if (_backGround != null)
         {
             progressBar.setBackground(_backGround);
         }
         return(progressBar);
     } // _createProgressBar


     private Runnable mUpdateIndicatorsRunnable = null;
     private void _updateIndicatorsLater()
     {
        if (mUpdateIndicatorsRunnable == null)
        {
           mUpdateIndicatorsRunnable = new Runnable() 
           {
              public void run() 
              {
                 _updateIndicators();
                 mUpdateIndicatorsRunnable = null;
                _updateIndicatorValuesLater();
              }
           };
    
           SwingUtilities.invokeLater(mUpdateIndicatorsRunnable);
        }
     } // _updateIndicatorsLater

     protected synchronized void  _updateIndicators()
     {
         int index = 0;
         boolean changedSome = false;

         if (_hasPercentDone)
         {
             if (_percentDone == null)
             {
                 _percentDone =
                     _createProgressBar(_percentDoneFormatString,
                                        _percentDoneFormatter, _labelBorder);
             }
             if (!_percentDoneShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = 1;
                 gbc.gridheight = 1;
                 gbc.weightx = 0;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.CENTER;
                 gbc.fill = GridBagConstraints.HORIZONTAL;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady = 0;
                 add(_percentDone, gbc, index);
                 changedSome = true;
                 _percentDoneShown = true;
             }
             index++;
         }
         else
         {
             changedSome = true;
             if (_percentDone != null)
             {
                remove(_percentDone);
             }
             _percentDoneShown = false;
         }

         if (_hasCurrentRow)
         {
             if (_currentRow == null)
             {
                 _currentRow =
                     _createStatusLabel(_currentRowFormatString,
                                        _currentRowFormatter, _labelBorder);
             }
             if (!_currentRowShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = 1;
                 gbc.gridheight = 1;
                 gbc.weightx = 0;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.CENTER;
                 gbc.fill = GridBagConstraints.NONE;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady =0 ;
                 add(_currentRow, gbc, index);
                 changedSome = true;
                 _currentRowShown = true;
             }
             index++;
         }
         else
         {
             if (_currentRow != null)
             {
                 changedSome = true;
                 remove(_currentRow);
                 _currentRowShown = false;
             }
         }
         if (_hasRowCount)
         {
             if (_rowCount == null)
             {
                 _rowCount =
                     _createStatusLabel(_rowCountFormatString,
                                        _rowCountFormatter, _labelBorder);
             }
             if (!_rowCountShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = 1;
                 gbc.gridheight = 1;
                 gbc.weightx = 0;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.CENTER;
                 gbc.fill = GridBagConstraints.NONE;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady = 0;
                 add(_rowCount, gbc, index);
                 changedSome = true;
                 _rowCountShown = true;
             }
             index++;
         }
         else
         {
             if (_rowCount != null)
             {
                 changedSome = true;
                 remove(_rowCount);
                 _rowCountShown = false;
             }
         }

         if (_hasModifiedFlag)
         {
             if (_modifiedFlag == null)
             {
                 _modifiedFlag =
                     _createStatusLabel(_modifiedFlagFormatString,
                                        _modifiedFlagFormatter, _labelBorder);
             }
             if (!_modifiedFlagShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = 1;
                 gbc.gridheight = 1;
                 gbc.weightx = 0;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.CENTER;
                 gbc.fill = GridBagConstraints.NONE;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady = 0;
                 add(_modifiedFlag, gbc, index);
                 changedSome = true;
                 _modifiedFlagShown = true;
             }
             index++;
         }
         else
         {
             if (_modifiedFlag != null)
             {
                 changedSome = true;
                 remove(_modifiedFlag);
                 _modifiedFlagShown = false;
             }
         }

         if (_hasMessageArea)
         {
             if (_messageArea == null)
             {
                 _messageArea =
                     _createStatusLabel(_messageAreaFormatString,
                                        _messageAreaFormatter, _labelBorder);
             }
             if (!_messageAreaShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = GridBagConstraints.RELATIVE;
                 gbc.gridheight = 1;
                 gbc.weightx = 1;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.CENTER;
                 gbc.fill = GridBagConstraints.HORIZONTAL;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady = 0;
                 add(_messageArea, gbc, index);
                 changedSome = true;
                 _messageAreaShown = true;
             }
             index++;
         }
         else
         {
             if (_messageArea != null)
             {
                 changedSome = true;
                 remove(_messageArea);
                 _messageAreaShown = false;
             }
         }


         if (_hasModeIcon)
         {
             if (_modeIcon == null)
             {
                 _modeIcon = _createModeIcon(_labelBorder);
             }
             if (!_modeIconShown)
             {
                 GridBagConstraints gbc = new GridBagConstraints();
                 gbc.gridx = GridBagConstraints.RELATIVE;
                 gbc.gridy = GridBagConstraints.RELATIVE;
                 gbc.gridwidth = GridBagConstraints.RELATIVE;
                 gbc.gridheight = 1;
                 gbc.weightx = 0;
                 gbc.weighty = 1;
                 gbc.anchor = GridBagConstraints.EAST;
                 gbc.fill = GridBagConstraints.NONE;
                 gbc.insets = new Insets(0,0,0,0);
                 gbc.ipadx = 0;
                 gbc.ipady = 0;
                 add(_modeIcon, gbc, index);
                 changedSome = true;
                 _modeIconShown = true;
             }
             index++;
         }
         else
         {
             if (_modeIcon != null)
             {
                 changedSome = true;
                 remove(_modeIcon);
                 _modeIconShown = false;
             }
         }

         if (changedSome)
         {
             // !!! might need to determine the focused Rowset...
             _updateIndicatorValuesLater();
         }
     } // _updateIndicators

     private Runnable mUpdateIndicatorValuesRunnable = null;

     private void _updateIndicatorValuesLater()
     {
        if (mUpdateIndicatorValuesRunnable == null)
        {
           mUpdateIndicatorValuesRunnable = new Runnable() 
           {
              public void run() 
              {
                 _updateIndicatorValues();
                 mUpdateIndicatorValuesRunnable = null;
              }
           };

           SwingUtilities.invokeLater(mUpdateIndicatorValuesRunnable);
        }
     } // _updateIndicatorValuesLater

     protected void _updateIndicatorValues()
     {
         if (mNotInited && !JUIUtil.inDesignTime())
         {
            if (mIterBinding != null)
            {
               mNotInited = false; //so that same sb is not readded to the listener
               mIterBinding.getDataControl().addTransactionStateListener(this);
            }
            else if (mFormBinding != null)
            {
               try
               {
                  if (mFormBinding != null && mFormBinding.getDataControl() != null)
                  {
                     mNotInited = false; //so that same sb is not readded to the listener
                     mFormBinding.getDataControl().addTransactionStateListener(this);
                  }
               }
               catch (oracle.jbo.InvalidObjNameException ione)
               {
                  //ignore as I'm not connected to any datacontrol.
               }
            }
         }
         
         if (mCurrentRSI != null) 
         {
            int index = -1;
            if (_currentRow != null)
            {
               index = mCurrentRSI.getCurrentRowIndex() + 1; //convert to 1 based
               _currentRow._updateValueLater(Integer.toString(index));
            }
            if (_rowCount != null || _percentDone != null)
            {
               long ct = (mCurrentRSI instanceof RowSetIterator)
                          ? ((RowSetIterator)mCurrentRSI).getRowSet().getEstimatedRowCount()
                          : mCurrentRSI.getRowCount();
               if (_rowCount != null)
               {
                  _rowCount._updateValueLater(Long.toString(ct));
               }
               if (_percentDone != null)
               {
                  if (index < 0) 
                  {
                     index = mCurrentRSI.getCurrentRowIndex() + 1; //convert to 1 based 
                  }
                  _percentDone.setValue((int)((double)index / ct * 100));
               }
            }
    
            if (_modifiedFlag != null)
            {
                
                if (mCurrentRSI instanceof RowSetIterator)
                {
                   _modifiedFlag.setText((new StringBuffer(_modifiedFlagFormatString)
                                              .append((mDirty ? _dirtyStr : _cleanStr)))
                                         .toString());
                }
                else
                {
                   _modifiedFlag.setText(
                                (new StringBuffer(_modifiedFlagFormatString)
                                     .append(_cleanStr))
                                   .toString());
                }
            }

            if (_modeIcon != null) 
            {
               if (_imgData == null) 
               {
                  Class cl = JUStatusBar.class;
                  _imgData = new ImageIcon(cl.getResource("images/data.gif"));
                  _imgFind = new ImageIcon(cl.getResource("images/find.gif"));
               }

               _modeIcon.setIcon((mIterBinding == null || !mIterBinding.isFindMode()) ? _imgData : _imgFind);
            }
         }
         else if (_modifiedFlag != null)
         {
             _modifiedFlag.setText(
                          (new StringBuffer(_modifiedFlagFormatString)
                               .append(_cleanStr))
                             .toString());
         }
         if (_messageArea != null)
         {
             _messageArea._updateValue(mMsgStr);
         }
     } // _updateIndicatorValues

     private void _updateStatusBarControl(StatusBarControl statusBarControl, String nuFormatString) 
     {
       if(statusBarControl!=null){
           statusBarControl.setFormatString(nuFormatString);
       }
     }

     private void _updateStatusBarControl(StatusBarControl statusBarControl, Formatter nuFormatter) 
     {
       if(statusBarControl!=null){
           statusBarControl.setFormatter(nuFormatter);
       }
     }

     public void release()
     {
        if (mFormBinding != null) 
        {
           mFormBinding.removeStatusBarInterface(this);
        }
        if (mIterBinding != null)
        {
           mIterBinding.getDataControl().removeTransactionStateListener(this);
        }
        else if (mFormBinding != null)
        {
           try
           {
              if (mFormBinding != null && mFormBinding.getDataControl() != null)
              {
                 mFormBinding.getDataControl().removeTransactionStateListener(this);
              }
           }
           catch (oracle.jbo.InvalidObjNameException ione)
           {
              //ignore as I'm not connected to any datacontrol.
           }
        }
        mNotInited = true;
        this.mFormBinding = null;
        setModel(null);
     }

    public interface StatusBarControl 
    {
        public void setFormatString(String nuFormatString);
        public void setFormatter(Formatter nuFormatter);   
    }

     public class StatusBarLabelControl
         extends JLabel implements StatusBarControl
     {

         String _formatString;
         Formatter _formatter;

         /**
         ** Constructs a StatusBarLabelControl.
         **
         ** The label's contents, once set, will be displayed at the left
         ** of the label's display area.
         */
         public StatusBarLabelControl()
         {
             this(null, JLabel.LEFT, null, null);
         }

         /**
         **  Creates a LabelControl instance with the specified image. The
         **  label is centered vertically and horizontally in display area
         **
         ** @param image The image to be displayed by the label.
         */
         public StatusBarLabelControl(Icon image)
         {
             this(image, JLabel.CENTER, null, null);
         }

         /**
         **  Creates a LabelControl instance with the specified formatter. The
         **  label is centered vertically and horizontally in the display area.
         **
         ** @param formatter the formatter to use to display the label
         */
         public StatusBarLabelControl(String formatString, Formatter formatter)
         {
             this(null, JLabel.LEFT, formatString, formatter);
         }

         /**
         ** Creates a <code>LabelControl</code> instance with the specified
         ** image and horizontal alignment.
         **
         ** @param icon  The image to be displayed by the label.
         ** @param horizontalAlignment  One of the following constants
         **           defined in <code>SwingConstants</code>:
         **           <code>LEFT</code>,
         **           <code>CENTER</code>, or
         **           <code>RIGHT</code>.
         ** @param formatString The format string to use when displaying the
         **                     value.
         */
         public StatusBarLabelControl(Icon icon, int horizontalAlignment,
                                      String formatString, Formatter formatter)
         {
             super("", icon, horizontalAlignment);
             _formatString = formatString;
             _formatter = formatter;
             _updateValueLater(null);
         }

         /**
         ** Sets the format string to be used when displaying the value. <P>
         **
         ** The format string should be a format string as supported by the
         ** DefaultNumberFormatter.
         **
         ** @param nuFormatString The format string.
         ** @see #getFormatString()
         ** @see oracle.jbo.format.DefaultNumberFormatter
         */
         public void setFormatString(String nuFormatString)
         {
             _formatString = nuFormatString;
             _updateValueLater(null);
         } // setFormatString

         /**
         ** Returns the format string to be used when displaying the value. <P>
         **
         ** The format string should be a format string as supported by the
         ** DefaultNumberFormatter.
         **
         ** @return A reference to the format string.
         ** @see #setFormatString(String nuFormatString)
         ** @see oracle.jbo.format.DefaultNumberFormatter
         */
         public String getFormatString()
         {
             return(_formatString);
         } // getFormatString

         /**
         **  Sets the formatter for the LabelControl.
         **
         **  @param formatter The new formatter for the label control.
         */
         public void setFormatter(Formatter formatter)
         {
             _formatter = formatter;
             _updateValueLater(null);
         } // setFormatter

         /**
         **  Returns the formatter for the LabelControl.
         **
         **  @return The new formatter for the label control.
         */
         public Formatter getFormatter()
         {
             return(_formatter);
         } // getFormatter


         // Private Methods

         private String mUpdateValueRunnableStringVal;
         private Runnable mUpdateValueRunnable;

         private void _updateValueLater(String value)
         {
            mUpdateValueRunnableStringVal = value;
            if (mUpdateValueRunnable == null)
            {
               mUpdateValueRunnable = new Runnable()
               {
                  public void run()
                  {
                     _updateValue(mUpdateValueRunnableStringVal);
                     mUpdateValueRunnable = null;
                     mUpdateValueRunnableStringVal = null;
                 }
               };
               SwingUtilities.invokeLater(mUpdateValueRunnable);
            }
         }

         private void _updateValue(String value)
         {
             String txt = BLANK;

             if (_formatString != null)
             {
                 if (_formatter != null)
                 {
                     try
                     {
                         txt = _formatter.format(_formatString, value);
                     }
                     catch(Exception e)
                     {
                         // fall back to the case where there's no formatter
                         txt = _formatString.replace('#',' ') +
                             (value != null ? value.toString() : BLANK);
                     }
                 }
                 else
                 {
                     txt = _formatString.replace('#',' ') +
                         (value != null ? value.toString() : BLANK);
                 }
             }
             else
             {
                 if (value != null)
                 {
                     txt = value;
                 }
             }
             setText(txt);
         }

     } // StatusBarLabelControl

     /**
     **  A derivative of JProgressBar that listens to three DataItems.
     **  The first DataItem is the Maximim value, the second DataItem is the
     **  current value, and the third DataItem is the minimum value.  The third
     **  DataItem is optional and if missing, the minimum value is assumed to be
     **  1.
     */
     public class StatusBarProgressControl
         extends JProgressBar implements StatusBarControl
     {
         //private transient Object _lockObj = new Object();

         String _formatString;
         Formatter _formatter;

         /**
         ** Constructs a StatusBarProgressControl.
         */
         public StatusBarProgressControl()
         {
             this(JProgressBar.HORIZONTAL, 0, 100, null, null);
         }

         public StatusBarProgressControl(int orient)
         {
             this(orient, 0, 100, null, null);
         }

         public StatusBarProgressControl(int min, int max)
         {
             this(JProgressBar.HORIZONTAL, min, max, null, null);
         }

         /**
         **  Creates a LabelControl instance with the specified formatter. The
         **  label is centered vertically and horizontally in display area.
         **
         ** @param formatter The formatter to be used to display the label.
         */
         public StatusBarProgressControl(String formatString,
                                         Formatter formatter)
         {
             this(JProgressBar.HORIZONTAL, 0, 100, formatString, formatter);
         }

         public StatusBarProgressControl(int orient, int min, int max,
                                         String formatString,
                                         Formatter formatter)
         {
             super(orient, min, max);
             
             // JProgressBars don't get focus
             _formatString = formatString;
             _formatter = formatter;
             setBorderPainted(true);
             setStringPainted(true);

             _updateAllValuesLater();
         }

         /**
         ** StatusBarProgressControl override. <P>
         **
         ** @return the maximum Dimensions of the StatusBarProgressControl
         */
         public Dimension getMaximumSize()
         {
             return(_progressBarSize);
         } // getPreferredSize

         public void setMaximumSize(Dimension dim)
         {
             dim.height = _progressBarSize.height;
             super.setMaximumSize(dim);
         }

         /**
         ** StatusBarProgressControl override. <P>
         **
         ** @return The minimum Dimensions of the StatusBarProgressControl.
         */
         public Dimension getMinimumSize()
         {
             return(_progressBarSize);
         } // getPreferredSize

         public void setMinimumSize(Dimension dim)
         {
             dim.height = _progressBarSize.height;
             super.setMinimumSize(dim);
         } // setPreferredSize

         /**
         ** StatusBarProgressControl override. <P>
         **
         ** @return The preferred Dimensions of the StatusBarProgressControl.
         */
         public Dimension getPreferredSize()
         {
             return(_progressBarSize);
         } // getPreferredSize

         public void setPreferredSize(Dimension dim)
         {
             dim.height = _progressBarSize.height;
             super.setPreferredSize(dim);
         }

         public void setSize(Dimension dim)
         {
             dim.height = _progressBarSize.height;
             super.setSize(dim);
         }
     
         public void setSize(int width, int height)
         {
             height = _progressBarSize.height;
             super.setSize(width, height);
         }
     
         /**
         ** Sets the format string to be used when displaying the value. <P>
         **
         ** The format string should be a format string as supported by the
         ** DefaultNumberFormatter.
         **
         ** @param nuFormatString The format string.
         ** @see #getFormatString()
         ** @see oracle.jbo.format.DefaultNumberFormatter
         */
         public void setFormatString(String nuFormatString)
         {
             _formatString = nuFormatString;
             _updateAllValuesLater();
         } // setFormatString

         /**
         ** Returns the format string to be used when displaying the value. <P>
         **
         ** The format string should be a format string as supported by the
         ** DefaultNumberFormatter.
         **
         ** @return A reference to the format string.
         ** @see #setFormatString(String nuFormatString)
         ** @see oracle.jbo.format.DefaultNumberFormatter
         */
         public String getFormatString()
         {
             return(_formatString);
         } // getFormatString

         /**
         **  Sets the formatter for the ProgressControl
         **
         **  @param formatter the new formatter for the progress control.
         */
         public void setFormatter(Formatter formatter)
         {
             _formatter = formatter;
             _updateAllValues();
         }// setFormatter

         /**
         **  Returns the formatter for the ProgressControl.
         **
         **  @return The new formatter for the progress control.
         */
         public Formatter getFormatter()
         {
             return(_formatter);
         } // getFormatter


         // Private Methods
         private Runnable mUpdateAllValuesRunnable;

         private void _updateAllValuesLater()
         {
            if (mUpdateAllValuesRunnable == null)
            {
               mUpdateAllValuesRunnable = new Runnable()
               {
                   public void run()
                   {
                      _updateAllValues();
                      mUpdateAllValuesRunnable = null;
                   }
               };
               SwingUtilities.invokeLater(mUpdateAllValuesRunnable);
            }
         }

         private void _updateAllValues()
         {
             double percent;
             String txt;
             Object value = null;

             percent = getPercentComplete();
             if (_formatString != null)
             {
                 if (_formatter != null)
                 {
                     try
                     {
                         txt = _formatter.format(_formatString,
                                                 new Double(percent*100.0));
                     }
                     catch(Exception e)
                     {
                         // fall back to the case where there's no formatter
                         txt = (percent*100.0) + "%";
                     }
                 }
                 else
                 {
                     txt = (percent*100.0) + "%";
                 }
                 if (txt != null && !txt.equals(""))
                 {
                     setString(txt);
                 }
             }
         }

     } // StatusBarProgressControl
 }  // JUStatusBar
