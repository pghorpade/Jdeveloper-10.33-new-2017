/*
 * @(#)JUTags.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import oracle.jbo.mom.Tags;

public class JUTags extends Tags
{
   static public final String RangeSize            = "RangeSize";
   static public final String DataControl          = "DataControl";
   static public final String DefClass             = "DefClass";
   static public final String RowSet               = "RowSet";
   static public final String Configuration        = "Configuration";
   static public final String Package              = "Package";
   static public final String EventClass           = "EventClass";
   static public final String FactoryClass         = "FactoryClass";
   static public final String DefinitionClass      = "Definition";
   static public final String BindingContainer     = "DCContainer";
   static public final String BindingContainerRef  = "BindingContainerReference";
   static public final String SubType              = "SubType";
   
   static public final String PNAME_invokeAction   = "invokeAction";
   static public final String PNAME_Accessor       = "Accessor";
   static public final String PNAME_AMName         = "AMName";
   static public final String PNAME_Binds          = "Binds";
   static public final String PNAME_VOName         = PNAME_Binds;
   static public final String PNAME_ViewDefName    = "ViewDefName";
   static public final String PNAME_RSIName        = "RSIName";
   static public final String PNAME_Sortable       = "Sortable";
   static public final String PNAME_IterTokenValidation = "StateValidation";
   static public final String PNAME_SortCriteriaCollection = "sortCriteria";
   static public final String PNAME_SortCriteria   = "sort";
   static public final String PNAME_SortOn         = "attribute";
   static public final String PNAME_Ascending	   = "ascending";
   static public final String OldSession           = "Session";
   static public final String BeanClass            = "BeanClass";
   static public final String Parameters           = "Parameters"; //old version
   static public final String parameters           = "parameters";
   static public final String Parameter            = "Parameter";
   static public final String parameter            = "parameter";
   static public final String ObjectType           = "ObjectType";
   static public final String FullName             = "FullName";
   static public final String DataControlConfigs   = "DataControlConfigs";
   static public final String Contents             = "Contents"; 
   static public final String ProjectConfigurer    = "ProjectConfigurer"; 
   static public final String SupportsTransactions = "SupportsTransactions";
   static public final String SupportsFindMode     = "SupportsFindMode";
   static public final String SupportsRangesize    = "SupportsRangesize";
   static public final String SupportsSortCollection = "SupportsSortCollection";
   static public final String SupportsResetState   = "SupportsResetState";
   static public final String SupportsUpdates   = "SupportsUpdates";
   
   static public final String DesignTimeClass      = "DTClass";
   static public final String Refresh              = "Refresh";
   static public final String RefreshCondition     = "RefreshCondition";
   static public final String ControllerClassName  = "ControllerClass";
   static public final String ActionProcessorClassName  = "ActionProcessorClass";
   static public final String executables          = "executables";
   static public final String variables            = "variables";
   static public final String variable             = "variable";
   static public final String CheckParams          = "CheckParams";


   static public final String PNAME_table                = "table";
   static public final String PNAME_tree                 = "tree";
   static public final String PNAME_attributeValue       = "attributeValue";
   static public final String PNAME_attributeValues      = "attributeValues";
   static public final String PNAME_action               = "action";
   static public final String PNAME_methodAction         = "methodAction";
   static public final String PNAME_iterator             = "iterator";
   static public final String PNAME_methodIterator       = "methodIterator";
   static public final String PNAME_accessorIterator     = "accessorIterator";
   static public final String PNAME_variableIterator     = "variableIterator";
   static public final String PNAME_button               = "button";
   static public final String PNAME_dynamicList          = "dynamicList";
   static public final String PNAME_list                 = "list";
   static public final String PNAME_listOfValues         = "listOfValues";
   static public final String PNAME_staticList           = "staticList";
   static public final String PNAME_defaultControl       = "defaultControl";
   static public final String PNAME_bindingContainer     = "bindingContainer";
   static public final String PNAME_pageDefinition       = "pageDefinition";
   static public final String PNAME_treeNodeDefinition   = "nodeDefinition";
   
   static public final String PNAME_CacheResults         = "CacheResults";
   // data control subtypes
   static public final String EJBDataControl          = "DCEJB";
   static public final String BC4JDataControl         = "DCBC4J";
   static public final String JavaBeanDataControl     = "DCJavaBean";
   static public final String ToplinkDataControl      = "DCTopLink";
   static public final String WebServiceDataControl   = "DCWebService";
   static public final String CredentialStoreDataControl = "CredentialStoreDataControl";
   static public final String AdapterDataControl = "AdapterDataControl";
    
    public static final String PNAME_buttonGroup          = "buttonGroup";	        //NOTRANS
    public static final String PNAME_formattedTextField   = "formattedTextField";	//NOTRANS
    public static final String PNAME_listSingleSel        = "listSingleSel";		//NOTRANS
    public static final String PNAME_lovButton            = "lovButton";		//NOTRANS
    public static final String PNAME_progressBar          = "progressBar";		//NOTRANS
    public static final String PNAME_progressBarAttr      = "progressBarAttr";		//NOTRANS
    public static final String PNAME_scrollBar            = "scrollBar";		//NOTRANS
    public static final String PNAME_scrollBarAttr        = "scrollBarAttr";		//NOTRANS
    public static final String PNAME_slider               = "slider";   		//NOTRANS
    public static final String PNAME_sliderAttr           = "sliderAttr";		//NOTRANS
    public static final String PNAME_spinner              = "spinner";		        //NOTRANS
    public static final String PNAME_label                = "label";		        //NOTRANS
    public static final String PNAME_graph                = "graph";		        //NOTRANS
    public static final String PNAME_combobox                = "combobox";		        //NOTRANS
    
   static public final String DATA_CONTROL_USAGES = "dataControlUsages";
   static public final String PAGE_DEFINITION_USAGES = "pageDefinitionUsages";
   public static final String PAGE_MAP       = "pageMap"; //NOTRANS 
   public static final String PAGE_MAP_ENTRY = "page";   //NOTRANS 
   public static final String PAGE_MAP_KEY   = "path";    //NOTRANS 
   public static final String PAGE_MAP_VALUE = "usageId";   //NOTRANS 
   public static final String pageDefinitionUsage = "page"; //NOTRANS 
   public static final String DC_USAGE   = "dc"; //NOTRANS 
   public static final String USAGE_PATH = "path"; //NOTRANS 
   static public final String APPLICATION_USAGES = "ApplicationUsages";
   static public final String APPLICATION_USAGE = "ApplicationUsage";
   
   public static final String SYNC_MODE   = "syncMode"; //NOTRANS
   public static final String VAL_MODE_STR  = "ValidateAtBindings"; //NOTRANS
   public static final String PNAME_variableUsage = "variableUsage"; //NOTRANS
   
   public static final String PName_RemoveMethod      = "RemoveMethod"; //NONLS
   public static final String PName_AddMethod         = "AddMethod"; //NONLS
}


