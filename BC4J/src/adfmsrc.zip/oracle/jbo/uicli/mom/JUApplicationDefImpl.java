/*
 * @(#)JUApplicationDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.lang.reflect.Constructor;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;

import oracle.adf.model.bc4j.DCJboDataControl;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCDataControlReference;
import oracle.adf.model.binding.DCBindingContainerReference;

import oracle.jbo.CustomClassNotFoundException;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.mom.ContainerDefImpl;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.Tags;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.ElementDefElement;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.uicli.binding.JUUtil;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class JUApplicationDefImpl extends ContainerDefImpl
{
   private String  mRootAMDefName = null;
   private boolean mAsProject = true;
   private String  mApplicationClassName = null;
   private String  mActualAppDefName = null;
   private ArrayList mDataControlDefs = new ArrayList(5);
   private HashMap   mDataControlDefsMap = new HashMap(5);
   private ArrayList mDataControlReferences = new ArrayList(5);
   private ArrayList mContainerReferences = new ArrayList(5);
   private HashMap   mPageMap = new HashMap(5);
   private ArrayList mApplicationUsages = new ArrayList(5);
   
   public static final String PNAME_TYPE_GENERIC = "Generic";
   public static final String PNAME_TYPE_JCLIENT = "JClient";
   public static final String PNAME_TYPE_PROJ = "JboProject";
   public static final String PNAME_TYPE_APPLICATION = PNAME_TYPE_PROJ;//"JUApplication";
   
   public static final String PNAME_BindingClass = "BindingClass";
   public static final String PNAME_RootAMDefName = "RootAMDefName";
   public static final String PNAME_ApplicationType = "ClientType";
   public static final String PNAME_CliApplication = "CliApplication";
   public static final String PNAME_SeparateXMLFiles = "SeparateXMLFiles";

   
   //This needs to be generic by default
   private String mClientType = PNAME_TYPE_GENERIC;  
   private String mIanaEncoding = null;
   private String mJdkEncoding = null;
   private String mPackageName = null;

   public JUApplicationDefImpl(String name)
   {
      super(JUMetaObjectManager.getJUMom());
      setName(name);

      mApplicationClassName = oracle.jbo.uicli.binding.JUApplication.class.getName();
   }
   

   public JUApplicationDefImpl()
   {
      super(JUMetaObjectManager.getJUMom());

      mApplicationClassName = oracle.jbo.uicli.binding.JUApplication.class.getName();
   }
   

   static public JUApplicationDefImpl findDefObjectNoSub(String name)
   {
      return (JUApplicationDefImpl) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_APPLICATION,
                                           JUApplicationDefImpl.class,
                                           false /*sub*/);
   }


   static public JUApplicationDefImpl findDefObject(String name)
   {
      return (JUApplicationDefImpl) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_APPLICATION,
                                           JUApplicationDefImpl.class,
                                           true /*sub*/);
   }


   protected com.sun.java.util.collections.ArrayList getContainerDefNames(boolean recursive)
   {
      return new com.sun.java.util.collections.ArrayList(1);
   }

   public Map getPageMap()
   {
      return (Map)mPageMap.clone();
   }

   public String getMapValueByPath(String path)
   {
      return (String)mPageMap.get(path);   
   }

   public String findBindingContainerIdByPath(String path, BindingContext ctx)
   {
      String id = (String)mPageMap.get(path); 

      for(int i = 0; id != null && i < mApplicationUsages.size(); i++)
      {
         JUApplicationReference ref = (JUApplicationReference)mApplicationUsages.get(i);
         id = ref.getDef(ctx).findBindingContainerIdByPath(path, ctx);
      }
      return id;
      
   }
   
   public String getRootAMDefName()
   {
      return mRootAMDefName;
   }
   
   
   public void setRootAMDefName(String rootAMDefName)
   {
      mRootAMDefName = rootAMDefName;
   }
   
   
   public String getApplicationClassName()
   {
      return mApplicationClassName;
   }
   
   
   public void setApplicationClassName(String applicationClassName)
   {
      mApplicationClassName = applicationClassName;
   }
   
   public String getPackageName()
   {
      return mPackageName;   
   }
   
   public void setPackageName(String sPackage)
   {
      mPackageName = sPackage;   
   }
   
   /**
    * Name this object.
    * @param name  the name to be given to this object.
    **/

   public void setName(String name)
   {
      // sim 4/19/01 -- setName is declared here to be public
      super.setName(name);
   }

   
   public boolean getAsProject()
   {
      return mAsProject;
   }

   
   public void setAsProject(boolean asProject)
   {
      mAsProject = asProject;
   }
   
   
   public ArrayList getSessionDefNames()
   {
      int count = mDataControlDefs.size();
      ArrayList retAl = new ArrayList(count);
      for (int i = 0; i < count; i++)
      {
         retAl.add(((DCDataControlDef)mDataControlDefs.get(i)).getName());
      }
      return retAl;
   }

   
   public void loadPackages()
   {
      com.sun.java.util.collections.ArrayList al = new com.sun.java.util.collections.ArrayList(5);
      
      getChildObjectNames(false /*recursive*/, JTXMLTags.PACKAGE, al);

      for (int j = 0; j < al.size(); j++)
      {
         String packageName = (String) al.get(j);

         JUMetaObjectManager.getJUMom().findPackage(packageName);
      }
   }

   private void loadSessions(DefElement xmlElement)
   {
      DebugDiagnostic.println("Loading JUSessions for DataControl '" + getFullName() + "'.");

      // load sessions for backward compatibility
      com.sun.java.util.collections.ArrayList children = xmlElement.getChildrenList(JUTags.OldSession);
      if ( (children != null) && (children.size() > 0) )
      {
         DCDefBase eInfo = null;
         String myFullName = getFullName();
         for ( int i=0; i < children.size(); i++ )
         {
            DefElement elem = (DefElement)children.get(i);
            eInfo = DCDataControlDef.createAndLoadFromXML(elem, myFullName);

            mDataControlDefs.add(eInfo);
            mDataControlDefsMap.put(eInfo.getName(), eInfo);

            DebugDiagnostic.println("Successfully loaded JUSession '" + eInfo.getFullName() + "'.");
         }
      }

      com.sun.java.util.collections.ArrayList list =
         xmlElement.getChildrenList();

      int length = list.size();
      if ( length > 0 )
      {
         DCDefBase eInfo = null;
         String myFullName = getFullName();
         for ( int i=0; i < length; i++ )
         {
            DefElement elem = (DefElement)list.get(i);
            if (elem.getNodeName().equals(JUTags.CONTAINEE) ||
                elem.getNodeName().equals(JUTags.PAGE_MAP) ||
                elem.getNodeName().equals(JUTags.DATA_CONTROL_USAGES) ||
                elem.getNodeName().equals(JUTags.PAGE_DEFINITION_USAGES))
            {
               continue;
            }

            eInfo = DCDataControlDef.createAndLoadFromXML(elem, myFullName);

            mDataControlDefs.add(eInfo);
            mDataControlDefsMap.put(eInfo.getName(), eInfo);

            DebugDiagnostic.println("Successfully loaded DataControlDefImpl '" +
                                    eInfo.getFullName() + "'.");
         }
      }
   }


   public java.util.ArrayList get_bindingContainerReferenceNames()
   {
      java.util.ArrayList list = new java.util.ArrayList();
      
      com.sun.java.util.collections.ArrayList nameList= new com.sun.java.util.collections.ArrayList(5);
      
      getChildObjectNames(false, JUTags.BindingContainerRef, nameList);
      
      for(int i = 0; i < nameList.size(); i++)
      {
        list.add(nameList.get(i));
      }
      return list;
   }

   public java.util.ArrayList getBindingContainerReferences()
   {
     return mContainerReferences;
   }
   
   protected ContainerDefImpl createContainerType(String typeName)
   {
      return null;
   }

   
   public DCDataControl createRootApplication(Hashtable context, String name, Object userData,
                                              String dbConnectionURL, Properties dbConnectionProps)
   {
      if (mActualAppDefName != null)
      {
         if(!mActualAppDefName.endsWith(".cpx"))
             mActualAppDefName += ".cpx";
         JUApplicationDefImpl appDefImpl = findDefObject(mActualAppDefName);

         setRootAMDefName(appDefImpl.getRootAMDefName());
         setApplicationClassName(appDefImpl.getApplicationClassName());

         mActualAppDefName = null;
      }

      Class cls = JUUtil.findClass(mApplicationClassName);
      DCDataControl app;

      try
      {
         Constructor cons = cls.getConstructor(new Class[] { Hashtable.class, String.class, Object.class });
      
         app = (DCDataControl) cons.newInstance(new Object[] { context, mRootAMDefName, userData });
      }
      catch(Exception e)
      {
         throw new CustomClassNotFoundException(mApplicationClassName, e);
      }
      
      if (app instanceof DCJboDataControl) 
      {
         ((DCJboDataControl)app).setConnectionInfo(dbConnectionURL, dbConnectionProps);
      }

      //app.setAppDef(this);

      if (name == null)
      {
         name = getName();
      }
      
      app.setName(name);
      app.initialize();

      return app;
   }

   
   protected void loadFromXMLFile(DefElement xmlElement) 
   {
      super.loadFromXMLFile(xmlElement);
      
      String strVal;
      
      mAsProject = (xmlElement.getNodeName().equals(PNAME_TYPE_PROJ));
      mRootAMDefName = xmlElement.readString(PNAME_RootAMDefName);
      strVal  = xmlElement.readString(PNAME_ApplicationType);
      mPackageName = xmlElement.readString(JUTags.Package);
      
      if (strVal != null)
      {
         mClientType = strVal;
      }
      strVal = xmlElement.readString(PNAME_BindingClass);
      if (strVal != null)
      {
         mApplicationClassName = strVal;
      }
      else
      {
         mApplicationClassName = (PNAME_TYPE_JCLIENT.equals(mClientType)) 
                                            ? mApplicationClassName
                                            : oracle.adf.model.bc4j.DCJboDataControl.class.getName();
      }

      mActualAppDefName = xmlElement.readString(PNAME_CliApplication);
   }

   public String getClientType()
   {
      return mClientType;
   }

   public ArrayList getSessionDefs()
   {
      return (ArrayList)mDataControlDefs.clone();
   }

   public DCDataControlDef findSession(String name)
   {
      return (DCDataControlDef)mDataControlDefsMap.get(name);
   }

   
   public void removeSession(String name)
   {
      Object obj = mDataControlDefsMap.get(name);
      if (obj != null) 
      {
         mDataControlDefs.remove(obj);
         mDataControlDefsMap.remove(name);
      }
   }

   
  /*FIXME public void addSession(String name)
   {
      JUDataControlDefImpl def = new JUDataControlDefImpl(name);
      
      //how about package/configuration.
      def.setFullName(new StringBuffer(getFullName()).append(".").append(name).toString());

      if (mDataControlDefsMap.get(name) != null) 
      {
         throw new oracle.jbo.NameClashException(JUTags.Session, name);
      }
      mDataControlDefs.add(def);
      mDataControlDefsMap.put(name, def);
   }
*/
  

   boolean mDirty = false;
   boolean mIsNew = false;

   
   /**
    * This method returns if an Object is modified from last save/load
    * @return Returns true if the Object is dirty. Returns false otherwise.
    **/
   public boolean isDirty()
   {
      return mDirty;
   }

   
   /**
    * This method marks the Object dirty
    * @param isDirty If true the Object is marked Dirty.
    **/
   public void setDirty(boolean isDirty)
   {
      mDirty = true;
   }

   
   /**
    * This method returns if this object is previously persisted.
    * @return true if the Object is previously persisted. Returns false otherwise.
    **/
   public boolean isNew()
   {
      return mIsNew;
   }

   
   /**
    * This method marks the as previously persisted. By default all objects
    * are new objects. When the object is persisted first time, that object is
    * marked as 'not new' object
    * @param isNew If true the Object is marked as new object.
    **/
   public void setNew(boolean isNew)
   {
      mIsNew = isNew;
   }


   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      if (getAsProject())
      {
         return PNAME_TYPE_PROJ; //JUTags.Project;
      }
      else
      {
         return PNAME_TYPE_APPLICATION;
      }
   }

   public String getIanaEncoding()
   {
       return mIanaEncoding;
   }

   public void setIanaEncoding(String iana)
   {
      mIanaEncoding = iana;
   }

   public String getJdkEncoding()
   {
       return mJdkEncoding;
   }

   public void setJdkEncoding(String jdkEnc)
   {
      mJdkEncoding = jdkEnc;
   }

   protected void loadContainee(DefElement xmlElement)
   {
      String sType = xmlElement.readString(Tags.OBJECT_TYPE);
      if(sType.equals(JUTags.BindingContainerRef))
      {
         mContainerReferences.add(
            JUMetaObjectManager.loadBindingContainerRef(xmlElement));
      }
   }
   
   protected void loadPageDefinitionUsage(DefElement xmlElement)
   {
      mContainerReferences.add(
            JUMetaObjectManager.loadBindingContainerRef(xmlElement));
   }

   static public JUApplicationDefImpl createAndLoadFromXML(DefElement xmlElement)
   {
      JUApplicationDefImpl defObj = new JUApplicationDefImpl();

      if (defObj != null)
      {
         defObj.loadFromXMLFile(xmlElement);
      }

      return defObj;
   }

   protected void loadPageMap(DefElement xmlElement)
   {
      DebugDiagnostic.println("Loading pageMap for DataControl '" + getFullName() + "'.");

      // load sessions for backward compatibility
      DefElement pageMap = xmlElement.findChildElement(JUTags.PAGE_MAP);
      if ( (pageMap != null))
      {
         DCDefBase eInfo = null;
         String myFullName = getFullName();
         com.sun.java.util.collections.ArrayList children = pageMap.getChildrenList(JUTags.PAGE_MAP_ENTRY);
         mPageMap = new HashMap(children.size());
         
         for ( int i=0; i < children.size(); i++ )
         {
            DefElement elem = (DefElement)children.get(i);

            String sViewPath = elem.getAttribute(JUTags.PAGE_MAP_KEY);
            String pageDefinitionId = elem.getAttribute(JUTags.PAGE_MAP_VALUE);
            
            mPageMap.put(sViewPath, pageDefinitionId);
         }
      }
   }
   
   protected void loadContainees(DefElement xmlElement, boolean sepXMLFiles)
   {
      boolean juiProject = xmlElement.readBoolean("JUIProject");

      DefElement container = xmlElement.findChildElement(JUTags.Contents);

      if(container == null)
         container = xmlElement;
         
      if (!juiProject)
      {
         loadSessions(container);
      }
      loadContainees(container);
      
      loadPageMap(container);
      
      loadDataControls(container);
      
      loadPageDefinitionUsages(container);

      loadApplicationUsages(container);
   }
   
   protected void loadDataControls(DefElement xmlElement)
   {
      DefElement datacontrols = xmlElement.findChildElement(JUTags.DATA_CONTROL_USAGES);
      
      if(datacontrols == null)
         return;

      com.sun.java.util.collections.ArrayList list =
         datacontrols.getChildrenList();

      int length = list.size();
      if (length > 0)
      {
         DCDefBase eInfo = null;
         String myFullName = getFullName();
         
         if (mDataControlDefs.size() == 0 && length != 0) 
         {
            mDataControlDefs = new ArrayList(length);
            mDataControlDefsMap = new HashMap(length);
         }

         for ( int i=0; i < length; i++ )
         {
            DefElement elem = (DefElement)list.get(i);
            if(!elem.getLocalName().equalsIgnoreCase(JUTags.DC_USAGE))
            {
               eInfo = DCDataControlDef.createAndLoadFromXML(elem, myFullName);

               mDataControlDefs.add(eInfo);
               mDataControlDefsMap.put(eInfo.getName(), eInfo);

               DebugDiagnostic.println("Successfully loaded DataControlDefImpl '" + eInfo.getFullName() + "'.");
            }
            else
            {
               loadDataControlUsage(elem);
            }
         }
      }
   }

   protected void loadPageDefinitionUsages(DefElement xmlElement)
   {
      DefElement pagedefinitions = xmlElement.findChildElement(JUTags.PAGE_DEFINITION_USAGES);
      if(pagedefinitions == null)
         return;

      com.sun.java.util.collections.ArrayList list =
         pagedefinitions.getChildrenList();

      int length = list.size();
      for (int i = 0; i < length; i++)
      {
         DefElement elem = (DefElement)list.get(i);

         loadPageDefinitionUsage(elem);
      }
   }

   public ArrayList getDataControlReferences()
   {
      return (ArrayList)mDataControlReferences.clone();
   }

   private void loadDataControlUsage(DefElement elem)
   {
      String dcDefName = elem.getAttribute(JUTags.USAGE_PATH);
      String dcUsageName = elem.getAttribute(JUTags.ID);

      DCDataControlDef dcDef = DCDataControlDef.findDefObject(dcDefName);

      DCDataControlReference dcRef = new DCDataControlReference(dcDef, dcUsageName);
      mDataControlReferences.add(dcRef);
   }

   private void loadDataControlUsages(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList dcUsagelist = xmlElement.getChildrenList(JUTags.DC_USAGE);
      if ( (dcUsagelist != null) && (dcUsagelist.size() > 0) )
      {
         for ( int i=0; i < dcUsagelist.size(); i++ )
         {
            DefElement elem = (DefElement)dcUsagelist.get(i);
            loadDataControlUsage(elem);
         }
      }
   }

   ArrayList getAllDataControlReferences()
   {
      ArrayList dcRefs = new ArrayList();
      dcRefs.addAll(getDataControlReferences());
      for(int i = 0; i < mDataControlDefs.size(); i++)
      {
         dcRefs.add(new DCDataControlReference((DCDataControlDef)mDataControlDefs.get(i)));
      }
      return dcRefs;
   }

   private void loadApplicationUsages(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList appsUsageList = xmlElement.getChildrenList(JUTags.APPLICATION_USAGE);
      if ( (appsUsageList != null) && (appsUsageList.size() > 0) )
      {
         for ( int i=0; i < appsUsageList.size(); i++ )
         {
            DefElement elem = (DefElement)appsUsageList.get(i);
            JUApplicationReference appRef = new JUApplicationReference(elem.getAttribute(JUTags.USAGE_PATH));
            mApplicationUsages.add(appRef);
         }
      }
   }

   void populateContext(BindingContext ctx, Map userParams)
   {
      ArrayList refs = getAllDataControlReferences();
      DCDataControlReference dcRef;
      for (int i=0; i < refs.size(); i++)
      {
         dcRef = (DCDataControlReference)refs.get(i);

         if (ctx.get(dcRef.getName()) != null)
         {
            throw new oracle.jbo.NameClashException(
               "DCDataControl", dcRef.getName()); //NONLS
         }

         dcRef.setUserParams(userParams);
         ctx.put(dcRef.getName(), dcRef);
      }

      refs = getBindingContainerReferences();
      DCBindingContainerReference ref;
      for (int i = 0; i < refs.size(); i++) 
      {
         try
         {
            ref = (DCBindingContainerReference)(
               (DCBindingContainerReference)refs.get(i)).clone(); 
         }
         catch(CloneNotSupportedException e)
         {
            // JRS Should not happen
            throw new RuntimeException(e);
         }

         ref.setBindingContext(ctx);
         ctx.put(ref.getName(), ref);
      }
   }

}

// Anonymous reference to an included application
class JUApplicationReference
{
   private String mFullDefName;
   private JUApplicationDefImpl mDef;

   JUApplicationReference(String fullDefName)
   {
      mFullDefName = fullDefName;
   }

   private void resolve(BindingContext ctx)
   {
      if(mDef == null)
      {
         mDef = JUApplicationDefImpl.findDefObject(mFullDefName);
         mDef.populateContext(ctx, null);
      }
   }

   public JUApplicationDefImpl getDef(BindingContext ctx)
   {
      resolve(ctx);
      return mDef;
   }
}
