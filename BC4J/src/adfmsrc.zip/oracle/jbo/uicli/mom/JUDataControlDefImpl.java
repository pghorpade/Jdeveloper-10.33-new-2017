/*
 * @(#)JUDataControlDefImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DefinitionFactory;

import oracle.jbo.mom.xml.DefElement;

public class JUDataControlDefImpl extends DCDataControlDef 
{
   // JRS 05/19/2004  Maintaining this class for backwards compatiblity.
   // I suppose we could move BC4J specific functionality to this class
   // as needed.  For now I have moved everything to the base class so
   // that it may be used by non-BC4J data controls.
   JUDataControlDefImpl(String name)
   {
      super(name);
   }

   JUDataControlDefImpl()
   {
   }

  
}

