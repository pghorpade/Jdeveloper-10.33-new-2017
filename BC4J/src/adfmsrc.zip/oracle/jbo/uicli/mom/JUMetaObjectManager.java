/*
 * @(#)JUMetaObjectManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.mom;

import java.io.InputStream;
import java.io.Reader;

import java.util.ArrayList;
import java.util.Map;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlDefinitionFactory;
import oracle.adf.model.DataControlFactory;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCBindingContainerDef;
import oracle.adf.model.binding.DCBindingContainerReference;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.model.binding.DCDataControlConfigDef;
import oracle.adf.model.binding.DCDataControlReference;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCDefFactory;
import oracle.adf.model.binding.DCErrorHandler;
import oracle.adf.model.binding.DCErrorHandlerThrow;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.binding.DefinitionFactory;
import oracle.adf.model.generic.StructureDefImpl;

import oracle.jbo.ApplicationModule;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.InvalidDefNameException;
import oracle.jbo.JboException;
import oracle.jbo.NoDefException;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.EnvInfoProvider;
import oracle.jbo.mom.ContainerDefImpl;
import oracle.jbo.mom.DefinitionManager;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.DefXMLParser;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.uicli.binding.JUApplication;
import oracle.jbo.uicli.binding.JUErrorHandler;
import oracle.jbo.uicli.binding.JUFormBinding;
import oracle.jbo.uicli.binding.JUFormDef;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

public class JUMetaObjectManager extends DefinitionManager implements JUMetaObjectBase
{
   private static boolean _loaded = false;
   public static JUMetaObjectManager mom = null;
   private static Object mBaseErrorHandler = null;
   private static DefinitionFactory mCtrlDefFactory = null;
   BindingContext mJUApplications = null;

   protected JUMetaObjectManager()
   {
      super();
      mom = this;

      JUObjectTypeHelper.register();

      initManager();
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public void setJClientDefFactory(DefinitionFactory factory)
   {
      boolean hasFactory = (mCtrlDefFactory != null);
      Class clz = null;
      try
      {
         //if a Jclient factory has been set, do not reset it.
         //setControlDefFactory should be used to set the right factory.
         clz = JBOClass.forName("oracle.jbo.uicli.jui.JUDefFactoryImpl");
      }
      catch (ClassNotFoundException cnfe)
      {
         hasFactory = false;
      }
      if (hasFactory)
      {
         hasFactory = clz.isAssignableFrom(mCtrlDefFactory.getClass());
      }
      if (!hasFactory)
      {
         if (factory == null)
         {
            factory = (DefinitionFactory)DCUtil.createNewInstance("oracle.jbo.uicli.jui.JUDefFactoryImpl");    //NOTRANS
         }

         if (clz != null && clz.isAssignableFrom(factory.getClass()))
         {
            JUMetaObjectManager.setControlDefFactory(factory);
         }
         registerDefinitionFactory("http://xmlns.oracle.com/adfm/jcuimodel", factory); //NOTRANS
         registerDefinitionFactory("http://xmlns.oracle.com/adfm/uimodel", factory); //NOTRANS
      }
   }

   public static void setControlDefFactory(DefinitionFactory factory)
   {
      if(Diagnostic.isOn())
      {
         Diagnostic.println(factory.getClass().getName()+" will be used to create ControlBindings.");
      }
      mCtrlDefFactory = factory;
   }

   public DefinitionFactory getControlDefFactory()
   {
     if (mCtrlDefFactory == null)
     {
        mCtrlDefFactory = new oracle.jbo.uicli.binding.JUBindingDefFactoryImpl();
     }
     return mCtrlDefFactory;
   }

   /**
    * @deprecated since 9.0.5.1, Use setErrorHandler instead.
    */
   public static void setBaseErrorHandler(JUErrorHandler baseErrorHandler)
   {
      mBaseErrorHandler = baseErrorHandler;
   }

   public static void setErrorHandler(DCErrorHandler baseErrorHandler)
   {
      mBaseErrorHandler = baseErrorHandler;
   }

   public static void reportException(DCBindingContainer formBnd, Exception ex)
   {
      if (mBaseErrorHandler == null)
      {
         new DCErrorHandlerThrow().reportException(formBnd, ex);
      }
      else
      {
         ((DCErrorHandler)mBaseErrorHandler).reportException(formBnd, ex);
      }
   }

   public static void reportException(JUFormBinding formBnd, Exception ex)
   {
     reportException(formBnd, ex, false);
   }

   public static void reportException(JUFormBinding formBnd, Exception ex, boolean reportExceptionNow)
   {
      if (mBaseErrorHandler instanceof JUErrorHandler )
      {
         ((JUErrorHandler)mBaseErrorHandler).reportException(formBnd, ex, reportExceptionNow);
      }
      else
      {
         reportException((DCBindingContainer)formBnd, ex);
      }
   }

   /**
    * @deprecated since 10.1.3.
    * Use {@link #setApplicationDefinition(String)} instead, if possible.
    */
   public static JUApplicationDefImpl setApplicationDefinition(InputStream is,
                                                               String appDefName)
   {
      synchronized(getJUMom().getMapLock())
      {
         JUApplicationDefImpl def = null;
         try
         {
            findApplicationDefImpl(appDefName) ;
         }
         catch (NoDefException nde)
         {
            //ignore.
         }
         if (def == null)
         {
            def = (JUApplicationDefImpl)getJUMom().
                     loadProjectDefinition(is, appDefName);
         }
         return def;
      }
   }

   /**
    * @deprecated since 10.1.3.
    * Use {@link #setApplicationDefinition(String)} instead, if possible.
    */
   public static JUApplicationDefImpl setApplicationDefinition(Reader reader,
                                                               String appDefName)
   {
      synchronized(getJUMom().getMapLock())
      {
         JUApplicationDefImpl def = null;
         try
         {
            findApplicationDefImpl(appDefName) ;
         }
         catch (NoDefException nde)
         {
            //ignore.
         }
         if (def == null)
         {
            def = (JUApplicationDefImpl)getJUMom().
                     loadProjectDefinition(reader, appDefName);
         }
         return def;
      }
   }
   public static JUApplicationDefImpl setApplicationDefinition(String appDefName)
   {
      synchronized(getJUMom().getMapLock())
      {
         JUApplicationDefImpl def = null;
         try
         {
            findApplicationDefImpl(appDefName) ;
         }
         catch (NoDefException nde)
         {
            //ignore.
         }
         if (def == null)
         {
            def = (JUApplicationDefImpl)getJUMom().
                     loadProjectDefinition(appDefName);
         }
         return def;
      }
   }

   public JUApplicationDefImpl createApplicationDefinition(String name)
   {
      JUApplicationDefImpl def = new JUApplicationDefImpl(name);

      insertDefinition(name, def, false);

      return def;
   }


   static public JUMetaObjectManager getJUMom()
   {
      if (mom == null)
      {
         synchronized(JUMetaObjectManager.class)
         {
            if (mom == null)
            {
               mom = new JUMetaObjectManager();
            }
         }
      }

      return mom;
   }

   /**
    * Gets the XML parser.
    * @return the XMLParser.
    * @deprecated since 10.1.3.  See {@link DefinitionManager#getJboXMLDoc}.
    */
   public static DefXMLParser getParser()
   {
      return getJUMom().getJboXMLDoc();
   }



   static JUApplicationDefImpl findApplicationDefImpl(String name)
   {
      return (JUApplicationDefImpl)getJUMom().findDefinitionObject(name, TYP_DEF_APPLICATION, JUApplicationDefImpl.class, true);
   }



   static boolean defExists(String name)
   {
      try
      {
         return (getJUMom().findDefinitionObject(name, TYP_DEF_ANY, oracle.jbo.mom.DefinitionObject.class, true, false) != null);
      }
      catch (oracle.jbo.NoDefException nde)
      {
      }
      return false;
   }



   public String[] getXMLVersionArray()
   {
      return new String[] {"jbo_03_01.dtd"};
   }

   protected String getDynamicPackageName()
   {
      return PropertyConstants.JU_DYNAMIC_PKG_NAME;
   }

   //.jpx or .addf
   protected String getProjectFileExtension()
   {
      return getClientProjectExtension();
   }

   public static String getClientProjectExtension()
   {
      return ".cpx";
   }

   //for project/dynamic-package def
   protected ContainerDefImpl createContainerDefObject(boolean topLevel)
   {
      return new JUApplicationDefImpl();
   }

   protected Object loadSpecialObjects(DefElement elem, String metaObjectName, String objType)
   {
      // We treat these two object separately since they are different from the
      // rest of the objects, for example : ValidationBeanLoader != DefObject
      if (objType.equalsIgnoreCase(JTXMLTags.PACKAGE))
      {
         JUPackageDefImpl pInfo = new JUPackageDefImpl();

         pInfo.loadFromXMLFile(elem);
         pInfo.setIsProject(false);
         insertDefinition(metaObjectName, pInfo);
         return pInfo;
      }

      return null;
   }

   protected Object loadLazyFromSharedObject(String metaObjectName,
                                                       ContainerDefImpl parent,
                                                       boolean loadParent,
                                                       boolean sub)
   {
      //do nothing as this is an JServer type load method.
      return null;
   }

   public static JUApplication findApplicationObject(String qualifiedAMName)
   {
      JUApplication obj = null;
      Map map = getJUMom().mJUApplications;
      if (map != null)
      {
         obj = (JUApplication)map.get(qualifiedAMName);
         if (obj == null)
         {
            qualifiedAMName =  qualifiedAMName.replace('.', '_');
            obj = (JUApplication)map.get(qualifiedAMName);
         }
      }
      return obj;
   }

   //for old dacs to set their am that they get from SessionInfo and call this
   //method instead of the generated boot-strap code in the main frame.
   public static void setApplicationObject(String qualifiedName, ApplicationModule am)
   {
      Map juapps = getJUMom().getBindingContext();
      if (juapps.get(qualifiedName) != null)
      {
         Diagnostic.println("WOOPS! I already have one with this name.");
         return;
      }

      JUApplication app = new JUApplication(am);

      if (mBaseErrorHandler != null)
      {
         app.setErrorHandler(mBaseErrorHandler);
      }

      juapps.put(qualifiedName, app);
   }

   /**
    * @deprecated since 10.1.2, use DCDataControl.release() instead
    * to release a datacontrol from the bindings as well as from
    * the business service.
    */
   public static void releaseApplicationObject(DCDataControl app)
   {
      /*
      Configuration.releaseRootApplicationModule(app.getApplicationModule(), true);
      if(app.getBindingContext() != null)
      {
         app.getBindingContext().remove(app.getName());
      }
      */
      app.release();
   }

   public static JUApplication createApplicationObject(String qualifiedAMName)
   {
      return createApplicationObject(qualifiedAMName, null);
   }

   public static JUApplication createApplicationObject(String qualifiedAMName, java.util.Properties env)
   {
      return createApplicationObject(qualifiedAMName, new java.util.Properties(), null);
   }

   /**
    * Returns the configuration name for a qualifiedAMName of the form
    * &lt;appDefName&gt;.&lt;sessDefName&gt;.
    *
    * @return null if the appDef or the sessDef are not found
    */
   public static String getConfigName(String qualifiedAMName)
   {
      // note that if the application definition has already been loaded
      // then it will not be loaded again.
      DCDataControlDef sessDef = null;
      try
      {
         sessDef = getSessionDef(qualifiedAMName);
      }
      catch (JboException e)
      {
      }

      return sessDef.getConfiguration();
   }

   private static DCDataControlDef getSessionDef(String qualifiedAMName)
   {
      //bootstrap application
      int dotIndex = qualifiedAMName.indexOf('.');
      String appDefName = null;
      String sessDefName = null;

      // bug 2474883.  if the cpx file name is not included in the
      // qualifiedAMName then do not parse the qualifiedAMName.  the
      // loadProject call will fail below with a proper application definition
      // not found exception
      if (dotIndex >= 0)
      {
         appDefName = qualifiedAMName.substring(0, dotIndex);
         sessDefName = qualifiedAMName.substring(dotIndex+1);
      }

      JUApplicationDefImpl appDef =
         (JUApplicationDefImpl)getJUMom().loadProjectDefinition(appDefName);

      if (appDef == null)
      {
           throw new JboException(CSMessageBundle.class,
                                  CSMessageBundle.EXC_NULL_APPDEF,
                                  new Object[]{appDefName});
      }

      DCDataControlDef sessDef    = appDef.findSession(sessDefName);
      if (sessDef == null)
      {
         throw new JboException(CSMessageBundle.class,
                                CSMessageBundle.EXC_NULL_SESSDEF,
                                new Object[]{sessDefName});
      }

      return sessDef;
   }

   public DCBindingContainerReference loadBindingContainerRef(BindingContext ctx, Node node)
   {
      NamedNodeMap map = node.getAttributes();
      String name;
      if(map.getNamedItem(JUTags.NAME) != null)
        name = map.getNamedItem(JUTags.NAME).getNodeValue();
      else
        name = map.getNamedItem(JUTags.ID).getNodeValue();
      String fName = map.getNamedItem(JUTags.FullName).getNodeValue();
      DCBindingContainerReference namedObj = new DCBindingContainerReference(ctx, name, fName);
      return namedObj;
   }

   public static DCBindingContainerReference loadBindingContainerRef(DefElement xmlElement)
   {
      String name = xmlElement.getAttribute(JUTags.NAME);
      if (name == null || name.length() == 0)
      {
         name = xmlElement.getAttribute(JUTags.ID);
         if (name != null && name.length() == 0)
         {
            name = null;
         }
      }

      String fName = xmlElement.getAttribute(JUTags.FullName);
      if (fName == null || fName.length() == 0)
      {
         fName = xmlElement.getAttribute(JUTags.USAGE_PATH);
         if (fName != null && fName.length() == 0)
         {
            fName = null;
         }
      }

      return new DCBindingContainerReference(name, fName);
   }


   public static void loadCpx(String sResource, Map userParams)
   {
      String projExt = getClientProjectExtension();
      //this conversion leads to improper name generation for findDefObject.
      //sjv-041227
      //if(sResource.endsWith(projExt))
      //{
      //   sResource = sResource.substring(0, sResource.lastIndexOf('.'));
      //}

      //sResource = sResource.replace('.','/') + projExt;

      // JRS 5/21/2004 Shouldn't JUApplicationDefImpl.findDefObject  or
      // JUMetaObjectManager.loadFromXML use loadProjectDefintion
      // for TYP_DEF_APPLICATION(s)?  This would obviate the need for this
      // special String parsing above.  Oh well, use what is here for now.
      if (!defExists(sResource))
      {
         if (sResource.endsWith(projExt))
         {
            sResource = sResource.substring(0, sResource.lastIndexOf(projExt));
         }
         getJUMom().loadProjectDefinition(sResource);
      }

      JUApplicationDefImpl appDef = JUApplicationDefImpl.findDefObject(sResource);

      //since session is now passed in in appParams, we could
      //set this binding context with session specific context.
      BindingContext ctx = (BindingContext)userParams.get(
         DataControlFactory.APP_PARAMS_BINDING_CONTEXT);

      if (ctx == null)
      {
         if(userParams instanceof BindingContext)
         {
            ctx = (BindingContext)userParams;
         }
      }

      if (ctx == null)
      {
         ctx = getJUMom().getBindingContext();
      }

      initContextFromDef(ctx, appDef, userParams);

   }

   private static void initContextFromDef(
      BindingContext ctx, JUApplicationDefImpl appDef, Map userParams)
   {
      ctx.put(BindingContext.APPLICATION_DEF, appDef);
      if (JUApplicationDefImpl.PNAME_TYPE_JCLIENT.equals(
         appDef.getClientType()))
      {
         ctx.setClientAppType(BindingContext.CLIENT_TYPE_JCLIENT);
      }

      appDef.populateContext(ctx, userParams);

   }

   public static JUApplication createApplicationObject(
      String qualifiedAMName
      , java.util.Properties env
      , EnvInfoProvider envInfo)
   {
      return (JUApplication)createDataControl(qualifiedAMName, env, envInfo);
   }

   static DCDataControl createDataControl(
      String qualifiedAMName
      , java.util.Properties env
      , EnvInfoProvider envInfo)
   {
      //bootstrap application
      try
      {

         //Get the pool with the given name and create a session cookie
         //from that name (the cookie gets a unique id from it's context
         //which should be retrievable form the rootAm at runtime by a client)
//         ApplicationPool pool = createPool(qualifiedAMName, env);

         //dac has only one obj in pool for now.

         DCDataControlDef sessDef = getSessionDef(qualifiedAMName);

         DCDataControl app;
         String factoryName = sessDef.getFactoryClass();

         int i = 0;
         String baseName = null;
         Map juapps = getJUMom().getBindingContext();

         if(factoryName == null)
         {
            // Use find pool.  Find pool is properly synchronized and will prevent
            // multiple pools from being created with the same pool name.
            Configuration configuration = new Configuration();
            configuration.loadFromClassPath(
               Configuration.buildConfigurationFileNameFromClassPath(
                  sessDef.getPackageName()));

             app = new JUApplication(
               configuration.createRootApplicationModuleFromConfig(
                  sessDef.getConfiguration(), envInfo));


             baseName = qualifiedAMName;
         }
         else
         {
            //new apps
            Class factoryClass = JBOClass.forName(factoryName);
            DataControlFactory factory = (DataControlFactory)factoryClass.newInstance();
            if (env == null)
            {
               env = new java.util.Properties();
               env.put(DataControlFactory.APP_PARAMS_BINDING_CONTEXT, getJUMom().getBindingContext());
            }

            java.util.Map map = sessDef.getDCProperties();

            if (map == null)
            {
               //map = sessDef.getParameters();
               map = sessDef;
            }

            if (map.get(JUTags.NAME) == null)
            {
               map.put(JUTags.NAME, sessDef.getName());
            }

            app = (DCDataControl)factory.createSession(getJUMom().getBindingContext(), sessDef.getName(), env, map);
            baseName = qualifiedAMName.replace('.', '_');
         }

         if (mBaseErrorHandler != null)
         {
            app.setErrorHandler(mBaseErrorHandler);
         }

         while (juapps.get(baseName) != null)
         {
            baseName = qualifiedAMName + (i++);
         }
         juapps.put(baseName, app);
         app.setName(baseName);
         return app;

      }
      catch(JboException jboEx)
      {
         jboEx.printStackTrace();
         throw jboEx;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new JboException(e);
      }
   }

   public BindingContext getBindingContext()
   {
      if (mJUApplications == null)
      {
         mJUApplications = new BindingContext();
         //mJUApplications = BindingContext.getInstance();
      }
      return mJUApplications;
   }

   public void addApplication(DCDataControl app)
   {
     Map juapps = getJUMom().getBindingContext();
     juapps.put(app.getName(), app);
     if (mBaseErrorHandler != null)
     {
        app.setErrorHandler(mBaseErrorHandler);
     }
   }

   /**
    * @deprecated  applications should use <tt>oracle.jbo.common.ampool.PoolMgr.findPool</tt>
    * directly or should rely upon <tt>createApplicationObject</tt> to create
    * a pool using the fully qualified ApplicationModule definition name.
    */
   public static ApplicationPool createPool(String qualifiedAMName)
   {
      return createPool(qualifiedAMName, new java.util.Properties());
   }

   /**
    * @deprecated  applications should use <tt>oracle.jbo.common.ampool.PoolMgr.findPool</tt>
    * directly or should rely upon <tt>createApplicationObject</tt> to create
    * a pool using the fully qualified ApplicationModule definition name.
    */
   public static ApplicationPool createPool(
      String qualifiedAMName, java.util.Properties env)
   {
      //bootstrap application
      DCDataControlDef sessDef = getSessionDef(qualifiedAMName);

      try
      {
         String configPackageName = sessDef.getPackageName();
         String configName = sessDef.getConfiguration();
         // Use find pool.  Find pool is properly synchronized and will prevent
         // multiple pools from being created with the same pool name.
         return oracle.jbo.common.ampool.PoolMgr.getInstance().findPool(
            configPackageName + "." + configName
            , configPackageName
            , configName
            , env);
      }
      catch(JboException jboEx)
      {
         jboEx.printStackTrace();
         throw jboEx;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new JboException(e);
      }
   }

   JUPackageDefImpl findPackage(String packageName)
   {
      // Try to find the object in the cache
      Object obj = findLoadedObject(packageName);

      if (obj == null)  // Check for lazyloading removed to bug :
      {
         if (mbValidateName && !JboNameUtil.isFullNameValid(packageName))
         {
            throw new InvalidDefNameException(TYP_PACKAGE, packageName);
         }

         // Package not found in cache, so call loadLazyObject
         obj = loadLazyDefinitionObject(packageName, null, false /*loadParent*/, true /*sub*/);
      }

      if (obj instanceof JUPackageDefImpl)
      {
         return (JUPackageDefImpl) obj;
      }

      return null;
   }

   // namespace factory support
   // namespace factory support
   protected com.sun.java.util.collections.HashMap getFactoryMap()
   {
      com.sun.java.util.collections.HashMap factoryMap =
          (com.sun.java.util.collections.HashMap)findLoadedObject("ADFNameSpaceMap");

      if (factoryMap == null)
      {
         factoryMap = new com.sun.java.util.collections.HashMap();
         // inititalize defaults
         factoryMap.put("http://xmlns.oracle.com/adfm/uimodel", new oracle.jbo.uicli.binding.JUBindingDefFactoryImpl());

         // had to remove this, it doesn't apply to all clients. This should be registered only for JClient clients
         //factoryMap.put("http://xmlns.oracle.com/adfm/jcuimodel", new oracle.jbo.uicli.jui.JUDefFactoryImpl());
         factoryMap.put("http://xmlns.oracle.com/adfm/datacontrol", new DataControlDefinitionFactory());

         insertDefinition("ADFNameSpaceMap", factoryMap, false);
      }

      return factoryMap;
   }

   /**
    * Registers a binding factory and associates it with the provided namespace.
    */
   public void registerDefinitionFactory(String sNameSpace, DefinitionFactory factory)
   {
      getFactoryMap().put(sNameSpace, factory);
   }

   /**
    * Returns the factory mapped to the provided namespace.
    */
   public DefinitionFactory getDefinitionFactory(String sNameSpace)
   {
        //getDefinitionFactory is getting called even before Client type is set.
        //So while invoking editors for JCLient projects
        //No factory class exists.
        //So ensure that if the nameSpace is jcuimodel
        //JClient factory is loaded
        //Remove it from here if find a better place to do it.
         if ("http://xmlns.oracle.com/adfm/jcuimodel".equals(sNameSpace))       //NOTRANS
                ensureJClientFactoryLoaded();

      return  (DefinitionFactory)getFactoryMap().get(sNameSpace);
   }

   private void ensureJClientFactoryLoaded()
   {
      if (!getFactoryMap().containsKey("http://xmlns.oracle.com/adfm/jcuimodel")) //NOTRANS
         setJClientDefFactory(null);
   }

   /**
    * Removed the factory associated with the provided namespace.
    */
   public void removeDefinitionFactory(String sNameSpace)
   {
      getFactoryMap().remove(sNameSpace);
   }

   /**
    * Loads the XML metadata stream and returns a Def Object
    *
    * @param metaObjectName  name of the metaobject, for diagnostic purposes.
    * @param elem            an XML Stream as a DefElement object.
    * @param objType         object type Tag.
    *
    * @return a defObject, which is a JBO Object extending DefinitionObject
    */

   public DefinitionObject loadFromXML(String metaObjectName, DefElement elem,
                                       String objType)
   {
      DefinitionObject childObject = null;

      try
      {
         //RF: If this is an explicitly namespaced object and
         // it's from one of our namespaces then use the local name...
         if( objType.indexOf(':') != -1 )
         {
            String uri = elem.getNamespaceURI();
            if( uri.startsWith( DCDefBase.DEF_XMLNS_BASE ) ||
                  uri.toLowerCase().startsWith( DCDefBase.DEF_XMLNS_BASE ) )
            {
               objType = elem.getLocalName();
               if( Diagnostic.isOn() )
                  Diagnostic.println( "RF: loadFromXML transformed: "+elem.getLocalName() +" "+ elem.getNamespaceURI() );
            }
            else if( Diagnostic.isOn() )
               Diagnostic.println( "RF: loadFromXML didn't transform: "+elem.getLocalName() +" "+ elem.getNamespaceURI() );
         }

         // Call the loadFromXML on the right object type
         if (objType.equalsIgnoreCase(JUApplicationDefImpl.PNAME_TYPE_APPLICATION)
            || objType.equalsIgnoreCase("Application"))
         {
            childObject = JUApplicationDefImpl.createAndLoadFromXML(elem);
         }
         else  if (objType.equalsIgnoreCase(JUFormDef.PNAME_TYPE)
                   || objType.equalsIgnoreCase(DCBindingContainerDef.PNAME_TYPE)
                   || objType.equalsIgnoreCase(JUTags.PNAME_bindingContainer)
                   || objType.equalsIgnoreCase(JUTags.PNAME_pageDefinition))
         {
            childObject = DCDefBase.createAndLoadFromXML(elem, DCDefBase.PNAME_Panel);
         }
         else if (objType.equalsIgnoreCase("JavaBean"))
         {
            childObject = StructureDefImpl.createAndLoadFromXML(elem);
         }
         else if(objType.equalsIgnoreCase(JUTags.DataControlConfigs))
         {
            childObject = DCDataControlConfigDef.createAndLoadFromXML(elem);
         }
      }
      catch(JboException jboEx) // JBOException
      {
         // If JBO Exception is already Thrown , Re Throw it again
         throw jboEx;
      }
      catch(Exception e) // Generic exception
      {
         if (Diagnostic.isOn())
         {
            String documentName = JboNameUtil.getDocumentName(metaObjectName);

            Diagnostic.println("Generic exception trying to load XML File " +
                               documentName);
         }
         JboException rtEx = new JboException(
                                    CSMessageBundle.class,
                                    CSMessageBundle.EXC_GENERIC_PERSISTENCE,
                                    null);
         rtEx.addToDetails(e);
         throw rtEx;
      }

      return childObject;
   }

   protected String getDefaultMOMCacheScope()
   {
      return System.getProperty(PropertyConstants.ADFM_MOM_CACHE_SCOPE);
   }

   protected boolean usesMDSByDefault()
   {
      //
      // Setting the default to false for ADFm.
      // This will have to be re-enabled after verifying
      // various generated scenarios work.
      //
      // ### [edelaube 2005/05/13] PropertyMetadata.ADFM_MOM_USES_MDS.getProperty()
      // is unreliable when initialized by some mechanisms
      // (e.g. oracle\jbo\server\jboserver.properties in a classpath directory):
      // this doesn't work for about 300 of the 800 guava tests (bug 4370575).
      // As it happens, this always works when the property value is specified
      // as a system property.  Nevertheless, I have chosen to change the code
      // to do a System.getProperty() until bug 4370575 is fixed: I consider it
      // preferable for initialization mechanisms other than system property
      // to fail consistently.
      //
      //return getBooleanFlag(PropertyMetadata.ADFM_MOM_USES_MDS, false);

      String flag = System.getProperty(PropertyConstants.ADFM_MOM_USES_MDS);
      boolean retVal = false;

      if (flag != null)
      {
         retVal = PropertyConstants.TRUE.equals(flag);
      }
      if (Diagnostic.isOn())
      {
         Diagnostic.println(PropertyConstants.ADFM_MOM_USES_MDS +
                            " Flag: " + retVal + ", str: " + flag);
      }
      return retVal;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public void invalidateBindingContainerDef(BindingContext ctx, String defName)
   {
      DCBindingContainerDef bcdef = DCBindingContainerDef.findDefObject(defName);
      java.util.Iterator iter = ctx.bindingContainersIterator();
      if (iter != null)
      {
         DCBindingContainer ctr;
         String ctrName;
         String fullName;
         while (iter.hasNext())
         {
            Object o = iter.next();
            // If not resolved yet. -dm 6/17/2005
            if(o instanceof DCBindingContainerReference)
            {
               continue;
            }
            ctr = (DCBindingContainer)o;
            if (ctr.usesDef(bcdef))
            {
               ctrName = ctr.getName();
               fullName = ctr.getDef().getFullName();
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("BindingContext:invalidating BindingContainer :"+ctrName);
               }
               ctr.release();
               ctx.put(ctrName,
                       new DCBindingContainerReference(ctx,
                                                       ctrName,
                                                       fullName));
            }
         }
      }
      if (Diagnostic.isOn())
      {
         Diagnostic.println("JUMetaObjectManager:removing BindingContainerDef :"+defName);
      }
      removeDefinition(defName);
   }
}
