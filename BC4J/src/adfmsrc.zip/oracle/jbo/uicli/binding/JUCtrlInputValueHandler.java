package oracle.jbo.uicli.binding;


public interface JUCtrlInputValueHandler
{
   /**
    * Implement value specific handling of the inputValue. For Example 
    * Intermedia domains know how to update their data based on a file url
    * or Struts FileHandle as input value. JUCtrlValueBinding provides the
    * base domain object (or null in which case it also provides access
    * to the AttributeDef that contains the domain/value type). Custom
    * implementation for the Intermedia domain may then update some fields
    * on the domain instead of the entire domain Object.
    * 
    * @param binding Control binding that is associated to the attribute to be updated.
    * @param index Index of the attribute in this control binding to update with 
    * the given Input Value. Note that for most single attribute control like
    * TextFields, this value should be 0.
    * @value Value to be set as InputValue for the given control binding.
    */
   void setInputValue(JUCtrlValueBinding binding, int index, Object value);

   /**
    * Returns true, if the caller needs to call setInputValue() on this
    * binding to update the current attribute value that this binding is set to.
    * <p>
    * If the value is different than the attribute value, or if this binding
    * had cached an error in a pervious setInputValue, then this method
    * returns true.
    */
   public boolean isNewInputValue(JUCtrlValueBinding binding, int index, Object value);

}
