/*
 * @(#)JUApplication.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import java.util.Hashtable;

import oracle.adf.model.bc4j.DCJboDataControl;
import oracle.adf.model.binding.DCErrorHandler;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.JboExceptionHandler;
import oracle.jbo.JboWarning;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.uicli.UIMessageBundle;


/**
 * The application class that manages connection to a 
 * BC4J Application Module. The JUApplication class provides:<p>
 * <ul>
 * <li>Methods to connect to a BC4J Application Module, if this application
 * is the root JUApplication object. JUApplications could be nested in other
 * JUApplication objects to mirror BC4J Nested Application Modules.
 * <li>Handles exceptions raised by the framework and passes it on
 * to registered Error handler. The error handler is same as registered
 * with the BC4J application module (if any). 
 * <li>Manages form bindings that contain iterator-bindings that 
 * bind iterators of the ViewObjects in the associated Application Module.
 * <li>If this JUApplication is the root, manages TransactionStateListeners
 * so that the BC4J Transaction's state events are passed on to the listeners.
 * <li>Routes all status bar messages to all status bars registered with 
 * this application. Framework uses this class to route all status bar messages.
 * </ul>
 * @version  PUBLIC
 * @see oracle.jbo.ApplicationModule
 * @see oracle.jbo.Transaction
 * @see JUTransactionStateListener
 * @see JUErrorHandler
 * 
 */
public class JUApplication extends DCJboDataControl 
{
   protected JUErrorHandler mJUErrorHandler;

   // only added for design time.
   public JUApplication()
   {
      super();
   }

   /**
   * Constructs a root JUApplication object that connects to a BC4J Application Module
   * of the given name.
   * @param context Context to pass on to the BC4J Application Module on creation.
   * @param rootAMDefName Name that identifies the root BC4J Application Module.
   * @param userData Data to store with the JUApplication object.
   */
   public JUApplication(Hashtable context, String rootAMDefName, Object userData)
   {
      super(context, rootAMDefName, userData);
   }
   
   
   /**
   * Constructor used internally by the framework to associate an application module
   * with a JClient application object.
   */
   public JUApplication(ApplicationModule am)
   {
      this(null, am, null);
   }
   
   
   /**
   * Constructor to be used to create a nested JUApplication inside another JUApplication object.
   */
   public JUApplication(JUApplication parent, ApplicationModule am, Object userData)
   {
      super(parent, am, userData);
   }

   public JUApplication(SessionCookie sessionCookie)
   {
      super(sessionCookie);
   }

   
   /**
   * Returns the root DCDataControl object.
   */
   public final JUApplication getRootApplication()
   {
      return (JUApplication)getRootDataControl();
   }

   /**
   * Remove the JUFormBinding object of the given name (if any).
   */
   public final void removeFormBinding(JUFormBinding formBnd)
   {
      super.removeBindingContainer(formBnd);
   }

   /**
   * Register the given form binding object with this application. If this
   * form binding object has no name or null name, framework generates a unique
   * name for the object (in the context of this application module).
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   */
   public final void addFormBinding(JUFormBinding formBnd)
   {
      addFormBinding(formBnd.getName(), formBnd);
   }
   
   
   /**
   * Register the given form binding object with this application with the given name.
   * @throws oracle.jbo.InvalidObjNameException If the given name does not follow the BC4J component or Java Identifier
   * naming rules.
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   * @see oracle.jbo.common.JboNameUtil#isNameValid(String)
   */
   public final void addFormBinding(String name, JUFormBinding formBnd, JUFormDef formDef)
   {
      super.addBindingContainer(name, formBnd, formDef);
   }

   /**
   * Register the given form binding object with this application with the given name.
   * @throws oracle.jbo.InvalidObjNameException If the given name does not follow the BC4J component or Java Identifier
   * naming rules.
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   * @see oracle.jbo.common.JboNameUtil#isNameValid(String)
   */
   public final void addFormBinding(String name, JUFormBinding formBnd)
   {
      super.addBindingContainer(name, formBnd);
   }
   

   /**
   * Return the JUFormBinding instance registered with this JUAppication with the given name.
   * If the name does not match, return null.
   */
   public final JUFormBinding findFormBinding(String name)
   {
      return (JUFormBinding)super.findBindingContainer(name);
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Create a JUFormBinding instance using the given name and form definition.
   */
   public final JUFormBinding createFormBinding(String name, String formDefName, boolean initialize)
   {
      return (JUFormBinding)super.createBindingContainer(name, formDefName, initialize);
   }
   


   /**
   * This method is used by all framework binding objects to report
   * exceptions. If this DCDataControl is not the root, it calls the
   * equivalent method on the root.
   * <p>
   * If the error handler is set to active state, then this method
   * calls the registered error handler's reportException method.
   * Othewise, it simply throws the given exception as a JboException.
   * @see DCErrorHandler
   * @see oracle.jbo.JboException
   */
   public final void reportException(JUFormBinding formBnd, Exception ex)
   {
      if (!mIsRoot)
      {
         getRootApplication().reportException(formBnd, ex);
      }
      else
      {
         if (getErrorHandlerActive())
         {
            if (mJUErrorHandler != null)
            {
               mJUErrorHandler.reportException(formBnd, ex);
            }
         }
         else
         {
            mErrorHandlerThrow.reportException(formBnd, ex);
         }
      }
   }
   

   /**
   * Returns the DCErrorHandler registered with the root DCDataControl.
   * By default a JClient application has an instance of DCErrorHandlerDialog
   * registered as the default DCErrorHandler. 
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   */
   public final JUErrorHandler getErrorHandler()
   {
      if (isRoot())
      {
         return mJUErrorHandler;
      }
      return ((JUApplication)getRootApplication()).getErrorHandler();
   }

   
   /**
   * Registers a DCErrorHandler with the root DCDataControl.
   * By default a JClient application has an instance of DCErrorHandlerDialog
   * registered as the default DCErrorHandler. 
   * Applications should use this method to register custom error handling
   * object so that all errors raised in the framework goes through the Application's
   * error handling object. Custom error handlers need to implement the DCErrorHandler
   * interface.
   * <p>
   * Custom error handlers may also implement oracle.jbo.JboExceptionHandler
   * to handle batched Exceptions raised during client-side processing
   * of Exceptions thrown in the Business Components tier. Alteratively
   * an application can register it's own JboExceptionHandler with the
   * Business Components ApplicationModule for this Application.
   * after the DCErrorHandler is set with DCDataControl in this method.
   * <p>
   * Note that errors are sent to the registered error handler only when
   * the error handler state is marked active (which is true by default)
   * using the setErrorHandlerActive method.
   * @param errHandlerObj An implementation of DCErrorHandler interface
   * that may optionally implement JboExceptionHandler interface too.
   * If errHandler implements the JboExceptionHandler, this method sets
   * it as the ExceptionHandler on the root ApplicationModule that this
   * client Application is connected with. Else, method sets a default 
   * ExceptionHandler which will collect all Exceptions
   * and throw a new JboException with these Exceptions set as in the new 
   * JboException's details list, for the errHandler to display
   * as one JboException with a bag of Exceptions.
   *
   * @see oracle.jbo.uicli.binding.JUErrorHandler
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   * @see oracle.jbo.JboExceptionHandler
   * @see oracle.jbo.ApplicationModule
   */
   public final void setErrorHandler(Object errHandlerObj)
   {
      if (errHandlerObj instanceof DCErrorHandler)
      {
         super.setErrorHandler(errHandlerObj);
      }
      else if (errHandlerObj instanceof JUErrorHandler)
      {
         JUErrorHandler errHandler = (JUErrorHandler)errHandlerObj;
         JUApplication root = (JUApplication)getRootApplication();
         root.mJUErrorHandler = errHandler;
         ApplicationModule am = getRootApplication().getApplicationModule();
         //if (am.getExceptionHandler() == null) 
         {
            if (errHandler instanceof JboExceptionHandler) 
            {
               am.setExceptionHandler((JboExceptionHandler)errHandler);
            }
            else
            {
               am.setExceptionHandler(new JboExceptionHandler()
               {
                  ArrayList al = null;
                  public void handleException(Exception ex, boolean lastEntryInPiggyback)
                  {
                     if (al == null) 
                     {
                        al = new ArrayList(5);
                     }

                     al.add(ex);
                  }

                  public void handleWarning(JboWarning warn)
                  {
                     if (oracle.jbo.common.Diagnostic.isOn()) 
                     {
                        oracle.jbo.common.Diagnostic.println(warn.getMessage());
                     }
                  }

                  public void finishedProcessingPiggyback(Exception[] exArray)
                  {
                     if (al != null && al.size() > 0)
                     {
                        JboException ex = new JboException(UIMessageBundle.class,
                                                           UIMessageBundle.EXC_SYNC_ERROR,
                                                           null,
                                                           (Exception[])al.toArray(new Exception[al.size()]));
                        al = null;
                        throw ex;  //so that DCI can catch and call reportException.
                     }
                  }
               }
               );
            }
         }
      }
   }

}       
