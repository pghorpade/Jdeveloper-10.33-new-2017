/*
 * @(#)JUCtrlValueBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.security.Permission;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.binding.PermissionHelper;
import oracle.adf.model.binding.PermissionBinding;
import oracle.adf.model.PermissionInfo;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttrSetValException;
import oracle.jbo.AttrValException;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.InvalidDefNameException;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.NavigationEvent;
import oracle.jbo.NoDefException;
import oracle.jbo.Row;
import oracle.jbo.ScrollEvent;
import oracle.jbo.StructureDef;
import oracle.jbo.ValidationException;
import oracle.jbo.Variable;
import oracle.jbo.VariableValueManager;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.domain.Struct;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.format.Formatter;
import oracle.jbo.rules.JboValidatorContext;
import oracle.jbo.rules.RulesBeanUtils;
import oracle.jbo.uicli.UIMessageBundle;

import oracle.adf.share.ADFContext;

/**
 * A JUControlBinding class responsible for maintaining which attribute(s)
 * of a row this binding can display/update. This class accepts a list of attribute names and
 * gets the AttributeDef objects for those attributes from the associated ViewObject.
 * This class also provides APIs to update values in a control given a new row or a set of rows.
 * JUIteratorBinding uses APIs in this class to notify the controls of:
 * <ul>
 * <li>Change in scrolling range if the control works with a range of rows
 * <li>Change in currency
 * <li>Row-inserted event
 * <li>Row-deleted event
 * </ul>
 * <p>
 * This class also has accessor methods that return attribute values for Attributes with which
 * this control binding is working. The indices of these attributes are ordered based on
 * the names provided to this control binding in the constructor.
 *
 * @javabean.class name=JUCtrlValueBinding
 */
abstract public class JUCtrlValueBinding extends JUControlBinding
         implements StructureDef, JUCtrlValueHandler
{
   private String[] mAttrNames;
   private AttributeDef[] mAttrs;

   final byte BIND_INIT = -1;
   final byte BIND_OBJ_ATTR = 1;
   final byte BIND_VO_ATTR  = 0;
   byte mObjAttrBinding = BIND_INIT;

   final byte TYPE_ROW_ITERATOR = 0;
   final byte TYPE_ARRAY_ITERATOR = 1;
   byte mIteratorBindingType = TYPE_ROW_ITERATOR;

   private JUCtrlInputValueHandler mInputHandler;
   private int mLookupInputHandler = IH_UNINIT;
   private static int IH_UNINIT = -1;
   private static int IH_READWRITE = 0;
   private static int IH_WRITEONLY = 1;
   private boolean mAttributeUpdated;

   //locale based string that needs to be reinitialized if locale changes (bindingcontainer is
   //reinitialized).
   private String mNullValueString;


   protected boolean mHasInputVal;
   protected Object  mInputVal; //stores the value being set via setAttribute.

   ArrayList mErrExc; //stores any exception that occured during setAttribute.

   private int[] mReadAuthorized = null;
   private int[] mUpdateAuthorized = null;

   protected JUCtrlValueBinding()
   {
      mInputHandler = this;
   }

   public JUCtrlValueBinding(Object control, DCIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding);

      mAttrNames = attrNames;
      mAttrs = null;

      if (iterBinding != null)
      {
         ((JUIteratorBinding)iterBinding).addValueBinding(this);
      }
      mInputHandler = this;
   }

   /**
   * Given a row, update the control with new attribute values from this row based on
   * the attributes with which this binding is associated.
   */
   public void updateValuesFromRow(Row row)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
   }

   protected void initResources()
   {
      //rebuild nullvalue string.
      if (getDef() != null)
      {
         setNullValueString(getCtrlValueDef().initializeNullValue(getBindingContainer()));
      }
   }


   /**
   * Given a set of rows, update the control with new attribute values from the rows based on
   * the attributes with which this binding is associated.
   * If clear is true, the control is expected to remove the current displayed value and associated
   * children values (like in a tree, remove all subnodes) and then set the new values.
   */
   abstract public void updateValuesFromRows(Row[] rows, boolean clear);

   /**
   * Update the control display based on whether the rows of data has scrolled.
   * @see oracle.jbo.ScrollEvent
   */
   abstract public void updateRangeScrolled(ScrollEvent event);

   /**
   * Update the current row display as the currency has navigated in the iterator
   * with which this control binding is working.
   */
   abstract public void updateNavigated(NavigationEvent event);


   /**
   * Notification that a new row was inserted in the associated iterator.
   * Control-bindings like JTable refresh their display to show the new row on this event.
   */
   public void updateRowInserted(InsertEvent event)
   {
   }


   /**
   * Notification that a row was deleted in the associated iterator.
   * Moves the currency on the associated row iterator to the next row (or previous row
   * if there is no next row) when the currency on the iterator was on the deleted row.
   */
   public void updateRowDeleted(DeleteEvent event)
   {
   }


   /**
    ** Return names of the attributes to which this binding is bound to
    ** and as defined in the binding definition.
    **/
   public String[] getAttributeNames()
   {
      return mAttrNames;
   }

   /**
    ** Return Attribute definitions of the attributes to which this binding
    ** is bound to.
    **/
   public AttributeDef[] getAttributeDefs()
   {
      if (mAttrs == null)
      {
         DCIteratorBinding iter = getDCIteratorBinding();
         if(iter == null)
         {
            if (hasVariables() && mAttrNames != null)
            {
               String str = (mAttrNames.length > 0) ? mAttrNames[0] : getName();
               Variable var = ensureVariableManager().lookupVariable(str);
               if (var != null)
               {
                  mAttrs = new AttributeDef[]{var};
               }
            }
            if (mAttrs == null)
            {
               mAttrs = new AttributeDef[0];
            }
            return mAttrs;
         }
         synchronized(iter.getSyncLock())
         {
            try
            {
               if (isAttributeBindingType())
               {
                  mAttrs = iter.getAttributeDefs(mAttrNames);
                  if (mAttrNames == null)
                  {
                     mAttrNames = new String[mAttrs.length];

                     for (int i = 0; i < mAttrNames.length; i++)
                     {
                        mAttrNames[i] = mAttrs[i].getName();
                     }
                  }
               }
            }
            catch(Exception ex)
            {
               reportException(ex);
            }
         }
      }

      return mAttrs;
   }


   /**
    * Returns attribute definition at the given index. Returns null if not found.
    */
   public AttributeDef getAttributeDef(int index)
   {
      return getAttributeDef(index, false);
   }

   AttributeDef getAttributeDef(int index, boolean thr)
   {
      AttributeDef[] ads = getAttributeDefs();
      if (ads != null && ads.length > index)
      {
         return ads[index];
      }
      if (thr)
      {
         String name = "<null>";
         if (mAttrNames != null && mAttrNames.length > index)
         {
            name = mAttrNames[index];
         }
         throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name, getName());
      }
      return null;
   }


   public AttributeDef lookupAttributeDef(String name)
   {
      try
      {
         return findAttributeDef(name, false);
      }
      catch (JboException ioe)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("JUCtrlValueBinding.lookupAttributeDef ignoring exception :"+ioe);
         }
      }
      return null;
   }

   public AttributeDef findAttributeDef(String name)
   {
     return findAttributeDef(name, true);
   }

   AttributeDef findAttributeDef(String name, boolean thr)
   {
      try
      {
         if (name == null)
         {
            if (thr)
            {
               throw new InvalidDefNameException(InvalidDefNameException.TYP_ATTRIBUTE,
                                              name);
            }
         }

         AttributeDef[] attrs = getAttributeDefs();

         if (attrs != null)
         {
            for (int j = 0; j < attrs.length; j++)
            {
               if (attrs[j] != null && attrs[j].getName().equals(name))
               {
                  return attrs[j];
               }
            }
         }

         if (thr)
         {
            throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name, getName());
         }
      }
      catch(Exception ex)
      {
         reportException(ex);
      }

      return null;
   }


   /**
    * Return formatted attribute value for the attribute at given index in the
    * row at the given row index within the current range in the iterator that
    * this binding is associated with.
    */
   public Object getAttributeFromRow(int rowIndexInRange, int attrIndex)
   {
      {
         try
         {
            Row row = getRowAtRangeIndex(rowIndexInRange);

            if (row == null)
            {
               return null;
            }

            if (mAttrs == null) //OTO
            {
               if (isObjectAttributeBindingType())
               {
                  resolveObjectAttributeDefs(row);
               }
            }
            return getAttributeFromRow(row, getAttributeDef(attrIndex), true);
         }
         catch(Exception ex)
         {
            reportException(ex);
         }

         return null;
      }
   }


   /**
   * Return formatted attribute value for the attribute of the given name in the
   * row at the given row index within the current range in the iterator that
   * this binding is associated with.
   */
   public Object getAttributeFromRow(int rowIndexInRange, String name)
   {
      return getAttributeFromRow(rowIndexInRange, getAttributeIndexOf(name));
   }


   /**
    * Return formatted attribute value for the attribute with the given attribute
    * definition and in the given row.
    */
   public Object getAttributeFromRow(Row row, AttributeDef def)
   {
      return getAttributeFromRow(row, def, true);
   }

   Object getAttributeFromRow(Row row, AttributeDef def, boolean formatted)
   {
      if (def == null)
      {
         if (def == null && getDCIteratorBinding() == null)
         {
            //if there is one name and it ends with .result, it's a method result binding.
            if (mAttrNames != null && mAttrNames.length == 1 && mAttrNames[0].endsWith(".result"))
            {
               //must be result in bindingContainer method-action.
               return getBindingContainer().findNamedObject(mAttrNames[0]);
            }
         }
         return null;
      }
      else
      {
         if (!isAttributeViewable(def.getIndex()))
         {
            return null;
         }

         JUIteratorBinding iterBind = getIteratorBinding();
         Object syncObj = (iterBind != null) ? iterBind.getSyncLock() : this;
         synchronized(syncObj)
         {
            LocaleContext locale = getLocaleContext();

            try
            {
               Object attrValue = null;
               AttributeHints hints = def.getUIHelper();
               boolean dataMode = (iterBind != null) ? !iterBind.isFindMode() : true;
               if (formatted && dataMode
                   && hints != null && hints.hasFormatInformation(locale))
               {
                  //for now domain attribute defs do not have hints.
                  try
                  {
                     // JRS 3284947 Catch formatting exceptions on get.
                     // The only way this can happen is if an invalid formatter
                     // format has been defined (development time) or if an
                     // invalid input value has been defined.  The latter case
                     // will still result in an input exception later when the
                     // invalid input value is reapplied.
                     attrValue = def.getUIHelper().getFormattedAttribute(row, locale);
                  }
                  catch(Exception e)
                  {
                     if (Diagnostic.isOn())
                     {
                        Diagnostic.print(
                           "A formatting exception occured:  " + def.getName());
                        Diagnostic.print(e.getMessage());
                     }
                  }
               }
               if ((attrValue == null) && isObjectAttributeBindingType())
               {
                  attrValue = Struct.getStructAttribute(row, getViewObject(), mAttrNames[getDefIndex(def)]);
               }
               else if (attrValue == null)
               {
                  //this is where parameter binding gets the value directly
                  //from expression.
                  attrValue = internalGetAttributeValueFromRow(row, def);
               }
               return attrValue;
            }
            catch(Exception ex)
            {
               reportException(ex);
            }

            return null;
         }
      }
   }

   /**
    * Return the attribute value for the attribute at the given index in this
    * control binding and from within the given row.
    */
   public Object getAttributeFromRow(Row row, int attrIndex)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(attrIndex), true);
   }


   /**
    * Return the attribute value for the attribute of the given name from within the given row.
    */
   public Object getAttributeFromRow(Row row, String name)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, findAttributeDef(name), true);
   }


   public void setAttributeInRow(int rowIndexInRange, int attrIndex, Object value, boolean handleException)
   {
      {
         try
         {
/***************
            Row[] rows = getAllRowsInRange();
            setAttributeInRow(rows[rowIndexInRange], getAttributeDef(attrIndex), value, handleException);
***************/
            Row row = getRowAtRangeIndex(rowIndexInRange);

            if (mAttrs == null) //OTO
            {
               if (isObjectAttributeBindingType())
               {
                  resolveObjectAttributeDefs(row);
               }
            }
            setAttributeInRow(row, getAttributeDef(attrIndex), value, handleException);
         }
         catch(JboException ex)
         {
            if (handleException)
            {
               reportException(ex);
            }
            else
            {
               throw ex;
            }
         }
      }
   }

   public String getNullValueString()
   {
      return mNullValueString;
   }

   protected void setNullValueString(String str)
   {
      mNullValueString = str;
   }

   public void setAttributeInRow(int rowIndexInRange, String name, Object value, boolean handleException)
   {
      setAttributeInRow(rowIndexInRange, getAttributeIndexOf(name), value, handleException);
   }

   public void setAttributeInRow(Row row, AttributeDef def, Object value)
   {
      setAttributeInRow(row, def, value, true);
   }

   public void setAttributeInRow(Row row, AttributeDef def, Object value, boolean handleException)
   {
      LocaleContext locale = getLocaleContext();
      if (def != null)
      {
         JUIteratorBinding iterBind = getIteratorBinding();
         Object syncObj = (iterBind != null) ? iterBind.getSyncLock() : this;
         synchronized(syncObj)
         {
            try
            {
               boolean dataMode = (iterBind != null) ? !iterBind.isFindMode() : true;
               if (dataMode)
               {
                  if (value != null)
                  {
                     Object parsedValue = null;

                     AttributeHints hints = def.getUIHelper();
                     if(hints != null && hints.hasFormatInformation(locale))
                     {
                        //for now domain attribute defs do not have hints.
                        if (!(value instanceof String))
                        {
                           value = formatValue(def, value);
                        }
                        parsedValue = def.getUIHelper().parseFormattedAttribute(value.toString(), locale) ;
                     }
                     value = (parsedValue != null) ? parsedValue : value;
                  }
               }
               else
               {
                  //find mode, so see if controlbinding allows findMode.
                  if (!isControlQueriable())
                  {
                     //return without setting the value if the
                     //control is not a queriable control.
                     //currently only textfield and grid support query.
                     if (Diagnostic.isOn())
                     {
                        Diagnostic.println("Warning! setInputValue ignores the value:"+value+" set for:"+getName());
                        Diagnostic.println("Binding subclass should return true for isControlQueriable to support findMode.");
                     }
                     return;
                  }
               }

               //there shouldn't be any exceptions state thus far.
               resetInputState();

               value = callBeforeSetAttribute(row, def, value);

               if (mErrExc != null && mErrExc.size() > 0)
               {
                  if (mErrExc.size() == 1)
                  {
                     throw (JboException)mErrExc.get(0);
                  }
                  throw new AttrSetValException(AttrSetValException.TYP_ATTRIBUTE_LIST_WITH_DEF,
                                                UIMessageBundle.class,
                                                UIMessageBundle.EXC_SYNC_ERROR,
                                                getName(),
                                                def.getName(),
                                                value,
                                                (Exception[])mErrExc.toArray(new JboException[mErrExc.size()]),
                                                true);
               }

               if (row != null)
               {
                  //go to setAttribute only if there's no binding side validation failure.
                  if (isAttributeBindingType())
                  {
                     DCDataControl dc = iterBind.getDataControl();
                     if (dc != null)
                     {
                        dc.setAttributeInRow(iterBind, row, def, value);
                     }
                     else
                     {
                        //variable
                        row.setAttribute(def.getName(), value);
                     }
                  }
                  else
                  {
                     Struct.setStructAttribute(row, getViewObject(), mAttrNames[getDefIndex(def)], value);
                     //for the first case when transaction is clean and on setAttr, the txn has
                     //to be set to modified state (even though the middletier is not in modified
                     //state yet as no sync has occured thus far.

                     //check if in find mode. in that case do not set the txnmodified state to true.
                     if (!iterBind.isFindMode() && !iterBind.getDataControl().isTransactionModified())
                     {
                        iterBind.getDataControl().setTransactionModified();
                     }
                  }
                  mAttributeUpdated = true;
               }
               else
               {
                  //do not throw exception as updates to controls via apis lead to this route
                  //in some cases.
                  internalSetAttribute(value);

               }
            }
            catch(JboException ex)
            {
               if (handleException)
               {
                  reportException(ex);
               }
               else
               {
                  throw ex;
               }
            }
         }
      }
   }


   //these two methods are where all get/setAttribute falls in.
   Object internalGetAttributeValueFromRow(Row row, AttributeDef def)
   {
      int index = def.getIndex();

      if (row != null)
      {
         return row.getAttribute(index);
      }
      else if (hasVariables()/* && index > -1*/)
      {
         AttributeDef defs[] = getAttributeDefs();
         if (defs.length > 0)
         {
            VariableValueManager mgr = ensureVariableManager();
            return mgr.getVariableValue(defs[0].getName());
         }
      }
      return null;
   }

   void internalSetAttribute(Object value)
   {
      if (hasVariables())
      {
         AttributeDef defs[] = getAttributeDefs();
         if (defs.length > 0)
         {
            VariableValueManager mgr = ensureVariableManager();
            mgr.setVariableValue(defs[0].getName(), value);
            return;
         }
      }
      if (Diagnostic.isOn())
      {
         Diagnostic.println("internalSetAttribute: Attempt to update attribute in null row with value:"+value);
      }
   }


   public void setAttributeInRow(Row row, int attrIndex, Object value, boolean handleException)
   {
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, getAttributeDef(attrIndex), value, handleException);
   }


   public void setAttributeInRow(Row row, String name, Object value, boolean handleException)
   {
      setAttributeInRow(row, findAttributeDef(name), value, handleException);
   }

   private boolean validateAttributeValue(Row row, AttributeDef def, Object value, boolean raiseEx)
   {
      boolean retVal = true;
      JUIteratorBinding iter = getIteratorBinding();
      boolean findMode = (iter != null) ? iter.isFindMode() : getBindingContainer().isFindMode();
      if (!findMode)
      {
         JUCtrlValueDef valDef = getCtrlValueDef();
         if (iter == null || iter.isOperationSupported(DCDataControl.OPER_CTRL_BINDING_VALIDATION)
             && valDef != null)
         {
            if (valDef.isApplyValidation())
            {
               //do typeconversion test first.
               if (value == null || !value.equals(mNullValueString))
               {
                  try
                  {
                     value = TypeFactory.convertAttributeValueToType(def, def.getJavaType(),
                                                                     value, AttrValException.TYP_ATTRIBUTE_LIST_WITH_DEF,
                                                                     valDef.getFullName());
                  }
                  catch (JboException jboe)
                  {
                     jboe.setNeedsEntityToVOMapping(false);

                     ApplicationModule am  = (iter != null) ? iter.getApplicationModule() : null;
                     if (raiseEx || am == null || !am.getTransaction().isBundledExceptionMode())
                     {
                        retVal = false;
                        throw jboe;
                     }
                     //cache the exception = do not throw.
                     setError(jboe, value, false);
                  }
               }

               ArrayList al = valDef.getValidatorsForAttribute(def);
               if (al != null)
               {
                  JboValidatorContext valCtx = new JboValidatorContext(
                                               JboValidatorContext.TYP_ATTRIBUTE_LIST_WITH_DEF,
                                               row,
                                               valDef.getFullName(),
                                               def,
                                               internalGetAttributeValueFromRow(row, def),
                                               value);

                  JboException ex = RulesBeanUtils.validate(al.iterator(),
                                       row,
                                       valCtx,
                                       false);
                  if (ex != null)
                  {
                     retVal = false;
                     ex.setNeedsEntityToVOMapping(false);
                     ApplicationModule am = iter.getApplicationModule();
                     if (raiseEx || am == null || !am.getTransaction().isBundledExceptionMode())
                     {
                        throw ex;
                     }
                     //cache the exception = do not throw.
                     setError(ex, value, false);
                  }
               }
            }
         }
      }
      return retVal;
   }

   Object callBeforeSetAttribute(Row row, AttributeDef def, Object value)
   {

      validateAttributeValue(row, def, value, false);
      return getBindingContainer().callBeforeSetAttribute(this, row, def, value);
   }

   Object internalGetConvertedValue(Object value)
   {
      return value;
   }

   /**
    ** <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected Row internalGetRow()
   {
      return getCurrentRow();
   }

   //
   // AttributeList implementation
   //

   /**
    * Returns formatted attribute value for the attribute at the given index in
    * this control binding's definition.
    */
   public Object getAttribute(int index)
   {
      Row row = internalGetRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(index), true);
   }


   public Object getAttribute(String name)
   {
      return getAttributeFromRow(internalGetRow(), findAttributeDef(name), true);
   }

   /**
    * Returns formatted attribute value for this binding.
   */
   public Object getAttribute()
   {
      return getAttribute(0);
   }


   /**
    * Returns formatted attribute values for this binding.
   */
   public Object[] getAttributes()
   {
      Object[] retVal = new Object[getAttributeCount()];
      for (int j = 0; j < retVal.length; j++)
      {
         retVal[j] = getAttribute(j);
      }
      return retVal;
   }

   /**
    * Returns formatted attribute values for the given set of attribute defs.
    */
   protected ArrayList getAttributes(Row row, AttributeDef attrs[])
   {
      ArrayList al = new ArrayList(attrs.length);
      for (int i = 0; i < attrs.length; i++)
      {
         al.add(getAttributeFromRow(row, attrs[i], true));
      }
      return al;
   }

   public void setAttribute(int index, Object value)
   {
      Row row = internalGetRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, getAttributeDef(index), value, false);
   }


   public void setAttribute(String name, Object value)
   {
      Row row = internalGetRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      setAttributeInRow(row, findAttributeDef(name), value, false);
   }


   public int getAttributeCount()
   {
      if (mAttrs != null)
      {
         return mAttrs.length;
      }
      else
      {
         getAttributeDefs();
         return (mAttrs != null) ? mAttrs.length : 0;
      }
   }


   public int getAttributeIndexOf(String name)
   {
      try
      {
         if (name == null)
         {
            throw new InvalidDefNameException(InvalidDefNameException.TYP_ATTRIBUTE,
                                              name);
         }

         AttributeDef[] attrs = getAttributeDefs();

         for (int j = 0; j < attrs.length; j++)
         {
            if (attrs[j].getName().equals(name))
            {
               return j;
            }
         }

         throw new NoDefException(NoDefException.TYP_ATTRIBUTE, name);
      }
      catch(Exception ex)
      {
         reportException(ex);
      }

      return -1;
   }


   /**
    * Returns unformatted attribute value of the first attribute
    *
    */
   public Object getAttributeValue()
   {
      Row row = internalGetRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(0), false);
   }

   /**
    * Returns unformatted attribute value of the first attribute
    *
    */
   public Object getAttributeValue(int j)
   {
      Row row = internalGetRow();
      if (mAttrs == null) //OTO
      {
         if (isObjectAttributeBindingType())
         {
            resolveObjectAttributeDefs(row);
         }
      }
      return getAttributeFromRow(row, getAttributeDef(j), false);
   }

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Sets the value to the first attribute in this binding.
    */
   public void setAttributeValue(Object val)
   {
     setAttribute(0, val);
   }

   /**
    * Returns un-formatted (raw) attribute values.
    */
   protected ArrayList getAttributeValues(Row row, AttributeDef attrs[])
   {
      ArrayList al = new ArrayList(attrs.length);
      for (int i = 0; i < attrs.length; i++)
      {
         al.add(getAttributeFromRow(row, attrs[i], false));
      }
      return al;
   }


   /**
    * Returns unformatted attribute value of the first attribute
    */
   protected Object getAttributeValueFromRow(int rowIndexInRange, int attrIndex)
   {
      {
         try
         {
            Row row = getRowAtRangeIndex(rowIndexInRange);

            if (row == null)
            {
               return null;
            }

            if (mAttrs == null) //OTO
            {
               if (isObjectAttributeBindingType())
               {
                  resolveObjectAttributeDefs(row);
               }
            }
            return getAttributeFromRow(row, getAttributeDef(attrIndex), false);
         }
         catch(Exception ex)
         {
            reportException(ex);
         }

         return null;
      }
   }


   /**
    * Returns unformatted attribute values for this binding.
   */
   public Object[] getAttributeValues()
   {
      Object[] retVal = new Object[getAttributeCount()];
      for (int j = 0; j < retVal.length; j++)
      {
         retVal[j] = getAttributeValue(j);
      }
      return retVal;
   }

   public static final String SEP_LIST_DISPLAY = " ";
   protected static String getMergedAttributeValues(List al)
   {
      StringBuffer buf = new StringBuffer();
      Object obj;
      for (int i = 0; i < al.size(); i++)
      {
         if (i > 0)
         {
            buf.append(SEP_LIST_DISPLAY);
         }
         obj = al.get(i);
         if (obj != null)
         {
            buf.append(al.get(i));
         }
      }
      return buf.toString();
   }

   /**
    * Returns true if the attribute at the given index is set to be mandatory.
    */
   public boolean isAttributeMandatory(int index)
   {
      JUIteratorBinding iterBind = getIteratorBinding();
      if (iterBind != null && iterBind.isFindMode())
      {
         return false;
      }
      AttributeDef ad = getAttributeDef(index);
      return (ad != null) ? ad.isMandatory() : false;
   }

   protected boolean isAttributeUpdateable(Row row, int index)
   {
      JUIteratorBinding iterBind = getIteratorBinding();
      if (iterBind != null)
      {
         synchronized(iterBind.getSyncLock())
         {
            try
            {
               boolean findMode = (iterBind.isFindMode());

               if (findMode)
               {
                  if (!iterBind.isOperationSupported(DCDataControl.OPER_FIND_MODE))
                  {
                     return false;
                  }
               }
               else
               {
                  if (!iterBind.isOperationSupported(DCDataControl.OPER_DATA_ROW_UPDATE))
                  {
                     return false;
                  }

                  //yvonne, this should be moved to DCDataControl.isOperationSupported
                  //which is consulted to perform this check.
                  if (!isInternalAttributeUpdateable(index))
                  {
                     return false;
		  }
               }

               if (row == null)
               {
                  row = internalGetRow();
               }

               if (row != null)
               {
                  DCBindingContainer bc = iterBind.getBindingContainer();
                  if (findMode)
                  {
                     //find mode.
                     if (isObjectAttributeBindingType() || !iterBind.isFindModeAllowed())
                     {
                        return false;
                     }
                     return (row.isAttributeUpdateable(getAttributeDef(index).getIndex())
                             && isControlQueriable());
                  }
                  else
                  {
                     if (mAttrs == null) //OTO
                     {
                        if (isObjectAttributeBindingType())
                        {
                           resolveObjectAttributeDefs(row);
                        }
                     }
                     return (isAttributeBindingType()) //OTO
                              ? row.isAttributeUpdateable(getAttributeDef(index).getIndex())
                              : true; //could we ask the attribute list for updateability?
                  }
               }
            }
            catch(Exception ex)
            {
               reportException(ex);
            }

         }
      }
      if (hasVariables())
      {
         return (getAttributeDef(0).getUpdateableFlag() != AttributeDef.READONLY);
      }
      return false;
   }

   /**
   * Determines whether this attribute is updateable for that row instance.
   * Returns true if iterator is in data mode and is the corresponding row. If
   * iterator is in find mode, then does an additional check to determine
   * whether the associated control is queriable.
   */
   public boolean isAttributeUpdateable(int index)
   {
      return isAttributeUpdateable(null, index);
   }

   /**
   * Notified by NavigationBar to stop any edits on the current control.
   * Primarily for grid and tree to notify their cell editors to stop
   * editing.
   */
   public void stopEditing() {}


   final void resolveAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT)
      {
         String names[] = mAttrNames;
         //if iteratorbinding is null then this is a method-result binding
         //there we only support scalars or collections. How about a bean?
         if (names != null && getDCIteratorBinding() != null)
         {
            for (int i = 0; i < names.length; i++)
            {
               if (names[i] != null && names[i].indexOf('.') > 0)
               {
                  mObjAttrBinding = BIND_OBJ_ATTR;
                  break;
               }
            }
         }
         if (mObjAttrBinding == BIND_INIT)
         {
            mObjAttrBinding = BIND_VO_ATTR;
         }
      }
   }

   final boolean isObjectAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT)
      {
         resolveAttributeBindingType();
      }
      return (mObjAttrBinding == BIND_OBJ_ATTR);
   }

   final boolean isAttributeBindingType()
   {
      if (mObjAttrBinding == BIND_INIT)
      {
         resolveAttributeBindingType();
      }
      return (mObjAttrBinding == BIND_VO_ATTR);
   }

   final void resolveObjectAttributeDefs(Row row)
   {
      mAttrs = new AttributeDef[mAttrNames.length];
      Struct.fillObjectAttributeDefs(row, getViewObject(), mAttrNames, mAttrs);
   }

   final int getDefIndex(AttributeDef ad)
   {
      for (int i = 0; i < mAttrs.length; i++)
      {
         if (ad == mAttrs[i])
         {
            return i;
         }
      }
      return -1;
   }

   public void setArrayIteratorType()
   {
      mIteratorBindingType = TYPE_ARRAY_ITERATOR;
   }

   public boolean isArrayIteratorType()
   {
      return (mIteratorBindingType == TYPE_ARRAY_ITERATOR);
   }

   public void release(int flags)
   {
      //if ((flags & DCDataControl.DATA_PROVIDER_REFERENCES) > 0)
      //this should also be done for release model, but for
      //now there's no need to expose release model to public
      if (flags == DCDataControl.REL_ALL_REFS)
      {
         JUIteratorBinding iter = getIteratorBinding();
         if (iter != null)
         {
            iter.removeValueBinding(this);
         }
      }
      super.release(flags);
   }

   public final LocaleContext getLocaleContext()
   {

      if (getBindingContainer() != null)
      {
          return getBindingContainer().getLocaleContext();
      }
      else
      {
         return new LocaleContext()
         {
            public java.util.Locale getLocale()
            {
                return java.util.Locale.getDefault();
            }

         };
      }
   }

   protected final AttributeHints getAttributeUIHelper(String attrName)
   {
      AttributeDef ad = (attrName != null)
                        ? findAttributeDef(attrName, false)
                        : getAttributeDef(0, true);
     if (ad != null)
     {
        return ad.getUIHelper();
     }
     return null;
   }


   public String[] getLabelSet()
   {
      AttributeDef defs[] = getAttributeDefs();
      if(defs == null)
      {
         return new String[0];
      }
      String[] retVal = new String[defs.length];
      for (int i = 0; i < defs.length; i++)
      {
         retVal[i] = defs[i].getUIHelper().getLabel(getLocaleContext());
      }
      return retVal;
   }

   public Map getLabels()
   {
      AttributeDef defs[] = getAttributeDefs();
      if (defs != null)
      {
         HashMap map = new HashMap(defs.length+3);
         for (int i = 0; i < defs.length; i++)
         {
            if(defs[i] != null)
               map.put(defs[i].getName(), defs[i].getUIHelper().getLabel(getLocaleContext()));
         }
         return map;
      }
      return null;
   }

   /***
   ** Retrieves the label to be used in any attribute prompts
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   ** @javabean.property
   **/
   public String getLabel()
   {
      AttributeDef aDef = getAttributeDef(0, true);

      if(aDef == null)
         return "";

      return aDef.getUIHelper().getLabel(getLocaleContext());
   }

  public Map getFormats()
  {
     AttributeDef defs[] = getAttributeDefs();
     if (defs != null)
     {
        JUIteratorBinding iterBind = getIteratorBinding();
        LocaleContext lc = getLocaleContext();
        HashMap map = new HashMap(defs.length);
        // JRS Removed the short circuit.  Please see the detailed analysis
        // in bug 4734276.  SJV, I think we may want to discuss this a bit
        // as well.
        //if ((iterBind != null && !iterBind.isFindMode())) 
        if ((iterBind != null))
        {
           for (int i = 0; i < defs.length; i++)
           {
              AttributeDef def = defs[i];
              if(def != null)
              {
                 map.put(def.getName(), def.getUIHelper().getFormat(lc));
              }
           }
        }
        return map;
     }
     return null;
  }

  /***
  ** Retrieves the format to be used to format any attribute value.
  **/
  public String getFormat()
  {
     JUIteratorBinding iterBind = getIteratorBinding();
     // JRS Removed the short circuit.  Please see the detailed analysis
     // in bug 4734276.  SJV, I think we may want to discuss this a bit
     // as well.
     //if (iterBind != null && iterBind.isFindMode())
     //{
     //   return null;
     //}

     AttributeDef aDef = getAttributeDef(0, true);

     if(aDef == null)
     {
        return null;
     }

     return aDef.getUIHelper().getFormat(getLocaleContext());
  }


   /***
   **  Retrives the tooltip text to be used for this attribute.
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   ** @javabean.property
   **/
   public String getTooltip()
   {
      return getAttributeDef(0, true).getUIHelper().getTooltip(getLocaleContext());
   }

   /***
   **  Retrieves the display hint that dictates whether this
   **  attribute should be visible or not. The two possible values
   **  are:
   **  <ul>
   **  <li>ATTRIBUTE_DISPLAY_HINT_DISPLAY  = "Display";
   **  <li>ATTRIBUTE_DISPLAY_HINT_HIDE     = "Hide";
   **  </ul>
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   **/
   public String getDisplayHint()
   {
      return getAttributeDef(0, true).getUIHelper().getDisplayHint(getLocaleContext());
   }

   /***
   **    Returns the preferred control type for this attribute.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   **/
   public int getControlType()
   {
      return getAttributeDef(0, true).getUIHelper().getControlType(getLocaleContext());
   }

   /**
   **    Returns the display width for this attribute.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   **
   **/

   public int getDisplayWidth()
   {
      return getAttributeDef(0, true).getUIHelper().getDisplayWidth(getLocaleContext());
   }

   /**
   **    Returns the display width for this attribute.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   **
   **/
   public int getDisplayHeight()
   {
      return getAttributeDef(0, true).getUIHelper().getDisplayHeight(getLocaleContext());
   }

  /**
   ** Returns the hint value based on the hint name.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **/

   public String getHint(String sHintName)
   {
      return getAttributeDef(0, true).getUIHelper().getHint(getLocaleContext(), sHintName);
   }

   /**
    **   Returns true if any format hints have been defined for this
    **   attribute. This function should be used to bracket any calls
    **   to the formatting API.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
    **/
   public boolean hasFormatInformation()
   {
      JUIteratorBinding iterBind = getIteratorBinding();
      if (iterBind != null && iterBind.isFindMode())
      {
         return false;
      }
      return getAttributeDef(0, true).getUIHelper().hasFormatInformation(getLocaleContext());
   }

   /**
    **   Returns true if the attribute is to displayed in the short(summary) form.
   ** <p>
   ** Calling this on a control-binding that does not have an attribute will
   ** throw a NullPointerException
   **
   **
   **/
   public boolean displayInShortForm()
   {
      return getAttributeDef(0, true).getUIHelper().displayInShortForm(getLocaleContext());
   }

   //Overridden Control Hint methods to get Object Attribute hints as well.

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voAttrName, String objectAttrName)
   {
      String str = getHint(voAttrName, objectAttrName, AttributeHints.ATTRIBUTE_LABEL);
      if (str == null)
      {
         int index = objectAttrName.lastIndexOf('.');
         if (index > -1)
         {
            str = objectAttrName.substring(index+1);
         }
         else
         {
            str = objectAttrName;
         }
      }
      return str;
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voAttrName, String objectAttrName)
   {
      return getHint(voAttrName, objectAttrName, AttributeHints.ATTRIBUTE_TOOLTIP);
   }

  /**
   ** Returns the hint value based on the hint name.
   **/
   public String getHint(String voAttrName, String objectAttrName, String sHintName)
   {
      StringBuffer hintBuf = new StringBuffer();
      if (objectAttrName != null && objectAttrName.length() > 0)
      {
         hintBuf.append(objectAttrName.replace('.','_')).append('_');
      }

      hintBuf.append(sHintName);

      return findAttributeDef(voAttrName, true).getUIHelper().getHint(getLocaleContext(), hintBuf.toString());
   }

   StructureDef getStructureDef()
   {
      return this;
   }

   JUCtrlValueDef getCtrlValueDef()
   {
      return (JUCtrlValueDef)getDef();
   }

   //for first attribute
   public final ArrayList getAttributeValidators()
   {
      return getAttributeValidators(0);
   }

   public ArrayList getAttributeValidators(int index)
   {
      return (getDef() != null) ? getCtrlValueDef().getValidatorsForAttribute(getAttributeDef(index)) : null;
   }



   //this is the public api that should be visible to spel via code-insight
   //we need to do a bean info for each of the control bindings to indicate
   //what apis are exposed in this method.
   public static final String ATTR_LABEL            = "label";
   public static final String ATTR_LABELS           = "labels";
   public static final String ATTR_LABELSET         = "labelSet";
   public static final String ATTR_FORMAT           = "format";
   public static final String ATTR_FORMATS          = "formats";
   public static final String ATTR_TOOLTIP          = "tooltip";
   public static final String ATTR_DISPLAY_HINT     = "displayHint";
   public static final String ATTR_DISPLAY_HEIGHT   = "displayHeight";
   public static final String ATTR_DISPLAY_WIDTH    = "displayWidth";
   public static final String ATTR_ATTRIBUTE        = "attribute";
   public static final String ATTR_ATTRIBUTES       = "attributes";
   public static final String ATTR_ATTRIBUTE_DEF    = "attributeDef";
   public static final String ATTR_ATTRIBUTE_DEFS   = "attributeDefs";
   public static final String ATTR_ATTRIBUTE_VALUE  = "attributeValue";
   public static final String ATTR_ATTRIBUTE_VALUES = "attributeValues";
   public static final String ATTR_INPUT_VALUE      = "inputValue";
   public static final String ATTR_UPDATEABLE       = "updateable";
   public static final String ATTR_MANDATORY        = "mandatory";
   public static final String ATTR_PATH             = "path";
   public static final String ATTR_VIEWABLE         = "viewable";       //NONLS
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>attributeValue</code> - returns getAttributeValue()</li>
    * <li><code>inputValue</code>  - returns getInputValue()</li>
    * <li><code>updateable</code> - returns isUpdateable()</li>
    * <li><code>mandatory</code> - returns isMandatory()</li>
    * <li><code>path</code> - returns getPath()</li>
    * <li><code>attributeValues</code> - returns getAttributeValues()</li>
    * <li><code>label</code> - returns getLabel()</li>
    * <li><code>tooltip</code>  - returns getTooltip()</li>
    * <li><code>displayHint</code> - returns getDisplayHint()</li>
    * <li><code>displayHeight</code> - returns getDisplayHeight()</li>
    * <li><code>displayWidth</code> - returns getDisplayWidth()</li>
    * <li><code>attributeDef</code> - returns getAttributeDef()</li>
    * <li><code>attributeDefs</code> - returns getAttributeDefs()</li>
    * <li><code>labels</code> - returns getLabels()</li>
    * <li><code>labelSet</code> - returns getLabelSet()</li>
    */
   protected Object internalGet(String key)
   {
      AttributeDef def = lookupAttributeDef(key);
      if (def == null)
      {
         def = lookupAttributeDef(JboNameUtil.toUpperCaseFirstChar(key));
      }

      if (def != null)
      {
         mInternalGet_KeyResolved = true;
         return getAttributeFromRow(internalGetRow(), def, true);
      }

      key = key.intern();
      if (ATTR_ATTRIBUTE_VALUE == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttributeValue();
      }
      if (ATTR_INPUT_VALUE == key)
      {
         mInternalGet_KeyResolved = true;
         return getInputValue();
      }
      if (ATTR_UPDATEABLE == key)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isUpdateable());
      }
      if (ATTR_MANDATORY == key)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isMandatory());
      }
      if (key == ATTR_PATH)
      {
         mInternalGet_KeyResolved = true;
         return getPath();
      }
      if (ATTR_ATTRIBUTE_VALUES == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttributeValues();
      }
      if (ATTR_ATTRIBUTE == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttribute();
      }
      if (ATTR_ATTRIBUTES == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttributes();
      }
      if (ATTR_LABEL == key)
      {
         mInternalGet_KeyResolved = true;
         return getLabel();
      }
      if (ATTR_FORMAT == key)
      {
         mInternalGet_KeyResolved = true;
         return getFormat();
      }
      if (ATTR_TOOLTIP == key)
      {
         mInternalGet_KeyResolved = true;
         return getTooltip();
      }
      if (ATTR_ATTRIBUTE_DEF == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttributeDef();
      }
      if (ATTR_ATTRIBUTE_DEFS == key)
      {
         mInternalGet_KeyResolved = true;
         return getAttributeDefs();
      }
      if (ATTR_DISPLAY_HINT == key)
      {
         mInternalGet_KeyResolved = true;
         return getDisplayHint();
      }
      if (ATTR_LABELS == key)
      {
         mInternalGet_KeyResolved = true;
         return getLabels();
      }
      if (ATTR_FORMATS == key)
      {
         mInternalGet_KeyResolved = true;
         return getFormats();
      }
      if (ATTR_LABELSET == key)
      {
         mInternalGet_KeyResolved = true;
         return getLabelSet();
      }
      if (key == ATTR_VIEWABLE)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isViewable());
      }
      if (ATTR_DISPLAY_HEIGHT == key)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getDisplayHeight());
      }
      if (ATTR_DISPLAY_WIDTH == key)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getDisplayWidth());
      }

      //let these go via introspection.
      //if (key == ATTRIBUTE_CTL_TYPE)
      //if (key == ATTRIBUTE_CTL_DISPLAYWIDTH)
      //if (key == ATTRIBUTE_CTL_DISPLAYHEIGHT
      //if (key == ATTRIBUTE_CTL_FORMTYPE
      return super.internalGet(key);
   }

   public Object put(Object obj, Object value)
   {
      if (obj instanceof String)
      {
         String key = ((String)obj).intern();
         if (ATTR_ATTRIBUTE_VALUE == key)
         {
            Object ret = getAttributeValue();
            setAttributeValue(value);
            return ret;
         }
         if (ATTR_INPUT_VALUE == key)
         {
            Object ret = getInputValue();
            setInputValue(value);
            return ret;
         }
      }
      return super.put(obj, value);
   }

   protected void resetInputState()
   {
      removeFromDCExceptions();
      mErrExc = null;
      mInputVal = null;
      mHasInputVal = false;
      mAttributeUpdated = false;
   }


   protected void processInputException(ValidationException vex)
   {
      AttributeDef defs[] = getAttributeDefs();

      //taking out this optimization as we need to look into attributes
      //that were not set as well. They may have entity level mandatory failures
      //etc that needs to be set on the attribute.
      //if (mHasInputVal)
      for (int i = 0; i < defs.length; i++)
      {
         if (vex.hasAttributeException(defs[i].getName()))
         {
            setError(vex.getAttributeException(null, defs[i].getName()), null, false);
            break;
         }
      }
   }

   protected void setError(JboException vex, Object value)
   {
      setError(vex, value, true);
   }

   void setError(JboException vex, Object value, boolean reportException)
   {
      if (mErrExc == null)
      {
         mErrExc = new ArrayList(3);
      }

      if (vex == null)
      {
         mHasInputVal = false;
      }
      else if (!mErrExc.contains(vex))
      {
         if(vex.hasPeerExceptions() )
         {
            if (mErrExc.contains(vex.getExceptions()[0]))
            {
               //inner exceptions have been cached.
               return;
            }
         }
         mErrExc.add(vex);
         boolean attrExc = vex instanceof AttrValException;
         if (mInputVal == null)
         {
            mInputVal = (value != null) ? value
                           : ((attrExc)
                              ? ((AttrValException)vex).getAttrValue()
                              : null);

            DCIteratorBinding iter = getIteratorBinding();
            if ( mInputVal != null
                 && iter != null
                 && !iter.isFindMode())
            {
               try
               {
                  mInputVal = formatValue(getAttributeDef(), mInputVal);
               }
               catch(Exception e)
               {
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.print("A formatting exception occured:  " + getName());
                     Diagnostic.print(e.getMessage());
                  }
               }
            }
         }

         mHasInputVal = true;

         //if this binding has updated the value onto the target row,
         //then reset the attribute value as we have an exception for the
         //input value and the row may have cached this exception.
         if (attrExc && mAttributeUpdated)
         {
            resetAttributeExceptionInRow(getCurrentRow(), getAttributeDef(), (AttrValException)vex);
            mAttributeUpdated = false;
         }
         addToDCExceptions(vex);

         DCDataControl dc = (getIteratorBinding() != null)
                          ? getIteratorBinding().getDataControl()
                          : getBindingContainer().getDataControl();
         if (reportException)
         {
            if (dc != null)
            {
               dc.reportException(getBindingContainer(), vex);
            }
            else
            {
               if (getBindingContainer() != null)
               {
                  getBindingContainer().reportException(vex);
               }
            }
         }
         else
         {
            getBindingContainer().cacheException(vex);
         }
      }
   }

   //These methods are primarily for Spel support to get access to the first attribute values.
   //These could be changed/merged into a get method to allow access to these properties via spel
   //and without performing introspection/reflection

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Returns updateability of the first attribute
    *
    * @javabean.property
    */
   public boolean isUpdateable()
   {
     return isAttributeUpdateable(0);
   }

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Returns mandatory flag for the first attribute that this binding
    * is bound to.
    *
    * @javabean.property
    */
   public boolean isMandatory()
   {
     return isAttributeMandatory(0);
   }

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Returns Attribute definition for the first attribute
    *
    * @javabean.property
    */
   public AttributeDef getAttributeDef()
   {
     return getAttributeDef(0, true);
   }

   final static char VALUE_PATH_DIVIDER = '#';

   /**
    **The returned path uniquely identifies this binding
    * within a top-level bindingContainer.
    **/
   public String getPath()
   {
      //bring back 1012 style path behavior as . in names breaks InputRenderers.
      //as per ADFFaces, this variable is not used in faces bindings.
      StringBuffer buf = new StringBuffer()
                         .append(DCUtil.DATA_PREFIX)
                         .append(getFullName().replace(DCUtil.SEP_DOT_CHAR, VALUE_PATH_DIVIDER));

      return buf.toString();

      /*
      //I could have transformed the . into something webspecific
      //but that implementation is view specific as each view may have
      //it's own reserved chars, so let the view decide how to
      //mask . in the name.
      StringBuffer buf = new StringBuffer()
                         .append(DCUtil.DATA_PREFIX)
                         .append(getFullName());

      return buf.toString();
      */
   }

   /**
    * Return true if this binding's path is found as a key in the given map.
    */
   public boolean resolvePath(Map postMap)
   {
      if (postMap != null)
      {
         String path = getPath();
         if (postMap.containsKey(path))
         {
            Object mappedObj = postMap.get(path);
            if (mappedObj != null && mappedObj.getClass().isArray())
            {
               //Note that in case of web applications this map is a ServletReqest.getParametersMap
               //and values in the map are returned as String[] from the request parameters map
               //as per ServletRequest javadoc.
               if (mappedObj instanceof String[])
               {
                  mappedObj = ((String[])mappedObj)[0];
               }
            }
            if (processNewInputValue(mappedObj))
            {
               DCIteratorBinding iter = getIteratorBinding();
               if (iter != null)
               {
                  iter.internalReserveCurrentRow();
               }
               return true;
            }
         }
      }
      return false;
   }

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Returns the last input value for the first attribute on this binding if this value
    * raised an exception. Otherwise returns the value from the model object calling
    * getAttribute(0);
    *
    * @javabean.property
    */
   public Object getInputValue()
   {
      getError();

      Object inval;

      if (mErrExc != null)
      {
        inval = mInputVal;
      }
      else
      {
         if (mLookupInputHandler == IH_UNINIT)
         {
           resolveInputHandler();
         }

         inval = (mLookupInputHandler == IH_READWRITE)
                 ? ((JUCtrlValueHandler)mInputHandler).getInputValue(this, 0)
                 : getInputValue(this, 0);
      }

      return inval;
   }

   public Object getInputValue(JUCtrlValueBinding binding, int index)
   {
      return this.getInputValueInRow(binding, internalGetRow(), getAttributeDef(index));
   }



   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get()
    * method for spel-access.
    * <p>
    * Sets the value given and caches any error/exception in member variables
    * for further access. Also rethrows the exception for outer methods to catch it.
    */
   public void setInputValue(Object value)
   {
      try
      {
         resetInputState();

         mInputVal = value;
         mHasInputVal = true;

         if (mLookupInputHandler == IH_UNINIT)
         {
            resolveInputHandler();
         }

         //in batch mode exception is not raised right away but on sync/validate
         //in that case HasInputVal is to be set to true so that on error processing
         //errors are cached
         mInputHandler.setInputValue(this, 0, value);
      }
      catch (JboException e)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("CtrlAttrs: Caching exception :"+e);
         }
         setError(e, value);
         //exception is already passed to bindingContainer and from
         //there to custom error handler and back to the binding
         //no need to rethrow this.
      }
   }

   /**
    * Return true if this value is valid as per validations defined for this binding.
    */
   public Object validateInputValue(Object value)
   {
      try
      {
         validateAttributeValue(getCurrentRow(), getAttributeDef(), value, true);
      }
      catch (Exception e)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Failed to validate :"+value+" for binding:"+getName());
         }
         return e;
      }
      return null;
   }

   public void setInputValue (JUCtrlValueBinding binding, int index, Object value)
   {
      setInputValueInRow(binding, internalGetRow(), getAttributeDef(index, true), value, false);
   }

   protected void setInputValueInRow(JUCtrlValueBinding binding, Row row, AttributeDef ad, Object value, boolean handleException)
   {
      if (value != null  && value.equals(getNullValueString()))
      {
         JUIteratorBinding iterBind = getIteratorBinding();
         if ((iterBind != null) && !iterBind.isFindMode())
         {
            value = null;
         }
      }
      binding.setAttributeInRow(row, ad, value, handleException);

   }

   protected Object getInputValueInRow(JUCtrlValueBinding binding, Row row, AttributeDef ad)
   {
      Object inval = getAttributeFromRow(row, ad, true);
      if (inval == null)
      {
         JUIteratorBinding iterBind = getIteratorBinding();
         if ((iterBind != null) && !iterBind.isFindMode())
         {
            return mNullValueString;
         }
      }
      return inval;
   }

   /**
    * Returns true, if the caller needs to call setInputValue() on this
    * binding to update the current attribute value that this binding is set to.
    * <p>
    * If the value is different than the attribute value, or if this binding
    * had cached an error in a pervious setInputValue, then this method
    * returns true.
    */
   public boolean processNewInputValue(Object value)
   {
      if (mLookupInputHandler == IH_UNINIT)
      {
         resolveInputHandler();
      }
      return mInputHandler.isNewInputValue(this, 0, value);
   }

   void lookupInputHandler()
   {
      mLookupInputHandler = IH_UNINIT;
   }

   void resolveInputHandler()
   {
      JUCtrlValueDef def = (JUCtrlValueDef)getDef();

      String handlerId = null;
      if (def != null)
      {
         handlerId = def.getCustomInputHandler();
         if (JUCtrlValueDef.DEFAULT_HANDLER.equals(handlerId))
         {
            handlerId = getAttributeDef(0).getJavaType().getName();
         }
      }

      if (handlerId != null)
      {
         DCDataControl dc = (getIteratorBinding() != null)
                          ? getIteratorBinding().getDataControl()
                          : getBindingContainer().getDataControl();
         mInputHandler = (JUCtrlInputValueHandler)
                       dc.getBindingContext().getBindingInputHandler(handlerId);
         if (Diagnostic.isOn() && mInputHandler == null)
         {
            Diagnostic.println("Warning! No InputHandler found for :"+handlerId);
            Diagnostic.println("******** Using default InputHandler");
         }
      }

      if (mInputHandler == null)
      {
         mInputHandler = this;
         mLookupInputHandler = IH_READWRITE;
      }
      else
      {
         mLookupInputHandler = (mInputHandler instanceof JUCtrlValueHandler)
                             ? IH_READWRITE
                             : IH_WRITEONLY;
      }
   }

   /**
    * Returns true, if the caller needs to call setInputValue() on this
    * binding to update the current attribute value that this binding is set to.
    * <p>
    * If the value is different than the attribute value, or if this binding
    * had cached an error in a pervious setInputValue, then this method
    * returns true.
    */
   public boolean isNewInputValue(JUCtrlValueBinding binding, int index, Object value)
   {
      DCIteratorBinding iter = binding.getIteratorBinding();

      if (iter != null)
      {
         iter.prepareForInput();
      }

      //if an exception was cached on this binding, that means this binding was set via setInputValue and
      //had errors, so needs to be cleaned. Returning true in this case indicates that setInputValue
      //should be called on this binding again.
      boolean retVal = true;
      if (this.mErrExc == null)
      {
         //use formatted attribute value for comparision.
         Object currentValue = binding.getAttribute(index);
         if (value == null && currentValue == null)
         {
            retVal = false;
         }
         else if (value != null)
         {
            if (value instanceof String)
            {
               if (((String)value).length() == 0)
               {
                  if (currentValue == null)
                  {
                     //if in datamode, then assume that the currentvalue = new value (as
                     //both of them are null).
                     //in find mode, do the comparision and then proceed.
                     if (iter == null || !iter.isFindMode())
                     {
                        retVal = false;
                     }
                  }
                  //check for mutableDomainInterface - Object/Image types. If they're non null
                  //a renderer should be displaying them and an inputRenderer should not pass
                  //"" for value if the domain is edited/updated.
                  else if (currentValue instanceof oracle.jbo.domain.MutableDomainInterface)
                  {
                     //for now treat null as "" as html passes "" for nulls.
                     //how would this impact a legit string value of ""?
                     retVal = false;
                  }
                  else if (value.equals(mNullValueString))
                  {
                     //can't go for conversion in TypeFactory as null value string
                     //may not be convertible to this attribute's type.
                     return true;
                  }
               }
            }

            if (retVal)
            {
               DCIteratorBinding iterBind = getIteratorBinding();
               boolean dataMode = (iterBind != null) ? !iterBind.isFindMode() : true;
               if (dataMode)
               {
                  LocaleContext locale = getLocaleContext();
                  AttributeDef def = binding.getAttributeDef(index);
                  Object formattedValue = formatValue(def, value);
                  value = (formattedValue != null) ? formattedValue : value;
               }
               retVal = !(value.equals(TypeFactory.getInstance(value.getClass(), currentValue)));
            }
         }
      }

      return retVal;
   }

   Object formatValue(AttributeDef def, Object value)
   {
      Object formattedValue = value;
      try
      {
         LocaleContext locale = getLocaleContext();
         AttributeHints hints = def.getUIHelper();
         if (hints != null && hints.hasFormatInformation(locale))
         {
            //for now domain attribute defs do not have hints.
            Formatter   formatter = hints.getFormatter(locale);
            String      sFormat = hints.getFormat(locale);
            formattedValue = formatter.format(sFormat, value);
         }
      }
      catch(Exception e)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.print(
               "A formatting exception occured:  " + def.getName());
            Diagnostic.print(e.getMessage());
         }
      }
      return formattedValue;
   }

   /**
    * Primarily for spel support.
    * <p>
    * Returns exception that occured on last setInputValue
    *
    * @javabean.property
    */
   public JboException getError()
   {
      if (mErrExc == null)
      {
         DCIteratorBinding iter = getIteratorBinding();
         if (iter != null && iter.getError() != null)
         {
            iter.processInputException();
         }
      }

      //only the first error.
      if (mErrExc != null && mErrExc.size() > 0)
      {
         JboException ex = (JboException)mErrExc.get(0);
         ex.setLocaleContext(getLocaleContext());
         return ex;
      }

      return null;
   }

   /**
    * Primarily for spel support.
    * <p>
    * Returns exceptions that occured on last setInputValue
    *
    */
   public List getErrors()
   {
      DCIteratorBinding iter = getIteratorBinding();
      if (mErrExc == null && iter != null)
      {
         if (iter.getError() != null)
         {
            iter.processInputException();
         }
      }

      //return (mErrExc != null && mErrExc.size() > 0) ? (List)mErrExc.clone() : null;
      return DCUtil.getLocalizedExceptionsList(mErrExc, getLocaleContext());
   }

   protected List getInputErrorsForRowKey(oracle.jbo.Key key)
   {
      return getErrors();
   }

   boolean hasBoundAttrChanged(int[] attrIdxs)
   {
      AttributeDef[] ads;
      for (int i = 0; i < attrIdxs.length; i++)
      {
         ads = getAttributeDefs();
         if (ads.length > 0)
         {
            for (int j = 0; j < ads.length; j++)
            {
               if (ads[j].getIndex() == attrIdxs[i])
               {
                  return true;
               }
            }
         }
      }
      return false;
   }

   /**
    * Advanced method.
    * Compares the value from the value for an attribute at the given index
    * as stored by the data that this binding is bound to and if the value
    * is different, then sets it on the bound attribute at the given index.
    */
   public void compareAndSetAttribute(int index, Object cVal)
   {
      Object dVal = getAttribute(index);  // value from the row

      // If value is the same, don't do anything
      if (cVal == dVal)
      {
         return;
      }

      // Here "" is the definiton of a null value
      String cStr = (cVal == null) ? "" : cVal.toString();
      String dStr = (dVal == null) ? "" : dVal.toString();

      if (!cStr.equals(dStr))
      {
         try
         {
            setAttribute(index, cVal);
         }
         catch (oracle.jbo.JboException ex)
         {
            reportException(ex, true);
         }
      }
   }

   /**
    * Return the input handler that this binding uses for setInputValue.
    * By default this binding itself is the input handler. This handler may
    * be customized by providing a custom inputhandler class name in the
    * definition for this binding (declaritvely at designtime) or by setting
    * it programmatically using the setInptuValueHandler method.
    */
   public final JUCtrlInputValueHandler getInputValueHandler()
   {
      return mInputHandler;
   }

   public void setInputValueHandler(JUCtrlInputValueHandler hdlr)
   {
       if ( hdlr != null )
       {
           mInputHandler = hdlr;
           mLookupInputHandler = (mInputHandler instanceof JUCtrlValueHandler)
                                  ? IH_READWRITE
                                  : IH_WRITEONLY;
       }
   }


   public final boolean hasVariables()
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (iter != null && iter.getClass() == JUVariableIteratorBinding.class)
      {
         return true;
      }
      return (getCtrlValueDef() != null && getCtrlValueDef().hasVariables());
   }

   public final VariableValueManager ensureVariableManager()
   {
      if (hasVariables() && getIteratorBinding() != null)
      {
         return ((JUVariableIteratorBinding)getIteratorBinding()).ensureVariableManager();
      }
      return getBindingContainer().ensureVariableManager();
   }

   protected boolean internalHasPermission(String target, String actions)
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (iter != null)
      {
         String permClassName = null;

         String targetName = iter.getPermissionTargetName();
         if (targetName != null && target.equalsIgnoreCase(targetName))
         {
            permClassName = PermissionHelper.getPermissionClassName(PermissionHelper.ROWSET_PERMISSION);
         }
         else
         {
            permClassName = PermissionHelper.getPermissionClassName(PermissionHelper.ATTRIBUTE_PERMISSION);
         }

         if (permClassName != null)
         {
            Permission p = (Permission)PermissionHelper.createPermissionInstance(permClassName, target, actions);
            if (!PermissionHelper.hasPermission(ADFContext.getCurrent().getSecurityContext(), p))
            {
               return false;
            }
         }
      }

      return true;
   }

   String getPermissionTargetName(String attrName)
   {
      DCIteratorBinding iter = getIteratorBinding();
      StringBuffer sbuf = new StringBuffer();
      if (iter != null)
      {
	 sbuf.append(iter.getPermissionTargetName());
	 if (attrName != null)
	 {
	    sbuf.append(DCUtil.SEP_DOT_CHAR).append(attrName);
	 }
      }
      return sbuf.toString();
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
	 String targetName = (mAttrNames.length > 0) ? mAttrNames[0] : null;
         if (targetName != null && getName().equals(targetName))
	 {
	    mPermissionInfo = new PermissionBinding(getPermissionTargetName(targetName), PermissionHelper.ATTRIBUTE_PERMISSION);
	 }
	 else
	 {
	    mPermissionInfo = new PermissionBinding(getPermissionTargetName(null), PermissionHelper.ROWSET_PERMISSION, getLabels());
	 }
      }
      return mPermissionInfo;
   }

   boolean isViewable()
   {
      if (!PermissionHelper.isAuthorizationEnabled() )
      {
	  return true;
      }

      if (mReadAuthorized == null)
      {
         initAuthorizationFlags();
      }

      if (mReadAuthorized[0] != PermissionHelper.NOT_CHECKED)
      {
         return mReadAuthorized[0] == PermissionHelper.HAS_PERMISSION ? true : false; 
      }

      JUIteratorBinding iter = getIteratorBinding();
      if (iter != null)
      {
         if (!iter.getDataControl().hasPermission(this, iter.getPermissionTargetName(), PermissionHelper.READ_ACTION))
         {
            mReadAuthorized[0] = PermissionHelper.NO_PERMISSION;
            return false;
         }
      }
      mReadAuthorized[0] = PermissionHelper.HAS_PERMISSION;
      return true;
   }

   boolean isAttributeViewable(int index)
   {
      if (!PermissionHelper.isAuthorizationEnabled() )
      {
	 return true;
      }

      JUIteratorBinding iter = getIteratorBinding();
      if (iter != null)
      {
         synchronized(iter.getSyncLock())
         {
            int ix = index;
            AttributeDef aDef = getAttributeDef(ix);

            if (aDef == null)
            {
	       ix = 0;
               aDef = getAttributeDef(ix, true);
               if (aDef == null)
               {
                  return true;
               }
            }

	    if (mReadAuthorized == null)
            {
	      initAuthorizationFlags();
            }
            else if (mReadAuthorized[ix] != PermissionHelper.NOT_CHECKED)
            {
               return mReadAuthorized[ix] == PermissionHelper.HAS_PERMISSION ? true : false; 
            }

	    String targetName = getPermissionTargetName(aDef.getName());
	    if (!internalHasPermission(targetName, PermissionHelper.READ_ACTION))
            {
	       mReadAuthorized[ix] = PermissionHelper.NO_PERMISSION;
               return false;
            }
	    mReadAuthorized[ix] = PermissionHelper.HAS_PERMISSION;
         }
      }
      return true;
   }

   void initAuthorizationFlags()
   {
       AttributeDef[] attrs = getAttributeDefs();

       if (mReadAuthorized == null)
       {
	  mReadAuthorized = new int[attrs.length];

	  for (int i = 0; i < attrs.length; i++)
	  {
	      mReadAuthorized[i] = PermissionHelper.NOT_CHECKED;
	  }
       }
       if (mUpdateAuthorized == null)
       {
	  mUpdateAuthorized = new int[attrs.length];

	  for (int i = 0; i < attrs.length; i++)
	  {
	      mUpdateAuthorized[i] = PermissionHelper.NOT_CHECKED;
	  }
       }
   }

   boolean isInternalAttributeUpdateable(int index)
   {
      if (PermissionHelper.isAuthorizationEnabled ())
      {
         if (mUpdateAuthorized == null)
           initAuthorizationFlags();

         if (index < mUpdateAuthorized.length && mUpdateAuthorized[index] == PermissionHelper.NO_PERMISSION)
         {
            return false;
         }
     
         if (index < mUpdateAuthorized.length && mUpdateAuthorized[index] == PermissionHelper.NOT_CHECKED)
         {
            AttributeDef attrDef = getAttributeDef(index);
            if (attrDef != null)
            {
               String targetName = getPermissionTargetName(attrDef.getName());
               DCDataControl dc = getIteratorBinding().getDataControl();
               if (dc != null && !dc.hasPermission(this, targetName, PermissionHelper.UPDATE_ACTION))
	       {
                  mUpdateAuthorized[index] = PermissionHelper.NO_PERMISSION;
	          return false;
	       }
               mUpdateAuthorized[index] = PermissionHelper.HAS_PERMISSION;
	    }
         }
      }
      return true;
   }
}
