/*
 * @(#)JUCtrlActionBindingAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

/**
 * Default adapter for JUCtrlActionBindingListener event.
 */
public class JUCtrlActionBindingAdapter implements JUCtrlActionBindingListener
{
   public void beforeActionPerformed(JUCtrlActionBindingEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeActionPerformed :" + ev.getBinding().getName());
   }

   public void afterActionPerformed(JUCtrlActionBindingEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("afterActionPerformed :" + ev.getBinding().getName());
   }
}
