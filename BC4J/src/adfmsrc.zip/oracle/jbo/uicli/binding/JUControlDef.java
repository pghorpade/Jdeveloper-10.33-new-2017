/*
 * @(#)JUControlDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import oracle.jbo.NoObjException;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.adf.model.binding.DCControlBindingDef;

abstract public class JUControlDef extends DCControlBindingDef
{
   
   public JUControlDef()
   {
      super();
   }


   public JUControlDef(String name, String controlClassName,
                       String controlBindingClassName, String iterBindingName)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName);
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);
   }

   
   void setFormDef(JUFormDef formDef)
   {
      super.setBindingContainerDef(formDef);
   }
   
   
   public JUIteratorBinding getIterBinding(JUFormBinding formBnd)
   {
      String iterName = getIterBindingName();
      if (iterName != null)
      {
         JUIteratorBinding iter = formBnd.findIterBinding(iterName);
         if (iter != null)
         {
            return iter;
         }
      }
      throw new NoObjException(JUMetaObjectBase.TYP_ITER_BINDING, getIterBindingName());
   }
}
