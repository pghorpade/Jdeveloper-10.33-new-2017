/*
 * @(#)JUCtrlListDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.mom.xml.DefElement;

import oracle.jbo.common.Diagnostic;

public class JUCtrlListDef extends JUCtrlAttrsDef
{
   private int mListOperMode = JUCtrlListBinding.LIST_OPER_SET_ATTRIBUTE;
   private boolean mStaticList;
   private String mListVOName;
   private String mListRSIName;
   private String[] mListAttrNames;
   private String[] mListDisplayAttrNames;
   private int mListRangeSize = -1;
   private Object[] mValueList;
   private String[] mLabelList;
   private String mListIterName;
   protected int mNullValueFlag = JUCtrlListBinding.LIST_ADD_NULL_UNINIT;
   
   public static final String PNAME_ListOperMode = "ListOperMode";
   public static final String PNAME_StaticList = "StaticList";
   public static final String PNAME_ListAttrNames = "ListAttrNames";
   public static final String PNAME_ListDisplayNames = "ListDisplayAttrNames";
   public static final String PNAME_ListRangeSize = "ListRangeSize";
   public static final String PNAME_ValueList = "ValueList";
   public static final String PNAME_LabelList = "LabelList";
   
   //for use by JClient 904 style test code.
   public static final String PNAME_ListVOName = "ListVOName";
   public static final String PNAME_ListRSIName = "ListRSIName";
   public static final String PNAME_ListIterName = "ListIter";
   public static final String PNAME_ListNullValueFlag = "NullValueFlag";

   
   public JUCtrlListDef()
   {
   }


   public JUCtrlListDef(String name, String controlClassName,
                        String controlBindingClassName, String iterBindingName,
                        String[] attrNames, boolean staticList,
                        String listVOName, String listRSIName, String[] listAttrNames,
                        Object[] valueList)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName, attrNames);

      mStaticList = staticList;
      mListVOName = listVOName;
      mListRSIName = listRSIName;
      mListAttrNames = listAttrNames;
      mValueList = valueList;
   }

   protected void initSubType()
   {
      setSubType(PNAME_ListSingleSel);
   }
   
   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;

      if ((val = initValues.get(PNAME_ListOperMode)) != null)
      {
         mListOperMode = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_StaticList)) != null)
      {
         mStaticList = convertToBoolean(val);
      }
      
      if ((val = initValues.get(PNAME_ListIterName)) != null)
      {
         mListIterName = val.toString();
      }

      if ((val = initValues.get(PNAME_ListVOName)) != null)
      {
         mListVOName = val.toString();
      }

      if ((val = initValues.get(PNAME_ListRSIName)) != null)
      {
         mListRSIName = val.toString();
      }

      if ((val = initValues.get(PNAME_ListAttrNames)) != null)
      {
         mListAttrNames = (String[]) val;
      }

      if ((val = initValues.get(PNAME_ListDisplayNames)) != null)
      {
         mListDisplayAttrNames = (String[]) val;
      }

      if ((val = initValues.get(PNAME_ListRangeSize)) != null)
      {
         mListRangeSize = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_ValueList)) != null)
      {
         mValueList = (Object[]) val;
      }
      
      if ((val = initValues.get(PNAME_LabelList)) != null)
      {
         mLabelList = (String[]) val;
      }
      
      if ((val = initValues.get(PNAME_ListNullValueFlag)) != null)
      {
         mNullValueFlag = convertToInt(val);
      }

   }

   
   public int getListOperMode()
   {
      return mListOperMode;
   }

   
   public void setListOperMode(int listOperMode)
   {
      mListOperMode = listOperMode;
   }
   

   public boolean isStaticList()
   {
      return mStaticList;
   }


   public int getNullValueFlag()
   {
      if (mListOperMode != JUCtrlListBinding.LIST_OPER_NAVIGATE
          && mNullValueFlag == JUCtrlListBinding.LIST_ADD_NULL_UNINIT)
      {
         mNullValueFlag = JUCtrlListBinding.LIST_ADD_NULL_NOWHERE;
      }
      return mNullValueFlag;
   }

   String initializeNullValue(DCBindingContainer bc)
   {
      //what about display label stuff = perhaps that should be used?
      if (isStaticList() //getNullValueId() == null 
          && ( mNullValueFlag > JUCtrlListBinding.LIST_ADD_NULL_NOWHERE)) 
      {
         String[] labelList = getLabelList();
         Object[] displayArr = (labelList != null && labelList.length > 0) ? labelList : getValueList();
         Object nullValueObj = null;
         if (displayArr != null && displayArr.length > 0) 
         {
            nullValueObj = ((mNullValueFlag == JUCtrlListBinding.LIST_ADD_NULL_AT_START)
                       ? displayArr[0] 
                       : displayArr[displayArr.length -1]);
            setNullValueObject(nullValueObj);
         }
         return (nullValueObj != null) ? nullValueObj.toString() : null;
      }
      return super.initializeNullValue(bc);
   }


   /*
   protected void setNullValueProperties(int flag, Object nullValue)
   {
      if (mListOperMode != JUCtrlListBinding.LIST_OPER_NAVIGATE) 
      {
         switch (flag) 
         {
         case JUCtrlListBinding.LIST_ADD_NULL_NOWHERE:
            mNullValueFlag = flag;
            break;
         case JUCtrlListBinding.LIST_ADD_NULL_AT_END:
         case JUCtrlListBinding.LIST_ADD_NULL_AT_START:
            mNullValueFlag = flag;
            break;

         default:
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Ignoring improper flag sent in for setNullValueFlag."); 
            }
         }
      }
      else
      {
         Diagnostic.println("Ignoring improper flag sent in for setNullValueFlag for navigation list."); 
      }
   }
   */

   /**
    * *** For internal framework use only ***
    */
   public void setStaticList(boolean staticList)
   {
      mStaticList = staticList;
   }

   public String getListIteratorBindingName()
   {
      return mListIterName;
   }

   
   public String getListVOName()
   {
      return mListVOName;
   }

   
   public String getListRSIName()
   {
      return mListRSIName;
   }


   public String[] getListAttrNames()
   {
      return mListAttrNames;
   }
   
   public String[] getListDisplayAttrNames()
   {
      return mListDisplayAttrNames;
   }
   

   public int getListRangeSize()
   {
      return mListRangeSize;
   }

   
   public void setListRangeSize(int listRangeSize)
   {
      mListRangeSize = listRangeSize;
   }

   
   public Object[] getValueList()
   {
      return mValueList;
   }
   
   public String[] getLabelList()
   {
      return mLabelList;
   }
   
   protected DCIteratorBinding findListIteratorBinding(DCBindingContainer formBinding)
   {
      return (mListIterName == null) 
             ? formBinding.getIteratorBinding(mListVOName, mListRSIName, null, mListRangeSize)
             : formBinding.findIteratorBinding(mListIterName);
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLInt(xmlElement, PNAME_ListOperMode, valueTab);
      readXMLBoolean(xmlElement, PNAME_StaticList, valueTab);
      readXMLInt(xmlElement, PNAME_ListNullValueFlag, valueTab);

      mStaticList = false;
      Object val;
      if ((val = valueTab.get(PNAME_StaticList)) != null)
      {
         mStaticList = convertToBoolean(val);
      }
      
      if (!mStaticList)
      {
         readXMLString(xmlElement, PNAME_ListIterName, valueTab);
         readXMLString(xmlElement, PNAME_ListVOName, valueTab);
         readXMLString(xmlElement, PNAME_ListRSIName, valueTab);
         readXMLInt(xmlElement, PNAME_ListRangeSize, valueTab);
      }
   }

   
   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(2);
      Object val;
         
      if (isStaticList())
      {
         readXMLStringArray(xmlElement, PNAME_ValueList, valueTab);
         readXMLStringArray(xmlElement, PNAME_LabelList, valueTab);
      }
      else
      {
         readXMLStringArray(xmlElement, PNAME_ListAttrNames, valueTab);
         readXMLStringArray(xmlElement, PNAME_ListDisplayNames, valueTab);
      }

      init(valueTab);
   }

   
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    int listOperMode)
   {
     return new JUCtrlListBinding(control, iterBinding, attrNames, listOperMode);
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    Object[] valueList)
   {
     return new JUCtrlListBinding(control, iterBinding, attrNames, valueList);
   }
    
   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    DCIteratorBinding listIterBinding,
    String[] listAttrNames,
    String[] listDisplayAttrNames)
   {
     return new JUCtrlListBinding(control, iterBinding, attrNames, 
       listIterBinding, listAttrNames, listDisplayAttrNames);
   }
   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      JUCtrlListBinding jListBnd = null;
      DCIteratorBinding iterBnd = getIterBinding(formBnd);
      
      if (getListOperMode() == JUCtrlListBinding.LIST_OPER_NAVIGATE)
      {
         jListBnd = createListBindingInstance(control, iterBnd, getAttrNames(), JUCtrlListBinding.LIST_OPER_NAVIGATE);
      }
      else 
      {
         if (isStaticList())
         {
            Object[] valueList = getValueList();
            String[] labelList = getLabelList();
            
            jListBnd = createListBindingInstance(control, iterBnd, getAttrNames(), valueList);

            if (mNullValueFlag > JUCtrlListBinding.LIST_ADD_NULL_NOWHERE)
            {   
               jListBnd.setNullValueProperties(mNullValueFlag);
            }
            jListBnd.setListDisplayAttrNames(labelList);
         }
         else
         {
            jListBnd = createListBindingInstance(control, 
                                                 iterBnd, 
                                                 getAttrNames(),
                                                 findListIteratorBinding(formBnd), 
                                                 getListAttrNames(), 
                                                 getListDisplayAttrNames());
            
            if (mNullValueFlag > JUCtrlListBinding.LIST_ADD_NULL_NOWHERE)
            {   
               jListBnd.setSingleAttrList(false);
               jListBnd.setNullValueProperties(mNullValueFlag);
            }
         }
      }
         

      return jListBnd;
   }
}
