/*
 * @(#)JUCtrlRangeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import oracle.adf.model.RangeBinding;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCDataControl;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttrValException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.ScrollEvent;
import oracle.jbo.common.DebugDiagnostic;

/**
 * A JUControlBinding class responsible for binding controls/models
 * that are bound to a range of Row objects in the BC4J layer.
 * This class:
 * <ul>
 * <li>Is responsible for updating the Control Bindings with attribute values
 * from the BC4J Row objects for all attributes that this Control Binding is bound to
 * by calling setValueAt() method for each attribute value with approprate row, column and
 * value information.
 * <li>Declares (abstract) methods that all subclasses need to implement
 * to handle Scroll and Navigation events from the BC4J RowIterator.
 * </ul>
 *
 * @javabean.class name=JUCtrlRangeBinding
 */
public class JUCtrlRangeBinding extends JUCtrlValueBinding implements RangeBinding
{

   //variables for use in the RangeSet wrapper.
   Row[] currentSet;
   JUCtrlValueBindingRef[] currentSetRef;
   JUCtrlRangeBinding thisObj;

   //Map mLabelsMap = null;

   /**
   * This constructor passes on the control, iterator, and attribute binding information
   * to its super.
   */
   public JUCtrlRangeBinding(Object control, DCIteratorBinding iterBinding, String[] attrNames)
   {
      super(control, iterBinding, attrNames);
   }

   /**
    * @deprecated since 10.1.2
    */
   public Object getValueAt(int rowIndex, int attrIndex)
   {
      return getAttribute(attrIndex);
   }

   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
   }

   /**
    * @deprecated since 10.1.2
    */
   public void setValueAt(Object value, int rowIndex, int attrIndex)
   {
      //not implemented.
   }

   /**
    ** @javabean.property 
    **/
   public int getRangeStart()
   {
      DCIteratorBinding iter = getIteratorBinding();
      return (iter.hasRSI()) ? iter.getNavigatableRowIterator().getRangeStart() : 0;
   }

   /**
    ** @javabean.property 
    **/
   public int getRangeSize()
   {
      DCIteratorBinding iter = getIteratorBinding();
      return (iter.hasRSI()) ? iter.getNavigatableRowIterator().getRangeSize() : 0;
   }

   /**
   * Returns the number of rows in the collection defined by the
   * associated ViewObject's query (if this control is in data display mode).
   * If this control is in find mode, returns the number of rows in the 
   * associated ViewCriteria object.
   *
   * @javabean.property
   */
   public long getEstimatedRowCount()
   {
      return (getIteratorBinding() != null) ? getIteratorBinding().getEstimatedRowCount() : 0;
   }

   public int getCurrentRowIndex()
   {
      DCIteratorBinding iter = getIteratorBinding();
      return (iter.hasRSI()) ? iter.getNavigatableRowIterator().getCurrentRowIndex() : 0;
   }

   public void setCurrentRowAtIndex(int rowIndex)
   {
      DCIteratorBinding iter = getIteratorBinding();
      if (iter.hasRSI()) 
      {
         iter.getNavigatableRowIterator().setCurrentRowAtRangeIndex(rowIndex);
      }
   }

   Map mInputMap;

   class InputEntry
   {
      String mAttributeName;
      Object mInputValue;
   }

   class RowInputEntry
   {
      InputEntry[] mAttributeEntry;
      List mErrors;
      RowInputEntry(int count)
      {
         mAttributeEntry = new InputEntry[count];
      }
   }


   
   void setError(JboException jex, Object value, boolean reportException)
   {
      if (mInputMap != null && jex instanceof AttrValException)
      {
         AttrValException vex = (AttrValException)jex;
         Key k = vex.getRowKey();
         RowInputEntry rowInput = (RowInputEntry)mInputMap.get(k);
         if (rowInput == null) 
         {
            rowInput = new RowInputEntry(getAttributeCount());
            mInputMap.put(k, rowInput);
         }
         if (rowInput.mErrors == null) 
         {
            rowInput.mErrors = new ArrayList(4);
         }
         List al = rowInput.mErrors;
         if (!al.contains(vex)) 
         {
            al.add(vex);
         }
         //NEED TO RESET THE ATTRIBUTE EXCEPTION in row.
         oracle.jbo.RowIterator ri = getIteratorBinding().getNavigatableRowIterator();
         Row rows [] = ri.findByKey(k, -1);
         if (rows != null && rows.length >= 1) 
         {
            resetAttributeExceptionInRow(rows[0], 
                                         getAttributeDef(getAttributeIndexOf(vex.getAttrName())), 
                                         vex);
         }
      }
      super.setError(jex, value, reportException);
   }

   protected List getInputErrorsForRowKey(Key key)
   {
      if (mInputMap != null) 
      {
         RowInputEntry rowEntry = (RowInputEntry)mInputMap.get(key);
         if (rowEntry != null) 
         {
            return rowEntry.mErrors;
         }
      }
      return null;
   }

   protected Object getInputValueInRow(JUCtrlValueBinding binding, Row row, AttributeDef ad) 
   {
      if (mInputMap != null) 
      {
         Key k = row.getKey();
         RowInputEntry rowEntry = (RowInputEntry)mInputMap.get(k);
         int index = getAttributeIndexOf(ad.getName());
         if (rowEntry != null && index > -1) 
         {
            if (rowEntry.mAttributeEntry[index] != null) 
            {
               return rowEntry.mAttributeEntry[index].mInputValue;
            }
         }
      }
      return super.getInputValueInRow(binding, row, ad);
   }

   protected void setInputValueInRow(JUCtrlValueBinding binding, Row row, AttributeDef ad, Object value, boolean handleException)
   {
      if (mInputMap == null) 
      {
         mInputMap = new HashMap(10);
      }
      Key k = null;
      RowInputEntry rowEntry = null;
      if (row != null) 
      {
         k = row.getKey();
         rowEntry = (RowInputEntry)mInputMap.get(k);
         if (rowEntry == null) 
         {
            rowEntry = new RowInputEntry(getAttributeCount());
            mInputMap.put(k, rowEntry);
         }

         InputEntry entry = new InputEntry();
         entry.mAttributeName = ad.getName();
         entry.mInputValue = value;
         rowEntry.mAttributeEntry[getAttributeIndexOf(ad.getName())] = entry;
      }
      try
      {
         //cache this exception.
         super.setInputValueInRow(binding, row, ad, value, true);
      }
      finally
      {
         if (k != null && rowEntry != null) 
         {
            if (!k.equals(row.getKey()))
            {
               mInputMap.remove(k);
               mInputMap.put(row.getKey(), rowEntry);
            }
         }
      }
   }


   /**
   * This method is called in the framework when values of a single row need to be 
   * updated in a control (typically on a navigation event). 
   */
   public void updateValuesFromRow(Row row)
   {
      updateValuesFromRows(new Row[] { row }, false /*clear*/);
   }
   
   /**
    * Returns a list of Map elements over the range of rows from the associated iterator binding.
    * The elements in this list are wrapper objects over the indexed row in the range that
    * restricts access to only the attributes that this control-binding is bound to.
    * The map exposes the following properties for each row in the range:
    * <li><code>index</code> - returns Range Index of the row</li>
    * <li><code>key</code>  - returns Key of the row</li>
    * <li><code>keyStr</code> - returns String format of the key of the row at this index()</li>
    * <li><code>currencyString</code> - if this row is the current row, returns * else returns a space " ".</li>
    * <li><code>attributeValues</code> - returns array of attribute
    * values for attributes that are bound in this rangeBinding from
    * the row</li>
    *
    * @javabean.property
    */
   public List getRangeSet()
   {
      //perhaps these two range variables can be cached and cleanedup in rangeRefeshed?

     currentSet = getAllRowsInRange();
     thisObj = this;
     if (currentSet != null)
     {
        currentSetRef = new JUCtrlValueBindingRef[currentSet.length];
        if (getRowIterator().getCurrentRowSlot() != oracle.jbo.RowIterator.SLOT_VALID)
        {
           if(currentSet.length > 0)
           {
              DebugDiagnostic.println("Setting currency to first row in range Index");
              getRowIterator().setCurrentRowAtRangeIndex(0);
           }
        }

        return new java.util.AbstractList()
        {
           public Object get(int i)
           {
              if (i < currentSet.length && currentSetRef[i] == null)
              {
                 currentSetRef[i] = createValueBindingRef(thisObj, i, currentSet[i]);
              }
              return currentSetRef[i];
           }

           public int size()
           {
              return currentSet.length;
           }
        };
     }
     return null;
   }

   protected JUCtrlValueBindingRef createValueBindingRef(
    JUCtrlRangeBinding rangeBinding,
    int index,
    Row row)
   {
     return new JUCtrlValueBindingRef(rangeBinding, index, row);
   }

   /**
   * This method is invoked in the framework to update values displayed in the associated 
   * control. This implementation updates all values given in the array of rows irrespective
   * of the clear flag (which indicates whether to clear out the existing displayed values or not).
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {

      if (clear) 
      {
         //incase of rangeRefreshed event, recreate the inputMap
         //for new set of rows.
         mInputMap = null;
      }
      if (mAttributeListener != null)
      {
         mAttributeListener.updateRenderer();
      }
      else
      {
         int ct = getAttributeCount();
         if (rows != null)
         {
            int rCt = rows.length;

            Row r;
            for (int i = 0; i < rCt; i++)
            {
               r = rows[i];
               for (int j = 0; j < ct; j++)
               {
                  Object value = getAttributeFromRow(r, j);
                  setValueAt(value, i, j);
               }
            }
         }
      }
   }

   
   /**
   * Method to handle scroll events from the BC4J iterator. Subclasses need to implement
   * this method to update the currently displayed rowset (if desired).
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
      if (mAttributeListener != null)
      {
         mAttributeListener.updateRenderer();
      }
   }


   /**
   * Method to handle Navigation event from the BC4J iterator. Subclasses need to implement
   * this method to update their current row display (if desired).
   */
   public void updateNavigated(NavigationEvent event)
   {
      if (mAttributeListener != null)
      {
         mAttributeListener.updateRenderer();
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      if (getRowIterator() == null)
         return;

      currentSet = null;
      currentSetRef = null;
      
      if (getRowIterator().getCurrentRowSlot() == oracle.jbo.RowIterator.SLOT_VALID)
      {
         updateValuesFromRows(getAllRowsInRange(), false);
      }
   }
   
   /**
   * Empty method to support DCControlBinding contract.
   **/
   //protected void resetInputState()
   //{
   //}

   private final String ATTR_RANGE_SIZE = "rangeSize";
   private final String ATTR_RANGE_START = "rangeStart";
   private final String ATTR_RANGE_SET = "rangeSet";
   private final String ATTR_EST_ROW_COUNT = "estimatedRowCount";
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>rangeSet</code> - returns getRangeSet()</li>
    * <li><code>estimatedRowCount</code>  - returns getEstimatedRowCount()</li>
    */
   protected Object internalGet(String key)
   {
      key = key.intern();
      if (key == ATTR_RANGE_SET)
      {
         mInternalGet_KeyResolved = true;
         return getRangeSet();
      }
      if (key == ATTR_EST_ROW_COUNT)
      {
         mInternalGet_KeyResolved = true;
         return new Long(getEstimatedRowCount());
      }
      if (key == ATTR_RANGE_SIZE)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getRangeSize());
      }
      if (key == ATTR_RANGE_START)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getRangeStart());
      }
      return super.internalGet(key);
   }

   /*
   public Map getLabels()
   {
      //do not cache the labels for cases where one has to fetch
      //it again due to change in locale. 
      if (mLabelsMap == null)
      {
         mLabelsMap = super.getLabels();
      }
      return mLabelsMap;
   }
   */

   public void release(int flags)
   {
      // lets just clean it in both view/data cases as next time we come in, we
      // do need to re-establish the list anyway.
      if ((flags < 0)
         || ((flags & DCDataControl.REL_ALL_REFS) > 0)
         || ((flags & DCDataControl.REL_DATA_REFS) > 0))
      {
         currentSet = null;
         currentSetRef = null;
      }

      mInputMap = null;

      super.release(flags);
   }

   //needs to fetch estimated row count eagerly.
   protected boolean needsEstimatedRowCount()
   {
      return true;
   }

   protected void setRangeStart(int x)
   {
      getIteratorBinding().setRangeStart(x);
   }
}

