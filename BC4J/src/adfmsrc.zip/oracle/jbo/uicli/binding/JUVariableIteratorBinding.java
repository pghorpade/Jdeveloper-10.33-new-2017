/*
 * @(#)JUVariableIteratorBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.BindingContext;

import oracle.jbo.common.Diagnostic;

import oracle.jbo.AttributeDef;
import oracle.jbo.Key;
import oracle.jbo.StructureDef;
import oracle.jbo.Variable;
import oracle.jbo.VariableManagerOwner;
import oracle.jbo.VariableValueManager;
import oracle.jbo.common.VariableValueManagerImpl;


import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 *
 * @javabean.class name=JUVariableIteratorBinding
 */

class JUVariableIteratorBinding 
      extends JUIteratorBinding 
      implements VariableManagerOwner
{
   private VariableValueManager mVariableManager = null;
   static final String GET_VariableManager = "variableManager"; //NONLS
   private Row mRow;
   private StructureDef mStructureDef;
   private JUVariableIteratorBinding thisIter = this;

   JUVariableIteratorBinding(BindingContext ctx, DCBindingContainer bc)
   {
      super(ctx, null, null, null, 1);
      super.setRowSetEventsEnabled(false);
      super.setAllowFindMode(false);
   }

   public void bindRowSetIterator(oracle.jbo.NavigatableRowIterator iter, boolean initRangeSize)
   {
      //noop
   }

   public void executeQueryIfNeeded()
   {
   }

   public void executeQuery()
   {
      //reset all the variable values.
   }
   /**
    *
    * @javabean.property
    */
   public boolean isOperationSupported(byte oper)
   {
      switch (oper) 
      {
      case DCDataControl.OPER_DATA_ROW_UPDATE:
      case DCDataControl.OPER_CTRL_BINDING_VALIDATION:
      case DCDataControl.OPER_EXECUTE:
         return true;
      }
      return false;
   }
  /**
   *
   * @javabean.property
   */
   public String getVOName()
   {
      return null;
   }
  /**
   *
   * @javabean.property
   */
   public String getSourceName()
   {
      return null;
   }

   public void resolveRangeSize(int rangeSize)
   {
      //noop.
   }
  /**
   *
   * @javabean.property
   */
   public ViewObject getViewObject()
   {
      return null;
   }

   public void refresh(int id)
   {
      Row r = getCurrentRow();
      updateValuesFromRows(new Row[]{r}, r, false);
   }

   public boolean isRefreshed()
   {
      return true;
   }

   public boolean hasRefreshParametersChanged()
   {
      //always refresh the variablesIterator
      //so that UIs can be updated.
      return true;
   }


   /**
   * @internal *** For internal framework use only *** 
    */
   public boolean allowsRefreshControl()
   {
      return true;
   }

   protected RowSetIterator initSourceRSI()
   {
      return null;
   }
  /**
   *
   * @javabean.property
   */
   public AttributeDef[] getAttributeDefs()
   {
      return ensureVariableManager().getVariables();
   }

   public AttributeDef[] getAttributeDefs(String[] attrNames)
   {
      // bug 4904563 - this was only returning the first match.  seems
      // wrong.  updated to return an array.
      if (attrNames != null)
      {
         int numVars = attrNames.length;
         if (numVars > 0)
         {
            ArrayList matchingVars = new ArrayList(attrNames.length);
            for (int j = 0; j < numVars; j++)
            {
               Variable var =
               ensureVariableManager().lookupVariable(attrNames[j]);
               if (var != null)
               {
                  matchingVars.add(var);
               }
            }

            if (matchingVars.size() > 0)
            {
               AttributeDef[] matchingDefs = new
               AttributeDef[matchingVars.size()];
               return (AttributeDef[])matchingVars.toArray(matchingDefs);
            }
         }
      }
      return null; 
   }

   protected Object internalGet(String key)
   {
      key = key.intern();
      Object ret = null;

      if (key == GET_VariableManager)
      {
         mInternalGet_KeyResolved = true;
         ensureVariableManager();
         return getVariableManager();
      }
      return super.internalGet(key);
   }

   public final boolean hasVariables()
   {
      return (mVariableManager != null || (((JUVariableIteratorDef)getDef()).hasVariables()));
   }
  /**
   *
   * @javabean.property
   */
   public final VariableValueManager getVariableManager()
   {
      if (((JUVariableIteratorDef)getDef()).hasVariables())
      {
         //make sure that if this variablemanager has declared variables
         //that they are in this instance as well.
         ensureVariableManager();
      }
      return mVariableManager;
   }

   public final VariableValueManager ensureVariableManager()
   {
      if (mVariableManager == null)
      {
         mVariableManager = ((JUVariableIteratorDef)getDef()).createVariableValueManager(this, getBindingContainer());
      }

      return mVariableManager;
   }
  /**
   *
   * @javabean.property
   */
   public final Class getMessageBundleClass()
   {
      return ((JUVariableIteratorDef)getDef()).getMessageBundleClass();
   }

   public void releaseData()
   {
      invalidateCache();
   }

   public void invalidateCache()
   {
      //let the variable manager be rebuilt and values set on it again.
      mVariableManager = null; 

      super.invalidateCache();
   }

   public void release(int flags)
   {
      //let the variable manager be rebuilt and values set on it again
      mVariableManager = null;
      super.release(flags);
   }


   protected Row internalGetCurrentRowInBinding()
   {
      if (mVariableManager == null) 
      {
         return null;
      }
      if (mRow == null) 
      {
         mStructureDef = new StructureDef()
         {
            public String getName()
            {
               return thisIter.getName();
            }

            public String getFullName()
            {
               return getName();
            }
            
            public String getDefName()
            {
               return thisIter.getDef().getName();
            }

            public String getDefFullName()
            {
               return thisIter.getDef().getFullName();
            }

            public AttributeDef[] getAttributeDefs()
            {
               return mVariableManager.getVariables();
            }

            public int getAttributeCount()
            {
               return mVariableManager.getVariableCount();
            }
            
            public AttributeDef findAttributeDef(String name)
            {
               return mVariableManager.findVariable(name);
            }

            public AttributeDef lookupAttributeDef(String name)
            {
               return mVariableManager.lookupVariable(name);
            }
            
            public AttributeDef getAttributeDef(int index)
            {
               return mVariableManager.getVariables()[index];
            }

            public int getAttributeIndexOf(String name)
            {
               AttributeDef[] defs = getAttributeDefs();
               for (int i = 0; i < defs.length; i++) 
               {
                  if (defs[i].getName().equals(name)) 
                  {
                     return i;
                  }
               }
               return -1;
            }
         };


         mRow = new Row()
         {
            public Object getAttribute(int index)
            {
               return mVariableManager.getVariableValue(mVariableManager.getVariables()[index]);
            }
         
            public Object getAttribute(String name)
            {
               return mVariableManager.getVariableValue(name);
            }
            
            public boolean isAttributeUpdateable(int index)
            {
               return (mStructureDef.getAttributeDef(index).getUpdateableFlag() != AttributeDef.READONLY);
            }
         
            public boolean isDead()
            {
              return false;
            }
            
            public StructureDef getStructureDef()
            {
               return mStructureDef;
            }
            
            public void setAttribute(int index, Object value)
            {
               mVariableManager.setVariableValue(mVariableManager.getVariables()[index], value);
            }
   
            public void setAttribute(String name, Object value)
            {
               mVariableManager.setVariableValue(name, value);
            }
            
            public int getAttributeCount()
            {
               return getStructureDef().getAttributeCount();
            }
            
            public int getAttributeIndexOf(String name)
            {
               return getStructureDef().getAttributeIndexOf(name);
            }
            
            public String[] getAttributeNames()
            {
               return null;
            }
            
            public Object[] getAttributeValues()
            {
               return mVariableManager.getVariableValues(mVariableManager.getVariables());
            }
            
            public ApplicationModule getApplicationModule()
            {
               return null;
            }
            
            public Key getKey()
            {
               return null;
            }
         
            public void validate()
            {
            }
         
            public void revert()
            {
            }
         
            public void refresh(int refreshMode)
            {
            }
         
            public void lock()
            {
            }
            
            public void remove()
            {
               throw new UnsupportedOperationException("remove()");
            }
            
         
            public void removeFromCollection()
            {
               throw new UnsupportedOperationException("removeFromCollection()");
            }
            
         
            public void removeAndRetain()
            {
               throw new UnsupportedOperationException("removeAndRetain()");
            }
            
         
            public Node writeXML(long options, com.sun.java.util.collections.HashMap voAttrMap)
            {
               throw new UnsupportedOperationException("writeXML()");
            }
         
            
            public Node writeXML(int depthCount, long options)
            {
               throw new UnsupportedOperationException("writeXML()");
            }
         
            
            public void readXML(Element elem, int depthCount)
            {
               throw new UnsupportedOperationException("readXML()");
            }
         
            
            public Node writeXML(long options, com.sun.java.util.collections.HashMap voAttrMap, oracle.xml.parser.v2.XSLStylesheet xslt)
            {
               throw new UnsupportedOperationException("writeXML()");
            }
         
            
            public Node writeXML(int depthCount, long options, oracle.xml.parser.v2.XSLStylesheet xslt)
            {
               throw new UnsupportedOperationException("writeXML()");
            }
         
            
            public void readXML(Element elem, int depthCount, oracle.xml.parser.v2.XSLStylesheet xslt)
            {
               throw new UnsupportedOperationException("readXML()");
            }
         
            public void setNewRowState(byte state)
            {
               //noop.
            }
         };
      }
      return mRow;
   }
}
