/*
 * @(#)JUUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.CustomClassNotFoundException;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;

import oracle.adf.model.BindingContext;
import java.util.ArrayList;

/**
 * Contains some static utility methods used by the framework.
 */
public class JUUtil
{
	static public String PROJECT_GLOBAL_VARIABLES = "PROJECT_GLOBAL_VARIABLES";
   /**
   * *** For internal framework use only ***
   */
   static public Class findClass(String className)
   {
      try
      {
         return JBOClass.forName(className);
      }
      catch(Exception e)
      {
         DebugDiagnostic.println("Could not load class: " + className);
         DebugDiagnostic.printStackTrace(e);
         throw new CustomClassNotFoundException(className, e);
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public Object createNewInstance(String className)
   {
      Class cls = findClass(className);

      try
      {
         return cls.newInstance();
      }
      catch(Exception e)
      {
         DebugDiagnostic.println("Could not create an instance: " + className);
         DebugDiagnostic.printStackTrace(e);
         throw new CustomClassNotFoundException(className, e);
      }
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public String generateFormName(JUFormBinding formBnd)
   {
      String className;
      Object panel = formBnd.getPanel();

      if (panel != null)
      {
         className = panel.getClass().getName();
      }
      else
      {
         className = "noPanel_" + formBnd.getClass().getName();
      }

      return JboNameUtil.getInstNameFromDefName(className);
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public String generateIteratorName(JUIteratorBinding iterBnd)
   {
      String className;

      className = iterBnd.getClass().getName();

      return JboNameUtil.getInstNameFromDefName(className);
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public String generateControlName(JUControlBinding controlBnd)
   {
      String className;
      Object control = controlBnd.getControl();

      if (control != null)
      {
         className = control.getClass().getName();
      }
      else
      {
         className = "noCtrl_" + controlBnd.getClass().getName();
      }

      return JboNameUtil.getInstNameFromDefName(className);
   }

   
   /**
   * *** For internal framework use only ***
   */
   static public boolean isEmptyString(String s)
   {
      return (s == null || s.equals(""));
   }
   
   static public void registerNavigationBarInterface(JUFormBinding formBinding, BindingContext bindCtx)
   {
   	ArrayList varList = (ArrayList)bindCtx.get(PROJECT_GLOBAL_VARIABLES);
   	
      if (varList == null || varList.size() == 0)
   	{
         return;
   	}
   	
      for (int i = 0;i < varList.size();i++)
   	{
         Object obj = varList.get(i);
         if (obj instanceof JUNavigationBarInterface)
         {
       		formBinding.addNavigationBar((JUNavigationBarInterface)obj);
         }
   	}
   }
   
   static public void registerStatusBarInterface(JUFormBinding formBinding, BindingContext bindCtx)
   {
   	ArrayList varList = (ArrayList)bindCtx.get(PROJECT_GLOBAL_VARIABLES);
   	
      if (varList == null || varList.size() == 0)
   	{
         return;
   	}
   	
      for (int i = 0;i < varList.size();i++)
   	{
         Object obj = varList.get(i);
         if (obj instanceof JUStatusBarInterface)
         {
       		formBinding.addStatusBarInterface((JUStatusBarInterface)obj);
         }
   	}
   }
   
   static public void unRegisterNavigationBarInterface(JUFormBinding formBinding, BindingContext bindCtx)
   {
   	ArrayList varList = (ArrayList)bindCtx.get(PROJECT_GLOBAL_VARIABLES);
   	
   	if (varList == null || varList.size() == 0)
   	{
         return;
   	}
   	
   	for (int i = 0;i < varList.size();i++)
   	{
   		Object obj = varList.get(i);
         if (obj instanceof JUNavigationBarInterface)
         {
       		formBinding.removeNavigationBar((JUNavigationBarInterface)obj);
         }
   	}
   }
   
   static public void unRegisterStatusBarInterface(JUFormBinding formBinding, BindingContext bindCtx)
   {
   	ArrayList varList = (ArrayList)bindCtx.get(PROJECT_GLOBAL_VARIABLES);
   	
   	if (varList == null || varList.size() == 0)
   	{
         return;
   	}
   	
   	for (int i = 0;i < varList.size();i++)
   	{
   		Object obj = varList.get(i);
         if (obj instanceof JUStatusBarInterface)
         {
       		formBinding.removeStatusBarInterface((JUStatusBarInterface)obj);
         }
   	}
   }
   
}
