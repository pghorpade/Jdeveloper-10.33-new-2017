/* $Header: JUCtrlListBindingChangeListener.java 25-jul-2006.12:52:37 pillanch Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Listener interface used to publish changes from JUCtrlListBinding

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    pillanch     07/25/06 - Creation
 */

package oracle.jbo.uicli.binding;

/**
 * Implementers of this interface can register with a JUCtrlListBinding
 * to be notified about events.
 * 
 *  @version $Header: JUCtrlListBindingChangeListener.java 25-jul-2006.12:52:37 pillanch Exp $
 *  @author  pillanch 
 *  @since   10.1.3
 */
public interface JUCtrlListBindingChangeListener 
{
  /**
    * This method will be called by the JUCtrlListBinding when a lookup is 
    * performed and the value is not found in the binding list.
    * This may occur when the UI allows free editing in a combobox; this
    * method can be used to validate the value and update the binding list.
    * @param event 
    */
  public void valueNotFound(JUCtrlListBindingChangeEvent event);   
}
