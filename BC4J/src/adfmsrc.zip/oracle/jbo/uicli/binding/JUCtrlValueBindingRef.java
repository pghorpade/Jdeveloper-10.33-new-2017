/*
 * @(#)JUCtrlValueBindingRef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.adf.model.binding.DCControlBinding;
import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.common.JboAbstractMap;

import oracle.adf.model.AttributesBinding;
import oracle.adf.model.UpdateListener;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

/**
 * The base class for all binding objects in the JClient framework that bind
 * a Swing control/model to a BC4J attribute(s). This class manages:
 * <ul>
 * <li>The references to the Swing control
 * <li>The IteratorBinding with which the binding object is in association
 * <li>The form binding that this binding belongs to
 * <li>The internal-state for findMode
 * </ul>
 * <p>
 * This class also implements helper methods to access BC4J objects like the Transaction,
 * the current Application Module, the ViewObject that this control binding is working with,
 * the current RowIterator, the current Row in the iterator that this control binding
 * is associated with. It also provides methods to execute the ViewObject behind this again (optionally).
 */
public class JUCtrlValueBindingRef extends JboAbstractMap implements AttributesBinding
{
   /**
    * Allows access to this references row-index in the current range set.
   */
   public static final String RANGESET_INDEX = "index";
   /**
    * Allows access to the key for the row referred to by this reference object.
   */
   public static final String RANGESET_ROW_KEY = "rowKey";

   /**
    * Allows access to the String form of the key for the row referred to by this reference object.
   */
   public static final String RANGESET_ROW_KEY_STR = "rowKeyStr";

   /**
    * Allows access to the key-attribute value for the row referred to by this reference object.
    * This assumes that this row type has only one attribute marked as key attribute.
   */
   public static final String RANGESET_ROW_KEY_VALUE = "keyValue";

   /**
    * accesses a String representation for web UIs to indicate if this refers to a current row.
   */
   public static final String RANGESET_CURRENCY_STRING = "currencyString";

   public static final String RANGESET_LABEL_SET = JUCtrlValueBinding.ATTR_LABELSET;

   /**
    * accesses the underlying row that this reference object is bound to.
   */
   public static final String RANGESET_ROW = "row";

   /**
    * accesses the bean in the underlying row that this reference object is bound to
    * incase of non bc4j datacontrols.
   */
   public static final String RANGESET_ROW_DATA_PROVIDER = "dataProvider";

   /**
    * accesses the underlying row that this reference object is bound to.
   */
   public static final String RANGESET_BASE_BINDING = "binding";

   /**
    * accesses the underlying row that this reference object is bound to.
   */
   //public static final String RANGESET_DATA_PROVIDER = "dataProvider";

   /**
    * String value returned from getCurrencyString if this row is not current
    */
   //due to use of cout this string gets printed as is.
   //public final String STR_NOT_CURRENT_ROW = "&nbsp;";
   public final String STR_NOT_CURRENT_ROW = " ";

   /**
    * String value returned from getCurrencyString if this row is current
    */
   public final String STR_CURRENT_ROW = "*";

   JUCtrlValueBinding mBinding;
   int mIndex = -1;
   Key mRowKey;
   WeakReference mRowRef;


   protected JUCtrlValueBindingRef(JUCtrlValueBinding binding, int index, Row row)
   {
      mBinding = binding;
      mIndex   = index;
      if (row != null)
      {
         mRowKey = row.getKey();
      }
      mRowRef = new WeakReference(row);
   }

   public String getName()
   {
      return (new StringBuffer(mBinding.getName()).append((new Integer(mIndex)).toString())).toString();
   }

   /**
   **@javabean.property 
   */
  public JUCtrlValueBinding getBinding()
  {
    return mBinding;
  }


  /**
  **@javabean.property 
  */
  public Row getRow()
  {
    return (Row)mRowRef.get();
  }
   /**
    * @return "*" if this refers to a current row otherwise returns "&nbsp;".
    **@javabean.property 
   */
   public String getCurrencyString()
   {
      Row curRow = mBinding.getCurrentRow();
      if (curRow != null  && mRowKey != null)
      {
         return (mRowKey.equals(curRow.getKey())) ? STR_CURRENT_ROW : STR_NOT_CURRENT_ROW;
      }
      return STR_NOT_CURRENT_ROW;
   }

   /**
    * Changes the currency to the row represented by this valu binding reference
    */
   public void makeCurrentRow()
   {
      Row row = getRow();
      mBinding.getDCIteratorBinding().setCurrentRowWithKey(row.getKey().toStringFormat(true));
   }
   /**
   * Properties returned via getter on this reference object are:
   * <li><code>index</code> - returns Range Index of the row this reference is pointing to</li>
   * <li><code>key</code>  - returns Key of the row this reference is pointing to</li>
   * <li><code>rowKeyStr</code> - returns String format of the key of the row this reference is pointing to()</li>
   * <li><code>keyValue</code> - returns the attribute value of the primary key attribute on the Row this reference is pointing to()</li>
   * <li><code>currencyString</code> - returns getCurrencyString
   * <li><code>attributeValues</code> - returns Array of applicable attribute values from the row()</li>
   * <li><code>labelSet</code> - returns Array of labels for attributes bound()</li>
   * <li><code>row</code> - returns the framework Row object that this binding is referring to</li>
   * <li><code>binding</code> - the rangeset binding that this reference binding is created within.</li>
   *
    */
   public Object get(Object key)
   {
     if (key instanceof String)
     {
        String keyStr = ((String)key).intern();
        if (keyStr == RANGESET_INDEX)
        {
           return new Integer(mIndex);
        }
        if (keyStr == RANGESET_CURRENCY_STRING)
        {
           return getCurrencyString();
        }
        if (keyStr == RANGESET_ROW_DATA_PROVIDER)
        {
           Row row = getRow();
           if (row instanceof oracle.adf.model.generic.RowImpl) 
           {
              return ((oracle.adf.model.generic.RowImpl)row).getDataProvider();
           }
        }
        if (keyStr == RANGESET_ROW_KEY)
        {
           return mRowKey;
        }
        if (keyStr == RANGESET_ROW_KEY_STR)
        {
           return (mRowKey != null) ? mRowKey.toStringFormat(true) : null;
        }
        if (keyStr == RANGESET_ROW_KEY_VALUE)
        {
           return (mRowKey != null && mRowKey.getAttributeCount() == 1) ? mRowKey.getAttribute(0) : null;
        }
        if(keyStr == JUCtrlValueBinding.ATTR_ATTRIBUTE_VALUES)
        {
           return getAttributeValues();
        }
        if (keyStr == RANGESET_ROW)
        {
           return getRow();
        }
        if (keyStr == RANGESET_BASE_BINDING)
        {
           return getBinding();
        }
        if (keyStr == JUCtrlValueBinding.ATTR_ERROR)
        {
           return getError();
        }
        if (keyStr == JUCtrlValueBinding.ATTR_ERRORS)
        {
           return getErrors();
        }


        Row row = resolveRow();
        AttributeDef def= mBinding.lookupAttributeDef(keyStr);
        if (def != null && row != null)
        {
          // JRS 12/02/2003 - 3270936 row.getAttribute does not do attribute
          // value formatting.
          // Object attrValue = row.getAttribute(def.getIndex());
          Object attrValue = mBinding.getInputValueInRow(mBinding, row, def);
          if (attrValue != null)
          {
             return resolveAttributeValue(keyStr, attrValue);
          }
        }
     }
     return null;
   }

   //return formatted value as getAttribute on CtrlValueBinding
   //also does that.
   protected Object[] getAttributeValues()
   {
      Row row = resolveRow();

      AttributeDef defs[]= mBinding.getAttributeDefs();
      Object[] retVal = new Object[defs.length];
      if (row != null)
      {
         for (int j = 0; j < retVal.length; j++)
         {
            retVal[j] = mBinding.getAttributeFromRow(row, defs[j]);
         }
      }
      return retVal;
   }


   protected Object resolveAttributeValue(String key, Object attrValue)
   {
      return attrValue;
   }

   Row resolveRow()
   {
      Row row = (Row)mRowRef.get();
      if (row == null)
      {
         row = getIteratorBinding().getNavigatableRowIterator().getRowAtRangeIndex(mIndex);
         if (row != null)
         {
            Key key = row.getKey();

            if (key == mRowKey || (key != null && !row.getKey().equals(mRowKey)))
            {
               Row rows[] = mBinding.getRowIterator().findByKey(mRowKey, 1);
               if (rows.length == 0 || rows[0] == null)
               {
                  throw new RowNotFoundException(false, getIteratorBinding().getDisplayName(), mRowKey);
               }
               row = rows[0];
            }
         }
      }
      return row;
   }

   /**
   * Returns the copntrol binding with which this reference is associated to get it's data.
   */
   final protected DCControlBinding getReferencedBinding()
   {
      return mBinding;
   }

   /**
   * Returns the iterator binding with which this control binding is associated to get it's data.
   */
   final JUIteratorBinding getIteratorBinding()
   {
      return (JUIteratorBinding)mBinding.getIteratorBinding();
   }

   public Object put(Object key, Object value)
   {
      if (key instanceof String)
      {
         String keyStr = (String)key;
         int index = mBinding.getAttributeIndexOf(keyStr);
         if (index > -1) 
         {
            setInputValue(index, value);
            return null;
         }
      }
      return super.put(key, value);
   }

   public String[] getLabelSet()
   {
      return mBinding.getLabelSet();
   }

   public Object getInputValue(int index)
   {
      return mBinding.getInputValueInRow(mBinding, resolveRow(), mBinding.getAttributeDef(index));
   }

   public void setInputValue(int index, Object val)
   {
      mBinding.getIteratorBinding().prepareForInput();
      mBinding.setInputValueInRow(mBinding, resolveRow(), mBinding.getAttributeDef(index), val, true);
   }

   public void setListener(UpdateListener l)
   {
      mBinding.setListener(l);
   }

   public void setListener(oracle.binding.UpdateListener listener)
   {
      mBinding.setListener(listener);
   }

   protected JboException getError()
   {
      List al = mBinding.getInputErrorsForRowKey(mRowKey);
      return (al == null || al.size() == 0) ? null : (JboException)al.get(0);
   }

   public List getErrors()
   {
      return mBinding.getInputErrorsForRowKey(mRowKey);
   }

   public void release(int flag)
   {
   }

   public boolean isUpdateable(int index)
   {
      return mBinding.isAttributeUpdateable(resolveRow(), index);
   }

   public String getPath()
   {
      return null;
   }

   public boolean resolvePath(Map map)
   {
      return false;
   }
}
