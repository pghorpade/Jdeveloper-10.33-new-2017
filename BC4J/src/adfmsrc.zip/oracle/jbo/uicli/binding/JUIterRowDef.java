/*
 * @(#)JUIterRowDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;
public class JUIterRowDef extends JUIteratorDef
{
   private static final String PNAME_TYPE = "IterBindingRow";
   public JUIterRowDef()
   {
   }
   public JUIterRowDef(String name, String amName, String voName, String rsiName, int rangeSize)
   {
      super(name, amName, voName, rsiName, rangeSize);
   }
   public JUIterRowDef(String name, String amName, String voName, String rsiName)
   {
      this(name, amName, voName, rsiName, 1);
   }
   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }
}
