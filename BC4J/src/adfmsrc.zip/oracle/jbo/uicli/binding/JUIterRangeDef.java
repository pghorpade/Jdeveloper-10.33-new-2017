/*
 * @(#)JUIterRangeDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;
public class JUIterRangeDef extends JUIterRowDef
{
   private static final String PNAME_TYPE = "IterBindingRange";
   public JUIterRangeDef()
   {
   }
   public JUIterRangeDef(String name, String amName, String voName, String rsiName,
                         int rangeSize)
   {
      super(name, amName, voName, rsiName, rangeSize);
   }
   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }
}
