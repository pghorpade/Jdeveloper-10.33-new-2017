/*
 * @(#)JUMethodIteratorDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCBindingContainerDef;
import oracle.adf.model.binding.DCVariableValueManagerImpl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;

import oracle.adf.model.generic.DCRowSetIteratorImpl;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.JboException;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.UIMessageBundle;


import oracle.jbo.Variable;      
import oracle.jbo.VariableManager;      
import oracle.jbo.VariableManagerOwner;      
import oracle.jbo.VariableValueManager;
import oracle.jbo.common.VariableImpl;      
import oracle.jbo.common.VariableValueManagerImpl;      


public class JUVariableIteratorDef extends JUIteratorDef
       implements VariableManagerOwner
{
   private   VariableValueManager mVariableManager;
   //private   boolean              mNotInited = true;

   public JUVariableIteratorDef()
   {
      super();
      setSubType(JUTags.PNAME_variableIterator);
      setName(JUTags.PNAME_variableIterator);
   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc, oracle.jbo.ApplicationModule anchorAM)
   {
      return new JUVariableIteratorBinding(ctx, bc);
   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc)
   {
      return createIterBinding(ctx, bc, null);
   }
   
   public void loadChildrenFromXML(DefElement xmlElement)
   {
      loadVariables(xmlElement);
   }

   protected void loadVariables(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList list =
              xmlElement.getChildrenList();

      int size = list.size();
      if (size > 0)
      {
         DefElement[] defElems = new DefElement[size];
         for (int i = 0; i < size; i++) 
         {
            defElems[i] = (DefElement)list.get(i);
         }
         ((VariableValueManagerImpl)ensureVariableManager()).loadFromXML(defElems, false);
      }
   }


   public final VariableValueManager getVariableManager()
   {
      return mVariableManager;
   }


   protected final VariableValueManager[] getVarMgrParents()
   {
      return new VariableValueManager[0];
   }


   public final boolean hasVariables()
   {
      return (mVariableManager != null);
   }

   public final VariableValueManager ensureVariableManager()
   {
      if (mVariableManager == null)
      {
         mVariableManager = new DCVariableValueManagerImpl(this, null, null);
      }

      return mVariableManager;
   }

   VariableValueManager createVariableValueManager(VariableManagerOwner ctr, DCBindingContainer bc)
   {
      VariableValueManager defMgr = ensureVariableManager();
      Variable vars[] = defMgr.getVariables();;
      VariableValueManager mgr = new DCVariableValueManagerImpl(ctr, null, bc);
      // clone def variables into instance.
      mgr.mergeVariables(vars);
      return mgr;
   }

   public final Class getMessageBundleClass()
   {
      return ((DCBindingContainerDef)getParent()).getMessageBundleClass();
   }

}



