/*
 * @(#)JUCtrlValueDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.StringManager;
import oracle.jbo.common.Diagnostic;      
import oracle.jbo.common.JBOClass;      
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.rules.AbstractValidator;
import oracle.jbo.rules.JboPrecisionScaleValidator;
import oracle.jbo.rules.JboValidatorInterface;
import oracle.jbo.rules.RulesBeanUtils;
import oracle.jbo.rules.ValidationManager;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.NoObjException;

abstract public class JUCtrlValueDef extends JUControlDef
                      implements ValidationManager
{
   private String[]  mAttrNames;
   private ArrayList mValidators;
   private HashMap   mAttrValMap;
   private String    mCustomInputHandler;
   
   //default false so that control-binding xml should not
   //include false entry by default. This needs to be
   //turned on by users for client side validation.
   private boolean   mApplyValidation = false;

   public static final String PNAME_AttrNames = "AttrNames";
   public static final String PNAME_ApplyValidation = "ApplyValidation";
   //public static final String PNAME_IsDynamic = "isDynamic";
   public static final String PNAME_InputHandler = "CustomInputHandler";
   public static final String PNAME_ListNullValueId = "NullValueId";
   public static final String DEFAULT_HANDLER = "DEFAULT";
   private Object mNullValue;
   private String mNullValueId;

   private int mVarInit = -1;
 
   public JUCtrlValueDef()
   {
   }


   public JUCtrlValueDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName);

      mAttrNames = attrNames;
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);
      initMyValues(initValues);      
   }
   
   private void initMyValues(HashMap initValues)
   {
      Object val;
      if ((val = initValues.get(PNAME_AttrNames)) != null)
      {
         mAttrNames = (String[]) val;
      }

      if ((val = initValues.get(PNAME_ApplyValidation)) != null)
      {
         mApplyValidation = convertToBoolean(val);
      }
      
      if ((val = initValues.get(PNAME_ListNullValueId)) != null)
      {
         mNullValueId = (String)val;
      }

      loadInputHandler((String)initValues.get(PNAME_InputHandler));
   }

   public boolean isApplyValidation()
   {
      return mApplyValidation;
   }
   
   public void setApplyValidation(boolean applyVal)
   {
       mApplyValidation = applyVal;
   }
   
   public String getFirstAttrName()
   {
      if (mAttrNames == null || mAttrNames.length == 0)
      {
         return null;
      }
      else
      {
         return mAttrNames[0];
      }
   }

   protected void setNullValueObject(Object nullValue)
   {
      mNullValue = nullValue;
   }
   
   public String getNullValueId()
   {
      return mNullValueId;
   }
   
   public Object getNullValueObject()
   {
      return mNullValue;
   }

   public String[] getAttrNames()
   {
      return mAttrNames;
   }

  
   public void addValidator(JboValidatorInterface intf)
   {
      if (mValidators == null)
      {
         mValidators = new ArrayList(4);
      }
      mValidators.add(intf);
   }

   public ArrayList getValidators()
   {
      return mValidators;
   }

   public String getCustomInputHandler()
   {
      return mCustomInputHandler;
   }

   public boolean hasCustomInputHandler()
   {
      return (mCustomInputHandler != null);
   }

   public void setCustomInputHandler(String id)
   {
      mCustomInputHandler = id;
   }

   ArrayList getValidatorsForAttribute(AttributeDef def)
   {
      String attrName = def.getName();
      if (mAttrValMap != null && mAttrValMap.containsKey(attrName))
      {
         //validators cached per attribute the first time.
         return (ArrayList)mAttrValMap.get(attrName);
      }

      ArrayList al = null;
      ArrayList validators = getValidators();
      if (validators != null)
      {
         Object valObj;
         int size = validators.size();
         al = new ArrayList(size); 
         for (int i = 0; i < size; i++)
         {
            valObj = validators.get(i);
            if (valObj instanceof AbstractValidator)
            {
               if (attrName.equals(((AbstractValidator)valObj).getValidatingAttributeName()))
               {
                  al.add(valObj); 
               }
            }
         }

      }
      if (def.getPrecision() > 0)
      {
         if (al == null)
         {
            al = new ArrayList(1);
         }
         al.add(JboPrecisionScaleValidator.getSingleton());
      }
      setValidatorsForAttribute(attrName, al);
      return al;

   }

   void setValidatorsForAttribute(String attrName, ArrayList al)
   {
      if (mAttrValMap == null)
      {
         mAttrValMap = new HashMap((mAttrNames != null) ? mAttrNames.length : 2);
      }
      mAttrValMap.put(attrName, al);
   }

   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(3);
      
      readXMLStringArray(xmlElement, PNAME_AttrNames, valueTab);
	  
      initMyValues(valueTab);

   }

   protected void loadCustomDef(DefElement xmlElement)
   {
      RulesBeanUtils.loadValidators(xmlElement, this, getMessageBundleClass());
   }

   public void loadFromXML(DefElement xmlElement)
   {
      super.loadFromXML(xmlElement);
      
      mNullValueId = xmlElement.readString(PNAME_ListNullValueId);
      mApplyValidation = xmlElement.readBoolean(PNAME_ApplyValidation);
      loadInputHandler(xmlElement.readString(PNAME_InputHandler));
   }

   private final void loadInputHandler(String str)
   {
      if (str != null && str.length() > 0)
      {
         mCustomInputHandler = str;
      }
   }

   public DCControlBinding createControlBinding(Object control, DCBindingContainer formBnd)
   {
      
      JUCtrlValueBinding controlBnd = (JUCtrlValueBinding)super.createControlBinding(control, formBnd);
      if (hasCustomInputHandler())
      {
         controlBnd.lookupInputHandler();
      }
      //this is done in bindingContainer.internalRefreshControl
      //when bindingContainer is initialized.
      //controlBnd.setNullValueString(initializeNullValue(formBnd));
      return controlBnd;
   }

  public JUIteratorBinding getIterBinding(JUFormBinding formBnd)
  {
     try
     {
        return super.getIterBinding(formBnd);
     }
     catch (oracle.jbo.JboException je)
     {
        if (getIterBindingName() == null)
        {
           if (hasVariables())
           {
              return null;
           }
        }
        throw je;
     }
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Returns the class of the reference object.
   * @return the class of the reference object.
  */
  public final Class getMessageBundleClass()
  {
     try
     {
        return JBOClass.forName(getBindingContainerDef().getMessageBundleClassName());
     }
     catch (Exception e)
     {
        if (Diagnostic.isOn()) 
        {
           Diagnostic.println("Ignoring exception on loading Message bundle for :"+getBindingContainerDef().getName());
        }
     }
     return null;
  }

  boolean hasVariables()
  {
     if (mVarInit == -1) 
     {
        mVarInit = (getIterBindingName() == null && mAttrNames != null && mAttrNames.length > 0) ? 1 : 0;
     }
     return (mVarInit == 1);
  }

  String initializeNullValue(DCBindingContainer bc)
  {
     if (mNullValueId != null) 
     {
        try
        {
           String bundle = bc.getDef().getMessageBundleClassName();
           LocaleContext lc = bc.getLocaleContext();
           Locale locale = (lc != null) ? lc.getLocale() : Locale.getDefault();
           mNullValue = StringManager.getLocalizedString(UIMessageBundle.class.getName(), 
                                                UIMessageBundle.STR_NULL_VALUE, "", locale);
           if (bundle != null)
           {
              mNullValue = StringManager.getLocalizedString(bundle, mNullValueId, (String)mNullValue, locale);
           }
        }
        catch (Exception e)
        {
           Diagnostic.println("Warning! Assuming null value id as the null value due to :");
           Diagnostic.println("exception on loading null value string from message bundle for :"+getName());
           Diagnostic.printStackTrace(e);
           mNullValue = mNullValueId;
        }
     }
     return (String)mNullValue;
  }

}   

