/*
 * @(#)JUCtrlActionDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.binding.DCMethodParameterDef;

import oracle.jbo.mom.xml.DefElement;

public class JUCtrlActionDef extends JUControlDef
{
   private int mAction = -1;

   public static final String PNAME_ActionID     = "Action";
   public static final String PNAME_InstanceName = "InstanceName";
   public static final String PNAME_MethodName   = "MethodName";
   public static final String PNAME_ReturnName   = "ReturnName"; 
   public static final String PNAME_ClassName   = "ClassName";
   public static final String PNAME_Arguments  = "Parameters";
   public static final String PNAME_DataControl = "DataControl";                 
   public static final String PNAME_IsViewObjectMethod  = "IsViewObjectMethod";
   public static final String PNAME_IsLocalObjectReference  = "IsLocalObjectReference";
   public static final String PNAME_RequiresUpdateModel  = "RequiresUpdateModel";
   private static final String INTERNAL_PNAME_Text = "ButtonText";
   
   //kavaonly.
   public static final String PNAME_ArgNamesList = "ArgNames";
   public static final String PNAME_ArgTypesList = "ArgTypes";
   public static final String PNAME_ArgValuesList = "ArgValues";
   public static final String PNAME_ArgOptionsList = "ArgOptions";
   
   protected  DCInvokeMethodDef mMethodInfo;
   private String mDCName;
   private String mButtonText;
   private Boolean mRequiresUpdateModel;
   
   
   public JUCtrlActionDef()
   {
   }


   public JUCtrlActionDef(String name, String controlClassName,
                          String controlBindingClassName, String iterBindingName,
                          int action)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName);

      mAction = action;
   }

   protected void initSubType()
   {
      setSubType(PNAME_Action);
   }
   
   public String getText()
   {
      return mButtonText;   
   }
   
   protected void setText(String txt)
   {
      mButtonText = txt;
   }
   
   public boolean requiresUpdateModel()
   {
      return mRequiresUpdateModel.booleanValue();   
   }
   
   public String getDataControlName()
   {
   	return(mDCName);
   }
   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_ActionID)) != null)
      {
         char ch = '0';

         if (val instanceof String)
         {
            ch = ((String) val).charAt(0);
         }

         if (ch < '0' || ch > '9')
         {
            mAction = JUCtrlActionBinding.actionNameToId((String) val);
         }
         else
         {
            mAction = convertToInt(val);
         }
      }

     if(initValues.get(PNAME_RequiresUpdateModel) == null)
     {
       mRequiresUpdateModel = new Boolean(getDefaultValueForUpdateModel(mAction));
     }
     else
     {
       mRequiresUpdateModel = (Boolean)initValues.get(PNAME_RequiresUpdateModel);
     }
     
	  mDCName = (String)initValues.get(PNAME_DataControl);

      switch (mAction)
      {
         case JUCtrlActionBinding.ACTION_EXECUTE_WITH_PARAMS:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEYVALUE:
         case JUCtrlActionBinding.ACTION_REMOVEROW_WITH_KEY:
            mMethodInfo = new DCInvokeMethodDef(getName(), 
                                                 JUCtrlActionBinding.actionIdToName(mAction), 
                                                 (DCMethodParameterDef[])initValues.get(PNAME_Arguments), 
                                                 null, null,
                                                 new Boolean(false), new Boolean(true));
         break;

         case JUCtrlActionBinding.ACTION_INVOKE_METHOD:

            if (initValues.get(PNAME_ArgTypesList) != null)
            {
               mMethodInfo = new DCInvokeMethodDef((String)initValues.get(PNAME_InstanceName), 
                                                    (String)initValues.get(PNAME_MethodName), 
                                                    (String[])initValues.get(PNAME_ArgTypesList), 
                                                    (String[])initValues.get(PNAME_ArgValuesList),
                                                    (String[])initValues.get(PNAME_ArgOptionsList),
                                                    (String)initValues.get(PNAME_ReturnName),
                                                    (String)initValues.get(PNAME_ClassName),
                                                    (Boolean)initValues.get(PNAME_IsViewObjectMethod),
                                                    (Boolean)initValues.get(PNAME_IsLocalObjectReference)
                                                    );
            }
            else
            {
               mMethodInfo = new DCInvokeMethodDef((String)initValues.get(PNAME_InstanceName), 
                                                    (String)initValues.get(PNAME_MethodName), 
                                                    (DCMethodParameterDef[])initValues.get(PNAME_Arguments), 
                                                    (String)initValues.get(PNAME_ReturnName),
                                                    (String)initValues.get(PNAME_ClassName),
                                                    (Boolean)initValues.get(PNAME_IsViewObjectMethod),
                                                    (Boolean)initValues.get(PNAME_IsLocalObjectReference)
                                                       );
            }
            break;

         case JUCtrlActionBinding.ACTION_COMMIT_TRANSACTION:
         case JUCtrlActionBinding.ACTION_ROLLBACK_TRANSACTION:
            mDCName = (String)initValues.get(PNAME_DataControl);
            break;

         default:
            break;
      }
   }

   /**
    *  For internal use only.
    */
   public DCInvokeMethodDef getMethodDef()
   {
      return mMethodInfo;
   }
   
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      switch (mAction)
      {
         case JUCtrlActionBinding.ACTION_EXECUTE_WITH_PARAMS:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEYVALUE:
         case JUCtrlActionBinding.ACTION_REMOVEROW_WITH_KEY:
         {
            JUCtrlActionBinding binding = createIteratorActionBinding(control, getIterBinding(formBnd), mAction);
            binding.setupMethodInfo(formBnd, mMethodInfo);
            return binding;
         }

         case JUCtrlActionBinding.ACTION_INVOKE_METHOD:
            return createInvokeActionBinding(control, formBnd, mMethodInfo);

         case JUCtrlActionBinding.ACTION_COMMIT_TRANSACTION:
         case JUCtrlActionBinding.ACTION_ROLLBACK_TRANSACTION:
         case JUCtrlActionBinding.ACTION_RESET_STATE:
            return createDataControlActionBinding(
              control, 
              (DCDataControl)DCUtil.findContextObject(formBnd.getBindingContext(), mDCName), 
              mAction);

         default:
            return createIteratorActionBinding(control, this.getIterBinding(formBnd), mAction);
      }
   }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createInvokeActionBinding(
    Object control,
    DCBindingContainer formBnd,
    DCInvokeMethodDef mMethodInfo)
   {
      return new JUCtrlActionBinding(control, formBnd, mMethodInfo);
   }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createDataControlActionBinding(
    Object control,
    DCDataControl dataControl,
    int mAction)
   {
      return new JUCtrlActionBinding(control, dataControl, mAction);
   }

   /**
    *  For internal use only.
    */
   protected JUCtrlActionBinding createIteratorActionBinding(
    Object control,
    DCIteratorBinding iterBinding,
    int mAction)
   {
      return new JUCtrlActionBinding(control, iterBinding, mAction);
   }

   public int getAction()
   {
      return mAction;
   }

   
   public static  boolean getDefaultValueForUpdateModel(int nAction)
   {
      switch(nAction)
      {
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEYVALUE:
         case JUCtrlActionBinding.ACTION_REMOVEROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_RESET:
         case JUCtrlActionBinding.ACTION_REMOVE_CURRENT_ROW:
         case JUCtrlActionBinding.ACTION_ROLLBACK_TRANSACTION:
            return false;
         case JUCtrlActionBinding.ACTION_BINDING_CONTAINER_EXECUTE:
         case JUCtrlActionBinding.ACTION_NEXT:
         case JUCtrlActionBinding.ACTION_PREVIOUS:
         case JUCtrlActionBinding.ACTION_NEXT_SET:
         case JUCtrlActionBinding.ACTION_PREVIOUS_SET:
         case JUCtrlActionBinding.ACTION_FIRST:
         case JUCtrlActionBinding.ACTION_LAST:
         case JUCtrlActionBinding.ACTION_CREATE_INSERT_ROW:
         case JUCtrlActionBinding.ACTION_COMMIT_TRANSACTION:

         //custom method calls need to indicate if they do not want 
         //values to be udpated. By default we are erring towards
         //the side of maintaining updates for a user.
         //this is a change in behavior from 1012 - bug4521584
         case JUCtrlActionBinding.ACTION_INVOKE_METHOD:
         default:
            return true;
      }
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLInt(xmlElement, PNAME_ActionID, valueTab);

      //so that we may read in 905 preview button texts.
      readXMLString(xmlElement, INTERNAL_PNAME_Text, valueTab);

	   readXMLString(xmlElement,  PNAME_DataControl, valueTab);
      readXMLBoolean(xmlElement, PNAME_RequiresUpdateModel, valueTab);
      
      Integer val = (Integer)valueTab.get(PNAME_ActionID);  

      int valInt = (val != null) ? val.intValue() : JUCtrlActionBinding.ACTION_INVOKE_METHOD;
      switch (valInt)
      {
         case JUCtrlActionBinding.ACTION_INVOKE_METHOD:
            valueTab.put(PNAME_ActionID, new Integer(valInt));
            readXMLString(xmlElement,      PNAME_InstanceName, valueTab);
            readXMLString(xmlElement,      PNAME_MethodName,   valueTab);
            readXMLString(xmlElement,      PNAME_ReturnName,   valueTab);
            readXMLString(xmlElement,      PNAME_ClassName, valueTab);
            readXMLBoolean(xmlElement,     PNAME_IsViewObjectMethod, valueTab);
            readXMLBoolean(xmlElement,     PNAME_IsLocalObjectReference, valueTab);
            break;

         case JUCtrlActionBinding.ACTION_COMMIT_TRANSACTION:
         case JUCtrlActionBinding.ACTION_ROLLBACK_TRANSACTION:
            readXMLString(xmlElement,      PNAME_DataControl, valueTab);
            break;

         default:
            break;
      }   
   }

   DCMethodParameterDef[] loadParameterInfo(DefElement xmlElement)
   {
      //if DefPersitable load via interface.
      com.sun.java.util.collections.ArrayList v = xmlElement.getChildrenList(oracle.jbo.mom.Tags.NAMED_DATA);
      
      if(v.size() == 0)
         return null;
         
      DCMethodParameterDef jnd;
      if ( (v != null) )
      {
         DCMethodParameterDef[] props = new DCMethodParameterDef[v.size()];
         for ( int i=0; i < v.size(); i++ )
         {
            //create * load named data.
            jnd = new DCMethodParameterDef();
            jnd.loadFromXMLFile((DefElement)v.get(i));
            props[i] = jnd;
         }
         return props;
      }
      return new DCMethodParameterDef[0];
   }

   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      switch (getAction()) 
      {
         case JUCtrlActionBinding.ACTION_EXECUTE_WITH_PARAMS:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_SETCURRENTROW_WITH_KEYVALUE:
         case JUCtrlActionBinding.ACTION_REMOVEROW_WITH_KEY:
         case JUCtrlActionBinding.ACTION_INVOKE_METHOD:
         {
            DCMethodParameterDef defs[] = loadParameterInfo(xmlElement);
            if(defs != null)
            {
               mMethodInfo.setArguments(defs);
            }
         }
         break;
      }
   }
}
