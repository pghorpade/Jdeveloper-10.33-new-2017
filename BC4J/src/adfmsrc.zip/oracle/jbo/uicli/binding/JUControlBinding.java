/*
 * @(#)JUControlBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.jbo.JboException;

/**
 * The base class for all binding objects in the JClient framework that bind
 * a Swing control/model to a BC4J attribute(s). This class manages:
 * <ul>
 * <li>The references to the Swing control
 * <li>The IteratorBinding with which the binding object is in association
 * <li>The form binding that this binding belongs to
 * <li>The internal-state for findMode
 * </ul>
 * <p>
 * This class also implements helper methods to access BC4J objects like the Transaction,
 * the current Application Module, the ViewObject that this control binding is working with,
 * the current RowIterator, the current Row in the iterator that this control binding
 * is associated with. It also provides methods to execute the
 * ViewObject behind this again (optionally).
 *
 * @javabean.class name=JUControlBinding
 * 
 */
abstract public class JUControlBinding extends DCControlBinding
{
   protected JUControlBinding()
   {
      super();
   }

   /**
   * Constructor used in the framework to pass in the Swing control and the Iterator Binding
   * with which this binding object works to get it's data.
   */
   public JUControlBinding(Object control, DCIteratorBinding iterBinding)
   {
      super(control, iterBinding);
   }

   
   /**
   * *** For internal framework use only ***
   */
   abstract public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons);

   
   /**
   * Returns the form binding object that this control binding is part
   * of.
   *
   */
   public final JUFormBinding getFormBinding()
   {
      return (JUFormBinding)super.getBindingContainer();
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void setFormBinding(JUFormBinding formBnd)
   {
      super.setBindingContainer(formBnd);
   }

   
   /**
   * Returns the iterator binding with which this control binding is
   * associated to get it's data.
   *
   * @javabean.property
   */
   public final JUIteratorBinding getIteratorBinding()
   {
      return (JUIteratorBinding)super.getDCIteratorBinding();
   }

   /**
   * Returns the current row for which this control is displaying data. In find mode, this will
   * return an instance of ViewCriteriaRow, whereas in data mode it returns a Row object.
   * This method should be used to get the current Row to which this control is bound in order
   * to perform any validations on the control-value or data stored in
   * the row.
   *
   * @javabean.property 
   */
   public oracle.jbo.Row getCurrentRow()
   {
      return super.getCurrentRow();
   }

   public void reportException(Exception ex, boolean grabFocus)
   {
      Object control = getControl();
      if (grabFocus && control instanceof javax.swing.JComponent) 
      {
         ((javax.swing.JComponent)control).grabFocus();
      }
      getBindingContainer().reportException(ex);
      if (!grabFocus)
      {
         throw (ex instanceof JboException) ? (JboException)ex : new JboException(ex);
      }
   }
   
}
