/*
 * @(#)JUCtrlScrollDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.jbo.mom.xml.DefElement;

abstract public class JUCtrlScrollDef extends JUControlDef
{
   private boolean mScrollCurrRow = true;
   private boolean mDeferAssignValues = false;
   private boolean mUseEstRC = true;

   public static final String PNAME_ScrollCurrRow = "ScrollCurrRow";
   public static final String PNAME_DeferAssignValues = "DeferAssignValues";
   public static final String PNAME_UseEstRC = "UseEstRC";

   
   public JUCtrlScrollDef()
   {
   }


   public JUCtrlScrollDef(String name, String controlClassName,
                          String controlBindingClassName, String iterBindingName,
                          boolean scrollCurrRow, boolean deferAssignValues,
                          boolean useEstRC)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName);

      mScrollCurrRow = scrollCurrRow;
      mDeferAssignValues = deferAssignValues;
      mUseEstRC = useEstRC;
   }

   protected void initSubType()
   {
      setSubType(PNAME_ScrollBar);
   }
   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_ScrollCurrRow)) != null)
      {
         mScrollCurrRow = convertToBoolean(val);
      }

      if ((val = initValues.get(PNAME_DeferAssignValues)) != null)
      {
         mDeferAssignValues = convertToBoolean(val);
      }

      if ((val = initValues.get(PNAME_UseEstRC)) != null)
      {
         mUseEstRC = convertToBoolean(val);
      }
   }

   
   public boolean isScrollCurrRow()
   {
      return mScrollCurrRow;
   }

   
   public boolean isDeferAssignValues()
   {
      return mDeferAssignValues;
   }

   
   public boolean isUseEstRC()
   {
      return mUseEstRC;
   }

   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_ScrollCurrRow, valueTab);
      readXMLBoolean(xmlElement, PNAME_DeferAssignValues, valueTab);
      readXMLBoolean(xmlElement, PNAME_UseEstRC, valueTab);
   }
}
