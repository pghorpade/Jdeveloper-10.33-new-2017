/*
 * @(#)JUCtrlHierNodeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.lang.ref.WeakReference;

import java.util.ArrayList;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.adf.model.generic.DCGenericRowSetIteratorImpl;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.common.JboNameUtil;
/**
 *
 * @javabean.class name=JUCtrlHierNodeBinding
 */
public class JUCtrlHierNodeBinding extends JUCtrlValueBinding 
{
   /**
   * *** For internal framework use only ***
    */
   protected JUCtrlHierTypeBinding mTypeBinding;
   /**
   * *** For internal framework use only ***
    */
   protected JUCtrlHierBinding mHierBinding;
   /**
   * *** For internal framework use only ***
    */
   protected JUCtrlHierNodeBinding mParentNode;
   /**
   * *** For internal framework use only ***
    */
   protected DCIteratorBinding mChildIterBinding;
   /**
   * *** For internal framework use only ***
    */
   protected Object mNodeValue;
   /**
   * *** For internal framework use only ***
    */
   protected Key mRowKey;
   /**
   * *** For internal framework use only ***
    */
   WeakReference mRowRef;
   /**
   * *** For internal framework use only ***
    */
   protected boolean mExpandable;
   /**
   * *** For internal framework use only ***
    */
   protected ArrayList mChildren;

   boolean mSyncWhenNeeded = false;
   
   public JUCtrlHierNodeBinding(JUCtrlHierBinding hierBinding, 
                                JUCtrlHierNodeBinding parent,
                                JUIteratorBinding iterBinding, 
                                JUCtrlHierTypeBinding typeBinding, 
                                Row      row, boolean expandable)
   {
      super(hierBinding.getControl(), 
            (parent != null) ? parent.getChildIteratorBinding() : iterBinding, 
            (typeBinding != null && typeBinding.getAttrNames() != null) 
                            ? typeBinding.getAttrNames()
                            : (new String[] {})
            );

      mExpandable = expandable;
      mHierBinding = hierBinding;
      mParentNode = parent;
      
      //this node is added to both parent iteratorBinding as well as
      //the child iterator binding.
      mChildIterBinding = iterBinding;

      String[] accs = typeBinding.getAccessorNames();
      mTypeBinding = typeBinding;

      if (accs == null || accs.length == 1) 
      {
         if (iterBinding != null && iterBinding != getIteratorBinding())
         {
            iterBinding.addValueBinding(this);
         }
      }
      /*
      else if (row != null) 
      {
         JUCtrlHierTypeBinding types[] = typeBinding.getAccessorTypeBindings();
         for (int i =0; i < accs.length; i++) 
         {
            hierBinding.createNodeBinding(this, createAccessorIteratorBinding(row, accs[i]), 
                                          types[i], null, true);
         }
         mChildIterBinding = null;
      }
      */

      if (parent != null)
      {
         parent.addChild(this);
      }

      boolean nodeVal = true;
      if (row != null)
      {
         mRowRef = new WeakReference(row);
         mRowKey = row.getKey();
         if (typeBinding != null)
         {
            refresh(row);
            nodeVal = false;
         }
      }

      if (nodeVal)
      {
         mNodeValue = iterBinding.getName();
      }

      if (iterBinding != null && parent != null)
      {
         //iteratorbindings with tree cannot change their datamode.
         //except the toplevel one which may have other controls
         //that may allow find mode.
         iterBinding.setAllowFindMode(false);
      }
      setFormBinding(hierBinding.getFormBinding());
   }


   public void release(int flags)
   {
      //clean up this node from the parent and set it's iteratorBinding to 
      //null for top level node (rootnode), childIterBinding is same as
      //iteratorBinding so leave that alone as this particular node does
      //not get recreated on sync.
      JUCtrlHierBinding tree = getHierBinding();
      if (mParentNode != null) 
      {
         mParentNode.removeChild(this);
         mChildIterBinding = null;
         mRowRef = null;
      }

      //force children to be refetched.
      //mChildren = null;
      // JRS 12/11/2007 commented the above.  need to actually release
      // the children.
      if (mChildren != null)
      {
         ArrayList children = (ArrayList)mChildren.clone();
         for (int i=0; i < children.size(); i++)
         {
            ((JUCtrlHierNodeBinding)children.get(i)).release(flags);
         }
         mChildren = null;
      }

      // jrs bug 5587359.  all JUCtrlHierNodeBinding releases should
      // be treated as release all.
      if (tree!= null && tree.internalGetRootNodeBinding() == this)
      {
         tree.clearRootBinding();
      }

      super.release(DCDataControl.REL_ALL_REFS);
   }

   public JUCtrlHierBinding getHierBinding()
   {
      return mHierBinding;
   }
   /**
    *
    * @javabean.property
    */
   public JUCtrlHierNodeBinding getParent()
   {
      return mParentNode;
   }

   /**
   * Returns the Key object that identifies the row that this node is displaying.
   */
   public Key getRowKey()
   {
      return mRowKey;
   }
   /**
    *
    * @javabean.property
    */
   public DCIteratorBinding getChildIteratorBinding()
   {
      return mChildIterBinding;
   }

   /**
    *
    * @javabean.property
    */
   protected boolean isAutoSyncEnabled()
   {
      return (mSyncWhenNeeded || mHierBinding.isAutoSyncEnabled());
   }

   /**
    <b>Advanced method:</b> <em>Applications should not use this method unless
    * in batchmode and control the sync() calls to middletier.
    * <p>
    * Reset this flag if the tree node should not force a DataControl.sync()
    * call to force fetching of data for this node. This method should be
    * used in batch mode when the Tree is viewed in a thin-client and
    * the application wants to control when to perform sync.
    */
   public void setAutoSyncEnabled(boolean flag)
   {
      mSyncWhenNeeded = flag;
   }


   /**
   * Execute the query for the RowIterator that this row is associated with if it is not already executed.
   */
   
   public void executeQueryIfNeeded()
   {
      if (mChildIterBinding != null)
      {
         boolean noChildren = (mChildren == null);

         if (mChildIterBinding.hasRSI())
         {
            mChildIterBinding.executeQueryIfNeeded();
         }

         if (noChildren)
         {
            Row[] childRows = null;
            //even for root node, we need to force a refresh
            //of it's children if none was created thus far.
            //so check of nodes other than root level, before
            //trying to find if we need to sync and expand
            //incase of batchmode for an unexpanded node.
            if (mParentNode != null)
            {
               DCDataControl dc = mChildIterBinding.getDataControl();
               if (dc.syncNeeded() && isAutoSyncEnabled() && !mChildIterBinding.hasRSI())
               {
                  //force execute in case of no RSI.
                  mChildIterBinding.executeQuery();
                  if (!mChildIterBinding.hasRSI())
                  {
                     mChildren = mHierBinding.syncAndExpand(dc, this);
                     return;
                  }
               }
               else
               {
                  //childiterbindings are created with refresh=never, so we need to force
                  //execute on them.
                  if (!(mChildIterBinding.isRefreshed() || mChildIterBinding.hasRSI())) 
                  {
                     mChildIterBinding.executeQuery();
                  }
               }
            }
            childRows = mChildIterBinding.getAllRowsInRange();
            myUpdateValuesFromRows(childRows, true);
         }
      }
      if (mChildren == null)
      {
         mChildren = new ArrayList(0);
      }
   }

   ArrayList internalGetChildren()
   {
      return mChildren;
   }

   /**
    * *** For internal framework use only ***
    * Return a list of children nodes from an accessor child with 
    * the matching accessor name (accName)
    * when this node expands into a multiple accessor nodes.
    */
   public ArrayList getChildren(String accName)
   {
      String[] accnames = getHierTypeBinding().getAccessorNames();
      if (accnames != null && accnames.length > 1) 
      {
         for (int i = 0; i < accnames.length; i++) 
         {
            if (accnames[i].equals(accName)) 
            {
               ArrayList list = getChildren();
               return ((JUCtrlHierNodeBinding)list.get(i)).getChildren();
            }
         }
      }
      return getChildren();
   }

   public ArrayList getChildren()
   {
      if (mChildren == null && mExpandable)
      {
         //this is a potential breakage point as it leads to 
         //data fetch.
         executeQueryIfNeeded();
      }
      if (getIteratorBinding() == null)
      {
         //must be in batchmode and iteratorbinding turned into null due to
         //rangeRefreshed. Lets get the equivalent and return it's children.
         JUCtrlHierNodeBinding node = getHierBinding().findNodeByKeyPath(getKeyPath());
         if (node != null)
         {
            //to avoid infinite loop in case of null children.
            mChildren =  node.internalGetChildren();
         }
      }
      if ((mHierBinding.getRootNodeBinding() == this) &&  getIteratorBinding().getDataControl().syncNeeded())
      {
         if (mChildren != null && mChildren.size() > 0)
         {
            //expand one more level in case of batchmode to avoid 
            //recreation of first level nodes due to syncAndRestore
            ((JUCtrlHierNodeBinding)mChildren.get(0)).getChildren();
         }
      }
      
      return (mChildren != null) ? (ArrayList)mChildren.clone() : null;
   }
   
   public void addChild(JUCtrlHierNodeBinding child)
   {
      if (mChildren == null)
      {
         mChildren = new ArrayList(2);
      }

      mChildren.add(child);
   }
   
   
   public boolean removeChild(JUCtrlHierNodeBinding child)
   {
      if (child.mChildren != null)
      {
         for (int i = child.mChildren.size()-1; i >= 0; --i)
         {
            child.removeChild((JUCtrlHierNodeBinding)child.mChildren.get(i));
         }
         child.mChildren = null;
      }

      if (mChildren != null)
      {
         DCIteratorBinding iter = child.getChildIteratorBinding();
         ArrayList al;
         if (iter != null)
         {
            iter.removeValueBinding(child);
            //this should be released by the child node itself.
            al = iter.getValueBindingList();
            if (al == null || al.size() == 0)
            {
               RowSetIterator rsi = iter.getRowSetIterator();

               //If navbar is listening to this iterator binding
               //it better be notified here or before this to 
               //focus elsewhere so that no unwanted action gets
               //invokved on this iterator binding.
               iter.release();

               if (rsi instanceof DCGenericRowSetIteratorImpl)
               {
                  rsi.closeRowSetIterator();
               }

            }
            child.mChildIterBinding = null;
         }
         
         iter = child.getIteratorBinding();
         iter.removeValueBinding(child);
         //al = iter.getValueBindingList();
         //if (al == null || al.size() == 0)
         //{
            //iter.release();
         //}
         getBindingContainer().removeControlBinding(child);
         return mChildren.remove(child);
      }

      return false;
   }

   protected JUCtrlHierNodeBinding findChildNode(Key key)
   {
      JUCtrlHierNodeBinding node = null;
      ArrayList children = getChildren();
      if (children != null)
      {
         int size = children.size();
         for (int j = 0; (j < size); j++)
         {
            node = ((JUCtrlHierNodeBinding) children.get(j));
            if (key.equals(node.mRowKey))
            {
               return node;
            }
         }
      }
      return null;
   }

   protected JUCtrlHierNodeBinding findMatchingNode(Key key)
   {
      if (mParentNode == null)
      {
         return findChildNode(key);
      }
      else if (mParentNode != null)
      {
         if (key.equals(this.getRowKey()))
         {
            return this;
         }
      }  
      return null;
   }
   
   /**
   * Update the display by adding a node to render the inserted row as this node's child.
   */
   public void updateRowInserted(InsertEvent event)
   {
      if (mChildIterBinding != null && mChildIterBinding.isBoundRowIteratorEvent(event))
      {
         if (!getIteratorBinding().isFindMode())
         {
            myUpdateValuesFromRows(mChildIterBinding.getAllRowsInRange(), true);
         }
      } 
   }
   
   
   /**
   * Removes a child node that displays the deleted row from amongst this node's children.
   */
   public void updateRowDeleted(DeleteEvent event)
   {
      //remove existing child-nodes and add new ones based on current range set.
      //an optimization could be we could look for the exact row that has been deleted
      //and remove that node.
      //if (mChildIterBinding != null && mChildIterBinding.hasRSI() && event.getSource() == mChildIterBinding.getNavigatableRowIterator())
      if (mChildIterBinding != null && mChildIterBinding.isBoundRowIteratorEvent(event))
      {
         if (!getIteratorBinding().isFindMode())
         {
            myUpdateValuesFromRows(mChildIterBinding.getAllRowsInRange(), true);
         }
      } 
   }

   void refresh (Row row)
   {
      String[] attrNames = getAttributeNames();
      if (row != null && attrNames != null)
      {
         if (attrNames.length == 1)
         {
            mNodeValue = row.getAttribute(attrNames[0]);
         }
         else
         {
            mNodeValue = getMergedAttributeValues(getAttributes(row, getAttributeDefs()));
         }
      }
      else
      {
         mNodeValue = null;
      }
   }

   /**
   * Finds the child node that displays this row and updates its display.
   */
   public void updateValuesFromRow(Row row)
   {
      if (row != null && getIteratorBinding() != null)
      {
         JUCtrlHierNodeBinding node = (JUCtrlHierNodeBinding)findMatchingNode(row.getKey());
         if (node != null) 
         {
            node.refresh(row);
         }
      }
   }

   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      JUIteratorBinding iter = getIteratorBinding();
      if (mParentNode == null && iter != null)
      {
         if (!iter.isFindMode())
         {
            myUpdateValuesFromRows(rows, clear);
         }
      }
   }
   
   /**
   * Updates the child nodes that this node contains after optionally clearing out all
   * the currently displayed children based on the clear flag.
   * <p>
   * This method determines the rules to associate with each row in the given array of rows.
   */
   public void myUpdateValuesFromRows(Row[] rows, boolean clear)
   {
      DCIteratorBinding myIter = getIteratorBinding();
      if (myIter != null && myIter.isFindMode())
      {
         return;
      }
      
      JUCtrlHierBinding treeBinding = (JUCtrlHierBinding)getHierBinding();
      if (clear)
      {
         if (mChildren != null)
         {
            JUCtrlHierNodeBinding node;
            for (int i = mChildren.size() - 1; i >= 0; --i)
            {
               node = (JUCtrlHierNodeBinding)mChildren.get(i);
               removeChild(node);
               node.release(DCDataControl.REL_ALL_REFS);
            }
            mChildren = null;
         }
      }
      
      if (rows == null)
      {
         return;
      }

      JUCtrlHierTypeBinding[] typeBindings = treeBinding.getTypeBindings();
      
      String thisVOType = mChildIterBinding.getIteratorDefName();

      JUCtrlHierTypeBinding typeBinding = null;

      int typeBindingSize = (typeBindings != null) ? typeBindings.length : 0;
      for (int k = 0; k < typeBindingSize; k++)
      {
         if (!typeBindings[k].isDiscrColumnType() && typeBindings[k].matchViewObjectType(thisVOType))
         {
            typeBinding = typeBindings[k];
            break;
         }
      }

      Row row;
      JUIteratorBinding iterBnd;
      String childAccessorName;
      boolean expandable;

      boolean batchmode = myIter.getDataControl().syncNeeded();
      if (typeBinding != null)
      {
         for (int j = 0; j < rows.length; j++)
         {
            row = rows[j];
            if (row != null) 
            {
               expandable = false;
               iterBnd = null;
               if ((childAccessorName = typeBinding.getAccessorName()) != null)
               {
                  //set the def to be a master row-tracking accessor iterator binding.
                  
                  iterBnd = createAccessorIteratorBinding(row, childAccessorName);

                  //incase of batchmode, accessor is null if not already fetched, so force a 
                  //roundtrip on expand to verify.
                  
                  //caveat:if accessor RSI is actually null, this may lead to one extra
                  //roundtrip to expand to a no-child state.
                  expandable = (batchmode || (iterBnd.hasRSI() && iterBnd.getRowSetIterator() != null));
               }
      
               JUCtrlHierNodeBinding newNode = treeBinding.createNodeBinding(this, iterBnd, typeBinding, row, expandable);
               if (row != null) 
               {
                  newNode.setupAccessors(row);
               }
            }
         }
      }
      else
      {
         //for each row, figure out the discriminant type and match the node-binding.
         ArrayList discrBindings = new ArrayList(typeBindingSize);
         for (int k = 0; k < typeBindingSize; k++)
         {
            //could have done instanceof Instead using methods
            //as supposedly methods are faster.
            if (typeBindings[k].isDiscrColumnType())
            {
               discrBindings.add(typeBindings[k]);
            }
         }
         JUCtrlHierTypeBinding discrBinding;
         java.util.Iterator iter;

         for (int j = 0; j < rows.length; j++)
         {
            row = rows[j];
            if (row != null) 
            {
               expandable = false;
               iterBnd = null;
               typeBinding = null;
               
               iter = discrBindings.iterator();
               while (iter.hasNext())
               {
                  discrBinding = (JUCtrlHierTypeBinding)iter.next();
                  if (discrBinding.matchRowDiscrColumn(row))
                  {
                     typeBinding = discrBinding;
                     break;
                  }
   
               }
   
               if (typeBinding != null)
               {
                  if ((childAccessorName = typeBinding.getAccessorName()) != null)
                  {
                     //iterBnd = new JUIteratorBinding(getIteratorBinding().getDataControl(), (RowSetIterator) row.getAttribute(childAccessorName));
                     //this.getBindingContainer().addIteratorBinding(iterBnd.getName(), iterBnd);
                     iterBnd = createAccessorIteratorBinding(row, childAccessorName);
                     expandable = (batchmode || (iterBnd.hasRSI() && iterBnd.getRowSetIterator() != null));
                  }
      
                  JUCtrlHierNodeBinding newNode = treeBinding.createNodeBinding(this, iterBnd, typeBinding, row, expandable);
                  if (row != null) 
                  {
                     newNode.setupAccessors(row);
                  }
               }
            }
         }
      }
   }
   protected void setupAccessors(Row row)
   {
      JUCtrlHierTypeBinding types[] = mTypeBinding.getAccessorTypeBindings();
      if (types != null) 
      {
         String accs[] = mTypeBinding.getAccessorNames();
         JUCtrlHierNodeBinding node;
         for (int i =0; i < types.length; i++) 
         {
            node = mHierBinding.createNodeBinding(this, ((i > 0) ? createAccessorIteratorBinding(row, accs[i]) 
                                                          : (JUIteratorBinding)mChildIterBinding), 
                                          types[i], null, true);
            node.mNodeValue = accs[i];
         }
         mChildIterBinding = null;
      }
   }

   private JUIteratorBinding createAccessorIteratorBinding(Row row, 
                                                           String childAccessorName)
   {
      DCIteratorBinding parentIter = getIteratorBinding();

      //set the def to be a master row-tracking accessor iterator binding.
      JUAccessorIteratorDef accDef = new JUAccessorIteratorDef(childAccessorName, 
                                                               mChildIterBinding.getName(), true);
      java.util.HashMap map = new java.util.HashMap(3);
      map.put(JUAccessorIteratorDef.PNAME_option, JUAccessorIteratorDef.PNAME_option_NEVER);
      accDef.init(map);
      DCDataControl dc = getIteratorBinding().getDataControl();
      DCBindingContainer bc = getBindingContainer();

      JUIteratorBinding iterBnd = (JUIteratorBinding)accDef.createIterBinding(dc, 
                                         bc, 
                                         parentIter.getRowSetIterator(),
                                         row, 
                                         childAccessorName);

      String iterName = iterBnd.getName();
      if (iterName == null)
      {
         iterName = childAccessorName;
         while (true)
         {
            iterName = JboNameUtil.getInstNameFromDefName(iterName);
            if (bc.findIteratorBinding(iterName) == null)
            {
               if (bc.findCtrlBinding(iterName) == null)
               {
                  break;
               }
            }
         }
         iterBnd.setName(iterName);
      }
      bc.addIteratorBinding(iterBnd.getName(), iterBnd);
      return iterBnd;
   }

   /**
   * Renders the attribute value that this node is supposed to show. This method is used
   * by JTree to display the String for a node in the tree.
   */
   public String toString()
   {
      if (mNodeValue == null)
      {
         return "";
      }

      return mNodeValue.toString();
   }

   /**
   * Returns the RowSetIterator that this node's row is part of. 
   * @javabean.property
   */
   public RowSetIterator getParentRowSetIterator()
   {
      return getIteratorBinding().getRowSetIterator();
   }

   /**
   * Returns the type binding that governs the display of this node. The returned object
   * can be used to find out the name of the attribute that this node displays and the
   * accessor that this row will expand (if any).
   else if (ATTR_ROW_KEY == key)
   {
      mInternalGet_KeyResolved = true;
      return getRowKey();
   }
   * @javabean.property
   */
   public final JUCtrlHierTypeBinding getHierTypeBinding()
   {
      return mTypeBinding;
   }
   
   //this is the public api that should be visible to spel via code-insight
   //we need to do a bean info for each of the control bindings to indicate
   //what apis are exposed in this method.
   public static final String ATTR_HIER_TYPE     = "hierType";
   public static final String ATTR_CHILDREN      = "children";
   public static final String ATTR_PARENT        = "parent";
   public static final String ATTR_ROW_KEY       = "rowKey";
   public static final String ATTR_PROMPT        = "prompt";
   public static final String ATTR_HIER_BINDING  = "hierbinding";
   public static final String ATTR_ROW           = "row";
   public static final String ATTR_ROW_DATA_PROVIDER = "dataProvider";
   
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>prompt</code> - returns get the value that this node displays()</li>
    * <li><code>children</code> - returns getChildren()</li>
    * <li><code>rowKey</code> - returns getRowKey()</li>
    * <li><code>hierType</code> - returns getHierTypeBinding()</li>
    * <li><code>hierBinding</code> - returns getHierBinding()</li>
    * <li><code>row</code> - returns getRow()</li>
    * <li><code>parent</code> - returns getParent()</li>
    */
   protected Object internalGet(String key)
   {
      key = key.intern();
      if (ATTR_CHILDREN == key)
      {
         mInternalGet_KeyResolved = true;
         return getChildren();
      }
      else if (ATTR_ROW == key)
      {
         mInternalGet_KeyResolved = true;
         return getRow();
      }
      else if (ATTR_ROW_DATA_PROVIDER == key)
      {
         Row row = internalGetRow();
         if (row instanceof oracle.adf.model.generic.RowImpl) 
         {
            mInternalGet_KeyResolved = true;
            return ((oracle.adf.model.generic.RowImpl)row).getDataProvider();
         }
      }
      else if (ATTR_ROW_KEY == key)
      {
         mInternalGet_KeyResolved = true;
         return getRowKey();
      }
      else if (ATTR_PARENT == key)
      {
         mInternalGet_KeyResolved = true;
         return getParent();
      }
      else if (ATTR_HIER_TYPE == key)
      {
         mInternalGet_KeyResolved = true;
         return getHierTypeBinding();
      }
      else if (ATTR_PROMPT == key)
      {
         mInternalGet_KeyResolved = true;
         return mNodeValue;
      }
      else if (ATTR_HIER_BINDING == key)
      {
         mInternalGet_KeyResolved = true;
         return getHierBinding();
      }
      else if (ROW_KEY_STR == key)
      {
         mInternalGet_KeyResolved = true;
         Key rowkey = getRowKey();
         return (rowkey != null) ? rowkey.toStringFormat(true) : "";
      }
      
      if (getIteratorBinding() != null)
      {
         //check attribute names.
         if (lookupAttributeDef(key) != null) 
         {
            mInternalGet_KeyResolved = true;
            return getInputValue(this, getAttributeIndexOf(key));
         }

         //check accessor name.
         String[] accnames = getHierTypeBinding().getAccessorNames();
         if (accnames != null) 
         {
            String accname;
            for (int i = 0; i < accnames.length; i++) 
            {
               accname = accnames[i];
               if (key.equals(accname))
               {
                  mInternalGet_KeyResolved = true;
                  ArrayList al = getChildren(accname);
                  if (al != null && al.size() == 1) 
                  {
                     //if list of one, then unbundle that and return the only node.
                     //this allows expression like <node>.<accessorName> get the row
                     //on which one can get attributes.
                     return al.get(0);
                  }
                  return al;
               }
            }
         }
         return super.internalGet(key);
      }
      else
      {
         //in batchmode, this node may have been 'released' due to refreshControl/
         //rangeRefreshed events. So find the latest Node at this key path and 
         //return value from that.
         JUCtrlHierNodeBinding node = getHierBinding().findNodeByKeyPath(getKeyPath());
         if (node != null)
         {
            mInternalGet_KeyResolved = true;
            return node.internalGet(key);
         }
         return null;
      }
   }
  /**
   *
   * @javabean.property
   */
   public Row getRow()
   {
      if (getRowIterator() == null)
      {
         return null;
      }
      return internalGetRow();
   }

   protected Row internalGetRow()
   {
      if (mRowRef != null)
      {
         Row row = (Row)mRowRef.get();
         if (row == null)
         {
            Row rows[] = getRowIterator().findByKey(mRowKey, 1);
            if (rows.length == 0 || rows[0] == null)
            {
               throw new RowNotFoundException(false, getIteratorBinding().getDisplayName(), mRowKey);
            }
            row = rows[0];
         }
         return row;
      }
      return null;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      if (getRowIterator() == null)
      {
         return;
      }

      refresh(internalGetRow());
   }

   public void updateNavigated(oracle.jbo.NavigationEvent event)
   {

   }

   public void updateRangeScrolled(oracle.jbo.ScrollEvent event)
   {

   }

   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons){}
   
   public void setValueAt(Object value, int rowIndex, int attrIndex)
   {
   }
   
   public ArrayList getKeyPath()
   {
      ArrayList al = new ArrayList();
      JUCtrlHierNodeBinding node = this;
      while (node != null)
      {
         if (node.getRowKey() == null)
         {
            break;
         }
         al.add(0, node.getRowKey());
         node = node.getParent();
      }
      return al;
   }
}
