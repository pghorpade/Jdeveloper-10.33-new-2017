/*
 * @(#)JUCtrlHierDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;

public class JUCtrlHierDef extends JUCtrlRangeDef
{
   private JUCtrlHierTypeBinding[] mTypeBindings;

   public static final String PNAME_TypeBindings = "TypeBindings";


   public JUCtrlHierDef()
   {
      setControlBindingClassName(JUCtrlHierBinding.class.getName());
   }


   public JUCtrlHierDef(String name, String controlClassName,
                        String controlBindingClassName, String iterBindingName,
                        String[] attrNames, JUCtrlHierTypeBinding[] typeBindings)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName, attrNames);

      mTypeBindings = typeBindings;
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {

      return new JUCtrlHierBinding(control, 
                                   (JUIteratorBinding)getIterBinding(formBnd), 
                                   getAttrNames(),
                                   getTypeBindings());
   }


   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_TypeBindings)) != null)
      {
         mTypeBindings = (JUCtrlHierTypeBinding[]) val;
      }
   }
   
   
   public JUCtrlHierTypeBinding[] getTypeBindings()
   {
      return mTypeBindings;
   }

   protected void initSubType()
   {
      setSubType(PNAME_Tree);
   }

   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      loadTypeBindingDef(xmlElement);
   }

   
   void loadTypeBindingDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList typeBindings = xmlElement.getChildrenList(JUCtrlHierTypeBinding.PNAME_TYPE);

      if (typeBindings != null)
      {
         JUCtrlHierTypeBinding[] typeBindingArr = new JUCtrlHierTypeBinding[typeBindings.size()];

         for (int j = 0; j < typeBindings.size(); j++)
         {
            DefElement typeBindingXML = (DefElement) typeBindings.get(j);
            JUCtrlHierTypeBinding typeBinding = (JUCtrlHierTypeBinding) DCDefBase.createAndLoadFromXML(typeBindingXML, null);

            typeBindingArr[j] = typeBinding;
         }

         mTypeBindings = typeBindingArr;
      }
      
      typeBindings = xmlElement.getChildrenList(oracle.jbo.uicli.mom.JUTags.PNAME_treeNodeDefinition);

      if (typeBindings != null && typeBindings.size() > 0)
      {
         JUCtrlHierTypeBinding[] typeBindingArr = new JUCtrlHierTypeBinding[typeBindings.size()];

         for (int j = 0; j < typeBindings.size(); j++)
         {
            DefElement typeBindingXML = (DefElement) typeBindings.get(j);
            JUCtrlHierTypeBinding typeBinding = (JUCtrlHierTypeBinding) DCDefBase.createAndLoadFromXML(typeBindingXML, null);

            typeBindingArr[j] = typeBinding;
         }

         mTypeBindings = typeBindingArr;
      }
   }

   
  
}
