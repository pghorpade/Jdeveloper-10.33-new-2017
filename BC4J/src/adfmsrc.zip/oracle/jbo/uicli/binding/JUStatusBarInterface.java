/*
 * @(#)JUStatusBarInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.adf.model.binding.DCStatusBarInterface;

/**
 * Implements status messages based on the current focus, current iterator, and current display mode of 
 * a JUPanel. Various JClient control bindings and Panel bindings use this interface to update
 * their status and the classes implementing this interface (typically a StatusBar) can display
 * these status messages. Messages that are MsgId0based could be found in UIMessageBundle class.
 * <p>
 * Applications could implement this interface to manage focus, currency and display status messages
 * in a custom manner and register the implementing class with a JUPanelBinding to get these messages.
 * <p>
 * @see oracle.jbo.uicli.UIMessageBundle
 */
public interface JUStatusBarInterface extends DCStatusBarInterface
{
}
