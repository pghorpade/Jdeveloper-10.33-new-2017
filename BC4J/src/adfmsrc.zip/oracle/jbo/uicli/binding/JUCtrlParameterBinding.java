/*
 * @(#)JUCtrlParameterBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.Map;

import oracle.jbo.AttributeDef;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.ScrollEvent;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCUtil;
import oracle.jbo.uicli.UIMessageBundle;

/**
 * A JUControlBinding class responsible for binding controls/models
 * that are bound to a single Row object in the BC4J layer.
 * This class is responsible for:
 * <ul>
 * <li>Updating the Control Bindings with attribute values
 * from the BC4J Row object for all attributes that this Control Binding is bound to.
 * <li>Enabling/disabling the control based on whether the corresponding Row's attribute
 * is updateable.
 * </ul>
 * <p>
 * This class defines the abstract APIs for subclasses to implement, so that
 * Row's attributes can be passed to the Binding object for appropriate display/update.
 */
public class JUCtrlParameterBinding extends JUCtrlAttrsBinding 
{

   /**
   * *** For internal framework use only ***
   */
   protected JUCtrlParameterBinding()
   {
      mObjAttrBinding = BIND_VO_ATTR;
   }

   /**
   * Creates a binding between the given control and attributes in the Rows returned
   * by the passed in Iterator Binding.
   */
   public JUCtrlParameterBinding(Object control, String expression)
   {
      super(control, null, new String[] {expression});
      mObjAttrBinding = BIND_VO_ATTR;
   }

   /**
   * Gets the value from the control for the attribute at the given index.
   * (The index is calculated from the list of attributes this control binding is
   * bound to as passed in the constructor).
   * Framework uses this method to get the attribute value from the control
   * and pass it on to the Row object on the BC4J side.
   */
   public Object getValueAt(int attrIndex)
   {
      return getAttribute(attrIndex);
   }

   /**
   * Updates the control/control-binding with the latest value of the
   * attribute at the given index with the given value. This method is used
   * by the framework to update the control with attribute values from a BC4J row.
   */
   public void setValueAt(Object value, int attrIndex)
   {
   }

   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
   }

   /*
   * Applications should use this method to update the value for an attribute 
   * at the given index on both a control as well as a BC4J row, where the index
   * is calculated from the list of attributes to which control is bound
   * in its constructor). For controls that are bound to one attribute,
   * pass in 0 for attrIndex.
   */
   public void setDataValueAt(Object value, int attrIndex)
   {
      setAttributeValue(value);
   }
   
   
   /**
   * Passes on the first row from the given array of rows to 
   * updateValuesFromRow() method to update the bound control's display.
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      updateValuesFromRow(null);
   }

   
   /**
   * Overridden as a no-op. Since this control is bound to only one row,
   * when that row becomes current the framework uses updateValuesFromRow to
   * update the display
   */
   public void updateRangeScrolled(ScrollEvent event)
   {
   }


   /**
   * Overridden as a no-op. Since this control is bound to only one row,
   * when that row becomes current the framework uses updateValuesFromRow to
   * update the display
   */
   public void updateNavigated(NavigationEvent event)
   {
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {   
      updateValuesFromRow(null);
   }
   

   /**
    * Parameters are not queriable, should not participate in findmode
    */
   protected final boolean isControlQueriable()
   {
      return false;
   }

   /**
    * return true if this binding is not marked READONLY
    */
   protected boolean isAttributeUpdateable(Row row, int index)
   {
      return !getParameterDef().isReadOnly();
   }

   /**
    * Return this binding's definition in an AttributeDef[].
    */
   public final AttributeDef[] getAttributeDefs()
   {
      return new AttributeDef[] {(AttributeDef)getParameterDef()};
   }

   final JUCtrlParameterDef getParameterDef()
   {
      return (JUCtrlParameterDef)getDef();
   }


   Object mValue;
   Object internalGetAttributeValueFromRow(Row row, int index)
   {
      if (mValue != null)
      {
         return mValue;
      }
      JUCtrlParameterDef def = getParameterDef();
      DCBindingContainer ctr = getBindingContainer();
      
      //if this value is final, then go the BindingContext to get the value.
      //if this value is required, then go to parent and return the value.
      //if this value is optional, go to parent first, then go to bindingcontext.
      Object value = null;
      if (!def.isFinal()) 
      {                            
         JUCtrlParameterBinding aliasParam = null;
         if (ctr.aliasExists(getName()) && ctr.getRegionContainer() != null)
         {
            value = ctr.getRegionContainer().evaluateParameter(ctr.getParameterAlias(getName()), false);
         }
         if (def.isMandatory()) 
         {
            if (value == null) 
            {
               throw new oracle.jbo.InvalidParamException(UIMessageBundle.class, 
                                                          UIMessageBundle.EXC_MANDATORY_PARAMETER,
                                                          new Object[]{getName()});
            }
            return value;
         }
      }

      if (value == null)
      {
         value = ctr.evaluateParameter(getParameterDef().getExpression(), true);
      }
      return value;
   }

   void internalSetAttribute(Object value)
   {
      //put the value back into the expression location.
      if (getParameterDef().isFinal()) 
      {
         throw new oracle.jbo.InvalidParamException(UIMessageBundle.class, 
                                                    UIMessageBundle.EXC_FINAL_PARAMETER,
                                                    new Object[]{getName()});
      }
      mValue = value;
   }

   void setError(oracle.jbo.JboException vex, Object value, boolean reportException)
   {
      try
      {
         super.setError(vex, value, reportException);
      }
      finally
      {
         if (getParameterDef().isFinal()) 
         {
            mHasInputVal = false;
            mInputVal = null;
         }
      }
   }

}
