/*
 * @(#)JUCtrlAttrsDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;


public class JUCtrlAttrsDef extends JUCtrlValueDef
{
   public JUCtrlAttrsDef()
   {
   }

   protected void initSubType()
   {
      setSubType(PNAME_DefaultControl);
   }

   public JUCtrlAttrsDef(String name, String controlClassName,
                         String controlBindingClassName, String iterBindingName,
                         String[] attrNames)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName, attrNames);
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      //kava creates bindings with null iterators as well.
      return new JUCtrlAttrsBinding(control, 
                                    (getIterBindingName() != null)
                                       ? this.getIterBinding(formBnd)
                                       : null, 
                                    getAttrNames());
   }

}
