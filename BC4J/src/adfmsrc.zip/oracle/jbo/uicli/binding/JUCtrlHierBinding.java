/*
 * @(#)JUCtrlHierBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;
import oracle.jbo.Row;
import java.util.ArrayList;
import java.util.List;

import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
/**
 *
 * @javabean.class name=JUCtrlHierBinding
 */
public class JUCtrlHierBinding extends JUCtrlRangeBinding
{
   protected JUCtrlHierTypeBinding[] mTypeBindings;
   protected JUCtrlHierNodeBinding mRootBinding = null;
   private boolean mAutoSync = true;


   public JUCtrlHierBinding(Object control, JUIteratorBinding iterBinding,
                            String[] attrNames, JUCtrlHierTypeBinding[] typeBindings)
   {
      super(control, iterBinding, attrNames);

      mTypeBindings = typeBindings;
   }


   /**
   * Returns the root node binding that contains the iterator that the root node is displaying.
   *
   * @javabean.property
   */
   public JUCtrlHierNodeBinding getRootNodeBinding()
   {
      if (mRootBinding == null)
      {
         //try executing the iterator
         DCIteratorBinding iter = getIteratorBinding();
         if (iter != null && iter.refreshIfNeeded())
         {
            iter.executeQueryIfNeeded();
         }
      }
      return mRootBinding;
   }

   protected void clearRootBinding()
   {
      mRootBinding = null;
   }

   public JUCtrlHierTypeBinding[] getTypeBindings()
   {
      return mTypeBindings;
   }
   
   /**
   * This method is called in the framework when values of a single row need to be 
   * updated in a control (typically on a navigation event). 
   */
   public void updateValuesFromRow(Row row)
   {
      //do nothing.
      //copied from tree.
   }

   /**
   * <b>Advanced method:</b> <em>Applications should not use this method
   */
   protected JUCtrlHierNodeBinding restoreTreeAndExpand(ArrayList al)
   {
      updateValuesFromRows(getIteratorBinding().getAllRowsInRange(), true);
      return findNodeByKeyPath(al);
   }

   
   /**
   * Updates the nodes in the tree based on the given set of rows. Clears the existing
   * display if clear flag is true.
   */
   public void updateValuesFromRows(Row[] rows, boolean clear)
   {
      if (mRootBinding == null)
      {
         createRootBinding();
      }

      if(mRootBinding != null)
      {
         //no need to call super as rootbinding is doing all the work.
         mRootBinding.updateValuesFromRows(rows, clear);
      }
   }

   protected void createRootBinding()
   {
      mRootBinding = createNodeBinding(null, getIteratorBinding(),  
                     (mTypeBindings != null && mTypeBindings.length > 0) ? mTypeBindings[0] : null,
                      null, true);
   }

   protected JUCtrlHierNodeBinding createNodeBinding(JUCtrlHierNodeBinding parent,
                                                     JUIteratorBinding iterBinding, 
                                                     JUCtrlHierTypeBinding typeBinding, 
                                                     Row row,
                                                     boolean expandable)
   {
      return new JUCtrlHierNodeBinding(this,
                                       parent,
                                       iterBinding,
                                       typeBinding,
                                       row,
                                       expandable);
   }
   
   //this is the public api that should be visible to spel via code-insight
   //we need to do a bean info for each of the control bindings to indicate
   //what apis are exposed in this method.
   public static final String ATTR_ROOTNODE     = "rootNodeBinding";
   public static final String ATTR_CHILDREN     = JUCtrlHierNodeBinding.ATTR_CHILDREN;
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>rootNodeBinding</code> - returns getRootNodeBinding()</li>
    * <li><code>children</code> - returns getRootNodeBinding().getChildren()()</li>
    */
   protected Object internalGet(String key)
   {
      key = key.intern();
      if (ATTR_ROOTNODE == key)
      {
         mInternalGet_KeyResolved = true;
         return getRootNodeBinding();
      }
      if (ATTR_CHILDREN == key)
      {
         mInternalGet_KeyResolved = true;
         return getChildren();
      }
      return super.internalGet(key);
   }

   /**
    * *** For internal framework use only ***
    * Returns children of the root node for easy el-access.
    */
   public List getChildren()
   {
      JUCtrlHierNodeBinding node = getRootNodeBinding();
      return (node != null) ? node.getChildren() : null;
   }

   boolean isAutoSyncEnabled()
   {
      return mAutoSync;
   }

   void setAutoSyncEnabled(boolean flag)
   {
      mAutoSync = flag;
   }
   
   public JUCtrlHierNodeBinding findNodeByKeyPath(List al)
   {
      JUCtrlHierNodeBinding node = (JUCtrlHierNodeBinding)this.getRootNodeBinding();
      JUCtrlHierNodeBinding child = node;
      int i = 0;
      for (; i < al.size(); i++)
      {
         child = (JUCtrlHierNodeBinding)node.findChildNode((oracle.jbo.Key)al.get(i));
         if (child == null)
         {
            break;
         }
         node = child;
      }
      return (i == al.size()) ? node : null;
   }

   private boolean mNotSyncAndExpand = true;
   ArrayList syncAndExpand(DCDataControl dc, JUCtrlHierNodeBinding node)
   {
      if (mNotSyncAndExpand)
      {
         mNotSyncAndExpand = false;
         try
         {
            ArrayList al = node.getKeyPath();
            ArrayList children = null;

            dc.sync("JUCtrlHierNodeBinding.executeQueryIfNeeded");

            //restore the entire tree from the first level down as 
            //sync brings back new RSIs for every level.
            JUCtrlHierNodeBinding newNode = restoreTreeAndExpand(al);
            if (newNode != null)
            {
               boolean treeSync = isAutoSyncEnabled();
               try
               {
                  newNode.setAutoSyncEnabled(false);
                  setAutoSyncEnabled(false);
                  //newNode should not sync again as it should have children
                  //if any by now due to sync().
                  children = newNode.getChildren();
               }
               finally
               {
                  newNode.setAutoSyncEnabled(node.isAutoSyncEnabled());
                  setAutoSyncEnabled(treeSync);
               }

            }
            if (children == null)
            {
               //found null, so no children.
               children = new ArrayList(0);
            }
            return children;
         }
         finally
         {
            mNotSyncAndExpand = true;
         }
      }
      return node.internalGetChildren();
   }

   protected JUCtrlHierNodeBinding internalGetRootNodeBinding()
   {
      return mRootBinding;
   }
}
