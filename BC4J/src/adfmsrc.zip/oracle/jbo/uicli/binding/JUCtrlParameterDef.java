/*
 * @(#)JUCtrlParameterDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.jbo.uicli.mom.JUTags;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeList;
import oracle.jbo.AttributeHints;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.JBOClass;
import oracle.jbo.format.Formatter;
import oracle.jbo.format.FormatterFactory;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.StringManager;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.rules.JboPrecisionScaleValidator;


import java.text.ParseException;

public class JUCtrlParameterDef extends JUCtrlAttrsDef implements AttributeDef, AttributeHints 
{
   
   /**
    * Binding definition has the expression to get to the value that should be used for this parameter.
    */
   public static int PARAM_FINAL    = 1; 
   
   /**
    * Binding definition's value is used only if the parameter is not specifically set by the caller.
    * This is the default.
    */
   public static int PARAM_OPTIONAL = 2; 
   
   /**
    * Parameter value has to be set by the caller.
    */
   public static int PARAM_MANDATORY = 3;
   

   /**
    * For internal use only.
    */
   public static int PARAM_DEFAULT = PARAM_OPTIONAL;
   
   
   private Class mJavaType = java.lang.String.class;
   private int mScale = -1;
   private int mPrecision = 0;
   private boolean mReadOnly;
   private boolean mApplyPrecision;
   private int mOption = PARAM_DEFAULT;

   private final byte         FORMAT_INFO_UNINITIALIZED = -1;
   private final byte         FORMAT_INFO_NOT_AVAILABLE = 0;
   private final byte         FORMAT_INFO_AVAILABLE     = 1;
   private byte               mHasFormatInfo = FORMAT_INFO_UNINITIALIZED;

   public JUCtrlParameterDef()
   {
   }

   protected void initSubType()
   {
      setSubType(JUTags.Parameter);
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      //kava creates bindings with null iterators as well.
      return new JUCtrlParameterBinding(control, getColumnName());
   }

   //*********************
   //*** AttributeDef  ***
   //*********************

   /**
   * *** For internal framework use only ***
   */
   public final byte getAttributeKind()
   {
      return ATTR_TRANSIENT;
   }

   /**
   *** For internal framework use only ***
   */
   public final String  getColumnName()
   {
      return getExpression();
   }

   public final String getExpression()
   {
      return getAttrNames()[0];
   }

   /**
    *** For internal framework use only ***
    */
   public final String  getColumnNameForQuery()
   {
      return getExpression();
   }

   /**
    * Always return 0.
    */
   public final int getIndex()
   {
      return 0;
   }

   /**
    * Returns javatype of the value that bound 
    * expression returns. 
    */
   public final Class getJavaType()
   {
      return mJavaType;
   }

   /**
    * Always return -1.
    */
   public final int getSQLType()
   {
      return -1;
   }

   /**
    * Return Scale value from metadata for this binding.
    */
   public final int getScale()
   {
      return mScale;
   }

   /**
    * Return Precision value from metadata for this binding.
    */
   public final int getPrecision()
   {
      return mPrecision;
   }

   /**
    * This binding is not queriable.
    */
   public final boolean isSelected()
   {
      return false;
   }

   /**
    * This binding is not queriable.
    */
   public final boolean isQueriable()
   {
      return false;
   }

   /**
    * Return Updateable flag from metadata for this binding.
    */
   public final boolean isReadOnly()
   {
      return mReadOnly;
   }

   public final byte getUpdateableFlag()
   {
      return (mReadOnly) ? READONLY: UPDATEABLE;
   }

   /**
    * Always return false
    */
   public final boolean isPrimaryKey()
   {
      return false;
   }

   public final boolean isApplyPrecision()
   {
      return mApplyPrecision;
   }

   public final boolean isMandatory()
   {
      return mOption == PARAM_MANDATORY;
   }

   public final boolean isOptional()
   {
      return mOption == PARAM_OPTIONAL;
   }

   public final boolean isFinal()
   {
      return mOption == PARAM_FINAL;
   }

   public int getOptionFlag()
   {
      return mOption;
   }

   /**
    * Returns this, as this object also implements AttributeHints interface
    */
   public final AttributeHints getUIHelper()
   {
      return this;
   }

   public final Class getElemType()
   {
      return null;
   }

   public final int getElemSQLType()
   {
      return -1;
   }

   //***********************
   //**** AttributeHints ***
   //***********************

   final String resolveResourceProperty(String property, LocaleContext locale)
   {
      Class clz = null;
      String retVal = null; 
      String clzName = getBindingContainerDef().getMessageBundleClassName();
      if (clzName != null) 
      {
         try
         {
            clz = JBOClass.forName(clzName);
         }
         catch (Exception e)
         {
            throw new JboException(e);
         }

         if (clz != null) 
         {

            String resName = (new StringBuffer(getName())).append("_").append(property).toString();
            retVal = StringManager.getLocalizedString(clz.getName(),
                                                    resName,
                                                    null,
                                                    ((locale != null) ? locale.getLocale() : null),
                                                    false);
         }
      }
      return retVal;
   }

   public final String getLabel(LocaleContext locale)
   {
      String sLabel = resolveResourceProperty(ATTRIBUTE_LABEL, locale);
      if(sLabel == null)
      {
         // use the attribute name
         sLabel = getName();
      }
      return sLabel;
   }

   public final String getTooltip(LocaleContext locale)
   {
      return resolveResourceProperty(ATTRIBUTE_TOOLTIP, locale);
   }

   public final String getDisplayHint(LocaleContext locale)
   {
      String sDisplayHint = resolveResourceProperty(ATTRIBUTE_DISPLAY_HINT, locale);
      
      if(sDisplayHint == null)
      {
         sDisplayHint = ATTRIBUTE_DISPLAY_HINT_DISPLAY;
      }

      return sDisplayHint;
   }

   public final int getControlType(LocaleContext locale)
   {
      String sValue = resolveResourceProperty(ATTRIBUTE_CTL_TYPE, locale); 

      if (sValue != null)
      {
         return Integer.parseInt(sValue);
      }

      return CTLTYPE_DEFAULT;
   }

   public final int getDisplayWidth(LocaleContext locale)
   {
      String sValue = resolveResourceProperty(ATTRIBUTE_CTL_DISPLAYWIDTH, locale); 

      if(sValue != null)
      {
         return Integer.parseInt(sValue);
      }
      return getPrecision();
   }

   public final int getDisplayHeight(LocaleContext locale)
   {
      String sValue = resolveResourceProperty(ATTRIBUTE_CTL_DISPLAYHEIGHT, locale); 

      if(sValue != null)
      {
         return Integer.parseInt(sValue);
      }

      return 1;
   }

   public final String getHint(LocaleContext locale, String sHintName)
   {
      if (sHintName.equals(ATTRIBUTE_LABEL))
      {
         return getLabel(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_TOOLTIP))
      {
         return getTooltip(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_CTL_DISPLAYWIDTH))
      {
         return Integer.toString(getDisplayWidth(locale));
      }
      else if (sHintName.equals(ATTRIBUTE_CTL_DISPLAYHEIGHT))
      {
         return Integer.toString(getDisplayHeight(locale));
      }
      else if (sHintName.equals(ATTRIBUTE_CTL_TYPE))
      {
         return Integer.toString(getControlType(locale));
      }
      else if (sHintName.equals(ATTRIBUTE_DISPLAY_HINT))
      {
         return getDisplayHint(locale);
      }
      else
      {
         return resolveResourceProperty(sHintName, locale);
      }
   }

   public final String getHintValue(LocaleContext locale, String sHintName)
   {
      return resolveResourceProperty(sHintName, locale);
   }
   
   public final String getFormat(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      return resolveResourceProperty(AttributeHints.FMT_FORMAT, locale);
   }

   
   public final String getFormatterClassName(LocaleContext locale)
   {
      return resolveResourceProperty(AttributeHints.FMT_FORMATTER, locale);
   }

   public final Formatter getFormatter(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      return FormatterFactory.getFormatter(getFormatterClassName(locale), locale);
   }

   
   public final boolean hasFormatInformation(LocaleContext locale)
   {
      if (mHasFormatInfo == FORMAT_INFO_UNINITIALIZED)
      {
         String   sFormatter = getFormatterClassName(locale);

         mHasFormatInfo = (sFormatter == null || sFormatter.equals("")) 
                       ? FORMAT_INFO_NOT_AVAILABLE 
                       : FORMAT_INFO_AVAILABLE;
      }

      return (mHasFormatInfo == FORMAT_INFO_AVAILABLE);
   }

   
   public final String getFormattedAttribute(AttributeList attrList, LocaleContext locale)
   {
      Object   aValue = attrList.getAttribute(getIndex());

      if(aValue == null)
          return null;

      if("".equals(aValue))
         return "";

      if(!hasFormatInformation(locale))
      {
         return aValue.toString();
      }

      try
      {
         Formatter   formatter = getFormatter(locale);
         String      sFormat = getFormat(locale);

         String sRet = formatter.format(sFormat, aValue);

         return sRet;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public final Object parseFormattedAttribute(String sValue, LocaleContext locale)
   {
       if(sValue == null)
           return null;

       if(sValue.equals(""))
          return "";

      if(!hasFormatInformation(locale))
      {
         return sValue;
      }

      try
      {
         Formatter formatter = getFormatter(locale);
         String    sFormat = getFormat(locale);

         formatter.setLocale(locale);

         Object newValue = formatter.parse(sFormat, sValue);

        // if the parser failed, just return the initial value
         if(newValue == null)
         {
            return sValue;
         }
          
         return newValue;
      }
      catch (ParseException parseEx)
      {
          return sValue;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }

   public final boolean displayInShortForm(LocaleContext locale)
   {
      return (AttributeHints.ATTRIBUTE_FORM_TYPE_SHORT.equals(resolveResourceProperty(AttributeHints.ATTRIBUTE_CTL_FORMTYPE, locale)));
   }

   public final String  getLocaleName(LocaleContext locale, String sName)
   {
      return JboNameUtil.getLocaleName(locale , sName);
   }

   //*********************
   //*** load routines ***
   //*********************
   public static final String PNAME_Value         ="value";
   public static final String PNAME_Type          ="type";
   public static final String PNAME_Scale         ="scale";
   public static final String PNAME_Precision     ="precision";
   public static final String PNAME_Option        ="option";
   public static final String PNAME_ReadOnly      ="readonly";
   public static final String PNAME_PrecisionRule ="applyPrecision";

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      readXMLString(xmlElement, PNAME_Type, valueTab);
      readXMLInt(xmlElement, PNAME_Scale, valueTab);
      readXMLInt(xmlElement, PNAME_Precision, valueTab);
      readXMLInt(xmlElement, PNAME_Option, valueTab);
      readXMLBoolean(xmlElement, PNAME_ReadOnly, valueTab);
      readXMLBoolean(xmlElement, PNAME_PrecisionRule, valueTab);

      com.sun.java.util.collections.ArrayList arrList = xmlElement.readStringArrayListElement(PNAME_AttrNames);
      if (arrList == null || arrList.size() == 0)
      {
         String str = xmlElement.readString(PNAME_Value);
         if (str != null) 
         {
            valueTab.put(PNAME_AttrNames, new String[]{str});
         }
      }
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      Object val;
      
      if ((val = initValues.get(PNAME_Type)) != null)
      {
         try
         {
            mJavaType = JBOClass.forName((String)val);
         }
         catch (Exception e)
         {
            throw new JboException(e);
         }
      }
      
      if ((val = initValues.get(PNAME_Scale)) != null)
      {
         mScale = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_Precision)) != null)
      {
         mPrecision = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_Option)) != null)
      {
         mOption = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_ReadOnly)) != null)
      {
         mReadOnly = convertToBoolean(val);
      }

      if ((val = initValues.get(PNAME_PrecisionRule)) != null)
      {
         mApplyPrecision = convertToBoolean(val);
      }

      if (mApplyPrecision)
      {
         JboPrecisionScaleValidator psval = new JboPrecisionScaleValidator();

         psval.setPrecision(mPrecision);
         psval.setScale(mScale);

         addValidator(psval);
      }
   }

}
