/*
 * @(#)JUControlDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCInvokeActionDef;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCDefFactory;
import oracle.adf.model.binding.DCParameterDef;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.binding.DefinitionFactory;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.graph.JUSingleTableGraphDef;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.common.JBOClass;

import org.w3c.dom.Element;

public class JUBindingDefFactoryImpl implements DCDefFactory, DefinitionFactory
{

   private HashMap mSubTypeMap;
   private void initSubTypeMap()
   {
      if (mSubTypeMap == null) 
      {
         mSubTypeMap = new HashMap(30);
         mSubTypeMap.put(JUTags.PNAME_attributeValue,                DCDefBase.PNAME_TextField);
         mSubTypeMap.put(JUTags.PNAME_attributeValues,               DCDefBase.PNAME_TextField);
         mSubTypeMap.put(JUTags.PNAME_action,                        DCDefBase.PNAME_Action);
         mSubTypeMap.put(JUTags.PNAME_methodAction,                  DCDefBase.PNAME_MethodAction);
         mSubTypeMap.put(JUTags.PNAME_defaultControl,                DCDefBase.PNAME_DefaultControl);
         mSubTypeMap.put(JUTags.PNAME_table,                         DCDefBase.PNAME_Table);
         mSubTypeMap.put(JUTags.PNAME_tree,                          DCDefBase.PNAME_Tree);
         mSubTypeMap.put(JUTags.PNAME_list,                          DCDefBase.PNAME_ComboBox);
         mSubTypeMap.put(JUTags.PNAME_listOfValues,                  DCDefBase.PNAME_ComboBox);
         mSubTypeMap.put(JUTags.PNAME_staticList,                    DCDefBase.PNAME_ComboBox);
         mSubTypeMap.put(JUTags.PNAME_dynamicList,                   DCDefBase.PNAME_ComboBox);
         mSubTypeMap.put(JUTags.PNAME_button,                        DCDefBase.PNAME_Button);
         mSubTypeMap.put(JUTags.PNAME_iterator,                      DCDefBase.PNAME_Iterator);
         mSubTypeMap.put(JUTags.PNAME_methodIterator,                DCDefBase.PNAME_MethodIterator);
         mSubTypeMap.put(JUTags.PNAME_accessorIterator,              DCDefBase.PNAME_AccessorIterator);
         mSubTypeMap.put(JUTags.PNAME_variableIterator,              JUTags.PNAME_variableIterator);
         mSubTypeMap.put(JUTags.PNAME_pageDefinition,                DCDefBase.PNAME_Panel);
         mSubTypeMap.put(JUTags.PNAME_invokeAction,                  JUTags.PNAME_invokeAction);
         //in good old days, no subtype was generated for BindingContainer or IteratorBinding.
         mSubTypeMap.put(JUTags.BindingContainer,                    DCDefBase.PNAME_Panel);
         // we need these for DT mapping of element to sub type
         mSubTypeMap.put(DCDefBase.PNAME_Iterator,                   DCDefBase.PNAME_Iterator);
         mSubTypeMap.put(DCDefBase.PNAME_MethodIterator,             DCDefBase.PNAME_MethodIterator);
         mSubTypeMap.put(DCDefBase.PNAME_AccessorIterator,           DCDefBase.PNAME_AccessorIterator);
         mSubTypeMap.put(JUTags.PNAME_treeNodeDefinition,            JUTags.PNAME_treeNodeDefinition);
         mSubTypeMap.put(JUTags.PNAME_graph,                         DCDefBase.PNAME_Graph);
      }
   }

   public String getSubTypeForElement(Element element)
   {
      initSubTypeMap();
      return (String)mSubTypeMap.get(element.getLocalName());
   }
   
   public DCDefBase createDefinition(DefElement element)
	{
      initSubTypeMap();
      String elemName = element.getLocalName();
      String subtype = element.readString(JUTags.SubType);

      if(subtype == null)
      {
         subtype = (String)mSubTypeMap.get(elemName);
      }

      if (subtype == null) 
      {
         if (elemName.equals(JUTags.parameter))
         {
            return new DCParameterDef();
         }
         //in good old days, we had elementNames as subtypes for
         //bindingContainer, iterator, methoditerator and accessoriterator.
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Warning! JUBindingDefFactoryImpl: assuming elementname as subtype for :"+elemName);
         }
         subtype = elemName;
      }
		
      DCDefBase ctrlDef= createControlDef(subtype);
      if (elemName.equals(JUTags.PNAME_staticList)) 
      {
         JUCtrlListDef def = (JUCtrlListDef)ctrlDef;
         def.setStaticList(true);
      }
      else if(elemName.equals(JUTags.PNAME_button))
      {
         JUCtrlBoolDef def = (JUCtrlBoolDef)ctrlDef;
         def.setSubType(oracle.adf.model.binding.DCDefBase.PNAME_Button);
         def.setControlBindingClassName(JUCtrlBoolBinding.class.getName());
      }
      
      if (ctrlDef == null) 
      {
         throw new RuntimeException("Factory could not create definition from element: " + elemName);
      }
      return ctrlDef;
	}
    
   public DCDefBase createControlDef(String subType)
   {
      DCDefBase ctrlDef = null;
      if(subType.equals(DCDefBase.PNAME_Iterator))
      {
         ctrlDef = new JUIteratorDef();
      }
      else if(subType.equals(DCDefBase.PNAME_MethodIterator))
      {
         ctrlDef = new JUMethodIteratorDef();
      }
      else if(subType.equals(DCDefBase.PNAME_AccessorIterator))
      {
         ctrlDef = new JUAccessorIteratorDef();
      }
      else if (subType.equals(DCDefBase.PNAME_Action))
      {
         ctrlDef = new JUCtrlActionDef();
      }
      else if (subType.equals(DCDefBase.PNAME_MethodAction))
      {
         ctrlDef = new JUCtrlActionDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_TextField))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Label))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Button))
      {
         ctrlDef = new JUCtrlBoolDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ComboBox))
      {
         ctrlDef = new JUCtrlListDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ButtonGroup))
      {
         ctrlDef = new JUCtrlListDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_DefaultControl))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Graph))
      {
         //ctrlDef = new JUSingleTableGraphDef();
         //fix for bug 4331479.
         ctrlDef = createGraphDef(); 
      }
      else  if (subType.equals(DCDefBase.PNAME_ListSingleSel))
      {
         ctrlDef = new JUCtrlListDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ScrollBar))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ScrollBarAttr))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Table))
      {
         ctrlDef = new JUCtrlRangeDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_DynamicTable))
      {
         ctrlDef = new JUCtrlRangeDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Tree))
      {
         ctrlDef = new JUCtrlHierDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ProgressBar))
      {
         ctrlDef = new JUCtrlRangeDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_ProgressBarAttr))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_Slider))
      {
         ctrlDef = new JUCtrlRangeDef();
      }
      else  if (subType.equals(DCDefBase.PNAME_SliderAttr))
      {
         ctrlDef = new JUCtrlAttrsDef();
      }
      else if (subType.equals(DCDefBase.PNAME_Panel))
      {
         ctrlDef = new JUFormDef();
      }
      else if (subType.equals(JUTags.PNAME_invokeAction))
      {
         ctrlDef = new DCInvokeActionDef();
      }
      else if (subType.equals(DCDefBase.PNAME_HGrid))
      {
         ctrlDef = (DCDefBase)DCUtil.createNewInstance("oracle.jbo.uicli.uix.JUCtrlHGridDef");

      }
      else if(subType.equals(JUTags.PNAME_variableIterator))
      {
         ctrlDef = new JUVariableIteratorDef();
      }
      else if (subType.equals(JUTags.PNAME_treeNodeDefinition)) 
      {
         ctrlDef = new JUCtrlHierTypeBinding();
      }
      return ctrlDef;
   }

    private DCDefBase createGraphDef()
    {
        try
        {
            Class c = JBOClass.forName("oracle.jbo.uicli.graph.JUSingleTableGraphDef"); // NOTRANS

            return (DCDefBase)c.newInstance(); 
        }
        catch(ClassNotFoundException cnfe)
        {
            oracle.jbo.common.DebugDiagnostic.println(cnfe.getMessage());
        }
        catch(IllegalAccessException iae)
        {
            oracle.jbo.common.DebugDiagnostic.println(iae.getMessage());
        }
        catch(InstantiationException ie)
        {
            oracle.jbo.common.DebugDiagnostic.println(ie.getMessage());
        }
        return null;
    }    
}
