/*
 * @(#)JUFormDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.adf.model.binding.DCBindingContainerDef;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.layout.DCLayoutDef;

import oracle.jbo.VariableValueManager;
import oracle.jbo.VariableManagerOwner;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;


public class JUFormDef extends DCBindingContainerDef
{
   
   public JUFormDef()
   {
      super();
      mBindingContainerClassName = JUFormBinding.class.getName();
   }


   public JUFormDef(DefPersistable outer)
   {
      super(outer);
      mBindingContainerClassName = JUFormBinding.class.getName();
   }


   public JUFormDef(DCLayoutDef layoutDef, String formClassName, String formBindingClassName)
   {
      super(layoutDef, formClassName, formBindingClassName);
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      
      if ((val = initValues.get(PNAME_FormClass)) != null)
      {
         mFormClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_BindingContainerClass)) != null)
      {
         mBindingContainerClassName = val.toString();
      }
   }

   public VariableValueManager ensureVariableManager()
   {

      VariableValueManager varIter = getVariableManager();
      if (varIter == null) 
      {
         VariableManagerOwner varMgr = getVariableManagerOwner();
         if (varMgr == null) 
         {
            varMgr = (VariableManagerOwner)((JUBindingDefFactoryImpl)JUMetaObjectManager.
                        getJUMom()
                        .getControlDefFactory())
                        .createControlDef(JUTags.PNAME_variableIterator);
            addIterator((DCIteratorBindingDef)varMgr);
         }
         varIter = varMgr.ensureVariableManager();
      }

      return varIter;
   }

}
