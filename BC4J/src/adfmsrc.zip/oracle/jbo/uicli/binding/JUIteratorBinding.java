/*
 * @(#)JUIteratorBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import oracle.jbo.ApplicationModule;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;

import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.BindingContext;

import oracle.jbo.common.Diagnostic;

/**
 * JUIteratorBinding is the binding class that interacts with BC4J RowIterator objects
 * to iterate over rows and provide the current row(s) to display to various control
 * bindings. JUIteratorBinding objects are named and uniquely identified by name in a 
 * JUFormBinding which acts as a container of iterator bindings. This class handles the 
 * events generated from the associated BC4J RowIterator and sends the current Row (rows 
 * in range) over to individual control bindings to display current data. This class also 
 * manages the findMode data for the associated BC4J iterator and ViewObject.
 * <p>
 * At runtime, an application can bind an instance of oracle.jbo.NavigatableRowIterator
 * to a JUIteratorBinding object using the <code>bindRowSetIterator</code> method.
 * @javabean.class name=JUIteratorBinding
 */
public class JUIteratorBinding extends DCIteratorBinding
{

   protected JUIteratorBinding()
   {
      super();
   }

   protected JUIteratorBinding(JUIteratorBinding iterBinding)
   {
      super(iterBinding);
   }

   public JUIteratorBinding(BindingContext ctx, String dcName, String sourceName, String rsiName, int rangeSize)
   {
      super(ctx, dcName, sourceName, rsiName, rangeSize);
   }

   /**
   * Use this constructor if a usage needs a specific range size on the associated iterator.
   * Objects of type JUCtrlRangeBinding may use this constructor to specify a default
   * range size for the iterator. 
   */
   public JUIteratorBinding(ApplicationModule am, String voName, String rsiName, int rangeSize)
   {
      super(am, voName, rsiName, rangeSize);
   }

   /**
   * When the usage only needs one row at a time, use this constructor to create
   * an iterator binding.
   */
   public JUIteratorBinding(ApplicationModule am, String voName, String rsiName)
   {
      super(am, voName, rsiName, 1);
   }


   /**
   * When an application has a BC4J RowSet it should use this constructor.
    * @deprecated since 9.0.5.1 use constructor with DCDataControl instead.
   */
   public JUIteratorBinding(RowSetIterator rsi)
   {
      super(null, rsi);
   }


   /**
   * When an application has a BC4J RowSet it should use this constructor.
   */
   public JUIteratorBinding(DCDataControl dataControl, RowSetIterator rsi)
   {
      super(dataControl, rsi);
      if (dataControl == null)
      {
         oracle.jbo.common.Diagnostic.println("ADFm Warning: Need to pass a valid DataControl JUIteratorBinding(DCDataControl, RowSetIterator");
      }
   }

 /**
  *
  * @javabean.property
  */
   public DCDataControl getApplication()
   {
      return getDataControl();
   }


   /**
   * *** For internal framework use only ***
   */
   public void setFormBinding(JUFormBinding formBnd)
   {
      super.setBindingContainer(formBnd);
   }

   /**
    *
    * @javabean.property
    */
   public JUFormBinding getFormBinding()
   {
      return (JUFormBinding)super.getBindingContainer();
   }
   /**
   * *** For internal framework use only ***
   * <p>
   * This method invokes updateRangeScrolled method on all instances of
   * JUCtrlRangeBinding objects associated with this iterator binding,
   * to notify them of the change in current range of rows.
   */
   public void rangeScrolled(ScrollEvent event)
   {
      if (!isSuspendRowSetEventsHandling()) 
      {
         if (mRangeSize != 1) 
         {
            synchronized(getSyncLock())
            {
               ArrayList bndList = getValueBindingList();
      
               if (bndList != null) 
               {
                  for (int j = 0; j < bndList.size(); j++)
                  {
                     JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
         
                     if (bnd instanceof JUCtrlRangeBinding)
                     {
                        bnd.updateRangeScrolled(event);
                     }
                  }
               }
            }
         }
      }
      super.rangeScrolled(event);
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * If range size of this iterator binding is not 1, 
   * this method invokes updateRowInserted method on all instances of
   * JUCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   */
   public void rowInserted(InsertEvent event)
   {
      if (!isSuspendRowSetEventsHandling())
      {
         if (mRangeSize != 1) 
         {
            synchronized(getSyncLock())
            {
               ArrayList bndList = getValueBindingList();
      
               if (bndList != null) 
               {
                  for (int j = 0; j < bndList.size(); j++)
                  {
                     JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
            
                     bnd.updateRowInserted(event);
                  }
               }
            }
         }
      }
      super.rowInserted(event);
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   * If range size of this iterator binding is not 1, 
   * this method invokes updateRowDeleted method on all instances of
   * JUCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   * <p>
   * This method also sets the currency on the RowIterator to 
   * the next row (if available) or previous row (if available)
   * or simply a NO row by calling navigated() with no current row.
   */
   public void rowDeleted(DeleteEvent event)
   {
      if (!isSuspendRowSetEventsHandling())
      {
         NavigatableRowIterator iter = getNavigatableRowIterator();

         if (mRangeSize != 1) 
         {
            synchronized(getSyncLock())
            {
               ArrayList bndList = getValueBindingList();
      
               if (bndList != null) 
               {
                  for (int j = 0; j < bndList.size(); j++)
                  {
                     JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);
         
                     bnd.updateRowDeleted(event);
                  }
               }
            }
         }
      }
      
      super.rowDeleted(event);
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Calls updateNavigated() for all JUCtrlRangeBinding instances associated
   * with this iterator binding object, or calls updateValuesFromRow() on 
   * all other control binding instances, passing in the current row instance
   * from the RowIterator.
   */
   public void navigated(NavigationEvent event)
   {
      if (!isSuspendRowSetEventsHandling())
      {
         if (!inExecute)
         {
            synchronized(getSyncLock())
            {
               ArrayList bndList = getValueBindingList();
               if (bndList != null) 
               {
                  Row r = (isRefreshed()) ? getCurrentRow() : event.getRow();
                  if (event.getRow() == null && r != null)
                  {
                     //incase of reset, getCurrentRow() will force
                     //the first row to be current. That means we need
                     //to send the adjusted NavigationEvent to the bindings.
                     event = new NavigationEvent((NavigatableRowIterator)event.getSource(), null, r);
                  }
                  for (int j = 0; j < bndList.size(); j++)
                  {
                     JUCtrlValueBinding bnd = (JUCtrlValueBinding) bndList.get(j);

                     if (bnd instanceof JUCtrlRangeBinding)
                     {
                        ((JUCtrlRangeBinding)bnd).updateNavigated(event);
                     }
                     else if (bnd instanceof JUCtrlHierNodeBinding)
                     {
                        ((JUCtrlHierNodeBinding)bnd).updateNavigated(event);
                     }
                     else 
                     {
                        bnd.updateValuesFromRow(r);
                     }
                  }
               }
            }
            super.navigated(event);
         }
      }
   }


   /**
   * Calls updateValuesFromRows() on each instance of JUCtrlRangeBinding object
   * associated with this iterator binding object. These objects are then responsible for
   * updating their display with the latest set of rows.
   */
   protected void updateValuesFromRows(Row[] rows, Row row, boolean clear)
   {
      ArrayList bndList = getValueBindingList();

      if (bndList != null) 
      {
         Object bnd;
         for (int j = 0; j < bndList.size(); j++)
         {
            bnd = bndList.get(j);
   
            if (bnd instanceof JUCtrlRangeBinding)
            {
               ((JUCtrlRangeBinding)bnd).updateValuesFromRows(rows, clear);
            }
            else //if (row != null)  //this check leads to failure in null return updates for accessors.
            {
               ((JUCtrlValueBinding)bnd).updateValuesFromRow(row);
            }
         }
      }
   }

   protected void notifyUpdateEvent(UpdateEvent event)
   {
      ArrayList bndList = getValueBindingList();
      int[] attrIdxs = event.getChangedAttrIndices();
      JUCtrlValueBinding bind;
      if (bndList != null) 
      {
         for (int j = 0; j < bndList.size(); j++)
         {
            bind = (JUCtrlValueBinding)bndList.get(j);
            if (bind.hasBoundAttrChanged(attrIdxs))
            {
               bind.updateValuesFromRow(event.getRow());
            }
         }
      }
   }

   /**
   * Calls updateValueFromRow() on each instance of JUCtrlValueBinding objects
   * associated with this iterator binding object. These control binding objects are
   * responsible for updating their display with values from the given Row.
   */
   protected void updateValuesFromRow(Row row)
   {
      ArrayList bndList = getValueBindingList();

      if (bndList != null) 
      {
         for (int j = 0; j < bndList.size(); j++)
         {
            ((JUCtrlValueBinding)bndList.get(j)).updateValuesFromRow(row);
         }
      }
   }
   

   /**
   * Returns the instance of ApplicationModule in which this iterator binding has an associated iterator.
   * Returns null for non-bc4j bound DataControls
   * @javabean.property
   */
   public ApplicationModule getApplicationModule()
   {
      return mAM;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Used in LovButtonBinding to set the def for the Lov Panel's iteratorBinding.
    */
   public void setIteratorBindingDef(DCIteratorBindingDef iterDef)
   {
      if (getDef() == null)
      {
         setDef(iterDef);
      }
      else if (Diagnostic.isOn())
      {
         Diagnostic.println("This iterator binding "+getName()+" already has a definition.");
      }
   }

   /**
    * *** For internal framework use only ***
    */
   protected void cacheCreatedRow(RowSetIterator rsi, Row row)
   {
      super.mCreatedRowRef = row;
      //send navigation event.
      navigated(new oracle.jbo.NavigationEvent(rsi, rsi.getCurrentRow(), row));
      //navigated will kill this entry off.
      super.cacheCreatedRow(rsi, row);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   boolean hasCachedRow()
   {
      return (mCreatedRowRef != null);
   }
}
