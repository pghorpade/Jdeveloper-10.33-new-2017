/*
 * @(#)JUFormBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.ArrayList;
import oracle.jbo.AttributeHints;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.LocaleContext;
import oracle.jbo.NameClashException;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.ViewObject;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCControlBinding;


import oracle.jbo.VariableValueManager;
import oracle.jbo.VariableManagerOwner;
import oracle.jbo.uicli.mom.JUTags;

/**
 *
 * Corresponds to a Swing JFrame instance and manages bindings used in a 
 * frame. The JUFormBinding class provides:
 * <ul>
 * <li>Management of iterator binding instances. 
 * <li>Management of control bindings for declarative forms (**for internal framework use only**).
 * <li>Manages the findMode status and switches the iterator bindings into approrpriate mode.
 * <li>Helper methods for displaying messages in status bar.
 * <li>Helper methods for retrieving UIHints from BC4J ViewObject and attribute definitions.
 * </ul>
 * <p>
 * In the JClient Framework, JUPanelBinding extends this class and provides a home
 * to various iterator bindings and control bindings.
 * @see oracle.jbo.uicli.jui.JUPanelBinding
 * @javabean.class name=JUFormBinding
 */
public class JUFormBinding extends DCBindingContainer  
{

   protected ArrayList mNavigationBarList;

   /**
   * Default constrcutor.
   */
   public JUFormBinding()
   {
      super();
   }


   /**
   * Constructor used by JUPanelBinding, which passes in a reference to the JPanel object.
   */
   public JUFormBinding(Object panel)
   {
      super(panel);
   }

   
   /**
   * Returns the JUApplciation object to which this form binding belongs.
   * @javabean.property
   */
   public JUApplication getApplication()
   {
      return (JUApplication)getDataControl();
   }

   
   /**
   * Sets the JUApplication instance in this form binding and adds it to the
   * JUApplication. If this form binding is already registered with a JUApplication,
   * then it throws an InvalidOperException.
   * @throws InvalidOperException
   */
   public void setApplication(JUApplication app)
   {
      setDataControl(app);
      if (app != null)
      {
         app.addBindingContainer(this);
      }
   }

   
   /**
   * Returns the associated JPanel object.
   * @javabean.property
   */
   public final Object getPanel()
   {
      return getViewComponent();
   }

   /**
   * Sets internal member variable with the given panel instance.
   */
   protected void setPanelInternal(Object panel)
   {
      setViewComponentInternal(panel);
   }

   
   
   /**
   * Returns the iterator binding object of the given name.
   */
   public final JUIteratorBinding findIterBinding(String name)
   {
      return (JUIteratorBinding) findIteratorBinding(name);
   }

   
   /**
   * Adds the given iterator binding name with a framework generated name.
   */
   public final void addIterBinding(JUIteratorBinding iterBinding)
   {
      addIteratorBinding(null, iterBinding);
   }


   /**
   * Adds this iterator binding with this form with the given name.
   * @throws InvalidObjNameException if an invalid name is passed in.
   * @throws NameClashException if given a duplicate name.
   */
   public final void addIterBinding(String name, JUIteratorBinding iterBinding)
   {
      addIteratorBinding(name, iterBinding);
   }


   /**
   * If an iterator binding exists with the given name, remove it from the internal
   * members.
   */
   public final boolean removeIterBinding(String name)
   {
      return removeIteratorBinding(name);
   }


   /**
   * Clean all iterator bindings registered with this form.
   */
   public final void clearIterBindings()
   {
      clearIteratorBindings();
   }


   public final JUControlBinding findControlBinding(String name)
   {
      return (JUControlBinding) findCtrlBinding(name);
   }
   /**
   * *** For internal framework use only ***
   */
   public JUCtrlValueBinding findCtrlValueBinding(String name)
   {
      //cant be final as DT needs this.
      return (JUCtrlValueBinding) findCtrlBinding(name);
   }
   
   public final JUControlBinding getControlBinding(Object control)
   {
      ArrayList al = getCtrlBindingList();
      int size = al.size();
      Object bind;
      for (int i = 0; i < size; i++) 
      {
         bind = al.get(i);
         if (bind instanceof JUControlBinding) 
         {
            if (((JUControlBinding)bind).getControl() == control)
            {
               return ((JUControlBinding)bind);
            }
         }
      }
      return null;
   }



   /**
   * Return an Iterator Binding of the given "voIterBindingName" if one already exists by that name.
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that display just one row's attribute invoke this method to find
   * or create the iterator binding for which they display an attribute data.
   */
   public JUIteratorBinding getRowIterBinding(String        voInstanceName,
                                             String        voIterName, /**temporarily taking nulls for this*/
                                             String        voIterBindingName)
   {
      return (JUIteratorBinding) getIteratorBinding(voInstanceName, voIterName, voIterBindingName, 1);
   }

   /**
   * Return an Iterator Binding of the given "voIterBindingName", if one already exists by that name,
   * after setting up the iterator binding's range Size to the greater of existing range size and
   * the given range size. If range size is -1, that indicates all rows in the range and hence
   * takes precedence in the above comparison.
   * <p>
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that are capable of displaying more than one row of data invoke this
   * method to create their iterator binding with a preferred range size.
   */
   public JUIteratorBinding getRangeIterBinding(String       voInstanceName,
                                                 String       voIterName, /**temporarily taking nulls for this*/
                                                 String       voIterBindingName, 
                                                 int          rangeSize)
   {
      return (JUIteratorBinding) getIteratorBinding(voInstanceName, voIterName, voIterBindingName, rangeSize);
   }

   /**
   * Helper method to add the given object to the JUApplication's StatusBars.
   */
   public void addStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (mDataControl != null) 
      {
         mDataControl.addStatusBarInterface(statusBar);
      }
   }

   /**
   * Helper method to remove the given object to the JUApplication's StatusBars.
   */
   public void removeStatusBarInterface(JUStatusBarInterface statusBar)
   {
      if (mDataControl != null) 
      {
         mDataControl.removeStatusBarInterface(statusBar);
      }
   }

   /**
   * Adds a NavigationBar (or like object) that needs to listen into changes
   * in an iterator, and focus events, etc. By default the framework adds
   * all Navigation Bars bound to the Panel Binding object into this list, so
   * that these Navigation bars adjust their display based on current iterator
   * in focus/use.
   */
   public final void addNavigationBar(JUNavigationBarInterface navBar)
   {
      if (mNavigationBarList == null) 
      {
         mNavigationBarList = new ArrayList(5);
      }
      mNavigationBarList.add(navBar);
   }

   /**
   * Removes a JUNavigationBarInterface listener object from the list.
   */
   public final void removeNavigationBar(JUNavigationBarInterface navBar)
   {
      if (mNavigationBarList != null) 
      {
         mNavigationBarList.remove(navBar);
      }
   }


   /**
   * Helper method to display the given message and params via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(JUIteratorBinding iterBinding, String msgId, Object[] params)
   {
      if (mDataControl != null) 
      {
         mDataControl.displayStatus(iterBinding, msgId, params);
      }
   }

   /**
   * Helper method to display the given message string via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(String msg)
   {
      if (mDataControl != null) 
      {
         mDataControl.displayStatus(msg);
      }
   }


   //UI Hint support methods.

   AttributeHints getAttributeUIHelper(String voName, String attrName)
   {
      //for 904 only! databinding apps should go through controlBinding.getLabel()/tooltip calls.
      return getApplicationModule().findViewObject(voName).findAttributeDef(attrName).getUIHelper();
   }

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getLabel((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getTooltip((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **  Retrieves the display hint that dictates whether this
   **  attribute should be visible or not. The two possible values
   **  are:
   **  <ul>
   **  <li>ATTRIBUTE_DISPLAY_HINT_DISPLAY  = "Display";
   **  <li>ATTRIBUTE_DISPLAY_HINT_HIDE     = "Hide";
   **  </ul>
   **/
   public String getDisplayHint(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayHint((locale == null) ? getLocaleContext() : locale);
   }

   /***
   **    Returns the preferred control type for this attribute.
   **/
   public int getControlType(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getControlType((locale == null) ? getLocaleContext() : locale);
   }

   /**
   **    Returns the display width for this attribute.
   **/
   public int getDisplayWidth(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayWidth((locale == null) ? getLocaleContext() : locale);
   }

   /**
   **    Returns the display width for this attribute.
   **/
   public int getDisplayHeight(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).getDisplayHeight((locale == null) ? getLocaleContext() : locale);
   }

  /**
   ** Returns the hint value based on the hint name.
   **/

   public String getHint(String voName, String attrName, LocaleContext locale, String sHintName)
   {
      return getAttributeUIHelper(voName, attrName).getHint((locale == null) ? getLocaleContext() : locale, sHintName);
   }

   /**
    **   Returns true if any format hints have been defined for this
    **   attribute. This function should be used to bracket any calls
    **   to the formatting API.
    **/
   public boolean hasFormatInformation(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).hasFormatInformation((locale == null) ? getLocaleContext() : locale);
   }
   
   /**
    **   Returns true if the attribute is to displayed in the short(summary) form.
    **/
   public boolean displayInShortForm(String voName, String attrName, LocaleContext locale)
   {
      return getAttributeUIHelper(voName, attrName).displayInShortForm((locale == null) ? getLocaleContext() : locale);
   }

   //Overridden Control Hint methods to get Object Attribute hints as well.

   /***
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
      String str = getHint(voName, voAttrName, objectAttrName, locale, AttributeHints.ATTRIBUTE_LABEL);
      if (str == null) 
      {
         int index = objectAttrName.lastIndexOf('.');
         if (index > -1) 
         {
            str = objectAttrName.substring(index+1);
         }
         else
         {
            str = objectAttrName;
         }
      }
      return str;
   }

   /***
   **  Retrives the tooltip text to be used for this attribute.
   **/
   public String getTooltip(String voName, String voAttrName, String objectAttrName, LocaleContext locale)
   {
      return getHint(voName, voAttrName, objectAttrName, locale, AttributeHints.ATTRIBUTE_TOOLTIP);
   }

  /**
   ** Returns the hint value based on the hint name.
   **/
   public String getHint(String voName, String voAttrName, String objectAttrName, LocaleContext locale, String sHintName)
   {
      StringBuffer hintBuf = new StringBuffer();
      if (objectAttrName != null && objectAttrName.length() > 0) 
      {
         hintBuf.append(objectAttrName.replace('.','_')).append('_');
      }

      hintBuf.append(sHintName);
      return getAttributeUIHelper(voName, voAttrName).getHint((locale == null) ? getLocaleContext() : locale, hintBuf.toString());
   }

   /**
    * Returns an ordered list of ViewObject usages in this panel so that a JboException parameters
    * can be transformed from Entity-layer names and exception parameters to ViewObject names and parameters.
    * @javabean.property
    */
   public ViewObject[] getOrderedVOUsageList()
   {
      return super.getOrderedVOUsageList(this.getDataControl());
   }

   protected void initializeViewComponent(ArrayList controls) 
   {
      initializePanel(controls);
   }

   /**
   * *** For internal framework use only ***
   */
   public void initializePanel(ArrayList controls) {};

   /**
   * *** For internal framework use only ***
   * Used to setup reference to JUApplication and oracle.jbo.Application objects.
   */
   protected void initializeApplicationModule() {};
   
   /**
   * Associates this form binding object with a JPanel object.
   */
   public void setPanel(Object panel) {};
   
   /**
   * Invoked by the framework to notify various status bars of which control has gained the focus.
   */
   protected void focusGained(DCIteratorBinding iterBinding, DCControlBinding binding, int attrIndex) {};

   /**
   * Notify each listener of the iteratorChanged event when an iterator changes its data due to execute, 
   * re-execute, or change in display mode (find mode or data mode).
   */
   protected void notifyIteratorChanged(DCIteratorBinding iterBnd, boolean refresh) {};

   /**
    * Invoked when a JUIteratorBinding receives a rangeRefreshed Event from BC4J RowSetIterator
    * @param iter that received the rangeRefreshed event.
    * @param event a description of the new ranges.
    */
   protected void rangeRefreshed(DCIteratorBinding iter, RangeRefreshEvent event) {};

   /**
    * Invoked when a JUIteratorBinding receives a rangeScrolled Event from BC4J RowSetIterator
    * @param iter that received the rangeScrolled event.
    * @param event a description of the new range.
    */
   protected void rangeScrolled(DCIteratorBinding iter, ScrollEvent event) {};

   /**
    * Invoked when a JUIteratorBinding receives a rowInserted Event from BC4J RowSetIterator
    * @param iter that received the rowInserted event.
    * @param event a description of the new Row object.
    */
   protected void rowInserted(DCIteratorBinding iter, InsertEvent event) {};

   /**
    * Invoked when a JUIteratorBinding receives a rowDeleted Event from BC4J RowSetIterator
    * @param iter that received the rowDeleted event.
    * @param event a description of the deleted Row object.
    */
   protected void rowDeleted(DCIteratorBinding iter, DeleteEvent event) {};

   /**
    * Invoked when a JUIteratorBinding receives a rowUpdated Event from BC4J RowSetIterator
    * @param iter that received the rowUpdated event.
    * @param event a description of the modified Row object.
    */
   protected void rowUpdated(DCIteratorBinding iter, UpdateEvent event) {};

   /**
    * Invoked when a JUIteratorBinding receives a navigated Event from BC4J RowSetIterator
    * @param iter that received the navigated event.
    * @param event a description of the new and previous current rows.
    */
   protected void navigated(DCIteratorBinding iter, NavigationEvent event) {};


   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeRowNavigated() method to notify all validation listeners.
   */
   //protected void callBeforeRowNavigated(DCIteratorBinding iter)
   //{
   //   super.callBeforeRowNavigated(iter);
   //}
   
   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeSaveTransaction() method to notify all validation listeners.
   */
   //protected void callBeforeSaveTransaction(oracle.jbo.Transaction txn)
   //{
   //   super.callBeforeSaveTransaction(txn);
   //}

   protected DCIteratorBinding createIteratorBinding(String       voInstanceName,                                      
                                                     String       voIterName, 
                                                     String       voIterBindingName,                                 
                                                     int          rangeSize)
   {
      return new JUIteratorBinding(getApplicationModule(),
                                    voInstanceName,
                                    voIterName, rangeSize);
   }

   public VariableValueManager ensureVariableManager()
   {

      VariableManagerOwner varMan = getVariableManagerOwner();
      if (varMan == null) 
      {
         VariableValueManager varManDef = getDef().ensureVariableManager();
         JUVariableIteratorDef varDef = (JUVariableIteratorDef)varManDef.getVarMgrOwner();
         JUVariableIteratorBinding varIter = (JUVariableIteratorBinding)varDef.createIterBinding(getBindingContext(), this);
         addIteratorBinding(JUTags.PNAME_variableIterator, varIter);
         return varIter.ensureVariableManager();
      }

      return varMan.ensureVariableManager();
   }

   /**
   * *** For internal framework use only ***
    */
   protected oracle.adf.model.binding.DCDataControl internalGetDataControl()
   {
      return super.internalGetDataControl();
   }
}
