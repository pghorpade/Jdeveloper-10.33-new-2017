/*
 * @(#)JUCtrlBoolDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;

import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.mom.xml.DefElement;

public class JUCtrlBoolDef extends JUCtrlListDef
{
   private boolean mBoolVal = true;

   public static final String PNAME_BoolVal = "BoolVal";
   

   public JUCtrlBoolDef()
   {
      setStaticList(true);
   }


   public JUCtrlBoolDef(String name, String controlClassName,
                        String controlBindingClassName, String iterBindingName,
                        String[] attrNames, Object[] valueList, boolean boolVal)
   {
      super(name, controlClassName, controlBindingClassName, iterBindingName,
            attrNames, true /*staticList*/,
            null /*listVOName*/, null /*listRSIName*/, null /*listAttrName*/,
            valueList);

      mBoolVal = boolVal;
   }

   protected void initSubType()
   {
      setSubType(PNAME_Boolean);
   }
   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_BoolVal)) != null)
      {
         mBoolVal = convertToBoolean(val);
      }
   }
      
      
   public boolean isBoolVal()
   {
      return mBoolVal;
   }

   protected JUCtrlListBinding createListBindingInstance(
    Object control,
    DCIteratorBinding iterBinding,
    String[] attrNames,
    Object[] valueList)
   {
     return new JUCtrlBoolBinding(control, iterBinding, attrNames[0], valueList, mBoolVal);
   }

   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLBoolean(xmlElement, PNAME_BoolVal, valueTab);
      
      //super.retrieveFromXML turns static list to false.
      setStaticList(true);
   }
}
