/*
 * @(#)JUMethodIteratorDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import java.util.ArrayList;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.generic.DCGenericRowSetIteratorImpl;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.ScrollEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.DeleteEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.InvalidObjNameException;

import oracle.jbo.AttributeDef;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetListener;
import oracle.jbo.ViewObject;
import oracle.jbo.NoObjException;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.mom.JUMetaObjectBase;

public class JUAccessorIteratorDef extends JUIteratorDef
{

   String mBeanClass;
   String mAccessorName;
   String mMasterBindingName;
   boolean mTrackMasterRow;
   public static final String PNAME_MasterBinding = "MasterBinding";



   public JUAccessorIteratorDef()
   {
      super();
      setSubType(PNAME_AccessorIterator);
   }

   public JUAccessorIteratorDef(String accName,  String mName)
   {
      this(accName, mName, false);
   }

   public JUAccessorIteratorDef(String accName,  String mName, boolean trackMaster)
   {
      this();
      this.mAccessorName = accName;
      this.mMasterBindingName = mName; 

      //if true, then the iterator bindings will find the master by key
      //once they are created by the 'tree node bindings'.
      this.mTrackMasterRow = trackMaster;
   }

   public String getBeanClassName()
   {
      return mBeanClass;
   }
         
   public DCIteratorBinding createIterBinding(DCDataControl dc, DCBindingContainer bc, RowSetIterator rsi)
   {
      DCIteratorBinding binding = new MyIteratorBinding(this, dc, null);
      binding.setBindingContainer(bc);
      if(rsi != null)
      {
         binding.bindRowSetIterator(rsi, false);
      }
      return binding;
   }

   /**
    * Advanced internal.
    * Used by tree node to create accessor iterator bindings that track
    * the master by row key.
    */
   public DCIteratorBinding createIterBinding(DCDataControl dc, DCBindingContainer bc, 
                                              RowSetIterator masterRSI, Row masterRow, 
                                              String accName)
   {
      DCIteratorBinding iterBnd = createIterBinding(dc, bc, null);
      dc.createAccessorRowSetIterator(masterRSI, masterRow, iterBnd, accName, null);

      //save the master row key information
      if (mTrackMasterRow && masterRow != null)
      {
         ((MyIteratorBinding)iterBnd).initializeMasterRowRef(masterRow);
      }
      return iterBnd;
   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc, oracle.jbo.ApplicationModule anchorAM)
   {
      
      String voName = getBindsName();
      String dcName = null;
      /*
      if (getMasterBindingName() != null)
      {
         //voName is the master iterator name
         mMasterBinding = (JUIteratorBinding)bc.findIteratorBinding(getMasterBindingName());
         if (mMasterBinding == null)
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_ITER_BINDING, getMasterBindingName());
         }
         dcName = mMasterBinding.getDataControl().getName();
      }
      else
      */
      if ((voName != null) && (getMasterBindingName() == null))
      {
         int index = voName.indexOf('.');
         dcName = voName.substring(0, index);
      }
      
      return new MyIteratorBinding(this, ctx, dcName, 
                                   getBindsName(), 
                                   getRSIName(), 
                                   getRangeSize());
   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc)
   {
      return createIterBinding(ctx, bc, null);
   }

   /**
    * Advanced internal.
    */
   public ViewObject calcAccessorPath(DCIteratorBinding accBinding, StringBuffer buf)
   {
      DCBindingContainer bc = accBinding.getBindingContainer();
      JUAccessorIteratorDef accDef = this;
      DCIteratorBindingDef def;
      DCIteratorBinding masterIter = null;
      while (accDef != null)
      {
         if (buf.length() > 0)
         {
            buf.insert(0, '/');
         }
         buf.insert(0, accDef.getAccessorName());
         masterIter = bc.findIteratorBinding(accDef.getMasterBindingName());
         def = masterIter.getDef();

         // JRS bug 4888794 Added an extra check for a null def.  Also
         // added logic to detect if the master iterator binding 
         // is not an accessor binding by checking the type.  
         if (def != null)
         {
            if (def.getSubType() != PNAME_AccessorIterator)
            {
               break;
            }
         }
         else if (!(masterIter instanceof MyIteratorBinding))
         {
            break;
         }
         accDef = (JUAccessorIteratorDef)def;
      }
      return masterIter.getViewObject();
   }

   public final String getMasterBindingName()
   {
      return mMasterBindingName;
   }


   public String getAccessorName()
   {
      return (mAccessorName == null) ? getBindsName() : mAccessorName;
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      //bindsto contains the iteratorBinding name for the master
      //accessor contains the accessor name on the current row of the master
      readXMLString(xmlElement, JUTags.PNAME_Accessor, valueTab);
      readXMLString(xmlElement, PNAME_MasterBinding, valueTab);
      readXMLString(xmlElement, JUTags.BeanClass, valueTab);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      if ((val = initValues.get(JUTags.PNAME_Accessor)) != null)
      {
         mAccessorName = val.toString();
      }
      if ((val = initValues.get(PNAME_MasterBinding)) != null)
      {
         mMasterBindingName = val.toString();
      }
      if ((val = initValues.get(JUTags.BeanClass)) != null)
      {
         mBeanClass = val.toString();
      }
   }
}

class MyIteratorBinding extends JUIteratorBinding
{
   private boolean mHasResult;
   private JUIteratorBinding mMasterBinding;
   private Key mMasterRowKey;
   String  mResultName;
   RowSetIterator myRSI;

   public void release(int flags)
   {
      if ((flags & DCDataControl.REL_DATA_REFS) > 0)
      {
         releaseDataInternal();
      }
      super.release(flags);
   }

   protected void releaseDataInternal()
   {
      myRSI = null;
      mHasResult = false;
      RowSetIterator masterRSI = null;

      if (mMasterBinding != null)
      {
         masterRSI = (mMasterBinding.hasRSI()) ? mMasterBinding.getRowSetIterator() : null;
         if (masterRSI != null)
         {
            masterRSI.removeListener(mMasterListener);
         }
         mMasterBinding.removeDependentExecutable(this);
      }
      mMasterBinding = null;
      mMasterRowKey = null;

      super.releaseDataInternal();
   }

   MyIteratorBinding(JUAccessorIteratorDef def,
                     BindingContext ctx, 
                     String dcName, 
                     String bName,
                     String rName,
                     int rangeSize) 
   {
      super(ctx, dcName, bName, rName, rangeSize);
      setDef(def);
   }

   MyIteratorBinding(JUAccessorIteratorDef def, DCDataControl dc,  RowSetIterator rsi)
   {
      super(dc, null);
      mHasResult = true;
      myRSI = rsi;
      setDef(def);
   }

   void initializeMasterRowRef (Row row)
   {
      mMasterRowKey = row.getKey();
      super.disableTokenValidation();
   }


   RowSetListener mMasterListener = new RowSetListener()
   {
         public void rangeRefreshed(RangeRefreshEvent event)
         {
         }

         public void rangeScrolled(ScrollEvent event)
         {
         }

         public void rowInserted(InsertEvent event)
         {
         }

         public void rowDeleted(DeleteEvent event)
         {
         }

         public void rowUpdated(UpdateEvent event)
         {
         }

         public void navigated(NavigationEvent event)
         {
            if (internalGetMasterBinding() == null && mHasResult == false && getBindingContainer() == null) 
            {
               //This is a released iteratorbinding being invoked from
               //a cached listeners list. No need to process this event.
               return;
            }

            setRefreshed(false);
            
            DCIteratorBindingDef def = getDef();
            /*
            Go for execute if object types or Bc4J case.
            Also go for execute if nonbc4j case and this iterator was 
            not bound to any RSI earlier = an attempt to bind to a RSI.
            This latter case occurs when initially there is no master
            and then on re-execute of the master, rows come in and then
            on first of the master, this event gets called which should
            build the RSI where none existed.
            */
            
            Object am = getDataControl().getApplicationModule();
            if ((am != null) || (def != null && def.isObjectType())
                || (am == null && !isBound()))
            {
               if (event != null && event.getRow() == null)
               {
                  RowSetIterator rsi = (hasRSI()) ? getRowSetIterator() : null;
                  if (rsi != null)
                  {
                     //force this detail RSI to be reset so that it can force
                     //it's accessors further to reset themselves or adjust 
                     //their currencies.
                     if (rsi instanceof oracle.adf.model.generic.DCRowSetIteratorImpl)
                     {
                        ((oracle.adf.model.generic.DCRowSetIteratorImpl)rsi).fireNavigationEvent(new NavigationEvent(rsi, null, null));
                     }
                  }
                  bindRowSetIterator(null, false);
               }
               else
               {
                  mHasResult = false;
                  executeQuery(); 
               }
            }
            
         }
      };

   protected RowSetListener getMasterListener()
   {
      return mMasterListener;
   }

   public void resolveRangeSize(int rangeSize)
   {
      if (mHasResult)
      {
         super.resolveRangeSize(rangeSize);
      }
      //do nothing otherwise.
   }

   public void setRangeSize(int val)
   {
      if (mHasResult)
      {
         super.setRangeSize(val);
      }
   }

   public AttributeDef[] getAttributeDefs(String[] attrNames)
   {
      JUAccessorIteratorDef def = getAccessorDef();
      if (def.isObjectType())
      {
         return getDataControl().getAttributeDefs(this, attrNames);
      }
      return super.getAttributeDefs(attrNames);
   }
   
   public ViewObject getViewObject()
   {
      RowSetIterator rsi = null;
      if (getDataControl().getApplicationModule() != null)
      {
         rsi = getRowSetIterator();
         if (!mHasResult)
         {
            if (rsi == null)
            {
               //Do not throw as callers should be ready to accept null
               //Accessor def should only be accessed after the
               //accessor data has been brought over to know it's structure
               return null;
            }
         }
      }

      if (rsi != null)
      {
         if (rsi.getRowSet() != null)
         {
            return rsi.getRowSet().getViewObject();
         }
      }
      return null;
   }

   /**
    * @internal *** For internal framework use only *** 
    * If this binding's RSI has a current row, make that ready for 
    * refreshControl to pass it on to various bindings to display
    * data. Override allows accessor Iterators to verify their
    * currency wrt. the current master before proceeding with use
    * of this row.
    */
   protected Row prepareCurrentRow()
   {
      JUIteratorBinding masterIter = (JUIteratorBinding)getMasterBinding();
      if (mHasResult && masterIter.hasCachedRow())
      {
         //fetch the accessor again, just in case it's changed. this
         //event is managed at the binding level rather than
         //on the RSI side since binding holds on to the created row
         //and there was no navigation event on the model side.
         mHasResult = false;

         boolean suspend = isSuspendRowSetEventsHandling();
         try
         {
            suspendRowSetEventsHandling(true);
            executeQuery(); 
         }
         finally
         {
            suspendRowSetEventsHandling(suspend);
         }
         if (hasRSI())
         {
            return getNavigatableRowIterator().first();
         }
      }
      return getCurrentRow();
   }


   /**
   * @internal *** For internal framework use only *** 
    */
   public boolean allowsRefreshControl()
   {
      //if I've fetched the details, allow refreshControl.
      //for accessors that are not domains in batchmode this would return 0
      //if accessor has not been brought over. 
      // JRS 3286438 Checking the fetchedRowCount > 0 prevents refresh events
      // from firing when navigating from a master with details to a master
      // without details.  There should be another state to prevent the scenario
      // described above for accessors still requiring synch.
       if(mHasResult && isBound())
       {
          RowSetIterator rsi = getRowSetIterator();
          if(rsi.getRowSet() != null)
          {
             return rsi.getRowSet().isExecuted();
          }
          return true;
       }
       
       if (!isFindMode() && mMasterBinding != null && mMasterBinding.hasRSI())
       {
          if (mMasterBinding.getRowSetIterator().getCurrentRowSlot() == RowSetIterator.SLOT_VALID)
          {
             //so that the accessor detail can now refresh itself with the current master row.
             //calling initSourceRSI rebuilds the rsi and rebinds it to the iteratorBinding.
             //gvbatch sv35
             //may be broken.
             //RowSetIterator rsi = initSourceRSI();
             RowSetIterator rsi;
             if (hasRSI()) 
             {
                rsi = getRowSetIterator();
             }
             else
             {
                rsi = null;
                //so that next refreshControl will set this back to alive (since
                //mAlive and mBound are both false.). If this is left to true
                //then refreshControl bails out. 
                //setAlive(false);
             }
             if(rsi != null && rsi.getRowSet() != null)
             {
                return rsi.getRowSet().isExecuted();
             }
             return true;
          }
       }
       return false;
   }

   private DCIteratorBinding internalGetMasterBinding()
   {
      return mMasterBinding;
   }
   
   private DCIteratorBinding getMasterBinding()
   {
      if (mMasterBinding != null)
      {
         return mMasterBinding;
      }
      String masterBindingName = getAccessorDef().getMasterBindingName();
      if (masterBindingName != null)
      {
         //voName is the master iterator name
         if (getBindingContainer() != null)
         {
            mMasterBinding = (JUIteratorBinding)getBindingContainer().findIteratorBinding(masterBindingName);
         }
         if (mMasterBinding == null)
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_ITER_BINDING, masterBindingName);
         }
      }

      mMasterBinding.addDependentExecutable(this);

      return mMasterBinding;
   }
   
   /**
   * Executes the query or the RowSet behind this iterator binding object.
    * Note that accessors are executed after all the non-accessor iterators
    * when the binding container is executed
   */
   public void executeQuery()
   {
      boolean doExecute = false;
      if (myRSI == null)
      {
         //these were created with RSI via a tree node binding.
         if (super.hasRSI())
         {
            RowSetIterator superRSI = super.getRowSetIterator();
            if (superRSI instanceof DCGenericRowSetIteratorImpl)
            {
               DCGenericRowSetIteratorImpl genRSI = ((DCGenericRowSetIteratorImpl)superRSI);
               genRSI.rebuildIteratorUpto(-1);
               return;
            }
            else if (superRSI.getRowSet() != null)
            {
               superRSI.getRowSet().executeQuery();
               return;
            }
         }
         else
         {
            //for tree based accessors, if rowkey is there but no rsi, 
            //that means it's a deferred mode case and tree accessor
            //was never executed thus far. need to refresh the 
            //accessor iterator
            doExecute = (mMasterRowKey != null);
         }
      } 
      else if (mMasterBinding != null)
      {
         doExecute = true;
         //close this detail so that next time we fetch again
         //this RSI will be GCed right.
         if (myRSI != null)
         {
            //deregister all listeners etc from this rsi.
            bindRowSetIterator(null, false);
         }
      }
      mHasResult = false;
      // Bug#3392666. This will be made visible 
      // when we successfully get the master row and the accessor
      // iterator from it. In batch mode the master may throw 
      // InvalidOperationException when we try to get the 
      // current (or first) row, but will be available 
      // with about be called sync. 
      // Turning this off allows the calling DataControl 
      // to recover from InvalidOperException.
      setIteratorMadeVisible(false);
      initSourceRSI();
      if (doExecute) 
      {
         super.doExecuteQuery();
      }
   }

   /*
   public void executeQueryIfNeeded()
   {
      if (hasRSI())
      {
         super.executeQueryIfNeeded();
      }
      else
      {
         executeQuery();
      }
   }
   */
   /**
    * return datacontrol for this iterator binding.
    */
   protected DCDataControl initDataControl()
   {
      if (mDC == null)
      {
         mDC = getMasterBinding().getDataControl();
      }
      return mDC;
   }

   //for both bc4j and bean datacontrols, always go through method invocation for
   //the finder method RSIs.
   protected RowSetIterator initSourceRSI()
   {
      //this is where method-binding control is unparsed
      //bindsName will be a method-binding name inside a method 
      RowSetIterator rsi = null;
      try
      {
         RowSetIterator masterRSI = null;

         if (getMasterBinding() != null)
         {
            masterRSI = mMasterBinding.getRowSetIterator();

            //implicitly executing the master.
            //do not consult the master's executeIfNeeded definition as
            //a child has been marked to be executed implies all masters
            //have to be executed. Such dependencies should be implied
            //at DT rather than a runtime check to manage the hierarchy.
            if (masterRSI == null)
            {
               mMasterBinding.executeQuery();
               masterRSI = mMasterBinding.getRowSetIterator();
            }
         }
         else if (mAM != null)
         {
            //find use getVOName as it's overridden in 
            //method iterator case.
            String str = getMasterVOName();
            masterRSI = mAM.findViewObject(str);

            if (masterRSI == null)
            {
               throw new NoObjException(NoObjException.TYP_VIEW_OBJECT, getSourceName());
            }
         }

         if (masterRSI != null)
         {
            //addListener is supposed to compare existence before adding.
            //we need to add release semantics.
            JUAccessorIteratorDef def = getAccessorDef();

            //need to cleanup the listeners on the current RSI;
            ArrayList details = new ArrayList();
            
            RowSetIterator curRSI = myRSI;
            if (curRSI != null)
            {
               curRSI.removeListener(this);
            }

            //accessor iterators are already wired up.
            //find all the dependent iterators on which I'm master
            ArrayList al = getBindingContainer().getIterBindingList();
            Object iterObj;
            for (int i = 0; i < al.size(); i++)
            {
               iterObj = al.get(i);
               if (iterObj instanceof MyIteratorBinding)
               {
                  if (((MyIteratorBinding)iterObj).getMasterBinding() == this)
                  {
                     if (curRSI != null) 
                     {
                        curRSI.removeListener(((MyIteratorBinding)iterObj).mMasterListener);
                     }
                     details.add(iterObj);
                  }
               }
            }

            //if master row key exists find the master row and use that to get the accessor
            //rsi.
            boolean createRSI = true;
            if (mMasterRowKey != null)
            {
               //have a key, that means tree based accessor. should not go to
               //create rsi from the datacontrol based on def.
               createRSI = false;
               Row masterRows[] = masterRSI.findByKey(mMasterRowKey, 1);
               if (masterRows.length > 0)
               {
                  rsi = getDataControl().createAccessorRowSetIterator(
                       masterRSI, masterRows[0], this, def.getAccessorName(), def.getBeanClassName());
               }
            }

            if (createRSI && rsi == null)
            {
               rsi = getDataControl().findOrCreateAccessorRowSetIterator(
                        mMasterBinding, this, def.getAccessorName(), def.getBeanClassName());
            }
            
            
            if (masterRSI != null)
            {
               masterRSI.addListener(mMasterListener);
            }

            //make iterator visible so that navbars etc. work on this iterator.
            setIteratorMadeVisible(true);

            //check if I was already set to this RSI. If so, then bindinRowSetIterator
            //will not call a range Refreshed so I need to call it here.
            //This will make sure if master is navigated, that details refresh
            //the ui as well.
            boolean needsRefresh =  (myRSI != null && this.getRowSetIterator() == rsi);
            mHasResult = true;
            myRSI = rsi;

            bindRowSetIterator(rsi, true);
            if (needsRefresh)
            {
               //because bindRowSetIterator won't send rangeRefreshed here.
               if (getDataControl().isJClientApp())
               {
                  rangeRefreshed(null);
               }
            }
            
            //now notify the details of change.
            if (curRSI != rsi && details != null)
            {
               DCIteratorBinding detailIter;
               for (int i = 0; i < details.size(); i++)
               {
                  detailIter = ((DCIteratorBinding) details.get(i));
                  if (detailIter.getBindingContainer() != null)
                  {
                     //only if details have not been released.
                     detailIter.executeQuery();
                  }
               }
            }
         }
      }
      catch (oracle.jbo.JboException e)
      {
         //if (rsi != null)
         {
            throw e;
         }
         //ignore and return null.
         //Diagnostic.println("*** IGNORING! following exception in JUAccessorIteratorDef.initSourceRSI()");
         //Diagnostic.printStackTrace(e);
      }
      return rsi;
   }

   public boolean isOperationSupported(byte oper)
   {
      if (oper != DCDataControl.OPER_EXECUTE) 
      {
         DCIteratorBinding master = internalGetMasterBinding();
         if ((master == null)
             || !master.hasRSI()
             || master.getCurrentRow() == null)
         {
            return false;
         }
      }
      return super.isOperationSupported(oper);
   }

   JUAccessorIteratorDef getAccessorDef()
   {
      return (JUAccessorIteratorDef)getDef();
   }

   public String getVOName()
   {
      if (mHasResult)
      {
         RowSetIterator rsi = getRowSetIterator();
         if (rsi != null)
         {
            RowSet rs = rsi.getRowSet();
            if (rs != null)
            {
               return rs.getViewObject().getName();
            }
            else
            {
               return rsi.getName();
            }
         }
      }
      return null;
   }

   String getMasterVOName()
   {
      DCIteratorBinding master = getMasterBinding();
      if (master != null)
      {
         RowSetIterator rsi = master.getRowSetIterator();
         if (rsi != null)
         {
            RowSet rs = rsi.getRowSet();
            if (rs != null)
            {
               return rs.getViewObject().getName();
            }
            else
            {
               return rsi.getName();
            }
         }
         return master.getVOName();
      }
      return null;
   }

   public String getPermissionTargetName()
   {
      if (isAccessorIterator())
      {
         String dcName = getDataControl().getName(); 
         String accName = ((JUAccessorIteratorDef)getDef()).getAccessorName(); 
         if (dcName != null && accName != null)
         {
            StringBuffer strBuf = new StringBuffer();
            strBuf.append(dcName).append(DCUtil.SEP_DOT_CHAR);
            strBuf.append("get").append(accName); //NONLS
            return strBuf.toString();
         }
      }
      return null;
   }
}

