/*
 * @(#)JUIteratorDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.jbo.ApplicationModule;
import oracle.jbo.SortCriteria;
import oracle.jbo.common.Diagnostic;
import oracle.adf.model.BindingContext;
import java.util.ArrayList;

public class JUIteratorDef extends DCIteratorBindingDef
{
   public JUIteratorDef()
   {
      super();
   }

   public JUIteratorDef(String name, String amName, String voName, String rsiName)
   {
      this(name, amName, voName, rsiName, 1);
   }

   public JUIteratorDef(String name, String amName, String voName, String rsiName, int rangeSize)
   {
      super(name, amName, voName, rsiName, rangeSize);
   }


   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc, ApplicationModule anchorAM)
   {
      if (anchorAM != null)
      {
         ApplicationModule am = anchorAM.findApplicationModule(getAMName());
	      return new JUIteratorBinding(am, getBindsName(), getRSIName(), mRangeSize);
      }
      if (ctx != null) 
      {
         return createIterBinding(ctx, (DCBindingContainer)bc);
      }
      return null;

   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc)
   {
      String voName = getBindsName();
      //check datacontrol name first. If exists, give that
      //precedence over fullVOName. Migrated apps should
      //have a dcName generated for them in all iterator Binding
      //and that dcName should be an alias into a bindingcontainer
      //dcMap.
      String dcName = this.getDataControlName();
      
      //if dcName is not an expression, it's not been overridden, so find the datacontrol
      //in JUIteratorBinding constructor. This matches 1012.
      //for 1013, dataControlName is generated and we do not need to look for 
      //voName with dataControlName prefixed, so we strip that out here.
      if ((dcName == null && !DCUtil.isElExpr(voName)) || (voName.startsWith(dcName)))
      {
         int index = voName.indexOf('.');
         if (index > 0) 
         {
            dcName = voName.substring(0, index);
            voName = voName.substring(index+1);
         }
         else if (dcName == null)
         {
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Warning! null DataControl name may lead to exceptions later on!");
            }
         }
      }
	   return new JUIteratorBinding(ctx, dcName, voName, getRSIName(), mRangeSize);
   }

}
