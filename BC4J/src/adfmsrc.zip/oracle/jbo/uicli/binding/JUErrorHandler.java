/*
 * @(#)JUErrorHandler.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

/**
 * Implements reporting of all JClient and BC4J exceptions raised in the context
 * of a JUFormBinding.
 * <p>
 * Applications could customize exception reporting in JClient by implementing
 * this interface and providing a custom implementation to display/handle BC4J and
 * JClient exceptions.
 * <p>
 * By default JUErrorHandlerThrow implements this interface and throws all
 * exceptions as a JboException which is a generic Java runtime exception and base
 * class for all BC4J and JClient exceptions.
 * <p>
 * For generated applications from JClient wizards, the wizards generate a call
 * to set JUErrorHandlerDialog as the default error handler so that all exceptions
 * are displayed in an error dialog.
 *
 * @see oracle.jbo.JboException
 * @see oracle.jbo.uicli.binding.JUErrorHandlerThrow
 * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
 */
public interface JUErrorHandler
{
   /**
   * Implements how to handle the given exception raised within the JClient framework
   * in the context of the given form binding.
   */
   public void reportException(JUFormBinding formBnd, Exception ex);

   /**
   * @see JUErrorHandler#reportException(JUFormBinding, Exception)
   * @param formBnd the binding where the exception was caused
   * @param ex the exception to report
   * @param reportExceptionNow true if the caller should be stopped until the 
   * exception is reported. If an exception is fatal, and the calling program 
   * wants to abort, the calling program typically wants to wait till the 
   * exception is shown to the user. 
   */
   public void reportException(JUFormBinding formBnd, Exception ex, boolean reportExceptionNow);
}
