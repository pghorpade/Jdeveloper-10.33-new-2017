package oracle.jbo.uicli.binding;

/**
 * A JUCtrlValueHandler interface defines method specific for returning 
 * inputValue from custom inputHandler. It is used for support cases such as 
 * intermedia in BC4J/FACEs scenario. For example, the "source" of Faces 
 * component &lt;objectMedia&gt; is not directly from the corresponding model
 * object, it is a caculated result. So we use a custom ValueHandler to handle
 * the return of correct source for &lt;objectMedia&gt; . 
 * 
 * This class extends existed JUCtrlInputValueHandler so that it provides
 * all display, update functionality for intermedia objects.
 *
 * @javabean.class name=JUCtrlValueHandler
 * @author  wangchun zhang July 11 2005.
 */ 
public interface JUCtrlValueHandler extends JUCtrlInputValueHandler
{
   /**
    * Return a custom valueHandle for inputValue. 
    * 
    * @param binding Control binding associated with the attribute.
    * @param index   Index of the attribute in this control binding 
    * @return InputValue for the given control binding.
    */
    public Object getInputValue(JUCtrlValueBinding binding, int index);
}