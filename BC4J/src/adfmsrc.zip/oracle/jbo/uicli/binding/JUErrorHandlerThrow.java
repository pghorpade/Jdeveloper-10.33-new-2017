/*
 * @(#)JUErrorHandlerThrow.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import oracle.jbo.JboException;

/**
 * Implements a default error handling class for the JClient framework. This handler
 * simply throws exceptions it receives as JboExceptions (by creating
 * a JboException if required).
 * @see oracle.jbo.JboException
 * @see oracle.jbo.uicli.binding.JUErrorHandler
 */
public class JUErrorHandlerThrow implements JUErrorHandler
{
   private boolean mScoped;
   
   
   public JUErrorHandlerThrow()
   {
   }


   /**
   * This method simply throws the exception 'ex' as a JboException (by creating
   * a new JboException if required).
   */
   public void reportException(JUFormBinding formBnd, Exception ex)
   {
      if (ex instanceof JboException)
      {
         throw (JboException) ex;
      }
      else
      {
         throw new JboException(ex);
      }
   }

   public void reportException(JUFormBinding formBnd, Exception ex, boolean reportExceptionNow)
   {
	//ignore reportExceptionNow
	reportException(formBnd, ex);
   }
}
