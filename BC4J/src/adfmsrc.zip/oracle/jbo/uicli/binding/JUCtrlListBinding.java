/*
 * @(#)JUCtrlListBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.lang.reflect.Array;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.JboException;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetManagementEvent;
import oracle.jbo.RowSetManagementListener;
import oracle.jbo.RowSetListener;
import oracle.jbo.RowIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * A JUCtrlAttrsBinding class responsible displaying a list of values
 * from a static list or a list calculated at runtime using another BC4J ViewObject/RowIterator.
 * This binding operates in two ways:
 * <ul>
 * <LI>To update attributes (default - LIST_OPER_SET_ATTRIBUTE)
 * <LI>To navigate a set of rows (LIST_OPER_NAVIGATE)
 * </ul>
 * <p>
 * The operating mode is to be setup in the constructor of this binding.
 * <p>
 * This binding works in two updateable modes:
 * <ul>
 * <li>Single attribute mode, where only one attribute from the display ViewObject/RowIterator
 * is used to display and only one attribute in the target ViewObject is updated based on the
 * selected item in the list.
 * <li>Row selection mode, where one or more than one attributes in the target ViewObject
 * is updated based on the currently selected item which identifies the current row in
 * the displayed list (display ViewObject/RowIterator).
 * </ul>
 * <p>
 * This binding can also be used to iterator through a RowIterator object and display 
 * single or multiple attributes from the rows.
 *
 * @javabean.class name=JUCtrlListBinding
 *
 */
public class JUCtrlListBinding extends JUCtrlAttrsBinding implements RowSetListener, RowSetManagementListener
{
   /**
   * Indicates this list binding will be used to update attributes in a target ViewObject.
   * This is the default mode 
   */
   public static int LIST_OPER_SET_ATTRIBUTE = 0;

   /**
   * Indicates that list binding will be used to navigate Rows in a RowIterator.
   */
   public static int LIST_OPER_NAVIGATE = 1;
   
   
   private int mListOperMode = LIST_OPER_SET_ATTRIBUTE;
   protected boolean mSingleAttrList = true;


   public static final int LIST_ADD_NULL_UNINIT   = -1; 
   public static final int LIST_ADD_NULL_NOWHERE  = 0; //default.
   public static final int LIST_ADD_NULL_AT_START = 1;
   public static final int LIST_ADD_NULL_AT_END   = 2;
   protected int mNullValueFlag = LIST_ADD_NULL_UNINIT;
   private int mNullValueIndex = -1;

   //boolean mInSetupList = false;

   /**
   * List of values displayed in the bound control. This could be a list of single
   * attribute values or a list of BC4J Rows.
   */
   protected Object[] mValueList = null;
   private int mSelectedIndex = -1;

   //set by ListBinding when it calls executeQueryIfNeeded on
   //an RSI which has no current row. This boolean is to 
   //break loops incase execute leads to refresh events that
   //forces execute again - due to null RSI dataprovider.
   private boolean mListNotExecuting = true;
   /**
   * Ordered list of attribute names that this control binding should use
   * to update the target ViewObject's attributes. 
   */
   protected String[] mListAttrNames;

   /**
   * Ordered list of attributes that this control binding should use
   * to display the Rows from the LOV ViewObject.
   */
   protected String[] mListDisplayAttrNames;

   private AttributeDef[] mDisplayAttrs;

   private static final String ATTR_SELECTED_INDEX = "selectedIndex";

   /**
   * Iterator Binding object that this binding uses to get the LOV data.
   */
   protected DCIteratorBinding mListIterBinding = null;

   /**
   * Controls whether the list of values should be fetched once or should this list update
   * itself when the ViewObject for the LOV changes.
   */
   protected boolean mStaticList = false;
   private boolean mListPrepared = false;

      
   protected AttributeDef mFirstDisplayAttr;

   /**
    * Constants to access properties in this list binding. See javadoc for internalGet().
    */
   private static final String ATTR_DISPLAY_HINTS = "displayHints";
   private static final String ATTR_DISPLAY_DATA  = "displayData";

   /**
    * Constants to access elements in the map returned in getDisplayData()
    */
   public final static String LISTITEM_Selected     = "selected";
   public final static String LISTITEM_Index        = "index";
   public final static String LISTITEM_Prompt       = "prompt";
   public final static String LISTITEM_DisplayValues= "displayValues";
   public final static String LISTITEM_SelectedIndex= "selectedIndex";

   /**
    * Constants to access elements in the map returned in getDisplayHints()
    */
   public static final String DH_LABEL         = "label";
   public static final String DH_TOOLTIP       = "tooltip";
   public static final String DH_DISPLAY_HINT  = "displayHint";
   public static final String DH_DISPLAY_HEIGHT= "displayHeight";
   public static final String DH_DISPLAY_WIDTH = "displayWidth";
   public static final String DH_CONTROL_TYPE  = "controlType";
   public static final String DH_FORMAT        = "format";

   
   JUCtrlListBinding thisBindingObj = null;
   JUCtrlListBindingItemRef[] currentSetRef;


   public static final int LOV_SRC_ATTRNAMES       = 0;
   public static final int LOV_SRC_ROW_DATA        = 1;
   public static final int LOV_SRC_EL_EXPR         = 2;
   
   //default initialized to zero. = attributenames.
   private int mLovSrcOption;
   
   private ArrayList listenerList = null;
   private transient Object valueNotFound = null;

   /**
   * *** For internal framework use only ***
   */
   protected JUCtrlListBinding()
   {
   }

   /**
   * **For Testing purposes only***
   * Uses the same Iterator Binding to update as well as display values.
   */
   public JUCtrlListBinding(Object control, DCIteratorBinding iterBinding,
                            String[] attrNames, int listOperMode)
   {
      super(control, iterBinding, attrNames);
      mListAttrNames = attrNames;
      mListDisplayAttrNames = attrNames;
      mListOperMode = listOperMode;
      if (listOperMode == LIST_OPER_NAVIGATE) 
      {
         //make the iteratorbinding for display be same as the one for update
         //so that refresh of the list happens when this lists' master navigates.
         mListIterBinding = iterBinding;
         
         mListDisplayAttrNames = attrNames;

         if (iterBinding != null)
         {
            iterBinding.setAllowFindMode(false);
         }
      }
      mSingleAttrList = ((attrNames == null) || (attrNames.length == 1));

   }

   /**
   * Uses the given static list of value objects to display data in the control.
   */
   public JUCtrlListBinding(Object control, DCIteratorBinding iterBinding, String[] attrNames,
                            Object[] valueList)
   {
      super(control, iterBinding, attrNames);
      mListAttrNames = attrNames;
      mListDisplayAttrNames = attrNames;
      mStaticList = true;
      mListPrepared = false;

      setValueList(valueList);
      mSingleAttrList = ((attrNames == null) || (attrNames.length == 1));
   }

   /**
   * Uses the listIterBinding object to get the iterator and attribute names from
   * listDisplayAttrNames to display attributes from the BC4J Rows in the iterator.
   * Also maps values from listAttrNames attributes to the set of attributes (attrNames)
   * in the current row of the target iterator referred by iterBinding object 
   */
   protected JUCtrlListBinding(Object control, DCIteratorBinding iterBinding,
                            String[] attrNames, DCIteratorBinding listIterBinding,
                            String[] listAttrNames, String[] listDisplayAttrNames)
   {
      super(control, iterBinding, attrNames);

      if (listAttrNames == null)
      {
         throw new oracle.jbo.InvalidParamException("JUCtrlListBinding()", "listAttrNames", "", "Edit list binding definition and fill in the list details.");
      }

      if (listDisplayAttrNames == null)
      {
         listDisplayAttrNames = listAttrNames;
      }

      if (listDisplayAttrNames == null)
      {
         listAttrNames = listDisplayAttrNames = getAttributeNames();
      }

      mListAttrNames = listAttrNames;
      mListDisplayAttrNames = listDisplayAttrNames;

      mListIterBinding = listIterBinding;
      if (listIterBinding != null)
      {
         listIterBinding.setAllowFindMode(false);
      }

      if (listAttrNames != null && listAttrNames.length > 0) 
      {
         int len = listAttrNames.length;
         String firstName = listAttrNames[0];
         if (len == 1 && DCDataControl.GET_DataProvider.equalsIgnoreCase(firstName)) 
         {
            mLovSrcOption = LOV_SRC_ROW_DATA;
         }
         else if (len > 0 && DCUtil.isElExpr(firstName)) 
         {
            mLovSrcOption = LOV_SRC_EL_EXPR;
         }
      }

      mSingleAttrList = ((listDisplayAttrNames != null) 
                          && (listDisplayAttrNames.length == 1)
                          && (attrNames.length == 1 && listDisplayAttrNames[0].equals(attrNames[0]))
                          && (listAttrNames.length == 1 && listDisplayAttrNames[0].equals(listAttrNames[0])));

   }

   /**
   * If this list is displaying a single attribute and updates a single attribute,
   * then this method fetches the attribute value from all the rows in the given LOV list
   * iterator and sets that as the list of values to display in the bound control.
   *
   <p>
   * If this list is displaying multiple attributes and/or is used in navigation mode,
   * then the valueList is set with the list of all rows from the LOV Iterator binding.
   * In this case, this binding also listens to events from the RowSetIterator 
   * for row currency changes, new rows, etc.
   */
   protected void setupListItems(boolean clean, boolean keepSelectedIndex)
   {

      //mInSetupList = true;
      boolean listPrepared = true;
      try
      {
         if (mStaticList)
         {
            if (mValueList == null)
            {
              mValueList = new Object[0];
            }
            else if (!mListPrepared)
            {
               convertValueList();
            }
            return;
         }
         RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
         if (mSingleAttrList) 
         {
            //only does one value as of now.
            setValueList(getAttrValuesFromRSI());
            //this will convert the list to target types.
            this.convertValueList();
         }
         else
         {
            boolean listRSIOpen = false;
            try
            {
               //default the listRSI to this target VO's rsi only when there are valid
               //list attribute names! infact this whole setup stuff may not be required at all
               //for cases where listRSI was not provided.
               if (listRSI == null && mListAttrNames.length > 0) 
               {
                  RowSetIterator bndRSI = getIteratorBinding().getRowSetIterator();
                  if (bndRSI != null && bndRSI.getRowSet() != null)
                  {
                     listRSI = bndRSI.getRowSet().createRowSetIterator(null);
                     listRSIOpen = true;
                  }
               }

               if (listRSI != null) 
               {
                  //if list rangesize is 1 or listIterBinding.rangeSize is DO_NOT_OVERRIDE, 
                  //then get all rows as someone is using a list to navigate or display source
                  // while the range size may be 1.
                  if (mListIterBinding == null || mListIterBinding.getRangeSize() < 2)
                  {
                     listRSI.setRangeSize(-1);
      
                     //if in batchmode we want to go and get all rows right?
                     //this is a bug in 9051.
                  }
                  Row[] rows = null;
                  try
                  {
                     if (mListIterBinding != null && mListIterBinding.refreshIfNeeded())
                     {
                        rows = listRSI.getAllRowsInRange();
                     }
                  }
                  catch (oracle.jbo.RowNotAvailableException rnae)
                  {
                     //instead of forcing a sync, rely on next sync to 
                     //setup the list. till then this list will have
                     //empty source.
                     listPrepared = false;
                     return;
                  }
                  catch (oracle.jbo.InvalidOperException ioe)
                  {
                     //instead of forcing a sync, rely on next sync to 
                     //setup the list. till then this list will have
                     //empty source.
                     listPrepared = false;
                     return;
                  }

                  //addnull entries.
                  if (hasNullValue()) 
                  {
                     addNullAndSetValueList(rows);
                  }
                  else
                  {
                     mNullValueIndex = -1;
                     setValueList(rows);
                  }


                  //listener mgt. keeps track of unique listener.
                  listRSI.addListener(this);
                  if (listRSI != null) 
                  {
                     listRSI.addManagementListener(this);
                  }
               }
               else
               {
                  setValueList(new Object[0]);
               }

            }
            catch(Exception ex)
            {
               oracle.jbo.common.Diagnostic.printStackTrace(ex);
               reportException(ex);
            }
            finally
            {
               if (listRSIOpen)
               {
                  listRSI.closeRowSetIterator();
               }
            }
         }
         // bug 3270826.  currentSetRef used to be removed.  however, it
         // could possibly be still in use.  reset it instead.
         // JRS -- Should this be performed for static lists as well?
         if (currentSetRef != null && mValueList != null)
         {
            currentSetRef = new JUCtrlListBindingItemRef[mValueList.length];
         }
      }
      finally
      {
         mListPrepared = listPrepared;
      }
   }

   /*
   Row[] forceGetAllRowsInRange()
   {

      if (Diagnostic.isOn())
      {
         Diagnostic.println("Warning! Explicit executeQuery and sync for :"+getIteratorBinding().getName());
      }
      mListIterBinding.executeQueryIfNeeded();
      mListIterBinding.getDataControl().sync("JUCtrlListBinding.forceGetAllRowsInRange");
      return mListIterBinding.getAllRowsInRange();
   }
   */

   /**
    *  Returns the iterator binding that is used to fill in the values for this list.
    * @javabean.property
    */
   public DCIteratorBinding getListIterBinding()
   {
      return mListIterBinding;
   }


   /**
   * Returns whether this list binding is used for Row Navigation or updating attributes on a target ViewObject (default).
   * The possible values are:
   * <ul>
   * <li>LIST_OPER_SET_ATTRIBUTE
   * <li>LIST_OPER_NAVIGATE
   * </ul>
   */
   public int getListOperMode()
   {
      return mListOperMode;
   }

   
   //make this protected. why was this public in the first place?
   //This method should be used only by subclasses to set the display names 
   //when it's not already set. should this list be changed at runtime?
   //that has impact on all list binding data and needs recalculation of
   //list values, etc.
   void setListDisplayAttrNames(String [] listDisplayAttrNames)
   {
     mListDisplayAttrNames = listDisplayAttrNames;
   }
   
   /**
   * *** For internal framework use only ***
    */
   public String[] getListDisplayAttrNames()
   {
   	return(mListDisplayAttrNames);
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the operating mode for this list binding.
   */
   public void setListOperMode(int listOperMode)
   {
      mListOperMode = listOperMode;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   void setSingleAttrList(boolean flag)
   {
      mSingleAttrList = flag;
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
    * @javabean.property
   */
   public boolean isSingleAttrList()
   {
      return mSingleAttrList;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   void setLovSourceOption(int x)
   {
      mLovSrcOption = x;
   }

   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void setValueList(Object[] valueList)
   {
      mValueList = valueList;
   }

   /**
   * *** For internal framework use only ***
   * This method adjusts the given list with a nullvalue flag as set
   * on this binding. 
   * <p>
   */
   public void addNullAndSetValueList(Object[] rows)
   {
      int size = (rows == null) ? 0 : rows.length;
      Object[] rowsWithNull = new Object[size+1];
      int start;
      if (mNullValueFlag == LIST_ADD_NULL_AT_START)
      {
         mNullValueIndex = 0;
         rowsWithNull[0] = getNullValueString();
         start=1;
      }
      else
      {
         mNullValueIndex = size;
         rowsWithNull[size] = getNullValueString();
         start = 0;
      }
      if (rows != null) 
      {
         System.arraycopy(rows, 0, rowsWithNull, start, size);
      }
      setValueList(rowsWithNull);
   }

   public boolean hasNullValue()
   {
      return (getNullValueFlag() > LIST_ADD_NULL_NOWHERE);
   }

   public int getNullValueIndex()
   {
      return mNullValueIndex;
   }


   protected final int getNullValueFlag()
   {
      return mNullValueFlag;
   }

   protected void setNullValueProperties(int flag)
   {
      if (mListOperMode != LIST_OPER_NAVIGATE) 
      {
         switch (flag) 
         {
         case LIST_ADD_NULL_AT_END:
         case LIST_ADD_NULL_AT_START:
         case LIST_ADD_NULL_NOWHERE:
            mNullValueFlag = flag;
            break;

         default:
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Ignoring improper flag sent in for setNullValueFlag."); 
            }
         }
      }
      else
      {
         Diagnostic.println("Ignoring improper flag sent in for setNullValueFlag for navigation list."); 
      }
   }
   
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void convertValueList()
   {
      if (mSingleAttrList) 
      {
         AttributeDef[] attrDefs = getAttributeDefs();
         
         if (attrDefs != null && attrDefs.length > 0)
         {
            Class listValClass = attrDefs[0].getJavaType();
            
            if (listValClass != null && mValueList != null)
            {
               boolean hasNull = hasNullValue();

               int length = mValueList.length;
               int j = 0;
               Object[] newList = new Object[length];
               if (hasNull) 
               {
                  if (mNullValueFlag == LIST_ADD_NULL_AT_START)
                  {
                     mNullValueIndex = 0;
                     j = 1;
                     newList[0] = mValueList[0];
                     setNullValueString((newList[0] != null) ? newList[0].toString() : getNullValueString());
                  }
                  else
                  {
                     --length;
                  }
               }
               
               for (;j < length; j++)
               {
                  Object listVal = mValueList[j];
                  
                  if (listVal != null && !listValClass.isInstance(listVal))
                  {
                     newList[j] = TypeFactory.getInstance(listValClass, listVal);
                  }
                  else
                  {
                     newList[j] = listVal;
                  }
               }

               if (hasNull && mNullValueFlag == LIST_ADD_NULL_AT_END)
               {
                  mNullValueIndex = j;
                  newList[j] = mValueList[j];
                  setNullValueString((newList[j] != null) ? newList[j].toString() : getNullValueString());
               }
            
               mValueList = newList;
            }
         }
      }
   }

   final private boolean isAttrValueAccesible(Row row)
   {
      if (row != null) 
      {
         return true;
      }
      DCIteratorBinding iter = getIteratorBinding();
      return (iter != null && iter.getClass() == JUVariableIteratorBinding.class);
   }

   
   public int getSelectedIndex()
   {
      if (getControl() == null)
      {
         //this is non-jclient case. 
         Row row = getCurrentRow();
         if (isAttrValueAccesible(row))
         {
            updateValuesFromRow(row);
         }
         //else
         {
            //mSelectedIndex = -1; //no target row found.
         }
      }
      return mSelectedIndex;
   }

   
   public void setSelectedIndex(int indx)
   {
      setSelectedIndexValue(indx);
      if (mListOperMode != LIST_OPER_NAVIGATE)
      {
         setAttributeFromValueList(mSelectedIndex);
      }
      else
      {
         if (indx >= 0)
         {
            RowIterator rsi = getRowIterator();
            if (rsi != null)
            {
               if (getIteratorBinding().getCurrentRowIndexInRange() != indx)
               {
                  getBindingContainer().callBeforeRowNavigated(getIteratorBinding());
                  rsi.setCurrentRowAtRangeIndex(indx);
               }
            }
         }
      }
   }
   
   protected void setSelectedIndexValue(int indx)
   {
      mSelectedIndex = indx;
   }

   protected int getSelectedIndexValue()
   {
      return mSelectedIndex;
   }
   
   
   //this method is supposed to return the attribute value at the given index
   //in the current row.
   public Object getValueAt(int attrIndex)
   {
      //return getSelectedValue();
      return getAttribute(attrIndex);
   }

   /**
    * *** For internal framework use only ***
    * <p>
    * Returns the static value list as set into this listbinding
    * incase of enumeration lists. In case of Row bound lists, 
    * returns an array of LOV rows set into this listbinding.
    */
   public Object[] getValueList()
   {
      return mValueList;
   }

   /**
    * Returns an ArrayList of values that should be displayed
    * in this list. If this listbinding has multiple display
    * attributes, then each element in the returned list is
    * itself an arraylist of that many attribute values.
    * @javabean.property
    */
   public Iterator getDisplayListIterator()
   {
      ArrayList al = new ArrayList();
      if (this.mSingleAttrList)
      {

      }

      return al.iterator();
   }

  /**
   *
   * @javabean.property
   */
   public Object getSelectedValue()
   {
      return getValueFromList(mSelectedIndex);
   }

   Object getLovRowData(Row lovRow, String attrName)
   {
      Object lovVal = null;
      if (lovRow != null) 
      {
         switch (mLovSrcOption) 
         {
         case LOV_SRC_ATTRNAMES:
            lovVal = lovRow.getAttribute(attrName);
            break;

         case LOV_SRC_ROW_DATA:
            lovVal = ((oracle.adf.model.generic.RowImpl)lovRow).getDataProvider();
            break;

         case LOV_SRC_EL_EXPR:
         default:
            lovVal = DCUtil.elEvaluate(getBindingContainer().getBindingContext(), lovRow, attrName);
         }
      }
      return lovVal;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   protected boolean matchTargetWithLov(Row targetRow, Row lovRow)
   {
      if (targetRow == lovRow)
      {
         return true;
      }


      AttributeDef ads[] = getAttributeDefs();
      {
         //mapping attribute names of the target row with the lov row.
         //this mapping could be provided by a user in some metadata in the future.
         Object targetVal;
         Object lovVal;
         boolean matched = true;
         for (int i = 0; i < ads.length; i++) 
         {
            if (mLovSrcOption != LOV_SRC_ROW_DATA) 
            {
               targetVal = targetRow.getAttribute(ads[i].getIndex());
            }
            else
            {
               targetVal = targetRow.getAttribute(ads[i].getName());
            }

            //list attribute on the source side may be an attribute name or 
            //dataProvider itself. 
            lovVal = getLovRowData(lovRow, mListAttrNames[i]);

            if (targetVal == null)
            {
               if (lovVal == null)
               {
                  continue;
               }
            }
            else  if (targetVal.equals(lovVal))
            {
               continue;
            }
            else if (lovVal != null && targetVal.getClass() != lovVal.getClass()) 
            {
               //try converting both to the same java type and compare.
               //this will handle cases where say PK is of different type than FK and
               //LOV displays all PKs but need to update an FK.
               if (targetVal.equals(TypeFactory.getInstance(ads[i].getJavaType(), lovVal))) 
               {
                  continue;
               }
            }
            //no attributes matched, get out.
            matched = false;
            break;
         }
         return matched;
      }
   }

   
   protected int setListValueAsSelected(Object val)
   {
      boolean found = false;
      if (mValueList != null)
      {
         for (int i = 0; i < mValueList.length; i++)
         {
            if (val == mValueList[i])
            {
               mSelectedIndex = i;
               found = true;
               break;
            }
         }
      }

      if (!found)
      {
         mSelectedIndex = -1;
      }
      return mSelectedIndex;
   }

   public Object findMatchingListValue(Object val)
   {
      return findAndUpdateSelectedIndex(val, false);
   }

   /**
   * *** For internal framework use only ***
    * findMatching List value for the given object and if found, set the
    * selected index to that value as well if given flag is true.
    */
   protected Object findAndUpdateSelectedIndex(Object val, boolean flag)
   {
      int selIndex = findListIndex(val);
      Object matchVal = null;

      if (selIndex >= 0)
      {
         //this returns a value in the list. 
         //this value can match the nullvalue set on the list as well.
         matchVal = mValueList[selIndex];
      }

      //Bug 5501803
      // If the flag is set mSelectedIndex is set to the value of
      // findListIndex(val). Previously it was set only if the found
      // index was greater than or equal to 0 ie when selIndex >= 0
      if(flag)
      {
         mSelectedIndex = selIndex;
      }

      return matchVal;
   }
   
   
   public int findListIndex(Object val)
   {
      if (mValueList == null)
      {
         return -1;
      }
      
      int listIndex = -1;

      if (mSingleAttrList) 
      {
         AttributeDef[] attrDefs = getAttributeDefs();
         Class listValClass = null;
         Class valClass = null;

         if (attrDefs != null && attrDefs.length > 0)
         {
            listValClass = attrDefs[0].getJavaType();
         }

         if (val != null)
         {
            valClass = val.getClass();
         }
         
         boolean hasNull = hasNullValue();
         for (int j = 0; j < mValueList.length; j++)
         {
            Object listVal = mValueList[j];
   
            if (val == listVal) 
            {
               listIndex = j;
               break;
            }
            if (val == null)
            {
               if (listVal == null || (hasNull && listVal == getNullValueString()))
               {
                  listIndex = j;
                  break;
               }
            }
            else if (valClass.isInstance(listVal))
            {
               if (val.equals(listVal))
               {
                  listIndex = j;
                  break;
               }
            }
            else if (listValClass != null)
            {
               try
               {
                  Object convVal = TypeFactory.getInstance(listValClass, val);

                  if (convVal.equals(listVal))
                  {
                     listIndex = j;
                     break;
                  }
               }
               catch (JboException je)
               {
                  if (getIteratorBinding().isFindMode())
                  {
                     //in findmode, this value can be a where-clause predicate
                     //with comparators. That may not convert to typed values,
                     //so return -1 as the selected index.
                     listIndex = -1;
                     break;
                  }
                  throw je;
               }
            }
            else if (val.equals(listVal))
            {
               listIndex = j;
               break;
            }
         }
      }
      else
      {
         if (mListIterBinding != null) 
         {
            boolean redoList = true;
            RowSetIterator rsi = mListIterBinding.getRowSetIterator();
            
            //gvbm2 sv05 -M3 fails as this condition could occur
            //even in immediate mode 3tier. 
            //so commenting out check for syncNeeded.
            //if (mListIterBinding.getDataControl().syncNeeded())
            {
               //bug 3502918 and 3503383
               //on commit/rollback/activation client side cache (Rowsetiterator)
               //is cleared out. The rows are all marked PS_LAZY and the list
               //ends up with these dead rows. In such situations we need to
               //rebuild the list so that matching values in the list will work.
               //Ideally this should be done via a RowSet refreshed or some
               //other rowset event so that the clients like this can rebuild
               //their data.

               //TODO: we should remove this caching of rows in the list binding.
               //Instead The rows should be returned from getAllRowsInRange.
               if (rsi != null)
               {
                  Row firstRow = rsi.getRowAtRangeIndex(0);
                  Row firstLovRow = null;
                  if (mValueList != null && mValueList.length > 0) 
                  {
                     if (mNullValueIndex != 0)
                     {
                        firstLovRow = (Row)mValueList[0];
                     }
                     else if (mValueList.length > 1)
                     {
                        firstLovRow = (Row)mValueList[1]; 
                     }
                     //otherwise mValueList has only one element for null.
                     //no first row.
                  }
                  if (firstRow != firstLovRow)
                  {
                     setupListItems(true, false);
                     redoList = false;
                  }
               }
            }

            if (redoList && (rsi == null 
                             || rsi.getCurrentRowSlot() != RowSetIterator.SLOT_VALID))
            {
               if (mListNotExecuting && (rsi == null 
                                          || rsi.getRowSet() == null 
                                          || !rsi.getRowSet().isExecuted()))
               {
                  // JRS 3334231 Use the IB to execute the query.  Generic RSIs
                  // do not have RowSets.  see test script 
                  // guava.JavaBeans.js02 for verification.
                  try
                  {
                     mListNotExecuting = false;
                     mListIterBinding.executeQueryIfNeeded();
                  }
                  finally
                  {
                     //if the list returns null, then only perform list execution once.
                     mListNotExecuting = true;
                  }
               }
            }
         }
         Row lovRow;
         if (val instanceof Row) 
         {
            Row row = (Row)val;
            for (int j = 0; j < mValueList.length; j++)
            {
               lovRow = (j != mNullValueIndex) ? (Row)mValueList[j] : null;
      
               if (val == null)
               {
                  if (lovRow == null)
                  {
                     listIndex = j;
                     break;
                  }
               }
               else  if (matchTargetWithLov(row, lovRow))
               {
                  listIndex = j;
                  break;
               }
            }
         }
         else
         {
            //check if first attribute value matches in any row. Ultimately
            //this should be the first in the LOVAttributesList as that's what
            //should be edited in the celleditor
            if (mFirstDisplayAttr == null)
            {
               // JRS 3334231 Generic RSIs do not have RowSets.
               // RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
               // oracle.jbo.ViewObject vo = listRSI.getRowSet().getViewObject();

               if (mListDisplayAttrNames.length > 0 && mListIterBinding != null)
               {
                  //AttributeDef[] attrDefs = getAttributeDefs();
                  //get the list display attribute definitions and use that to 
                  //perform value matching. bug 2653822  and 3749704
                  AttributeDef[] attrDefs = mListIterBinding.getAttributeDefs(mListDisplayAttrNames);
                  for (int i=0; i < attrDefs.length; i++)
                  {
                     if (mListDisplayAttrNames[0].equals(attrDefs[i].getName()))
                     {
                        mFirstDisplayAttr = attrDefs[i];
                        break;
                     }
                  }
               }
               if (mFirstDisplayAttr == null)
               {
                  mFirstDisplayAttr = getAttributeDef(0);
               }
            }

            if (val == getNullValueString()) 
            {
               listIndex = mNullValueIndex;
            }
            else
            {
               Class adClass = mFirstDisplayAttr.getJavaType();
               for (int j = 0; j < mValueList.length; j++)
               {
                  lovRow = (j != mNullValueIndex) ? (Row)mValueList[j] : null;

                  if (val == null)
                  {
                     if (lovRow == null)
                     {
                        listIndex = j;
                        break;
                     }
                     else
                     {
                        if (lovRow.getAttribute(0) == null) 
                        {
                           listIndex = j;
                           break;
                        }
                     }

                  }
                  else if (lovRow != null)
                  {
                     try
                     {
                        Object convVal = TypeFactory.getInstance(adClass, val);
                        //do we have to worry about null values here? only if getAttribute(0) returns null
                        //which we assume is unlikely for lists!
                        if (convVal != null && convVal.equals(lovRow.getAttribute(mFirstDisplayAttr.getIndex())))
                        {
                           listIndex = j;
                           break;
                        }
                     }
                     catch (JboException je)
                     {
                        if (getIteratorBinding().isFindMode())
                        {
                           //in findmode, this value can be a where-clause predicate
                           //with comparators. That may not convert to typed values,
                           //so return -1 as the selected index.
                           listIndex = -1;
                           break;
                        }
                        throw je;
                     }
                  }
               }
            }
         }
      }

//      mSelectedIndex = listIndex;
      
//      return mSelectedIndex;
     if(listIndex<0) 
     {
         this.notifyValueNotFound(val);
     }
     return listIndex;
   }

   private void notifyValueNotFound(Object value) 
   {
     //if there are no listeners, we don't need to do anything.
     //Swing will call us twice to find a value, so we check the value
     //and call our listeners only once.
     if(this.listenerList!=null && (value==null || !value.equals(valueNotFound)))
     {
         valueNotFound = value;
         JUCtrlListBindingChangeEvent event = new JUCtrlListBindingChangeEvent(this,value);
         for(int i=0;i<this.listenerList.size();i++)
         {
           ((JUCtrlListBindingChangeListener)this.listenerList.get(i)).valueNotFound(event);   
         }
     }
   }

   // makes the attribute value the default value for the binding object when the expression language is used
   // This takes out one level while using the binding
   public String toString()
   {
      Object value = String.valueOf(getSelectedIndex());
      return (value != null) ? value.toString() : "";
   }
   
   public Object findValue(Object val)
   {
      if (mValueList == null || mValueList.length == 0)
      {
         return null;
      }

      return getValueFromList(findListIndex(val));
   }


   public Object getValueFromList(int listIndex)
   {
      if (listIndex >= 0 && listIndex < mValueList.length)
      {
         return mValueList[listIndex];
      }
      else
      {
         return null;
      }
   }

   protected boolean isViewInitialized()
   {
      return true;
   }

   /**
    * For ADF/nonJClient apps return true so that
    * list bindings are created as queriable if the
    * bound iteratorBinding allows findmode.
    */
   protected boolean isControlQueriable()
   {
      DCIteratorBinding iter = getIteratorBinding();
      if (iter != null && iter.getDataControl() != null)
      {
         if (!iter.getDataControl().isJClientApp())
         {
            return iter.isFindModeAllowed();
         }
      }
      return false;
   }

   public void updateValuesFromRow(Row row)
   {
      if (mValueList == null || !isViewInitialized() || !mListPrepared) 
      {
         setupListItems(true, false);
      }
      else if (mListIterBinding != null)
      {
         DCDataControl dc = mListIterBinding.getDataControl();
         if (dc != null && dc.syncNeeded())
         {
            //in sync=batch mode, check if rsi is executed before going ahead with
            //update values.
            RowSetIterator rsi = mListIterBinding.getRowSetIterator();

            if (rsi == null || rsi.getCurrentRowSlot() != RowSetIterator.SLOT_VALID)
            {
               if (rsi == null || rsi.getRowSet() == null || !rsi.getRowSet().isExecuted())
               {
                  Diagnostic.println("List iterator has not been synced yet.");
                  return;
               }
            }
         }
      }
      if (mSingleAttrList) 
      {
         Object ctrl = getControl();
         boolean enabled = false;
         if (ctrl instanceof java.awt.Component) 
         {
            enabled = (mListOperMode == LIST_OPER_NAVIGATE) && ((java.awt.Component)ctrl).isEnabled();
         }

         super.updateValuesFromRow(row);

         if (enabled)
         {
            super.setControlEnabled(enabled);
         }

         if (row != null)
         {
            setValueAt(row.getAttribute(getAttributeDef().getIndex()), 0);
         }
         else
         {
            setValueAt(getAttribute(), 0);
         }
      }
      else
      {
         //update the list with the current row.
         setValueAt(row, -1);

         //do not set control disabled if in navigation mode
         //as that'd disable the control and make is unusable in the UI.
         if (mListOperMode != LIST_OPER_NAVIGATE)
         {
            Object ctrl = getControl();
            if (ctrl instanceof java.awt.Component) 
            {
               boolean attrEnabled = true;
               int ct = getAttributeCount();
               for (--ct; attrEnabled && ct >= 0; --ct) 
               {
                  attrEnabled &= isAttributeUpdateable(ct);
               }

               //forcing enabled here without check leads to a Locked state
               //while drawing up UIs for scrolbars etc. some guava tests block
               java.awt.Component comp = (java.awt.Component) ctrl;
               boolean compEnabled = comp.isEnabled();
               if (compEnabled != attrEnabled) 
               {
                  super.setControlEnabled(attrEnabled);
               }

            }
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   protected void setTargetAttrsFromLovRow(Row targetRow, Row lovRow)
   {
      AttributeDef ads[] = getAttributeDefs();

      int size = mListAttrNames.length;
      for (int i = 0; i < size; i++) 
      {
         setAttributeInRow(targetRow, ads[i], getLovRowData(lovRow, mListAttrNames[i]));
      }
      //for 3tier, after the dialog comes out, we need to sync with MT as 
      //setAttributes in the above needs to be brought back so that other
      //controls listening on the updated-data redisplay themselves.

      if (getIteratorBinding().getDataControl().isClientTier())
      {
         //we could do a sync but that'd cause a network roundtrip which may be too much
         //for cases like a listbox/combobox LOV. Instead, just update this iterator binding
         //or may be throw an update notification from the RSI?

         //What if there are more than one iteratorbinding's working on the same iterator?
         //If that's the case (which I think would be 20 side of the 80/20 rule), I'd leave
         //it for the app to workaround this issue by calling a sync or a rangeRefresh() event
         //individually on the iteratorBindings rather than penalizing most apps with a roundtrip.

         JUIteratorBinding iter = getIteratorBinding();
         int[] attrIndices = new int[size];
         for (size--; size >= 0; size--) 
         {
            attrIndices[size] = ads[size].getIndex();
         }
         iter.rowUpdated(new oracle.jbo.UpdateEvent(iter.getRowSetIterator(), targetRow, -1, attrIndices));
      }
   }

   public void setAttributeFromValueList(int listIndex)
   {
      try
      {
         //do nothing if there is no current row in the target
         //iterator as there's nothing to update.
         if (getIteratorBinding() != null) 
         {
            Row row = getCurrentRow();
            if (isAttrValueAccesible(row))
            {
               updateTargetFromSelectedValue(getValueFromList(listIndex));
            }
         }
      }
      catch(Exception ex)
      {
         reportException(ex);
      }
   }

   protected void updateTargetFromSelectedValue(Object val)
   {
      if (!isSingleAttrList()) 
      {
         if (!(val instanceof Row)) 
         {
            if (val != null)
            {
               //val is first attribute of this row.
               val = findMatchingListValue(val);

               if (val == getNullValueString()) 
               {
                  val = null;
               }
               else if (val == null) 
               {
                  if (!getIteratorBinding().isFindMode()) 
                  {
                     reportException(new oracle.jbo.JboException(UIMessageBundle.class, UIMessageBundle.EXC_NO_MATCHING_ROW_IN_LOV, null));
                  }
               }
            }
            //if val is null, then null will be set for the target attrs.
         }

         //mSelectedIndex is adjusted in findMatchingListValue 
         if (getIteratorBinding() != null) 
         {
            Row row = getCurrentRow();
   
            if (row != null)
            {
               setTargetAttrsFromLovRow(row, (Row)val);
            }
            else
            {
               //ignore null row.
            }
         }

      }
      else
      {
         if (val == getNullValueString()) 
         {
            val = null;
         }
         setAttribute(0, val);
      }
   }

   
   /**
    * *** For internal framework use only ***
    */
   Object[] getAttrValuesFromRSI()
   {

      //addnull
      boolean listRSIOpen = false;
      
      RowSetIterator listRSI = (mListIterBinding != null) ? mListIterBinding.getRowSetIterator() : null;
      String[] listAttrNames = this.mListAttrNames;
      JUIteratorBinding iterBinding = getIteratorBinding();

      try
      {
         int index = 0;
         if (listRSI == null)
         {
            if (iterBinding == null)
            {
               return new Object[0];
            }
            
            RowSetIterator bndRSI = iterBinding.getRowSetIterator();
            
            if (bndRSI == null)
            {
               return new Object[0];
            }
            
            if(bndRSI.getRowSet() != null)
            {
               listRSI = bndRSI.getRowSet().createRowSetIterator(null);
               listRSIOpen = true;
            }

            //if target iterator is assumed as list iterator
            //use attribute index from the target iterator's attribute defs.
            if (listAttrNames != null)
            {
               AttributeDef ads[] = iterBinding.getAttributeDefs(listAttrNames);
               index = (ads != null && ads.length > 0) ? ads[0].getIndex() : 0;
            }
         }

         if (listRSI != null)
         {
            //if list rangesize is 1 or listIterBinding.rangeSize is DO_NOT_OVERRIDE, 
            //then get all rows as someone is using a list to navigate or display source
            // while the range size may be 1.
            if (mListIterBinding == null || mListIterBinding.getRangeSize() < 2)
            {
               if (mListIterBinding != null)
               {
                  mListIterBinding.setRangeSize(-1);
               }
               else
               {
                  listRSI.setRangeSize(-1);
               }

               //if in batchmode we want to go and get all rows right?
               //this is a bug in 9051.
            }
            Row[] rows = listRSI.getAllRowsInRange();

            if (listAttrNames != null && mListIterBinding != null)
            {
               AttributeDef ads[] = mListIterBinding.getAttributeDefs(listAttrNames);
               index = (ads != null && ads.length > 0) ? ads[0].getIndex() : 0;
            }

            Object[] valueList = new Object[rows.length];
            for (int j = 0; j < valueList.length; j++)
            {
               valueList[j] = rows[j].getAttribute(index);
            }

            //addListener guarentees that a listener is not added more than once.
            listRSI.addListener(this);
            return (valueList);
         }
         return new Object[0];

      }
      catch(Exception ex)
      {
         oracle.jbo.common.Diagnostic.printStackTrace(ex);
         iterBinding.getBindingContainer().reportException(ex);
      }
      finally
      {
         if (listRSIOpen)
         {
            listRSI.closeRowSetIterator();
         }
      }
      
      return null;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      //if iteratorBinding is marked to not handle events, then set the list values only.
      //this will set the values again from new list (as sent in the rangeRefreshed).
      setupListItems(true, !(getIteratorBinding() != null && getIteratorBinding().isSuspendRowSetEventsHandling()));
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowInserted(InsertEvent event)
   {
      if (getIteratorBinding() != null && getIteratorBinding().isSuspendRowSetEventsHandling()) return;

      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowDeleted(DeleteEvent event)
   {
      if (getIteratorBinding() != null && getIteratorBinding().isSuspendRowSetEventsHandling()) return;

      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void rowUpdated(UpdateEvent event)
   {
      if (getIteratorBinding() != null && getIteratorBinding().isSuspendRowSetEventsHandling()) return;

      setupListItems(true, true);
   }
   
   /**
   * *** For internal framework use only ***
   */
   public void navigated(NavigationEvent event)
   {
      // Don't forget to enable the following if you add handling.
      // if (getIteratorBinding().isSuspendRowSetEventsHandling()) return;
   }

   /**
   * *** For internal framework use only ***
   */
   public void rangeScrolled(ScrollEvent event)
   {
      if (getIteratorBinding() != null && getIteratorBinding().isSuspendRowSetEventsHandling()) return;

      Object srcRSI = event.getSource();
      if (srcRSI instanceof RowSetIterator)
      {
         //if list is bound to a range of rows and not all rows.
         if (((RowSetIterator)srcRSI).getRangeSize() > 1)
         {
            setupListItems(true, true);
         }  
      }
   }
   
   /**
   * Notifies rangeRefreshed to all bindings so that
   * they can update their display.
   * @internal *** For internal framework use only *** 
   */
   public void iteratorReset(RowSetManagementEvent event)
   {
   }


   /**
   * Resets the internal state of this binding object and marks it as unusable.
   * @internal *** For internal framework use only *** 
   */
   public void iteratorClosed(RowSetManagementEvent event)
   {
      if (!this.mStaticList)
      {
         mListPrepared = false; //so that on next 'attach' list is built again.
         mValueList = null;
      }
   }

    /**
      * Remove a listener.
      * @see JUCtrlListBindingChangeListener
      * @param listener
      */
    public void removeBindingChangeListener(JUCtrlListBindingChangeListener listener)   
    {
      if(this.listenerList!=null) 
      {
          this.listenerList.remove(listener);
      }
    }

   public void release(int flags)
   {
      //lets just clean it in both view/data cases as next time we come in, we do need
      //to re-establish the list anyway.
      RowSetIterator listRSI = (mListIterBinding != null && mListIterBinding.isBound()) 
                                ? mListIterBinding.getRowSetIterator() 
                                : null;
      if (listRSI != null) 
      {
         listRSI.removeListener(this);
         listRSI.removeManagementListener(this);
      }
      
      // JRS Bug 3498424.  Do this even if the list IB is not bound.  In some
      // cases the IB may be unbound before the control binding is released.
      //
      // Actually, I think we should just perform release on control bindings
      // before we do on JUIteratorBindings.  Leaving this here just in case
      // -- can't hurt.
      if (!this.mStaticList)
      {
         mListPrepared = false; //so that on next 'attach' list is built again.
         mValueList = null;
      }
      super.release(flags);
   }

   public void setDataValueAt(Object value, int attrIndex)
   {
    //TODO Shailesh, what happens here?    
   }
   
   public void setValueAt(Object value, int attrIndex)
   {
     if (getControl() == null)
     {
        mSelectedIndex = findListIndex(value);
     }
   }
   
   /**
     * Register a listener.
     * @see JUCtrlListBindingChangeListener
     * @param listener
     */
   public void addBindingChangeListener(JUCtrlListBindingChangeListener listener)   
   {
     if(this.listenerList==null) 
     {
         this.listenerList = new ArrayList();
     }
     this.listenerList.add(listener);
   }
   
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
    // TODO: Shailesh, what happens here?  
   }
   
   public Object put(Object obj, Object value)
   {
      if (obj instanceof String)
      {
         String key = ((String)obj).intern();
         if (ATTR_SELECTED_INDEX == key)
         {
            /*
            try
            {
               if (value != null)
               {
                  Integer intVal = (Integer)TypeFactory.getInstance(java.lang.Integer.class, value);
                  setSelectedIndex(intVal.intValue());
               }
               else
               {
                  setSelectedIndex(-1);
               }
            }
            catch (Exception e)
            {
               //need to hold this somewhere.

            }
            */
            Object ret = getInputValue();
            setInputValue(value);
            return ret;
         }
      }
      return super.put(obj, value);
   }

   
   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get() 
    * method for spel-access.
    * <p>
    * Returns the last input value for the first attribute on this binding if this value 
    * raised an exception. Otherwise returns the value from the model object calling
    * getAttribute(0);
    * @javabean.property
    */
   public Object getInputValue()
   {
      getError();
      if (mErrExc != null) 
      {
         return mInputVal;
      }
      int sel = getSelectedIndex();
      if (mInputVal != null && (sel == -1 || sel == mNullValueIndex))
      {
         return mInputVal;
      }
      return new Integer(sel);
   }

   /**
    * Primarily for spel support. Could be removed prior to 905Prod and merged into a get() 
    * method for spel-access.
    * <p>
    * Sets the value given and caches any error/exception in member variables
    * for further access. Also rethrows the exception for outer methods to catch it.
    */
   public void setInputValue(Object value)
   {
      try
      {
         mInputVal = value;
         mHasInputVal = true;
         //in batch mode exception is not raised right away but on sync/validate
         //in that case HasInputVal is to be set to true so that on error processing
         //errors are cached 
         if (value != null)
         {
            try
            {
               Integer intVal = (Integer)TypeFactory.getInstance(java.lang.Integer.class, value);
               setSelectedIndex(intVal.intValue());
            }
            catch (Exception e)
            {
               //value is not an integer and needs to be matched with items in the list.
               setSelectedIndex(findListIndex(value));
            }
         }
         else
         {
            setSelectedIndex(-1);
         }
         //setSelectedIndex(findListIndex(value));
      }
      catch (JboException e)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("CtrlAttrs: Caching exception :"+e);
         }
         setError(e, value);
         //exception is already passed to bindingContainer and from 
         //there to custom error handler and back to the binding
         //no need to rethrow this.
         //throw e; 
      }
   }

   
   /**
   * Returns a List of Map elements. Each map entry contains the following four elements:
   * <li><code>selected</code> - Boolean.TRUE if current entry should be selected</li>
   * <li><code>index</code> - Index value of the current entry()</li>
   * <li><code>prompt</code> - Concatenated string of all display attribute values for the current entry()</li>
   * <li><code>displayValues</code> - Iterator of display attribute values.</li>
   * <li><code>selectedIndex</code> - Index of the selected entry that this listBinding is bound to.
   * <p>
   * Returns null if the list of values for this binding is null. This condition should 
   * not occur if the list-binding definition is complete.
   */
   public List getDisplayData()
   {
    thisBindingObj = this;
    if (mValueList == null)
    {
       setupListItems(true, true);
    }
   
    if (mValueList != null)
    {
       currentSetRef = new JUCtrlListBindingItemRef[mValueList.length];
       return new java.util.AbstractList()
       {
          public Object get(int i)
          {
             if (i < mValueList.length && currentSetRef[i] == null)
             {
                currentSetRef[i] = new JUCtrlListBindingItemRef(i);
             }
             return currentSetRef[i];
          }
   
          public int size()
          {
             return mValueList.length;
          }
       };
    }
    return null;
   }
   
   /**
   * Returns a List of Map elements (name-value pairs) for UI hints for 
   * all display attributes in this list binding. 
   * The map contains the following elements:
   * <li><code>label</code> - Label to display for the current attribute</li>
   * <li><code>tooltip</code> - Tooltip to display for the current attribute</li>
   * <li><code>displayHint</code> - DisplayHint for the current attribute</li>
   * <li><code>displayHeight</code> - Height in lines for the current attribute</li>
   * <li><code>displayWidth</code> - Width in characters for the current attribute</li>
   * <li><code>controlType</code> - ControlType hint for the current attribute</li>
   * <li><code>format</code> - Format to be used for the current attribute</li>
   */
   public List getDisplayHints()
   {
     AttributeDef[] attrs = getDisplayAttributeDefs();
     ArrayList al = new ArrayList();
     AttributeHints hints;
     HashMap map;
     for (int i = 0; i < attrs.length; i++)
     {
        map = new HashMap(10);
        hints = attrs[i].getUIHelper();
        map.put(DH_LABEL,   hints.getLabel(getLocaleContext()));
        map.put(DH_TOOLTIP, hints.getTooltip(getLocaleContext()));
        map.put(DH_DISPLAY_HINT, hints.getDisplayHint(getLocaleContext()));
        map.put(DH_DISPLAY_HEIGHT, new Integer(hints.getDisplayHeight(getLocaleContext())));
        map.put(DH_DISPLAY_WIDTH, new Integer(hints.getDisplayWidth(getLocaleContext())));
        map.put(DH_CONTROL_TYPE, new Integer(hints.getControlType(getLocaleContext())));
        map.put(DH_FORMAT, hints.getFormat(getLocaleContext()));
        al.add(map);
     }
     return al;
   }
   
   
   /**
   * Subclasses should override this to handle a specific key.
   * If they do find the key valid, they should also set the
   * mInternalGet_KeyResolved to  'true' so that bean-introspection
   * is not done for valid null-value returns from the internalGet() call.
   * <p>
   * Properties returned vis getter on this control bindings are:
   * <li><code>displayHints</code> - returns getDisplayHints()</li>
   * <li><code>displayData</code>  - returns getDisplayData()</li>
   * <li><code>path</code> - returns getPath()</li>
   */
   protected Object internalGet(String key)
   {
     key = key.intern();
     if (ATTR_DISPLAY_DATA == key)
     {
        mInternalGet_KeyResolved = true;
        return getDisplayData();
     }
     if (ATTR_DISPLAY_HINTS == key)
     {
        mInternalGet_KeyResolved = true;
        return getDisplayHints();
     }
     /*
     JUCtrlValueBinding.internalGet will return getPath 
     if (key == ATTR_PATH)
     {
        mInternalGet_KeyResolved = true;
        return getPath();
     }
     */
   
     //let these go via introspection.
     //if (key == ATTRIBUTE_CTL_TYPE)
     //if (key == ATTRIBUTE_CTL_DISPLAYWIDTH)
     //if (key == ATTRIBUTE_CTL_DISPLAYHEIGHT
     //if (key == ATTRIBUTE_CTL_FORMTYPE
     return super.internalGet(key);
   }
   
   protected AttributeDef[] getDisplayAttributeDefs()
   {
     if (mDisplayAttrs == null)
     {
        AttributeDef displayAttrs[] = null;
        if (getListOperMode() == LIST_OPER_NAVIGATE)
        {
           displayAttrs = getAttributeDefs();
        }
        else if (mListIterBinding != null)
        {
           AttributeDef ad;
           ArrayList adList = null;
           int i = 0;
           DCIteratorBinding listValuesBinding = mListIterBinding;

           String[] lovVODisplayedAttrNames = mListDisplayAttrNames;

           if (lovVODisplayedAttrNames == null)
           {
              int kind;
              ArrayList al = null;
              AttributeDef[] ads = listValuesBinding.getAttributeDefs();
              int count = ads.length;

              adList = new ArrayList(count);
              al = new ArrayList(count); 
              for (i = 0; i < count; i++)
              {
                 ad = ads[i];
                 kind = ad.getAttributeKind();
                 if (kind == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR
                     || kind == AttributeDef.ATTR_ASSOCIATED_ROW)
                 {
                    continue;
                 }
                 al.add(ad.getName());
                 adList.add(ad);
              }

              lovVODisplayedAttrNames = (String[])al.toArray(new String[al.size()]);
           }
           else if (listValuesBinding != null)
           {
              AttributeDef ads[] = listValuesBinding.getAttributeDefs(lovVODisplayedAttrNames) ;
              int count = ads.length;
              adList = new ArrayList(count);

              for (i = 0; i < count; i++)
              {
                 adList.add(ads[i]);
              }
           }
           else
           {
              adList = new ArrayList(0);
           }
           displayAttrs = (AttributeDef[])adList.toArray(new AttributeDef[adList.size()]);
        }
        //mDisplayAttrs = mListIterBinding.getAttributeDefs(mListDisplayAttrNames);
        mDisplayAttrs = displayAttrs;
     }
     return mDisplayAttrs;
   }

  /**
   * Compares the value (assumed to be a numeric String or an Integer) with currently
   * selected index in this listbinding and if different, then returns true.
   * @param value new selectedIndex value.
   */
   public boolean processNewInputValue(Object value)
   {
      DCIteratorBinding iter = getIteratorBinding();
      if (iter != null)
      {
         iter.prepareForInput();
      }

      Object val = getInputValue();
      try
      {
         value = (Integer)TypeFactory.getInstance(java.lang.Integer.class, value);
      }
      catch (Exception e)
      {
         //new value is different try applying it.
         //also inputValue may be a String based on displayed values.
         //in that case it needs to matched via items in the list.
         value = new Integer(findListIndex(val));
      }

      //if InputValue = current selection is same as value, then it's not a new value.
      //otherwise it is.
      return (!(value.equals(val)));
   }

   protected void setStaticList(boolean staticList)
   {
   	mStaticList=staticList;
   }


   /**
    * Given a map of attribute names and values that they map to,
    * shorten the data that this list is exposing. 
    * <p>
    * This method establishes a new ViewCriteria on the collection
    * that the list source iterator binding is bound to. Looks up
    * values from the given map based on the Attribute names in 
    * the associated list source collection and sets the corresponding
    * values on a new ViewCriteria row that is added to the ViewCriteria
    * and then applied on the collection to filter the collection.
    * <p>
    * If the filtered list has only one row then that row is assumed
    * as the selected row and list selection index is set to that row.
    */
   public void filterList(Map valuesMap)
   {
      if (valuesMap == null || valuesMap.size() == 0) 
      {
         return;
      }

      Row vcrow;
      ViewCriteria vc;
      Row rows[];
      DCIteratorBinding listIter = getListIterBinding();
      
      //AttributeDef defs[] = listIter.getAttributeDefs();

      RowSetIterator rsi = listIter.getRowSetIterator();
      
      vc = listIter.getDataControl().createViewCriteria(listIter);

      //vc.setCriteriaForQuery(false);
      vcrow = vc.createRow();
      vc.insertRow(vcrow);

      Iterator keyIter = valuesMap.keySet().iterator();
      String attrName;
      Object value;
      String val;
      while (keyIter.hasNext()) 
      {
         attrName = (String)keyIter.next();
         value = valuesMap.get(attrName);
         if (value != null) 
         {
            val = value.toString().trim();

            //this * wildchar needs to be platform specific.
            //how do we get this for all cases? assume *
            if (!(val.endsWith("%") || val.endsWith("*"))) 
            {
               val = val + '*';
            }

            vcrow.setAttribute(attrName, val);
         }
      }

      //todo: modify this impl in future to use findByViewCriteria
      //to avoid execution. Also we need similar implementation for
      //non bc4j dcs.

      //rows = rsi.findByViewCriteria(vc, -1, oracle.jbo.ViewObject.QUERY_MODE_SCAN_VIEW_ROWS);

      //listIter.getViewObject().applyViewCriteria(vc);
      listIter.getDataControl().applyViewCriteria(vc, listIter, rsi);

      listIter.executeQuery();
      if (listIter.getDataControl().syncNeeded()) 
      {
         getBindingContainer().refreshControl();
      }

      rows = listIter.getAllRowsInRange();
      //addNullAndSetValueList(rows);

      //if (getControl() != null) 
      //{
         //for JClient 
         //rangeRefreshed(null);
      //}

      if (rows.length == 1)
      {
         if (getNullValueIndex() == 0) 
         {
            setSelectedIndex(1);
         }
         else
         {
            setSelectedIndex(0);
         }
      }

      vc = listIter.getViewCriteria();
      if (vc.getRowCount() > 0) 
      {
         vc.first().remove();
      }
   }


   class JUCtrlListBindingItemRef extends JboAbstractMap
   {
      int mIndex = -1;
      JUCtrlListBindingItemRef(int index)
      {
        mIndex = index;
      }
      
      public Object get(Object key)
      {
        if (key instanceof String)
        {
           String keyStr = ((String)key).intern();
           if (LISTITEM_Selected == keyStr)
           {
              return Boolean.valueOf(mIndex == thisBindingObj.mSelectedIndex);
           }
           if (LISTITEM_Index == keyStr)
           {
              return String.valueOf(mIndex);
           }
           if (LISTITEM_Prompt == keyStr)
           {
              return getMergedPrompt();
           }
           if (LISTITEM_DisplayValues == keyStr)
           {
              return getDisplayValues();
           }
           if(LISTITEM_SelectedIndex == keyStr)
           {
              return String.valueOf(thisBindingObj.mSelectedIndex);
           }
        }
        return null;
      }
      
      String getMergedPrompt()
      {
         return JUCtrlValueBinding.getMergedAttributeValues(getDisplayValues());
      }
      
      List getDisplayValues()
      {
         
         Object myValue = thisBindingObj.mValueList[mIndex];
         if (myValue instanceof Row)
         {
            return thisBindingObj.getAttributes((Row)myValue, getDisplayAttributeDefs());
         }
         else
         {
            ArrayList al = new ArrayList();
            al.add(myValue);
            return al;
         }
      }
   }

   /**
    * Overridden to return true incase of NavigationListBinding,
    * so that list component is rendered as enabled.
    */
   public boolean isUpdateable()
   {
      if (mListOperMode != LIST_OPER_NAVIGATE)
      {
         return super.isUpdateable();
      }

      return true;
   }
}
