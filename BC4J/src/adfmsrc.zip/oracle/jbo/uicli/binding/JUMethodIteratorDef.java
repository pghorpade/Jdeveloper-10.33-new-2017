/*
 * @(#)JUMethodIteratorDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCExecutableBindingDef;
import oracle.adf.model.binding.DCIExecutable;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCInvokeMethod;
import oracle.adf.model.binding.DCInvokeMethodAdapter;
import oracle.adf.model.binding.DCInvokeMethodEvent;
import oracle.adf.model.binding.DCUtil;

import oracle.adf.model.generic.DCRowSetIteratorImpl;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.JboException;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.UIMessageBundle;

public class JUMethodIteratorDef extends JUIteratorDef
{
   String mBeanClass;
   private boolean mCheckParams = true;
   // JRS 3289782 Why is IteratorBinding usage state defined on the def?
   // boolean mHasResult = false;

   public JUMethodIteratorDef()
   {
      super();
      setSubType(PNAME_MethodIterator);
   }

   public String getBeanClassName()
   {
      return mBeanClass;
   }

   public boolean isRefreshable(DCBindingContainer ctr, DCIExecutable exec, int refreshFlag)
   {
      boolean flag;
      if (!(flag = super.isRefreshable(ctr, exec, refreshFlag)))
      {
         //this setsup a listener to the actionbinding so that
         //when that's invoked this iterator is refreshed.
         ((JUMethodIteratorBinding)exec).getActionBinding();
      }
      return flag;
   }

   public String getActionBindingName()
   {
      String actionResult = getBindsName();
      return oracle.jbo.common.JboNameUtil.getContainerPartOfName(actionResult);
   }

   boolean isCheckParams()
   {
      return mCheckParams;
   }

         
   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc, oracle.jbo.ApplicationModule anchorAM)
   {
      DCIteratorBinding iter = createIterBinding(ctx, bc);
      iter.setRowSetEventsEnabled(false);
      return iter;
   }

   public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bc)
   {
      //use range size set from the def as UIs may want to set the desired range.
      //in JClient if this is not set, then we end up with table with one row!
      return new JUMethodIteratorBinding(ctx, getDataControlName(), getBindsName(), getRSIName(), getRangeSize());
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, JUTags.DataControl, valueTab);
      readXMLString(xmlElement, JUTags.BeanClass, valueTab);
      readXMLBoolean(xmlElement, JUTags.CheckParams, valueTab);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      if ((val = initValues.get(JUTags.BeanClass)) != null)
      {
         mBeanClass = val.toString();
      }
      if ((val = initValues.get(JUTags.CheckParams)) != null)
      {
         mCheckParams = convertToBoolean(val);
      }


   }

   class JUMethodIteratorBinding extends JUIteratorBinding
   {

      String  mResultName;
      String  mActionName;
      JUCtrlActionBinding mAction;
      //boolean mLocalRefreshed = false;
      boolean mHasResult = false;
      boolean mInExecute = false;

      JUMethodIteratorBinding(BindingContext ctx, 
                              String dcName, 
                              String bindsName,
                              String rsiName, 
                              int rangeSize)
      {
         super(ctx, dcName, bindsName, rsiName, rangeSize);
      }

      Object invokeMethodAction()
      {
         //mLocalRefreshed = true;
         super.setRefreshed(true);
         Object result = null;
         mHasResult = true; //result was null!
         //throw new oracle.jbo.InvalidParamException("JUIteratorBinding.initSourceRSI()", "", "", "Method that creates the iterator for this object has not been executed or returns null.");
         //attempt to call this method. If it still returns null, then throw the above exception.
         DCBindingContainer ctr = getBindingContainer();
         JUCtrlActionBinding action = getActionBinding();
         if (action != null)
         {
            boolean flag = ctr.isErrorHandlerActive();
            if (flag)
            {
               ctr.setErrorHandlerActive(false);
            }
            try
            {
               action.invoke();
               result = ctr.findNamedObject(getResultName());  
            }
            catch (JboException e)
            {
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("Exception during implicit execution of method bound to iteratorBinding:"+getName());
               }
               throw e;
            }
            finally
            {
               if (flag)
               {
                  ctr.setErrorHandlerActive(true);
               }
            }
         }
         return result;
      }

      JUCtrlActionBinding getActionBinding()
      {
         if (mAction == null) 
         {
            if (mActionName == null)
            {
               //String actionResult = super.getSourceName();
               mActionName = getActionBindingName();
            }
            if (mActionName != null) 
            {
               Object action = getBindingContainer().findNamedObject(mActionName);  
               if (action instanceof JUCtrlActionBinding)
               {
                  mAction = (JUCtrlActionBinding)action;
                  
                  DCInvokeMethod methodInfo = (DCInvokeMethod)mAction.getOperationInfo();
                  if (methodInfo instanceof DCInvokeMethod) 
                  {
                     methodInfo.setCacheResolvedValues(true);
                     methodInfo.addInvokeMethodListener(
                        new DCInvokeMethodAdapter()
                        {
                           RowSetIterator oldRSI;
                           public void beforeInvokeMethod(DCInvokeMethodEvent ev)
                           {
                              //clearout rsi.
                              //needsRefresh = mHasResult;

                              if (hasRSI())
                              {
                                 oldRSI = getRowSetIterator();
                              }
                           }

                           public void afterInvokeMethod(DCInvokeMethodEvent ev)
                           {
                              if (!mInExecute) 
                              {
                                 executeQueryIfNeeded();
                              }
                              if (oldRSI == getRowSetIterator()
                                  && getDataControl().isJClientApp())
                              {
                                 //in case of jclient, send event to 
                                 //UI to update themselves 
                                 //as there's no change in RSI and 
                                 //executeQueryIfNeeded() would not do it
                                 //if RSI reference did not change
                                 //even though it's been reprepared
                                 rangeRefreshed(null);
                              }
                           }
                        }
                     );
                  }
               }
            }
         }
         return mAction;
      }

      public void bindRowSetIterator(oracle.jbo.NavigatableRowIterator iter, boolean initRangeSize)
      {
         super.bindRowSetIterator(iter, initRangeSize);
         if (!hasRSI())
         {
            mHasResult = false;
         }
      }

      public void executeQueryIfNeeded()
      {
         synchronized(getSyncLock())
         {
            JUCtrlActionBinding action = getActionBinding();
            if (action != null) 
            {
               DCDataControl dc = getDataControl();
               boolean hasRSI = hasRSI();
               //if has rsi and parameters have changed
               //or if this rsi was never bound (gvrdefer sv38)
               
               //if ((hasRSI && dc.hasOperationParamsChanged(action.getOperationInfo()))
               //   || (!(hasRSI || isBound())))
               
               boolean checkParams = true;

               // if isCheckParams is false then only check the params if
               // we have not cached a result set
               if (!((JUMethodIteratorDef)getDef()).isCheckParams()) 
               {
                  checkParams = (getBindingContainer().findNamedObject(
                     getResultName()) == null);  
               }

               if (checkParams && dc.hasOperationParamsChanged(action.getOperationInfo()))
               {
                  //more like executeQuery.
                  //invokeMethodAction();
                  executeQuery();
                  return;
               }

               //this will set or reset mIsBound again.
               initSourceRSI();
            }
            super.executeQueryIfNeeded();
         }
      }

      /**
      * Executes the query or the RowSet behind this iterator binding object.
      */
      public void executeQuery()
      {
         //if this is on, then invokeMethodAction will not be called.
         //mHasResult = true;
         RowSetIterator rsi = null;
         if (mHasResult)
         {
            rsi = getRowSetIterator();
            bindRowSetIterator(null, false);
         }

         // JRS Why doesn't this clear the RSI current data?
         // For acceessor RSIs this is typically performed
         // by DCGenericDataControl.executeIteratorBinding.  Why doesn't
         // this method call back to DCDataControl?  Added clearCurrentData
         // here for now.  Evaluate invoking execute on DCGenericDataControl
         // in the future (I suspect it's related to difference in implicit
         // method invocation).
         //JUCtrlActionBinding action = getActionBinding();

         //look for method result, if it exists do not reinvoke as this is
         //the first time I'm binding to it. Someone has executed and placed
         //the result for me. It could be a button in this BC or a RSI/button  
         //in previous BC.
         if (rsi != null && (rsi instanceof DCRowSetIteratorImpl))
         {
            //forceInvoke = true;
            ((DCRowSetIteratorImpl)rsi).clearCurrentData();
         }
         

         //force the RSI again.
         try
         {
            mInExecute = true;
            invokeMethodAction();
            mInExecute = false;
         }
         catch (JboException je)
         {
            mInExecute = false;
            if (rsi != null) 
            {
               try
               {
                  //try to rebind the UIs with existing/old
                  //rsi so that display gets updated
                  bindRowSetIterator(rsi, false);
               }
               catch (Exception e)
               {
                  //ignore this inner exception
                  //we already have the outer one that needs
                  //to be generated.
               }
            }
            throw je;
         }

         //force the RSI again.
         initSourceRSI();
      }

      public String getVOName()
      {
         //override to return the VO name as stored in this method definition.
         
         //mSourceName is the path to the VO and that could be a method result path.
         return mBeanClass; 
      }

      public String getSourceName()
      {
         //unwrap the method result name to return the datacontrol relative sourceName
         //for the collection.
         if (mActionName == null && !mHasResult)
         {
            String actionResult = super.getSourceName();
            mActionName = oracle.jbo.common.JboNameUtil.getContainerPartOfName(actionResult);
         }
         if (mActionName != null)
         {
            Object action = getBindingContainer().findNamedObject(mActionName);  
            if (action instanceof JUCtrlActionBinding)
            {
               return ((JUCtrlActionDef)((JUCtrlActionBinding)action).getDef()).getMethodDef().getReturnName();
            }
         }
         return mActionName;
      }

      public void resolveRangeSize(int rangeSize)
      {
         if (mHasResult && getNavigatableRowIterator() != null)
         {
            super.resolveRangeSize(rangeSize);
         }
         //do nothing otherwise.
      }


      public ViewObject getViewObject()
      {
         RowSetIterator rsi = null;
         if (getDataControl().getApplicationModule() != null)
         {
            rsi = getRowSetIterator();
            /*
             * rsi may be null when method returns null
             * also we can have generic collections returned
             * that do not return RSI from Bc4J.
             */
            if (!mHasResult)
            {
               if (rsi == null)
               {
                  throw new InvalidObjAccessException("ViewObject", getVOName());
               }
            }
         }

         if (rsi != null)
         {
            if (rsi.getRowSet() != null)
            {
               return rsi.getRowSet().getViewObject();
            }
         }
         return null;
      }

      /**
      * Utility method to report exceptions via the containing Form binding object.
      */
      public void reportException(boolean markDead, Exception ex)
      {
         if (mResultName != null && markDead)
         {
            super.setAlive(false);
         }

         getBindingContainer().reportException(ex);
      }
      
      //public boolean isRefreshed()
      //{
         //if (mLocalRefreshed && super.isRefreshed()) 
         //{
         //   if (hasRefreshParametersChanged()) 
         //   {
         //      //mLocalRefreshed = false;
         //      super.setRefreshed(false);
         //   }
         //}
         //return super.isRefreshed();
      //}

      public boolean hasRefreshParametersChanged()
      {
         JUCtrlActionBinding action = getActionBinding();
         if (action != null) 
         {
            if (hasRSI())
            {
               DCDataControl dc = action.getDataControl();
               //if (methodInfo.getParameters().length > 0 && methodInfo.hasParameterValuesChanged())
               if (dc.hasOperationParamsChanged(action.getOperationInfo())) 
               {
                  return true;
               }

               //parameters are same, check if result at the result location is
               //different from RSI's dataProvider. This means someone called
               //the method again. That needs refresh to recreate the RSI data.
               RowSetIterator rsi = getRowSetIterator();
               if (rsi instanceof DCRowSetIteratorImpl) 
               {
                  return (((DCRowSetIteratorImpl)rsi).getDataProvider() != action.getResult());
               }
               return (!isRefreshed());
            }
         }
         return super.hasRefreshParametersChanged();
      }

      protected DCDataControl initDataControl()
      {
         if (getDef() != null)
         {
            String dcName = getDef().getDataControlName();
            if (dcName != null)
            {
               //Use this chokepoint to redirect to DCName aliasing in bindingContainer
               //return getBindingContainer().getBindingContext().findDataControl(dcName);
               return getBindingContainer().findDataControl(dcName);
            }
         }
         DCDataControl dc = getActionBinding().getDataControl();
         if (dc != null) 
         {
            return dc;
         }
         return ((getBindingContainer() != null) ? getBindingContainer().getDataControl() : null);
      }
      /**
       * name where the source iterator is found.
       */
      String getResultName()
      {
         return (mResultName != null) ? mResultName : super.getVOName();
      }

      /**
      * @internal *** For internal framework use only *** 
       */
      public boolean allowsRefreshControl()
      {
         return (mHasResult && getNavigatableRowIterator() != null);
      }


      //for both bc4j and bean datacontrols, always go through method invocation for
      //the finder method RSIs.
      protected RowSetIterator initSourceRSI()
      {
         //do not implicitly execute a method rsi. check if
         //is options allow refreshing by default
         DCExecutableBindingDef def = getDef();
         boolean isRefreshable = (def != null && def.isRefreshable(getBindingContainer(), 
                                                          this, 
                                                          getBindingContainer().getTransientRefreshFlag()));
         if (!isRefreshable)                                                
         {
            return null;
         }

         //this is where method-binding control is unparsed
         //bindsName will be a method-binding name inside a method 
         RowSetIterator rsi = null;
         try
         {
            Object result = getBindingContainer().findNamedObject(getResultName());  

            //if invokeMethodAction has been called then mHasResult is true
            if (!mHasResult && result == null)
            {
               result = invokeMethodAction();
               if (result == null)
               {
                  /*
                  throw new InvalidOperException(UIMessageBundle.class,
                                                 UIMessageBundle.EXC_NULL_COLLECTION,
                                                 new Object[] { getName()+".initSourceRSI()" });
                  */
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.println("Warning! <null> found for method iterator at: "+getResultName());
                  }
               }
            }
            else if (mAction == null)
            {
               //this setup this binding as a listener to the method action
               //for notifications when the action is invoked directly.
               getActionBinding();
            }

            if (mResultName == null)
            {
               mResultName = super.getVOName();
            }
            
            if (result instanceof RowSetIterator)
            {
               rsi = (RowSetIterator)result;
               mHasResult = true; //has a valid RSI
               //mLocalRefreshed = true;
               setRefreshed(true);
            }
            else if (result != null)
            {
               rsi = getDataControl().findOrCreateMethodRowSetIterator(this, mBeanClass, result);
               mHasResult = true; //has a valid RSI
               //mLocalRefreshed = true;
               setRefreshed(true);
            }
            
            setRowSetEventsEnabled(true); 


            //as this will change the mSourceName
            bindRowSetIterator(rsi, true);
            
            //this gets restored to false in bindRSI when null rsi is set on it and it thinks 
            // it needs to reexecute for the result.
            mHasResult = true;
            if (allowsRefreshControl() && !getDataControl().isJClientApp())
            {
               rangeRefreshed(null);
            }

         }
         catch (oracle.jbo.JboException e)
         {
		//NISHAH for bug5601026 fix. Exception should be thrown irrespective of the value of 'rsi' 
		//and let the application error handler handle the exception message.
            /*if (rsi != null)
            {  
               throw e;
            }*/
            Diagnostic.println("THROWING THE EXCEPTION THIS TIME FROM JUMethodIteratorDef.iniSourceRSI()");
            throw e;
            //ignore and return null.
            //Diagnostic.println("*** IGNORING! following exception in JUMethodIteratorDef.initSourceRSI()");
            //Diagnostic.printStackTrace(e);
         }
         return rsi;
      }

      public void invalidateCache()
      {
         super.invalidateCache();

         JUCtrlActionBinding binding = getActionBinding();
         if (binding != null)
         {
            DCInvokeMethod method = binding.getInvokeMethod();
            if (method != null)
            {
               method.invalidateMethodResults();
            }
         }
      }
   }
}

