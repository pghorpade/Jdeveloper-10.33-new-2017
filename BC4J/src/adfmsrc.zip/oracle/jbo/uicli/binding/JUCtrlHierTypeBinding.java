/*
 * @(#)JUCtrlHierTypeBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.util.HashMap;
import javax.swing.Icon;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;

import oracle.jbo.mom.xml.DefElement;
/**
 *
 * @javabean.class name=JUCtrlHierTypeBinding
 */
public class JUCtrlHierTypeBinding extends JUCtrlValueDef
{
   protected String mVODefName;
   protected String mDiscrColumnName;
   protected Object mDiscrColumnValue;
   protected String[] mChildAccessorNames;
   private String mLeafIcon;
   private String mOpenIcon;
   private String mClosedIcon;
   private JUCtrlHierTypeBinding[] mChildTypeBindings;

   private String mNodeString;

   protected String mViewInstanceName;

   
   public static final String PNAME_TYPE = "JUCtrlHierTypeBinding";

   public static final String PNAME_ViewDefName = "DefName";
   public static final String PNAME_DiscrColumnName = "DiscrName";
   public static final String PNAME_DiscrColumnValue = "DiscrValue";
   public static final String PNAME_AccessorName = "Accessors";
   public static final String PNAME_IconName       = "Icon";
   public static final String PNAME_OpenIconName   = "OpenIcon";
   public static final String PNAME_ClosedIconName = "ClosedIcon";

   public static final String PNAME_ViewInstanceName="DTViewInstanceName";



   public JUCtrlHierTypeBinding()
   {
   }

   
   public JUCtrlHierTypeBinding(String voTypeName, 
                                String discrColumnName, 
                                String discrColumnValue,
                                String accessorName, 
                                String attrName,
                                Icon leafIcon,
                                Icon openIcon,
                                Icon closedIcon
                                )
   {
      super(null, null, null, null, new String[]{attrName});
      mVODefName = voTypeName;
      mDiscrColumnName = discrColumnName;
      mDiscrColumnValue = discrColumnValue;
      mChildAccessorNames = new String[]{accessorName};
      /*
      mLeafIcon   = leafIcon;   
      mOpenIcon   = openIcon;   
      mClosedIcon = closedIcon; 
      */
   }

   
   /**
   * For Framework internal use only
    */
   public void init(HashMap initValues)
   {
      Object val;
      super.init(initValues);

      if ((val = initValues.get(PNAME_ViewDefName)) != null)
      {
         mVODefName = val.toString();
      }

      if ((val = initValues.get(PNAME_DiscrColumnName)) != null)
      {
         mDiscrColumnName = val.toString();
      }
      
      if ((val = initValues.get(PNAME_DiscrColumnValue)) != null)
      {
         mDiscrColumnValue = val.toString();
      }
      
      if ((val = initValues.get(PNAME_IconName)) != null)
      {
         mLeafIcon = val.toString();
      }
      
      if ((val = initValues.get(PNAME_OpenIconName)) != null)
      {
         mOpenIcon = val.toString();
      }
      
      if ((val = initValues.get(PNAME_ClosedIconName)) != null)
      {
         mClosedIcon = val.toString();
      }

      if ((val = initValues.get(PNAME_AccessorName)) != null)
      {
         mChildAccessorNames = (String[])val;
      }

      if ((val = initValues.get(PNAME_ViewInstanceName)) != null)
      {
         mViewInstanceName = (String)val;
      }
   }

   
   /**
   * For Framework internal use only
    */
   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }

   
   /**
   * For Framework internal use only
    */
   public String getStructureDefName()
   {
      return mVODefName;
   }

   /**
   * For Framework internal use only
    * @deprecated since 10.1.3 use getStructureDefName instead.
    * @javabean.property
    */
   public String getViewDefName()
   {
      return mVODefName;
   }

   // used only in DT
   /**
   * For Framework internal use only
   * @javabean.property
   */
   public String getViewInstanceName()
   {
       return mViewInstanceName;
   }


   /**
   * For Framework internal use only
    */
   public String getDiscrColumnName()
   {
      return mDiscrColumnName;
   }

   
   /**
   * For Framework internal use only
    */
   public Object getDiscrColumnValue()
   {
      return mDiscrColumnValue;
   }


   /**
   * For Framework internal use only
    */
   public String getAccessorName()
   {
      return (mChildAccessorNames != null) ? mChildAccessorNames[0] : null;
   }


   /**
   * For Framework internal use only
    */
   public String getAttributeName()
   {
      String[] attrs = getAttrNames();
      return (attrs != null) ? attrs[0] : null;
   }

   /**
   * For Framework internal use only
    */
   public String[] getAccessorNames()
   {
      return mChildAccessorNames;
   }

   JUCtrlHierTypeBinding [] getAccessorTypeBindings()
   {
      if (mChildTypeBindings == null && (mChildAccessorNames != null && mChildAccessorNames.length > 1))
      {
         mChildTypeBindings = new JUCtrlHierTypeBinding[mChildAccessorNames.length];
         JUCtrlHierTypeBinding child;
         for (int i = 0; i < mChildAccessorNames.length; i++) 
         {
            child = cloneType();
            child.mNodeString = mChildAccessorNames[i];
            child.mChildAccessorNames = new String[]{mChildAccessorNames[i]};
            mChildTypeBindings[i] = child;
         }
      }
      return mChildTypeBindings;
   }

   /**
   * For Framework internal use only
    */
   public boolean hasIcon()
   {
      return (mLeafIcon != null
               || mClosedIcon != null
               || mOpenIcon != null) ;
   }


   /**
   * For Framework internal use only
    */
   public String getLeafIconName()
   {
      return mLeafIcon;
   }
   
   /**
   * For Framework internal use only
    */
   public String getOpenIconName()
   {
      return mOpenIcon;
   }

   /**
   * For Framework internal use only
    */
   public String getClosedIconName()
   {
      return mClosedIcon;
   }

   /**
   * For Framework internal use only
    */
   public Icon getLeafIcon()
   {
      return null;
   }
   
   /**
   * For Framework internal use only
    */
   public Icon getOpenIcon()
   {
      return null;
   }

   /**
   * For Framework internal use only
    */
   public Icon getClosedIcon()
   {
      return null;
   }

   
   /**
   * Returns true if the given string matches the fully-qualified ViewObject definition name
   * that this node-type is supposed to display.
   */
   public boolean matchViewObjectType(String str)
   {
      //if discriminator column exists, then return false. 
      if (mDiscrColumnName == null) 
      {
         return (mVODefName != null) ? mVODefName.equals(str) : true;
      }
      return false;
   }

   /**
   * Returns true if the given row has an attribute value for the discriminator attribute that this
   * node type is interested in, such that that attribute value matches this type's discriminator
   * attribute value.
   */
   public boolean matchRowDiscrColumn(oracle.jbo.Row row)
   {
      Object discrColumnValue = row.getAttribute(mDiscrColumnName) ;
      boolean discrValueMatched = false;
      if (mDiscrColumnValue == null && discrColumnValue == null) 
      {
         discrValueMatched = true;
      }
      else if (mDiscrColumnValue != null && discrColumnValue != null) 
      {
         Object value = discrColumnValue.toString();
         discrValueMatched = value.equals(mDiscrColumnValue);
         if (!discrValueMatched) 
         {
            discrValueMatched = discrColumnValue.equals(mDiscrColumnValue);
         }
      }
      return discrValueMatched;
   }

   /**
   * Returns false as this type of node does not support discriminator columns.
   */
   public boolean isDiscrColumnType()
   {
      return (mDiscrColumnName != null);
   }
   
   /**
   * For Framework internal use only
    */
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_ViewDefName, valueTab);
      readXMLString(xmlElement, PNAME_DiscrColumnName, valueTab);
      readXMLString(xmlElement, PNAME_DiscrColumnValue, valueTab);
      readXMLString(xmlElement, PNAME_IconName, valueTab);
      readXMLString(xmlElement, PNAME_OpenIconName, valueTab);
      readXMLString(xmlElement, PNAME_ClosedIconName, valueTab);

      readXMLString(xmlElement, PNAME_ViewInstanceName, valueTab);
   }

   /**
   * For Framework internal use only
    */
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      HashMap valueTab = new HashMap(3);
      readXMLStringArray(xmlElement, PNAME_AccessorName, valueTab);
      init(valueTab);

      //attributes are loaded in the super.
   }

   /**
   * For Framework internal use only
    */
   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      //nooop.
      return null;
   }

   /**
   * For Framework internal use only
    */
   protected JUCtrlHierTypeBinding cloneType()
   {
      JUCtrlHierTypeBinding cloneObj = new JUCtrlHierTypeBinding();
      
      cloneObj.mVODefName          = mVODefName;
      cloneObj.mDiscrColumnName    = mDiscrColumnName;
      cloneObj.mDiscrColumnValue   = mDiscrColumnValue;
      cloneObj.mChildAccessorNames = mChildAccessorNames;
      cloneObj.mLeafIcon           = mLeafIcon;
      cloneObj.mOpenIcon           = mOpenIcon;
      cloneObj.mClosedIcon         = mClosedIcon;
      return cloneObj;
   }
   
}
