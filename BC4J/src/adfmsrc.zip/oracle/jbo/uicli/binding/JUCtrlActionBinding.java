/*
 * @(#)JUCtrlActionBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.binding;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Frame;

import java.security.Permission;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCInvokeMethod;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.binding.DCInvokeMethodListener;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.binding.PermissionHelper;
import oracle.adf.model.binding.PermissionBinding;
import oracle.adf.model.meta.OperationDefinition;
import oracle.adf.model.PermissionInfo;

import oracle.jbo.InvalidParamException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowNotAvailableException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.uicli.UIMessageBundle;

import oracle.adf.model.ADFmMessageBundle;

class JUActionDef
{
   int mId;
   String mStr;


   JUActionDef(int id, String str)
   {
      mId = id;
      mStr = str;
   }
}

/**
* Implements actions on BC4J RowIterator to which this control is bound.
* This class supports the following actions:
* <ul>
* <li><code>ACTION_EXECUTE</code> Executes the ViewObject query.
* <li><code>ACTION_NEXT</code> Moves the currency to the next row.
* <li><code>ACTION_PREVIOUS</code> Moves the currency to the previous row.
* <li><code>ACTION_FIRST</code> Moves the currency to the first row.
* <li><code>ACTION_LAST</code> Moves the currency to the last row.
      mAction = action;
* <li><code>ACTION_RESET</code> Resets the currency to the beginning of the RowIterator.
* <li><code>ACTION_EXECUTE_WITH_PARAMS</code> Executes the corresponding VO with the given set of parameters.
* <li><code>ACTION_REMOVE_CURRENT_ROW</code> Removes the current row in this iterator.
* <li><code>ACTION_CREATE_INSERT_ROW</code> Creates a new row and insert it into this iterator before the current row.
* <li><code>ACTION_COMMIT_TRANSACTION</code> Commits all changes in the current BC4J application module session into database.
* <li><code>ACTION_ROLLBACK_TRANSACTION</code> Rolls back any changes in the current BC4J application module session.
* </ul>
* <p>
* If a button is bound to this binding class, then, on button press, the action event on the
* button binding should call <code>invoke()</code> method on this object to perform the desired action.
 *
 * @javabean.class name=JUCtrlActionBinding
*/

public class JUCtrlActionBinding extends JUControlBinding implements OperationBinding
{
   public static final int ACTION_EXECUTE = OperationDefinition.ACTION_EXECUTE;
   public static final int ACTION_FIND    = OperationDefinition.ACTION_FIND;
   //BindingContainer actions
   public static final int ACTION_BINDING_CONTAINER_EXECUTE = OperationDefinition.ACTION_EXECUTE;
   public static final int ACTION_BINDING_CONTAINER_FIND    = OperationDefinition.ACTION_FIND;

   //IteratorBinding actions
   public static final int ACTION_ITERATOR_BINDING_EXECUTE= OperationDefinition.ACTION_ITERATOR_BINDING_EXECUTE;
   public static final int ACTION_ITERATOR_BINDING_FIND   = OperationDefinition.ACTION_ITERATOR_BINDING_FIND;

   public static final int ACTION_NEXT = OperationDefinition.ACTION_NEXT;
   public static final int ACTION_PREVIOUS = OperationDefinition.ACTION_PREVIOUS;
   public static final int ACTION_FIRST = OperationDefinition.ACTION_FIRST;
   public static final int ACTION_LAST = OperationDefinition.ACTION_LAST;
   public static final int ACTION_NEXT_SET = OperationDefinition.ACTION_NEXT_SET;
   public static final int ACTION_PREVIOUS_SET = OperationDefinition.ACTION_PREVIOUS_SET;

   public static final int ACTION_RESET = OperationDefinition.ACTION_RESET;
   public static final int ACTION_EXECUTE_WITH_PARAMS = OperationDefinition.ACTION_EXECUTE_WITH_PARAMS;
   public static final int ACTION_REMOVE_CURRENT_ROW = OperationDefinition.ACTION_REMOVE_CURRENT_ROW;
   public static final int ACTION_CREATE_INSERT_ROW = OperationDefinition.ACTION_CREATE_INSERT_ROW;
   public static final int ACTION_CREATE_ROW = OperationDefinition.ACTION_CREATE_ROW;

   public static final int ACTION_SETCURRENTROW_WITH_KEY      = OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY;
   public static final int ACTION_SETCURRENTROW_WITH_KEYVALUE = OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE;
   public static final int ACTION_REMOVEROW_WITH_KEY   = OperationDefinition.ACTION_REMOVEROW_WITH_KEY;

   //DataControl actions
   public static final int ACTION_COMMIT_TRANSACTION = OperationDefinition.ACTION_COMMIT_TRANSACTION;
   public static final int ACTION_ROLLBACK_TRANSACTION = OperationDefinition.ACTION_ROLLBACK_TRANSACTION;
   public static final int ACTION_RESET_STATE = OperationDefinition.ACTION_RESET_STATE;
   public static final int ACTION_INVOKE_METHOD = OperationDefinition.CUSTOM;


   private DCDataControl mDataControl;
   private int mAction;
   private DCInvokeMethod mMethod;
   private ArrayList mActionBindingListeners;

   final byte TYPE_ROW_ITERATOR = 0;
   final byte TYPE_ARRAY_ITERATOR = 1;
   byte mIteratorBindingType = TYPE_ROW_ITERATOR;

   private ArrayList mParams;
   private Object    mRetVal;
   private HashMap   mParamMap;

   private JboException mErrExc; //stores any exception that occured during setAttribute.

   private int mAuthorized = PermissionHelper.NOT_CHECKED;

   static final JUActionDef[] mActionDefs =
   {
      new JUActionDef(ACTION_BINDING_CONTAINER_EXECUTE, "execute"),
      new JUActionDef(ACTION_BINDING_CONTAINER_FIND, "find"),
      new JUActionDef(ACTION_ITERATOR_BINDING_EXECUTE, "iteratorExecute"),
      new JUActionDef(ACTION_ITERATOR_BINDING_FIND, "iteratorFind"),
      new JUActionDef(ACTION_NEXT, "next"),
      new JUActionDef(ACTION_PREVIOUS, "previous"),
      new JUActionDef(ACTION_FIRST, "first"),
      new JUActionDef(ACTION_LAST, "last"),
      new JUActionDef(ACTION_RESET, "reset"),
      new JUActionDef(ACTION_NEXT_SET, "nextSet"),
      new JUActionDef(ACTION_PREVIOUS_SET, "previousSet"),
      new JUActionDef(ACTION_REMOVE_CURRENT_ROW, "removeCurrentRow"),
      new JUActionDef(ACTION_EXECUTE_WITH_PARAMS, "executeWithParams"),
      new JUActionDef(ACTION_CREATE_INSERT_ROW, "createInsertRow"),
      new JUActionDef(ACTION_CREATE_ROW, "createRow"),
      new JUActionDef(ACTION_COMMIT_TRANSACTION, "commitTransaction"),
      new JUActionDef(ACTION_ROLLBACK_TRANSACTION, "rollbackTransaction"),
      new JUActionDef(ACTION_RESET_STATE, "resetState"),
      new JUActionDef(ACTION_SETCURRENTROW_WITH_KEY, "setCurrentRowWithKey"),
      new JUActionDef(ACTION_SETCURRENTROW_WITH_KEYVALUE, "setCurrentRowWithKeyValue"),
      new JUActionDef(ACTION_REMOVEROW_WITH_KEY, "removeRowWithKey"),
      new JUActionDef(ACTION_INVOKE_METHOD, "invokeMethod")
   }  ;

   /**
    * @param control View-layer object that this action binding works with.
    */
   public JUCtrlActionBinding(Object control, DCBindingContainer form, DCInvokeMethodDef methodInfo)
   {
      super(control, null);
      mAction = ACTION_INVOKE_METHOD;
      setupMethodInfo(form, methodInfo);
      setBindingContainer(form);
   }

   /**
   * Creates an ActionBinding instance that works with the given control and
   * on control's ActionEvent, call the invoke() method.
   * @param control The control that this binding works with.
   * @param iterBinding JUIteratorBinding instance that this binding works with.
   * @param action Indicates the selected action from the list of actions this class implements.
   */
   public JUCtrlActionBinding(Object control, DCIteratorBinding iterBinding, int action)
   {
      super(control, iterBinding);
      mAction = action;
      if (action == ACTION_INVOKE_METHOD)
      {
         throw new InvalidParamException("JUCtrlActionBinding", "action", Integer.toString(action));
      }

      if (iterBinding != null)
      {
         iterBinding.addActionBinding(this);
      }
   }

   /**
   * Creates an ActionBinding instance that works with the given control and
   * on control's ActionEvent, call the invoke() method.
   * @param control The control that this binding works with.
   * @param dc JUIteratorBinding instance that this binding works with.
   * @param action Indicates the selected action from the list of actions this class implements.
   */
   public JUCtrlActionBinding(Object control, DCDataControl dc, int action)
   {
      super(control, null); //null iterBinding.
      switch (action)
      {
         case JUCtrlActionBinding.ACTION_COMMIT_TRANSACTION:
         case JUCtrlActionBinding.ACTION_ROLLBACK_TRANSACTION:
         case JUCtrlActionBinding.ACTION_RESET_STATE:
            break;

         default:
            throw new InvalidParamException("JUCtrlActionBinding", "action", Integer.toString(action));
      }

      mAction = action;
      mDataControl = dc;
   }

   /**
    * @javabean.property 
    */
   public String  getEnabledString()
   {
      if(isActionEnabled())
         return "";
      return "disabled";
   }

   protected void setupMethodInfo(DCBindingContainer form, DCInvokeMethodDef def)
   {
      mMethod = def.createMethodInstance(form, this);
   }


   /**
    * Returns true if this action should be enabled for a given
    * iterator or datacontrol.
    *
    * @javabean.property
    */
   public boolean isActionEnabled()
   {
      return isOperationEnabled();
   }

   /**
    * Returns true if this action should be enabled for a given
    * iterator or datacontrol.
    *
    * @javabean.property
    */
   public boolean isOperationEnabled()
   {
      RowIterator nri;
      DCIteratorBinding iter = getIteratorBinding();
      DCDataControl dc = getDataControl();

      //Need at least read permission for any of navigation, row, find or execute operations
      //Need at least read permission for any of navigation, row, find or execute operations
      if (!(internalCheckPermission(ACTION_EXECUTE, false) &&
            internalCheckPermission(mAction, false)))
      {
          return false;
      }

      if (iter == null || !iter.isIteratorMadeVisible())
      {
         switch(mAction)
         {
            case ACTION_NEXT:
            case ACTION_PREVIOUS:
            case ACTION_FIRST:
            case ACTION_LAST:
            case ACTION_RESET:
            case ACTION_NEXT_SET:
            case ACTION_PREVIOUS_SET:

               // JRS 3280673 Err  on the less conservative side.  In some
               // cases this is invoked before the iterator will be refreshed
               // in the request lifecycle.
               // return false;
               if (iter != null && (iter.getDataControl() != null && !iter.getDataControl().isJClientApp()))
               {
                  //see bug 3948387 for jclient usecase.
                  //return true for web clients only 
                  //for JClient let the focus determine which iterator
                  //binding sets the navbar/menu action buttons enabled/disabled.
                  return true;
               }
               return false;

            case ACTION_REMOVE_CURRENT_ROW:
               return false;

            case ACTION_CREATE_INSERT_ROW:
            case ACTION_CREATE_ROW:
            case ACTION_ITERATOR_BINDING_EXECUTE:
            case ACTION_ITERATOR_BINDING_FIND:
               if (iter != null && iter.getDataControl() != null && iter.getDataControl().isJClientApp())
               {
                  //see bug 3948387 for jclient usecase.
                  //return true for web clients only 
                  //for JClient let the focus determine which iterator
                  //binding sets the navbar/menu action buttons enabled/disabled.
                  //for web cases go down to datacontrol checks.
                  return false;
               }

            default:
               //rest of the operations should go to datacontrol
               //to consult if the operation should be enabled or not
               break;
         }
      }
      //check for alive iteratorBindings to avoid exceptions in isOperationEnabled calls from NavBar
      //in closed Apps after the AM is disconnected, but UI is still going down. gvbatch sv19
      switch (mAction)
      {
         case ACTION_ITERATOR_BINDING_EXECUTE:
            if (iter == null)
            {
               return false;
            }
            //follow through for exeucte check on dc.

         case ACTION_BINDING_CONTAINER_EXECUTE:
            if (iter == null)
            {
               return false;
            }
            return iter.isOperationSupported(DCDataControl.OPER_EXECUTE);

         case ACTION_ITERATOR_BINDING_FIND:
            if (iter == null)
            {
               return false;
            }
            //follow through for DC check.

         case ACTION_BINDING_CONTAINER_FIND:
            //find mode button is also used to cancel find mode - to go back to data mode
            //without executing the query.
            if (iter == null)
            {
               return false;
            }
            return iter.isOperationSupported(DCDataControl.OPER_FIND_MODE);

         case ACTION_LAST:
         case ACTION_NEXT:
            try
            {
               if (iter.isAlive())
               {
                  if (iter.hasRSI() || iter.isFindMode() || iter.refreshIfNeeded())
                  {
                     if ((nri = iter.getNavigatableRowIterator()) != null)
                     {
                        return nri.hasNext();
                     }
                  }
               }
               return false;
            }
            catch (oracle.jbo.RowNotAvailableException rnae)
            {
               return false;
            }

         case ACTION_FIRST:
         case ACTION_PREVIOUS:
            if (iter.isAlive())
            {
               if (iter.hasRSI() || iter.isFindMode() || iter.refreshIfNeeded())
               {
                  if ((nri = iter.getNavigatableRowIterator()) != null)
                  {
                     return nri.hasPrevious();
                  }
               }
            }
            return false;

         case ACTION_NEXT_SET:
            if (iter.isAlive())
            {
               if (iter.hasRSI() || iter.refreshIfNeeded())
               {
                  if ((nri = iter.getNavigatableRowIterator()) != null)
                  {
                     return !nri.isRangeAtBottom();
                  }
               }
            }
            return false;
            //return (iter.hasRSI()) ? !iter.getNavigatableRowIterator().isRangeAtBottom() : false;

      case ACTION_PREVIOUS_SET:
            if (iter.isAlive())
            {
               if (iter.hasRSI() || iter.refreshIfNeeded())
               {
                  if ((nri = iter.getNavigatableRowIterator()) != null)
                  {
                     return !nri.isRangeAtTop();
                  }
               }
            }
            return false;

         case ACTION_RESET:
            if (iter == null)
            {
               return false;
            }
            return (iter.getCurrentRow() != null);

        case ACTION_REMOVE_CURRENT_ROW:
            if (iter == null || !iter.isAlive())
            {
               return false;
            }

            if (iter.isOperationSupported(DCDataControl.OPER_DATA_ROW_REMOVE))
            {
               if (iter.hasRSI() || iter.isFindMode() || iter.refreshIfNeeded())
               {
                  if ((nri = iter.getNavigatableRowIterator()) != null)
                  {
                     return (nri.getCurrentRowSlot() == RowIterator.SLOT_VALID);
                  }
               }
            }
            return false;

         case ACTION_EXECUTE_WITH_PARAMS:
            if (iter == null)
            {
               return false;
            }
            return true;

         case ACTION_CREATE_INSERT_ROW:
         case ACTION_CREATE_ROW:
            if (iter == null)
            {
               return false;
            }
            if (iter.isAlive())
            {
               iter.refreshIfNeeded();

               return iter.isOperationSupported(DCDataControl.OPER_DATA_ROW_CREATE);
            }
            return false;

         case ACTION_COMMIT_TRANSACTION:
         case ACTION_ROLLBACK_TRANSACTION:
            return (dc != null && dc.isTransactionModified());

         default:
            break;
      }
      return true;
   }


   /**
    * Returns the datacontrol that this action or it's iteratorBinding is associated with.
    */
   public final DCDataControl getDataControl()
   {
      if (mDataControl == null)
      {
         if (getDef() instanceof JUCtrlActionDef )
         {
            String name = ((JUCtrlActionDef)getDef()).getDataControlName();
            if (name != null && getBindingContainer() != null)
            {
               BindingContext ctx = getBindingContainer().getBindingContext();
               if (ctx != null)
               {
                  DCDataControl dc = (ctx.findDataControl(name));
                  
                  mDataControl = dc;
                  if (getIteratorBinding() == null) 
                  {
                     //if this action is not bound to any iteratorBinding
                     //make sure this bindingContainer is registered
                     //with the datacontrol for it to be properly
                     //released on endRequest.
                     JUFormBinding ctr = getFormBinding();
                     if (dc != null && ctr != null) 
                     {
                        if (dc != ctr.internalGetDataControl()) 
                        {
                           dc.addBindingContainer(ctr);
                        }
                     }
                  }
               }
            }
         }

         if (mDataControl == null)
         {
            if (getIteratorBinding() != null)
            {
               mDataControl = getIteratorBinding().getDataControl();
               //this bindingContainer should already be in the datacontrol
               //iteratorBinding must have put it.
            }
            else if (getBindingContainer() != null)
            {
               mDataControl = getBindingContainer().getDataControl();
               //this bindingContainer should already be in the datacontrol
               //iteratorBinding must have put it.
            }
         }
      }
      return mDataControl;
   }

   /**
   * *** For internal framework use only ***
   */
   static public int actionNameToId(String actionName)
   {
      for (int j = 0; j < mActionDefs.length; j++)
      {
         if (mActionDefs[j].mStr.equals(actionName))
         {
            return mActionDefs[j].mId;
         }
      }

      return -1;
   }

   /**
   * *** For internal framework use only ***
   */
   static public String actionIdToName(int id)
   {
      for (int j = 0; j < mActionDefs.length; j++)
      {
         if (mActionDefs[j].mId == id)
         {
            return mActionDefs[j].mStr;
         }
      }

      return null;
   }

   Component getParentFrame()
   {
      Object control = getControl();
      if (control instanceof Component)
      {
         Component ctrl = (Component)control;
         while (ctrl != null && !(ctrl instanceof Frame))
         {
            ctrl = ctrl.getParent();
         }
         if (ctrl instanceof Frame)
         {
            return ctrl;
         }
      }
      return null;
   }

   /**
    * Invoke the bound action and return the operation returned value. 
    * In case of error, return null.
    */
   public Object execute()
   {
      //clean up errors.
      resetInputState();
      
      invoke();

      //only returns getResult() for custom method operations. For navigation, 
      //transactional and other built-ins, returns null 
      return (mErrExc == null) ? mRetVal : null;
   }

   /**
    * If this action is bound to a datacontrol, then calls
    * dataControl.invokeAction to perform the action operations
    * otherwise calls doIt() to perform the method action.
    * <p>
    * This allows datacontrol subclasses to perform custom implementation
    * for all actions in the framework
    *
    * @since 9.0.5.1
    */
   public final void invoke()
   {
      int i;
      JUCtrlActionBindingEvent ev = null;
      ArrayList al = null;
      int count = 0;
      if (mActionBindingListeners != null && mActionBindingListeners.size() > 0)
      {
         ev = createActionBindingEvent();
         al = (ArrayList)mActionBindingListeners.clone();
         count = al.size(); 
         for (i = 0; i < count; i++) 
         {
            ((JUCtrlActionBindingListener)al.get(i)).beforeActionPerformed(ev);
         }
      }

      internalCheckPermission(mAction, true);

      if (getDataControl() != null)
      {
         getDataControl().invokeOperation(getDataControl().getBindingContext(), this);
      }
      else
      {
         doIt();
      }

      if (ev != null)
      {
         for (i = 0; i < count; i++) 
         {
            ((JUCtrlActionBindingListener)al.get(i)).afterActionPerformed(ev);
         }
      }
   }

   /**
    * Added for satisfying the oracle.binding.ActionBinding interface.
    *
    * @return List with errors
    */
   public List getErrors()
   {
      ArrayList al = new ArrayList();
      JboException ex = getError();
      if (ex != null) 
      {
         al.add(ex);
      }
      return al;
   }

   /**
   * Performs the action that this binding is selected to perform.
   * This method gets the RowIterator from the associated Iterator binding
   * and then calls an equivalent method on the RowIterator.
   * BC4J runtime then sends appropriate events to various binding objects
   * based on the action to update their display with the latest currency,
   * data, etc.
   * <p>
   * Here's a list of actions and corresponding method calls on the BC4J side.
   * <p>
   * <ul>
   * <li><code>ACTION_ITERATOR_BINDING_FIND</code> Calls IteratorBinding.setFindMode(true)
   * <li><code>ACTION_BINDING_CONTAINER_FIND</code> Calls BindingContainer.setFindMode(true)
   * <li><code>ACTION_ITERATOR_BINDING_EXECUTE</code> Calls IteratorBinding.executeQuery()
   * <li><code>ACTION_BINDING_CONTAINER_EXECUTE</code> Calls BindingContainer.executeQuery()
   * <li><code>ACTION_NEXT</code> Calls RowIterator.next() after generating
   * beforeRowNavigated event on the associated JUFormBinding (if currency is
   * moved from an existing current row to another one.)
   * <li><code>ACTION_PREVIOUS</code> Calls RowIterator.previous() after generating
   * beforeRowNavigated event on the associated JUFormBinding (if currency is
   * moved from an existing current row to another one.)
   * <li><code>ACTION_FIRST</code> Calls RowIterator.first() after generating
   * beforeRowNavigated event on the associated JUFormBinding (if currency is
   * moved from an existing current row to the first row.)
   * <li><code>ACTION_LAST</code> Calls RowIterator.last() after generating
   * beforeRowNavigated event on the associated JUFormBinding (if currency is
   * moved from an existing current row to the last row.)
   * <li><code>ACTION_NEXT_SET</code> Calls RowIterator.scrollRange() with
   * this iterator's rangeSize as the number of rows to scroll forward.
   * <li><code>ACTION_PREVIOUS_SET</code> Calls RowIterator.scrollRange() with
   * the negative value for this iterator's rangeSize as the number of rows to scroll back.
   * <li><code>ACTION_RESET</code> Reset the currency to the beginning of the RowIterator
   * by calling RowIterator.reset() after generating beforeRowNavigated event if
   * currency is taken away from an existing current row.
   * <li><code>ACTION_EXECUTE_WITH_PARAMS</code> Execute iteratorBinding's datasource with
   * parameter values collected from this bindingContainer.
   * <li><code>ACTION_REMOVE_CURRENT_ROW</code> Remove the current row in this iterator by
   * calling RowIterator.removeCurrentRow()
   * <li><code>ACTION_CREATE_INSERT_ROW</code> Create a new row and insert it into this iterator before the current row
   * after generating beforeRowNavigated event on the containing JUFormBinding.
   * <li><code>ACTION_CREATE_INSERT_ROW</code> Create a new row but do not insert it into this iterator. Callers need
   * to insert this row programmatically into the iterator.
   * <li><code>ACTION_COMMIT_TRANSACTION</code> Commit all changes in the current BC4J application module session into database
   * by calling commit() method on the related BC4J Transaction object.
   * <li><code>ACTION_ROLLBACK_TRANSACTION</code> Rollback any changes in the current BC4J application module session by
   * calling rollback() method on the related BC4J Transaction object. This method also re-executes the Form (all VOs
   * in the JUFormBinding) after a successful rollback.
   * </ul>
   */
   public void doIt()
   {
      //first reset any exceptions cached in this binding so that new exceptions if any
      //get displayed on performing this action.
      resetInputState();

      JUIteratorBinding iterBinding = getIteratorBinding();
      DCBindingContainer form = null;

      Object lockObj = (iterBinding != null) ? iterBinding.getSyncLock() : getBindingContainer();
      if (lockObj == null)
      {
         //this could occur if button is bound to an iterator
         //that's been released and button is now waiting
         //for another iterator to get into focus and
         //navbar will readjust the button's iteratorbinding.
         lockObj = this;
      }
      synchronized(lockObj)
      {
         RowIterator rsi = null;
         Component frame = getParentFrame();
         form = getBindingContainer();
         boolean errorHandlerActive = (form != null) ? form.isErrorHandlerActive() : false;
         try
         {
            if (frame != null)
            {
               frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            }

            if (errorHandlerActive)
            {
               form.setErrorHandlerActive(false);
            }

            switch(mAction)
            {
               case ACTION_BINDING_CONTAINER_EXECUTE:
                  {
                     boolean findMode = (form != null && form.isFindMode());
                     if (findMode)
                     {
                        form.setFindMode(false, true);
                     }
                     try
                     {
                        form.execute();
                     }
                     catch (Exception e)
                     {
                        if (findMode)
                        {
                           //reset find mode.
                           try
                           {
                              form.setFindMode(true, false);
                           }
                           catch (Exception ije)
                           {
                              //ignore inner Exception
                              //we want to send out the first exception.
                           }
                        }
                        JboException je;
                        if (e instanceof JboException)
                        {
                           je = (JboException)e;
                        }
                        else
                        {
                           je = new JboException(e);
                        }
                        //this will be caught by catch outside the switch.
                        throw je;
                     }
                  }
                  //since execute and find buttons are acting on the form
                  return;

               case ACTION_BINDING_CONTAINER_FIND:
                  if (form != null)
                  {
                     //do not apply the current view criteria as we
                     //are cancelling out of find mode, if I'm already
                     //in find mode
                     form.setFindMode(!form.isFindMode(), false);
                  }
                  return;
               case ACTION_ITERATOR_BINDING_EXECUTE:
                  {
                     if (iterBinding != null)
                     {
                        boolean findMode = (iterBinding.isFindMode());
                        if (findMode)
                        {
                           iterBinding.setFindMode(false, true);
                        }
                        try
                        {
                           //this should only throw JboException.
                           iterBinding.executeQuery();
                           if (iterBinding.getDataControl().syncNeeded())
                           {
                              //invoke sync right away to collect execution errors otherwise
                              //we end up in datamode and cannot get back.
                              iterBinding.getDataControl().sync("JUCtrlActionBinding.doIt().iteratorExecute"); //nonls
                           }

                        }
                        catch (Exception e)
                        {
                           if (findMode)
                           {
                              //reset find mode.
                              try
                              {
                                 iterBinding.setFindMode(true, false);
                              }
                              catch (Exception ije)
                              {
                                 //ignore inner Exception
                                 //we want to send out the first exception.
                              }
                           }
                           JboException je;
                           if (e instanceof JboException)
                           {
                              je = (JboException)e;
                           }
                           else
                           {
                              je = new JboException(e);
                           }
                           //this will be caught by catch outside the switch.
                           throw je;
                        }
                     }
                  }
                  //since execute and find buttons are acting on the form
                  return;

               case ACTION_ITERATOR_BINDING_FIND:
                  if (iterBinding != null)
                  {
                     //do not apply the current view criteria since we are cancelling out of find mode
                     //if iterator is already in find mode.
                     iterBinding.setFindMode(!iterBinding.isFindMode(), false);
                  }
                  return;
               case ACTION_NEXT:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                     }
                     /*if (rsi.getCurrentRowIndex() < 0)
                     {
                        rsi.first();
                     }
                     else
                     */
                     if (form != null)
                     {
                        {
                           form.callBeforeRowNavigated(iterBinding);
                        }
                     }
                     //check for next to avoid setting rsi into no-row slot leading to
                     //other controls being in disabled state as they have no rows.
                     if (rsi.hasNext())
                     {
                        if (!iterBinding.getDataControl().syncNeeded())
                        {
                           rsi.next();
                        }
                        else
                        {
                           try
                           {
                              rsi.next();
                           }
                           catch (RowNotAvailableException rnae)
                           {
                              //currency is set on the first row in the rangeby this guy
                              //((RowSetIterator)rsi).getNextRangeSet();
                              iterBinding.internalGetNextRangeSet();
                           }
                        }
                     }
                  }
                  break;
               case ACTION_PREVIOUS:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                        form.callBeforeRowNavigated(iterBinding);
                     }
                     //check for hasPrevious to avoid setting rsi into no-row slot leading to
                     //other controls being in disabled state as they have no rows.
                     if (rsi.hasPrevious())
                     {
                        if (!iterBinding.getDataControl().syncNeeded())
                        {
                           rsi.previous();
                        }
                        else
                        {
                           try
                           {
                              rsi.previous();
                           }
                           catch (RowNotAvailableException rnae)
                           {
                              //currency is set on the first row in the rangeby this guy
                              //((RowSetIterator)rsi).getPreviousRangeSet();
                              iterBinding.internalGetPreviousRangeSet();
                           }
                        }
                     }
                  }
                  break;
               case ACTION_FIRST:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                        form.callBeforeRowNavigated(iterBinding);
                     }

                     if (!iterBinding.getDataControl().syncNeeded())
                     {
                        rsi.first();
                     }
                     else
                     {
                        try
                        {
                           rsi.first();
                        }
                        catch (RowNotAvailableException rnae)
                        {
                           ((RowSetIterator)rsi).scrollRange(Integer.MIN_VALUE);
                           iterBinding.getDataControl().sync("JUCtrlActionBinding.doIt().first after RowNotAvailableException"); //nonls
                           rsi.first();
                        }
                     }
                  }
                  break;
               case ACTION_LAST:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                        form.callBeforeRowNavigated(iterBinding);
                     }

                     if (!iterBinding.getDataControl().syncNeeded())
                     {
                        rsi.last();
                     }
                     else
                     {
                        try
                        {
                           rsi.last();
                        }
                        catch (RowNotAvailableException rnae)
                        {
                           ((RowSetIterator)rsi).scrollRange(Integer.MAX_VALUE);
                           iterBinding.getDataControl().sync("JUCtrlActionBinding.doIt().last after RowNotAvailableException"); //nonls
                           rsi.last();
                        }
                     }
                  }
                  break;
               case ACTION_NEXT_SET:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                     }
                     {
                        //check for next to avoid setting rsi into no-row slot leading to
                        //other controls being in disabled state as they have no rows.
                        if (!rsi.isRangeAtBottom())
                        {
                           /*
                           if (!iterBinding.getDataControl().syncNeeded())
                           {
                              rsi.scrollRange(rsi.getRangeSize());
                           }
                           else
                           */
                           {
                              if (form != null)
                              {
                                 form.callBeforeRowNavigated(iterBinding);
                              }
                              //currency is set on the first row in the rangeby this guy
                              ((RowSetIterator)rsi).getNextRangeSet();
                           }
                        }
                     }
                  }
                  break;
               case ACTION_PREVIOUS_SET:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_NAVIGATING, new Object[] {iterBinding.getDisplayName()});
                     }
                     //check for hasPrevious to avoid setting rsi into no-row slot leading to
                     //other controls being in disabled state as they have no rows.
                     if (!rsi.isRangeAtTop())
                     {
                        /*
                        if (!iterBinding.getDataControl().syncNeeded())
                        {
                           rsi.scrollRange(-1 * rsi.getRangeSize());
                        }
                        else
                        */
                        {
                           if (form != null)
                           {
                              form.callBeforeRowNavigated(iterBinding);
                           }
                           //currency is set on the first row in the rangeby this guy
                           ((RowSetIterator)rsi).getPreviousRangeSet();
                        }
                     }
                  }
                  break;
               case ACTION_RESET:
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (form != null)
                     {
                        form.callBeforeRowNavigated(iterBinding);
                     }
                     rsi.reset();
                  }
                  break;

               
               case ACTION_REMOVE_CURRENT_ROW:
               {
                  if (iterBinding != null)
                  {
                     rsi = getRowIterator();
                     iterBinding.removeCurrentRow();
                     if (iterBinding.isFindMode())
                     {
                        DCDataControl dc = iterBinding.getDataControl();
                        if (!dc.syncNeeded())
                        {
                           //if sync needed, then refreshControl has already dirtied
                           //the VC/VO when getting the ViewCriteria in the first place
                           //so that it gets updated on every sync. So, we only need
                           //to force a sync for immediate 3tier case.
                           oracle.jbo.ApplicationModule am = dc.getApplicationModule();
                           if (am != null && am.getSession().isClient())
                           {
                              //if BC4JDC, force sync of VO with modified ViewCriteria.
                              iterBinding.getViewObject().applyViewCriteria((oracle.jbo.ViewCriteria)rsi);
                           }
                        }
                     }
                  }
                  break;
               }

               case ACTION_CREATE_ROW:
               case ACTION_CREATE_INSERT_ROW:
               {
                  rsi = getRowIterator();
                  if (rsi != null)
                  {
                     if (!iterBinding.isRefreshed())
                     {
                        iterBinding.refreshIfNeeded();
                     }
                     Row row = rsi.createRow();

                     if (row != null)
                     {
                        DCDataControl dc = iterBinding.getDataControl();

                        //just incase there's a navigation
                        if (form != null)
                        {
                           form.callBeforeRowNavigated(iterBinding);
                        }

                        boolean find = iterBinding.isFindMode();
                        boolean doCreateInsert = (mAction == ACTION_CREATE_INSERT_ROW || find);
                        if (!doCreateInsert)
                        {
                           doCreateInsert = (iterBinding.getViewObject() == null);
                        }

                        if (doCreateInsert)
                        {
                           rsi.insertRow(row);
                           if (find)
                           {
                              if (dc.syncNeeded())
                              {
                                 //this forces dataControl to reapply view criteria.
                                 dc.getViewCriteria(iterBinding);
                              }
                              else
                              {
                                 oracle.jbo.ApplicationModule am = dc.getApplicationModule();
                                 if (am != null && am.getSession().isClient())
                                 {
                                    //if BC4JDC, force sync of VO with modified ViewCriteria.
                                    iterBinding.getViewObject().applyViewCriteria((oracle.jbo.ViewCriteria)rsi);
                                 }
                              }
                           }
                           else
                           {
                              row.setNewRowState(Row.STATUS_INITIALIZED);
                           }
                        }
                        else
                        {
                           //create initialized row only in datamode/web case.
                           row.setNewRowState(Row.STATUS_INITIALIZED);
                           iterBinding.cacheCreatedRow((RowSetIterator)rsi, row);
                        }
                     }
                  }
                  break;
               }
               case ACTION_COMMIT_TRANSACTION:
               {
                  if (form != null)
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_BEFORE_COMMIT, null);
                     DCDataControl app = getDataControl();
                     if (app != null)
                     {
                        app.callCommitTransaction();
                     }
                     else
                     {
                        getApplicationModule().getTransaction().commit();
                     }
                     if (app.isTransactionModified())
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_ERROR_COMMIT, null);
                     }
                     else
                     {
                        form.displayStatus(iterBinding, UIMessageBundle.STR_DONE_COMMIT, null);
                     }
                  }

                  {
                     //this will make sure that controls are enabled/disabled
                     //as per attribute-updateability
                     ArrayList al = form.getCtrlBindingList();
                     Object binding;
                     JUCtrlAttrsBinding ctrl;
                     for (int i = 0; i < al.size(); i++)
                     {
                        binding = al.get(i);
                        if (binding instanceof JUCtrlAttrsBinding)
                        {
                           ctrl = ((JUCtrlAttrsBinding)binding);
                           ctrl.refreshControl();
                        }
                     }
                  }

                  return;
               }
               case ACTION_ROLLBACK_TRANSACTION:
               {
                  if (form != null)
                  {
                     form.displayStatus(iterBinding, UIMessageBundle.STR_BEFORE_ROLLBACK, null);
                     DCDataControl app = getDataControl();
                     if (app != null)
                     {
                        app.rollbackTransaction();
                     }
                     else
                     {
                        getApplicationModule().getTransaction().rollback();
                     }

                     if (form.isExecuteOnRollback())
                     {
                        form.getRootBindingContainer().execute(); // bug 5365941
                     }

                     form.displayStatus(iterBinding, UIMessageBundle.STR_DONE_ROLLBACK, null);
                  }
                  return;
               }

               case ACTION_RESET_STATE:
               {
                  DCDataControl dc = getDataControl();
                  if (dc != null)
                  {
                     dc.resetState();
                  }
                  return;
               }

               case ACTION_EXECUTE_WITH_PARAMS:
                  if (iterBinding != null)
                  {
                     DCDataControl dc = iterBinding.getDataControl();
                     Object[] vals = mMethod.fetchParameterValues(getDataControl().getBindingContext(), 
                                                                  resolveParamsMap()) ;
                     dc.executeIteratorBindingWithParams(iterBinding, mMethod.getParameters(), vals);
                     break;
                  }

               case ACTION_SETCURRENTROW_WITH_KEY:
                  if (iterBinding != null)
                  {
                     Object[] vals = mMethod.fetchParameterValues(getDataControl().getBindingContext(), 
                                                                  resolveParamsMap()) ;
                     if (vals.length > 0) 
                     {
                        iterBinding.setCurrentRowWithKey((String)vals[0]);
                     }
                  }
               break;
               case ACTION_SETCURRENTROW_WITH_KEYVALUE:
                  if (iterBinding != null)
                  {
                     Object[] vals = mMethod.fetchParameterValues(getDataControl().getBindingContext(), 
                                                                  resolveParamsMap()) ;
                     if (vals.length > 0) 
                     {
                        iterBinding.setCurrentRowWithKeyValue((String)vals[0]);
                     }
                  }
               break;
               case ACTION_REMOVEROW_WITH_KEY:
                  if (iterBinding != null)
                  {
                     Object[] vals = mMethod.fetchParameterValues(getDataControl().getBindingContext(), 
                                                                  resolveParamsMap()) ;
                     if (vals.length > 0) 
                     {
                        iterBinding.removeRowWithKey((String)vals[0]);
                     }
                  }
               break;

               case ACTION_INVOKE_METHOD:
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.println("Invoke method Action:" + mAction);
                  }
                  mRetVal = null;

                  DCDataControl dc = getDataControl();
                  mRetVal = mMethod.callMethod(dc, this,  resolveParamsMap());
                  mParams = null;
                  break;
               default:
                  Diagnostic.println("Action " + mAction + " not recognized");
                  break;
            }
         }
         catch(JboException jex)
         {
            //if error handler was active, make it active again
            //and then send out the exception for the dialog to come up.
            if (errorHandlerActive)
            {
               form.setErrorHandlerActive(errorHandlerActive);
            }
            reportException(jex);
         }
         catch(Exception ex)
         {
            if (errorHandlerActive)
            {
               form.setErrorHandlerActive(errorHandlerActive);
            }
            reportException(ex);
         }
         catch(Throwable ex)
         {
            if (errorHandlerActive)
            {
               form.setErrorHandlerActive(errorHandlerActive);
            }
             reportException(new JboException(ex));
         }
         finally
         {
            mParamMap = null; //clean out params map on every call, so that
                              //it gets rebuilt on the next call (even in case
                              //of errors).

            if (errorHandlerActive)
            {
               form.setErrorHandlerActive(errorHandlerActive);
            }
            if (frame != null)
            {
               frame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
         }
      }
   }

   private Map resolveParamsMap()
   {
      HashMap map = (mParamMap != null) ? (HashMap)mParamMap : new HashMap(6);
      if (mParams != null)
      {
         OperationParameter[] params = mMethod.getParameters();
         if (params != null && mParams != null)
         {
            int count = java.lang.Math.min(params.length, mParams.size());
            for (int i = 0; i < count; i++)
            {
               if (mParams.get(i) != null)
               {
                  //copy ordered list of parameter values from the map.
                  map.put(params[i].getName(), mParams.get(i));
               }
            }
         }
      }
      mParamMap = map;
      return map;
   }

   public void setArrayIteratorType()
   {
      mIteratorBindingType = TYPE_ARRAY_ITERATOR;
   }

   public boolean isArrayIteratorType()
   {
      return (mIteratorBindingType == TYPE_ARRAY_ITERATOR);
   }

   /**
   * *** For internal framework use only ***
   * <p>
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public void refreshControl()
   {
      // NOOP
   }

   public boolean ignoreUpdates()
   {
      JUCtrlActionDef def = (JUCtrlActionDef)getDef();
      if (def != null)
      {
         return (!def.requiresUpdateModel());
      }
      return !JUCtrlActionDef.getDefaultValueForUpdateModel(mAction);
   }

   /**
    * Returns Action Id for this Action binding.
    */
   public int getActionId()
   {
      return mAction;
   }
   public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
   {
   }

   public oracle.binding.OperationInfo getOperationInfo()
   {
      return mMethod;
   }

   DCInvokeMethod getInvokeMethod()
   {
      return mMethod;
   }

   /**
    * *** For internal framework use only ***
    * Used for testing purposes only.
    */
   public DCInvokeMethodDef getInvokeMethodDef()
   {
      return (mMethod != null) ? mMethod.getDef() : null;
   }

   /*
   * Calls invoke() and caches any exception for UIs to display later.
   * This method is primarily for SPEL to be able to get to this action
   * binding and call invoke() directly/declaratively.
   */
   public void setInvoke(Object dummy)
   {
      //moved nulling out of exc. into doIt() as that should be done
      //for any action before the action is executed.
      invoke();
   }

   protected void initResources()
   {
      //no resources to initialize based on locale.
   }

   protected void resetInputState()
   {
      removeFromDCExceptions();
      mErrExc = null;
   }

   /**
    * Primarily for spel support. Returns cached exceptions for some bindings.
    * <p>
    * Returns exception that occured on last setInputValue
    */
   public JboException getError()
   {
      if (mErrExc != null)
      {
         mErrExc.setLocaleContext(getBindingContainer().getLocaleContext());
      }
      return mErrExc;
   }

   /**
    * 
    * Returns true if this action should be enabled.
    * 
    * @javabean.property
    * 
    * @return true if this action should be enabled.
    */
   public final Boolean getEnabled()
   {
      return Boolean.valueOf(isActionEnabled());
   }
   
   /**
    * Returns a / separated name to the setInvoke() that could
    * be used in el-expressions to invoke the method bound in this action binding.
    *
    * @javabean.property
    */
   public final String getPath()
   {
      StringBuffer buf = new StringBuffer()
                         .append(getFullName().replace(DCUtil.SEP_DOT_CHAR, DCUtil.SEP_SLASH_CHAR))
                         .append(DCUtil.SEP_SLASH_CHAR)
                         .append("invoke");
      return buf.toString();
      /** 1012 impl the result should be same.
      StringBuffer buf = new StringBuffer()
                         .append(getFullName())
                         .append(DCUtil.SEP_DOT_CHAR)
                         .append("invoke");
      return DCUtil.encodePath(buf.toString(), DCUtil.SEP_SLASH_CHAR);
       */
   }

   /**
    * Return true if this binding's path is found as a key in the given map.
    */
   public boolean resolvePath(Map postMap)
   {
      if (postMap != null) 
      {
         return postMap.containsKey(getPath());
      }
      return false;
   }


   //this is the public api that should be visible to spel via code-insight
   //we need to do a bean info for each of the control bindings to indicate
   //what apis are exposed in this method.
   private static final String ATTR_PARAMS  = "params";
   private static final String ATTR_PARAMSMAP = "paramsMap";
   private static final String ATTR_RETVAL  = "result";
   private static final String ATTR_ENABLED = "enabled";
   private static final String ATTR_PATH    = "path";
   private static final String ATTR_ENABLED_STRING  = "enabledString";
   private static final String ATTR_ACTION_ENABLED = "actionEnabled";
   private static final String ATTR_ACTION_ID  = "actionId";

   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>params</code> - returns getParams()</li>
    * <li><code>paramsMap</code> - returns getParamsMap()</li>
    * <li><code>result</code>  - returns getResult()</li>
    * <li><code>enabled</code>  - returns isActionEnabled()</li>
    * <li><code>path</code>  - returns getPath()</li>
    * <li><code>text</code>  - returns getText()</li>
    */
   protected Object internalGet(String key)
   {
      if (ATTR_ACTION_ENABLED == key)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isActionEnabled());
      }
      if (ATTR_ENABLED_STRING == key)
      {
         mInternalGet_KeyResolved = true;
         return getEnabledString();
      }
      if (ATTR_PARAMS == key)
      {
         mInternalGet_KeyResolved = true;
         return getParams();
      }
      if (ATTR_PARAMSMAP == key)
      {
         mInternalGet_KeyResolved = true;
         return getParamsMap();
      }
      if (ATTR_RETVAL == key)
      {
         mInternalGet_KeyResolved = true;
         return getResult();
      }
      if (ATTR_ENABLED == key)
      {
         mInternalGet_KeyResolved = true;
         return getEnabled();
      }
      if (ATTR_PATH == key)
      {
         mInternalGet_KeyResolved = true;
         return getPath();
      }
      if (ATTR_ACTION_ID == key) 
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getActionId());
      }
      return super.internalGet(key);
   }

   /**
    * Returns a map of parameter expressions. The key values in this map should be
    * the argument names as stored in the metadata for a given method.
    *
    */
   public Map getParamsMap()
   {
      return resolveParamsMap();
   }

   /**
    * Returns the return value (if any) from the method that this binding invokes.
    *
    * @javabean.property
    */
   public Object getResult()
   {
      //for method actions always go the datacontrol location for result.
      //this will allow unexecuted bindings to also get the current result,
      //if the method was executed via another action and placed at the same
      //location as this method's resultname.

      DCInvokeMethodDef def = ((JUCtrlActionDef)getDef()).getMethodDef();
      if (def != null && def.getReturnName() != null)
      {
         mRetVal = DCUtil.findContextObject(getDataControl().getBindingContext(), def.getReturnName());
      }
      return mRetVal;
   }

   /**
    * Returns an ordered list of parameter expressions that will be passed
    * to the bound method on invocation.
    *
    */
   public ArrayList getParams()
   {
      return mParams;
   }

   /**
    * Set the ordered list of parameter expressions that should be passed
    * to the bound method on invocation. Note that this list should contain
    * el-expressions for values to be looked for in the bindingContext.
    */
   public void setParams(ArrayList al)
   {
      mParams = (al != null) ? (ArrayList)al.clone() : null;
   }

   /**
   * Report the given exception via the containing BindingContainer object.
   */
   public void reportException(Exception ex)
   {
      if (ex == null)
      {
         return;
      }
      JboException je;
      if (ex instanceof JboException)
      {
         je = (JboException)ex;
      }
      else
      {
         je = new JboException(ex);
      }
      mErrExc = je;
      addToDCExceptions(je);

      super.reportException(ex);
   }

   public void release(int flag)
   {
      if (mMethod != null) 
      {
         mMethod.release(flag);
      }
      mDataControl = null;
      super.release(flag);
   }

   boolean internalCheckPermission(int action, boolean reportException)
   {
      if (!PermissionHelper.isAuthorizationEnabled() )
      {
         return true;
      }

      DCIteratorBinding iter = getIteratorBinding();
      DCDataControl dc = getDataControl();

      if (dc == null) 
      {
         return true;
      }
        
      boolean hasPermission = mAuthorized == PermissionHelper.NO_PERMISSION ? false : true;
      if (mAuthorized == PermissionHelper.NOT_CHECKED)
      {
          if (action == ACTION_INVOKE_METHOD && mMethod != null)
          {
             hasPermission = dc.hasPermission(this, getPermissionTargetName(), PermissionHelper.INVOKE_ACTION);
          }
          else if (iter != null)
          {
              switch (action)
              {
                 case ACTION_REMOVE_CURRENT_ROW:
                    hasPermission = dc.hasPermission(this, getPermissionTargetName(), PermissionHelper.DELETE_ACTION);
                    break;
             
                 case ACTION_CREATE_INSERT_ROW:
                 case ACTION_CREATE_ROW:
                    hasPermission = dc.hasPermission(this, getPermissionTargetName(), PermissionHelper.CREATE_ACTION);
                    break;
             
                 case ACTION_REMOVEROW_WITH_KEY:
                    hasPermission = dc.hasPermission(this, getPermissionTargetName(), PermissionHelper.DELETE_ACTION);
                    break;
             
                 default:
                    hasPermission = dc.hasPermission(this, getPermissionTargetName(), PermissionHelper.READ_ACTION);
                    break;
              }
          }
          if (action == mAction)
          {
             mAuthorized = hasPermission ? PermissionHelper.HAS_PERMISSION : PermissionHelper.NO_PERMISSION;
          }
      }   

      if (!hasPermission && reportException)
      {
         throw new InvalidOperException(ADFmMessageBundle.class,
                                        ADFmMessageBundle.EXC_ACTION_NO_PERMISSION,
                                        new Object[] { actionIdToName(action) });
      }
      return hasPermission;
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         if (mMethod != null)
         {
            mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.METHOD_PERMISSION);
         }
         else
         {
            mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.ROWSET_PERMISSION);
         }
      }
      return mPermissionInfo;
   }

   public String getPermissionTargetName()
   {
      if (mAction == ACTION_INVOKE_METHOD && mMethod != null)
      {
         return mMethod.getPermissionTargetName();
      }

      DCIteratorBinding iter = getIteratorBinding();
      if (iter != null)
      {
         return iter.getPermissionTargetName();
      }
      return null;
   }

   protected boolean internalHasPermission(String target, String actions)
   {
      String permClassName = PermissionHelper.getPermissionClassName((mMethod != null && actionNameToId(mMethod.getOperationName()) != ACTION_EXECUTE_WITH_PARAMS) ?
                             PermissionHelper.METHOD_PERMISSION : PermissionHelper.ROWSET_PERMISSION);
      if (permClassName == null || target == null || actions == null)
      {
         return true;
      }

      Permission p = (Permission)PermissionHelper.createPermissionInstance(permClassName, target, actions);
      JUIteratorBinding iterBind = getIteratorBinding();
      DCDataControl dc = getDataControl();
      if (iterBind != null ) 
      {
         dc = iterBind.getDataControl();
      }

      if (dc != null && PermissionHelper.hasPermission(dc.getSecurityContext(), p))
      {
         return true;
      }
      return false;
   }


   public void addInvokeMethodListener(DCInvokeMethodListener l)
   {
      if (mMethod != null) 
      {
         mMethod.addInvokeMethodListener(l);
      }
   }

   public void removeInvokeMethodListener(DCInvokeMethodListener l)
   {
      if (mMethod != null) 
      {
         mMethod.removeInvokeMethodListener(l);
      }
   }

   /**
   * Returns a list of JUActionBindingListener  (returns an empty list if no such listener was registered).
   */
   public final ArrayList getActionBindingListeners()
   {
      return (mActionBindingListeners != null) ? (ArrayList)mActionBindingListeners.clone() : new ArrayList(0);
   }

   protected JUCtrlActionBindingEvent createActionBindingEvent()
   {
      return new JUCtrlActionBindingEvent (this); 
   }
   
   /**
   * Adds the given listener to this Action Binding's listeners list.    
   */
   public final void addActionBindingListener(JUCtrlActionBindingListener l)
   {
      if (mActionBindingListeners == null) 
      {
         mActionBindingListeners = new ArrayList(4);
      }
      if (!mActionBindingListeners.contains(l)) 
      {
         mActionBindingListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this Action Binding's listeners list.
   */
   public final void removeActionBindingListener(JUCtrlActionBindingListener l)
   {
      if (mActionBindingListeners != null) 
      {
         mActionBindingListeners.remove(l);
         if (mActionBindingListeners.size() == 0)
         {
            mActionBindingListeners = null;
         }
      }
   }
}
