/*
 * @(#)JUGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.graph;

import javax.swing.SwingUtilities;
import oracle.dss.graph.Graph;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUCtrlRangeBinding;

import oracle.adf.model.binding.DCIteratorBinding;

/**
 *  Data source for the Perspective chart bean.
 *
 */
public abstract class JUGraphBinding
      extends JUCtrlRangeBinding
      implements GraphConstants
{
    
    protected final static String emptyString = "";

	private static ColumnCountHelper columnCountHelper;

    /**
    *  Constructor
    *
    *  @param iterBinding Supplies label for columns and data values for 
    *         the chart. Last column is treated as label.
    */
    public JUGraphBinding(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames)
    {
        super(control, iterBinding, dataValueAttrNames);
    } 

    // helper method used by BIBeanDataAccessAdapter
    abstract protected String getColumnLabel(int i);
    
    abstract protected int getColumnCount();
        
    abstract protected String getRowLabel(int i);
    
    abstract protected long getRowCount();
        
	abstract protected Object getValue(int row, int col);

   /**
   * Returns false to indicate that the Graph binding cannot participate 
   * in query in Find mode
   */
   protected boolean isControlQueriable()
   {
      return false;
   }

	/**
	*  Returns the number of column values required to plot a datapoint. 
	*  For example, in the case of HLC graph, three values are needed per marker,
	*  or in the case of XY graph, two values are needed.
	*
	* @return number Value count per marker.
	*/
	public static int getNumberOfColumnPerMarker(int graphType)
	{
		if (columnCountHelper == null)

			columnCountHelper = new ColumnCountHelper();

		return columnCountHelper.findNumberOfColumnsFor(graphType);
	}
    
    
    protected int rowIndexToRangeIndex(int rowIndex)
    {
         RowSetIterator iter = (RowSetIterator)getRowIterator();

         if (iter != null)
         {
            int rangeStart = iter.getRangeStart();

            if (rangeStart <= 0)
            {
               return rowIndex;
            }
         
            return rowIndex - rangeStart;
         }
         else
         {
            return rowIndex;
         }
    }

    public boolean isDirty()
    {
       return false;
    }
    
    
    // JCtrlRangeUI abstract method impl
    
    public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
    {

    }

    public Object getValueAt(int rowIndex, int columnIndex)
    {
        return null;
    }


    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {
    }
    
	public void updateValuesFromRows(Row[] rows, boolean clear)
	{
		notifyView();
	}
   
    public void updateRowInserted(InsertEvent event)
    {
        notifyView();
    }
   
   
    public void updateRowDeleted(DeleteEvent event)
    {
        notifyView();
    }

    private boolean isFindMode()
    {
        return getBindingContainer().isFindMode();
    }

	/**
	*  derived class should override this method and notify the view
	*/
    abstract protected void notifyView();

	protected void refreshBIBeanAdapter(final BIBeanDataAccessAdapter adapter)
	{	
        Runnable r = new Runnable() 
		{
			public void run() 
			{
				try
				{
                    if (!isFindMode())
                    {
                        adapter.refresh();
                    }
				}
				catch(Exception exc)
				{
				}
			};
		};

		SwingUtilities.invokeLater(r);
	}


     
    
    public static String[] buildAttributeListWithLabel(
                String[] dataValueAttrNames,
                String labelAttrName )
    {
        int len = dataValueAttrNames.length;
        
        String attrNames[] = new String[ len + 1];
        
        System.arraycopy(dataValueAttrNames, 0, attrNames, 0, len);        
        
        // attach label at the end 
        attrNames[len] = new String(labelAttrName);
        
        return attrNames;

    }
          
}

class ColumnCountHelper
{
	static MarkerDef[] defs = 
	{
		new MarkerDef(0,54, 1),  // 3d & 2d
		new MarkerDef(55,60, 1), // pie
		new MarkerDef(61,62, 2), // xyscatter
		new MarkerDef(63,64, 2), // xyscatter with label
		new MarkerDef(65,66, 2), // Polar charts
		new MarkerDef(67,69, 1), // Radar
		new MarkerDef(70,70, 4), // Stock chart SHLC
		new MarkerDef(71,71, 5), // Stock chart SHLVC
		new MarkerDef(72,72, 4), // Stock chart SC
		new MarkerDef(73,75, 2), // Stock chart HL
		new MarkerDef(76,78, 3), // Stock Chart three values per marker
		new MarkerDef(79,81, 4), // Stock chart SC - four values per marker
		new MarkerDef(82,82, 3), // Stock chart SC - four values per marker
		new MarkerDef(83,83, 5), // Stock chart - five values per marker
		new MarkerDef(84,84, 5), // Candle Stock chart - five values per marker
		new MarkerDef(85,85, 1), // Histogram chart
	};

	int findNumberOfColumnsFor(int graphType)
	{
		for (int i=0; i < defs.length; i++)
	    {
			if (defs[i].isBelongsToRange(graphType))
		    {
				return defs[i].numValuesPerMarker;
			}
		}
		return 1;
	}

}

class MarkerDef
{
	int start;
	int end;
	int numValuesPerMarker;
                                            
	MarkerDef(int start, int end, int numValuesPerMarker)
	{
		this.start = start;
		this.end   = end;
		this.numValuesPerMarker = numValuesPerMarker;
	}

	boolean isBelongsToRange(int graphType)
	{
		if ((graphType > start)  && (graphType < end))
			return true;
		else if ((graphType == start) || (graphType == end))
			return true;

		return false;
	}
}





