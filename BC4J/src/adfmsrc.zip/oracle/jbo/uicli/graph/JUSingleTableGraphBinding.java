/*
 * @(#)JUSingleTableGraphBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.graph;

import java.awt.Component;
import java.io.InputStream;

import javax.swing.JPanel;
import oracle.dss.graph.Graph;
import oracle.dss.util.CubeDataDirector;
import oracle.dss.util.DataSource;
import oracle.dss.util.DefaultErrorHandler;
import oracle.dss.util.RelationalDataDirector;

import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;

import oracle.adf.model.binding.DCIteratorBinding;



/**
 *  Data source for the BI Graph bean. This binding may be used
 *  for Graph which requires one value per marker. A Pie chart 
 *  for example requires one value per marker. Each column in the 
 *  table (ViewObject) represents a Group in the Graph. Each row in
 *  table (ViewObject) represents a series in the Graph.
 * 
 *  @see JUMasterDetailGraphBinding
 */
public class JUSingleTableGraphBinding
      extends GraphDataFromRow
      implements DataSource
{
   protected BIBeanDataAccessAdapter mAdapter;

   protected InputStream mGraphPropertiesStream;

    
   public JUSingleTableGraphBinding(
            Graph control,
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            String   seriesLabelAttrName,
			String[] colLabels)
   {
       this(control, iterBinding, 
            buildAttributeListWithLabel(dataValueAttrNames, seriesLabelAttrName), 
            colLabels);
   }

   /**
   * graphDefFileName should be of form 
   *
   * mypackage1/BIGraphDef.xml
   *
   */
   public JUSingleTableGraphBinding(
            Graph control,
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            String   seriesLabelAttrName,
			String[] colLabels,
            String   graphDefFileName)
   {
       this(control, iterBinding, 
            buildAttributeListWithLabel(dataValueAttrNames, seriesLabelAttrName), 
            colLabels, 
            JBOClass.getResourceAsStream(graphDefFileName));
   }

    public JUSingleTableGraphBinding(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames /* last column serves as Series label*/,
			String[] colLabels)
    {
        this(control, iterBinding, dataValueAttrNames, colLabels, (InputStream)null);
    }

    public JUSingleTableGraphBinding(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames /* last column serves as Series label*/,
			String[] colLabels,
            InputStream graphPropertiesStream)
    {
        super(control, iterBinding, dataValueAttrNames, colLabels);

		mGraphPropertiesStream = graphPropertiesStream;
                
        init(control, graphPropertiesStream);
    } 


    protected void init(Graph control, InputStream is)
    {
         mAdapter = new BIBeanDataAccessAdapter(this);

         if ( (is != null) && (control != null))
         {
             try
             {	 
				control.readXML(is, oracle.dss.dataView.Dataview.RESET_NONE);
             }
             catch(oracle.dss.util.xml.BIParseException bipe)
             {
                 throw new JboException(bipe);
             }
             catch(oracle.dss.util.xml.BISAXException bie)
             {
                 throw new JboException(bie);
             }
             catch(oracle.dss.util.xml.BIIOException biioe)
             {
                 throw new JboException(biioe);
             }
         }

		 if (control != null)
		 {
			 Object errHandler = control.getErrorHandler();

			 if ( (errHandler != null) && (errHandler instanceof DefaultErrorHandler))
			 {
				 DefaultErrorHandler defErrHandler = (DefaultErrorHandler) errHandler;
	
				 defErrHandler.setDebugMode(DefaultErrorHandler.SHOW_NONE);
	
			 }
		 }
    }
    
    
    public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons)
    {
        ((JPanel) panel).add((Component) layoutObject, layoutCons);
    }

	protected void notifyView()
	{
		super.refreshBIBeanAdapter(mAdapter);
	}

    // Implement DataSource interface
    public RelationalDataDirector createRelationalDataDirector() 
    {
        return mAdapter;
    }
    
    public CubeDataDirector createCubeDataDirector() 
    {
        return mAdapter;
    }

    public void releaseReferences()
    {
        mAdapter.releaseReferences();

        mAdapter = null;

        mGraphPropertiesStream = null;
    }

}

