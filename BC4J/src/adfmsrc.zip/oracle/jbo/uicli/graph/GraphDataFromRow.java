/*
 * @(#)GraphDataFromRow.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.graph;

import oracle.dss.graph.Graph;

import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;

import oracle.adf.model.binding.DCIteratorBinding;

public class GraphDataFromRow
      extends JUGraphBinding
{
    
    private int mSeriesLabelColumnIndex = -1;

	private int numberOfColumnValuesPerMarker = 1;

	private String[] colLabels;
    
    public GraphDataFromRow(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames, String[] colLabels)
    {
        super(control, iterBinding, dataValueAttrNames);

		// last column used as series label
		mSeriesLabelColumnIndex = dataValueAttrNames.length -1; 

                iterBinding.setRangeSize(-1);

		setColumnLabels(colLabels);
    } 

	public void setColumnLabels(String[] labels)
	{
		this.colLabels = labels;
	}

	public String[] getColumnLabels()
	{
		return this.colLabels;
	}

    
    // implement JUGraphBinding abstract methods.
    protected String getColumnLabel(int i)
    {
        String label = null;

        if (colLabels != null)
        {
            return colLabels[i]; 
        }
        else
        {
            return super.getAttributeNames()[i];
        }
    }

    protected int getColumnCount()
    {
        
        String[] s = super.getAttributeNames();

		return s.length - 1; // last column is series label
    }


	protected String getRowLabel(int i)
    {
		if (isFindMode())
		{
			return emptyString;
		}

		int rangeIndex = rowIndexToRangeIndex(i);

		Object val =  getAttributeFromRow(rangeIndex, mSeriesLabelColumnIndex);
        
        if (val == null)
            val = emptyString;
            
        return val.toString();
    }

    protected long getRowCount()
    {
		long rc = getEstimatedRowCount(); 

        return ((rc == -1) ? 0 : rc);
    }


    protected Object getValue(int row, int col)
    {
		if (isFindMode())
		{
			return emptyString;
		}

		int rangeIndex = rowIndexToRangeIndex(row);

		Object val =  getAttributeValueFromRow(rangeIndex, col);
        
        if (val == null)
            val = emptyString;
            
        if ( val instanceof oracle.jbo.domain.Number)
            val = ((oracle.jbo.domain.Number)val).getData();

        return val;
    }

    public void updateValuesFromRows(Row[] rows, boolean clear)
	{
        super.updateValuesFromRows(rows, clear);

        if (colLabels == null)
        {
            colLabels = getHintsForColumnLabels();
        }
	}

    private String[] getHintsForColumnLabels()
    {
        String[] attrNames = super.getAttributeNames();

        DCIteratorBinding iter = super.getIteratorBinding();

        String hints[] = new String[attrNames.length];

        AttributeDef defs[] = iter.getAttributeDefs(attrNames);

       
        LocaleContext ctx = iter.getDataControl().getLocaleContext();

       
        for (int i=0; i < attrNames.length; i++)
               
        {
           hints[i] = defs[i].getUIHelper().getLabel(ctx);

           if (hints[i] == null)
           {
               hints[i] = attrNames[i];
           }
        }
      
        return hints;
    }


	// implement JUGraphBinding
    protected void notifyView()
	{
	}

	boolean isFindMode()
	{
		return getFormBinding().isFindMode();
	}

}




