/*
 * @(#)JUSingleTableGraphDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.graph;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.dss.graph.Graph;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.binding.JUCtrlRangeDef;
import oracle.jbo.common.JBOClass;


public class JUSingleTableGraphDef extends JUCtrlRangeDef
{
   public static final String PNAME_ColumnLabels = "ColumnLabels";// NOTRANS

   public static final String PNAME_SeriesLabelName = "SeriesLabel";// NOTRANS

   public static final String PNAME_GroupLabelName  = "GroupLabel";// NOTRANS
   
   public static final String PNAME_GraphPropertiesFileName  = "GraphPropertiesFileName";// NOTRANS

   // used in master detail graph binding
   public static final String PNAME_ChildAccessorName = "ChildAccessorName";// NOTRANS

   public static final String PNAME_SeriesType = "SeriesType";// NOTRANS

   public static final String SINGLE_SERIES = "SINGLE_SERIES";  // NOTRANS

   public static final String MASTER_DETAIL= "MASTER_DETAIL"; // NOTRANS

   public static final String PNAME_Graph             =  "DCGraph"; //NOTRANS

   // possible values SINGLE_SERIES and MASTER_DETAIL
   private String mSeriesType = SINGLE_SERIES;

   private String[] mColumnLabels = null;

   private String mSeriesLabelAttrName;

   private String mGroupLabelAttrName;

   private String mGraphPropertiesFileName;

   private String mChildAccessorName;

   
   public JUSingleTableGraphDef()
   {
      //setControlClassName(Graph.class.getName());

      setControlBindingClassName(JUSingleTableGraphBinding.class.getName());
   }


   public JUSingleTableGraphDef(String name, String controlClassName, 
                     String controlBindingClassName, String iterBindingName, 
                     String seriesLabelAttrName,
                     String[] attrNames, String[] colLabels, 
                     String graphPropertiesFileName)
   {
        super(name, controlClassName,
            (controlBindingClassName != null) ? controlBindingClassName : 
                        JUSingleTableGraphBinding.class.getName(),
            iterBindingName, attrNames);

        mColumnLabels = colLabels;

        mSeriesLabelAttrName = seriesLabelAttrName;

        mGraphPropertiesFileName = graphPropertiesFileName; 
   }


   public String[] getColumnLabels()
   {
        return mColumnLabels;
   }

   public String getSeriesLabelAttrName()
   {
       return mSeriesLabelAttrName;
   }

   public String getGroupLabelAttrName()
   {
       return mGroupLabelAttrName;
   }
   
   public String getGraphPropertiesFileName()
   {
       return mGraphPropertiesFileName;
   }

   public String getChildAccessorName()
   {
	   return mChildAccessorName;
   }

   public String getSeriesType()
   {
	   return mSeriesType;
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_ColumnLabels)) != null)
      {
         mColumnLabels = (String[]) val;
      }

      if ((val = initValues.get(PNAME_SeriesLabelName)) != null)
      {
        mSeriesLabelAttrName = (String) val;
      }

      if ((val = initValues.get(PNAME_GraphPropertiesFileName)) != null)
      {
        mGraphPropertiesFileName  = (String) val;
      }

	  if ((val = initValues.get(PNAME_ChildAccessorName)) != null)
      {
        mChildAccessorName  = (String) val;
      }

	  if ((val = initValues.get(PNAME_SeriesType)) != null)
      {
        mSeriesType = (String) val;
      }

      if ((val = initValues.get(PNAME_GroupLabelName)) != null)
      {
        mGroupLabelAttrName = (String) val;
      }
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
   
		if (getSeriesType().equals(SINGLE_SERIES))
		{
			return createSingleTableGraphBinding(control, formBnd);
		}
		else
		{
			return createMasterDetailGraphBinding(control, formBnd);
		}
	  
   }
   

   private DCControlBinding createSingleTableGraphBinding(Object control, DCBindingContainer formBnd)
   {
	   Graph graph = (Graph)control;

	   JUSingleTableGraphBinding graphBinding = null;

       if (getGraphPropertiesFileName() == null)
	   {
			graphBinding = (JUSingleTableGraphBinding)createSingleTableGraphBinding(
                (Graph)control,
				getIterBinding(formBnd), getAttrNames(), getSeriesLabelAttrName(), 
                null /* labels */);
	   }
	   else
	   {
	
			graphBinding = (JUSingleTableGraphBinding)createSingleTableGraphBinding(
                (Graph)control,
				getIterBinding(formBnd), getAttrNames(), getSeriesLabelAttrName(), 
                null, // labels - use UI hint
                decorateGraphPropertiesFileName(getGraphPropertiesFileName()) );
	   }

	   return graphBinding;
   }


   
   protected Object createSingleTableGraphBinding(Graph control, 
                DCIteratorBinding iterBinding, String[] dataValueAttrNames,
                String   seriesLabelAttrName, String[] colLabels)
   {
       return  new JUSingleTableGraphBinding(control, iterBinding, dataValueAttrNames,
                   seriesLabelAttrName, colLabels);
   }

   protected Object createSingleTableGraphBinding(Graph control, 
            DCIteratorBinding iterBinding, 
            String[] dataValueAttrNames,
            String   seriesLabelAttrName,
			String[] colLabels,
            String   graphDefFileName)
   {
       return new JUSingleTableGraphBinding ( control, iterBinding, dataValueAttrNames,
            seriesLabelAttrName, colLabels, graphDefFileName);
   }
   
   private DCControlBinding createMasterDetailGraphBinding(Object control, DCBindingContainer formBnd)
   {
	  Graph graph = (Graph)control;

	  JUMasterDetailGraphBinding graphBinding = null;

      String groupLabel = getGroupLabelAttrName();

      if (groupLabel == null)
      {
          groupLabel = getFirstAttrName();
      }

      // include the group label in the list of attr., 
      String[] modifiedAttrList = JUGraphBinding.buildAttributeListWithLabel(
              getAttrNames(), groupLabel); 

	  if (getGraphPropertiesFileName() == null)
	  {

		  graphBinding = (JUMasterDetailGraphBinding)createMasterDetailGraphBinding(
				(Graph)control, getIterBinding(formBnd),
				getSeriesLabelAttrName(), 
                getChildAccessorName(),
				modifiedAttrList,
			    1); 
	  }
	  else
	  {
          String decoratedGraphPropertiesFileName = decorateGraphPropertiesFileName(
                                    getGraphPropertiesFileName());

          int graphType = getGraphType((Graph)control,decoratedGraphPropertiesFileName);

          int numColumnsPerMarker = JUGraphBinding.getNumberOfColumnPerMarker(graphType);

		  graphBinding = (JUMasterDetailGraphBinding)createMasterDetailGraphBinding(
				(Graph)control, getIterBinding(formBnd),
				getSeriesLabelAttrName(), 
                getChildAccessorName(),
				modifiedAttrList,
			    numColumnsPerMarker, decoratedGraphPropertiesFileName);
      }

      graphBinding.setName(getName());

      return graphBinding;
   }

   protected Object createMasterDetailGraphBinding(Graph control, 
        DCIteratorBinding iterBinding, 
        String seriesLabelAttrName, String childAccessorName,
        String[] dataValueAttrNames, int numberOfColumnValuesPerMarker)
   {
       return new JUMasterDetailGraphBinding(control, 
                  iterBinding,  seriesLabelAttrName,
                  childAccessorName, dataValueAttrNames, 
                  numberOfColumnValuesPerMarker);
   }

   protected Object createMasterDetailGraphBinding(Graph control, 
                  DCIteratorBinding seriesBinding, 
				  String  seriesLabelAttrName,
				  String childAccessorName,
				  String[] dataValueAttrNames,
				  int numberOfColumnValuesPerMarker,
				  String graphPropertiesFileName)
   {
       return new JUMasterDetailGraphBinding(control, seriesBinding, 
              seriesLabelAttrName, childAccessorName, dataValueAttrNames,
              numberOfColumnValuesPerMarker, graphPropertiesFileName);
   }


   // package qualifed name passed : mypackage1.BIGraphDef
   //
   // replace dot with File seperator and add suffix xml

   // return mypackage1/BIGraphDef.xml

   private String decorateGraphPropertiesFileName(String s)
   {
       StringBuffer sbuf = new StringBuffer( s.replace('.', '/'));

       sbuf.append(".xml"); // NOTRANS

       return sbuf.toString();
   }

   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      HashMap valueTab = new HashMap(2);
      Object val;
      
      readXMLStringArray(xmlElement, PNAME_ColumnLabels, valueTab);

      if ((val = valueTab.get(PNAME_ColumnLabels)) != null)
      {
         mColumnLabels  = (String[]) val;
      }
   }

  
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_SeriesLabelName, valueTab);

      readXMLString(xmlElement, PNAME_GroupLabelName, valueTab);

      readXMLString(xmlElement, PNAME_GraphPropertiesFileName, valueTab);

      readXMLString(xmlElement, PNAME_ChildAccessorName, valueTab);

      readXMLString(xmlElement, PNAME_SeriesType, valueTab);

      Object val;

      if ((val = valueTab.get(PNAME_SeriesLabelName)) != null)
      {
         this.mSeriesLabelAttrName = (String) val;
      }

      if ((val = valueTab.get(PNAME_GroupLabelName)) != null)
      {
         this.mGroupLabelAttrName = (String) val;
      }

      if ((val = valueTab.get(PNAME_GraphPropertiesFileName)) != null)
      {
        mGraphPropertiesFileName  = (String) val;
      }

	  if ((val = valueTab.get(PNAME_ChildAccessorName)) != null)
	  {
		mChildAccessorName  = (String) val;
	  }

	  if ((val = valueTab.get(PNAME_SeriesType)) != null)
	  {	
		mSeriesType = (String) val;
	  }


   }

   int getGraphType(Graph control, String graphDefFileName)
   {
       Graph gr = control;

       if (gr == null)
       {
           gr = new Graph();
       }

       InputStream is = JBOClass.getResourceAsStream(graphDefFileName);
       
       try
       {	 
	       gr.readXML(is, oracle.dss.dataView.Dataview.RESET_NONE);

           return gr.getGraphType();
       }
       catch(Exception exc)
       {
           // exc.printStackTrace();
       }
       finally
       {   
           try
           {
               is.close();
           }
           catch(Exception e)
           {
               //   
           }
       }

       return Graph.BAR_VERT_CLUST ;
    
    }

   protected void initSubType()
   {
      setSubType(PNAME_Graph);
   }
}
