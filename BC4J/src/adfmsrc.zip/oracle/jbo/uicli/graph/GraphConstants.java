/*
 * @(#)GraphConstants.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.uicli.graph;

public interface GraphConstants
{
	// constants for various chart types

    // Three D charts
    public final static int THREED_BARS = 0;
    public final static int THREED_PYRAMIDS = 1;
    public final static int THREED_OCTAGONS = 2;
    public final static int THREED_FLOATING_CUBES = 4;
    public final static int THREED_FLOATING_PYRAMIDS = 5;
    public final static int THREED_FLOATING_CONNECTED_SERIES_AREA = 6;
    public final static int THREED_FLOATING_CONNECTED_SERIES_RIBBON = 7;
    public final static int THREED_FLOATING_CONNECTED_GROUP_AREA = 9;
    public final static int THREED_FLOATING_CONNECTED_GROUP_RIBBON = 10;
    public final static int THREED_SURFACE = 12;
    public final static int THREED_SURFACE_WITH_SIDES = 13;
    public final static int THREED_HONEYCOMB_SURFACE = 14;


    //Two D charts
    public final static int VERTICAL_CLUSTERED_BARS = 17;
    public final static int VERTICAL_STACKED_BARS = 18;
    public final static int VERTICAL_DUAL_AXIS_CLUSTERED_BARS = 19;
    public final static int VERTICAL_DUAL_AXIS_STACKED_BARS = 20;
    public final static int VERTICAL_BI_POLAR_CLUSTERED_BARS = 21;
    public final static int VERTICAL_BI_POLAR_STACKED_BARS = 22;
    public final static int VERTICAL_PERCENT_BARS = 23;

    // Bar charts - Horizontal
    public final static int HORIZONTAL_CLUSTERED_BARS = 24;
    public final static int HORIZONTAL_STACKED_BARS = 25;
    public final static int HORIZONTAL_DUAL_AXIS_CLUSTERED_BARS = 26;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_BARS = 27;
    public final static int HORIZONTAL_BI_POLAR_CLUSTERED_BARS = 28;
    public final static int HORIZONTAL_BI_POLAR_STACKED_BARS = 29;
    public final static int HORIZONTAL_PERCENT_BARS = 30;


    // Area charts - Vertical
    public final static int VERTICAL_ABSOLUTE_AREA = 31;
    public final static int VERTICAL_STACKED_AREA = 32;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_AREA = 33;
    public final static int VERTICAL_BI_POLAR_STACKED_AREA = 34;
    public final static int VERTICAL_PERCENT_AREA = 35;

    // Area charts - Horizontal
    public final static int HORIZONTAL_ABSOLUTE_AREA = 36;
    public final static int HORIZONTAL_STACKED_AREA = 37;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_AREA = 38;
    public final static int HORIZONTAL_BI_POLAR_STACKED_AREA = 39;
    public final static int HORIZONTAL_PERCENT_AREA = 40;

    // Line charts - Vertical
    public final static int VERTICAL_ABSOLUTE_LINE = 41;
    public final static int VERTICAL_STACKED_LINE = 42;
    public final static int VERTICAL_DUAL_AXIS_ABSOLUTE_LINE = 43;
    public final static int VERTICAL_DUAL_AXIS_STACKED_LINE = 44;
    public final static int VERTICAL_BI_POLAR_ABSOLUTE_LINE = 45;
    public final static int VERTICAL_BI_POLAR_STACKED_LINE = 46;
    public final static int VERTICAL_PERCENT_LINE = 47;

    // Line charts - Horizantal
    public final static int HORIZONTAL_ABSOLUTE_LINE = 48;
    public final static int HORIZONTAL_STACKED_LINE = 49;
    public final static int HORIZONTAL_DUAL_AXIS_ABSOLUTE_LINE = 50;
    public final static int HORIZONTAL_DUAL_AXIS_STACKED_LINE = 51;
    public final static int HORIZONTAL_BI_POLAR_ABSOLUTE_LINE = 52;
    public final static int HORIZONTAL_BI_POLAR_STACKED_LINE = 53;
    public final static int HORIZONTAL_PERCENT_LINE = 54;


    //Pie charts
    public final static int PIE = 55;
    public final static int RING_PIE = 56;
    public final static int MULTI_PIE = 57;
    public final static int MULTI_RING_PIE = 58;
    public final static int MULTI_PROPORTIONAL_PIE = 59;
    public final static int MULTI_PROPORTIONAL_RING_PIE = 60;
    public final static int PIE_BAR_CHART = 93;
    public final static int RING_PIE_BAR_CHART = 94;


    // Scatter charts
    public final static int XY_SCATTER = 61;
    public final static int XY_SCATTER_DUAL_AXIS = 62;
    public final static int XY_SCATTER_WITH_LABELS = 63;
    public final static int XY_SCATTER_WITH_LABELS_DUAL_AXIS = 64;


    public final static int POLAR = 65;
    public final static int POLAR_DUAL_AXIS = 66;


    public final static int RADAR_LINE =  67;
    public final static int RADAR_AREA =  68;
    public final static int RADAR_LINE_DUAL_AXIS =  69;

    // HI LO charts
    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART = 70;
    public final static int OPEN_HI_LO_CLOSE_CANDLE_STOCK_CHART_VOLUME = 71;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE = 72;
    public final static int STOCK_HI_LO = 73;
    public final static int STOCK_HI_LO_DUAL_AXIS = 74;
    public final static int STOCK_HI_LO_BI_POLAR = 75;
    public final static int STOCK_HI_LO_CLOSE = 76;
    public final static int STOCK_HI_LO_CLOSE_DUAL_AXIS = 77;
    public final static int STOCK_HI_LO_OPEN_CLOSE = 79;
    public final static int STOCK_HI_LO_OPEN_CLOSE_DUAL_AXIS = 80;
    public final static int STOCK_HI_LO_OPEN_CLOSE_BI_POLAR = 81;
    public final static int STOCK_HI_LO_VOLUME = 82;
    public final static int STOCK_HI_LO_OPEN_CLOSE_VOLUME = 83;
    public final static int CANDLE_STOCK_HI_LO_OPEN_CLOSE_VOLUME = 84;

    public final static int VERTICAL_HISTOGRAM = 85;
    public final static int HORIZONTAL_HISTOGRAM = 86;

    public final static int SPECTRAL_MAP = 87;

    public final static int BUBBLE_CHART = 89;
    public final static int BUBBLE_CHART_LABELS = 90;
    public final static int BUBBLE_CHART_DUAL_AXIS = 91;
    public final static int BUBBLE_CHART_LABELS_DUAL_AXIS = 92;

}

