package oracle.binding;

import java.util.Map;

/**
 * An interface through which the Data Binding Facility interacts with a Service.
 * An implementation of DataControl interface provides
 * generic adaptation for a Service and Model technology. For example,
 * a generic SessionBean DataControl can be written to handle interaction with any EJB
 * session beans.
 * <br>
 * The DataControl is to be implemented by someone who is familiar with the service
 * whose values and operations will be exposed to the view layer.
 * <br>
 * The DataControl is to be used exclusively by Tooling and the Data Binding facility
 * to adapt different Services. It is not to be used directly by the View or Controller
 * to access Services and Model.
 *  
 *
 */
public interface DataControl
{

    /**
     * Release all references held in the data control.
     */
    public static int REL_ALL_REFS       = -1;

    /**
     * Release only the data provider (Business Service) references
     */
    public static int REL_DATA_REFS      = 0x1;

    /**
     * Hold on to the data references and release the View references
     * if held on the datacontrol.
     */
    public static int REL_VIEW_REFS      = 0x2;

    /**
     * This is a weak data release.  This may be specified by
     * a DataControl to release data refs that do not rely upon any session state
     * like iterator currency.  These references are typical cache references and
     * may be rebuilt at any time using the DataControl.
     */
    public static int REL_WEAK_DATA_REFS = 0x4;

    /**
     * Returns name to identify this datacontrol inside a BindingContext.
     */
    public String getName();

    /**
     * Based on the value of the flags parameter, releases all references to
     * the objects in the data provider layer
     * Valid values for flags are:
     * <ul>
     *    <li><code>REL_ALL_REFS</code> - if this data control
     *        should release all references to both the view and model
     *        objects.
     *    <li><code>REL_DATA_REFS</code> - if this data control
     *        should release all references to data provider objects. The
     *        likely usage would be when say an Application Module is to
     *        be checked into a pool and this data-control may be given
     *        that or another checked out AM to work with subsequently.
     *    <li><code>REL_VIEW_REFS</code> - if this data control
     *        should release all references to the UI/View layer objects.
     * </ul>
     *
     * @param flags Indicates what references in the datacontrol should be released.
     *              Valid values are listed above.
     **/
    public void release(int flags);

    /**
     * Returns the Business Service Object that this datacontrol is associated with.
     *
     * @return The underlying business service object.
     */
    public Object getDataProvider();

    /**
     * Invokes an operation identified by the given method info and with ordered arguments in the params list.
     * <i>To be renamed to invokeOperation</i>
     *
     * @param bindingContext A binding context that provide access to all binding related
     *                       objects.
     * @param methodInfo Operartion on the datacontrol to be invoked.
     * @param params A map of argument names and values to be passed to the operation to be invoked.
     * @return the method return value.
     */
    //commenting out as invokeAction provides all the info for a method call.
    //public Object invokeMethod(Map bindingContext, MethodInfo methodInfo, java.util.Map params);

    /**
     * All OperationBindings should first delegate to the DataControl associated
     * with the binding to perform the action. DataControls may choose to interpret
     * a given action differently based on the data/collection that action is bound to.
     * @return true if this datacontrol has handled this action, false if the action
     * should be interpreted in the bindings framework or in the caller.
     */
    public boolean invokeOperation(Map bindingContext, OperationBinding action);

}
