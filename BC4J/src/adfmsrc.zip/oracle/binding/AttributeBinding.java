package oracle.binding;

import java.util.List;

/**
 * A ControlBinding that binds a single attribute value exposed via a datacontrol
 * to a view component.
 * <br>
 * This interface is implemented by the data binding framework, and is made available
 * to the View components through the binding container. 

 */
public interface AttributeBinding extends ControlBinding
{
    /**
     * Returns the value that should be rendered on a view for the attribute
     * associated with this binding.
     *
     * @return The attribute value.
     */
    public Object getInputValue();

    /**
     * Updates the attribute value associated with this binding. If there are exceptions
     * while updating this attribute, these exceptions should be accessible via getErrors().
     *
     * @param inputVal The new attribute value.
     *
     * @see #getErrors()
     */
    public void setInputValue(Object inputVal);

    /**
     * Returns the display label or prompt for the attribute represented by this binding.
     *
     * @return The display label or prompt string.
     */
    public String getLabel();

    /**
     * Finds out whether the attribute is updateable or is for display only.
     *
     * @return True if the attribute is updateable, false otherwise.
     */
    public boolean isUpdateable();

    /**
     * Returns a list of errors that were raised during the last setInputValue
     * call.
     *
     * @return A list of Throwable that were raised during setInputValue(). It
     *         returns null if there is no error occurred.
     *
     * @see #setInputValue(Object)
     */
    public List getErrors();
}
