package oracle.binding;

import java.util.List;

/**
 * A ControlBinding that binds multiple attribute values exposed via a datacontrol
 * to a view component, and manages access to current ranges and position within
 * the attribute collection. It can be used for binding the detail rows in a
 * master-detail relationship.
 * <br>
 * This interface is implemented by the data binding framework, and is made available
 * to the View components through the binding container. 
 */
public interface RangeBinding extends ControlBinding
{
    /**
     * Returns the display label or prompt for the all the attributes represented by this
     * binding.
     *
     * @return An array of the display label or prompt strings, one per attribute represented
     *         by this AttributesBinding.
     */
    public String[] getLabelSet();

    //public int getRowCountInRange();

    /**
     * Returns the index of the current row.
     *
     * @return The index of the current row.
     */
    public int getCurrentRowIndex();

    /**
     * Designates a given index as the current row.
     *
     * @param index the index of the new current row.
     */
    public void setCurrentRowAtIndex(int index);

    /**
     * Returns a list of Map elements over the range of rows.
     * The elements in this list are wrapper objects over the indexed row in the range that
     * restricts access to only the attributes that this control-binding is bound to.
     * The map exposes the following properties for each row in the range:
     * <li><code>index</code> - returns index of the row</li>
     * <li><code>key</code>  - returns Key of the row</li>
     * <li><code>keyStr</code> - returns String format of the key of the row at this index()</li>
     * <li><code>currencyString</code> - if this row is the current row, returns "*" else returns a space.</li>
     * <li><code>attributeValues</code> - returns an array of attribute values for attributes that are bound
     *                                    to this row</li>
     *
     * @return A list of Map elements as described above.
     */
    public List getRangeSet();
}
