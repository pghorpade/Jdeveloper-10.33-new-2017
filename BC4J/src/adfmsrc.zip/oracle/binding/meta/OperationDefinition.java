package oracle.binding.meta;

/**
 * Interface for holding metadata of an operation. 
 * The operation can be either a common operation, such as Next and Commit,
 * or custom operation, which is specific to the DataControl implementation.
 */
public interface OperationDefinition extends NamedDefinition
{
   // Id for custom operation to be returned in getId
   public final int CUSTOM = 999;   
   
   /**
    * Retrieves the metadata of the parameters of the operation.
    *
    * @return A DefinitionContainer containing the metadata of all parameters in
    *         the operation. There should be one ParameterDefinition object
    *         in the DefinitionContainer containing metadata for each parameter.
    *         If there are no paremeters, or if the operation is a common
    *         operation, an instance of EmptyDefinitionContainer
    *         should be returned.
    *
    * @see ParameterDefinition
    * @see EmptyDefinitionContainer
    */
   public DefinitionContainer getOperationParameters();
   
   /**
    * Retrieves the metadata of the return type of the operation.
    *
    * @return Metadata of the return type of the operation. If the operation
    *         does not return any value, or if it is a common operation, null
    *         can be returned.
    */
   public MethodReturnDefinition getOperationReturnType();
   
   /**
    * Retrieves the operation id of the operation.
    * @return The id of the operation, or CUSTOM if this is a custom
    *         operation. 
    */
   public int getOperationId();
   
   /**
    * Retrieves the DataControlDefinition that this Operation belongs to.
    * 
    * @return The DataControlDefinition that this Operation belongs to.
    */ 
   public DataControlDefinition getDataControlDefinition();

   /**
    **
    **@return true if this is a static method on the structure.
    **
    **/
   public boolean isStatic();
}

