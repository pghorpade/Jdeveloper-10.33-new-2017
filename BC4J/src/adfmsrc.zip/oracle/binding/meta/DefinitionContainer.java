package oracle.binding.meta;
import java.util.Iterator;

/**
 * Interface used as container of multiple Definitions. It is used
 * for returning multiple instances of Definition from a method.
 *
 * @see Definition
 */
public interface DefinitionContainer
{
    /**
     * Finds a Definition with the given identifier.
     *
     * @param definitionId Identifier of the Definition that we want to find.
     * @return The Definition object with the given identifier, or null if no
     *         such Definition is found.
     */
    public Definition find(String definitionId);

    /**
     * Obtains an iterator for looping through each of the Definition instances contained
     * in this DefinitionContainer.
     * @return An Iterator of Definition instances that are stored in this
     *         DefinitionContainer.
     */
    public Iterator iterator();

    /**
     * Tests whether the definition container is empty.
     * @return True if this DefinitionContainer does not contain any Definition,
     *         or false otherwise.
     */
    public boolean isEmpty();
}
