package oracle.binding.meta;
import java.util.ArrayList;

/**
 * A class that implements the DefinitionContainer interface using an java.util.ArrayList
 * for storage of Definition instances.
 * <br>This class may be modified to expose the Iterator or List interface instead of
 *     extending java.util.ArrayList.
 */
public class ArrayListDefinitionContainer extends ArrayList implements DefinitionContainer
{
    /**
     * Default Constructor.
     */
    public ArrayListDefinitionContainer()
    {
    }

    /**
     * Returns the number of Definition instances contained in this ArrayListDefinitionContainer.
     * @return The number of definitions.
     */
    public int getSize()
    {
        return super.size();
    }

    /**
     * Retrieves the Definition located at the given position in the array.
     * @param index Position of the Definition to be retrieved.
     * @return The Definition located at the given position in the array.
     */
    public Definition item(int index)
    {
        return (Definition)super.get(index);
    }

    /**
     * Finds a Definition with the given id.
     * @param definitionId Identifier of the Definition that we want to find.
     * @return The Definition object with the given identifier, or null if no
     *         such Definition is found.
     */
    public Definition find(String definitionId)
    {
        int nSize = super.size();
        for(int i = 0; i < nSize; i++)
        {
            Definition def = item(i);
            if(def instanceof NamedDefinition)
            {
                if(((NamedDefinition)def).getName().equals(definitionId))
                    return def;
            }
        }

        return null;
    }
}
