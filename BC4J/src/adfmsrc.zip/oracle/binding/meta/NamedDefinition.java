package oracle.binding.meta;

import oracle.binding.meta.Definition;

import java.util.Hashtable;

/**
 * Interface for holding named metadata.
 */
public interface NamedDefinition extends Definition
{

   /**
    * Returns the parent of this metadata definition, which is the Definition
    * that contains this Definition. For example, the parent of an AttributeDefinition
    * could be a StructureDefinition if the attribute is contained in the structure.
    *
    * @return The parent Definition
    */
   public Definition getDefinitionParent();
   
   /**
    * Returns the name of this Definition.
    *
    * @return Name of this Definition.
    */
   public String getName();
   
   /**
    * Returns the full name of this Definition, which includes the name of any parent
    * objects. The full name should reflect the runtime nesting level.
    *
    * @return Full name of this Definition.
    */
   public String getFullName();
   
   /**
    * Retrieves the value of a property with the given name. Properties can
    * be used for UI hints such as display width and height. 
    * @param propertyName Name of the property to be retrieved.
    * @return Value of the property with the given property name.
    */
   
   public Object getProperty(String propertyName);
   
   /**
    * Gets the table of properties.
    * This returns a hashtable to ensure any modification done by caller would
    * be synchronized.
    * 
    * Note that this API has not been added to the JSR yet.
    * @return a hashtable of properties.
    */
   public Hashtable getProperties();

}
