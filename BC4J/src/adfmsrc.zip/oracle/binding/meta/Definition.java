package oracle.binding.meta;

/**
 * This is a a marker interface.
 * This interface is the parent of other interfaces that are used for
 * holding metadata.
 **/
public interface Definition
{
   /**
    * Constant for Definition. 
    * Classes that implements Definition but not any of its subinterfaces 
    * should return this in its getType().
    */ 
   public static final int TYPE_DEFINITION = 0;
   /**
    * Constant for NamedDefinition. 
    * Classes that implements NamedDefinition but not any of its subinterfaces 
    * should return this in its getType().
    */ 
   public static final int TYPE_NAMED = 10;
   /**
    * Constant for StructureDefinition. 
    * Classes that implements StructureDefinition should return this in its getType().
    */ 
   public static final int TYPE_STRUCTURE = 20;
   /**
    * Constant for AttributeDefinition
    * Classes that implements AttributeDefinition but not any of its subinterfaces
    * should return this in its getType().
    */
   public static final int TYPE_ATTRIBUTE = 30;
   /**
    * Constant for AccessorDefinition
    * Classes that implements AccessorDefinition should return this in its getType().
    */
   public static final int TYPE_ACCESSOR = 40;
   /**
    * Constant for DataControlDefinition
    * Classes that implements DataControlDefinition should return this in its getType().
    */
   public static final int TYPE_DATACONTROL = 50;
   /**
    * Constant for OperationDefinition
    * Classes that implements OperationDefinition should return this in its getType().
    */
   public static final int TYPE_OPERATION = 60;
   /**
    * Constant for ParameterDefinition
    * Classes that implements ParameterDefinition should return this in its getType().
    */
   public static final int TYPE_PARAMETER = 70;
   /**
    * Constant for VariableDefinition
    * Classes that implements VariableDefinition but not any of its subinterfaces
    * should return this in its getType().
    */
   public static final int TYPE_VARIABLE = 80;
   /**
    * Constant for DefinitionContext
    * Classes that implements DefinitionContext should return this in its getType().
    */
   public static final int TYPE_DEFINITIONCONTEXT = 90;

   /**
    * Constant for MethodReturnDefinition
    * Classes that implements MethodReturnDefinition should return this in its getType().
    */
   public static final int TYPE_METHODRETURN = 100;
   
   /**
    * Retrieves the type of this definition. It can be one of the TYPE_* 
    * constants defined in this class. This is useful to find out the
    * actual type of the Definition without doing an instanceof operations.
    * @return The type of definition that this Definition implementation 
    *         class implements.
    */ 
   public int getDefinitionType();
}
