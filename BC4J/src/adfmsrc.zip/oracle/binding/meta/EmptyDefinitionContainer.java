package oracle.binding.meta;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * An implementation class of DefinitionContainer to represent an empty collection
 * of Definition.
 */
public final class EmptyDefinitionContainer implements DefinitionContainer
{
    private static EmptyDefinitionContainer _instance = new EmptyDefinitionContainer();
    private static ArrayList     _list = new ArrayList();

    /**
     * Private constructor to prevent instances of EmptyDefinitionContainer from
     * being created. Callers should use getInstance instead.
     * @see #getInstance()
     */
    private EmptyDefinitionContainer()
    {
    }

    /**
     * Obtain the singleton EmptyDefinitionContainer instance.
     * @return The one and only EmptyDefinitionContainer instance.
     */
    public static DefinitionContainer getInstance()
    {
        return _instance;
    }

    /**
     * Find a Definition with the given id.
     * @param definitionId Identifier of the Definition that we want to find.
     * @return The Definition object with the given identifier. This method always null.
     */
    public Definition find(String definitionId)
    {
        return null;
    }

    /**
     * Obtain an iterator for looping through each of the Definitions contained
     * in this DefinitionContainer.
     * @return An Iterator of Definition instances that are stored in this
     *         DefinitionContainer. The Iterator returns from this method contains
     *         no element.
     */
    public Iterator iterator()
    {
        return _list.iterator();
    }

    /**
     * Return true if the container is empty.
     * @return Always return true since this is an empty container.
     */ 
    public boolean isEmpty()
    {
       return true;
    }
}
