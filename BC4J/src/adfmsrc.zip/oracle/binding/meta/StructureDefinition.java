package oracle.binding.meta;


/**
 * Contains metadata for a structure such as a datacontrol, an accessor,
 * or a parameter.
 */
public interface StructureDefinition extends NamedDefinition
{
    /**
     * Returns the metadata about the attributes in this structure.
     * @return A DefinitionContainer containing the metadata of all attributes in
     *         the structure. There should be one AttributeDefinition object
     *         in the DefinitionContainer containing metadata for each attribute.
     *         If there are no attribute, an instance of EmptyDefinitionContainer
     *         should be returned.
     * @see EmptyDefinitionContainer
     * @see AttributeDefinition
     */
    public DefinitionContainer getAttributeDefinitions();

    /**
     * Returns the metadata about the accessors in this structure.
     * @return A DefinitionContainer containing the metadata of all acessors in
     *         the structure. There should be one AccessorDefinition object
     *         in the DefinitionContainer containing metadata for each accessor.
     *         If there are no accessor, an instance of EmptyDefinitionContainer
     *         should be returned.
     * @see EmptyDefinitionContainer
     * @see AccessorDefinition
     */
    public DefinitionContainer getAccessorDefinitions();

    /**
     * Returns the metadata about the operations in this structure.
     * @return A DefinitionContainer containing the metadata of all operations in
     *         the structure. There should be one OperationDefinition object
     *         in the DefinitionContainer containing metadata for each operation.
     *         If there are no operation, an instance of EmptyDefinitionContainer
     *         should be returned.
     * @see EmptyDefinitionContainer
     * @see OperationDefinition
     */
    public DefinitionContainer getOperationDefinitions();
    
   /**
    * Returns the metadata about the constructor operations in this structure.
    * @return A DefinitionContainer containing the metadata of all constructor operations in
    *         the structure. There should be one OperationDefinition object
    *         in the DefinitionContainer containing metadata for each operation.
    *         If there are no operation, an instance of EmptyDefinitionContainer
    *         should be returned.
    * @see EmptyDefinitionContainer
    * @see OperationDefinition
    */
   public DefinitionContainer getConstructorOperationDefinitions();
   
   /**
    * Retrieves the DataControlDefinition that this Structure belongs to.
    * 
    * @return The DataControlDefinition that this Structure belongs to.
    */ 
   public DataControlDefinition getDataControlDefinition();
}
