package oracle.binding.meta;
import java.util.HashMap;

/**
 * The DefaultDefinitionContext class can be used for storing and lookup of
 * control bindings and datacontrols metadata. It uses a HashMap for internal
 * storage of the metadata.
 */
public class DefaultDefinitionContext extends HashMap implements DefinitionContext
{
    /**
     * Default Constructor.
     */
    public DefaultDefinitionContext()
    {
    }

   public int getDefinitionType()
   {
      return TYPE_DEFINITIONCONTEXT;
   }
}
