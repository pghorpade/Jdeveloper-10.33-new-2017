package oracle.binding.meta;

/**
 * Interface for holding attribute metadata.
 */
public interface AttributeDefinition extends VariableDefinition
{
    /**
     * Finds out whether this attribute is read-only or is updateable.
     *
     * @return True if this attribute is read-only, false otherwise.
     */
    public boolean isReadOnly();

    /**
     * Finds out whether this attribute is the primary key of the row.
     *
     * @return True if this attribute is the primary key, false otherwise.
     */
    public boolean isKey();

    /**
     * Returns the actual java type of the attribute in the data source.
     * This may be different from the java type returned by getJavaTypeString
     * if the data control is returning an attribute as a different datatype
     * as what it is in its data source. For example, if the source type is
     * a java.lang.String representing some number, the java type of the attribute
     * could be java.lang.Integer.
     *  
     * @return The java type of the attribute in the data source.
     */ 
    public String getSourceTypeString();
}
