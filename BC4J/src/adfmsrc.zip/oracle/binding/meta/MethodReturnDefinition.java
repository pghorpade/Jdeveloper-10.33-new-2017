package oracle.binding.meta;

/**
 * Marker interface for defining return types, as returned
 * in the getReturnType method in OperationDefinition.
 *  
 * Instances of this interface should return TYPE_METHODRETURN,
 * which is defined in oracle.binding.meta.Definition, when its
 * getType() method is called. 
 */
public interface MethodReturnDefinition extends ParameterDefinition
{
   
   /**
    * Retrieves the metadata of the return collection. It is possible that the
    * collection itself has operations defined, such as if the collection is
    * a class that implements a java.util.Collection interface and contains
    * methods for searching through its elements.
    *  
    * Please note that this is different from the getStructure API, which
    * returns the metadata of the collection elements.
    * 
    * @return The metadata describing the structure of the collection, or null
    *         if there is none available for the return collection.
    */ 
   public StructureDefinition getCollectionStructure();
   
}
