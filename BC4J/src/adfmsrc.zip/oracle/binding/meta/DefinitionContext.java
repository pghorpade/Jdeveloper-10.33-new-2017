package oracle.binding.meta;
import java.util.Map;

/**
 *  Marker interface that provides a namespace for looking up metadata for
 *  control bindings and datacontrols.
 */
public interface DefinitionContext extends Map, Definition
{
}
