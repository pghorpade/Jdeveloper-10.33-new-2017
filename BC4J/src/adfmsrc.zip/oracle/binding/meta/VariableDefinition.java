package oracle.binding.meta;

/**
 * This interface is used for holding metadata for a variable.
 */
public interface VariableDefinition extends NamedDefinition
{

   /**
    * Retrieves the type of the variable.
    *
    * @return The fully qualified Java class name of the variable type.
    */
   public String getJavaTypeString();

   /**
    * Retrieves the DataControlDefinition that this Variable belongs to.
    * 
    * @return The DataControlDefinition that this Variable belongs to.
    */ 
   public DataControlDefinition getDataControlDefinition();

}
