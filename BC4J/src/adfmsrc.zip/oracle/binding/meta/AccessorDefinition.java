package oracle.binding.meta;

/**
 * Interface for holding accessor metadata. Accessor is an attribute that returns
 * a collection.
 */
public interface AccessorDefinition extends AttributeDefinition
{
   /**
    * Since an accessor can return a structured object (or a
    * collection). This function should return true when the accessor
    * represents a collection.
    *
    * @return true if the accessor is a collection, false if it is a simple object such
    *         as a String or an int.
    **/
   public boolean isCollection();
   
   /**
    * Returns true if the accessor returns a collection of scalars.
    * Scalars are simple types that are not structured and are not
    * collections.
    * 
    * @return true if the accessor is a collection of scalars, false otherwise.
    */ 
   public boolean isScalarCollection();
   
   /**
    * Retrieves the metadata of the elements that the accessor collection contains.
    *
    * @return The metadata describing the structure of the elements in the accessor
    *         collection.
    */
   public StructureDefinition getStructure();
   
   /**
    * Retrieves the metadata of the collection itself. It is possible that the
    * collection itself has operations defined, such as if the collection is
    * a class that implements a java.util.Collection interface and contains
    * methods for searching through its elements.
    *  
    * Please note that this is different from the getStructure API, which
    * returns the metadata of the collection elements.
    * 
    * @return The metadata describing the structure of the collection, or null
    *         if there is none available for the collection.
    */ 
   public StructureDefinition getCollectionStructure();
   
   /**
    * Retrieves the AccessorDefinition of the parent accessor. A parent accessor
    * is the accessor from which this accessor is obtained from. For example,
    * we have a Dept structure, which contains an accessor called emps that returns
    * a collection of Employee. Each Employee structure in turn contains an
    * accessor called address that returns a structured type Address.
    * The parent accessor of address would be the accessor emps in the Dept structure.
    * @return The definition of the parent accessor.
    */ 
   public NamedDefinition getParentAccessor();
}
