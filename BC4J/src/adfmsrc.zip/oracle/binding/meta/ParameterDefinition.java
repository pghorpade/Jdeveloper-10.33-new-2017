package oracle.binding.meta;

/**
 * Interface for holding metadata for a method parameter.
 */
public interface ParameterDefinition extends VariableDefinition
{
    /**
     * Whether the parameter is a structure, such as a JavaBean or a Collection of
     * JavaBeans.
     *
     * @return True if the parameter is a structure, false if it is a simple type such
     *         as a String, int, etc.
     */
    public boolean isStructured();

    /**
     * If the parameter is a structure, returns the metadata of the structure.
     *
     * @return The metadata of the parameter if it is a structure, or
     *         null otherwise.
     */
    public StructureDefinition getStructure();

    /**
     * Whether the parameter is a Collection of objects.
     *
     * @return True if the parameter is a Collection of objects, false otherwise.
     */
    public boolean isCollection();

   /**
    * Returns true if the parameter is a collection of scalars.
    * Scalars are simple types that are not structured and are not
    * collections.
    * 
    * @return true if this parameter is a collection of scalars, false otherwise.
    */ 
   public boolean isScalarCollection();
   
}
