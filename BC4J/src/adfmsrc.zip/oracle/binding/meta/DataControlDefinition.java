package oracle.binding.meta;

/**
 * Interface for holding metadata for a DataControl.
 *
 * @see oracle.binding.DataControl
 *
 */
public interface DataControlDefinition extends NamedDefinition
{
    /**
     * Retrieves the structure metadata of this datacontrol.
     *
     * @return The structure metadata of this datacontrol.
     */
    public StructureDefinition getStructure();
}
