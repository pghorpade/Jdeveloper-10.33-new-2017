package oracle.binding;

import java.util.Map;

/**
 * A RowContext contains context that is passed into the TransactionalDataControl APIs
 * when manipulating a row, such as when the row is being modified, created, or removed
 * as a result of user interaction with the view layer.
 */
public interface RowContext
{
   /**
    * Return the data object that this row represents.
    */
   public Object getRowDataProvider();

   /**
    * Return the data object of the master row of the row that this RowContext
    * represents.
    * @return The data object of the master row
    */
   public Object getMasterRowDataProvider();

   /**
    * Return true when the container object of this row is null.
    * In that case, the datacontrol may also have to create the container object.
    */
   public boolean isNullContainer();

   /**
    * Return the fully-qualified type name for the dataprovider that this row represents.
    */
   public String getRowDataProviderType();

   /**
    * Return the bindingContext for this Application instance.
    */
   public Map getBindingContextMap();
}

