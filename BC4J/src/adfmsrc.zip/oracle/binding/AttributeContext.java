package oracle.binding;

import java.util.Map;

/**
 * A AttributeContext contains context that is passed into the TransactionalDataControl APIs
 * when manipulating a bean attribute.
 */
public interface AttributeContext extends RowContext
{
   /**
    * Attribute name within the associated bean that is being modified.
    */
   String getAttributeName();
}

