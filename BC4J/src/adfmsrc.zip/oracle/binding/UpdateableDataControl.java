package oracle.binding;

/* $Header: UpdateableDataControl.java 02-dec-2005.16:13:13 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    12/02/05 - XbranchMerge jsmiljan_bug-4752286 from main 
    jsmiljan    11/18/05 - Creation
 */

/**
 *  @version $Header: UpdateableDataControl.java 02-dec-2005.16:13:13 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */

import java.util.Map;

/**
 * This interface is to be implemented by DataControls that support an
 * updateable or mutable business service.
 */
public interface UpdateableDataControl extends DataControl
{
    /**
     * This method is called by the data binding framework when a new
     * value is to be set on an attribute in a bean. The attribute and bean
     * are provided in the attribute context along with other
     * framework context information.
     * <p>
     * Return true if the base framework should skip any further processing
     * of this attribute set. Otherwise return false so that framework can
     * perform a set or put of the attribute value based on introspection.
     */
    public boolean setAttributeValue(AttributeContext ctx, Object value);

    /**
     * This method is called by the data binding framework when a new
     * row is needed from the data control.
     *
     * @param ctx Context of the new row.
     * @return A data object for the new row.
     */
    public Object createRowData(RowContext ctx);

    /**
     * This method is called by the data binding facility before the row in the RowContext object is 
     * modified or marked as removed, so the row can be marked dirty by the data control.
     *
     * @param ctx Context of the row to be modified or removed.
     * @return  The data object that the row represents.
     */
    public Object registerDataProvider(RowContext ctx);

    /**
     * This method is called by the data binding facility when a row
     * should be removed from the underlying data source.
     *
     * @param ctx Context of the row to be removed.
     * @return true if the operation is sucessful, false otherwise.
     */
    boolean removeRowData(RowContext ctx);

    /**
     * Validates transaction if dirty.
     */
    public void validate();
}
