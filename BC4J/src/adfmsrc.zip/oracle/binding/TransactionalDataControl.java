package oracle.binding;

import java.util.Map;

/**
 * This interface is to be implementated by DataControls that supports transactions.
 */
public interface TransactionalDataControl extends DataControl
{
    /**
     * Returns true if this transaction has been dirtied by this application, as a result
     * of data updates, deletes or inserts.
     *
     * @return true if transaction is dirty, false otherwise.
     */
    boolean isTransactionDirty();

    /**
     * Rolls back the current transaction.
     */
    public void rollbackTransaction();

    /**
     * Commits the current transaction to save all changes to the data source.
     */
    public void commitTransaction();
}
