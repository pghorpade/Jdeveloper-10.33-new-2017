package oracle.binding;

import oracle.binding.meta.Definition;

/**
 * This interface is implemented by data controls that may return 
 * definitions.
 */
public interface DefinitionProviderDataControl
{
   /**
    *  Returns a definition of the specified type.
    */
   public Definition getDefinition(String name, Class type);
}
