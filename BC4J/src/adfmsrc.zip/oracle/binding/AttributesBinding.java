package oracle.binding;

import java.util.List;

/**
 * A ControlBinding that binds multiple attribute values exposed via a datacontrol
 * to a view component, and manages access to the actual values.
 * <br>
 * This interface is implemented by the data binding framework, and is made available
 * to the View components through the binding container. 
 */
public interface AttributesBinding extends ControlBinding
{
    /**
     * Returns the value that should be rendered on a view for the attribute
     * associated with this binding at the specified position.
     *
     * @param index index of the attribute to retrieve.
     * @return The attribute value at the specified position, or null if the given
     *         index is out of range or no attribute can be found at the specified
     *         position.
     */
    public Object getInputValue(int index);

    /**
     * Updates the attribute value associated with this binding at the given position.
     * If there are exceptions while updating this attribute, these exceptions should be accessible
     * via getErrors().
     *
     * @param index index of the attribute to be updated.
     * @param inputVal The new attribute value.
     */
    public void setInputValue(int index, Object inputVal);

    /**
     * Finds out whether the attribute is updateable or is for display only.
     *
     * @return True if the attribute is updateable, false otherwise.
     */
    public boolean isUpdateable(int index);

    /**
     * Returns the display label or prompt for the all the attributes represented by this
     * binding.
     *
     * @return An array of the display label or prompt strings, one per attribute represented
     *         by this AttributesBinding.
     */
    public String[] getLabelSet();

    /**
     * Returns a list of errors that were raised during the last setInputValue
     * call.
     *
     * @return A list of Throwable that were raised during setInputValue(). It
     *         returns null if there is no error occurred.
     *
     * @see #setInputValue(int, Object)
     */
    public List getErrors();
}
