package oracle.binding.metaimpl;

import java.util.Hashtable;
import oracle.binding.meta.*;

/**
 * A class for holding metadata of variables.
 */
public class BaseValueObjectDefinition implements VariableDefinition
{
    private String       _id;
    private Definition   _parent;
    private String       _bindPath;
    private String       _javaType;
    private Hashtable    _properties;
   
    /**
     * Constructor.
     * @param id Name of the variable.
     * @param parent Metadata of the parent structure.
     * @param bindPath Path used to find this object at runtime
     * @param javaType Fully-qualified Java class name of the attribute type.
     * @see VariableDefinition
     */
    public BaseValueObjectDefinition(String id, Definition parent,
                                     String bindPath, String javaType)
    {
        _id = id;
        _parent = parent;
        _bindPath = bindPath;
        _javaType = javaType;
        _properties = new Hashtable();
    }

    /**
     * Retrieves the type of the variable.
     *
     * @return The fully qualified Java class name of the variable type.
     */
    public String getJavaTypeString()
    {
        return _javaType;
    }

    /**
     * Returns the definition of the DataControl that the variable belongs to.
     * This method attempts to retrieve the DataControlDefinition from the
     * parent definition.
     * 
     * @return The DataControlDefinition of the datacontrol that this variable
     *         comes from.
     */ 
    public DataControlDefinition getDataControlDefinition()
    {
       if (_parent != null)
       {
          int type = _parent.getDefinitionType();
          switch (type)
          {
             case TYPE_ACCESSOR:
             case TYPE_ATTRIBUTE:
             case TYPE_VARIABLE:
             case TYPE_PARAMETER:
             case TYPE_METHODRETURN:
                return ((VariableDefinition)_parent).getDataControlDefinition();
             case TYPE_STRUCTURE:
                return ((StructureDefinition)_parent).getDataControlDefinition();
             case TYPE_OPERATION:
                return ((OperationDefinition)_parent).getDataControlDefinition();
             case TYPE_DATACONTROL:
                return (DataControlDefinition) _parent;
          }
       }
       return null;
    }
   
    /**
     * Retrieves the type of the variable. It can be one of the TYPE_*
     * contants definied in VariableDefinition.
     * @return Always return TYPE_PRIMITIVE.
     */
    public int getDefinitionType()
    {
       return TYPE_VARIABLE;
    }
   
    /**
     * Returns the name of this Definition.
     *
     * @return Name of this Definition.
     */
    public String getName()
    {
        return _id;
    }

    /**
     * Returns the parent of this metadata definition, which is the Definition
     * that contains this Definition. For example, the parent of an AttributeDefinition
     * could be a StructureDefinition if the attribute is contained in the structure.
     *
     * @return The parent Defintion
     */
    public Definition getDefinitionParent()
    {
        return _parent;
    }

    /**
     * Returns the full name of this Definition.
     *
     * @return Full name of this Definition.
     */
    public String getFullName()
    {
        return _bindPath;
    }

    /**
     * Returns the value of the given property name.
     * @param propertyName Name of property whose value is to be returned.
     * @return Always return null since this class does not have any property.
     */ 
    public Object getProperty(String propertyName)
    {
       return _properties.get(propertyName);
    }

   /**
    * Gets the table of properties.
    * This returns a hashtable to ensure any modification done by caller would
    * be synchronized.
    * 
    * Note that this API has not been added to the JSR yet.
    * @return a hashtable of properties.
    */
    public Hashtable getProperties()
    {
       return _properties;
    }
}
