package oracle.binding.metaimpl;

import oracle.binding.meta.*;

/**
 * A class for holding metadata of attributes.
 */
public class BaseAttributeDefinition extends BaseValueObjectDefinition implements AttributeDefinition
{
    private boolean   _isReadOnly;
    private boolean   _isKey;
    private String    _sourceTypeString;
   
    /**
     * Constructor.
     *
     * @param id Identifier, or name, of the attribute.
     * @param parent Metadata of the parent structure.
     * @param javaType Fully-qualified Java class name of the attribute type.
     * @param isReadOnly Whether the attribute is read-only.
     * @param isKey Whether the attribute is the primary key of a row.
     */
    public BaseAttributeDefinition(String id, StructureDefinition parent,
                                   String javaType, boolean isReadOnly, boolean isKey)
    {
        super(id, parent, parent.getFullName() + "." + id, javaType);
        _isReadOnly = isReadOnly;
        _isKey = isKey;
        _sourceTypeString = javaType;
    }

    /**
     * Finds out whether this attribute is read-only or is updateable.
     *
     * @return True if this attribute is read-only, false otherwise.
     */
    public boolean isReadOnly()
    {
        return _isReadOnly;
    }

    /**
     * Specify whether this attribute is read-only or is updateable.
     */
    public void setReadOnly(boolean isReadOnly)
    {
        _isReadOnly = isReadOnly;
    }

    /**
     * Set the java type of this attribute in the data source.
     * 
     * @param sourceTypeString A String representing the java type.
     */ 
    public void setSourceTypeString(String sourceTypeString)
    {
       _sourceTypeString = sourceTypeString;
    }
   
    /**
     * Finds out whether this attribute is the primary key of the row.
     *
     * @return True if this attribute is the primary key, false otherwise.
     */
    public boolean isKey()
    {
        return _isKey;
    }

    /**
     * Returns the actual java type of the attribute in the data source.
     * This may be different from the java type returned by getJavaTypeString
     * if the data control is returning an attribute as a different datatype
     * as what it is in its data source. For example, if the source type is
     * a java.lang.String representing some number, the java type of the attribute
     * could be java.lang.Integer.
     * 
     * @return The java type of the attribute in the data source.
     */ 
    public String getSourceTypeString()
    {
       return _sourceTypeString;
    }

   /**
     * Retrieves the value of the given property. This class does not
     * provide any properties.
     *
     * @param propertyName Name of property whose value should be returned.
     * @return  Value of the property whose name is given.
     */
    public Object getProperty(String propertyName)
    {
        return null;
    }
   
   public int getDefinitionType()
   {
      return TYPE_ATTRIBUTE;
   }
}
