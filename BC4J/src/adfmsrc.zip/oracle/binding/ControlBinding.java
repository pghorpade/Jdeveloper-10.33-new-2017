package oracle.binding;
import java.util.Map;

/**
 * Base interface for all bindings that allow binding a View component
 * to the data accessed via a datacontrol.
 */
public interface ControlBinding
{
    /**
     * Releases this ControlBinding. This method is called when the view component has
     * finished using this ControlBinding.
     *
     * @param flags specifies what references should be released. See DataControl for
     *              valid values.
     *
     * @see DataControl#REL_ALL_REFS
     * @see DataControl#REL_DATA_REFS
     * @see DataControl#REL_VIEW_REFS
     * @see DataControl#REL_WEAK_DATA_REFS
     */
    public void release(int flags);

    /**
     * Adds a listener that should be notified when the associated attribute value changes.
     *
     * @param listener The listener object that needs be notified.
     */
    public void setListener(UpdateListener listener);

    /**
     * Get a unique path to this instance of the control binding inside it's 
     * 'outermost' container that is referred in the BindingContext. This string
     * allows the control binding to extract it's data or action out of the 
     * postMap provided in resolvePath(). Both these apis are useful in web
     * style clients and may not have much role to play in interactive clients
     * like Swing.
     */
    public String getPath();

    /**
     * Given a map of name/value pairs, use this binding's path to find an entry
     * in this map. If found, return true so that controller logic may use that
     * information to update binding's data if changed or otherwise.
     */
    public boolean resolvePath(Map postMap);

    /**
     * Return name that identifies this binding uniquely in it's container.
     */
    public String getName();
}
