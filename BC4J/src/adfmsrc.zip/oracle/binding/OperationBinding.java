package oracle.binding;

import java.util.List;
import java.util.Map;

/**
 * A ControlBinding that binds an datacontrol action, including navigational
 * actions such as "Next" and "Prev", or other actions such as "Commit" and
 * "Rollback", to a view component.
 * <br>
 * This interface is implemented by the data binding framework, and is made available
 * to the View components through the binding container. 
 */
public interface OperationBinding extends ControlBinding
{
    /**
     * Whether the action binding is enabled or disabled.
     * @return True if the action is currently enabled. False otherwise.
     */
    public boolean isOperationEnabled();

    /**
     * Executes this OperationBinding, for example, as a result of a UI button being pressed.
     * This should translate into invoking some operation on the underlying data control.
     * If there are exceptions within the invoke operation, these exceptions should be
     * accessible via getErrors().
     * @return the result of the operation (null if the operation has no return type (void). 
     */
    public Object execute();

    /**
     * Returns a list of errors that were raised during the last invoke operation
     * call.
     *
     * @return A list of Throwable that were raised during setInputValue(). It
     *         returns null if there is no error occurred.
     *
     * @see #execute()
     */
    public List getErrors();

    /**
     * Returns a description of the operation to invoke. If this operation is a built in operation,
     * this method may return null or no MethodInfo.
     */
    OperationInfo getOperationInfo();

    /**
     * Retuns a map of name-value pairs of arguments and argument values to be passed
     * to the bound operation.
     */
    Map getParamsMap();

    /**
     * Returns the result of invoking the operation bound by this binding (if the method
     * has been already invoked. This method may not force the method invocation.)
     * This method may return null in case the method has not been invoked.
     */
    public Object getResult();


}
