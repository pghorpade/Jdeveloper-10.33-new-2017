package oracle.binding;


/**
 * This interface is implemented by data controls that needs to have each request
 * demarcated by beginRequest/endRequest pair, so that request level initialization
 * and cleanup processing is possible.
 */
public interface ManagedDataControl extends DataControl
{
   /**
    * Invoked in some contexts to signal the beginning of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the Binding Facilities before
    * control is forwarded to the first <tt>Servlet</tt> defined by the request.
    * <p>
    * Datacontrols may implement this method to perform request level
    * initialization.
    * <p>
    * This method is to be called only once per request. For example, in
    * web applications,
    * page forwards should not result in multiple invocations of this method.
    * <p>
    * @param requestCtx a HashMap representing request context.
    */
   public void beginRequest(java.util.HashMap requestCtx);

   /**
    * Invoked in some contexts to signal the end of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the Binding Facilities after
    * control is returned from the last <tt>Servlet</tt> defined by the request
    * page flow.
    * <p>
    * Datacontrols may implement this method to perform request level
    * cleanup.
    * <p>
    * This method is to be called only once per request. For example, in
    * web applications,
    * page forwards should not result in multiple invocations of this method.
    * <p>
    * @param requestCtx a HashMap representing request context.
    */
   public void endRequest(java.util.HashMap requestCtx);

   /**
    * Resets the DataControl.  DataControl implementation can reset
    * any model session state that maay have been managed by this data control
    * in this method.
    * <p>
    * For example, an EJB DataControl provider may extend resetState to close the DataControl
    * EJB SessionBean
    * <p>
    * Please note that resetState may not occur immediately.  If beginRequest
    * has been invoked on the DataControl then resetState processing will be
    * deferred until endRequest processing.
    *
    * @return true if resetState was processed immediately.  false if resetState
    *    was deferred to endRequest processing.
    */
   public boolean resetState();
}
