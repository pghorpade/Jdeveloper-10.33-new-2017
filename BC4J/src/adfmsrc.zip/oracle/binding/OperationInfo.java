/*
 * @(#)OperationInfo.java
 *
 * Copyright 2003-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.binding;

/**
 * Represents information about an operation that a DataControl implementation should
 * perform when its invokeAction method is called.
 * @see OperationBinding
 * @see DataControl#invokeAction
 */
public interface OperationInfo
{
   /**
    * An El-expression that identifies the object on which an operation has to be invoked.
    * This expression should be relative to the BindingContext for this application instance.
    */
   String getInstanceName();

   /**
    * Name of the operation to invoke
    */
   String getOperationName();

   /**
    * Returns an expression to the location inside the BindingContext where this method's
    * result should be found.
    */
   String getReturnName();
}
