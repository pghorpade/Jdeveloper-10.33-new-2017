package oracle.binding;

import java.util.Map;
import java.util.List;

/**
 * The BindingContainer contains the Control Bindings for a reusable unit of View technology.
 * For example, each individual Page, Region, or Panel refers to a unique BindingContainer
 * with a set of Control Bindings that refer to the Model elements used by that Page.
 * The BindingContainer interface is implemented by the data binding framework provider.
 */
public interface BindingContainer extends Map
{
   /**
    * Returns the name to identify this instance of the Region
    * within it's container (BindingContext at the top level).
    */
   public String getName();

   /**
    * Releases this ControlBinding. This method is called when the view component has
    * finished using this ControlBinding.
    *
    * @param flags specifies what references should be released. See DataControl for
    *              valid values.
    *
    * @see DataControl#REL_ALL_REFS
    * @see DataControl#REL_DATA_REFS
    * @see DataControl#REL_VIEW_REFS
    * @see DataControl#REL_WEAK_DATA_REFS
    */
   public void release(int flags);

   /**
    * Refreshes the DataControl by iteratively re-evaluating the executable
    * bindings. This method is called by the Controller to initialize
    * and perpare the Bindings.
    *
    * This method can be called anytime.  If the bindings have already been
    * evaluated, and no state has changed, they should not re-execute.
    */
   public void refresh();

   /**
    * Returns a control binding with the given name. Returns null
    * if name is not found.
    *
    * @param name
    * @return ControlBinding that matches the given name
    */
   public ControlBinding getControlBinding(String name);

   /**
    * Returns an operation binding with the given name. Returns null
    * if name is not found. This is a typed accessor that can
    * be used instead of getControlBinding() to get to an action
    * binding in this region.
    *
    * @param name
    * @return ControlBinding that matches the given name
    */
   public OperationBinding getOperationBinding(String name);

   /**
    * Return a list of all control bindings in this RegionBinding.
    */
   public List getControlBindings();

   /**
    * Return a list of all AttributeBinding and AttributesBinding in this RegionBinding.
    */
   public List getAttributeBindings();

   /**
    * Return a list of all Action bindings in this RegionBinding.
    */
   public List getOperationBindings();


   /**
    * Calls DataControl validate() for each data control that has a collection
    * to which an iterator binding in this container or it's containeeds are bound to.
    */
   public void validate();


   /**
    * Returns true if token validation is enabled for this RegionBinding.
    * A token can be used to identify the current state of the Bindings.
    *
    * <br>For example, a token can be use in a web application to verify that the
    * bindings are in the same state as the token implies, and only then are values
    * updated. This also avoids multiple updates due to continuous button
    * clicks that users tend to do in a web application.
    *
    * @return true if token validation is enabled for this RegionBinding, false otherwise.
    */
   public boolean isTokenValidationEnabled();

   /**
    * Validates that this RegionBindings is in the same state as represented by the given string token.
    *
    * @param sState State that this RegionBinding should be in.
    */
   public void validateToken(String sState);

   /**
    * Returns the state token.
    * @return String The state token representing the current state of this RegionBinding.
    */
   public String getStateToken();
}
