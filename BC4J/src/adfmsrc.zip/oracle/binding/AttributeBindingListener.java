package oracle.binding;

/**
 * This Listener will be notified that the associated attribute
 * has been updated and hence the renderer needs to re-render
 * the attribute value.
 */
public interface AttributeBindingListener extends UpdateListener
{
}

