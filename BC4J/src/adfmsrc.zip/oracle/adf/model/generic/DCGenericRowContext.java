package oracle.adf.model.generic;

import oracle.jbo.Row;
import oracle.jbo.StructureDef;
import oracle.jbo.RowSetIterator;


public class DCGenericRowContext extends DCRowContext
{
   
   private Object mMasterRowDataProvider;

    protected DCGenericRowContext(Row data, RowSetIterator iter, StructureDef def, Object masterRowDataProvider)
   {
      super (data, iter, def);
      mMasterRowDataProvider = masterRowDataProvider;
   }

   protected DCGenericRowContext(RowSetIterator iter, Object masterRowDataProvider)
   {
      super (null, iter, ((DCRowSetIteratorImpl)iter).getStructureDef());
      mMasterRowDataProvider = masterRowDataProvider;
   }

   public Object getMasterRowDataProvider()
   {
       return mMasterRowDataProvider;
   }

}
