package oracle.adf.model.generic;

//import oracle.adf.model.StructureInfo;

import oracle.jbo.AttributeList;
import oracle.jbo.Row;
import oracle.jbo.StructureDef;
import oracle.jbo.RowSetIterator;

import java.util.Map;

import oracle.binding.OperationBinding;
import oracle.binding.OperationInfo;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;

public class DCRowContext implements oracle.adf.model.RowContext
{
   protected Row            mRow;
   protected StructureDef   mStructureDef;
   protected RowSetIterator mRSI;
   protected AttributeList  mAL;

   protected DCRowContext (Row row, RowSetIterator iter, StructureDef def)
   {
      mRow = row;
      mRSI = iter;
      mStructureDef = def;
   }

   public DCRowContext (RowSetIterator iter, StructureDef def, AttributeList al)
   {

      mAL = al;
      mRSI = iter;
      mStructureDef = def;
   }

   public AttributeList getAttributeList()
   {
      return mAL;
   }

   public Object getMasterRowDataProvider()
   {
       return null;
   }

   public Object getRowDataProvider()
   {
      return (mRow instanceof RowImpl) ? ((RowImpl)mRow).getDataProvider() : null;
   }

   public Row getRow()
   {
      return mRow;
   }

   public boolean isNullRSI()
   {
      return isNullContainer();
   }
   public boolean isNullContainer()
   {
      if (mRSI instanceof DCRowSetIteratorImpl)
      {
         return (((DCRowSetIteratorImpl)mRSI).getDataProvider() == null);
      }
      return false;
   }

   public StructureDef getStructureDef()
   {
      return mStructureDef;
   }

   public String getRowDataProviderType()
   {
      if (mStructureDef instanceof StructureDefImpl)
      {
         return ((StructureDefImpl)mStructureDef).getBeanClassName();
      }
      return null;
   }

   /*
   public StructureInfo getStructureInfo()
   {
      if (mStructureDef instanceof StructureInfo)
      {
         return (StructureInfo)mStructureDef;
      }
      return null;
   }
   */

   public RowSetIterator getRowSetIterator()
   {
      return mRSI;
   }

   public int getCurrentRowIndex()
   {
      return mRSI.getCurrentRowIndex();
   }

   public Map getBindingContextMap()
   {
      //to be implemented.
      return null;
   }

   public Object getRowDataContainer()
   {
      if (mRSI instanceof DCRowSetIteratorImpl)
      {
         return ((DCRowSetIteratorImpl)mRSI).getDataProvider();
      }
      return mRSI;
   }

   public String getMasterAccessorName()
   {
      if (mRSI instanceof DCRowSetIteratorImpl)
      {
         DCRowSetIteratorImpl dcrsi = ((DCRowSetIteratorImpl)mRSI);
         String name = dcrsi.getAccessorName();
         if (name != null) 
         {
            return name;
         }
         if (dcrsi.getProviderMethodResultName() != null) 
         {
            OperationInfo info = getMasterOperationInfo();
            if (info != null) 
            {
               return info.getOperationName();
            }
         }
      }
      return mRSI.getName();
   }

   public OperationInfo getMasterOperationInfo()
   {
      if (mRSI instanceof DCGenericRowSetIteratorImpl)
      {
         DCGenericRowSetIteratorImpl rsi = (DCGenericRowSetIteratorImpl)mRSI;
         if (rsi.getProviderMethodResultName() != null)
         {
            com.sun.java.util.collections.ArrayList al = rsi.getListenersList();
            if (al != null)
            {
               Object obj;
               for (int i = 0; i < al.size(); i++)
               {
                  obj = al.get(i);
                  if (obj instanceof DCIteratorBinding)
                  {
                     DCIteratorBinding iter = (DCIteratorBinding)obj;
                     String actionName = (String)DCUtil.findSpelObject(iter.getDef(), "actionBindingName");
                     OperationBinding action = (OperationBinding)iter.getBindingContainer().findCtrlBinding(actionName);
                     return action.getOperationInfo();
                  }
               }
            }
         }
      }
      return null;
   }
}
