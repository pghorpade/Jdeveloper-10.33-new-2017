/*
 * @(#)DCRowSetIteratorImpl.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;

import java.util.AbstractList;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeList;
import oracle.jbo.CriteriaAdapter;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.Key;
import oracle.jbo.LocaleContext;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowMatch;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.SortCriteria;
import oracle.jbo.StructureDef;
import oracle.jbo.UpdateEvent;
import oracle.jbo.JboSyncLock;
import oracle.jbo.Variable;
import oracle.jbo.VariableValueManager;
import oracle.jbo.ViewCriteria;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.RowSetHelper;
import oracle.jbo.common.RowSetIteratorHelper;

import oracle.adf.model.binding.DCDataControl;

/**
 *
 *
 * @version INTERNAL
 */
public class DCRowSetIteratorImpl extends RowSetHelper implements RowSetIterator
{

   ViewCriteria mVC;
   RowMatch mRowMatch;

   protected DCDataControl mApp;
   protected List    dataRows = new ArrayList();
   protected List    orgDataRows = null;

   private String         mProviderMethodResultLoc;
   private int            mProviderMethodResultUseCount = 0;
   protected Object       mProvider;
   protected Iterator     mProviderIter;
   protected StructureDef mStructureDef;
   protected String       mAccessorName;

   protected Row        mCurrentRow;

   private boolean      mHasAllRows = false;
   private boolean      mFetchedAllRows = false;

   private int          cursor = -1;  // absolute index;

   private int          rangeSize = -1;
   private int          rangeStart = 0;
   private int          hasNext;
   //private int          hasPrevious;
   //private Row          mPrevCurrentRow;

   private int          mCurrentRowSlot = SLOT_BEFORE_FIRST;

   private boolean      mValidationFlag;

   private boolean      mExecuted = false;

   private JboSyncLock  mSyncLock = null;
   
   private boolean      mRebuilt = true;

   static AttributeDef[] mStaticRowNumKeyDef = null;

   private static Iterator NULL_COLL_ITERATOR = (new ArrayList(0)).iterator();
   private SortCriteria[] mSC;

   public static final int REQ_FIRST               = oracle.jbo.common.SvcMsgRequest.REQ_FIRST;
   public static final int REQ_PREVIOUS            = oracle.jbo.common.SvcMsgRequest.REQ_PREVIOUS;
   public static final int REQ_NEXT                = oracle.jbo.common.SvcMsgRequest.REQ_NEXT;
   public static final int REQ_LAST                = oracle.jbo.common.SvcMsgRequest.REQ_LAST;


   protected DCRowSetIteratorImpl(DCDataControl dc, Collection coll, String name)
   {
      mApp = dc;
      mProvider = coll;
      mProviderIter = coll.iterator();
      mExecuted = true;
      init(name);
   }

   protected DCRowSetIteratorImpl(DCDataControl dc, Iterator iter, String name)
   {
      mApp = dc;
      mProvider = iter;
      mProviderIter = iter;
      mExecuted = true;
      init(name);
   }

   protected DCRowSetIteratorImpl(DCDataControl dc, Object data, String name)
   {
      mApp = dc;
      mProvider = data;
      if ((mExecuted = (data != null))) 
      {
         buildProviderIterator(data);
      }
      init(name);
   }

   public DCRowSetIteratorImpl(DCDataControl dc, Object data, String name, StructureDef def)
   {
      mApp = dc;
      mProvider = data;
      mProviderIter = null;
      if ((mExecuted = (data != null))) 
      {
         buildProviderIterator(data);
      }

      init(name);
      mStructureDef = def;
   }

   public final Object getSyncLock()
   {
      if (mSyncLock == null)
      {
         mSyncLock = new JboSyncLock();
      }

      return mSyncLock;
   }

   public String getName()
   {
      return mName;
   }

   private final void init(String name)
   {
      synchronized(getSyncLock())
      {
         resetCrack();
         setName(name);
      }
   }

   protected DCDataControl getDataControl()
   {
      return mApp;
   }

   /**
    * Creates a new Iterator over the dataSource (if the datasource
    * itself is not an Iterator) and resets the currency to the given
    * index.
    */
   public void rebuildIteratorUpto(int index)
   {
      //buildProviderIterator();
      //syncIterator(index);
      restoreCurrency(true);
   }

   public final void setProviderMethodResultName(String name)
   {
      mProviderMethodResultLoc = name;
   }

   public final String getProviderMethodResultName()
   {
      return mProviderMethodResultLoc;
   }

   public final void setProviderMethodResultUseCount(int count)
   {
      mProviderMethodResultUseCount = count;
   }

   public final int getProviderMethodResultUseCount()
   {
      return mProviderMethodResultUseCount;
   }

   public final void setAccessorName(String accName)
   {
      mAccessorName = accName;
   }

   public final String getAccessorName()
   {
      return mAccessorName;
   }

   protected int syncIterator (int index)
   {
      getRowAtAbsoluteIndex(index);
      int size = dataRows.size();
      if (index < size && index > -1 && size > 0)
      {
         cursor = index;
         hasNext = (index != size-1) ? 1 : -1;
      }
      else
      {
         if (size <= 0)
         {
            cursor = -1;
         }
         return -1;
      }

      Row oldRow = mCurrentRow;
      mCurrentRow = (Row)dataRows.get(cursor);
      if (index > 0)
      {
         //hasPrevious = 1;
      }
      if (mCurrentRow != null)
      {
         mCurrentRowSlot = SLOT_VALID;
      }
      else
      {
         //what should be done here? we do not have slot_invalid;
         mCurrentRowSlot = SLOT_BEFORE_FIRST;
      }
      if (mCurrentRow != oldRow)
      {
         this.notifyNavigationEvent(oldRow, mCurrentRow);
      }
      return cursor;
   }
   /**
     * If clz object represents a primitive type array, then the
     * name returned is the name determined by the following table.
     * The encoding of element type names
     * is as follows:
     * <blockquote><pre>
     * B            byte
     * C            char
     * D            double
     * F            float
     * I            int
     * J            long
     * L<i>classname;</i>  class or interface
     * S            short
     * Z            boolean
     * V	    void
     * </pre></blockquote>
    */
   static Iterator getIteratorForArray(Object data, Class clz)
   {
      ArrayList al = null;
      try
      {
         Object[] arr = (Object[])data;
         al = new ArrayList(arr.length);
         for (int i = 0; i < arr.length; i++)
         {
            al.add(arr[i]); //do we need type conversion here.
         }
         return al.iterator();
      }
      catch (ClassCastException cce)
      {
         //must be a primitive type array.
      }
      String className = clz.getName();
      if (className.startsWith("[I"))
      {
         int[] arr = (int[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Integer(arr[i]));
         }
      }
      else if (className.startsWith("[Z"))
      {
         boolean[] arr = (boolean[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Boolean(arr[i]));
         }
      }
      else if (className.startsWith("[B"))
      {
         byte[] arr = (byte[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Byte(arr[i]));
         }
      }
      else if (className.startsWith("[D"))
      {
         double[] arr = (double[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Double(arr[i]));
         }
      }
      else if (className.startsWith("[J"))
      {
         long[] arr = (long[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Long(arr[i]));
         }
      }
      else if (className.startsWith("[S"))
      {
         short[] arr = (short[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Short(arr[i]));
         }
      }
      else if (className.startsWith("[F"))
      {
         float[] arr = (float[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Float(arr[i]));
         }
      }
      else if (className.startsWith("[C"))
      {
         char[] arr = (char[])data;
         al = new ArrayList(arr.length);
         for(int i = 0; i < arr.length; i++)
         {
            al.add(new Character(arr[i]));
         }
      }
      else
      {
         throw new UnsupportedOperationException("Invalid primitive type Array");
      }
      return al.iterator();
   }


   void fetchDataSource()
   {
      // this may seem redundant since the base fetchProvider impl just returns
      // mProvider.  However, DCGenericRowSetIteratorImpl is overriding
      // fetchProvider with logic to either get a bean property (detail RS)
      // or to query the DC for the provider collection.
      mRebuilt = true;

      //clean dataRows as rows might be inserted into this collection
      //via insertRow. We are going for a fresh collection from the
      //source, dataRows should match that.
      clearCurrentData();


      mProvider = fetchProvider();

      buildProviderIterator(mProvider);
   }

   protected Object fetchProvider()
   {
      // returns the existing provider.  subclassing RSIs may return
      // a new provider which was fetched using the DC or an accessor.
      if (mProvider == null && !mHasAllRows && mApp != null)
      {
         mProvider = mApp.getMethodResults().get(getProviderMethodResultName());
      }
      return mProvider;
   }

   private void buildProviderIterator(Object data)
   {
      // created for bug 3088857.  The subclass DCGenericRowSetIteratorImpl
      // already overrides fetchDataSource to lookup the datasource data.
      // this logic should not repeated by the fetchDataSource implementation
      // above.  buildProviderIterator is used after the data has been
      // retrieved.
      Iterator dataIter = null;
      if (data instanceof Iterator)
      {
         dataIter = (Iterator)data;
      }
      else
      {
         if (data instanceof Collection)
         {
            dataIter = ((Collection)data).iterator();
            if (useListAdapter() && (data instanceof List))
            {
              // if the data is a List, then we don't need to read it through
              // an iterator; instead we can directly access its contents. see
              // bug 3150891:

              dataRows = new MyListAdapter((List) data);
              mHasAllRows = true;
              //this is where mFetchedAllRows and mHasAllRows will be different
              //till we read all rows from this list.
            }
         }
         else if (data instanceof Enumeration)
         {
            dataIter = new EnumerationIterator((Enumeration)data);
         }
         else if (data != null)
         {
            Class clz = data.getClass();
            if (clz.isArray())
            {
               dataIter = getIteratorForArray(data, clz);
            }
            else
            {
               ArrayList al = new ArrayList(3);
               al.add(data);
               dataIter = al.iterator();
            }
         }
         else
         {
            Diagnostic.println("Null data returned for an accessor. Assuming empty iterator");
            dataIter = NULL_COLL_ITERATOR;
         }
      }
      mProviderIter = dataIter;

      mExecuted = true;
      resetCrack();
      notifyRangeRefreshed(0);
   }

   void bringRows(int index)
   {
      if (!mHasAllRows)
      {
         if (mProviderIter == null)
         {
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("DCRowSetIteratorImpl:"+getName()+" fetch data source.");
            }
            fetchDataSource();

            if (mHasAllRows) 
            {
               //in case this is a detail, master fetch will force 
               //this detail to be fetched by now.
               return;
            }
         }
         int count = dataRows.size();

         boolean hasVC = (mRowMatch != null);

         Row row;
         RowMatch rowMatch = mRowMatch;

         //if sortcriteria set, bring all rows.
         if (mSC != null) 
         {
            index = -1;
         }

         if (Diagnostic.isOn() && index == -1 && rangeSize != -1) 
         {
            Diagnostic.println("DCRowSetIteratorImpl "+getName()+" fetching all rows from dataProvider");
         }

         while (mProviderIter.hasNext() && (count <= index || index == -1))
         {
            row = internalCreateRowInstanceFor(mProviderIter.next());
            if (rowMatch == null || rowMatch.rowQualifies(row))
            {
               dataRows.add(row);
               ++count;
            }
         }
         
         //real fetchedAllRows.
         mHasAllRows = !(mProviderIter.hasNext());
         mFetchedAllRows = mHasAllRows;

         if (mSC != null) 
         {
            sortRows(mSC);
         }

         if (Diagnostic.isOn() && mHasAllRows) 
         {
            Diagnostic.println("DCRowSetIteratorImpl:"+getName()+" fetched all rows.");
         }

      }
   }


   private final void resetCrack()
   {
      cursor      = -1;
      hasNext     = -1;
      //hasPrevious = -1;
      mCurrentRow = null;
      //mPrevCurrentRow = null;

      mCurrentRowSlot = SLOT_BEFORE_FIRST;
   }

   final void setDataRows(ArrayList rowArr)
   {
      resetCrack();
      dataRows = rowArr;
      orgDataRows = null;

      notifyRangeRefreshed(0);
   }

   void clearClientSide()
   {
      clearCurrentData();
   }
   /**
    * for internal framework use only.
    * Cleans the current data and rests this iterator. Next call to fetch
    * data will attempt to re-execute the data provider.
    */
   public void clearCurrentData()
   {
     // don't call clear because clear() is not implemented (and cannot be
     // implemented) on ListAdapter
     // dataRows.clear();
     dataRows = new ArrayList();
     orgDataRows = null;

     mProviderIter = null;
     
     mProvider = null;

     mExecuted = false;
     mHasAllRows = false;
     mFetchedAllRows = false; 
     //mCurrentRowSlot = SLOT_BEFORE_FIRST;
     resetCrack();
   }

   boolean isExecuted()
   {
      return mExecuted;
   }
   public void closeRowSetIterator()
   {
      clearClientSide(); // gotoMT
      if (hasManagementListeners() == false)
      {
         return;
      }

      fireMgmtIteratorClosed(new oracle.jbo.RowSetManagementEvent(this,
                                                       oracle.jbo.RowSetManagementEvent.EVENT_TYPE_CLOSED));
   }



   public RowSet getRowSet()
   {
      return null;
   }

   public Object getDataProvider()
   {
      return mProvider;
   }

   public RowSetIterator getRowSetIterator()
   {
      return this;
   }

   public Row next()
   {
      synchronized(getSyncLock())
      {
         int tmpCursor = (mCurrentRowSlot == SLOT_VALID || mCurrentRowSlot == SLOT_BEFORE_FIRST) ? cursor + 1 : cursor;
         syncIterator(tmpCursor);
         scrollRangeTo(tmpCursor);

         return mCurrentRow;
      }
   }

   public Row previous()
   {
      synchronized(getSyncLock())
      {
         int tmpCursor = (mCurrentRowSlot == SLOT_VALID || mCurrentRowSlot == SLOT_BEYOND_LAST)
                        ? cursor - 1
                        : (mCurrentRowSlot == SLOT_DELETED && cursor >= dataRows.size())
                           ? dataRows.size()-1
                           : cursor;
         syncIterator(tmpCursor);
         scrollRangeTo(tmpCursor);

         return mCurrentRow;
      }
   }


   public Row first()
   {
      synchronized(getSyncLock())
      {
         cursor = 0;
         scrollRangeTo(cursor);

         // JRS 07/14/04 BUG 3747856.  cursor may be reset by
         // scrollRangeTo.  Pass 0 to syncIterator this will force
         // the cursor back to 0.
         syncIterator(0);

         return mCurrentRow;
      }
   }


   public Row last()
   {
      synchronized(getSyncLock())
      {
         int lastIndex = getRowCount() - 1;
         if (mCurrentRowSlot == SLOT_VALID || mCurrentRowSlot == SLOT_BEFORE_FIRST)
         {
            cursor = lastIndex;
         }
         // bug 3003774.  getRowCount() - 1 could be negative.  syncIterator to
         // 0, this should be consistent with the behaviour of first and next
         // when the iterator is empty.
         cursor = syncIterator((cursor < 0 ? 0 : cursor));
         scrollRangeTo(cursor);
         return mCurrentRow;
      }
   }


   public void reset()
   {
      synchronized(getSyncLock())
      {
         resetCrack();
      }
   }

   public boolean hasNext()
   {
      //synchronized(getSyncLock())
      {
         int nextIndex;

         if (mCurrentRowSlot == SLOT_BEFORE_FIRST)
         {
            nextIndex = 0;
         }
         else  if (mCurrentRowSlot == SLOT_BEYOND_LAST)
         {
            return false;
         }
         else
         {
            nextIndex = cursor + 1;
            if (mCurrentRowSlot == SLOT_DELETED)
            {
               nextIndex--;
            }
         }
         if (nextIndex < dataRows.size())
         {
            return true;
         }
         else if (mHasAllRows) 
         {
            //if I've fetched all rows, there is no more next row.
            return false;
         }
         else
         {
            if (hasNext != 0)
            {
               //for the first time, see if there's one row.
               if (mProviderIter == null)
               {
                  //this may lead to fetching all rows
                  //so mProvider may reach the end.
                  fetchDataSource();
               }
               hasNext = (mProviderIter.hasNext()) ? 1 : 0;
               if (hasNext == 0)
               {
                  //reached the end.
                  mHasAllRows = true;
                  mFetchedAllRows = true; 

                  //last row being deleted and hasNext is called to figure
                  //out if there are more rows. Since cursor will be on the
                  //last row and dataRows.size() will be less than cursor,
                  //we do not have any more rows. Return zero in that case.
                  hasNext = (dataRows.size() > nextIndex) ? 1 : 0;
               }
            }
            return (hasNext == 1);
         }
      }
   }


   public boolean hasPrevious()
   {
      //synchronized(getSyncLock())
      {
         if (cursor <= 0)
         {
            if (mCurrentRowSlot == SLOT_BEYOND_LAST)
            {
               return (dataRows.size() > 0);
            }
            else
            {
               return false;
            }
         }
         return true;
      }
   }


   public boolean isRangeAtBottom()
   {
     return (rangeSize > -1)
       ? ((rangeStart+rangeSize) >= dataRows.size() && this.mHasAllRows)
       : true;
   }


   public boolean isRangeAtTop()
   {
     return (getRealRangeStart()==0);
   }


   public int getFetchedRowCount()
   {
      synchronized(getSyncLock())
      {
         return dataRows.size();
      }
   }


   public int getRowCount()
   {
      if (mProvider instanceof Collection && mRowMatch == null) 
      {
         return ((Collection)mProvider).size();
      }
      //incase not all rows are fetched, fetch them as 
      //we need to the set size.
      bringRows(-1);
      return getFetchedRowCount();
   }

   private boolean isIndexValid(int index)
   {
     // check to see is index is too large. We first check against
     // fetchedRowCount since that is fast:
      if (index >= 0)
      {
         if (index >= getFetchedRowCount())
         {
            bringRows(index);
            if (index >= getFetchedRowCount())
            {
               return false;
            }
         }

         return true;
      }
      return false;
   }

   public int setRangeSize(int size)
   {
     if (size != 0) // zero means keep default
     {
        rangeSize = size;
     }
     return rangeSize;
   }


   public int getRangeSize()
   {
     return rangeSize;
   }

   // if range paging is supported then return the current
   // rangeSize. Otherwise, return the number of rows in the fetched data
   // list:
   private int getRealRangeSize()
   {
     return (rangeSize > 0) ? rangeSize : dataRows.size();
   }


   public int getRowCountInRange()
   {
     return getRowsInRange().size();
   }

   // if range paging is supported then return the current
   // rangeStart. Otherwise, return 0:
   private int getRealRangeStart()
   {
     return (rangeSize > 0) ? rangeStart : 0;
   }

   public int getRangeStart()
   {
     return rangeStart;
   }

   public int setRangeStart(int start)
   {
     int oldRangeStart = rangeStart;
     rangeStart = isIndexValid(start) ? start : 0;
     if (oldRangeStart != rangeStart)
     {
       notifyRangeScrolled(oldRangeStart);
     }
     return rangeStart;
   }

   public int getEstimatedRangePageCount()
   {
      return 1;
   }

   public int scrollToRangePage(int pageIndex)
   {
      return 0;
   }

   public int scrollRange(int amount)
   {
     int oldRangeStart = rangeStart;
     setRangeStart(rangeStart + amount);
     int scrollAmount = rangeStart - oldRangeStart;
     return scrollAmount;
   }

   public int scrollRangeTo(Row row, int index)
   {
      //throw new UnsupportedOperationException("DCRowSetIteratorImpl.scrollRangeTo");
      int rangeStartBefore = rangeStart;
      int absoluteIndex = dataRows.indexOf(row);

      if (absoluteIndex < 0)
      {
         throw new oracle.jbo.InvalidParamException("DCRowSetIteratorImpl.scrollRangeTo",
                                         "row",
                                         row.getClass().getName(),
                                         "not in the collection");
      }

      int amtToScroll = absoluteIndex - rangeStartBefore - index;

      return scrollRange(amtToScroll);
   }

   private void scrollRangeTo(int absoluteIndex)
   {
     int rangeSize = getRangeSize();
     if (rangeSize > 0) // bug 3412466
     {
       int pageIndex = absoluteIndex / rangeSize;
       int newStart = pageIndex * rangeSize;
       setRangeStart(newStart);
     }
   }

   private final Row findRowInCache(Key key)
   {
      Row row;
      Key cachedKey;
      if (mCurrentRow != null)
      {
         cachedKey = mCurrentRow.getKey();
         if(cachedKey != null && cachedKey.equals(key))
         {
            return mCurrentRow;
         }
      }

      for (Iterator e = dataRows.iterator(); e.hasNext(); )
      {
         row = (Row) e.next();
         cachedKey = row.getKey();
         if (cachedKey != null && cachedKey.equals(key))
         {
            return row;
         }
      }

      return null;
   }
   public Row getRow(Key key)
   {
      synchronized(getSyncLock())
      {
         Row r = findRowInCache(key);
         if (r == null)
         {
            //look for row in iterator.
            if (mProviderIter == null)
            {
               fetchDataSource();
            }

            if (mProviderIter != null)
            {
               Key cachedKey;
               Row row;
               RowMatch rowMatch = mRowMatch;
               while (mProviderIter.hasNext())
               {
                  row = internalCreateRowInstanceFor(mProviderIter.next());
                  if (rowMatch == null || rowMatch.rowQualifies(row))
                  {
                     dataRows.add(row);
                     cachedKey = row.getKey();
                     if (cachedKey != null && cachedKey.equals(key))
                     {
                        return row;
                     }
                  }
               }
            }
         }
         return r;
      }
   }
   String toUpperFirst(String str)
   {
      StringBuffer buf = new StringBuffer(str);
      return (new StringBuffer(str.length())
                               .append(Character.toUpperCase(buf.charAt(0)))
                               .append(buf.substring(1))).toString();
   }

   public StructureDef getStructureDef()
   {
      return mStructureDef;
   }

   public Row getRowAtRangeIndex(int rangeIndex)
   {
     int index = toAbsoluteIndex(rangeIndex);
     return getRowAtAbsoluteIndex(index);
   }

   private Row getRowAtAbsoluteIndex(int index)
   {
      if (mProviderIter == null)
      {
         fetchDataSource();
      }
      int size = dataRows.size();
      //hasNext should return false incase when dataRows.size is really zero.
      //if(size >= 0)
      if (mProviderIter != null)
      {
         /*
         while (size <= index)
         {
            if (mProviderIter.hasNext())
            {
               dataRows.add(internalCreateRowInstanceFor(mProviderIter.next()));
               size++;
            }
            else
            {
               //reached the end.
               mHasAllRows = true;
               return null;
            }
         }
         */
         bringRows(index);
         if (index < size && index >= 0)
         {
            return (Row)dataRows.get(index);
         }
      }
      return null;
   }


   public Row getCurrentRow()
   {
      return mCurrentRow;
   }


   public int getCurrentRowIndex()
   {
      return cursor;
   }


   public int getCurrentRowSlot()
   {
      return mCurrentRowSlot;
   }


   public int getIterMode()
   {
      return 0;
   }

   public void setIterMode(int mode)
   {
   }

   public void setRowValidation(boolean flag)
   {
      mValidationFlag = flag;
   }

   public boolean isRowValidation()
   {
      return mValidationFlag;
   }

   protected boolean containsRow (Row row)
   {
      return (getRow(row.getKey()) != null);
   }

   protected void setAttributeValue(RowImpl row, String accName, Object value)
   {
      if (row.isProviderMap()) 
      {
         ((java.util.Map)row.getDataProvider()).put(accName, value);
      }
      else
      {
         BeanUtils.setProperty(row.getDataProvider(), accName, value);
      }
   }

   void sortRows(SortCriteria[] scs)
   {
      if (isSortable()) 
      {

         Row oldRow = mCurrentRow;
         if (scs == null || scs.length == 0 ) 
         {
            mSC = null;
            dataRows = (orgDataRows != null) ? orgDataRows : dataRows;
            orgDataRows = null;
         }
         else if (dataRows != null)
         {
            bringRows(-1);
            Row rows[] = (Row[])dataRows.toArray(new Row[dataRows.size()]);
            java.util.Arrays.sort(rows, new oracle.jbo.RowComparator(scs));
            mSC = scs;

            if (orgDataRows == null) 
            {
               orgDataRows = dataRows;
            }
            dataRows = new ArrayList(rows.length);
            for (int i = 0; i < rows.length; i++) 
            {
               dataRows.add(rows[i]);
            }
         }
         
         resetCrack();
         notifyNavigationEvent(oldRow, mCurrentRow);

         notifyRangeRefreshed(0);
      }
   }

   public boolean setCurrentRow(Row row)
   {
      synchronized(getSyncLock())
      {
         // First make sure this row is part of this set
         if (!containsRow(row))
         {
            return false;
         }
         // Are we already there?
         if (mCurrentRow != null && mCurrentRow == row)
         {
            return true;
         }
         int index = dataRows.indexOf(row);
         if (index < 0)
         {
            bringRows(-1);
            index = dataRows.indexOf(row);
         }
         return setCurrentRowAtAbsoluteIndex(index);
      }
   }


   public boolean setCurrentRowAtRangeIndex(int rangeIndex)
   {
      int index = toAbsoluteIndex(rangeIndex);
      return setCurrentRowAtAbsoluteIndex(index);
   }

   private boolean setCurrentRowAtAbsoluteIndex(int index)
   {
     synchronized(getSyncLock())
     {
       if (!isIndexValid(index))
       {
         return false;
       }
       return syncIterator(index) >= 0;
     }
   }

   public Row createRow()
   {
      return createAndInitRow(null);
   }


   public Row createAndInitRow(AttributeList nvp)
   {
      throw new UnsupportedOperationException("createAndInitRow()");
   }
   public void insertRow(Row row)
   {
      // JRS 3310544 Added the containsRow check.  see guava.toplink.jb04
      if (!containsRow(row))
      {
         insertRowAtAbsoluteIndex(cursor, row);
      }
   }


   public void insertRowAtRangeIndex(int rangeIndex, Row row)
   {
      // JRS 3310544 Added the containsRow check.  see guava.toplink.jb04
      if (!containsRow(row))
      {
         int index = toAbsoluteIndex(rangeIndex);
         insertRowAtAbsoluteIndex(index, row);
      }
   }
   private void insertRowAtAbsoluteIndex(int index, Row row)
   {
      if (index >= getFetchedRowCount())
      {
         bringRows(index);
      }

      boolean append = false;
      if (index >= getFetchedRowCount())
      {
         append = true;
      }
      else if (index < 0 )
      {
         append = true;
      }

      int size = dataRows.size();
      if (append)
      {
         dataRows.add(row);
         index = size;
      }
      else
      {
         dataRows.add(index, row);
      }
      if (orgDataRows != null && orgDataRows != dataRows) 
      {
         //add to the end of original dataset.
         orgDataRows.add(row);
      }

      resetIndexBasedKeys(index);
      notifyRowInserted(row, index, size);
      syncIterator(index);

   }

   void resetIndexBasedKeys(int index)
   {
      if (getStructureDef() instanceof StructureDefImpl)
      {
         ArrayList al = ((StructureDefImpl)getStructureDef()).getKeyAttrsList();
         int size = al.size();
         if (size == 0)
         {
            size = dataRows.size();
            for (int i = index; i < size; i++ )
            {
               ((RowImpl)dataRows.get(i)).resetKey();
            }
         }
      }
      else
      {
         // JRS 3/9/2004 bug 3458167.  Non-structured rows may also have index
         // based keys.  In fact, I think it is more likely for an
         // unstructured row to have an index based key than it is for
         // a structured row.
         int size = dataRows.size();
         for (int i = index; i < size; i++ )
         {
            ((RowImpl)dataRows.get(i)).resetKey();
         }
      }
   }

   protected Object getMasterRowDataProvider()
   {
      return null;
   }

   void doRemoveRow(Row row, boolean isRemoveFromTable)
   {
      if (row != null)
      {
         int index = dataRows.indexOf(row);
         boolean removeCurrentRow = cursor == index;

         mRebuilt = false;
         boolean rsltCode = (isRemoveFromTable) ? mApp.removeRowData(new DCGenericRowContext(row, this, mStructureDef, getMasterRowDataProvider())) :
                                                  mApp.removeRowDataFromCollection(new DCGenericRowContext(row, this, mStructureDef, getMasterRowDataProvider()));

         
         if (rsltCode && !mRebuilt)
         {
            mRebuilt = true;
            //mPrevCurrentRow = mCurrentRow;
            if (removeCurrentRow) 
            {
               mCurrentRow = null;
               mCurrentRowSlot = SLOT_DELETED;
            }

            int size = dataRows.size();
            if (!rsltCode)
            {
               if (index < dataRows.size())
               {
                  dataRows.remove(index);
                  if (orgDataRows != null && orgDataRows != dataRows) 
                  {
                     orgDataRows.remove(((RowImpl)row).getDataProvider());
                  }
               }
               resetIndexBasedKeys(index);
            }
            else
            {
               //since mApp.removeRowData may have rebuilt the iterator (provider)
               //reset the cursor to the index being removed, so that notifyRowDeleted
               //when it does hasNext(), it returs true for focus to go on next row.
               if (index == size)
               {
                  cursor = index;
               }
               else
               {
                  // modified by alai on 2/23/05
                  // if index is 0, set cursor to 0 and not -1
                  if (index == 0)
                  {
                     cursor = 0;
                  }
                  else
                  {
                     cursor = index-1;
                  }
                  resetIndexBasedKeys(index);
               }

            }
            notifyRowDeleted(row, index, size, --size, isRemoveFromTable);
         }
      }
   }

   public void removeCurrentRow()
   {
      doRemoveRow(getCurrentRow(), true /*isRemoveFromTable*/);
   }

   public void removeCurrentRowFromCollection()
   {
      doRemoveRow(getCurrentRow(), false /*isRemoveFromTable*/);
   }

   public Row removeCurrentRowAndRetain()
   {
      Row row = getCurrentRow();

      removeCurrentRowFromCollection();

      return row;
   }

   public Class getMessageBundleClass()
   {
      if (mStructureDef instanceof StructureDefImpl)
      {
         return ((StructureDefImpl)mStructureDef).getMessageBundleClass();
      }
      else
      {
         return null;
      }
   }

   public int getRangeIndexOf(Row row)
   {
      synchronized(getSyncLock())
      {
         if (row == null)
         {
            return -1;
         }
         int absoluteIndex = dataRows.indexOf(row);
         if (rangeSize == -1)
         {
            return absoluteIndex;
         }

         return absoluteIndex - rangeStart;
      }
   }

   public Enumeration enumerateRowsInRange()
   {
      synchronized(getSyncLock())
      {
         return new Enumeration()
         {
            Iterator al = getRowsInRange().iterator();
            public boolean hasMoreElements()
            {
               return al.hasNext();
            }
            public Object nextElement()
            {
               synchronized(getSyncLock())
               {
                  return al.next();
               }
            }
         };
      }
   }


   public Row[] getFilteredRows(String attrName, Object attrValue)
   {
      return getFilteredRowsInRange(attrName, attrValue);
   }

   public Row[] getFilteredRowsInRange(String attrName, Object attrValue)
   {
      return RowSetIteratorHelper.getFilteredRowsInRange(this, attrName, attrValue);
   }

   public Row[] getAllRowsInRange()
   {
      List rangeRows = getRowsInRange();
      return (Row[])rangeRows.toArray(new Row[rangeRows.size()]);
   }

   private List getRowsInRange()
   {
     if (rangeSize < 1)
     {
        bringRows(-1);
        return dataRows;
     }

     /*
     int sz = dataRows.size();
     if (rangeStart >= sz)
     {
       rangeStart = sz - rangeSize;
     }

     if (rangeStart < 0)
     {
       rangeStart = 0;
     }

     int rangeEnd = rangeStart + rangeSize;
     if (rangeEnd > sz)
     {
       rangeEnd = sz;
     }
     */
     if (rangeStart < 0)
     {
        rangeStart = 0;
     }
     int rangeEnd = rangeStart + rangeSize;

     bringRows(rangeEnd);

     if (rangeEnd > dataRows.size())
     {
        rangeEnd = dataRows.size();
     }

     return dataRows.subList(rangeStart, rangeEnd);
   }

  /**
   * Let a subclass decide if the ListAdapter should be used to avoid
   * creating an iterator over the original list. This will allow
   * bean subclasses that only use java.util.List to override and get
   * a synchronized list behavior where they do not have to notify the
   * bindings of list mutations. In this case the datacontrol will also
   * have to consider issue with default Action binding behavior of insert
   * and remove rows (if they enable it via the datacontrol).
   *
   * (Advanced: internal method - use with caution as this is not tested/
   * advertized as a supported feature.).
   */
   protected boolean useListAdapter()
   {
     //return (mApp != null) && (mApp.getClass() == DCGenericDataControl.class);
      return false;
   }

   // converts a rangeIndex into an absolute index
   private int toAbsoluteIndex(int rangeIndex)
   {
     int index = rangeIndex + getRealRangeStart();
     return index;
   }

   // converts an absoluteIndex into a rangeIndex
   /*
   private int toRangeIndex(int absoluteIndex)
   {
      if (rangeSize == -1)
      {
         return absoluteIndex;
      }
      int rangeIndex = absoluteIndex - rangeStart;
      if ((rangeIndex < 0) || (rangeIndex > rangeSize))
      {
         return -1; // index is not in range
      }
      return rangeIndex;
   }
   */
   public Row[] getNextRangeSet()
   {
     return getRangeSet(isRangeAtBottom(), true /*scrollDown*/);
   }
   public Row[] getPreviousRangeSet()
   {
     return getRangeSet(isRangeAtTop(), false /*scrollDown*/);
   }
   private Row[] getRangeSet(boolean noMoreRows, boolean scrollDown)
   {
     if (noMoreRows)
     {
       return new Row[0];
     }

     int amount = getRealRangeSize();
     if (!scrollDown)
     {
       amount = -amount;
     }

     scrollRange(amount);
     Row[] rows = getAllRowsInRange();
     if (scrollDown) 
     {
        setCurrentRowAtRangeIndex(0);
     }
     else
     {
        setCurrentRowAtRangeIndex(rows.length - 1);
     }
     return rows;
   }

   /**
    * Get all detail row sets.
    * @return An array of detail RowSet objects.
    */
   public RowSet[] getDetailRowSets()
   {
      //hmmm. could we coordinate master detail on the client side?
      return null;
   }


   /**
    * Create a row set for the view link.
    * @return the detail RowSet object.
    */
   public RowSet createDetailRowSet(String rsName, String linkDefName)
   {
      throw new UnsupportedOperationException("createDetailRowSet()");
   }

   public final void notifyRangeRefreshed(int rangeStart)
   {
      Row[] rows = (Row[])dataRows.toArray(new Row[dataRows.size()]);
      fireRangeRefreshed(new RangeRefreshEvent(this, rangeStart, rows.length, rows));
   }


   /*
   final void notifyIteratorReset()
   {
      if (hasManagementListeners() == false)
      {
         return;
      }

      fireMgmtIteratorReset(new RowSetManagementEvent(getExposedObject(),
                                                      RowSetManagementEvent.EVENT_TYPE_RESET));
   }


   final void notifyIteratorClosed()
   {
      if (hasManagementListeners() == false)
      {
         return;
      }

      fireMgmtIteratorClosed(new RowSetManagementEvent(getExposedObject(),
                                                       RowSetManagementEvent.EVENT_TYPE_CLOSED));
   }
   */



   final void notifyRangeScrolled(int rangeStartBefore)
   {
      fireRangeScrolled(new ScrollEvent(this, rangeStartBefore));
   }


   protected void notifyNavigationEvent(Row srcRow, Row dstRow)
   {
      if (hasListeners()) 
      {
         fireNavigationEvent(new NavigationEvent(this, srcRow, dstRow));
      }
   }


   final void notifyRowInserted(Row row, int rowId, int rowCountBefore)
   {
      if (hasListeners()) 
      {
         InsertEvent event = new InsertEvent(this, row, rowId, rowCountBefore,
                                             dataRows.size());
         fireRowInserted(event);
      }
   }

   final void notifyRowDeleted(Row row, int rowId, int rowCountBefore, int rowCountAfter, boolean isRemoveFromTable)
   {
      if (hasListeners()) 
      {
         DeleteEvent event = new DeleteEvent(this, row, rowId, rowCountBefore, rowCountAfter, isRemoveFromTable);

         fireRowDeleted(event);
      }
   }


   final void notifyRowUpdated(Row row, int rowId, int[] attrIndices)
   {
      if (hasListeners()) 
      {
         UpdateEvent event = new UpdateEvent(this, row, rowId, attrIndices);

         fireRowUpdated(event);
      }
   }
   
   AttributeDef[] getRowNumKeyDefArray()
   {
      if (mStaticRowNumKeyDef == null)
      {
         synchronized (NULL_COLL_ITERATOR)
         {
            try
            {

               AttributeDefImpl ad = new AttributeDefImpl(null);

               ad.init("ROWNUM",  //name         
                              null,                 //accessorName
                              -1,                    //index           
                              "java.lang.Integer",                 //attributeType        
                              "java.lang.Integer",                 //accessorType
                              false,                 //isSelected
                              false,                //isQueriable
                              AttributeDef.READONLY,//updateable
                              false,                 //primarykey
                              false,                //mandatory
                              null);                
               mStaticRowNumKeyDef  = new AttributeDefImpl[] {ad};

            }
            catch (Exception e)
            {
               //should not occur.
            }
         }
      }
      return mStaticRowNumKeyDef; 
   }

   public Key createKey (String stringifiedKey)
   {
      StructureDef def = getStructureDef();
      if (def instanceof StructureDefImpl)
      {
         ArrayList al = ((StructureDefImpl)def).getKeyAttrsList();
         try
         {
            if (al.size() > 0) 
            {
               return new Key(stringifiedKey, (AttributeDef[])al.toArray(new AttributeDef[al.size()]));
            }
            else
            {
               //index based key.
               return new Key(stringifiedKey, getRowNumKeyDefArray());
            }
         }
         catch (Exception e)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.printStackTrace(e);
            }
         }
      }
      return null;
   }
   public Key createKey(AttributeList nvp)
   {
      //return rowSet.createKey(nvp);
      return null;
   }

   public Row[] findByKey(Key key, int maxNumOfRows)
   {
      synchronized(getSyncLock())
      {
         Row r = getRow(key);
         if (r != null)
         {
            return new Row[] {r};
         }
         return new Row[0];
      }
   }


   ViewCriteria getViewCriteria()
   {
      return mVC;
   }

   void applyViewCriteria (ViewCriteria vc)
   {
      mVC = vc;
   }

   void executeCriteria(ViewCriteria vc, RowMatch rm)
   {
      applyViewCriteria(vc);
      mRowMatch = rm;
   }  

   protected boolean isSortable()
   {
      return true;
      //return (mFetchedAllRows || this.rangeSize == -1);
   }


   public RowIterator findByViewCriteria(ViewCriteria criteria, int maxNumOfRows, int queryMode)
   {
      DCDataControl dc = getDataControl();
      if (dc instanceof DCGenericDataControl) 
      {
         DCGenericDataControl gendc = (DCGenericDataControl)dc;
         if (!mHasAllRows) 
         {
            bringRows(-1);
         }

         RowMatch rowMatch = gendc.createCriteriaRowMatch(this, criteria);

         ArrayList found = new ArrayList(10);
         int noFetchedRows = getFetchedRowCount();
         int count = 0;
         for (int j = 0; j < noFetchedRows && (maxNumOfRows == -1 || count < maxNumOfRows); j++)
         {
            Row row = getRowAtAbsoluteIndex(j);

            if (rowMatch == null || rowMatch.rowQualifies(row))
            {
               found.add(row);
               ++count;
            }
         }

         return createFilteredRowSetIterator(found); 

      }
      return null;
   }

   /**
    * Create and return an equivalent RowSetIterator with data containing rows
    * from this same RSI filtered via a criteria.
    */
   protected RowSetIterator createFilteredRowSetIterator(Object data)
   {
      return getDataControl().createRowSetIteratorImpl(null, 
                                                   getStructureDef().getFullName(), data,
                                                   null);
   }

   public Row[] findByEntity(int eRowHandle, int maxNumOfRows)
   {
      throw new UnsupportedOperationException("findByEntity()");
   }

   public java.util.Hashtable getProperties()
   {
      return null;
   }

   public boolean isNameGenerated()
   {
      return false;
   }

   void restoreCurrency(boolean fetch)
   {
      int curIdx = cursor;
      if (curIdx > -1)
      {
         resetCrack();
      }
      clearCurrentData();
      if (fetch && (curIdx > -1))
      {
         if (syncIterator(curIdx) == -1)
         {
            //fetch all rows.
            if (dataRows.size() > 0)
            {
               syncIterator(dataRows.size()-1);
            }
         }
      }
   }

   //override to allow DCGeneric data control to access it.
   protected com.sun.java.util.collections.ArrayList getListenersList()
   {
      return super.getListenersList();
   }

   //only place where a row is created.
   protected Row internalCreateRowInstanceFor(Object rowData)
   {
      if (rowData instanceof Row)
      {
         return (Row)rowData;
      }
      if (mStructureDef instanceof StructureDefImpl)
      {
         StructureDefImpl impl = ((StructureDefImpl)mStructureDef);
         if (impl.isElementsScalar(rowData))
         {
            rowData = new ScalarRowMap(impl.getName(), rowData); ;
         }
      }
      return new RowImpl(rowData, this);
   }

   //private ClientVariableValueManager mVariableManager = null;
   public VariableValueManager getVariableManager()
   {
      return null;
   }


   public boolean hasVariables()
   {
      return false;
   }


   public VariableValueManager ensureVariableManager()
   {
      return null;
   }

   class EnumerationIterator implements Iterator
   {
      Enumeration mEnum;
      EnumerationIterator(Enumeration enumx)
      {
         mEnum = enumx;
      }
      public boolean hasNext()
      {
         return mEnum.hasMoreElements();
      }
      public Object next()
      {
         return mEnum.nextElement();
      }
      public void remove()
      {
         throw new UnsupportedOperationException("EnumerationIterator.remove");
      }
   }

   class ScalarRowMap extends AbstractMap
   {
      ArrayList _oneEntryArray = new ArrayList(1);

      ScalarRowMap(String name, Object data)
      {
         _oneEntryArray.add(data);
      }

      public Set entrySet()
      {
         return new AbstractSet()
         {
            public Iterator iterator()
            {
               return _oneEntryArray.iterator();
            }

            public int size()
            {
               return _oneEntryArray.size();
            }

            public boolean removeAll(Collection c)
            {
               throw new java.lang.UnsupportedOperationException("removeAll");
            }
         };
      }

      public Object get(Object key)
      {
         return _oneEntryArray.get(0);
      }
   } //class ScalarRowMap extends AbstractMap

  // this list is not mutable:
  private final class MyListAdapter extends AbstractList
  {
    MyListAdapter(List table)
    {
      _table = table;
    }

    public int size()
    {
      return _table.size();
    }

    public Object get(int index)
    {
      return internalCreateRowInstanceFor(_table.get(index));
    }

    private List _table;
  }
}
