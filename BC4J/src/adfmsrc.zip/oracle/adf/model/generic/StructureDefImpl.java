/*
 * @(#)StructureDef.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import oracle.binding.meta.AccessorDefinition;
import oracle.binding.meta.AttributeDefinition;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.binding.DCDataControl;

import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.StructureDef;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.rules.JboValidatorInterface;
import oracle.jbo.rules.ValidationManager;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;

import org.w3c.dom.Node;

/**
 * Imlemented by classes that access a View Object's or Entity Object's metadata.
 * @see oracle.jbo.ApplicationModule
 * @see oracle.jbo.RowSet
 * @since JDeveloper 3.0
 */
public class StructureDefImpl extends DefinitionObject implements StructureDef, ValidationManager
{
   protected AttributeDefImpl mAttrs[];
   protected StructureDefImpl mAccessors[];
   protected StructureDefImpl mScalarAccessors[];
   protected String mName;
   protected String mMsgClassName;
   protected String mBeanClassName;
   protected Class mBeanClass;
   protected Class mMsgClass;
   protected boolean mElementsScalar = false;
   private boolean  _isCollection = true;  
   protected boolean loaded = false;
   private ArrayList mValidators;
   private String    mFieldType;
   private Object mFirstRowData;
   private String mArrayElementType;
   private StructureDefImpl mDefStr;
  
  
   private static final String JAVA_OBJECT_CLZNAME = Object.class.getName();
   public static final String PName_Attribute         = "Attribute";     //NONLS
   public static final String PName_AccessorAttribute = "AccessorAttribute";     //NONLS
   public static final String PName_FieldName         = "SourceName";     //NONLS
   public static final String PName_FieldType         = "SourceType";     //NONLS
   public static final String PName_BeanClass         = "BeanClass";      //NONLS
   public static final String PName_MsgBundleClass    = "MsgBundleClass"; //NONLS
   public static final String PName_Master            = "Master";         //NONLS
   public static final String PName_MasterAccName     = "MasterAccName";  //NONLS
   public static final String PName_IsCollection      = "IsCollection"; //NONLS
   public static final String PName_IsStructured      = "isStructured"; //NONLS
   public static final String PName_ArrayElementType  = "ArrayElementType"; //NONLS
   public static final String PName_Name              = "Name";     //NONLS
   public static final String PName_ReadOnly          = "ReadOnly";     //NONLS

    
   public static final String SCALAR_ELEMENT_NAME = "element"; //NONLS
   
   public static final String PName_CollectionBeanClass         = "CollectionBeanClass";      //NONLS
    
   /*
    * For internal use 
    */
   public StructureDefImpl()
   {
   }

   public StructureDefImpl(DCDataControl app, String sDefName, String sName) 
   {
      mBeanClassName = sDefName;
      setName(sName);
      if (sDefName == null || sDefName.length() == 0)
      {
         setElementsScalar();
      }
      if (app != null) 
      {
         StructureDefinition def227 =
            (StructureDefinition)app.getDefinition(sDefName, StructureDefinition.class);

         if (def227 != null)
         {
            loadFromStructureDefinition(def227, app);
         }
      }
   }

   public String getDefName()
   {
      return mBeanClassName;
   }

   public String getDefFullName()
   {
      return mBeanClassName;
   }

   public String getArrayElementType()
   {
      return mArrayElementType;
   }
   
   public void setArrayElementType(String sType)
   {
      mArrayElementType = sType;         
   }
   
   public boolean isCollection()
   {
      return _isCollection;
   }
   
   public void setIsCollection(boolean bSet)
   {
      _isCollection = bSet;
   }
   
   /**
    * Gets the defined attributes.
    *
    * @return an array of attribute definitions.
    */
   public AttributeDef[] getAttributeDefs()
   {
      if (mDefStr != null) 
      {
         return mDefStr.getAttributeDefs();
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      return mAttrs;
   }

   /**
    * Returns the number of defined attributes.
    *
    * @return the number of attributes.
    */
   public int getAttributeCount()
   {
      if (mDefStr != null) 
      {
         return mDefStr.getAttributeCount();
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      return mAttrs.length;
   }

   /**
    * Gets an attribute definition, given its name.
    *
    * @param name the name of an <code>AttributeDef</code>.
    * @return  an attribute definition
    * @throws NoDefException - if the attribute is not found.
    */
   public AttributeDef findAttributeDef(String name)
   {
      if (mDefStr != null) 
      {
         return mDefStr.findAttributeDef(name);
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      for (int i = 0; i < mAttrs.length; i++)
      {
         if (mAttrs[i].getName().equals(name))
         {
            return mAttrs[i];
         }
      }
      
      //if scalar then all names match to the default and only attribute
      return (isElementsScalar()) ? mAttrs[0] : null;
   }

   /**
    * Gets an attribute definition, given its name.
    *
    * @param name the name of an <code>AttributeDef</code>.
    * @return  an attribute definition if found, null otherwise
    */
   public AttributeDef lookupAttributeDef(String name)
   {
      if (mDefStr != null) 
      {
         return mDefStr.lookupAttributeDef(name);
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      return findAttributeDef(name);
   }
   

   /**
    * Gets an attribute definition, given its index.
    *
    * @param index the index of an <code>AttributeDef</code>, where the leftmost
    * attribute has index zero.
    * @return  an attribute definition.
    */
   public AttributeDef getAttributeDef(int index)
   {
      if (mDefStr != null) 
      {
         return mDefStr.getAttributeDef(index);
      }

      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      
      if(mAttrs == null)
         return null;
         
      return (index < mAttrs.length) ? mAttrs[index] : null;
   }
   

   public int getAttributeIndexOf(String name)
   {
      AttributeDef attrDef = lookupAttributeDef(name);

      if (attrDef == null)
      {
         return -1;
      }

      return attrDef.getIndex();
   }


   ArrayList getKeyAttrsList()
   {
      AttributeDef ads[] = getAttributeDefs();
      ArrayList al = new ArrayList();
      int size = ads.length;
      for (int i = 0; i < size; i++)
      {
         if (ads[i].isPrimaryKey())
         {
            al.add(ads[i]);
         }
      }
      return al;
   }

   public StructureDefImpl getAccessorDef(String name)
   {
      if (mDefStr != null) 
      {
         return mDefStr.getAccessorDef(name);
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      if (mAccessors != null)
      {
         for (int i = 0; i < mAccessors.length; i++)
         {
            if (mAccessors[i].mName.equals(name))
            {
               return mAccessors[i];
            }
         }
      }
      return null;
   }

   AttributeDef createAccessorAttributeDef(String accName, StructureDefImpl accDef)
   {
      if (mDefStr != null) 
      {
         return mDefStr.createAccessorAttributeDef(accName, accDef);
      }

      if (mAccessors != null)
      {
         int idx = mAttrs.length;
         AttributeDefImpl ad = new AttributeDefImpl(
                           null, //StructureDefImpl def, 
                           accName, //String nm, 
                           accName, //String cnm, 
                           idx, 
                           accDef.getBeanClassName(),
                           accDef.getBeanClassName(),
                           AttributeDef.UPDATEABLE, //assume accessor is true if it's part of updateable attributes.
                           false, 
                           false,
                           null);
         
         AttributeDefImpl[] attrs = new AttributeDefImpl[idx+1];
         System.arraycopy(mAttrs, 0, attrs, 0, idx);
         attrs[idx] = ad;
         mAttrs = attrs;
         return ad;

      }
      return null;
   }

   void createScalarAttribute(String bean)
   {
      String name = this.getName();

      mAttrs = new AttributeDefImpl[]{new AttributeDefImpl(this)};

      mAttrs[0].init(SCALAR_ELEMENT_NAME,  //name         
                     name,                 //accessorName
                     0,                    //index           
                     bean,                 //attributeType        
                     bean,                 //accessorType
                     true,                 //isSelected
                     false,                //isQueriable
                     AttributeDef.UPDATEABLE,//updateable
                     false,                 //primarykey
                     false,                //mandatory
                     null);                

      loaded = true;
      setElementsScalar();
   }

   public StructureDefImpl[] getAccessors()
   {
      if (mDefStr != null) 
      {
         return mDefStr.getAccessors();
      }
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      return mAccessors;
   }
   
   static String loadOptionalNodeValue(Node node)
   {
      return (node != null) ? node.getNodeValue() : null;
   }
   
   
   public static StructureDefImpl createAndLoadFromXML(DefElement elem)
   {
      StructureDefImpl str = new StructureDefImpl();
      str.readContents(elem);
      if (str.mBeanClassName != null)
      {
         str.setName(JboNameUtil.getLastPartOfName(str.mBeanClassName));
      }
      else
      if (elem.getAttribute(JUTags.ID) != null)
      {
         //in 1013, id is generated that should be the name of this structuredef.
         str.setName(elem.getAttribute(JUTags.ID));
      }
      return str;
   }
   
   void loadFromXML(String beanClass)
   {
      try
      {
         if (beanClass != null)
         {
            referToMOMStructureDef(beanClass);
         }
      }
      catch (oracle.jbo.JboException e)
      {
         //we may move this to be a entry in the structuredef xml itself by indicating this is a 
         //scalar def.
         boolean skipMD = BeanUtils.skipMetaData(beanClass);
         if (Diagnostic.isOn())
         {
            if (skipMD)
            {
               Diagnostic.println("StructureDefImpl:Assuming default Attribute for:"+beanClass); //NONLS
            }
            else 
            {
               Diagnostic.println("Error in loading "+beanClass); //NONLS
               Diagnostic.println(e.getMessage());
            }
         }

         if (skipMD)
         {
            createScalarAttribute(beanClass);
         }
      }
   }

   void loadFromStructureDefinition(StructureDefinition str227, DCDataControl app)
   {
      if (getName() == null)
      {
         setName(str227.getName());
      }

      Iterator attrs227 = str227.getAttributeDefinitions().iterator();
      ArrayList attrs = new ArrayList();
      int index = 0;
      AttributeDefImpl attrDef = null;
      AttributeDefinition attrDef227;
      while (attrs227.hasNext())
      {
         attrDef227 = (AttributeDefinition)attrs227.next();

         attrDef = new AttributeDefImpl(this);
         mAttrs[0].init(attrDef227.getName(),  //name         
                        attrDef227.getName(), //accessorName
                        index,                    //index           
                        attrDef227.getJavaTypeString(),//attributeType        
                        attrDef227.getJavaTypeString(),//accessorType
                        true,                 //isSelected
                        false,                //isQueriable
                        (attrDef227.isReadOnly() ? AttributeDef.UPDATEABLE : AttributeDef.READONLY),
                        false,                 //primarykey
                        false,                //mandatory
                        null);                
          
          attrs.add(attrDef);
          index++;
      }

      setAttributeDefs(attrs);

      Iterator accs227 = str227.getAccessorDefinitions().iterator();
      ArrayList accs = new ArrayList();
      while (accs227.hasNext())
      {
         AccessorDefinition accDef227 =
            (AccessorDefinition)accs227.next();

         AccessorDefImpl def = createNewAccessor(
            accDef227.getStructure().getName(), accDef227.getName(), app);

         def.init(accDef227.getStructure().getName(),
            accDef227.getJavaTypeString(), accDef227.getJavaTypeString()
            , true);
//         initAccessor(def, accDef227.getStructure().getName(),
//            accDef227.getJavaTypeString(), accDef227.getJavaTypeString(), true);

          accs.add(def);
      }
      mAccessors = (StructureDefImpl[])accs.toArray(
                      new StructureDefImpl[accs.size()]);
   }

   void setAttributeDefs(ArrayList al)
   {
      mAttrs = (AttributeDefImpl[])al.toArray(new AttributeDefImpl[al.size()]);
      for (int i = 0; i < mAttrs.length; i++)
      {
         mAttrs[i].setDef(this);
      }
      loaded = true;
   }

   /**
    * Advanced only for testing purposes.
    */
   public void init (HashMap map)
   {
      if (map.get(PName_BeanClass) != null)
      {
         mBeanClassName = (String)map.get(PName_BeanClass);
      }
      if (map.get(PName_MsgBundleClass) != null)
      {
         mMsgClassName = (String)map.get(PName_MsgBundleClass);
      }
      if (map.get(PName_FieldType) != null)
      {
         mFieldType = (String)map.get(PName_FieldType);
      }
      if(map.get(PName_ArrayElementType) != null)
      {
         mArrayElementType = (String)map.get(PName_ArrayElementType);
      }
      if (map.get(PName_IsCollection) != null)
      {
         String isCollectionMappedStr = (String)map.get(PName_IsCollection);
         if (isCollectionMappedStr != null)
         {
            _isCollection =
               Boolean.valueOf(isCollectionMappedStr).booleanValue();
         }
      }
   }

   public void readContents(DefElement elem)
   {
      // if you change this don't forget to check copyFrom(StructureDefImpl)
      // as well.
      try
      {
         mBeanClassName = elem.readString(PName_BeanClass);
         mMsgClassName  = elem.readString(PName_MsgBundleClass);
         mBeanClass = elem.readClassName(PName_BeanClass);
         mMsgClass  = elem.readClassName(PName_MsgBundleClass);
         _isCollection = elem.readBoolean(PName_IsCollection);
         mFieldType = elem.readString(PName_FieldType);
         mArrayElementType = elem.readString(PName_ArrayElementType);
         
         DefElement contents = elem.findChildElement("Contents"); //NOTRANS 
         
         if(contents != null)
            readChildren(contents);
         else
            readChildren(elem);
         
         loaded = true;
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }
   
   private void copyFrom(StructureDefImpl str)
   {
      // currently assumes deep immutability in the original StructureDefImpl.
      // If this assumption changes we must clone below.

      mAttrs = str.mAttrs;
      mAccessors = str.mAccessors;
      mScalarAccessors = str.mScalarAccessors;
      mValidators = str.mValidators;

      // JRS Don't copy the name, it is set in the constructor for accessor
      // collections
      // mName = str.mName;
      
      //this accessor does not seem to have any impact on whether
      //it's copied over or not. - sjv.
      mMsgClassName = str.mMsgClassName;
      
      if (mBeanClassName != null && str.mBeanClassName == null && str.mBeanClass == null)
      {
         //
         //reverse setting. 
         //
         //str was loaded via MOM and does not have beanclassname in the xml
         //we may set this up here since the accessor def does have the fullname.
         str.mBeanClassName = mBeanClassName;
      }
      
      mBeanClassName = str.mBeanClassName;
      mBeanClass = str.mBeanClass;
      mMsgClass = str.mMsgClass;
      mElementsScalar = str.mElementsScalar;
      _isCollection = str._isCollection;  
      mFieldType = str.mFieldType;
      mArrayElementType = str.mArrayElementType;

      // don't clone this
      loaded = true;
   }

   protected void readChildren(DefElement elem)
   {
         loadAccessors(elem);
         loadAttributes(elem);
         oracle.jbo.rules.RulesBeanUtils.loadValidators(elem, this, getMessageBundleClass());
         loadProperties(elem);
   }
   
   void loadAttributes(DefElement elem)
   {
      try
      {
         com.sun.java.util.collections.ArrayList attributes = elem.getChildrenList(PName_Attribute);  //NONLS
         if (attributes != null && attributes.size() > 0)
         {
            ArrayList list = new ArrayList();
            //String sDefName;
            AttributeDefImpl def;
            for(int i = 0; i < attributes.size(); i++)
            {
               def = new AttributeDefImpl(this);
               def.loadFromXML((DefElement)attributes.get(i), i);
               list.add(def);
            }
            this.mAttrs = (AttributeDefImpl[])list.toArray(new AttributeDefImpl[list.size()]);
         }
         else if (mAttrs == null) //for scalars mAttrs is already set by now.
         {
            mAttrs = new AttributeDefImpl[0];
         }
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }

   void loadAccessors(DefElement elem)
   {
      ArrayList accessorList = new ArrayList();

      com.sun.java.util.collections.ArrayList childrenList =
         elem.getChildrenList();

      int length = childrenList.size();
      for (int i = 0; i < length; i++)
      {
         DefElement child = (DefElement)childrenList.get(i);

         //
         // ### [edelaube 2005/01/25] Should the comparison be case-insensitive?
         // If so, we could use getChildrenList(PName_AccessorAttribute)
         // and simplify the logic.
         //
         if (child.getNodeName().equals(PName_AccessorAttribute))
         {
            String name = child.getAttribute(JUTags.NAME);
            if (name == null || name.length() == 0)
            {
               name = child.getAttribute(JUTags.ID);
               if (name != null && name.length() == 0)
               {
                  name = null;
               }
            }

            String beanClass = child.getAttribute(PName_BeanClass);
            if (beanClass != null && beanClass.length() == 0)
            {
               beanClass = null;
            }

            AccessorDefImpl def = createNewAccessor(beanClass, name, null);

            // JRS Encapsulate the logic that reads the Accessor MD in the
            // AccessorDefImpl.  This API could be generalized to
            // StructureDefImpl.  Not doing it for right now.  Too big of an
            // impact.
            def.loadFromXML(child);

            accessorList.add(def);
         }
      }
      mAccessors = (StructureDefImpl[])accessorList.toArray(
                      new StructureDefImpl[accessorList.size()]);
   }


   protected void referToMOMStructureDef(String beanClass)
   {
      StructureDefImpl str = (StructureDefImpl)JUMetaObjectManager.getJUMom().findDefinitionObjectDontCheckName(
            beanClass,
            JUMetaObjectManager.TYP_DEF_ANY,
            StructureDefImpl.class,
            false /*sub*/);
      copyFrom(str);
      mDefStr = str;
   }


   boolean isElementsScalar(Object firstRowData)
   {
      if (!loaded)
      {
         try
         {
            //may be used in getting structure info for this object.
            mFirstRowData = firstRowData;
            loadFromXML(getBeanClassName());
         }
         finally
         {
            mFirstRowData = null;
         }
      }
      return mElementsScalar;
   }

   boolean isElementsScalar()
   {
      if (!loaded)
      {
         loadFromXML(getBeanClassName());
      }
      return mElementsScalar;
   }

   void setElementsScalar()
   {
      mElementsScalar = true;
      if (mAttrs == null || getAttributeDef(0) == null)
      {
         mAttrs = new AttributeDefImpl[]
              {
                 new AttributeDefImpl(this)
              };

         mAttrs[0].init(SCALAR_ELEMENT_NAME,  //name         
                        getName(),            //accessorName
                        0,                    //index           
                        JAVA_OBJECT_CLZNAME,  //attributeType        
                        JAVA_OBJECT_CLZNAME,  //accessorType
                        true,                 //isSelected
                        false,                //isQueriable
                        AttributeDef.UPDATEABLE,//updateable
                        false,                //primarykey
                        false,                //mandatory
                        null);                
         //since we're setting an attribute stString elemClzName)ructure here, 
         //this def is now considered loaded.
         loaded = true;
      }
   }

   protected StructureDefImpl[] getScalarAccessorsList()
   {
      if (mScalarAccessors == null)
      {
         ArrayList al = new ArrayList(mAccessors.length);
         for (int i = 0; i < mAccessors.length; i++)
         {
            if (mAccessors[i].isElementsScalar())
            {
               al.add(mAccessors[i]);
            }
         }
         mScalarAccessors = (StructureDefImpl[])al.toArray(new StructureDefImpl[al.size()]);
      }
      return mScalarAccessors;
   }

   protected AccessorDefImpl createNewAccessor(
      String sDefName, String sName, DCDataControl app)
   {
      return new AccessorDefImpl(app, sDefName, sName);
   }

   void setAttributes(AttributeDefImpl ad[])
   {
      mAttrs = (ad != null) ? ad : new AttributeDefImpl[0];
      loaded = true;
   }

   void setAccessors (StructureDefImpl ad[])
   {
      mAccessors = ad;
   }

   protected void setName(String str)
   {
      mName = str;
      super.setName(str);
   }

   public String getFieldType()
   {
      return mFieldType;
   }

   public void setFieldType(String sType)
   {
      mFieldType = sType;   
   }
   
   public String getMessageBundleClassName()
   {
      return (mMsgClass != null) ? mMsgClass.getName() : mMsgClassName;
   }

   public String getBeanClassName()
   {
      if(mBeanClassName != null)
         return mBeanClassName;
         
      return (mBeanClass != null) ? mBeanClass.getName() : mBeanClassName;
   }

   public void setBeanClassName(String sName)
   {
      mBeanClassName = sName;   
   }

   public Class getBeanClass()
   {
      // can this be null?
      return mBeanClass;
   }

   Class getMessageBundleClass()
   {
      return mMsgClass;
   }

   public void addValidator(JboValidatorInterface intf)
   {
      if (mValidators == null)
      {
         mValidators = new ArrayList(3);
      }
      mValidators.add(intf);
   }

   public ArrayList getValidators()
   {
      return (mValidators != null) ? (ArrayList)mValidators.clone() : new ArrayList(0);
   }
}
