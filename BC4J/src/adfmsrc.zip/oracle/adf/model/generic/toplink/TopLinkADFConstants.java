package oracle.adf.model.generic.toplink;

/**
 * <b>Purpose<b>: TopLink related constants that are ADF specific.<p>
 * <b>Description<b>: Constants for application parameters.
 * 
 * @version 10.1.2
 * @deprecated - TopLink Data Controls created with 10.1.3 ADF, will no longer use 
 * these classes.
 */
public interface TopLinkADFConstants
{
	/** Parameter key for the TopLink Deployment Descriptor location */
	public static final String DEPLOYMENT_DESCRIPTOR_LOCATION_KEY = "DeploymentDescriptorFileName";
	/** Parameter key for the TopLink sessions.xml location */
	public static final String SESSIONS_XML_LOCATION_KEY = "TopLinkSessionsXMLFileName";
	/** Parameter key for the TopLink Session name to be used */
	public static final String SESSION_NAME_KEY = "TopLinkSessionName";
	/** Parameter indicating that sequence numbers should be assigned on object creation */
	public static final String ASSIGN_SEQUENCE_NUMBERS_ON_CREATE_KEY = "TopLinkSequenceOnCreate";
  /** Parameter indicating that the associated UnitOfWork should perform deletes first upon commit*/
	public static final String SHOULD_PERFORM_DELETES_FIRST_KEY = "TopLinkShouldPerformDeletesFirst";
}
