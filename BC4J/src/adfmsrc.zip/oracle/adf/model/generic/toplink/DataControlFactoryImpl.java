package oracle.adf.model.generic.toplink;

// JDK
import java.util.IdentityHashMap;
import java.util.Map;
import java.lang.reflect.Constructor;

// ADF
import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControl;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.common.JBOClass;



/**
 * <b>Purpose<b>: Construct a data control upon request.<p>
 * <b>Description<b>: The ADF infrastructure will use this factory to create 
 * TopLink data controls when required. ADF will create multipe factories so no
 * shared state should be assumed (not a singlton factory).
 * 
 *
 * @see oracle.adf.model.DataControlFactory
 * @see oracle.adf.model.generic.toplink.TopLinkDataControl
 * @see oracle.adf.model.generic.toplink.PersistenceManager
 * 
 * @version 10.1.2  
 * @deprecated - TopLink Data Controls created with 10.1.3 ADF, will no longer use 
 * these classes.
 */
public class DataControlFactoryImpl extends oracle.adf.model.generic.DataControlFactoryImpl
{
	/** Default data control class name */
	public static final String DEFAULT_DATA_CONTROL_CLASS_NAME = "oracle.adf.model.generic.toplink.TopLinkDataControl";

	/** 
	 * Static map of application class loaders to PersistenceManagers.  The fundamental basis for application resource management 
	 * in ADF and BC4J is the application class loader.  The application level class loader is unique to a given application and spans
	 * all user contexts of that appliction (user and binding contexts).  As such, it serves to identify an application as there may
	 * be many TL ADF applications deployed to a given app server.  There should be one PersistenceManager per application 
	 * (instead of per application instance) to make use of sharing three-tier TL resources if necessary.  An IdentityHashMap is
	 * used as class loader identity serves as the key to identifying a particular application.
	 */
	private static IdentityHashMap persistenceManagerMap;

	public DataControlFactoryImpl() {
	}

	/**
	 * Creates a new TopLinkDataControl instance based upon the given inputs.
	 * 
	 * @see oracle.adf.model.DataControlFactory#createSession(oracle.adf.model.BindingContext, String, java.util.Map, java.util.Map)
	 */
	public DataControl createSession(BindingContext ctx, String sName, Map appParams, Map parameters) {
		try {
			String beanClassName = (String) parameters.get("BeanClass");
			TransactionBroker transHandler = getPersistenceManager().getTransactionBrokerFor(ctx, parameters);
			TopLinkDataControl app = null;
			try {
				Class dcClass = JBOClass.forName(getDataControlClassName());
				Constructor cons = dcClass.getConstructor(new Class[]{String.class, Map.class, String.class, boolean.class,
						TransactionBroker.class});
				app = (TopLinkDataControl) cons.newInstance(new Object[]{sName, parameters, beanClassName, new Boolean(true),
						transHandler});
			} catch (Exception e) {
				System.out.println("**********Could not instantiate DataControl:  " + getDataControlClassName());
				app = new TopLinkDataControl(sName, parameters, beanClassName, true, transHandler);
			}
			JUMetaObjectManager.getJUMom().addApplication(app);
			app.setName(sName);
			app.setBindingContext(ctx);
			transHandler.addDataControl(app);
			return app;
		} catch (Exception e) {
			throw new oracle.jbo.JboException(e);
		}
	}

	/**
	 * May be overridden to return a custom DataControl class name.
	 */
	public String getDataControlClassName() {
		return DEFAULT_DATA_CONTROL_CLASS_NAME;
	}

	/**
	 * Returns the static PeristenceManager for the given application based on its class loader.  If a PersistenceManager
	 * does not exist yet, one is created and added to the map.
	 */
	private synchronized static final PersistenceManager getPersistenceManager() {
		ClassLoader currLoader = JBOClass.getCurrentClassLoader();
   		PersistenceManager persistenceManager = (PersistenceManager)getPersistenceManagerMap().get(currLoader);
    		if (persistenceManager == null) {
			persistenceManager = new PersistenceManager();
      			getPersistenceManagerMap().put(currLoader, persistenceManager);
    		}
    		return persistenceManager;
	}
  
  	/**
	 * Lazily initializes and returns the static map of PeristenceManager instance shared across all factories.  
	 */
	private synchronized static final Map getPersistenceManagerMap() {
		if (persistenceManagerMap == null) {
			persistenceManagerMap = new IdentityHashMap();
		}
		return persistenceManagerMap;
	}
}
