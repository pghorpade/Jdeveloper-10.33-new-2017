package oracle.adf.model.generic.toplink;

// JDK
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

// ADF
import oracle.adf.model.binding.DCInvokeMethod;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.generic.DCGenericDataControl;
import oracle.adf.model.generic.DCRowContext;
import oracle.adf.model.generic.DCRowSetIteratorImpl;
import oracle.adf.model.generic.StructureDefImpl;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;

 /**
 * <b>Purpose<b>: Data control for use of TopLink within ADF.<p>
 * <b>Description<b>: This data control abstracts the use of TopLink. It allows
 * for a single TransactionBroker to be shared all TL data controls that share a 
 * common binding context. This assumes a single transaction and database session
 * (isolated or *client/1server) per user context.
 * 
 * 
 * @see oracle.adf.model.generic.toplink.DataControlFactoryImpl
 * @see oracle.adf.model.generic.DCGenericDataControl
 * @see oracle.adf.model.generic.toplink.TransactionBroker
 * 
 * @version 10.1.2
 * @deprecated - TopLink Data Controls created with 10.1.3 ADF, will no longer use 
 * these classes.
 */
public class TopLinkDataControl extends DCGenericDataControl
{
	public static final String DOT_STR = ".";
	/** Identifies a method invocation as a TL query */
	public static final String QUERY_SPEL_IDENTIFIER = "query";
	/** Identifies a method invocation as a TL "read all" query */
	public static final String READ_ALL_QUERY_SPEL_IDENTIFIER = "query.all";
	/** Handles all transactional related activities for this data control instance */
	private TransactionBroker transactionBroker;
	/** bean class representing the root object of this data control */
	private Class beanClass;
	private String beanClassName;
	/** Determines whether to assign sequence numbers on object creation. */
	private boolean sequenceOnCreate;
	
 	/**
	 * Creates a new instance of the TopLinkDataControl.
	 * 
	 * @param name - data control name.
	 * @param params - application parameters.
	 * @param beanClassName - name of the object this data control represents.
	 * @param root - indicates whether this data control is the root in the structure.
	 * @param transactionBroker - transactional management facility.
	 */
	public TopLinkDataControl(String name, Map params, String beanClassName, boolean root, 
			TransactionBroker transactionBroker) {
		super(name, beanClassName, null, root);
		initialize(params, beanClassName, transactionBroker);
	}

	protected void initialize(Map params, String beanClassName, TransactionBroker transactionBroker) {
		this.sequenceOnCreate = Boolean.valueOf((String)params.get(TopLinkADFConstants.ASSIGN_SEQUENCE_NUMBERS_ON_CREATE_KEY)).booleanValue();
    		this.beanClassName = beanClassName;
		this.transactionBroker = transactionBroker;
	}

	/**
	 * Describes what operations are supported by the TopLinkDataControl.
	 * 
	 * @see oracle.adf.model.binding.DCDataControl#isOperationSupported(oracle.adf.model.binding.DCIteratorBinding,
	 *      byte)
	 */
	public boolean isOperationSupported(DCIteratorBinding iterBinding, byte oper) {
		switch (oper) {
			case OPER_DATA_ROW_UPDATE :
			case OPER_DATA_ROW_CREATE :
			case OPER_DATA_ROW_REMOVE :
			case OPER_EXECUTE :
				return true;
			default :
				return super.isOperationSupported(iterBinding, oper);
		}
	}
  
  	/**
  	 * Overridden from <code>DCDataControl</code>, this method serves as an
  	 * entry point for executing native java methods as well as TopLink
  	 * queries.
  	 * 
  	 * @see oracle.adf.model.binding.DCDataControl#isOperationSupported(DCIteratorBinding, byte)
  	 */
  	public Object invokeMethod(DCInvokeMethod methodInfo, oracle.adf.model.OperationBinding action, Map params) {
  		if (isFindAllQuery(methodInfo) || isFindQuery(methodInfo)) {
  			return executeQuery(methodInfo, params);
  		} else {
  			return super.invokeMethod(methodInfo, action, params);
  		}
  	}

	/**
	 * Return true if the row at the given index is removed from the the RSI
	 * associated with the given iterator-binding. In addition, this method
	 * goes into the providing underlying collection removes the object
	 * contained in the Row, and marks the object to be deleted in the given
	 * transaction.
	 */
	public boolean removeRowData(DCRowContext ctx) {
		setTransactionModified();
		DCRowSetIteratorImpl rowSetIteratorImpl = (ctx.getRowSetIterator() instanceof DCRowSetIteratorImpl)
				? (DCRowSetIteratorImpl) ctx.getRowSetIterator()
				: null;
		// ensure that the RowSetIterator is an instance of
		// DCRowSetIteratorImpl
		if (rowSetIteratorImpl != null) {
			// get the data source which is the underlying object Collection
			Object dataSource = rowSetIteratorImpl.getDataProvider();
			Object rowProvider = ctx.getRowDataProvider();
			// if the data source exists
			if (dataSource != null && rowProvider != null) {
				// if an instance of Collection, then use "remove"
				if (dataSource instanceof Collection) {
					((Collection) dataSource).remove(rowProvider);
				}
				// if an instance of Iterator, the remove through thie iterator
				else if (dataSource instanceof Iterator) {
					((Iterator) dataSource).remove();
				}
			}
			// tell the UnitOfWork to remove this object on the next commit (or
			// revert on the next rollback)
			Object workingCopy = getTransactionBroker().deleteObject(rowProvider);
			// invoke a rebuild on the RowSetIterator back to the current
			// selected row
			rowSetIteratorImpl.rebuildIteratorUpto(rowSetIteratorImpl.getCurrentRowIndex());
			return true;
		}
		return false;
	}

	/**
	 * Creates the object described by <code>DCRowContext</code>, adds it to
	 * the underlying provider Collection, registers it in the given
	 * transaction, and returns the newly created object.
	 * 
	 * @param ctx -
	 *            description of the Row to create
	 * 
	 * @see oracle.adf.model.binding.DCDataControl#createRowData(oracle.adf.model.generic.DCRowContext)
	 */
	public Object createRowData(DCRowContext ctx) {
        setTransactionModified();
		//	 get the object provider's type
		String rowTypeName = ((StructureDefImpl) ctx.getStructureDef()).getBeanClassName();
		try {
			// create a new instance of the provider object and register it
			// with the UnitOfWork
			Object newProvider = getTransactionBroker().createNewInstance(JBOClass.forName(rowTypeName), this.sequenceOnCreate);
			DCRowSetIteratorImpl rowSetIteratorImpl = (ctx.getRowSetIterator() instanceof DCRowSetIteratorImpl)
					? (DCRowSetIteratorImpl) ctx.getRowSetIterator()
					: null;
			// if the rowset iterator is a non-null instance of
			// DCRowSetIteratorImpl, then
			if (rowSetIteratorImpl != null) {
				// get the data source provider object
				Object dataSource = rowSetIteratorImpl.getDataProvider();
				if (dataSource != null) {
					// if it is a List, insert the object at the current
					// iterator index
					if (dataSource instanceof List) {
						int index = rowSetIteratorImpl.getCurrentRowIndex();
						// in the case that the row is being inserted into an
						// empty List, the cursor will be -1. If so, set to 0.
						index = (index == -1) ? 0 : index;
						((List) dataSource).add(index, newProvider);
					}
					// if it is a Collection, append
					else if (dataSource instanceof Collection) {
						((Collection) dataSource).add(newProvider);
					}
				}
				// reset the contained iterator in the DCRowSetIteratorImpl to the current index
				rowSetIteratorImpl.rebuildIteratorUpto(rowSetIteratorImpl.getCurrentRowIndex());
			}
			return newProvider;
		} catch (JboException je) {
			throw je;
		} catch (Exception e) {
			throw new JboException(e);
		}
	}

	/**
	 * Overridden from DCDataControl to handle cleanup of TopLink related
	 * resources in the event of a data release.
	 * 
	 * @param flags -
	 *            Release type flags.
	 */
	public void release(int flags) {
		// call to super will handle any generic level cleanup including
		// removing this data control from the binding container if necessary.
		super.release(flags);
		// make sure that the right flags are passed and ensure that this
		// DC has not been previously released.
		if (((flags & REL_DATA_REFS) > 0) && getTransactionBroker().isDataControlRegistered(this)) {
			getTransactionBroker().release(this);
		}
	}

	/**
	 * Commits the transaction for this data control. The side effect of this
	 * method call is that all data controls sharing the same transaction will
	 * be commited and have their transactional state reset as well.
	 * 
	 * @see oracle.adf.model.binding.DCDataControl#commitTransaction()
	 */
	public void commitTransaction() {
		getTransactionBroker().commitTransaction();
	}

	/**
	 * Rollsback the transaction for this data control. The side effect of this
	 * method call is that all data controls sharing the same transaction will
	 * be commited and have their transactional state reset as well.
	 * 
	 * @see oracle.adf.model.binding.DCDataControl#rollbackTransaction()()
	 */
	public void rollbackTransaction() {
		getTransactionBroker().rollbackTransaction();
	}
  
  	/**
	 * Resets the state of the TopLinkDataControl to it's initial state upon
   	 * entering the application: a new UnitOfWork is acquired and all RSIs
   	 * associated with this DataControl are reset to their initial state (old 
	 * query results are invalidated as well). Calls to this method will also 
	 * recurse to all TopLinkDataControls that share the same TX space in 
	 * the application.
	 * 
   	 * @return whether this call has been deferred to the end of the web request.
	 * @see oracle.adf.model.binding.DCDataControl#resetState()
	 */
  	public boolean resetState() {
    		boolean shouldResetState = super.resetState();
    		if (shouldResetState) {
      			getTransactionBroker().resetState();
    		}
    		return shouldResetState;
  	}
 
	/**
	 * Executes the named TopLink query defined by the given <code>DCInvokeMethodDef</code>
	 * and parameters.
	 * 
	 * @param methodInfo -
	 *            description of the method and parameter values for the query
	 * @param params -
	 *            literal values provided by the user
	 * @return Single persistent object, List of persistent objects or null,
	 *         depending upon the query definition
	 */
	private Object executeQuery(DCInvokeMethod methodInfo, Map params) {
		String queryName = methodInfo.getMethodName();
		Object retVal = null;
		// if identifed as a read all query, then execute accordingly
		if (isFindAllQuery(methodInfo)) {
			retVal = getTransactionBroker().executeReadAllQuery(getBeanClass());
		} else {
     			Object [] paramVals = methodInfo.fetchParameterValues(getBindingContext(), params);
      			Vector paramValCollection = new Vector(Arrays.asList(paramVals));
			retVal = getTransactionBroker().executeQuery(getBeanClass(), queryName, paramValCollection);
		}
		String returnName = methodInfo.getReturnName();
		if (returnName != null) {
			DCUtil.putValueInPath(getBindingContext(), returnName, retVal);
		}
		return retVal;
	}

	/**
	 * Returns whether the given <code>DCInvokeMethodDef</code> is
	 * representative of a the default TopLink "read all" query defined on the given
	 * class. This is denoted by a SPEL identifier on the methodInfo instance
	 * name.
	 */
	private boolean isFindAllQuery(DCInvokeMethod methodInfo) {
		return methodInfo.getInstanceName().endsWith(READ_ALL_QUERY_SPEL_IDENTIFIER);
	}

	/**
	 * Returns whether the given <code>DCInvokeMethodDef</code> is
	 * representative of a user defined TopLink query defined on the given
	 * class. This is denoted by a SPEL identifier on the methodInfo instance
	 * name.
	 */
	private boolean isFindQuery(DCInvokeMethod methodInfo) {
		return methodInfo.getInstanceName().endsWith(QUERY_SPEL_IDENTIFIER);
	}

	/**
	 * Helper method that will use the JBO class-loader to lookup and hold the
	 * bean class for the data controller. This will avoid additional class
	 * lookups.
	 */
	private Class getBeanClass() {
		if (this.beanClass == null) {
			try {
				this.beanClass = JBOClass.forName(this.beanClassName);
			} catch (ClassNotFoundException cnfe) {
				throw new JboException(cnfe);
			}
		}
		return this.beanClass;
	}

	/**
	 * Notifies this data control that a commit has been performed and that the
	 * transactional state needs to be reset.
	 */
	protected void commitPerformed() {
    		resetTransactionalState();
	}

	/**
	 * Notifies this data control that a rollback has been performed and that
	 * the transactional state needs to be reset.
	 */
	protected void rollbackPerformed() {
    		transactionalResourcesReset();
  	}

 	/**
  	 * Notifies this data control that a "resetState: has been performed and
  	 * that the transactional and associated RSIs' state need to be reset.
  	 */
 	protected void resetStatePerformed() {
    		resetTransactionalState();
    		// close all RSIs associated with this DC along with their children(detail RSIs)
    		closeRowSetIterators(true);
    		// clear all cached method results
    		getMethodResults().clear();
  	}

	/**
	 * Notifies this data control that the transactional resources have been
	 * reset and that a full re-execution of all associated RSIs must be
	 * performed.
	 */
	protected void transactionalResourcesReset() {
		resetTransactionalState();
		restoreRSIs();
	}

	/**
	 * Resets the transactional state of this Data Control.
	 */
	protected void resetTransactionalState() {
		transactionStateChanged(false);
	}

	/**
	 * INTERNAL: Resets the transactional resources associated with this data
	 * control and all data controls that share the same transactional space.
	 * This method should be called with care since it will revert all data
	 * controls and subsequent RSIs in the same application and transactional
	 * space to their original states and remove all changes made.  Additionally,
   	 * the RSIs will be restored to their previous state.
	 */
	public void resetTransaction() {
		getTransactionBroker().resetTransactionalResources();
	}

	/**
	 * Returns the <code>TransactionBroker</code> associated with this data control
	 * instance that manages all transactional related activities for this data control.
	 */
	protected TransactionBroker getTransactionBroker() {
		return transactionBroker;
	}
  
  	/**
   	 * ADVANCED: Returns the TopLink UnitOfWork associated with this data control's transaction.
  	 * Use care when accessing this Session as any transactional state management activities will
  	 * make the transactional state of this data control inconsistent.
	 */
	public UnitOfWork getAssociatedUnitOfWork() {
	   return getTransactionBroker().getUnitOfWork();
	}
  
  	/**
	 * ADVANCED: Returns the TopLink Session associated with this data control's transaction.
	 * Use care when accessing this Session as any transactional state management activities will
	 * make the transactional state of this data control inconsistent.
	 */
	public Session getAssociatedSession() {
	    return getTransactionBroker().getSession();
  	}
    
}
