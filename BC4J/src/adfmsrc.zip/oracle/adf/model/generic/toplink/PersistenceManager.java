package oracle.adf.model.generic.toplink;

// JDK
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

// ADF
import oracle.adf.model.BindingContext;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;

// TopLink
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.internal.helper.ConversionManager;
import oracle.toplink.sessionbroker.SessionBroker;
import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.sessions.Project;
import oracle.toplink.sessions.Session;
import oracle.toplink.threetier.ServerSession;
import oracle.toplink.tools.sessionconfiguration.XMLSessionConfigLoader;
import oracle.toplink.tools.sessionmanagement.SessionManager;
import oracle.toplink.tools.workbench.XMLProjectReader;

/**
 * <b>Purpose<b>: TopLink abstraction for brokering TopLink Sessions and UnitOfWorks across all
 * ADF TopLink data controls and instances of a given application.<p>
 * <b>Description<b>: Handles transaction creation, allocation, and management related activities for 
 * the TopLink ADF Data Control implementation.  
 * 
 * @see oracle.adf.model.generic.toplink.TransactionBroker
 * @see oracle.adf.model.generic.toplink.TopLinkDataControl
 * @see oracle.adf.model.generic.toplink.DataControlFactoryImpl
 * 
 * @version 10.1.2
 * @deprecated - TopLink Data Controls created with 10.1.3 ADF, will no longer use 
 * these classes.
 */
public class PersistenceManager implements TopLinkADFConstants
{
	/** A Map describing all session.xml paths -> SessionManagers that have been read into the system*/
	private Map sessionsLocationsToSessionManagers;
	/** All TransactionBrokers in the system */
	private Collection transactionBrokerDescriptors;
	/** All Client TransactionBrokers paired with the parent Session */
	private Collection clientTransactionBrokersHolders;

	PersistenceManager() {
		super();
		initialize();
	}

	/**
	 * Performs initialization related activities.
	 */
	protected void initialize() {
		this.sessionsLocationsToSessionManagers = new HashMap();
		this.transactionBrokerDescriptors = new Vector();
		this.clientTransactionBrokersHolders = new Vector();
		// Prime the ConversionManager with the application class loader
		ConversionManager.getDefaultManager().setShouldUseClassLoaderFromCurrentThread(true);
	}

	/**
	 * Builds up a new or retrieves a cached TransactionBroker for the given application BindingContext 
	 * and application parameters.
	 */
	public synchronized TransactionBroker getTransactionBrokerFor(BindingContext bindingContext, Map params) {
		final String deploymentDescriptorLocation = (String) params.get(DEPLOYMENT_DESCRIPTOR_LOCATION_KEY);
		final String sessionsXMLLocation = (String) params.get(SESSIONS_XML_LOCATION_KEY);
		final String sessionName = (String) params.get(SESSION_NAME_KEY);
    final boolean shouldPerformDeletesFirst = Boolean.valueOf((String)params.get(SHOULD_PERFORM_DELETES_FIRST_KEY)).booleanValue();
		checkParameters(deploymentDescriptorLocation, sessionsXMLLocation, sessionName);
		TransactionBroker transBroker;
		if (deploymentDescriptorLocation != null) {
			transBroker = getTransactionBroker(bindingContext, deploymentDescriptorLocation, shouldPerformDeletesFirst);
		} else {
			transBroker = getTransactionBroker(bindingContext, sessionsXMLLocation, sessionName, shouldPerformDeletesFirst);
		}
		return transBroker;
	}

	/**
	 * Determines whether the provided parameters are legitimate. Throws a JBOException indicating the problem
	 * if not. 
	 */
	private void checkParameters(String deploymentDescriptorLocation, String sessionsXMLLocation, String sessionName) {
		if (deploymentDescriptorLocation == null && sessionsXMLLocation == null && sessionName == null) {
			throw new JboException("ERROR: No Parameters specified for this Data Control.");
		} else if (deploymentDescriptorLocation != null && sessionsXMLLocation != null && sessionName != null) {
			throw new JboException(
					"ERROR: Ambiguous Parameters. Either the deployment descriptor location OR the sessions.xml and Session name should be specified.");
		} else if (deploymentDescriptorLocation == null && (sessionsXMLLocation == null || sessionName == null)) {
			throw new JboException(
					"ERROR: When using the sessions.xml, both a sessions.xml location and Session name must be specified.");
		}
	}

	/**
	 * Gets the TransactionBroker for the given application BindingContext and deployment descriptor location.  If
	 * one does not exist, one is created and returned.  
	 */
	synchronized TransactionBroker getTransactionBroker(BindingContext applicationContext, String deploymentDescriptorLocation, 
                                                                                                                                                              boolean performDeletesFirst) {
		TransactionBroker transBroker = findTransactionBroker(applicationContext, deploymentDescriptorLocation);
		if (transBroker == null) {
			Project project = XMLProjectReader.read(deploymentDescriptorLocation, JBOClass.getCurrentClassLoader());
			DatabaseSession session = project.createDatabaseSession();
			session.login();
			transBroker = new TransactionBroker(applicationContext, session, this,
					TransactionBroker.ISOLATED_DATABASE_SESSION_TYPE, performDeletesFirst);
			addTransactionBroker(transBroker, deploymentDescriptorLocation);
		}
		return transBroker;
	}

	/**
	 * Gets the TransactionBroker for the given application BindingContext, sessions.xml location and session name.  If
	 * one does not exist, one is created and returned.  
	 */
	synchronized TransactionBroker getTransactionBroker(BindingContext applicationContext, String sessionsXMLLocation,
			String sessionName, boolean performDeletesFirst) {
		TransactionBroker transBroker = findTransactionBroker(applicationContext, sessionsXMLLocation, sessionName);
		if (transBroker == null) {
			SessionManager sessionManager = findSessionManager(sessionsXMLLocation);
			if (sessionManager == null) {
				sessionManager = new SessionManager();
				addSessionManager(sessionsXMLLocation, sessionManager);
			}
			Session session = null;
			try {
				session = sessionManager.getSession(sessionName, true);
			} catch (ValidationException e) {
				// likely means that the SessionManager has not been primed
				// with
				// a sessions.xml file. Try again below with the XMLLoader and
				// file. If failure occurs, let the exception propagate then.
			}
			// handle the sessions.xml loading case either way.
			if (session == null) {
                session = sessionManager.getSession(new XMLSessionConfigLoader(sessionsXMLLocation), sessionName, JBOClass
                        .getCurrentClassLoader(), true, true);
			}
			if (session == null) {
				throw new JboException("Problem encountered loading Session named: " + sessionName + " from file: "
						+ sessionsXMLLocation);
			}
			Session sessionToUse;
			int sessionType;
			if (session.isServerSession()) {
				sessionToUse = ((ServerSession) session).acquireClientSession();
				sessionType = TransactionBroker.CLIENT_SESSION_TYPE;
			} else if (session.isSessionBroker() && session.isServerSession()) {
				sessionToUse = ((SessionBroker) session).acquireClientSessionBroker();
				sessionType = TransactionBroker.CLIENT_SESSION_BROKER_TYPE;
			} else if (session.isSessionBroker()) {
				sessionToUse = session;
				sessionType = TransactionBroker.SHARED_SESSION_BROKER_TYPE;
			} else {
				sessionToUse = session;
				sessionType = TransactionBroker.SHARED_DATABASE_SESSION_TYPE;
			}
			transBroker = new TransactionBroker(applicationContext, sessionToUse, this, sessionType, performDeletesFirst);
			addTransactionBroker(transBroker, sessionsXMLLocation, sessionName, true);
			getClientTransactionBrokersHolder(sessionsXMLLocation, sessionName).addTransactionBroker(transBroker);
		}
		return transBroker;
	}

	/**
	 * Finds a TransactionBroker for the given application BindingContext and deployment descriptor location. If one does not
	 * exist, null is returned. 
	 */
	private TransactionBroker findTransactionBroker(BindingContext applicationContext, String deploymentDescriptorLocation) {
		synchronized (transactionBrokerDescriptors) {
			for (Iterator BrokerDescs = transactionBrokerDescriptors.iterator(); BrokerDescs.hasNext();) {
				TransactionBrokerDescriptor desc = (TransactionBrokerDescriptor) BrokerDescs.next();
				if (desc.isBrokerFor(applicationContext, deploymentDescriptorLocation)) {
					return desc.getTransactionBroker();
				}
			}
		}
		return null;
	}

	/**
	 * Finds a TransactionBroker for the given application BindingContext, sessions.xml location, and session name. If
	 * one does not exist, null is returned. 
	 */
	private TransactionBroker findTransactionBroker(BindingContext applicationContext, String sessionsXMLLocation,
			String sessionName) {
		synchronized (transactionBrokerDescriptors) {
			for (Iterator brokerDescs = transactionBrokerDescriptors.iterator(); brokerDescs.hasNext();) {
				TransactionBrokerDescriptor desc = (TransactionBrokerDescriptor) brokerDescs.next();
				if (desc.isBrokerFor(applicationContext, sessionsXMLLocation, sessionName)) {
					return desc.getTransactionBroker();
				}
			}
		}
		return null;
	}

	/**
	 * Adds a TransactionBrokerDescription for the specified TransactionBroker and deployment descriptor location. This
	 * methid should be called if the TransactionBroker resulted directly from a deployment descriptor.
	 */
	private void addTransactionBroker(TransactionBroker transactionBroker, String deploymentDescriptorLocation) {
		TransactionBrokerDescriptor desc = new TransactionBrokerDescriptor(transactionBroker, deploymentDescriptorLocation);
		transactionBrokerDescriptors.add(desc);
	}

	/**
	 * Adds a TransactionBrokerDescription for the give TransactionBroker, sessions.xml location and Session name.  This
	 * method should be called if the TransactionBroker resulted from a Session defined in the session.xml. 
	 */
	private void addTransactionBroker(TransactionBroker transactionBroker, String sessionsXMLLocation, String sessionName,
			boolean isThreeTier) {
		TransactionBrokerDescriptor desc = new TransactionBrokerDescriptor(transactionBroker, sessionsXMLLocation, sessionName,
				isThreeTier);
		transactionBrokerDescriptors.add(desc);
	}

	/**
	 * Removes the given TransactionBroker from the PersistenceManager. Any Session related cleanup is performed
	 * by this operation as well. 
	 */
	synchronized void removeTransactionBroker(TransactionBroker transactionBroker) {
		TransactionBrokerDescriptor desc = null;
		synchronized (transactionBrokerDescriptors) {
			for (Iterator brokerDescs = transactionBrokerDescriptors.iterator(); brokerDescs.hasNext();) {
				desc = (TransactionBrokerDescriptor) brokerDescs.next();
				if (desc.isBrokerFor(transactionBroker)) {
					brokerDescs.remove();
					break;
				}
			}
		}
		removeClientTransactionBrokersHolderIfNecessary(desc);
	}

	/**
	 * Determins if the TransactionBroker descrbed by the given TransactionBrokerDescriptor is using a three tier TL Session
	 * configuration.  If so, it removes the TransactionBroker from the associated ClientTransactionBrokerHolder.  If the
	 * ClientTransactionBrokerHolder is empty (no reference remain to the server session), then the ServerSession is destroyed
	 * as well.  
	 */
	private synchronized void removeClientTransactionBrokersHolderIfNecessary(TransactionBrokerDescriptor brokerDescriptor) {
		if (brokerDescriptor == null)
			return;
		// uses sessions.xml?
		if (brokerDescriptor.isThreeTierBroker()) {
			ClientTransactionBrokersHolder brokerHolder = findClientTransactionBrokersHolder(brokerDescriptor.getFileLocation(),
					brokerDescriptor.getSessionName());
			if (brokerHolder != null) {
				// remove this Broker from the bucket?
				brokerHolder.removeTransactionBroker(brokerDescriptor.getTransactionBroker());
				// if this holder is empty (in other words, there are no more
				// child client Sessions (or UOWs) referencing the parent
				// session),
				// then...
				if (!brokerHolder.hasTransactionBrokers()) {
					removeClientTransactionBrokersHolder(brokerHolder);
					SessionManager sessionManager = findSessionManager(brokerHolder.getSessionsXMLLocation());
					if (sessionManager != null) {
						// kill the primay session
						sessionManager.destroySession(brokerHolder.getSessionName());
						if (sessionManager.getSessions().isEmpty()) {
							// if the SessionManager at the given location is
							// empty,
							// then kill then kill the reference to it as well.
							removeSessionManager(brokerHolder.getSessionsXMLLocation());
						}
					}
				}
			}
		}
	}

	/**
	 * Returns a ClientTransactionBrokerHolder for the given sessions.xml path and session name.  If one does not exist, a 
	 * new one is created, added to the underlying collection and returned.
	 */
	private ClientTransactionBrokersHolder getClientTransactionBrokersHolder(String sessionsXMLLocation, String sessionName) {
		ClientTransactionBrokersHolder holder = findClientTransactionBrokersHolder(sessionsXMLLocation, sessionName);
		if (holder == null) {
			holder = new ClientTransactionBrokersHolder(sessionsXMLLocation, sessionName);
			addClientTransactionBrokersHolder(holder);
		}
		return holder;
	}

	/**
	 * Locates the ClientTransactionBroker for the given sessions.xml path and session name.  If one does not exist, null
	 * is returned.
	 */
	private ClientTransactionBrokersHolder findClientTransactionBrokersHolder(String sessionsXMLLocation, String sessionName) {
		if (sessionsXMLLocation == null || sessionName == null)
			return null;
		for (Iterator BrokerDescHolders = clientTransactionBrokersHolderCopy(); BrokerDescHolders.hasNext();) {
			ClientTransactionBrokersHolder holder = (ClientTransactionBrokersHolder) BrokerDescHolders.next();
			if (holder.getSessionsXMLLocation().equals(sessionsXMLLocation) && holder.getSessionName().equals(sessionName)) {
				return holder;
			}
		}
		return null;
	}

	/**
	 * Adds the give ClientTransactioBrokerHolder.
	 */
	private synchronized void addClientTransactionBrokersHolder(ClientTransactionBrokersHolder transactionBrokerDescriptorHolder) {
		this.clientTransactionBrokersHolders.add(transactionBrokerDescriptorHolder);
	}

	/**
	 * Removes the give ClientTransactioBrokerHolder from the underlying Collection. 
	 */
	private synchronized void removeClientTransactionBrokersHolder(ClientTransactionBrokersHolder transactionBrokerDescriptorHolder) {
		this.clientTransactionBrokersHolders.remove(transactionBrokerDescriptorHolder);
	}

	/**
	 * Returns an Iterator over a copy of the Collection of all ClientTransactionBrokerHolders. 
	 */
	private Iterator clientTransactionBrokersHolderCopy() {
		return new ArrayList(this.clientTransactionBrokersHolders).iterator();
	}

	/**
	 * Adds a SessionManager for the given sessions.xml path.
	 * 
	 * @param sessionsXMLLocation - sessions.xml path.
	 * @param sessionManager - SessionManager to add.
	 */
	private void addSessionManager(String sessionsXMLLocation, SessionManager sessionManager) {
		sessionsLocationsToSessionManagers.put(sessionsXMLLocation, sessionManager);
	}

	/**
	 * Finds the SessionManager identified by the given sessions.xml path. 
	 */
	private SessionManager findSessionManager(String sessionsXMLLocation) {
		return (SessionManager) sessionsLocationsToSessionManagers.get(sessionsXMLLocation);
	}

	/**
	 * Uncaches from memory the SessionManager identfied by the given sessions.xml path.  
	 */
	private void removeSessionManager(String sessionsXMLLocation) {
		this.sessionsLocationsToSessionManagers.remove(sessionsXMLLocation);
	}
	
	/**
	 * Describes the grouping of TransactionBrokers with a named parent Server or SessionBroker.  Used to determine
	 * when to release the parent Session 
	 */
	private class ClientTransactionBrokersHolder
	{
		private Collection clientTransactionBrokerDescriptors;
		private String sessionsXMLLocation;
		private String sessionName;

		/**
		 * @param sessionsXMLLocation - path of the associated sessions.xml
		 * @param sessionName - name of the parent ServerSession or SessionBroker.
		 */
		private ClientTransactionBrokersHolder(String sessionsXMLLocation, String sessionName) {
			super();
			this.clientTransactionBrokerDescriptors = new Vector();
			this.sessionsXMLLocation = sessionsXMLLocation;
			this.sessionName = sessionName;
		}

		/**
		 * Adds a TransactionBroker to this holder. 
		 */
		private void addTransactionBroker(TransactionBroker transactionBroker) {
			this.clientTransactionBrokerDescriptors.add(transactionBroker);
		}

		/**
		 * Removes a TransactionBroker from this holder.
		 */
		private void removeTransactionBroker(TransactionBroker transactionBroker) {
			this.clientTransactionBrokerDescriptors.remove(transactionBroker);
		}

		/**
		 * Returns whether this holder contains the given TransactionBroker.
		 */
		private boolean containsTransactionBroker(TransactionBroker transactionBroker) {
			return this.clientTransactionBrokerDescriptors.contains(transactionBroker);
		}
		
		/**
		 * Returns whether this holder contains any more TransactionBrokers 
		 */
		private boolean hasTransactionBrokers() {
			return !this.clientTransactionBrokerDescriptors.isEmpty();
		}
		
		private String getSessionsXMLLocation() {
			return this.sessionsXMLLocation;
		}

		private String getSessionName() {
			return this.sessionName;
		}
	}
	
	/**
	 * Describes the pairing of a TransactionBroker with its deployment resource paths, and unique 
	 * application context (BindingContext).
	 */
	private class TransactionBrokerDescriptor
	{
		/** Deployment Descriptor or sessions.xml location */
		private String fileLocation;
		/** Optional TL Session name */
		private String sessionName;
		/** TransactionBroker described by this class */
		private TransactionBroker transactionBroker;
		/** Describes whether this is a three tier broker */
		private boolean isThreeTier = false;

		/**
		 * Use this constructor if this TransactionBroker describes a sessions.xml enabled data control that uses 
		 * a shared SessionBroker or ServerSession with an isolated ClientSession. 
		 */
		private TransactionBrokerDescriptor(TransactionBroker transactionBroker, String fileLocation, String sessionName,
				boolean isThreeTier) {
			this(transactionBroker, fileLocation, sessionName);
			this.isThreeTier = isThreeTier;
		}

		/**
		 * Use this constructor if this TransactionBroker describes a simple deployment descriptor enabled data control that uses 
		 * a shared DatabaseSession. 
		 */
		private TransactionBrokerDescriptor(TransactionBroker transactionBroker, String fileLocation) {
			super();
			this.fileLocation = fileLocation;
			this.transactionBroker = transactionBroker;
		}
		/**
		 * Use this constructor if this TransactionBroker describes a sessions.xml enabled data control that uses 
		 * a shared SessionBroker or DatabaseSession. 
		 */
		private TransactionBrokerDescriptor(TransactionBroker transactionBroker, String fileLocation, String sessionName) {
			this(transactionBroker, fileLocation);
			this.sessionName = sessionName;
		}

		/**
		 * Returns whether this instance describes the TransactionBroker for the given deployment file
		 * path and unique application BindingContext. 
		 */
		private boolean isBrokerFor(BindingContext applicationContext, String fileLocation, String sessionName) {
			return (fileLocation.equalsIgnoreCase(this.fileLocation) && sessionName.equals(this.sessionName) && transactionBroker
					.getApplicationBindingContext() == applicationContext);
		}

		/**
		 * Returns whether this instance describes the TransactionBroker for the given deployment file
		 * path and unique application BindingContext. 
		 */
		private boolean isBrokerFor(BindingContext applicationContext, String fileLocation) {
			return (sessionName == null && fileLocation.equalsIgnoreCase(this.fileLocation) && transactionBroker
					.getApplicationBindingContext() == applicationContext);
		}
		
		/**
		 * Returns whether this is this instance describes the given TransactionBroker
		 */
		private boolean isBrokerFor(TransactionBroker transactionBroker) {
			return transactionBroker == this.transactionBroker;
		}

		private TransactionBroker getTransactionBroker() {
			return transactionBroker;
		}

		private String getFileLocation() {
			return this.fileLocation;
		}

		private String getSessionName() {
			return this.sessionName;
		}

		private boolean isThreeTierBroker() {
			return this.isThreeTier;
		}
	}
}
