package oracle.adf.model.generic.toplink;

// JDK
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

// ADF
import oracle.adf.model.BindingContext;
import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;

//TopLink
import oracle.toplink.sessionbroker.SessionBroker;
import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;


/**
 * 
 * <b>Purpose<b>: Transactional unti used by all TopLinkDataControls that share common deployment resources in a given
 * application context<p>
 * <b>Description<b>: Defines the transactional behavior and boundaries for a given instance of a TopLink application
 * in ADF and brokers these transactional properties between all TopLinkDataControls in this application instance.
 * This transactional behavior includes operations such as: create, delete, update, query execution, commit, and 
 * rollback.  The transactional boundaries of a given application are defined by the application BindingContext 
 * instance and extend to all TopLinDataControl which share a common binding context and TopLink deployment and
 * data access resources.  
 * 
 * @see oracle.adf.model.BindingContext
 * @see oracle.adf.model.generic.toplink.DataControlFactoryImpl
 * @see oracle.adf.model.generic.toplink.TopLinkDataControl
 * @version 10.1.2
 * @deprecated - TopLink Data Controls created with 10.1.3 ADF, will no longer use 
 * these classes.
 */
public class TransactionBroker
{
	/** 
	 * Defines this TransactionBroker as three tier 
	 * user of a TopLink ClientSession per application instance. 
	 */
	protected static final int CLIENT_SESSION_TYPE = 1;
	/** 
	 * Defines this instance as a three tier user of a TopLink Client SessionBroker
	 * per application instance. 
	 */
	protected static final int CLIENT_SESSION_BROKER_TYPE = 2;
	/** 
	 * Defines this TransactionBroker as using a shared SessionBroker 
	 * across all application instances.
	 */
	protected static final int SHARED_SESSION_BROKER_TYPE = 3;
	/** 
	 * Defines this TransactionBroker as using a shared DatabaseSession 
	 * across all application instances.
	 */
	protected static final int SHARED_DATABASE_SESSION_TYPE = 4;
	/** 
	 * Defines this TransactionBroker as using a DatabaseSession 
	 * per application instance.
	 */
	protected static final int ISOLATED_DATABASE_SESSION_TYPE = 5;
	/** Current TopLink Session for this transaction */
	private Session session;
	/** Current UnitOfWork for this transaction */
	private UnitOfWork unitOfWork;
	/** Parent PersistenceManager */
	private PersistenceManager persistenceManager;
	/** All TopLinkDataControl instances associated with this TransactionBroker */
	private Collection associatedDataControls;
	/** The application instances binding context used as a unique identifier for this application */
	private BindingContext applicationBindingContext;
	/** The type of TransactionBroker */
	private int brokerType;
 	 /** determine if deletes should be performed first upon commit */
 	 boolean shouldPerformDeletesFirst;

	/**
	 * Creates a new TransactionBroker instance.
	 * 
	 * @param applicationBindingContext - BindingContext unique to this application instance.
	 * @param session - TopLink Session for this application instance.
	 * @param persistenceManager - PersistenceManager for all application instances.
	 * @param brokerType - describes the mode of operation with regards to the underlying TL Session.
   	 * @param shouldPerformDeletesFirst - determines whether the UnitOfWork in this TransactionBroker should perform deletes first pn commit.
	 */
	protected TransactionBroker(BindingContext applicationBindingContext, Session session, PersistenceManager persistenceManager,
			int brokerType, boolean shouldPerformDeletesFirst) {
		super();
		initialize(applicationBindingContext, session, persistenceManager, brokerType, shouldPerformDeletesFirst);
	}
	
	/**
	 * Initializes based constructor parameters.
	 */
	protected void initialize(BindingContext applicationBindingContext, Session session, PersistenceManager persistenceManager,
			int brokerType, boolean shouldPerformDeletesFirst) {
		this.associatedDataControls = new Vector();
		this.applicationBindingContext = applicationBindingContext;
		this.session = session;
		this.persistenceManager = persistenceManager;
		this.brokerType = brokerType;
    		this.shouldPerformDeletesFirst = shouldPerformDeletesFirst;
		// acquires and configures UOW.
    		resetUnitOfWork();
	}
	
	/**
	 * Commits the transaction for all TopLinkDataControls associated with this TransactionBroker.
	 * Also resets the transactional state as being commited for all TopLinkDataControls 
	 * that are associated with this TransactionBroker.
	 */
	protected synchronized void commitTransaction() {
		Diagnostic.println("TOPLINK ADF: Calling TopLink.commit");
		this.unitOfWork.commitAndResume();
		notifyTransactionCommitted();
	}
	
	/**
	 * Rollback the transaction for all TopLinkDataControls associated with this TransactionBroker. 
	 * Also resets the transactional state as being rolled back for all TopLinkDataControls 
	 * that are associated with this TransactionBroker.
	 */
	protected synchronized void rollbackTransaction() {
		Diagnostic.println("TOPLINK ADF: Calling TopLink.rollback");
    	this.unitOfWork.revertAndResume();
    	notifyTransactionRolledback();
	}

  	/**
	 * Resets the transaction for all TopLinkDataControls associated with this TransactionBroker. Also
	 * resets the transactional state as being rolled back for all TopLinkDataControls that are 
	 * associated with this TransactionBroker.
	 */
  	protected synchronized void resetState() {
    		Diagnostic.println("TOPLINK ADF: Calling TopLink.resetState");
    		resetUnitOfWork();
    		notifyStateReset();
  	}

	/**
	 * Notifies all TopLinkDataControls associated with this application and TL transactional resources
	 * that the transaction has been commited.
	 */
	protected void notifyTransactionCommitted() {
		for (Iterator dataControlIter = associatedDataControls(); dataControlIter.hasNext();) {
			TopLinkDataControl dataControl = (TopLinkDataControl) dataControlIter.next();
			dataControl.commitPerformed();
		}
	}

	/**
	 * Notifies all TopLinkDataControls associated with this application and TL transactional resources
	 * that the transaction has been rolled back.
	 */
	protected void notifyTransactionRolledback() {
		for (Iterator dataControlIter = associatedDataControls(); dataControlIter.hasNext();) {
			TopLinkDataControl dataControl = (TopLinkDataControl) dataControlIter.next();
			dataControl.rollbackPerformed();
		}
	}

	/**
	 * Notifies all TopLinkDataControls associated with this application and TL transactional resources
	 * that the transactional state has been reset.
	 */
  	protected void notifyStateReset() {
    		for (Iterator dataControlIter = associatedDataControls(); dataControlIter.hasNext();) {
			TopLinkDataControl dataControl = (TopLinkDataControl) dataControlIter.next();
			dataControl.resetStatePerformed();
    		}
  	}

	/**
	 * Resets the transactional resources for this TransactionalBroker instance and notifies all
	 * associated TopLinkDataControls of that the transactional state has been reset.  Specifically,
	 * the TopLink UnitOfWork is reset to a new instance and all DC instances(and associated RSIs) 
	 * are brought back to their initial state.
	 */
	protected synchronized void resetTransactionalResources() {
		resetUnitOfWork();
		for (Iterator dcs = associatedDataControls(); dcs.hasNext();) {
			TopLinkDataControl dc = (TopLinkDataControl) dcs.next();
			dc.transactionalResourcesReset();
		}
	}

	/**
	 * Creates and configures a new TopLink UnitOfWork from the client Session.
	 * If a UnitOfWork exists already then all working copies in use must be
	 * replaced with new working copies.
	 */
	protected  void resetUnitOfWork() {
		if (unitOfWork != null) unitOfWork.release();
		unitOfWork = session.acquireUnitOfWork();
		unitOfWork.setShouldPerformDeletesFirst(shouldPerformDeletesFirst);
	}

	/**
	 * Registers the given object in this transaction.
	 * 
	 * @return - the working copy of the object. 
	 */
	protected Object registerInTransaction(Object object) {
		return this.unitOfWork.registerObject(object);
	}

	/**
	 * Creates a new object instance based upon the given class type
	 * to be created in this transaction.  This does not assign a sequence
	 * number in the case where the newly created object uses sequencing.
	 * 
	 * @return the working copy of the newly created object.
	 */
  	protected Object createNewInstance(Class objectType) {
		return this.unitOfWork.newInstance(objectType);
	}

	/**
	 * Creates a new object instance based upon the given class type
	 * to be created in this transaction.
	 * 
	 * @param objectType - type of object.
	 * @param assignSequenceNumber - should assign a sequence number in the
	 * case where sequencing is used with the associated object type.
	 * @return the working copy of the newly created object.
	 */
	protected Object createNewInstance(Class objectType, boolean assignSequenceNumber) {
		Object newObject = this.unitOfWork.newInstance(objectType);
		if (assignSequenceNumber){
			this.unitOfWork.assignSequenceNumber(newObject);
		}
		return newObject;
	}
	






	/**
	 * Marks the given object to be deleted in this transaction.
	 * 
	 * @return the working copy of the deleted object.
	 */
	protected Object deleteObject(Object objectToRemove) {
		return this.unitOfWork.deleteObject(objectToRemove);
	}

	/**
	 * Handles the releasing behavior that occurs when associated TopLinkDataControls are released
	 * from the binding container and subsequent application server (typically during application timeout
	 * or shutdown).  For each TopLinkDataControl that this method is invoked on, they are disassociated 
	 * with this TransactionBroker.  Upon the last data control instance being released, the given 
	 * TransactionBroker instance destroys its TL Session(in the Client Session case) and UnitOfWork as well
	 * as removing itself from the PersistenceManager.
	 */
	protected synchronized void release(TopLinkDataControl dataControl) {
		removeDataControl(dataControl);
		if (associatedDataControls.isEmpty()) {
			Exception lastExceptionEncountered = null;
			try {
				releaseUnitOfWork();
			} catch (Exception e) {
				lastExceptionEncountered = e;
			}
			try {
				releaseSession();
			} catch (Exception e) {
				lastExceptionEncountered = e;
			}
			getPersistenceManager().removeTransactionBroker(this);
			if (lastExceptionEncountered != null) {
				throw new JboException(lastExceptionEncountered);
			}
		}
	}

	/**
	 * Releases the UnitOfWork for this broker.
	 */
	protected void releaseUnitOfWork() {
		this.unitOfWork.release();
		this.unitOfWork = null;
	}

	/**
	 * Releases the TL Session and performs a logout if necessary.
	 */
	protected void releaseSession() {
		switch (brokerType) {
			case CLIENT_SESSION_TYPE :
				this.session.release();
				break;
			case CLIENT_SESSION_BROKER_TYPE :
				((SessionBroker) this.session).releaseClientSessionBroker();
				break;
			case ISOLATED_DATABASE_SESSION_TYPE :
				DatabaseSession dbSession = (DatabaseSession) this.session;
				if (dbSession.isInTransaction()) {
					dbSession.rollbackTransaction();
				}
				dbSession.logout();
				dbSession.release();
				break;
			case SHARED_DATABASE_SESSION_TYPE :
			case SHARED_SESSION_BROKER_TYPE :
			default:
			// do nothing
		}
		this.session = null;
	}

	/**
	 * Executes the default TopLink "read all" query for the given class. 
	 *	
	 * @return result set from read all query.
	 */
	protected Object executeReadAllQuery(Class javaClass) {
		return this.unitOfWork.readAllObjects(javaClass);
	}

	/**
	 * Executes the defined TopLink query based upon the given class, query name, 
	 * and parameters.
	 * 
	 * @return results of the query. 
	 */
	protected Object executeQuery(Class beanClass, String queryName, Vector queryParameters) {
		return this.unitOfWork.executeQuery(queryName, beanClass, queryParameters);
	}

	/**
	 * Adds a TopLinkDataControl to be managed by this TransactionBroker.
	 */
	protected void addDataControl(TopLinkDataControl dataControl) {
		this.associatedDataControls.add(dataControl);
	}

	/**
	 * Removes a TopLinkDataControl from being managed by this TransactionBroker.
	 */
	protected void removeDataControl(TopLinkDataControl dataControl) {
		this.associatedDataControls.remove(dataControl);
	}

	/**
	 * Determines whether a TopLinkDataControl is being managed by this TransactionBroker.
	 */
	protected boolean isDataControlRegistered(TopLinkDataControl dataControl) {
		return this.associatedDataControls.contains(dataControl);
	}

	/**
	 * Returns an Iterator over all TopLinkDataControls that are a client of this TransactionBroker.
	 */
	protected  Iterator associatedDataControls() {
		return this.associatedDataControls.iterator();
	}

	/**
	 * Returns the PersistenceManager that this TransactionBroker is associated with.
	 */
	protected  PersistenceManager getPersistenceManager() {
		return persistenceManager;
	}

	/**
	 * Returns the application BindingContext associated with this TransactionBroker.
	 */
	protected BindingContext getApplicationBindingContext() {
		return applicationBindingContext;
	}
  
  	/**
  	 *  Returns the UnitOfWork associated with this transaction.
 	 */
  	protected UnitOfWork getUnitOfWork()  {
    		return this.unitOfWork;
  	}
  
	/**
	  * Returns the Session associated with this transaction.
	  */
  	protected Session getSession() {
    		return this.session;
  	}
}
