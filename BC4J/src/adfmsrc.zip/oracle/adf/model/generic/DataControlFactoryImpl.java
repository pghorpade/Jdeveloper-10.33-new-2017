package oracle.adf.model.generic;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import oracle.adf.model.DataControl;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import oracle.adf.model.DataControlFactory;
import oracle.adf.model.BindingContext;
import oracle.jbo.uicli.mom.JUTags;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCDataControlDef;

import oracle.jbo.common.NamedObjectImpl;
import oracle.jbo.uicli.mom.JUMetaObjectManager;


public class DataControlFactoryImpl implements DataControlFactory 
{
   public DataControlFactoryImpl()
   {
   }
   
   public DataControl createSession(BindingContext ctx, Node node, Map appParams)
   {
      String sName;

      if(node.getAttributes().getNamedItem(JUTags.NAME) != null)
          sName = node.getAttributes().getNamedItem(JUTags.NAME).getNodeValue();
      else
          sName = node.getAttributes().getNamedItem(JUTags.ID).getNodeValue();
      
      Node beanNode = node.getAttributes().getNamedItem(JUTags.BeanClass);
      if (beanNode == null)
      {
         beanNode = node.getAttributes().getNamedItem(JUTags.DefinitionClass);
      }
      String beanName = (beanNode != null) ? beanNode.getNodeValue() : null;

      NodeList list = node.getChildNodes();
      HashMap  parameters = new HashMap(10);
      Node childNode, paramNode;
      ArrayList containers = new ArrayList();
      NamedObjectImpl ctr;
      for(int i = 0; i < list.getLength(); i++)
      {
         childNode = list.item(i);
         if (childNode.getNodeName().equalsIgnoreCase(JUTags.Parameters))
         {
            NodeList paramList = childNode.getChildNodes();
            for (int j=0; j < paramList.getLength(); j++)
            {
               paramNode = paramList.item(j);
               String sParamName = paramNode.getAttributes().getNamedItem("name").getNodeValue(); //NONLS
               String sValue = paramNode.getAttributes().getNamedItem("value").getNodeValue();    //NONLS
               parameters.put(sParamName, sValue);
            }
         }
      }
      parameters.put(JUTags.BeanClass, beanName);
      DataControl dc = createSession(ctx, sName, appParams, parameters);
      if(dc instanceof DCDataControl) 
      {
         for (int i = 0; i < containers.size(); i++)
         {
            ctr = (NamedObjectImpl)containers.get(i);
            ((DCDataControl)dc).addBindingContainerRef(ctr);
         }
      }
      return dc;
   }

   public DataControl createSession(BindingContext ctx, String sName, Map appParams, Map parameters)
   {
      try
      {
         //use newInstance().
         String beanClass = (String)parameters.get("BeanClass");
         if(beanClass == null) 
         {
            beanClass = (String)parameters.get("Definition");
         }

         Object bean = oracle.jbo.common.JBOClass.forName(beanClass).newInstance();
         DCGenericDataControl app = createDataControl(sName, beanClass, bean, true);
         JUMetaObjectManager.getJUMom().addApplication(app);
         app.initDCProperties(sName, ctx, parameters, beanClass, bean);
         return app;
      }
      catch (Exception e)
      {
         throw new oracle.jbo.JboException(e);
      }
   }

   /**
    *  Override this method to supply custom generic-based data control
    */
   protected DCGenericDataControl createDataControl( String name, String beanClass, Object beanInstance, boolean root )
   {
      //return new DCGenericDataControl(name, beanClass, beanInstance, root);
      return new DCGenericDataControl();
   }
}
