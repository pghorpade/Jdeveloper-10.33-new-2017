/*
 * @(#)AttributeDefImpl.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;

import oracle.jbo.mom.xml.DefElement;

import oracle.jbo.common.AttributeDefHelper;
import oracle.adf.model.binding.DCDataControl;

import java.util.ArrayList;
import java.util.Map;

/**
 * The AttributeDefHelper class implement the AttributeDef interface
 *
 * @see RowImpl
 *
 * @version INTERNAL
 */
public class AccessorDefImpl extends StructureDefImpl 
{
   private static String PName_AddMethod = "AddMethod";
   private static String PName_RemoveMethod = "RemoveMethod";

   private String mAddMethodName = null;
   private String mRemoveMethodName = null;

   public AccessorDefImpl(DCDataControl app, String sDefName, String sName) 
   {
      super(app, sDefName, sName);
   }

   void loadFromXML(DefElement elem)
   {
      String fieldType = elem.getAttribute(PName_FieldType);
      if (fieldType != null && fieldType.length() == 0)
      {
         fieldType = null;
      }

      String elementType = elem.getAttribute(PName_ArrayElementType);
      if (elementType != null && elementType.length() == 0)
      {
         elementType = null;
      }

      String isCollection = elem.getAttribute(PName_IsCollection);
      boolean isCollectionB = false;
      if (isCollection != null && isCollection.length() > 0)
      {
         isCollectionB = isCollection.equals("true"); //NONLS
      }

      init(mBeanClassName, fieldType, elementType, isCollectionB);

      com.sun.java.util.collections.ArrayList attributes = elem.getChildrenList(PName_Attribute);  //NONLS
      if (attributes != null && attributes.size() > 0)
      {
         //Scalar value Array
         loadAttributes(elem);
         loaded = true;
      }
      loadProperties(elem);

      mAddMethodName = elem.getAttribute(PName_AddMethod);
      if (mAddMethodName != null && mAddMethodName.length() == 0)
      {
         mAddMethodName = null;
      }

      mRemoveMethodName = elem.getAttribute(PName_RemoveMethod);
      if (mRemoveMethodName != null && mRemoveMethodName.length() == 0)
      {
         mRemoveMethodName = null;
      }

   }

   void init(String beanClass, String fieldType, String elementType
      , boolean isCollection)
   {
      mBeanClassName = beanClass;

      setFieldType(fieldType);
      setArrayElementType(elementType);
      setIsCollection(isCollection); //NONLS

      if (beanClass == null)
      {
         setElementsScalar();
      }

      if (loaded && !isElementsScalar()) 
      {
         //this is a reference to a StructureDef in mom.
         try
         {
            referToMOMStructureDef(beanClass);
         }
         catch (oracle.jbo.NoDefException nde)
         {
            //ignore.
            //not in mom. this is a dynamic structuredef or a scalar one.
         }
      }
   }

   public String getAddMethodName()
   {
      return mAddMethodName;
   }

   public String getRemoveMethodName()
   {
      return mRemoveMethodName;
   }
}
