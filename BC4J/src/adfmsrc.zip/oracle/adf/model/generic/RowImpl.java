/*
 * @(#)RowImpl.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;


import java.util.Map;
import java.util.BitSet;
import java.util.ArrayList;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttrValException;
import oracle.jbo.InvalidParamException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.ReadOnlyAttrException;
import oracle.jbo.Row;
import oracle.jbo.StructureDef;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.domain.TypeFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import oracle.adf.model.ADFmMessageBundle;

/**
 * The RowImpl class is used to access the data inside a row using the Row interface
 *
 * @see AttributeDef
 *
 * @version INTERNAL
 */
public class RowImpl implements Row
{
   // Member variables

   private DCRowSetIteratorImpl mRSI;
   private BitSet       mChanged = null;
   private int          mChangedCount = 0;  // Keep track of the number of attribute changed
   private int          mPKChangedCount = 0;
   private Object       mRowDataProvider;
   private Key          mCachedKey;

   static final int PS_NEW     = 0; // for new rows
   static final int PS_CLEAN   = 1; // for unchanged rows
   static final int PS_MODIFIED= 2; // for changed rows
   static final int PS_DELETED = 3; // for deleted rows
   static final int PS_DEAD    = 4; // for dead rows
   static final int PS_LAZY    = 5; // for lazy retrieval
   private int      mRowState = PS_CLEAN;

   private static final int DEFAULT_NUM_CHANGED_BITS = 4;

   static final byte PROVIDER_MAP = 0;
   static final byte PROVIDER_BEAN = 1;
   static final byte PROVIDER_SCALAR = 2;
   private byte mProviderType = PROVIDER_MAP;

   
   final boolean isProviderMap()
   {
      return mProviderType == PROVIDER_MAP;
   }
   
   protected RowImpl (Object rowDataProvider, DCRowSetIteratorImpl rowSetIterator)
   {
      if (rowDataProvider == null) 
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Fatal Error: Creating a row over Null bean or map will lead to NPEs");
         }
         throw new InvalidParamException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_NULL_BEAN_FOR_ROW,
                                         new Object[] {rowSetIterator.getStructureDef().getFullName()});
      }
      
      mRowDataProvider = rowDataProvider;
      mRSI             = rowSetIterator;

      mPKChangedCount = 0;

      //if (!((StructureDefImpl)rowSetIterator.getStructureDef()).isElementsScalar())
      {
         mProviderType = (rowDataProvider instanceof Map) ? PROVIDER_MAP : PROVIDER_BEAN;
      }
      /*
      else
      {
         mProviderType = PROVIDER_SCALAR;
      }
      */
   }

   public boolean equals(Object obj)
   {
      if (obj instanceof RowImpl)
      {
         RowImpl other = (RowImpl)obj;
         if (mRowDataProvider != null && other.mRowDataProvider != null && mRowDataProvider.equals(other.mRowDataProvider))
         {
            return true;
         }
      }
      return super.equals(obj);
   }

   boolean belongsTo(Object obj)
   {
      return (obj == mRSI);
   }

   /**
    * Returns the data for the attribute at the given index.
    *
    * @param index attribute index
    * @return The value of the attribute
    */
   public Object getAttribute(int index)
   {
      return internalGetAttributeValue(getStructureDef().getAttributeDef(index));
   }

   
   /**
    * Returns the data for the attribute with the given name.
    *
    * @param name attribute name
    * @return The value of the attribute
    */
   public Object getAttribute(String name)
   {
      AttributeDef ad = getStructureDef().findAttributeDef(name);
      if (ad != null)
      {
         return internalGetAttributeValue(ad);
      }
      return null;
   }
   
   private Object internalGetAttributeValue(AttributeDef ad)
   {
      Object retVal;

      String name = ad.getColumnName();
      switch (mProviderType)
      {
         case PROVIDER_MAP:
            retVal =  ((Map)mRowDataProvider).get(name);
            break;

         case PROVIDER_SCALAR:
            retVal =  mRowDataProvider;
            break;
         
         case PROVIDER_BEAN:
         default:
            retVal =  BeanUtils.getProperty(mRowDataProvider, name);
            break;
      }
      
      Class type = ad.getJavaType();
      if (type != null) 
      {
         retVal = TypeFactory.convertAttributeValueToType(ad, ad.getJavaType(), retVal, 
                                           AttrValException.TYP_ATTRIBUTE_LIST_WITH_DEF, 
                                           ""); //not passing any name. what name could be passed?
      }
      return retVal;
   }

   
   public boolean isAttributeUpdateable(int index)
   {

      StructureDef def = getStructureDef();
      if (def instanceof StructureDefImpl)
      {
         //for now scalar elements are readonly.
         if (((StructureDefImpl)def).isElementsScalar())
         {
            AttributeDef defs[] = def.getAttributeDefs();
            if (defs == null && defs.length == 0) 
            {
               return false;
            }
         }
      }

      if (def != null)
      {
         AttributeDef attr = def.getAttributeDef(index);
         switch(attr.getUpdateableFlag())
         {
            case AttributeDef.UPDATEABLE_WHILE_NEW:
               return mRowState == PS_NEW;

            case AttributeDef.UPDATEABLE:
               return true;
         }
      }
      return false;
   }

   public boolean isDead()
   {
     return false;
   }
   
   public StructureDef getStructureDef()
   {
      return mRSI.getStructureDef();
   }
   
   
   /**
    * Set the value for an attribute at a given index.
    *
    * @param index The attribute index.
    * @param value The value.
    */
   public void setAttribute(int index, Object value)
   {
      internalSetAttributeValue(getStructureDef().getAttributeDef(index), value);
   }

   /**
    * Set the value for an attribute with a given name.
    *
    * @param name The attribute name.
    * @param value The value.
    */
   public void setAttribute(String name, Object value)
   {
      internalSetAttributeValue(getStructureDef().findAttributeDef(name), value);
   }
   
   final void internalSetAttributeValue(AttributeDef ai, Object value)
   {
      String accName = ai.getColumnName();
      Class javaType = ai.getJavaType();
      String name = ai.getName();

      if (!isAttributeUpdateable(ai.getIndex()))
      {
         throw new ReadOnlyAttrException(ReadOnlyAttrException.TYP_DEF_ANY,
                                         ADFmMessageBundle.class,
                                         ADFmMessageBundle.EXC_VAL_ATTR_SET_FAILED,
                                         mRSI.getName(),
                                         name);
      }

      try
      {
         if (mChanged == null)
         {
            mChanged = new BitSet(DEFAULT_NUM_CHANGED_BITS);
         }

         Object newValue = null;
         if (value != null)
         {
            try
            {
               newValue = TypeFactory.convertAttributeValueToType(ai, javaType, value, 
                                                 AttrValException.TYP_ATTRIBUTE_LIST_WITH_DEF, 
                                                 ""); //not passing any name. what name could be passed?
                                                      
               ((AttributeDefImpl)ai).validate(this, newValue);

            }
            catch (JboException jboe)
            {
               jboe.setNeedsEntityToVOMapping(false); 
               throw jboe;
            }
         }

         lock();

         if (ai instanceof AttributeDefImpl) 
         {
            Class sourceType = ((AttributeDefImpl)ai).getColumnType();
            if (javaType != sourceType) 
            {
               newValue = TypeFactory.convertAttributeValueToType(ai, sourceType, value, 
                                                 AttrValException.TYP_ATTRIBUTE_LIST_WITH_DEF, 
                                                 ""); //not passing any name. what name could be passed?
                                                      
            }
         }

         if (mProviderType == PROVIDER_SCALAR)
         {
            mRowDataProvider = newValue;
         }
         else
         {
            /*
            switch (mProviderType)
            {
               case PROVIDER_MAP:
                  ((Map)mRowDataProvider).put(accName, newValue);
               break;

               case PROVIDER_SCALAR:
                  //((StructureDefImpl)getStructureDef()).setElementModified(true);
                  mRowDataProvider = newValue;
               break;

               default:
                  BeanUtils.setProperty(mRowDataProvider, accName, newValue);
            }
            */
            mRSI.setAttributeValue(this, accName, newValue);
         }

         if (ai.isPrimaryKey())
         {
            resetKey();
         }
      }
      catch(oracle.jbo.domain.DataCreationException dce)
      {
         dce.setAttrInfo(JboException.TYP_VIEW_OBJECT, 
                            mRSI.getName(), 
                            name,
                            value);
         throw dce;
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Exception ex)
      {
         throw new JboException(ex);
      }

      int idx = ai.getIndex();
      if (!mChanged.get(idx))
      {
         mChanged.set(idx);
         mChangedCount++;

         if (ai != null && ai.isPrimaryKey())
         {
            mPKChangedCount++;
         }
      }
      mRSI.notifyRowUpdated(this, mRSI.getRangeIndexOf(this), new int[]{idx});
   }

   /**
    * Get the attribute count
    *
    */
   public int getAttributeCount()
   {
      return getStructureDef().getAttributeCount();
   }
   
   
   /**
    * Get the index for an attribute given the name
    *
    * @param name The attribute name
    * @return numerical index for given attribute name
    */
   public int getAttributeIndexOf(String name)
   {
      //return findAttributeDef(name).getIndex();
      //bean introspection to get index of attribute.
      return getStructureDef().findAttributeDef(name).getIndex();
   }
   
   
   public String[] getAttributeNames()
   {
      String[] retVal = new String[getAttributeCount()];
      AttributeDef[] attrs = getStructureDef().getAttributeDefs();
      for (int j = 0; j < attrs.length; j++)
      {
         retVal[j] = attrs[j].getName();
      }
      return retVal;
   }
   
   
   public Object[] getAttributeValues()
   {
      Object[] retVal = new Object[getAttributeCount()];
      for (int j = 0; j < retVal.length; j++)
      {
         retVal[j] = getAttribute(j);
      }

      return retVal;
   }
   

   /**
    * @return  The ApplicationModule this Row belongs
    */
   public ApplicationModule getApplicationModule()
   {
      //do we need this method? 
      //what would be the ApplicationModule in the case of non-bc4j apps?
      return null;
   }
   
   
   /**
    * Returns the key of the row.
    *
    * @return The key object
    */
   public Key getKey()
   {
      if (mCachedKey == null && mRSI != null)
      {
         StructureDef def = getStructureDef(); 
         if (def instanceof StructureDefImpl)
         {
            StructureDefImpl defImpl = (StructureDefImpl)def;
            ArrayList al = defImpl.getKeyAttrsList();
            int size = al.size();
            if (size > 0)
            {
               Object[] objs = new Object[size];
               while (size > 0) 
               {
                  objs[--size] = getAttribute(((AttributeDef)al.get(size)).getName());
               }
   
               mCachedKey = new Key(objs);
            }

            /*
            if (mCachedKey == null)
            {
               //use defName in the key as well to avoid Key conflicts between Keys of two types.
               //e.g. Key from Dept with index 1 should not conflict with Key from Emp with index 1.
               mCachedKey = new Key(new Object[]{new Integer(getRowIndex()), defImpl.getDefName()}); 
            }
            */
         }
         if (mCachedKey == null)
         {
            mCachedKey = new Key(new Object[]{new Integer(getRowIndex())}); 
         }
      }

      return mCachedKey;
   }

   /**
    * Call this if the correpsonding dataProvider row object has a change
    * in key object values. This will force a recalculation of the row key.
    */
   public void resetKey()
   {
      mCachedKey = null;
   }

   int getRowIndex()
   {
      if (mRSI.getCurrentRow() == this)
      {
         return mRSI.getCurrentRowIndex();
      }
      
      int start = mRSI.getRangeStart();
      int rangeIndex = mRSI.getRangeIndexOf(this);
      return (start <= 0) ? rangeIndex : rangeIndex + start;
   }
   
   /**
    * Invoke validate method for the validators attached to this Row
    *
    */
   public void validate()
   {
       //no errors generated
   }

   
   /**
    * Revert the row to the Database state.
    *
    **/
   public void revert()
   {
      throw new UnsupportedOperationException("revert()");
   }


   public void refresh(int refreshMode)
   {
      throw new UnsupportedOperationException("refresh()");
   }

   
   /**
    * Acquire the row provider data to be modified in this transaction space.
    * Calls DataControl.registerDataProvider(row.getDataProvider());
    **/
   public void lock()
   {
      //give a chance to models to register the dataProvider as being dirtied
      //so that they can commit them.
      mRowDataProvider = mRSI.mApp.registerDataProvider(new DCGenericRowContext(this, mRSI, mRSI.getStructureDef(), null));
   }
   

   /**
    * Delete the row.
    *
    **/
   public void remove()
   {
      mRSI.doRemoveRow(this, true);
   }
   

   public void removeFromCollection()
   {
      mRSI.doRemoveRow (this, false);
   }
   

   public void removeAndRetain()
   {
      mRSI.doRemoveRow (this, false);
   }
   

   final void _setState(int st, DCGenericRowSetIteratorImpl srcRSI)
   {
      mRowState = st;
      
      // dirty the RowSetImpl
      /*
      if (mRowState != PS_CLEAN && mRowState != PS_LAZY)
      {
         srcRSI.setChanged(this, true);
      }
      */
   }
   
   public Node writeXML(long options, com.sun.java.util.collections.HashMap voAttrMap)
   {
      throw new UnsupportedOperationException("writeXML()");
   }

   
   public Node writeXML(int depthCount, long options)
   {
      throw new UnsupportedOperationException("writeXML()");
   }

   
   public void readXML(Element elem, int depthCount)
   {
      throw new UnsupportedOperationException("readXML()");
   }

   
   public Node writeXML(long options, com.sun.java.util.collections.HashMap voAttrMap, oracle.xml.parser.v2.XSLStylesheet xslt)
   {
      throw new UnsupportedOperationException("writeXML()");
   }

   
   public Node writeXML(int depthCount, long options, oracle.xml.parser.v2.XSLStylesheet xslt)
   {
      throw new UnsupportedOperationException("writeXML()");
   }

   
   public void readXML(Element elem, int depthCount, oracle.xml.parser.v2.XSLStylesheet xslt)
   {
      throw new UnsupportedOperationException("readXML()");
   }

   public void setNewRowState(byte state)
   {
      //noop.
   }

   public Object getDataProvider()
   {
      return mRowDataProvider;
   }

}
