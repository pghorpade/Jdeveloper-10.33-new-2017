package oracle.adf.model.generic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

/*
//commenting out the adf.model interfaces and bringing in
//the jsr ones. We could swap these at a later time.
import oracle.adf.model.TransactionalDataControl;
import oracle.adf.model.ManagedDataControl;
import oracle.adf.model.DataControl;
*/
import oracle.binding.TransactionalDataControl;
import oracle.binding.UpdateableDataControl;
import oracle.binding.ManagedDataControl;
import oracle.binding.DefinitionProviderDataControl;
import oracle.binding.DataControl;

import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.Definition;

import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCBindingContainerDef;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.binding.DCInvokeMethod;
import oracle.adf.model.binding.DCMethodParameter;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.AttributeDef;
import oracle.jbo.CriteriaAdapter;
import oracle.jbo.CriteriaClauses;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.InvalidParamException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowMatch;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.SortCriteria;
import oracle.jbo.ViewCriteria;
import oracle.jbo.domain.TypeFactory;

import oracle.jbo.common.CommonCriteriaAdapter;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.format.Formatter;

import oracle.jbo.uicli.mom.JUApplicationDefImpl;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUAccessorIteratorDef;
import oracle.jbo.uicli.binding.JUMethodIteratorDef;

public class DCGenericDataControl extends DCDataControl
{
   protected HashMap mStructureDefs;  //defName based.
   protected HashMap mRSIs;           //Accessor Name based.
   protected StructureDefImpl mDef;
   public static String DC_ROOT_ACC_NAME = "root"; //NONLS
   private TransactionalDataControl mTxnAdapter;
   private UpdateableDataControl mUpdateAdapter;
   private ManagedDataControl mManagedAdapter;
   private DefinitionProviderDataControl mDefinitionAdapter;
   private DataControl mAdapter;
   private CriteriaAdapter mCriteriaAdapter;

   class CriteriaAdapterImpl extends CommonCriteriaAdapter implements oracle.jbo.CriteriaAdapter
   {
      LocaleContext mLctx;
      CriteriaAdapterImpl(LocaleContext lctx)
      {
         mLctx = lctx;
      }

      public String getCriteriaClause(ViewCriteria vc)
      {
         return super.getCriteriaClause(vc.getStructureDef().getAttributeDefs(), vc);
      }

      protected Object formatAttributeValue(ViewCriteria vc, AttributeDef curDef, String valString)
      {
         Object val = valString;
         try
         {
            AttributeDefImpl adImpl = ((AttributeDefImpl)curDef);
            
            val = adImpl.parseFormattedAttribute(valString, mLctx);
            if (adImpl.hasFormatInformation(mLctx))
            {
               Formatter formatter = adImpl.getFormatter(mLctx);
               // JRS 11/24/2003 Replaced format("yyyy-MM-dd", val) with below.
               // bug 3271064.  Only the DefaultDateFormatter now implements
               // the "yyyy-MM-dd" string.
               val = formatter.format(formatter.getDefaultFormatString(), val);
            }
         }
         catch (Exception e)
         {
            //ignore. this will revert to 904 behavior.
         }
         return val;

      }
   }


   /**
    * Subclasses calling this constructor should then override and call initDCProperties method 
    * as well to initialize the datacontrol properties.
    */
   protected DCGenericDataControl()
   {
   }

   /**
    * Subclasses calling this constructor should then override and call initDCProperties method 
    * as well to initialize the datacontrol properties.
    */
   protected DCGenericDataControl(String name)
   {
     setName(name);
   }

   public DCGenericDataControl(String name, String beanClass, Object beanInstance)
   {
      this(name, beanClass, beanInstance, false);
   }

   public DCGenericDataControl(String name, String beanClass, Object beanInstance, boolean root)
   {
      super(root, null);
      initDCProperties(name, null, null, beanClass, beanInstance);
   }

   /**
    * this may get called twice - once from constructor (optionally) and once from factory.
    */
   protected void initDCProperties(String name, 
                       BindingContext ctx, //bindingContext in which this DC is created.
                       Map dcDefAsParams,  //should be JUApplicationDefImpl to be set.
                       String beanClass,   //bean Class that leads to StructureDef for this DC.
                       Object beanInstance) //bean Instance if already realized.
   {
      setName(name);

      if (beanInstance instanceof DataControl)
      {
         DataControl adapter = (DataControl)beanInstance;

         mAdapter = adapter;

         if (adapter instanceof UpdateableDataControl)
         {
            mUpdateAdapter = (UpdateableDataControl)adapter;
         }
         if (adapter instanceof TransactionalDataControl)
         {
            mTxnAdapter = (TransactionalDataControl)adapter;
         }
         if (adapter instanceof ManagedDataControl)
         {
            mManagedAdapter = (ManagedDataControl)adapter;
         }
         if (adapter instanceof DefinitionProviderDataControl)
         {
            mDefinitionAdapter = (DefinitionProviderDataControl)adapter;
         }
      }
      
      if (mStructureDefs == null) 
      {
         mStructureDefs = new HashMap(20);
      }
      
      if (mDef == null) 
      {
         mDef = new StructureDefImpl(this, beanClass, DC_ROOT_ACC_NAME);
         mDef.mBeanClassName = beanClass;
      }

      mDataProvider = beanInstance;

      if (dcDefAsParams instanceof DCDataControlDef) 
      {
         setDef((DCDataControlDef)dcDefAsParams);
      }

      if (ctx != null) 
      {
         setBindingContext(ctx);
      }
      
      if (mDef != null) 
      {
         initializeRSIs();
      }
   }


   //
   //DataControl interface methods.
   ///
   public void release(int flags)
   {
      if (mAdapter != null)
      {
         mAdapter.release(flags);
      }
      super.release(flags);
   }
   public Object getDataProvider()
   {
      if (mAdapter != null)
      {
         return mAdapter.getDataProvider();
      }
      return super.getDataProvider();
   }

   protected Object invokeMethod(DCInvokeMethod method, OperationBinding action, java.util.Map paramsMap)
   {
      if (mAdapter != null)
      {
         DCInvokeMethod methodInfo = null;
         Object params[] = null;
         if (mAdapter.invokeOperation(getBindingContext(), action))
         {
            Object result = ((JUCtrlActionBinding)action).getResult();

            cacheMethodResult(method, result, params);
            return result;
         }
      }
      return super.invokeMethod(method, action, paramsMap);
   }

   public boolean invokeOperation(Map map, oracle.binding.OperationBinding action)
   {
      if (mAdapter != null)
      {
         boolean builtin = false;
         if (action instanceof JUCtrlActionBinding) 
         {
            builtin = (((JUCtrlActionBinding)action).getActionId() != JUCtrlActionBinding.ACTION_INVOKE_METHOD);
         }

         if (builtin && mAdapter.invokeOperation(map, action))
         {
            return true;
         }
      }
      return super.invokeOperation(map, action);
   }


   //
   //UpdateableDataControl methods
   //
   final UpdateableDataControl getUpdateableDataControl()
   {
      return mUpdateAdapter;
   }
  
   public boolean isTransactionDirty()
   {
      if (mTxnAdapter != null)
      {
         mTxnAdapter.isTransactionDirty();
      }
      return false;
   }

   public void commitTransaction()
   {
      if (mTxnAdapter != null)
      {
         mTxnAdapter.commitTransaction();

         // JRS Opted to leave isTransactionDirty on the update adapter.
         // this is debatable.  We could move this later.  related to
         // bug 4737504.
         super.transactionStateChanged(
            mTxnAdapter != null 
               ? mTxnAdapter.isTransactionDirty() : false);

         return;
      }
      super.commitTransaction();
   }

   public void rollbackTransaction()
   {
      if (mTxnAdapter != null)
      {
         mTxnAdapter.rollbackTransaction();

         // JRS Opted to leave isTransactionDirty on the update adapter.
         // this is debatable.  We could move this later.  related to
         // bug 4737504.
         super.transactionStateChanged(
            mTxnAdapter != null 
               ? mTxnAdapter.isTransactionDirty() : false);

         return;
      }
      super.rollbackTransaction();
   }
   public Object registerDataProvider(DCRowContext ctx)
   {
      if (mUpdateAdapter != null)
      {
         return mUpdateAdapter.registerDataProvider(ctx);
      }
      return ctx.getRowDataProvider();
   }

   public boolean removeRowData (DCRowContext ctx)
   {
      if (mUpdateAdapter != null)
      {
         setTransactionModified();
         if (mUpdateAdapter.removeRowData(ctx))
         {
            return true;
         }
         else
         {
            DCRowSetIteratorImpl rsi = (DCRowSetIteratorImpl) ctx.getRowSetIterator();
            if (rsi != null)
            {
               rsi.restoreCurrency(true);
               return true;
            }
            else
            {
               return false;
            }
         }
      }

      if (isOperationSupported(null, OPER_DATA_ROW_REMOVE))
      {
         setTransactionModified();
         return false;
      }
      else
      {
         // super throws unsupported operation exception
         return super.removeRowData(ctx);
      }
   }
   public Object createRowData (DCRowContext ctx)
   {
      if (mUpdateAdapter != null)
      {
        Object newRowData = mUpdateAdapter.createRowData(ctx);
        if (newRowData == null) 
        {
           throw new InvalidParamException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_NULL_BEAN_FOR_ROW,
                                           new Object[] {ctx.getStructureDef().getFullName()});
        }
        DCRowSetIteratorImpl rsi = (DCRowSetIteratorImpl) ctx.getRowSetIterator();
        if (rsi != null)
        {
           rsi.restoreCurrency(true);
           RowImpl r = (RowImpl)rsi.getCurrentRow();
           Object bean = (r != null) ? r.getDataProvider() : null;
           if (newRowData != bean) 
           {
              Row rows[] = rsi.getAllRowsInRange();
              for (int i = 0; i < rows.length; i++) 
              {
                 if (newRowData == ((RowImpl)rows[i]).getDataProvider()) 
                 {
                    rsi.setCurrentRow(rows[i]);
                    break;
                 }
              }
           }
        }
        setTransactionModified();
        return newRowData;
      }
      if (isOperationSupported(null, OPER_DATA_ROW_CREATE))
      {
         setTransactionModified();
         Object newRowData = ctx.getRowDataProvider();
         if (newRowData == null) 
         {
            throw new InvalidParamException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_NULL_BEAN_FOR_ROW,
                                            new Object[] {ctx.getStructureDef().getFullName()});
         }
         return newRowData;
      }
      else
      {
         return super.createRowData(ctx);
      }
   }

   public void validate()
   {
      if (mUpdateAdapter != null)
      {
         mUpdateAdapter.validate();
         return;
      }
      super.validate();
   }

   /*
   public boolean removeRowDataFromCollection (DCRowContext ctx)
   {
      if (mUpdateAdapter != null)
      {
         return mUpdateAdapter.removeRowDataFromCollection(ctx);
      }
      return true;
   }
   */
   //
   //ManagedDataControl methods.
   //
   public void beginRequest(HashMap map)
   {
      if (mManagedAdapter != null)
      {
         mManagedAdapter.beginRequest(map);
      }
      super.beginRequest(map);
   }
   public void endRequest(HashMap map)
   {
      if (mManagedAdapter != null)
      {
         mManagedAdapter.endRequest(map);
      }
      super.endRequest(map);
   }

   public boolean resetState()
   {
      if (super.resetState())
      {
         if (mManagedAdapter != null)
         {
            mManagedAdapter.resetState();
         }

         release(REL_ALL_REFS);

         return true;
      }

      return false;
   }

   //
   // DefinitionProviderDataControl interface
   //
   /**
    * Internal use only.  Application developers should not use this method.
    */
   public Definition getDefinition(String name, Class type)
   {
      if (mDefinitionAdapter != null)
      {
         return mDefinitionAdapter.getDefinition(name, type);
      }
      return null;
   }

   //
   //Implementation Details
   //

   /**
    * Internal use only.  Application developers should not extend.
    */
   protected void initializeRSIs()
   {
      //trigger first bean load.
      if (mRSIs == null)
      {
         StructureDefImpl defs[] = mDef.getAccessors();
         mRSIs = (defs != null ? new HashMap(defs.length + 3) : new HashMap(5));
         //add root to the list of RSIs.
         DCGenericRowSetIteratorImpl rootRSI =
            (DCGenericRowSetIteratorImpl)createRowSetIteratorImpl((mDef != null) ? mDef.getName() : null, mDef, null);
         mRSIs.put(DC_ROOT_ACC_NAME, rootRSI);

         if (defs != null)
         {
            DCGenericRowSetIteratorImpl[] rsis =
               new DCGenericRowSetIteratorImpl[defs.length];
            for (int i = 0; i < defs.length; i++)
            {
               // JRS Parent the root accessor RSIs with the root accessor
               // so that they may be resolved using the root accessor.
               //
               // JRS If the "root" RSI owns the root accessor RSI refs
               // then why do we bother adding the root accessor RSI refs
               // to the mRSIs hashmap?  Keeping for potential back compat.
               rsis[i] = (DCGenericRowSetIteratorImpl)createRowSetIteratorImpl(
                  defs[i].getName(), defs[i], rootRSI);
               mRSIs.put(defs[i].mName, rsis[i]);
            }
         }
      }
   }

   protected void initializeBindingContainer(DCBindingContainerDef formDef, DCBindingContainer formBnd, boolean initialize)
   {
      //initializeRSIs();
      formDef.initializeBindingContainer(this, formBnd, initialize);
   }
   /**
    * Clears the dataProvider iterator cached on the RowSet bound to given iterator binding,
    * so that the method accessor is invoked again to fetch a fresh dataProvider for
    * the association RowSet.
    */
   protected void executeIteratorBinding (DCIteratorBinding iter)
   {
      initializeRSIs();
      DCRowSetIteratorImpl impl = (DCRowSetIteratorImpl)iter.getRowSetIterator();
      //clear RSI so that it goes for the iterator again.
      if (impl != null) 
      {
         impl.clearCurrentData();
         impl.first();
      }
   }
   protected void executeIteratorBindingIfNeeded (DCIteratorBinding iter)
   {
      initializeRSIs();
      DCIteratorBindingDef iterDef = iter.getDef();
      if (iterDef != null)
      {
         //allow both method and accessor iterators to build themselves,
         //if they've not been built/made visible thus far.
         if (DCDefBase.PNAME_MethodIterator.equals(iterDef.getSubType())
           || iter.isAccessorIterator())
         {
            //go down to super to rebuild this iterator if it's
            //RSI datasource has been refetched / source method has
            //been reexecuted.
            if (iter.hasRSI())
            {
               if (iter.isAccessorIterator() && iter.allowsRefreshControl())
               {
                  DCRowSetIteratorImpl rsi = (DCRowSetIteratorImpl)iter.getRowSetIterator();
                  //this iterator may have had no rows. So if it didn't check if
                  //fetching again leads to a new iterator.
                  if (rsi.getDataProvider() == null)
                  {
                     //if the RSI had null data provider, it may have new data provider
                     //so go check (via introspection).
                     //This allows apps that set a new collection (on a null one)
                     //to work in ADF without extra notification that a collection
                     //has been created on the server side.
                     //besides this should be done only for RSIs that are 'refreshable'.
                     rsi.fetchDataSource();
                  }
               }
               else
               {
                  rebuildIteratorIfNeeded(iter);
               }
            }
            else
            {
               //this will force execute if this iterator has not been
               //executed as of now.
               iter.executeQuery();
            }
            return;
         }
      }
      if (iter.getRowSetIterator().getCurrentRowSlot() != RowIterator.SLOT_VALID)
      {
         executeIteratorBinding(iter);
      }
   }
   protected RowSetIterator getRowSetIterator(String sourceName)
   {
      initializeRSIs();
      return fetchRowSetIterator(sourceName);
   }
   private final String DOT_STR = ".";
   /*
   protected RowSetIterator findRowSetIterator(DCIteratorBindingDef iterDef)
   {
      initializeRSIs();
      return fetchRowSetIterator(iterDef.getSourceName());
   }
   */

   protected RowSetIterator fetchRowSetIterator(String path)
   {
      //jdk1.4 only.
      //String[] accNames = iterDef.getSourcePath().split(".");
      //String[] accNames = java.util.regex.Pattern.compile(iterDef.getSourcePath()).split(".", 0);
      StringBuffer strBuffer = new StringBuffer(path);
      DCGenericRowSetIteratorImpl curRsi = null;
      int index = strBuffer.indexOf(DOT_STR);
      if (index > 0)
      {
         String curStr = strBuffer.substring(0, index);
         DCGenericRowSetIteratorImpl master = findRootRowSetIterator(curStr);
         if (master == null)
         {
            throw new oracle.jbo.JboException(
               "Root iterator not found in container:  " + curStr);
         }
         int lastIndex = index+1;
         curRsi = master;
         while (index > 0)
         {
            index = strBuffer.indexOf(DOT_STR, lastIndex);
            curStr = (index > 0) ? strBuffer.substring(lastIndex, index) : strBuffer.substring(lastIndex);
            lastIndex = index+1;

            curRsi = master.getDetailRowSetIterator(curStr);
            if (curRsi == null)
            {
               curRsi = (DCGenericRowSetIteratorImpl)createRowSetIteratorImpl(
                  curStr
                  , master.getStructureDefImpl().getAccessorDef(curStr)
                  , master);
            }
            master = curRsi;
         }
      }
      else
      {
         curRsi = findRootRowSetIterator(path);
      }

      return curRsi;
   }
   /**
    * Clears the current data and state associated with all RSIs contained in this data
    * control.
    */
   protected void closeRowSetIterators(boolean recurseDetailRSIs)
   {
     for (Iterator rsis = associatedRowSetIterators(); rsis.hasNext();)
     {
       DCGenericRowSetIteratorImpl rsi = (DCGenericRowSetIteratorImpl)rsis.next();
       rsi.closeRowSetIterator(recurseDetailRSIs);
     }
   }
   /**
   * Returns an iterator over a copy of the RSIs associated with this data control.
   */
   private Iterator associatedRowSetIterators()
   {
     return ((HashMap)this.mRSIs.clone()).values().iterator();
   }
   protected DCGenericRowSetIteratorImpl findRootRowSetIterator(String name)
   {
      return (DCGenericRowSetIteratorImpl)mRSIs.get(name);
   }

   protected Object getAccessorValue(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName)
   {
      Object result;
      if (row.getStructureDef().lookupAttributeDef(accName) != null)
      {
         result = row.getAttribute(accName);
      }
      else
      {
         result = DCUtil.findSpelObject(((RowImpl)row).getDataProvider(), accName, false);
      }
      return result;
   }
   public RowSetIterator findOrCreateMethodRowSetIterator(
      DCIteratorBinding iter
      , String beanClass
      , Object result)
   {
      if (mRSIs == null)
      {
         mRSIs = new HashMap(5);
      }
      // JRS What cache key should we use?  Should be the source name.  However,
      // the source name is not currently unique for different method bindings.
      // Use the bindname for right now.  See bug 3310538 for issue with using
      // source name.
      DCIteratorBindingDef def = iter.getDef();
      RowSetIterator rsi = null;
      if (def != null)
      {
         rsi = (RowSetIterator)mRSIs.get(def.getBindsName());
      }
      if (rsi != null)
      {
        // alai: 3/17/05 reload data into RSI if it has been cleared but there 
        // are data from the last invokeAction, as passed to this method in the
        // result argument.
        if (rsi instanceof DCRowSetIteratorImpl)
        {
//          if (((DCRowSetIteratorImpl)rsi).getDataProvider() == null && result != null)
          Object curData = ((DCRowSetIteratorImpl)rsi).getDataProvider(); 
          if (curData != null && curData != result)
           //new result in the DC. needs to be fetched again on the cached rsi.
          {
             //delay accessing of dataprovider till it's needed
             //so that rangeRefreshed is generated after the
             //iteratorBinding has it's rsi setup and thus
             //components can find data in the rsi in an iteratorbinding.
             ((DCRowSetIteratorImpl)rsi).clearCurrentData();
          }
        }
      }
      else
      {
         rsi = createRowSetIteratorImpl(iter, beanClass, result, null);
         if (def != null)
         {
            mRSIs.put(def.getBindsName(), rsi);
         }
      }
      return rsi;
   }

   public RowSetIterator findOrCreateAccessorRowSetIterator(DCIteratorBinding masterIter,
                                                      DCIteratorBinding iter,
                                                      String accName,
                                                      String beanClass)
   {
      Row row = internalGetCurrentRow(masterIter);
      if (!masterIter.isFindMode())
      {
         RowSetIterator masterRSI = masterIter.getRowSetIterator();
         if (masterRSI.getCurrentRow() == row)
         {
            RowSetIterator rsi = ((DCGenericRowSetIteratorImpl)masterRSI).getDetailRowSetIterator(accName);
            if (rsi != null)
            {
               return rsi;
            }
         }
      }
      return super.findOrCreateAccessorRowSetIterator(masterIter, iter, accName, beanClass);
   }

   /**
    * Use findOrCreateAccessorRowSetIterator(DCIteratorBinding masterIter....) instead.
    * @deprecated since 10.1.2 
    */
   public RowSetIterator findOrCreateAccessorRowSetIterator(RowSetIterator masterRSI,
                                                      DCIteratorBinding iter,
                                                      String accName,
                                                      String beanClass)
   {
      RowSetIterator rsi = ((DCGenericRowSetIteratorImpl)masterRSI).getDetailRowSetIterator(accName);
      if (rsi == null)
      {
         rsi = createAccessorRowSetIterator(masterRSI, iter, accName, beanClass);
         if (rsi != null)
         {
            // JRS For some reason the super does not set the RSI name (overloaded)
            ((DCGenericRowSetIteratorImpl)rsi).setName(accName);
         }
      }
      return rsi;
   }

   protected RowSetIterator createRowSetIteratorImpl(String defName, //ignored when sourceObj is structureDefImpl
                                                  Object sourceObj,
                                                  RowSetIterator master)
   {
      DCGenericRowSetIteratorImpl rsi = null;
      if ((master == null || master instanceof DCGenericRowSetIteratorImpl) && sourceObj instanceof StructureDefImpl)
      {
         rsi = new DCGenericRowSetIteratorImpl(this, (StructureDefImpl)sourceObj, (DCGenericRowSetIteratorImpl)master);
         rsi.setAccessorName(defName);
         return rsi;
      }

      boolean setMaster = true;
      if (sourceObj instanceof java.util.Collection)
      {
         rsi = new DCGenericRowSetIteratorImpl(this, (java.util.Collection)sourceObj, "methodRSICollection");
      }
      else if (sourceObj instanceof java.util.Iterator)
      {
         rsi = new DCGenericRowSetIteratorImpl(this, (java.util.Iterator)sourceObj, "methodRSIIterator");
      }
      else
      {
         Class clz = null;
         if( sourceObj != null)
         {
            clz = sourceObj.getClass();
         }
         if ( (clz != null) && clz.isArray())
         {
            rsi = new DCGenericRowSetIteratorImpl(this, (java.util.Iterator)DCGenericRowSetIteratorImpl.getIteratorForArray(sourceObj, clz), 
                                           "methodArrayIterator");
         }
         else if(( clz != null ) || (defName != null))
         { 
            String clzName = null;
            if(defName != null)
            {
                clzName = defName;
            }
            else
            {
               clzName = clz.getName();
            }
            //non-Array/collection. Must be a bean.
            //turn this into an RSI of one object.
            //String clzName = clz.getName();
            String shortName = JboNameUtil.getLastPartOfName(clzName);
            JboNameUtil.stripToValidName(shortName);
            clzName = clzName.replace(JboNameUtil.INNER_CLASS_DESIGNATOR, '_');
            int n = 0;
            while (mStructureDefs.get(shortName) != null)
            {
               n++;
               shortName = shortName+n;
            }

            StructureDefImpl str = findStructureDef(clzName);
            if (str == null)
            {
               str = new StructureDefImpl(this, clzName, shortName);
            }
            mStructureDefs.put(shortName, str);
            //why do we need DCRowSetIteratorImpl here? changing it to GenericRSI
            setMaster = false;
            if (master instanceof DCGenericRowSetIteratorImpl)
            {
               rsi = new DCGenericRowSetIteratorImpl(this, sourceObj, shortName, str, (DCGenericRowSetIteratorImpl)master);
            }
            else
            {
               rsi = new DCGenericRowSetIteratorImpl(this, sourceObj, shortName, str);
               if (master != null)
               {
                 rsi.datacontrolFetch = false;
               }
            }
         }
      }

      if (rsi != null)
      {
         if (rsi.getStructureDefImpl() == null)
         {
            StructureDefImpl str = new StructureDefImpl(this, defName, "methodRSIStructure");
            rsi.setStructureDefImpl(str);
         }

         if (setMaster && master instanceof DCGenericRowSetIteratorImpl)
         {
            rsi.setAccessorName(defName);
            //rsi.setMasterRSI((DCGenericRowSetIteratorImpl)master);
         }

         return rsi;
      }

      /*
      throw new oracle.jbo.InvalidOperException(CSMessageBundle.class,
                                     CSMessageBundle.EXC_INVALID_METHOD_CALL,
                                     new Object[] { "DCGenericDataControl.createRowSetIteratorImpl" });
      */
      if (Diagnostic.isOn())
      {
         Diagnostic.println("*** DCGenericDataControl: null RSI being returned for def:"+defName);
      }
      return null;
   }

   public void setCurrentRowWithKeyValue(DCIteratorBinding iter, String stringValue)
   {
      DCGenericRowSetIteratorImpl rsi = (DCGenericRowSetIteratorImpl)iter.getRowSetIterator();
      ArrayList al = rsi.getStructureDefImpl().getKeyAttrsList();
      AttributeDef[] keyAttrs = (AttributeDef[])al.toArray(new AttributeDef[al.size()]);
      Class type = null;
      if (keyAttrs.length == 0)
      {
         type = rsi.getRowNumKeyDefArray()[0].getJavaType();
      }
      else if (keyAttrs.length == 1)
      {
         type = keyAttrs[0].getJavaType();
      }
      if (type != null)
      {
         Object keyVal = TypeFactory.getInstance(type, stringValue);
         Key key = new Key(new Object[]{keyVal});
         Row rows[] = rsi.findByKey(key, 1);
         if (rows.length <= 0)
         {
            oracle.jbo.common.Diagnostic.println("Currency not set, no row found with key :"+stringValue);
            throw new RowNotFoundException(CSMessageBundle.class,
                                                      CSMessageBundle.EXC_VIEW_ROW_NOT_FOUND, 
                                                      new Object[]{iter.getName(), stringValue});
         }

         rsi.setCurrentRow(rows[0]);
      }
   }

   public void setCurrentRowWithKey(DCIteratorBinding iter, String stringKey)
   {
      DCGenericRowSetIteratorImpl rsi = (DCGenericRowSetIteratorImpl)iter.getRowSetIterator();
      setCurrentRowWithKey(iter, rsi.createKey(stringKey));
   }

   public void setCurrentRowWithKey(DCIteratorBinding iter, Key key)
   {
      DCGenericRowSetIteratorImpl rsi = (DCGenericRowSetIteratorImpl)iter.getRowSetIterator();
      Row rows[] = rsi.findByKey(key, 1);
      if (rows.length <= 0)
      {
         oracle.jbo.common.Diagnostic.println("Currency not set, no row found with key :"+key);
         throw new RowNotFoundException(CSMessageBundle.class,
                                                   CSMessageBundle.EXC_VIEW_ROW_NOT_FOUND,
                                                   new Object[]{iter.getName(), key});
      }

      rsi.setCurrentRow(rows[0]);
   }


   protected StructureDefImpl findStructureDef(String beanClass)
   {
      StructureDefImpl str = null;
      if (beanClass != null)
      {
         if (getDefinition(beanClass, StructureDefinition.class) != null)
         {
            str = new StructureDefImpl(this, beanClass, beanClass);
         }
         else
         {
            try
            {
               str = (StructureDefImpl)JUMetaObjectManager.getJUMom().findDefinitionObjectDontCheckName(
                  beanClass,
                  JUMetaObjectManager.TYP_DEF_ANY,
                  StructureDefImpl.class,
                  false /*sub*/);
            }
            catch (oracle.jbo.NoDefException nde)
            {
               //if this beanClass is for a java type or a domain, it won't have
               //metadata
               if (!BeanUtils.skipMetaData(beanClass))
               {
                  throw nde;
               }
            }
         }
      }
      return str;
   }

   /*
   public Object getBeanInstance()
   {
      return mDataProvider;
   }
   */
   public AttributeDef[] getAttributeDefs(DCIteratorBinding iterBinding, String[] attrNames)
   {
      DCIteratorBindingDef iterDef = iterBinding.getDef();
      String beanClass = null;
      if (DCDefBase.PNAME_MethodIterator.equals(iterDef.getSubType()))
      {
         beanClass = ((JUMethodIteratorDef)iterDef).getBeanClassName();
      }
      else if (DCDefBase.PNAME_AccessorIterator.equals(iterDef.getSubType()))
      {
         beanClass = ((JUAccessorIteratorDef)iterDef).getBeanClassName();
      }
      oracle.jbo.StructureDef str = findStructureDef(beanClass);

      if (str == null)
      {
         DCRowSetIteratorImpl rsi = (DCRowSetIteratorImpl)iterBinding.getRowSetIterator();
         if (rsi != null)
         {
            str = rsi.getStructureDef();
         }
      }
      
      AttributeDef[] defs = super.resolveAttributeDefs(str, attrNames);
      if (defs == null || defs.length == 0 || defs[0] == null)
      {
         if (attrNames != null && attrNames.length == 1 && str instanceof StructureDefImpl) 
         {
            String accName = attrNames[0];
            StructureDefImpl strDef = (StructureDefImpl)str;
            StructureDefImpl accDef = strDef.getAccessorDef(accName);
            if (accDef != null) 
            {
               return new AttributeDef[]
               {
                  strDef.createAccessorAttributeDef(accName, accDef)
               };
            }
         }
      }
      return defs;
   }

   protected Object fetchProperty (RowImpl row, String propName)
   {
      //we could go to DCUtil.findSpel object to do this
      //but this check avoids a 'instanceof' check as we
      //already know that the master is a map rather than a bean.
      if (row.isProviderMap())
      {
         return ((java.util.Map)row.getDataProvider()).get(propName);
      }
      return BeanUtils.getProperty(row.getDataProvider(), propName);
   }

   protected Object fetchProviderProperty(String propName)
   {
      if (propName == null || propName.equals(DC_ROOT_ACC_NAME))
      {
         ArrayList al = new ArrayList(2);
         al.add(mDataProvider);
         return al.iterator();
      }
      return BeanUtils.getProperty(getDataProvider(), propName);
   }

   protected void restoreRSIs()
   {
      Iterator iter = mRSIs.values().iterator();
      DCRowSetIteratorImpl rsi;
      while (iter.hasNext())
      {
         rsi = ((DCRowSetIteratorImpl)iter.next());
         if (rsi.getProviderMethodResultName() != null)
         {
            //clean out the method result before restore currency
            //so that restore currency won't find it again.
            getMethodResults().remove(rsi.getProviderMethodResultName());
         }
         rsi.restoreCurrency(true);
      }
   }

   /**
    * Returns false for execute, create, remove and find Operations
    */
   public boolean isOperationSupported(DCIteratorBinding iterBinding, byte oper)
   {
      switch (oper)
      {
         case OPER_DATA_ROW_UPDATE:
            if (mUpdateAdapter != null)
            {
               return true;
            }
            return super.isOperationSupported(iterBinding, oper);

      case OPER_SORT_COLLECTION:
            //if def says it supports sorting and if rangeSize == -1
            //then adfm implements sorting for the associated collection.
         {
            DCDataControlDef def = getDef();
            if (def == null || super.isOperationSupported(iterBinding, oper)) 
            {
               if (iterBinding.hasRSI()) 
               {
                  if (iterBinding.getRowSetIterator() instanceof DCRowSetIteratorImpl) 
                  {
                     return ((DCRowSetIteratorImpl)iterBinding.getRowSetIterator()).isSortable();
                  }
               }
               return (iterBinding.getRangeSize() == -1);
            }
            return false;
         }

         case OPER_DATA_ROW_CREATE:
         case OPER_DATA_ROW_REMOVE:
            return (mUpdateAdapter != null);

         case OPER_FIND_MODE:
            return true;
            
         //allows refresh.
         case OPER_EXECUTE:
            return true;

         default:
            return super.isOperationSupported(iterBinding, oper);
      }
   }

   protected long getEstimatedRowCount(DCIteratorBinding iter)
   {
      RowSetIterator rsi = iter.getRowSetIterator();

      return (rsi != null) ? rsi.getRowCount() : 0;
   }

   /**
    * May be extended to initialize the specified StructureDefImpl
    * instance.  This is only called if the StructureDefImpl instance
    * cannot be otherwise loaded from its metadata or its bean properties.
    *
    * An extending DataControl should be sure to initialize the
    * StructureDefImpl attributes and accessors as follows:
    * <tt>
    *    def.setAttributes(&lt;AttributeDefImpl[]&gt;);
    *    def.setAccessors(&lt;StructureDefImpl[]&gt;);
    * </tt>
    * <p>
    * This method will be invoked for all accessor and root StructureDefImpl
    * instances.  It is preferred over initializing the structure def instance
    * in the DataControl initialize because the latter will not handle the
    * accessor StructureDefImpl instances.
    * <p>
    */
   void introspectStructureDef(StructureDefImpl def)
   {
      def.setAttributes(getAttributeDefs(def));
      def.setAccessors(getAccessorDefs(def));
   }

   /**
    * Invoked for dynamic DataControls.  Should be implemented to return
    * an array of {@link oracle.adf.model.generic.AttributeDefImpl} instances
    * for the specified StructureDefImpl instance.
    * <p>
    * The constructor {@link oracle.adf.model.generic.AttributeDefImpl#AttributeDefImpl(String, String, String, boolean, int)}
    * should be used to create the AttributeDefImpl instances.
    *
    */
   protected AttributeDefImpl[] getAttributeDefs(StructureDefImpl def)
   {
      return null;
   }

   /**
    * Invoked for dynamic DataControls.  Should be implemented to return
    * at array of accesor {@link oracle.adf.model.generic.StructureDefImpl}
    * instances for the specified StructureDefImpl instance.
    * <p>
    * The method {@link oracle.adf.model.generic.StructureDefImpl#createNewAccessor(String, String, DCDataControl)}.
    * should be used to create StructureDefImpl instances.
    */
   protected StructureDefImpl[] getAccessorDefs(StructureDefImpl def)
   {
      return null;
   }

   /**
    * Return a view criteria object attached to the RSI that this iterator binding 
    * is associated with. This method creates an empty ViewCriteria if non exists
    * on the RSI.
    */
   public ViewCriteria getViewCriteria(DCIteratorBinding iter)
   {
      ViewCriteria vc = null;
      if (iter.hasRSI()) 
      {
         RowSetIterator rsi = iter.getRowSetIterator();
         if (rsi instanceof DCRowSetIteratorImpl) 
         {
            DCRowSetIteratorImpl dcrsi = (DCRowSetIteratorImpl)rsi;
            vc = dcrsi.getViewCriteria();
            if (vc == null) 
            {
               //set this VC instance on the VO so that other iterbindings
               //share it.
               vc = new ViewCriteria(dcrsi.getStructureDef());
               vc.setCriteriaMode(ViewCriteria.CRITERIA_MODE_QUERY | ViewCriteria.CRITERIA_MODE_CACHE);
            }
            dcrsi.applyViewCriteria(vc);
         }
      }
      return vc;
   }

   public ViewCriteria createViewCriteria(DCIteratorBinding iter)
   {
      ViewCriteria vc = null;
      if (iter.hasRSI()) 
      {
         RowSetIterator rsi = iter.getRowSetIterator();
         if (rsi instanceof DCRowSetIteratorImpl) 
         {
            DCRowSetIteratorImpl dcrsi = (DCRowSetIteratorImpl)rsi;
            //set this VC instance on the VO so that other iterbindings
            //share it.
            vc = new ViewCriteria(dcrsi.getStructureDef());
            vc.setCriteriaMode(ViewCriteria.CRITERIA_MODE_QUERY | ViewCriteria.CRITERIA_MODE_CACHE);
         }
      }
      return vc;
   }

   /**
    * Return the criteria adapter that should be used
    * to create RowMatch for any view criterias attached
    * to RSIs created within this datacontrol
    */
   protected CriteriaAdapter getCriteriaAdapter()
   {
      if (mCriteriaAdapter == null) 
      {
         mCriteriaAdapter = new CriteriaAdapterImpl(getLocaleContext());
      }
      return mCriteriaAdapter;
   }

   protected RowMatch createCriteriaRowMatch(DCRowSetIteratorImpl rsi, ViewCriteria vc)
   {
      RowMatch rm = null;
      if (vc != null) 
      {
         String critStr = CriteriaClauses.buildCriteriaClauses(vc, getCriteriaAdapter()).getClauseForCache();
         rm = (critStr != null) ? new RowMatch(critStr) : null;
      }
      return rm;
   }

   /**
    * Sets the view criteria on the given RSI if it's a DCRowSetIteratorImpl or subclass thereof.
    * The next fetch from the dataProvider of this RSI will be filtered based on the criteria.
    */
   public void applyViewCriteria(ViewCriteria vc, DCIteratorBinding iter, RowSetIterator rsi)
   {
      if (rsi instanceof DCRowSetIteratorImpl) 
      {
         DCRowSetIteratorImpl dcrsi = (DCRowSetIteratorImpl)rsi;
         dcrsi.executeCriteria(vc, createCriteriaRowMatch(dcrsi, vc));
      }
   }



   /**
    * Subclasses need to implement sorting and turn this flag on if the given
    * attribute is sortable for a given iterator.
    */
   public boolean isAttributeSortable(DCIteratorBinding iter, AttributeDef ad)
   {
      //sorting is not implemented for generic DCs. 
      if (isOperationSupported(iter, DCDataControl.OPER_SORT_COLLECTION))
      {
         return (Comparable.class.isAssignableFrom(ad.getJavaType()));
      }
      return false;
   }

   /**
    * Sets the sort critiera that will be applied next time when the
    * source for this iteratorBinding is executed.
    */
   protected void applySortCriteria(DCIteratorBinding iter, SortCriteria[] sortby)
   {
      //only if this iteratorBinding requests all rows, implement sorting.
      if (isOperationSupported(iter, DCDataControl.OPER_SORT_COLLECTION))
      {
         RowSetIterator rsi = iter.getRowSetIterator();
         if (rsi instanceof DCRowSetIteratorImpl) 
         {
            ((DCRowSetIteratorImpl)rsi).sortRows(sortby);
         }
      }
   }

   /**
    * Returns an ordered array of SortCriteria that will be applied when
    * the source for this iteratorBinding is executed.
    */
   protected SortCriteria[] getSortCriteria(DCIteratorBinding iter)
   {
      return null;
   }

   protected void executeMethodIterators()
   {
      Iterator iter = mRSIs.values().iterator();
      DCRowSetIteratorImpl rsi;

      while (iter.hasNext())
      {
         rsi = ((DCRowSetIteratorImpl)iter.next());
         if (rsi.getProviderMethodResultName() != null)
         {
            //these rsis have methods.
            //get their event-listeners
            //that should be a method iterator binding
            //call execute query on those.

            com.sun.java.util.collections.ArrayList al = rsi.getListenersList();
            if (al != null)
            {
               Object obj;
               for (int i = 0; i < al.size(); i++)
               {
                  obj = al.get(i);
                  if (obj instanceof DCIteratorBinding)
                  {
                     ((DCIteratorBinding)obj).executeQuery();
                     break; //execute only once per RSI
                  }
               }
            }
         }
      }
   }
}
