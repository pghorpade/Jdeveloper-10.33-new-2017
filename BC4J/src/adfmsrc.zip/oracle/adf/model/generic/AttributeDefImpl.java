/*
 * @(#)AttributeDefImpl.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.AttributeList;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.AttributeDefHelper;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.StringManager;
import oracle.jbo.format.Formatter;
import oracle.jbo.format.FormatterFactory;
import oracle.jbo.rules.JboValidatorContext;
import java.text.ParseException;
import oracle.jbo.mom.xml.DefElement;
import org.w3c.dom.NamedNodeMap;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.rules.JboValidatorInterface;
import oracle.jbo.rules.JboPrecisionScaleValidator;
import oracle.jbo.rules.ValidationManager;

import java.util.ArrayList;

/**
 * The AttributeDefHelper class implement the AttributeDef interface
 *
 * @see RowImpl
 *
 * @version INTERNAL
 */
public class AttributeDefImpl extends DefinitionObject implements AttributeDef, AttributeHints, ValidationManager
{
   
   private String    name;
   private String    columnName;
   private int       index;
   private Class     columnType = null;
   private Class     type = null;
   private boolean   isSelected = false;
   private boolean   isQueriable = false;
   private byte      updateable;
   private boolean   primarykey;
   private boolean   mandatory;
   private int       precision;
   private int       scale;
   private String    elemClassName;
   private String    javaTypeName;
   private ArrayList mValidators;
   private StructureDefImpl mDef;

   /**
    * Construct a new instance.  
    * <p>
    * @param nm The AttributeDefImpl instance name.  Must be unique for
    *    for the parent StructureDefImpl instance.
    * @param type The type of the value that is returned by this
    *    AttributeDefImpl instance.
    * @param accName The name that should be used to acquire the
    *    AttributeDefImpl value from the owning StructureDefImpl.  If
    *    The owning StructureDefImpl instance is dynamic then this should
    *    be a map key.  If the owning StructureDefImpl instance references a
    *    a JavaBean then this should be a JavaBean property name.
    * @param editable  a boolean indicating if the AttributeDefImpl value is
    *    editable.
    * @param index The index of the AttributeDefImpl instance in its owning
    *    StructureDefImpl instance.
    * @deprecated since 10.1.2. Use a constructor variant that takes StructureDefImpl.
    */
   public AttributeDefImpl(String nm, String type, String accName, boolean editable, int index)
   {
      this (null, nm, accName, index, type, type, (editable ? UPDATEABLE : READONLY), false, false, null);
      if (oracle.jbo.common.Diagnostic.isOn()) 
      {
         oracle.jbo.common.Diagnostic.println("Missing StructureDefinition reference from an attributeDef of name:"+name);
      }
   }


   /**
    * Construct a new instance.  For internal use only.
    * <p>
    * @param def instance to which this attribute definition belongs.
    * @param nm The AttributeDefImpl instance name.  Must be unique for
    *    for the parent StructureDefImpl instance.
    * @param cnm Name of the source to which this attribute is mapped to in the
    *    source data objects for this definition
    * @param idx Index of this attribute within the structure definition.
    * @param typ The type of the value that is returned by this
    *    AttributeDefImpl instance.
    * @param cnmType The type of the value that the source data objects provide
    *    for this attribute.
    * @param upd One of the three udpateable flags in AttributeDef.
    * @param pk Whether this attribute should be a primarykey participant 
    * @param reqd Whether this attribute requires a non-null value.
    * @param elemClzName Name of the class to which the objects in this attribute belongs if this
    *                 attribute represents a collection type attribute (e.g., Array domain)
    * 
    * @deprecated since 10.1.3. Use a constructor variant that takes StructureDefImpl.
    */
   public AttributeDefImpl(StructureDefImpl def, 
                           String nm, 
                           String cnm, 
                           int idx, 
                           String typ, 
                           String cnmType, 
                           byte upd, 
                           boolean pk, 
                           boolean reqd,
                           String elemClzName)
   {
      init(nm, cnm, idx, typ, cnmType, false, false, upd, pk, reqd, elemClzName);
   }

   AttributeDefImpl(StructureDefImpl def)
   {
      mDef = def;
   }

   void init(String nm, 
             String cnm, 
             int idx, 
             String typ, 
             String cnmType, 
             boolean isSelected,
             boolean isQueriable, 
             byte updateable, 
             boolean primarykey, 
             boolean mandatory,
             String elemClzName)
   {
      this.name   = nm;
      this.columnName = cnm;
      this.index  = idx;
      this.javaTypeName = typ;
      this.isSelected = isSelected;
      this.isQueriable = isQueriable;
      this.updateable = updateable;
      this.primarykey = primarykey;
      this.mandatory = mandatory;
      this.elemClassName = elemClzName;

      if (cnmType == null || cnmType.length() == 0) 
      {
         //if no source/column type, then assume attribute's java type to be the column type
         cnmType = typ;
      }
      this.columnType = JBOClass.findDataClass(cnmType);

      if (cnm == null) 
      {
         columnName = name;
      }
   }

   /**
    * Returns the <tt>DefObject</tt> object which describes this attribute.
    * @return the definition for this attribute.
   */
   StructureDefImpl getDef()
   {
      return mDef;
   }

   void setDef(StructureDefImpl def)
   {
      mDef = def;
   }

   void loadFromXML(DefElement elem, int index)
   {
      init(elem.readString("Name"),                                                            //NONLS
           elem.readString(StructureDefImpl.PName_FieldName),
           index,
           elem.readString(oracle.jbo.uicli.mom.JUTags.TYPE),
           elem.readString(StructureDefImpl.PName_FieldType),
           elem.readBoolean("IsSelected"),                                                     //NONLS
           elem.readBoolean("IsQueriable"),                                                    //NONLS
           AttributeDefHelper.convertUpdateableStringToFlag(elem.readString("IsUpdateable")),  //NONLS
           elem.readBoolean("PrimaryKey"),                                                     //NONLS
           elem.readBoolean("IsNotNull"),                                                      //NONLS
           null);
      setPrecisionScale(elem.readInt("Precision"), elem.readInt("Scale"), elem.readBoolean("PrecisionRule"));                     //NONLS
      oracle.jbo.rules.RulesBeanUtils.loadValidators(elem, this, mDef.getMessageBundleClass());
      loadProperties(elem);
   }

   /**
    * Use setPrecisionScale(int, int, boolean) to indicate if this def should
    * imply applying precision validation as well. 
    */
   public void setPrecisionScale(int prec, int scale)
   {
      setPrecisionScale(prec, scale, true);
   }

   public void setPrecisionScale(int prec, int scale, boolean applyValidation)
   {
      precision = (prec);
      if (prec > 0)
      {
         this.scale = (scale);

         if (applyValidation) 
         {
            JboPrecisionScaleValidator val = new JboPrecisionScaleValidator();

            val.setPrecision(prec);
            val.setScale(scale);

            if (val != null)
            {
               addValidator(val);
            }
         }
      }
   }

   /**
   ** return the AttributeHints interface implemented by this class
   **/
   public AttributeHints getUIHelper()
   {
      return this;
   }

// Attribute hints implementation
   public String  getLocaleName(LocaleContext locale, String sName)
   {
      return JboNameUtil.getLocaleName(locale , sName);
   }


   String getStringFromMessageBundle(String property, LocaleContext locale)
   {
      Class clz = null;

      if(getDef() != null)
      {
         clz = getDef().getMessageBundleClass();
      }
        
      if (clz != null) 
      {
   
         String resName = (new StringBuffer(getName())).append("_").append(property).toString(); //NONLS
         return StringManager.getLocalizedString(clz.getName(),
                                                 resName,
                                                 null,
                                                 ((locale != null) ? locale.getLocale() : null),
                                                 false);
      }
      return null;
   }

   //for internal use only.
   String getControlHint(LocaleContext locale, String sName)
   {
      //go to message bundle first.
      String prop = getStringFromMessageBundle(sName, locale);

      if (prop == null) 
      {
         //load map
         com.sun.java.util.collections.HashMap propsMap = getPropertiesMap();

         //find locale specific name first.
         String localeName = getLocaleName(locale, sName);
         prop = (String)propsMap.get(localeName);

         //if locale specific entry not found, use base name.
         if (prop== null && !propsMap.containsKey(localeName))
         {
            prop = (String)propsMap.get(sName);
         }
      }

      return (prop == null) ? (String)getProperty(sName) : prop;
   }


  /**
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(LocaleContext locale)
   {
      String sLabel = getControlHint(locale, ATTRIBUTE_LABEL);
      if(sLabel == null)
      {
           // use the attribute name
         sLabel = getName();
      }
      return sLabel;
   }

   /**
   **  Retrives the tooltip text to be used for this attribute
   **/
   public String getTooltip(LocaleContext locale)
   {
      return getControlHint(locale, ATTRIBUTE_TOOLTIP);
   }

   /**
   **    Retrieves the displya hint that dictates whether this
   **  attributr should be visible or not. The two possible values
   **  are:
   **    ATTRIBUTE_DISPLAY_HINT_DISPLAY  = "Display";
   **    ATTRIBUTE_DISPLAY_HINT_HIDE     = "Hide";
   **/
   public String getDisplayHint(LocaleContext locale)
   {
      String sDisplayHint = getControlHint(locale, ATTRIBUTE_DISPLAY_HINT);
      if(sDisplayHint == null)
         sDisplayHint = ATTRIBUTE_DISPLAY_HINT_DISPLAY;

      return sDisplayHint;
   }

   /**
   **    Returns the preferred control type for this attribute
   **/
   public int getControlType(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_TYPE);

      if (sValue != null)
         return Integer.parseInt(sValue);

      // no hint is setup, return the default and let the client runtime or designtime decide
      // which control to use
      return CTLTYPE_DEFAULT;
   }

   /**
   **    Returns the display width for this attribute
   **/
   public int getDisplayWidth(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_DISPLAYWIDTH);

      if(sValue != null)
         return Integer.parseInt(sValue);

      return getPrecision();
   }

  /**
   **    Returns the display width for this attribute
   **/
   public int getDisplayHeight(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_DISPLAYHEIGHT);

      if(sValue != null)
         return Integer.parseInt(sValue);

      return 1;
   }

   /**
   ** Return defaulted hint value
   **/
   public String getHint(LocaleContext locale, String sHintName)
   {
      if (sHintName.equals(ATTRIBUTE_LABEL))
      {
         return getLabel(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_TOOLTIP))
      {
         return getTooltip(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_CTL_DISPLAYWIDTH))
      {
         return Integer.toString(getDisplayWidth(locale));
      }
      else
      {
         return getControlHint(locale, sHintName);
      }
   }

   /**
   ** Return non-defaulted hint value
   **/
   public String getHintValue(LocaleContext locale, String sHintName)
   {
      return getControlHint(locale, sHintName);
   }

   // formatting support
   public String getFormat(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      String format = getControlHint(locale, AttributeHints.FMT_FORMAT);
      if (format == null) 
      {
         format = getFormatter(locale).getDefaultFormatString();
      }
      return format;
   }

   public Formatter getFormatter(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      return FormatterFactory.getFormatter(getFormatterClassName(locale), locale);
   }

   public boolean hasFormatInformation(LocaleContext locale)
   {
      String   sFormatter = getControlHint(locale, AttributeHints.FMT_FORMATTER);

      if(sFormatter == null || sFormatter.equals(""))
         return false;

      return true;
   }

   public String getFormattedAttribute(AttributeList attrList, LocaleContext locale)
   {
      Object   aValue = attrList.getAttribute(getIndex());

      if(aValue == null)
          return null;

      if(aValue.equals(""))
         return "";
      
      if(!hasFormatInformation(locale))
      {
         return aValue.toString();
      }

      try
      {
         Formatter   formatter = getFormatter(locale);
         String      sFormat = getFormat(locale);

         formatter.setLocale(locale);

         String sRet = formatter.format(sFormat, aValue);

         return sRet;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public Object parseFormattedAttribute(String sValue, LocaleContext locale)
   {
       if(sValue == null)
           return null;

       if(sValue.equals(""))
            return "";

      if(!hasFormatInformation(locale))
      {
         return sValue;
      }

      try
      {
         Formatter formatter = getFormatter(locale);
         String    sFormat = getFormat(locale);

         formatter.setLocale(locale);

         Object newValue = formatter.parse(sFormat, sValue);

          // if the parser failed, just return the initial value
         if(newValue == null)
          return sValue;

         return newValue;
      }
      catch(ParseException parseEx)
      {
          return sValue;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public boolean displayInShortForm(LocaleContext locale)
   {
      String    sFormType = getControlHint(locale, AttributeHints.ATTRIBUTE_CTL_FORMTYPE);

      if(sFormType == null)
         return false;
         
      if(sFormType.equals(AttributeHints.ATTRIBUTE_FORM_TYPE_SHORT))
         return true;

      return false;
   }

      /**
   ** returns the formatter object stored in the ui hints
   **/
   public String getFormatterClassName(LocaleContext locale)
   {
      return getControlHint(locale, AttributeHints.FMT_FORMATTER);
   }

   // AttributeDef interface

   /*
    * Retrieve the name of the attribute.
    *
    * @return Name of the attribute
    */
   public String getName()
   {
      return name;
   }


   /*
    * Returns the name of the column the attribute might represent.
    *
    * @return The name of the column
    */
   public String getColumnName()
   {
      return columnName;
   }

   Class getColumnType()
   {
      return columnType;
   }


   public String getColumnNameForQuery()
   {
      return columnName;
   }

   
   /*
    * Retrieve the index of the attribute.
    *
    * @return Index of the attribute
    */
   public int getIndex()
   {
      return index;
   }


   /*
    * Retrieve the type of the attribute as a string.
    *
    * @return Class object of the attribute
    */
   public Class getJavaType()
   {
      if (type == null) 
      {
        type = JBOClass.findDataClass(javaTypeName);
      }
      
      return type;
   }

   /*
    * Retrieve the Java type name of the attribute as a string.
    *
    * @return java type name(class name) of the attribute
    */
   public String getJavaTypeName()
   {
      return javaTypeName;
   }


   /*
    * Get the java.sql.Types of this attribute.
    *
    * @return The data type
    * @see java.sql.Types
    */
   public int getSQLType()
   {
      return 0;
   }

   
   public byte getAttributeKind()
   {
      return ATTR_PERSISTENT;
   }
   

   public boolean isSelected()
   {
      return isSelected;
   }


   /*
    * Queriable attributes are those attributes that
    * may have a filter condition for the where clause
    * If isQueriable returns false, the attribute will
    * not be used in constructing the where clause
    * of the SQL to fetch data.
    *
    * @return true if queriable
    */
   public boolean isQueriable()
   {
      return isQueriable;
   }
   
   /*
    * Return true if this attribute is updateable
    *
    * @return true if this is an editable attribute.
    */
   public byte getUpdateableFlag()
   {
      return updateable;
   }
   
   
   /*
    * Return true if this attribute is a primarykey
    *
    * @return true if this is a primary key attribute.
    */
   public boolean isPrimaryKey()
   {
      return primarykey;
   }
   
   
   /**
    * Return true if this attribute does not allow null values.
    */
   public boolean isMandatory()
   {
      return mandatory;
   }

   /*
    *
    * @return precision
    */
   public int getPrecision()
   {
      return precision;
   }

   /*
    *
    * @return scale
    */
   public int getScale()
   {
      return scale;
   }

   
   /**
    * Returns the element type of the attribute.
    * <p>
    * For VARRAYs, this method returns the class name of the elements that are
    * in the VARRAY.
    * <p>
    * Element type is relevant only if the attribute is an array attribute.
    * @return the attribute's element class, or <tt>null</tt> if the attribute is not
    * an array attribute.
    */
   public Class getElemType()
   {
      if (elemClassName != null && elemClassName.length() > 0) 
      {
         try
         {
            return JBOClass.forName(elemClassName);
         }
         catch (java.lang.ClassNotFoundException cnfe)
         {
            throw new JboException(cnfe);
         }
      }
      return null;
   }


   /**
    * Returns the jdbc type of the elements of this attribute.
    * <p>
    * For VARRAYs, this method returns the jdbc type of the elements that are in the VARRAY.
    * <p>
    * Element type is relevant only if the attribute is an array attribute.
    * @return the jdbc type (java.sql.Types.*) of this attribute's elements, or <tt>java.sql.Types.NULL</tt> 
    * if this attribute is not an array attribute.
    */
   public int getElemSQLType()
   {
      return 0;
   }

   public void addValidator(JboValidatorInterface intf)
   {
      if (mValidators == null)
      {
         mValidators = new ArrayList(4);
      }
      mValidators.add(intf);
   }

   public ArrayList getValidators()
   {
      return (mValidators != null) ? (ArrayList)mValidators.clone() : new ArrayList(0);
   }

   public void validate(AttributeList al, Object newValue)
   {
      if (mValidators != null)
      {
         JboValidatorContext valCtx = new JboValidatorContext(JboValidatorContext.TYP_ATTRIBUTE_LIST_WITH_DEF,
                                      al, 
                                      getDef().getFullName(),
                                      this, 
                                      al.getAttribute(getIndex()), 
                                      newValue);

         for (int i = 0; i < mValidators.size(); i++)
         {
            ((JboValidatorInterface)mValidators.get(i)).validate(valCtx);
         }
      }
   }
}
