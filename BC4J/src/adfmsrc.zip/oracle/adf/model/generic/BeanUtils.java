package oracle.adf.model.generic;

public class BeanUtils extends oracle.adf.model.binding.DCUtil
{
   //if string is null/empty or one of the known java types
   //then skip metadata lookup.
   public static boolean skipMetaData(String sType)
   {
      if(sType == null || sType.equals(""))
         return true;

      if(sType.equals("int"))
         return true;
      if(sType.startsWith("java."))
         return true;
       if(sType.startsWith("javax."))
         return true;
      if(sType.startsWith("org.w3c."))
         return true;
      if(sType.startsWith("oracle.sql"))
         return true;
      if(sType.startsWith("orace.jdbc"))
         return true;
      if(sType.startsWith("oracle.jbo"))
         return true;
      if(sType.startsWith("oracle.adf.model"))
         return true;
      return false;
   }

}