/*
 * @(#)DCGenericRowSetIteratorImpl.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.generic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.HashMap;

import oracle.jbo.AttributeList;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.StructureDef;
import oracle.jbo.JboException;
import oracle.jbo.NoObjException;
import oracle.jbo.common.Diagnostic;

import oracle.adf.model.binding.DCDataControl;
/**
 *
 *
 * @version INTERNAL
 */
public class DCGenericRowSetIteratorImpl extends DCRowSetIteratorImpl
{
   DCGenericRowSetIteratorImpl mMasterRSI;
   Key mMasterRowKey;
   HashMap mDetails;
   boolean datacontrolFetch = true;

   protected DCGenericRowSetIteratorImpl(DCDataControl dc, Collection coll, String name)
   {
      super(dc, coll, name);
   }

   protected DCGenericRowSetIteratorImpl(DCDataControl dc, Iterator iter, String name)
   {
      super(dc, iter, name);
   }
   //this should not be used as fetchProvider always goes via datacontrol
   //for DCGenericRSI.
   DCGenericRowSetIteratorImpl(DCDataControl dc, Object data, String name, StructureDef def)
   {
      super(dc, data, name, def);
   }

   DCGenericRowSetIteratorImpl(DCDataControl dc, Object data, String name, StructureDef def, DCGenericRowSetIteratorImpl masterRSI)
   {
      super(dc, data, name, def);
      setMasterRSI(masterRSI);
   }


   protected DCGenericRowSetIteratorImpl(DCGenericDataControl dc, StructureDefImpl def, DCGenericRowSetIteratorImpl masterRSI)
   {
      super (dc, (Object)null, def.mName);
      mStructureDef = def;
      setMasterRSI(masterRSI);
   }


   /**
    * *** For internal framework use only ***
    */
   private void setMasterRSI(DCGenericRowSetIteratorImpl masterRSI)
   {
      if (mMasterRSI != masterRSI)
      {
         if (mMasterRSI != null)
         {
            mMasterRSI.removeDetailRowSetIterator(getName());
         }

         mMasterRSI = masterRSI;

         if (masterRSI != null)
         {
            masterRSI.addDetailRowSetIterator(getName(), this);
         }
      }
   }

   protected Object fetchProvider()
   {
      Object data = null;
      if (mMasterRSI != null || mMasterRowKey != null)
      {
         RowImpl masterRow = null;
         if (mMasterRowKey == null)
         {
            masterRow = (RowImpl)mMasterRSI.getCurrentRow();
            if (masterRow == null)
            {
               masterRow = (RowImpl)mMasterRSI.first();
            }
         }
         else if (mMasterRSI != null)
         {
            Row[] rows = mMasterRSI.findByKey(mMasterRowKey, 1);
            masterRow = (rows != null && rows.length > 0) ? (RowImpl)rows[0] : null;
         }

         if (masterRow == null)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("No master row found for :"+ ((mMasterRSI != null) ? mMasterRSI.getName() : this.getAccessorName()));
            }
            data = null;
            //tested in guava javabeans sv16
            //throw new NoObjException("Master Row", mMasterRSI.getName());
         }
         else
         {
            data = ((DCGenericDataControl)mApp).fetchProperty(masterRow, getAccessorName());
         }
      }
      else if (getProviderMethodResultName() == null && datacontrolFetch)
      {
         data = ((DCGenericDataControl)mApp).fetchProviderProperty(getAccessorName());
      }
      else
      {
         //a method result, fetch it's value again.
         data = super.fetchProvider();
      }
      return data;
   }

   void clearClientSide()
   {
      if (mMasterRSI != null)
      {
         //mMasterRSI.removeDetailRowSetIterator((mMasterRowKey != null) ? (Object)mMasterRowKey : (Object)getName());
         mMasterRSI.removeDetailRowSetIterator(mMasterRowKey);
         mMasterRSI.removeDetailRowSetIterator(getName());
      }
      if (getProviderMethodResultName() != null)
      {
         ((DCGenericDataControl)mApp).mRSIs.remove(getProviderMethodResultName());
      }
      else if (mMasterRSI == null)
      {
         ((DCGenericDataControl)mApp).mRSIs.remove(((StructureDefImpl)getStructureDef()).mName);
      }
      mMasterRSI = null;

      super.clearClientSide();
   }
   public StructureDef getStructureDef()
   {
      if (mStructureDef == null)
      {
         mStructureDef = new StructureDefImpl();
         RowImpl row = (RowImpl) getRowAtRangeIndex(0);
         ((StructureDefImpl)mStructureDef).setAttributeDefs(
                 resolveAttributeDefs(mStructureDef, (row != null) ? row.getDataProvider() : null));
      }
      return mStructureDef;
   }

   StructureDefImpl getStructureDefImpl()
   {
      return (StructureDefImpl)mStructureDef;
   }
   void setStructureDefImpl(StructureDefImpl def)
   {
      mStructureDef = def;
   }

   ArrayList resolveAttributeDefs(StructureDef def, Object bean)
   {
      //we'd be coming here either in testcases or when there's no beanclass
      //xml. So get the first row without breaking the original iterator.
      //RowImpl r = (RowImpl)getRowAtRangeIndex(0);

      ArrayList al = new ArrayList();
      if (bean != null)
      {
        try
        {
           java.beans.BeanInfo beanInfo = java.beans.Introspector.getBeanInfo(bean.getClass());
           java.beans.PropertyDescriptor[] props = beanInfo.getPropertyDescriptors();
           int count = 0;
           for (int i = 0; i < props.length; i++)
           {
              if (props[i].getName().equals("class"))
              {
                continue;
              }

              AttributeDefImpl ad = new AttributeDefImpl((StructureDefImpl)def);
              ad.init(toUpperFirst(props[i].getName()),  //name         
                      props[i].getName(),                 //accessorName
                      count++,                    //index           
                      props[i].getPropertyType().getName(),                 //attributeType        
                      props[i].getPropertyType().getName(),                 //accessorType
                      true,                 //isSelected
                      false,                //isQueriable
                      (props[i].getWriteMethod() == null) ? AttributeDefImpl.READONLY : AttributeDefImpl.UPDATEABLE,//updateable
                      false,                 //primarykey
                      false,                //mandatory
                      null);                
              al.add(ad);
           }
        }
        catch (Exception e)
        {
           new JboException(e);
        }
      }
      return al;
   }
   DCGenericRowSetIteratorImpl getDetailRowSetIterator(String name)
   {
      return (mDetails != null) ? (DCGenericRowSetIteratorImpl)mDetails.get(name) : null;
   }

   void addDetailRowSetIterator(Object key, DCGenericRowSetIteratorImpl detail)
   {
      if (mDetails == null)
      {
         mDetails = new HashMap(5);
      }

      DCGenericRowSetIteratorImpl exists = (DCGenericRowSetIteratorImpl)mDetails.get(key);
      if (exists == null)
      {
         mDetails.put(key, detail);
      }
      else if (key instanceof String && exists != detail)
      {
         //set a unique internal name for detail rsi.
         String accessorName = detail.getAccessorName();
         if (accessorName == null)
         {
            accessorName = ((String)key);
         }
         String name = accessorName;
         while (true && mDetails.get(name) != null)
         {
            name = oracle.jbo.common.JboNameUtil.getInstNameFromDefName(accessorName);
         }
         key = name;
         detail.internalSetName(name);
         mDetails.put(name, detail);
      }
   }
   void internalSetName(String name)
   {
      super.setName(name);
   }
   void removeDetailRowSetIterator(Object key)
   {
      if (mDetails != null)
      {
         mDetails.remove(key);
      }
   }

   public void setName(String name)
   {
      if (mMasterRSI != null && mMasterRowKey != null)
      {
         mMasterRSI.removeDetailRowSetIterator(getName());
      }

      super.setName(name);

      if (mMasterRSI != null && mMasterRowKey != null)
      {
         mMasterRSI.addDetailRowSetIterator(getName(), this);
      }
   }


   final protected void notifyNavigationEvent(Row srcRow, Row dstRow)
   {
      DCGenericRowSetIteratorImpl detail;
      HashMap details = (mDetails != null) ? (HashMap)mDetails.clone() : null;
      HashMap detailCurRowMap = null;
      Object key;
      if (details != null)
      {
         Iterator iter = details.keySet().iterator();
         detailCurRowMap = new HashMap(mDetails.size());
         while (iter.hasNext())
         {
            key = iter.next();
            detail = ((DCGenericRowSetIteratorImpl)mDetails.get(key));
            if (detail.isExecuted())
            {
               // only clear detail RSI's data if data has been loaded.
               if (detail.getCurrentRow() != null ) 
               {
                  detailCurRowMap.put(key, detail.getCurrentRow());
               }
               detail.clearCurrentData();
            }
         }
      }

      super.notifyNavigationEvent(srcRow, dstRow);

      if (detailCurRowMap != null)
      {
         Iterator iter = details.keySet().iterator();

         while (iter.hasNext())
         {
            key = iter.next();
            detail = ((DCGenericRowSetIteratorImpl)mDetails.get(key));
            key = detailCurRowMap.get(key);
            if (key != null) 
            {
               //navigating out of the current row.
               detail.notifyNavigationEvent((Row)key, null);
            }
            //this will generate rangeRefreshed to redisplay
            //the current details.
            detail.fetchDataSource();
         }
      }
   }
   
   /*original version: final protected void notifyNavigationEvent(Row srcRow, Row dstRow)
   {
      HashMap detailsExecutedState = new HashMap();
      DCGenericRowSetIteratorImpl detail;
      if (mDetails != null)
      {
         Iterator iter = mDetails.keySet().iterator();
         while (iter.hasNext())
         {
            detail = ((DCGenericRowSetIteratorImpl)mDetails.get(iter.next()));
            detailsExecutedState.put(detail, new Boolean(detail.isExecuted()));
            detail.clearCurrentData();
         }
      }

      super.notifyNavigationEvent(srcRow, dstRow);

      if (mDetails != null)
      {
         Iterator iter = mDetails.keySet().iterator();
         while (iter.hasNext())
         {
            detail = ((DCGenericRowSetIteratorImpl)mDetails.get(iter.next()));
            Boolean boolVal = ((Boolean)detailsExecutedState.get(detail));
            if (boolVal != null && boolVal.booleanValue())
            {
               detail.fetchDataSource();
               //detail.resetCrack();
            }
         }
      }
   }
   */
   
   //recursive clearCurrentData to clear all levels of children
   public void clearCurrentData()
   {
      super.clearCurrentData();
      if (mDetails != null)
      {
         Iterator iter = mDetails.keySet().iterator();
         DCGenericRowSetIteratorImpl detail;
         while (iter.hasNext())
         {
            detail = ((DCGenericRowSetIteratorImpl)mDetails.get(iter.next()));
            detail.clearCurrentData();
         }
      }
   }

   protected Object getMasterRowDataProvider()
   {
     Object masterRowDataProvider = null;
     if (mMasterRSI != null && mMasterRSI.getCurrentRow() != null)
     {
       Row masterRow = mMasterRSI.getCurrentRow();
       if (masterRow instanceof RowImpl)
       {
         masterRowDataProvider = ((RowImpl)masterRow).getDataProvider();
       }
     }
     return masterRowDataProvider;
   }

   public Row createAndInitRow(AttributeList nvp)
   {
      return internalCreateRowInstanceFor(mApp.createRowData(new DCGenericRowContext(this, getMasterRowDataProvider())));
   }

   protected boolean containsRow(Row row)
   {
      if (((RowImpl)row).belongsTo(this))
      {
         return dataRows.contains(row);
      }
      return false;
   }
   public void closeRowSetIterator(boolean recurseDetails)
   {
     this.closeRowSetIterator();
     if (recurseDetails)
     {
       Collection details = getDetailsCopy();
       if (details != null)
       {
         for (Iterator detailIter = details.iterator(); detailIter.hasNext();)
         {
           DCGenericRowSetIteratorImpl detailRSI = (DCGenericRowSetIteratorImpl)detailIter.next();
           detailRSI.closeRowSetIterator(recurseDetails);
         }
       }
     }
   }
   private Collection getDetailsCopy()
   {
      if (this.mDetails != null)
      {
        return ((HashMap)this.mDetails.clone()).values();
      }
      return null;
   }

   /**
    * *** For internal framework use only ***
    */
   public DCGenericRowSetIteratorImpl setMasterInfo(DCGenericRowSetIteratorImpl masterRSI, RowImpl masterRow, String name, boolean trackMaster)
   {
      //if this accessor has been created as an accessor RSI for a master row
      String existingName = getName();
      if(!trackMaster)
      {
         mMasterRowKey = (masterRow.getKey());
         mMasterRSI = masterRSI;
         masterRSI.addDetailRowSetIterator(mMasterRowKey, this);
      }
      else if (trackMaster && masterRSI != null)
      {
         if (mMasterRSI == masterRSI)
         {
            if (masterRSI.getDetailRowSetIterator(existingName) != null)
            {
               masterRSI.removeDetailRowSetIterator(existingName);
               //this will get added again into this master.
               mMasterRSI = null;
            }
         }
         //reset the name on this accessor RSI to match the accessor name.
         setName(name);
         setMasterRSI(masterRSI);
         return masterRSI.getDetailRowSetIterator(getName());
      }
      return this;
   }

   public boolean isSameMasterRSI(RowSetIterator rsi)
   {
      return rsi == mMasterRSI;
   }

   /**
    * Create and return an equivalent RowSetIterator with data containing rows
    * from this same RSI filtered via a criteria.
    */
   protected RowSetIterator createFilteredRowSetIterator(Object data)
   {
      return getDataControl().createRowSetIteratorImpl(null, getStructureDef().getFullName(),
                                                   data,
                                                   mMasterRSI);
   }

   protected void setAttributeValue(RowImpl row, String accName, Object value)
   {
      oracle.binding.UpdateableDataControl updateDC;
      if ((updateDC = ((DCGenericDataControl)mApp).getUpdateableDataControl()) != null)
      {
         class AttributeContext extends DCGenericRowContext implements oracle.binding.AttributeContext
         {
            String mAccName;
            AttributeContext(Row data, String accName, RowSetIterator iter, StructureDef def, Object masterRowDataProvider)
            {
               super(data, iter,  def, masterRowDataProvider);
               mAccName = accName;
            }

            public String getAttributeName()
            {
               return mAccName;
            }

         }
         if (updateDC.setAttributeValue(new AttributeContext(row, 
                                                          accName,
                                                          this, 
                                                          getStructureDef(),
                                                          getMasterRowDataProvider()), value))
         {
            return;
         }
      }
      super.setAttributeValue(row, accName, value);
   }
}
