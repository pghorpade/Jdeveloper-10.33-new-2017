package oracle.adf.model;

import java.util.List;

/**
 * A ControlBinding that binds a single attribute value exposed via a datacontrol
 * to a view component.
 */
public interface AttributeBinding extends ControlBinding, oracle.binding.AttributeBinding
{
   /**
    * Return the value that should be rendered on a view for the attribute
    * associated with this binding.
    */
   public Object getInputValue();

   /**
    * Update the attribute value associated with this binding. If there are exceptions
    * while updating this attribute, these exceptions should be accessible via getErrors()
    */
   public void setInputValue(Object inputVal);

   /**
    * validate the given value with validations applied at the binding level (if any.)
    * Return value of null means the validation succeeded.
    * In case of failed validation, the return value should be an Exception object.
    * Some attribute bindings may want to generate 'warning' type messages from
    * this method. To account for those, the return type is not an Exception object
    * itself.
    */
   public Object validateInputValue(Object inputVal);
   
   /**
    * Return the display label or prompt for the attribute represented by this binding.
    */
   public String getLabel();

   public boolean isUpdateable();

   /**
    * Return a list of errors that were raised during setInputValue()
    */
   public List getErrors();

   /**
    * Prepare the binding for being able to accept a new value
    */
   public boolean processNewInputValue(Object value);
}
