package oracle.adf.model;

import java.util.List;

/**
 * A ControlBinding that binds a single attribute value exposed via a datacontrol
 * to a view component.
 */
public interface RangeBinding extends ControlBinding, oracle.binding.RangeBinding
{
   public String[] getLabelSet();

   //public int getRowCountInRange();
   
   public int getCurrentRowIndex();

   public void setCurrentRowAtIndex(int x);

   public List getRangeSet();
}
