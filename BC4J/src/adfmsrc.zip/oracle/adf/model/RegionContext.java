package oracle.adf.model;

import java.util.List;
/**
 * A map that provides a name-space to locate binding objects
 * through which data is accessed on a view region.
 */
public interface RegionContext
{
   /**
    * RegionBinding instance with which this context is created.
    */
   RegionBinding getRegionBinding();

   /**
    * Returns the refresh type in case of refreshRegion event.
    */
   int getRefreshFlag();
}
