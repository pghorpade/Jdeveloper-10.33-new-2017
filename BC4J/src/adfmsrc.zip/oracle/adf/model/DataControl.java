package oracle.adf.model;

import java.util.Map;

/**
 * DataControl is a collection of DataControls accessed by their key
 * This is only for internal purposes and implementing just this interface
 * will not work in ADF 9.0.5.1. This interface exists for future api
 * needs.
 */
public interface DataControl extends oracle.binding.DataControl, Map
{

   /**
    * Release all references held in the data control.
    */
   public static int REL_ALL_REFS       = -1;

   /**
    * Release only the data provider (Business Service) references
    */
   public static int REL_DATA_REFS      = 0x1;

   /**
    * Hold on to the data references and release the View references
    * if held on the datacontrol. This should be internal to 
    * ADFm implementation and may not be exposed in the JSR.
    */
   public static int REL_VIEW_REFS      = 0x2;

   /**
    * This is a weak data release.  This may be specified by
    * a DataControl to release data refs that do not rely upon any session state
    * like iterator currency.  These references are typical cache references and
    * may be rebuilt at any time using the DataControl.  For example, BC4J uses
    * this release flag to release JUCtrlListBinding references to BC4J rows.
    * These rows are cached for performance but also may be re-fetched from the
    * DataControl at any time.
    */
   public static int REL_WEAK_DATA_REFS = 0x4;

   /**
    * Returns name to identify this datacontrol. - unused.
    */
   public String getName();
   
   /**
    * Based on the value of the flags parameter, releases all references to 
    * the objects in the data provider layer 
    * Valid values for flags are:
    * <ul>
    *    <li><code>REL_ALL_REFS</code> - if this data control
    *        should release all references to both the view and model 
    *        objects.
    *    <li><code>REL_DATA_REFS</code> - if this data control
    *        should release all references to data provider objects. The
    *        likely usage would be when say an Application Module is to 
    *        be checked into a pool and this data-control may be given
    *        that or another checked out AM to work with subsequently.
    *    <li><code>REL_VIEW_REFS</code> - if this data control
    *        should release all references to the UI/View layer objects.
    * </ul>
    **/
   public void release(int flags);

   /**
   * Return the Business Service Object that this datacontrol is associated with.
   */
   Object getDataProvider();
   
   /**
   * Invoke a method identified by the given method info and with ordered arguments in the params list.
   */
   //Object invokeMethod(Map bindingContext, MethodInfo methodInfo, java.util.Map params);

}
