/*
 * @(#)DCDataControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.bc4j;

import java.util.HashMap;
import java.util.Map;
import java.util.Hashtable;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttrValException;
import oracle.jbo.AttributeList;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ApplicationModuleCreateException;
import oracle.jbo.ApplicationModuleHome;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.LocaleContext;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboEvent;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.StructureDef;
import oracle.jbo.Transaction;
import oracle.jbo.TransactionStateListener;
import oracle.jbo.ViewCriteria;
import oracle.jbo.Variable;
import oracle.jbo.VariableManager;
import oracle.jbo.VariableValueManager;
import oracle.jbo.ViewObject;
import oracle.jbo.SortCriteria;
import oracle.jbo.client.JboUtil;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.VariableImpl;
import oracle.jbo.common.VariableValueManagerImpl;
import oracle.jbo.common.ws.WSApplicationModuleImpl;
import oracle.jbo.common.ws.WSViewObjectImpl;
import oracle.jbo.common.ws.WSRowSet;
import oracle.jbo.common.ws.WSRowSetIteratorImpl;
import oracle.jbo.common.ws.WSRowSetIteratorBase;
import oracle.jbo.client.Configuration;
import oracle.jbo.domain.TypeFactory;

import oracle.adf.model.generic.DCRowContext;
import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.binding.DCInvokeMethod;


import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieImpl;


import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCIteratorBindingDef;
import oracle.adf.model.generic.DCRowSetIteratorImpl;
import oracle.adf.model.generic.StructureDefImpl;

import oracle.jbo.uicli.binding.JUAccessorIteratorDef;

import oracle.adf.share.statemanager.StateManagerScopeAdapter;
import oracle.adf.share.statemanager.DefaultPolicyImpl;

import oracle.adf.share.ADFContext;

/**
 * The application class that manages connection to a 
 * BC4J Application Module. The DCDataControl class provides:<p>
 * <ul>
 * <li>Methods to connect to a BC4J Application Module, if this application
 * is the root DCDataControl object. DCDataControls could be nested in other
 * DCDataControl objects to mirror BC4J Nested Application Modules.
 * <li>Handles exceptions raised by the framework and passes it on
 * to registered Error handler. The error handler is same as registered
 * with the BC4J application module (if any). 
 * <li>Manages form bindings that contain iterator-bindings that 
 * bind iterators of the ViewObjects in the associated Application Module.
 * <li>If this DCDataControl is the root, manages TransactionStateListeners
 * so that the BC4J Transaction's state events are passed on to the listeners.
 * <li>Routes all status bar messages to all status bars registered with 
 * this application. Framework uses this class to route all status bar messages.
 * </ul>
 * @version  PUBLIC
 * @see oracle.jbo.ApplicationModule
 * @see oracle.jbo.Transaction
 * @see oracle.adf.model.binding.DCTransactionStateListener
 * @see oracle.adf.model.binding.DCErrorHandler
 * 
 */
public class DCJboDataControl extends DCDataControl
                              implements TransactionStateListener
{
   private String mRootAMDefName;
   private Hashtable mContext;
   private String mDBConnectionURL;
   private Properties mDBConnectionProps;
   private String mPackageName;
   private int mValidationInBinding = VAL_MODE_UNINIT;

   ApplicationModule mAM;
   SessionCookie mSessionCookie;

   boolean mSyncNeeded = false;


   public final static int VAL_MODE_REMOTE = 3;
   public final static int VAL_MODE_ALWAYS = -1;
   public final static int VAL_MODE_NEVER  = 1;
   public final static int VAL_MODE_UNINIT = 0;

   static public final int EXC_MODE_DEFAULT   = 0; //meaning for JClient it's immediate, for others it's deferred.
   static public final int EXC_MODE_DEFERRED  = 1;
   static public final int EXC_MODE_IMMEDIATE = 2;

   private static byte DEPLOY_UNRESOLVED = -1;
   private static byte DEPLOY_LOCAL      = 0;
   private static byte DEPLOY_REMOTE     = 1;
   private byte mDeployMode = DEPLOY_UNRESOLVED;

   // JRS Used to signal to resetState that it does not need to reset
   // the AM reference immediately.
   private boolean mInEndRequest = false;
   private boolean mInRequest = false;

   private int mReleaseLevel = ApplicationModule.RELEASE_LEVEL_MANAGED;

   static final String GET_TransactionDirty = "TransactionDirty";          //NONLS
   
   private static final String FINDVOWITHPARAMS = "findViewObjectWithParameters";
   private static final String VARAIBLE_MANAGER_CLASS = VariableManager.class.getName();

   private HashMap mastersToExecute; //set to null before sync().

   // only added for design time.
   /**
    * *** For internal framework use only ***
    */
   protected DCJboDataControl()
   {
      super();
   }

   /**
   * Constructs a root DCDataControl object that connects to a BC4J Application Module
   * of the given name.
   * @param context Context to pass on to the BC4J Application Module on creation.
   * @param rootAMDefName Name that identifies the root BC4J Application Module.
   * @param userData Data to store with the DCDataControl object.
   */
   public DCJboDataControl(Hashtable context, String rootAMDefName, Object userData)
   {
      super(true, userData);
      mContext = context;
      mRootAMDefName = rootAMDefName;
   }
   
   
   /**
   * Constructor used internally by the framework to associate an application module
   * with a JClient application object.
   */
   public DCJboDataControl(ApplicationModule am)
   {
      this(null, am, null);
   }
   
   
   /**
   * Constructor to be used to create a nested DCDataControl inside another DCDataControl object.
   */
   public DCJboDataControl(DCDataControl parent, ApplicationModule am, Object userData)
   {
      super((parent == null), userData);
      mParent = parent;

      setApplicationModule(am);
      
         
      // JRS 03/05/2004 bug 3457784.  guava.batchmode.js06.
      // An activation may occur while preparing the AM above.
      // Re-synch the DCDataControl mTxnModified state.
      //
      // This code is a little fragile.  It depends upon setApplicationModule
      // above to initialize the WSAM (in batch), to perform an activation,
      // and to synch the cliAM isTxnDirty state.  If these assumptions fail
      // then the isDirty check below could result in an unwanted RT OR an
      // unexpected exception due to an uninitialized AM state.
      if (am.getTransaction().isDirty())
      {
         setTransactionModified();
      }
   }

   public DCJboDataControl(SessionCookie sessionCookie)
   {
      super(true, null);
      mSessionCookie = sessionCookie;

      mRootApplication = this;
   }

   private void setApplicationModule(ApplicationModule am)
   {
      mAM = am;
      setDataProvider(am);

      mSyncNeeded  = (am instanceof WSApplicationModuleImpl);

      if (mIsRoot)
      {
         mRootAMDefName = mAM.getDefFullName();
         mRootApplication = this;

         mAM.getTransaction().addTransactionStateListener(this);
      }
      else
      {
         mRootApplication = mParent.getRootDataControl();
      }
   }

   
   /**
   * *** Advanced method ***
   * *** For internal framework use only ***
   * <p>
   * Creates a connection to the BC4J application module. 
   */
   public void initialize()
   {
      if (mIsRoot)
      {
         createRootApplicationModule();
         loadPackage();
         connect();
      }
   }

   /**
   * *** Advanced method ***
   * *** For internal framework use only ***
   * <p>
   * If this DCAppication is root, and the root's application module is not created,
   * this method creates a root BC4J Application Module using the root application module
   * def name and the context information (both passed to the constructor of the root DCDataControl).
   * @see oracle.jbo.ApplicationModule
   * @see oracle.jbo.ApplicationModuleHome#create
   * @throws oracle.jbo.ApplicationModuleCreateException if the application module is not
   * created, perhaps due to an improper root application module name.
   */
   public final void createRootApplicationModule()
   {
      if (!mIsRoot)
      {
         return;
      }

      if (mAM == null) 
      {
      
         if (mRootAMDefName == null || mRootAMDefName.length() == 0)
         {
            mRootAMDefName = ApplicationModule.DEFAULT_DEF_FULL_NAME;
         }
   
         try
         {
            Context ic = new InitialContext(mContext);
            ApplicationModuleHome home = (ApplicationModuleHome) ic.lookup(mRootAMDefName);
   
            mAM = home.create();
            setDataProvider(mAM);
         }
         catch(NamingException ex)
         {
            throw new ApplicationModuleCreateException(ex);
         }
      }
   }

   /**
   * Returns the context object with which the root DCApplication was created.
   */
   public final Hashtable getContext()
   {
      return ((DCJboDataControl)getRootDataControl()).mContext;
   }
   

   /**
   * *** For internal framework use only ***
   * If this DCDataControl is the root, and it has a BC4J package, it needs to preload.
   * This method could be used to load the BC4J package object by name. Use setPackageName() method
   * to set the package name to be loaded in this method. This method should be used
   * to preload the BC4J package metadata with which this application may work. 
   */
   final void loadPackage()
   {
      if (mIsRoot && mPackageName != null && mPackageName.length() != 0)
      {
         mAM.getSession().loadPackage(mPackageName);
      }
   }

   
   /**
   * *** For internal framework use only ***
   * If this application is root, this method invokes the corresponding BC4J Transaction's
   * connect() method to create a database connection. Also this method is used
   * to register the application as a TransactionStateListener on the BC4J Transaction object.
   */
   protected void connect()
   {
      if (mIsRoot)
      {
         mAM.getTransaction().connect(mDBConnectionURL, mDBConnectionProps);   
         mAM.getTransaction().addTransactionStateListener(this);
      }
   }

   
   /**
   * Returns root DCDataControl's ApplicationModule definition name.
   */
   public final String getRootAMDefName()
   {
      return ((DCJboDataControl)getRootDataControl()).mRootAMDefName;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final String getDBConnectionURL()
   {
      return mDBConnectionURL;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final Properties getDBConnectionProps()
   {
      return mDBConnectionProps;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final void setConnectionInfo(String dbConnectionURL, Properties dbConnectionProps)
   {
      mDBConnectionURL = dbConnectionURL;
      mDBConnectionProps = dbConnectionProps;
   }
   
   
   /**
   * *** For internal framework use only ***
   */
   public final String getPackageName()
   {
      return mPackageName;
   }


   /**
   * *** For internal framework use only ***
   */
   public final void setPackageName(String packageName)
   {
      mPackageName = packageName;
   }
   
   
   /**
   * Returns the locale for this Application
   */
   public final LocaleContext getLocaleContext()
   {
      ApplicationModule am = getApplicationModule();
      if (am != null) 
      {
         return am.getSession().getLocaleContext();
      }
      return super.getLocaleContext();
   }
   
   /**
   * Helper method that sets the locale in the current Application Module's session.
   */
   public final void setLocaleContext(LocaleContext locale)
   {
      ApplicationModule am = getApplicationModule();
      if (am != null && locale != null) 
      {
         am.getSession().setLocale(locale.getLocale());
      }
      super.setLocaleContext(locale);
   }

   /**
    * For EL evaluation.
    * Properties returned vis getter on this control bindings are:
   * <li><code>transactionDirty</code> - returns getApplicationModule().isTransactionDirty()</li>
    */
   protected Object internalGet(String key)
   {
      if (GET_TransactionDirty == key)
      {
         return Boolean.valueOf(isTransactionDirty());
      }
      return super.internalGet(key);
   }
   /**
   * Returns the associated oracle.jbo.ApplicationModule object
   */
   public final ApplicationModule getApplicationModule()
   {
      return mAM;
   }


   /**
    * Use this method to release connection to an Application Module
    */
   public void release(int flags)
   {
      if (!mInEndRequest && syncNeeded())
      {
         WSApplicationModuleImpl wsam =
            (WSApplicationModuleImpl)getApplicationModule();

         if (wsam != null && wsam.getImplObject() == null)
         {
            BindingContext ctx = getBindingContext();
            if (ctx  != null && ctx.isJClientApp())
            {
               resetState();
               endRequest(null);
            }
         }
      }

      super.release(flags);
      if (mIsRoot)
      {
         if ((flags & DCDataControl.REL_DATA_REFS) > 0)
         {
            if (mAM != null)
            {
              // JRS 3450394 isConnected() is potentially expensive.
              // In batchmode this will also result in a roundtrip.  Just
              // go ahead and handle the NotConnectedException
               try
               {
                  mAM.getTransaction().removeTransactionStateListener(this);
               }
               catch(oracle.jbo.NotConnectedException e) {}
            }
            
            if (flags == REL_ALL_REFS)
            {
               if (mAM != null && syncNeeded())
               {
                  // the batch AM knows how to cleanup the SC.
                  ((WSApplicationModuleImpl)mAM).closeWSApplicationModule();
               }
               else if (mSessionCookie != null)
               {
                  ((SessionCookieImpl)mSessionCookie).timeout();
               }
               else if (mAM != null)
               {
                  Configuration.releaseRootApplicationModule(mAM, true);
               }
               mSessionCookie = null;
            }
            
            mAM = null;
         }
      }
   }

   protected RowSetIterator getRowSetIterator(String masterName)
   {
      return mAM.findViewObject(masterName);
   }

   protected Object getAccessorValue(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName)
   {
      try
      {
         Object accessorVal = row.getAttribute(accName);
         if (accessorVal == null && syncNeeded() && !isObjectTypeIterator(iter) && masterRSI != null)
         {
            //if (mastersToExecute != null && mastersToExecute.containsKey(masterRSI.getName()))
            {
               //add this to WS to execute on next sync.
               executeIteratorBinding(iter);
               return null; //iterator will be created after sync.
            }
         }
         return accessorVal;
      }
      catch (oracle.jbo.InvalidOperException ioe)
      {
         if (this.syncNeeded())
         {
            //ignore ioe the first time.
            if (!iter.isIteratorMadeVisible())
            {
               //This takes care of exceptions in accessor invocation in case
               //of batchmode and no sync has occurred thus far for data/executing
               //any VOs.
               return null;
            }
         }
         throw ioe;
      }
   }

   private boolean isObjectTypeIterator(DCIteratorBinding iter)
   {
      DCIteratorBindingDef iterDef = iter.getDef();
      return (iterDef != null && iterDef.isObjectType());
   }
   
   protected RowSetIterator createAccessorRowSetIterator(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName, String beanClass, boolean trackMaster)
   {
      if (isObjectTypeIterator(iter))
      {
         //switch off findmode on this iterator as Object attributes
         //do not participate
         iter.setAllowFindMode(false);

         StructureDef def = null;
         oracle.jbo.domain.Struct struct = null;
         Class domainClz = null;
         if (row != null)
         {
            struct = (oracle.jbo.domain.Struct)getAccessorValue(masterRSI, row, iter, accName);
            if (struct != null)
            {
               domainClz = struct.getClass();
               def = struct.getStructureDef();
            }
         }

         if (domainClz == null)
         {
            //use attribute def to get to the def.
            StructureDef masterStr = null;
            if (masterRSI instanceof DCRowSetIteratorImpl)
            {
               masterStr = ((DCRowSetIteratorImpl)masterRSI).getStructureDef();
            }
            else if (masterRSI.getRowSet() != null)
            {
               masterStr = masterRSI.getRowSet().getViewObject();
            }
            if (masterStr != null)
            {
               AttributeDef ad = null;
               try
               {
                  ad = masterStr.lookupAttributeDef(accName);
               }
               catch (oracle.jbo.InvalidOperException ioe)
               {
                  //ignore as this happens in case of workingset 
                  //and we get a chance to get the structure def setup
                  //later on.
               }
               if (ad != null)
               {
                  domainClz = ad.getJavaType();
               }
            }
         }

         if (domainClz != null && def == null)
         {
            def = oracle.jbo.domain.Struct.resolveAndGetStructureDef(domainClz); 
         }

         return new DCDomainRowSetIteratorImpl(this, struct, accName, def, domainClz, row);

      }
      else
      {
         try
         {
            if (syncNeeded())
            {
               if (masterRSI != null)
               {
                  if (mastersToExecute != null && mastersToExecute.containsKey(masterRSI.getName()))
                  {
                     //add this to WS to execute on next sync.
                     executeIteratorBinding(iter);
                     return null; //iterator will be created after sync.
                  }
               }
            }
            return super.createAccessorRowSetIterator(masterRSI, row, iter, accName, beanClass, trackMaster);
         }
         catch (oracle.jbo.InvalidOperException ioe)
         {
            if (this.syncNeeded())
            {
               //ignore ioe the first time.
               if (!iter.isIteratorMadeVisible())
               {
                  //This takes care of exceptions in accessor invocation in case
                  //of batchmode and no sync has occurred thus far for data/executing
                  //any VOs.
                  return null;
               }
            }
            throw ioe;
         }
      }
   }

   public RowSetIterator createAccessorRowSetIterator(RowSetIterator masterRSI, 
                                                      DCIteratorBinding iter,
                                                      String accName, 
                                                      String beanClass)
   {
      Row row = null;
      if (isObjectTypeIterator(iter))
      {
         StructureDef def = null;

         row = masterRSI.getCurrentRow();
         if (row == null)
         {
            //this will throw in case of batchmode in the first set of executes
            //before sync for domains.
            try
            {
               row = masterRSI.first();
            }
            catch (InvalidOperException ioe)
            {
               if (!syncNeeded())
               {
                  throw ioe;
               }
               Diagnostic.println("Warning! Ignoring InvalidOperException in case of domain access in batchmode");
            }
         }
      }
      return createAccessorRowSetIterator (masterRSI, row, iter, accName, beanClass);
   }

   protected RowSetIterator createRowSetIteratorImpl(String defName, 
                                                  Object sourceObj, 
                                                  RowSetIterator master)
   {
      RowSetIterator rsi = null;
      if (sourceObj instanceof RowSetIterator)
      {
         return (RowSetIterator)sourceObj;
      }
      
      StructureDef def = null;//dc.getApplicationModule().findViewObject(defName);
      if (sourceObj instanceof Row)
      {
         def = ((Row)sourceObj).getStructureDef();
      }
      else if (sourceObj instanceof Row[] )
      {
         Row[] rows = (Row[])sourceObj;
         if (rows.length > 0)
         {
            def = rows[0].getStructureDef();
         }
      }
      else if (defName != null) 
      {
         //as the last defence.
         //this requires that the VO by this name (if found) has been
         //sync'ed and the definition is on the client side so that
         //attributedefs can be found in it.
         def = getApplicationModule().findViewObject(defName);
      }

      if (def == null)
      {
         def = new StructureDefImpl(this, defName, "methodRSIStructure");
      }

      return new DCRowSetIteratorImpl(this, sourceObj, "methodArrayIterator", def);
   }

   protected void executeIteratorBinding(DCIteratorBinding iterBinding)
   {
      if (mSyncNeeded)
      {
         DCIteratorBindingDef def = iterBinding.getDef();
         if (def != null && def.getSubType() == DCDefBase.PNAME_AccessorIterator)
         {
            StringBuffer buf = new StringBuffer();
            //fill the String for accessor path in.

            WSViewObjectImpl vo = (WSViewObjectImpl)((JUAccessorIteratorDef)iterBinding.getDef()).calcAccessorPath(iterBinding, buf);
            // vo.setAttributeAccessorPath(new String[]{buf.toString()});
            vo.setAccessorTraversalByNamePaths(new String[]{buf.toString()});
            if (iterBinding.needsEstimatedRowCount())
            {
               vo.requestEstimatedRowCount();
            }
         }
         else
         {
            RowSetIterator wsrsi = iterBinding.getRowSetIterator(); 
            if (wsrsi != null)
            {
               if (mastersToExecute == null)
               {
                  mastersToExecute = new HashMap(7);
               }
               mastersToExecute.put(wsrsi.getName(), null);
            }

            ((WSViewObjectImpl) iterBinding.getViewObject()).refreshDataModel();

            if (iterBinding.needsEstimatedRowCount())
            {
               ((WSRowSet)wsrsi.getRowSet()).requestEstimatedRowCount();
            }
         }
      }
      else
      {
         RowSetIterator rsi = iterBinding.getRowSetIterator();
         RowSet rs = rsi.getRowSet();
         if (rs != null)
         {
            rs.executeQuery();
         }
      }
   }
   
   protected void executeIteratorBindingIfNeeded(DCIteratorBinding iterBinding)
   {

      //for batchmode, do not force getRowSetIterator as we may not have the rows
      //to call accessors on yet? Simply add the accessor path.
      //if (!iterBinding.hasRSI() || iterBinding.getRowSetIterator() == null)
      if (mSyncNeeded && !iterBinding.hasRSI())
      {
         DCIteratorBindingDef def = iterBinding.getDef();
         if (def != null && def.getSubType() == DCDefBase.PNAME_AccessorIterator)
         {
            StringBuffer buf = new StringBuffer();
            //fill the String for accessor path in.
            WSViewObjectImpl vo = (WSViewObjectImpl)((JUAccessorIteratorDef)iterBinding.getDef()).calcAccessorPath(iterBinding, buf);
            // vo.setAttributeAccessorPath(new String[]{buf.toString()});
            vo.setAccessorTraversalByNamePaths(new String[]{buf.toString()});
            if (iterBinding.needsEstimatedRowCount())
            {
               vo.requestEstimatedRowCount();
            }
            return;
         }
      }

      RowSetIterator rsi = iterBinding.getRowSetIterator();

      //check for RSI, if not try to get one and if it's null, return as we do not
      //have any object to execute the query on.

      if (rsi != null) 
      {
         RowSet rs = rsi.getRowSet();
         if (rs == null)
         {
            //this is for accessors/method returns that return non-bc4j collections.
            super.rebuildIteratorIfNeeded(iterBinding);
         }
         else if (!rs.isExecuted())
         {
            if (mSyncNeeded)
            {
               WSRowSet wrs = (WSRowSet)rs;

               //Sung, if I enable this call instead of refreshDataModel, 
               //then accessor details do not get executed.

               //wrs.executeQuery2(false, false);
               // wrs.refreshDataModel();
               wrs.refreshDataModel2(true /*resetCurrency*/, false /*force*/);
               if (iterBinding.needsEstimatedRowCount())
               {
                  // ((WSViewObjectImpl) iterBinding.getViewObject()).getEstimatedRowCount();
                  wrs.requestEstimatedRowCount();
               }
            }
            else
            {
               rs.executeQuery();
            }
         }
      }
   }

   public void setCurrentRowWithKeyValue(DCIteratorBinding iter, String stringValue)
   {
      RowSetIterator rsi = iter.getRowSetIterator();
      ViewObject vo = rsi.getRowSet().getViewObject();
      AttributeDef ads[] = vo.getKeyAttributeDefs();
      if (ads.length == 1)
      {
         Object keyVal = TypeFactory.getInstance(ads[0].getJavaType(), stringValue);
         Key key = new Key(new Object[]{keyVal});
         /*
         Row rows[] = rsi.findByKey(key,1);
         Row r = null;
         if (rows.length > 0)
         {
            r = rows[0];
         }
         */
         setCurrentRowInRSI(iter, rsi, null, key);
      }
   }

   public void setCurrentRowWithKey(DCIteratorBinding iter, String stringKey)
   {
      RowSetIterator rsi = iter.getRowSetIterator();
      // RowSet rs = rsi.getRowSet();
      try
      {
         setCurrentRowInRSI(iter, rsi, null, //JboUtil.getRowFromKey(rsi, stringKey),
                     new Key(stringKey, rsi.getRowSet().getViewObject().getKeyAttributeDefs()));
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Throwable th)
      {
         throw new JboException(th);
      }
   }

   public void setCurrentRowWithKey(DCIteratorBinding iter, Key keyObj)
   {
      RowSetIterator rsi = iter.getRowSetIterator();
      try
      {
         setCurrentRowInRSI(iter, rsi, null, keyObj);
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Throwable th)
      {
         throw new JboException(th);
      }
   }


   void setCurrentRowInRSI(DCIteratorBinding iter, RowSetIterator rsi, Row r, Key key)
   {
      /*
      if (r == null && syncNeeded())
      {
         //resort to linear search in batchmode.
         //hoping there aren't too many rows in the range on the client side.
         Row rows[] = rsi.getAllRowsInRange();
         try
         {
            for (int i = 0; i < rows.length; i++)
            {
               if (key.equals(rows[i].getKey()))
               {
                  r = rows[i];
                  break;
               }
            }
         }
         catch (oracle.jbo.JboException je)
         {
            throw je;
         }
         catch (Exception e)
         {
         }
      }

      if (r != null)
      */

      if (r == null && syncNeeded())
      {
         if(rsi instanceof WSRowSetIteratorBase)
         {
            ((WSRowSetIteratorBase)rsi).findAndSetCurrentRowByKey(key, 0);
         }
         else if(rsi instanceof java.lang.reflect.Proxy)
         {
             WSRowSetIteratorBase wsvo = null;
             oracle.jbo.common.ws.WSProxy wspro = (oracle.jbo.common.ws.WSProxy)(java.lang.reflect.Proxy.getInvocationHandler(rsi));
             wsvo = wspro.getWSViewObject();
             ((WSRowSetIteratorBase)wsvo).findAndSetCurrentRowByKey(key, 0);
         }
      }
      Row rows[] = rsi.findByKey(key, 1);
      if (rows != null && rows.length > 0)
      {
         if (!rsi.getRowSet().isExecuted()) 
         {
            //if RSI is not executed, then in ondemand mode,
            //currency will be lost if someone lateron
            //tries to getcurrent row from an iterator binding.
            rsi.getRowSet().executeQuery();
            
            //need to force this again so that row belongs to the
            //right rsi post execution.
            rows = rsi.findByKey(key, 1);
         }
         rsi.setCurrentRow(rows[0]);
      }
      else
      {
         oracle.jbo.common.Diagnostic.println("Currency not set, no row found with key :"+key);
         throw new RowNotFoundException(CSMessageBundle.class,
                                                   CSMessageBundle.EXC_VIEW_ROW_NOT_FOUND, 
                                                   new Object[]{iter.getName(), key});
      }
   }

   protected long getEstimatedRowCount(DCIteratorBinding iter)
   {
      long size = 0;
      try
      {
         RowSetIterator rsi = iter.getRowSetIterator();
         if (rsi != null)
         {
            RowSet rs = rsi.getRowSet();
            if (rs != null)
            {
               if (rs.isExecuted()) 
               {
                  size = rs.getEstimatedRowCount();
                  //do not force VO execution.
                  if (size <= 0)
                  {
                     if (iter.needsEstimatedRowCount())
                     {
                        //this leads to infinite cycles.
                        //this.getApplicationModule().sync();              
                        //size = rsi.getRowSet().getEstimatedRowCount();
                     }
                     size = rsi.getRowCountInRange();
                  }
               }
            }
            else
            {
               size = rsi.getRowCount();
            }
         }
      }
      catch(Exception ex)
      {
         reportException(iter.getBindingContainer(), ex);
      }
      return size;
   }


   /**
    * @javabean.property 
    * Returns true if the Transaction for this DataControl's ApplicationModule is marked dirty.
    */
   public boolean isTransactionDirty()
   {
      return isTransactionModified() || (mAM != null && mAM.getTransaction().isDirty());
   }

   public void commitTransaction()
   {
      getApplicationModule().getTransaction().commit();
   }

   public void validate()
   {
      getApplicationModule().getTransaction().validate();
   }

   public void rollbackTransaction()
   {
      getApplicationModule().getTransaction().rollback();
   }


   /**
    * Returns true for find, create, remove operations.
    * Returns false for CTRL_BINDING_VALIDATION if BC4J is deployed in 
    * local mode as that'd avoid dupliate validation in setters.
    */
   public boolean isOperationSupported(DCIteratorBinding iterBinding, byte oper)
   {
      if (iterBinding == null)
      {
         return false;
      }
      switch (oper)
      {
         //how about method returns. They do not support qbe. 
         case OPER_FIND_MODE: 
            if (!iterBinding.isFindModeAllowed())
            {
               return false;
            }
            else
            {
               DCIteratorBindingDef iterDef = iterBinding.getDef();
               if (iterDef != null && DCDefBase.PNAME_MethodIterator.equals(iterDef.getSubType()))
               {
                  if (iterBinding.hasRSI()) 
                  {
                     if (iterBinding.getNavigatableRowIterator() instanceof DCRowSetIteratorImpl)
                     {
                        //not supported for non-bc4j collections in bc4j dc
                        return false;
                     }
                  }
               }
            }
            return true;

         case OPER_EXECUTE: 
            if (iterBinding.isIteratorMadeVisible())
            {
               if (iterBinding.getViewObject() == null)
               {
                  //generic RSI case.
                  return false;
               }
            }
            return true;

         case OPER_DATA_ROW_CREATE:
         case OPER_DATA_ROW_REMOVE:
            {
               if (this.isObjectTypeIterator(iterBinding))
               {
                  if (iterBinding.isIteratorMadeVisible())
                  {
                     DCBindingContainer bc = iterBinding.getBindingContainer();
                     if (bc != null && bc.isFindMode())
                     {
                        //if bindingcontainer is in find mode do not allow 
                        //data to be created/removed from object type iterator.
                        return false;
                     }
                     DCDomainRowSetIteratorImpl rsi = (DCDomainRowSetIteratorImpl)iterBinding.getRowSetIterator();
                     if (rsi != null && rsi.getOwnerRow() != null)
                     {
                        if (rsi != null && rsi.getFetchedRowCount() == 0)
                        {
                           if (rsi.getDomainJavaType() != null)
                           {
                              return (oper == OPER_DATA_ROW_CREATE);
                           }
                        }
                        else
                        {
                           return (oper == OPER_DATA_ROW_REMOVE);
                        }
                     }
                  }
                  return false;
               }
               if (iterBinding.isFindMode())
               {
                  return true;
               }
               //check for RSI as we do not want to do early execution
               //of accessor/method rsis.
               if (iterBinding.hasRSI())
               {
                  oracle.jbo.ViewObject vo = iterBinding.getViewObject();
                  if (vo != null)
                  {
                     if (syncNeeded())
                     {
                        //if in batchmode and VO has not been synced yet, return false;
                        if (vo instanceof WSViewObjectImpl)
                        {
                           if (((WSViewObjectImpl)vo).getImplObject() == null)
                           {
                              return false;
                           }
                        }
                     }
                     return !vo.isReadOnly();
                  }
               }
            }
            return false;

         case OPER_CTRL_BINDING_VALIDATION:
            {
               switch (mValidationInBinding) 
               {
                  case VAL_MODE_REMOTE:
                  {
                     if (mDeployMode == DEPLOY_UNRESOLVED)
                     {
                        mDeployMode = (mAM.getSession().isClient()) ? DEPLOY_REMOTE : DEPLOY_LOCAL;
                     }
                     return (mDeployMode != DEPLOY_LOCAL);
                  }
   
                  case VAL_MODE_NEVER:
                     return false;
   
                  case VAL_MODE_ALWAYS:
                  default:
                     return true;
               }
            }

         case OPER_SORT_COLLECTION: 
            {
               DCIteratorBindingDef def = iterBinding.getDef();
               return (def == null || def.getSubType() == DCDefBase.PNAME_Iterator);
            }

         case OPER_DATA_ROW_UPDATE: 
            {
               if (iterBinding.hasRSI())
               {
                  oracle.jbo.ViewObject vo = iterBinding.getViewObject();
                  if (vo != null)
                  {
                     if (syncNeeded())
                     {
                        //if in batchmode and VO has not been synced yet, return false;
                        if (vo instanceof WSViewObjectImpl)
                        {
                           if (((WSViewObjectImpl)vo).getImplObject() == null)
                           {
                              return false;
                           }
                        }
                     }
                     return !vo.isReadOnly();
                  }
               }
               
               //no VO case.
               if (iterBinding.isFindMode())
               {
                  //no VO. turn off findmode.
                  return false;
               }

               if (this.isObjectTypeIterator(iterBinding))
               {
                  if (iterBinding.isIteratorMadeVisible())
                  {
                     DCBindingContainer bc = iterBinding.getBindingContainer();
                     if (bc != null && bc.isFindMode())
                     {
                        //no query is allowed on domain iterators.
                        return false;
                     }
                     if (iterBinding.hasRSI()) 
                     {
                        DCDomainRowSetIteratorImpl rsi = (DCDomainRowSetIteratorImpl)iterBinding.getRowSetIterator();
                        if (rsi != null && rsi.getOwnerRow() != null)
                        {
                           if (rsi.getDomainJavaType() != null)
                           {
                              return true;
                           }
                        }
                     }
                  }
               }
            }
            return super.isOperationSupported(iterBinding, oper);

         default:
            return super.isOperationSupported(iterBinding, oper);
      }
   }

   /**
    * Returns true if this data-control's Application module is deployed in three-tier mode
    */
   public boolean isClientTier()
   {
      // return JboEnvUtil.isClient(getApplicationModule().getSession().getEnvironment());
      return getApplicationModule().getSession().isClient();
   }

   public boolean syncNeeded()
   {
      return ((DCJboDataControl)getRootDataControl()).mSyncNeeded;
   }

   void syncWithForceOption(String syncFromDiagnostic, boolean force)
   {
      if (syncNeeded() && force == false)
      {
         WSApplicationModuleImpl wsam =
            (WSApplicationModuleImpl)getApplicationModule();

         if (wsam.isSyncNeeded() == false)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("*** DCDataControl.sync() SKIP visit to MT: " + syncFromDiagnostic);
            }

            return;
         }
      }

      if (Diagnostic.isOn())
      {
         DebugDiagnostic.println("**********************************************");
         Diagnostic.println("*** DCDataControl.sync() called from :"+syncFromDiagnostic);
         DebugDiagnostic.println("**********************************************");
      }

      mastersToExecute = null;
      boolean txnDirty = isTransactionDirty();
      getApplicationModule().sync();
      if (txnDirty != isTransactionDirty()) 
      {
         //sync up the MT txn dirty state with the bindings as it may
         //have changed in the MT gvbm3 sv04
         internalSetTransactionStateChanged(!txnDirty);
      }

   }

   public void syncIfNeeded(String syncFromDiagnostic)
   {
      syncWithForceOption(syncFromDiagnostic, false /*force*/);
   }
   
   public void sync(String syncFromDiagnostic)
   {
      syncWithForceOption(syncFromDiagnostic, true /*force*/);
   }


   /**
    * Incase of non-JClient, set the transaction to deferred exception mode by default
    */
   public void setClientApp(byte clientType)
   {
      super.setClientApp(clientType);
      resolveBundledExceptionMode();
   }

   private int mExcMode = EXC_MODE_DEFAULT;


   int getBundledExceptionMode()
   {
      return (mExcMode != EXC_MODE_DEFAULT) 
                ? mExcMode
                : ((isJClientApp()) 
                      ? EXC_MODE_IMMEDIATE
                      : EXC_MODE_DEFERRED);
   }

   private void resolveBundledExceptionMode()
   {
      boolean excMode = !isJClientApp();
      if (mExcMode == EXC_MODE_DEFERRED)
      {
         excMode = true;
      }
      else if (mExcMode == EXC_MODE_IMMEDIATE)
      {
         excMode = false;
      }

      if (mSessionCookie != null)
      {
         mSessionCookie.getUserData().put(SessionCookie.BUNDLED_EXC_MODE_KEY, new Boolean(excMode));
      }
   }

   public void setBundledExceptionMode(int mode)
   {
      switch (mode)
      {
         case EXC_MODE_DEFERRED:
            mExcMode = EXC_MODE_DEFERRED;
         break;
         case EXC_MODE_IMMEDIATE:
            mExcMode = EXC_MODE_IMMEDIATE;
         break;
         default:
            mExcMode = EXC_MODE_DEFAULT;
            break;
      }
      resolveBundledExceptionMode();
   }

   /**
    * *** For internal framework use only ***
    */
   public void setValidationInBinding(int flag)
   {
      switch (flag) 
      {
      case VAL_MODE_NEVER:
         mValidationInBinding = VAL_MODE_NEVER;
         break;

      case VAL_MODE_UNINIT: //kava 
      case VAL_MODE_REMOTE:
         mValidationInBinding = VAL_MODE_REMOTE;
         break;

      case VAL_MODE_ALWAYS:
      default:
         mValidationInBinding = VAL_MODE_ALWAYS;
      }
   }

   /**
    * *** For internal framework use only ***
    */
   public int getValidationInBinding()
   {
      return mValidationInBinding;
   }

   /**
    * *** For internal framework use only ***
    */
   void setSyncNeeded(boolean flag)
   {
      mSyncNeeded = flag;
   }

   public void prepareSession()
   {
      if (syncNeeded())
      {
         BindingContext ctx = getBindingContext();
         if (ctx  != null && ctx.isJClientApp())
         {
            beginRequest(null);
         }

         // JRS 09/28/05 Commented this sync call.
         // It was causing an extra checkout for web client because
         // beginRequest was not invoked yet to pin the AM.  Why do we need
         // to sync here?
         //((WSApplicationModuleImpl)getApplicationModule()).sync();
      }
   }

   public void beginRequest(HashMap requestCtx)
   {
      if (!mInRequest)
      {
         mInRequest = true;

         super.beginRequest(requestCtx);
         
         rebuildApplicationModule();

         if (syncNeeded())
         {
            ((WSApplicationModuleImpl)mAM).beginRequest(requestCtx);
         }
         else
         {
            ADFContext adfContext = ADFContext.getCurrent();
            if (adfContext.hasEnvironment())
            {
               mSessionCookie.writeValue(
                  adfContext.getEnvironment().getRequest());
            }
         }
      }
   }

   public void endRequest(HashMap requestCtx)
   {
      try
      {
         mInEndRequest = true;

         super.endRequest(requestCtx);
         // if mAM is not null then endRequest did not result in resetState
         // let's go ahead and release managed state.
         if (mAM != null)
         {
            releaseApplicationModule(true);

            if (syncNeeded())
            {
               if (requestCtx == null)
               {
                  requestCtx = new HashMap(1);
               }

               requestCtx.put(
                  WSApplicationModuleImpl.END_REQUEST_RELEASE_LEVEL
                  , new Integer(getReleaseLevel()));

               ((WSApplicationModuleImpl)mAM).endRequest(requestCtx);
            }
         }

         if (mSessionCookie != null)
         {
            // JRS  only adding the passivation id to the state manager for
            // right now.  Having an issue with the classloader when
            // deserializing the HttpSessionCookie (ClassNotFoundException).
            //
            // This should not be too much of an issue for the following
            // reasons:
            //
            // 1.  The mSessionCookie is cached in the BindingContext via
            // the DataControl.
            //
            // 2.  The only real state on the SessionCookie is the passivation
            // id.
            //
            // Of course, this means that failover will not protect a
            // custom cookie environment, the previous passivation id, etc.
            // Still need to fix the ClassLoader issue.
            if (mSessionCookie.isFailoverEnabled())
            {
               Hashtable adapterEnv = new Hashtable(4);

               // setup the distributable policy
               adapterEnv.put(
                  StateManagerScopeAdapter.ENV_STATE_MANAGER_POLICY_KEY
                  , new DefaultPolicyImpl(true, true, -1));

               ADFContext adfCtx = ADFContext.getCurrent(); 
               Map adapter = adfCtx.getStateManager(
                  ADFContext.SESSION_SCOPE, adapterEnv);
   
               String name = getName();
   
               // JRS The name can be null in kava testing.  Generate
               // a name for the DC.
               if (name == null) name = DCJboDataControl.class.getName();
   
               adapter.put(name, String.valueOf(mSessionCookie.getPassivationId()));
            }
            // getBindingContext()
            //   .addPersistentState(getName(), mSessionCookie);
         }
      }
      finally
      {
         mInEndRequest = false;
         mInRequest = false;
      }
   }

   public boolean resetState()
   {
      if (super.resetState())
      {
         releaseApplicationModule(false);

         Map stateManager = ADFContext.getCurrent().getStateManager(
            ADFContext.SESSION_SCOPE, null);

         String name = getName();
         if (name == null) name = DCJboDataControl.class.getName();

         stateManager.remove(name);

         if (!mInEndRequest)
         {
            rebuildApplicationModule();
         }

         return true;
      }

      return false;
   }

   private void rebuildApplicationModule()
   {
      if ((mAM == null) && syncNeeded())
      {
         setApplicationModule(new WSApplicationModuleImpl(mSessionCookie));
         prepareSession();
      }

      // this will add a deferred request if the AM is not already
      // checked out.  The cookie will do nothing if failover is not
      // enabled.
      if (mSessionCookie != null) 
      {
         mSessionCookie.reservePassivationId();

         if (!syncNeeded())
         {
            //guava comes through this route the first time am is established.
            setApplicationModule(mSessionCookie.useApplicationModule());

            // JRS If the cookie was activated during use then check for txn
            // dirtiness.  This is handled for the batch case in construction
            // handle it here for immediate b/c the constructor is fairly
            // overloaded.  Should consider about handling it in a single place
            // for both batch and immediate in 9.0.5.2.  There is a concern
            // here that an activation occured while the DC was still in scope
            // (loss of affinity).  In this case this code may be redundant.
            // However, this should be very cheap for:
            // 1.  Loss of affinity is exception case
            // 2.  setTransactionModified should be re-entrant -- only performs
            //    work if txn is not modified.
            if (mSessionCookie.wasActivated() && mAM.getTransaction().isDirty())
            {
               setTransactionModified();
            }
         }
      }
   }

   public ViewObject findCustomViewObject(String name, String interfaceName)
   {
      
      ApplicationModule am = getApplicationModule();
      if(am == null)
      {
         throw new IllegalStateException();
      }
      if(syncNeeded())
      {
         WSApplicationModuleImpl wsam = (WSApplicationModuleImpl) am;
         return wsam.findCustomViewObject(name,  interfaceName);
      }
      else
      {
         return am.findViewObject(name);
      }
   }

   private void releaseApplicationModule(boolean manageState)
   {
      // release the AM reference whenever we are not managing state
      // or not in batch mode.  We can hold the AM reference in batch mode
      // b/c the server AM reference is still being released.
      if (!manageState)
      {
         // JRS Only do a full release if we have a DCDef.  If 
         // the Def is null then we won't be able to transition to
         // a Ref and the DC will be permanently lost.
         // This should solely be a backwards compatibility check.
         if (getDef() != null)
         {
            // JRS Why bother firing the resetState on the WSAM?  We are not
            // firing anything on the immediate AM.
            //if (syncNeeded())
            //{
            //   mAM.resetState(ApplicationModule.RESET_CLIENT_ONLY_FLAG);
            //
            //   // fire endRequest on the WSAM now.  the WS must release the 
            //   // SC now since we will soon be releasing all refs (including
            //   // the WSAM).
            //   if (mInEndRequest)
            //   {
            //      ((WSApplicationModuleImpl)mAM).endRequest(requestCtx);
            //   }
            //}

            // if we are not managing state then go ahead and release the
            // entire data control.
            release(DCDataControl.REL_ALL_REFS);
         }
         else
         {
            if (syncNeeded())
            {
               mAM.resetState(ApplicationModule.RESET_CLIENT_ONLY_FLAG);
            }

            release(DCDataControl.REL_DATA_REFS);

            setDataProvider(null);
         }
      }
      else if (!syncNeeded())
      {
         release(DCDataControl.REL_DATA_REFS);

         setDataProvider(null);

         // JRS WSApplicationModuleImpl.endRequest handles the release for
         // the syncNeeded case -- WSApplicationModuleImpl.beginRequest is now
         // handling the acquisition.
         if ((getReleaseLevel()
            & ApplicationModule.RELEASE_LEVEL_RESERVED) > 0)
         {
            mSessionCookie.releaseApplicationModule(
               SessionCookie.RESERVED_UNMANAGED_RELEASE_MODE);
         }
         else
         {
            mSessionCookie.releaseApplicationModule(
               SessionCookie.SHARED_MANAGED_RELEASE_MODE);
         }
      }
      else // manageState && syncNeeded()
      {
         // JRS 3/8/2004 Fix 3492628.  Release weak data references.  An
         // application developer may not require that the data provider of
         // these references is passivatable.  As a result, the references
         // may not survive an activation.  Release them to be certain.
         release(DCDataControl.REL_WEAK_DATA_REFS);
      }
   }

   protected void setDataProvider(Object provider)
   {
      if(provider instanceof WSApplicationModuleImpl)
      {
         provider = ((WSApplicationModuleImpl)provider).getCustomApplicationModule();
      }
      super.setDataProvider(provider);
   }

   public AttributeDef[] getAttributeDefs(DCIteratorBinding iterBinding, String[] attrNames)
   {
      RowSetIterator rsi = iterBinding.getRowSetIterator();
      if (rsi instanceof DCRowSetIteratorImpl)
      {
         return super.resolveAttributeDefs(((DCRowSetIteratorImpl)rsi).getStructureDef(), attrNames);
      }
      return  new AttributeDef[0];
   }

   public void setSessionCookie(SessionCookie sessionCookie)
   {
      mSessionCookie = sessionCookie;
      resolveBundledExceptionMode();
   }


   /**
    * Sets the sort critiera that will be applied next time when the 
    * source for this iteratorBinding is executed.
    */
   protected void applySortCriteria(DCIteratorBinding iter, SortCriteria[] sortBy)
   {
      if (sortBy != null)
      {
         ViewObject vo = iter.getViewObject();

         if (syncNeeded())
         {
            ((WSApplicationModuleImpl)mAM).applyVOSortCriteria(vo, sortBy);
         }
         else
         {
            oracle.jbo.common.JboEnvUtil.applyVOSortCriteria(vo, sortBy);
         }
      }
   }

   /**
    * Returns an ordered array of SortCriteria that will be applied when
    * the source for this iteratorBinding is executed.
    */
   protected SortCriteria[] getSortCriteria(DCIteratorBinding iter)
   {
      //we could do a getOrderByClause and parse it.
      return null;
   }

   public Object createRowData (DCRowContext ctx)
   {
      RowSetIterator rsi = ctx.getRowSetIterator();
      if (rsi instanceof DCDomainRowSetIteratorImpl)
      {
         DCDomainRowSetIteratorImpl domainRSI = (DCDomainRowSetIteratorImpl)rsi;
         Row owner = domainRSI.getOwnerRow();
         if (owner != null)
         {
            Class domainClz = domainRSI.getDomainJavaType();
            try
            {
               Object domain = domainClz.newInstance();
               owner.setAttribute(rsi.getName(), domain);
               return domain;
            }
            catch (JboException je)
            {
               throw je;
            }
            catch (Exception e)
            {
               throw new JboException(e);
            }
         }
      }
      //should this throw here?
      return null;

   }

   public boolean removeRowData (DCRowContext ctx)
   {
      RowSetIterator rsi = ctx.getRowSetIterator();
      if (rsi instanceof DCDomainRowSetIteratorImpl)
      {
         DCDomainRowSetIteratorImpl domainRSI = (DCDomainRowSetIteratorImpl)rsi;
         domainRSI.getOwnerRow().setAttribute(rsi.getName(), null);
         domainRSI.clearCurrentData();
         return true;
      }
      return true;
   }

   /**
    * @internal *** For internal framework use only ***
    * 
    * Called primarily for find mode to allow findmode to save out row changes 
    * incase of batchmode.
    */
   public void setAttributeInRow(DCIteratorBinding iterBind, Row row, AttributeDef ad, Object value)
   {
      super.setAttributeInRow(iterBind, row, ad, value);
      if (iterBind.isFindMode())
      {
         if (syncNeeded())
         {
            ((WSApplicationModuleImpl)mAM).setIsSyncNeeded(true);
            //force view criteria to be applied.
            getViewCriteria(iterBind);
         }
         else if (isClientTier())
         {
            //force view criteria to be applied in immediate 3tier.
            getViewCriteria(iterBind);
         }
      }
   }

   public ViewCriteria createViewCriteria(DCIteratorBinding iter)
   {
      if (iter.getViewObject() != null) 
      {
         return iter.getViewObject().createViewCriteria();
      }
      return null;
   }

   public ViewCriteria getViewCriteria(DCIteratorBinding iter)
   {
      ViewCriteria vc = null;
      ViewObject vo = iter.getViewObject();
      if (vo != null)
      {
         vc = vo.getViewCriteria();
         if (vc == null) 
         {
            vc = vo.createViewCriteria();
            //set this VC instance on the VO so that other iterbindings
            //share it.
         }
         vo.applyViewCriteria(vc);
         if (syncNeeded())
         {
            ((WSApplicationModuleImpl)mAM).setIsSyncNeeded(true);
         }
      }
      return vc;
   }


   public void applyViewCriteria(ViewCriteria vc, DCIteratorBinding iter, RowSetIterator rsi)
   {
      if (rsi instanceof ViewObject) 
      {
         ((ViewObject)rsi).applyViewCriteria(vc);
      }
      else if (rsi.getRowSet() != null) 
      {
         rsi.getRowSet().getViewObject().applyViewCriteria(vc);
      }
      else
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("Warning.... Can't apply criteria to this iteratorbinding :"+iter.getName()); 
         }
      }
   }

   protected void internalSetTransactionStateChanged(boolean state)
   {
      if (state && !isTransactionModified()) 
      {
         //verify if this is true in the bc4j layer as well.
         //for immediate 3tier, this is one remote call as of now.
         if (!getApplicationModule().getTransaction().isDirty()) 
         {
            //ignoring state changed event from binding layer
            //as bc4j txn is not dirty.
            return;
         }
      }

      super.internalSetTransactionStateChanged(state);
   }

   protected boolean isBoundRowIteratorEvent(DCIteratorBinding iter, JboEvent ev)
   {
      if (iter.getNavigatableRowIterator() == ev.getSource())
      {
         return true;
      }

      if (syncNeeded())
      {
         RowIterator ri = iter.getNavigatableRowIterator();
         if (ri instanceof WSRowSetIteratorBase) 
         {
            return (((WSRowSetIteratorBase)ri).getImplObject() == ev.getSource());
         }
      }

      return false;
   }

   /**
    * @see oracle.jbo.ApplicationModule#getReleaseLevel()
    */
   public int getReleaseLevel()
   {
      if (mAM != null)
      {
         return mReleaseLevel | mAM.getReleaseLevel();
      }
      else
      {
         return mReleaseLevel;
      }
   }

   /**
    * @see oracle.jbo.ApplicationModule#setReleaseLevel(int)
    */
   public void setReleaseLevel(int releaseLevel)
   {
      if (mAM != null)
      {
         mAM.setReleaseLevel(releaseLevel);
      }
      mReleaseLevel = releaseLevel;
   }

   /**
    * @internal *** For internal framework use only ***
    */
   public void executeIteratorBindingWithParams(DCIteratorBinding iter, OperationParameter params[], Object[] paramVals)
   {
      RowSet rs = iter.getRowSetIterator().getRowSet();

      VariableValueManager voVarMgr = (VariableValueManager)rs.ensureVariableManager();
      //Variable[] voVars = voVarMgr.getVariablesOfKind(Variable.VAR_KIND_WHERE_CLAUSE_PARAM);
      Variable varObj;
      
      if (params != null) 
      {
         String varName;
         //Object oldVal;
         //Object newVal;
         for (int i = 0; i < params.length; i++)
         {
            varName = params[i].getName();
            varObj = voVarMgr.lookupVariable(varName);
            if (varObj != null) 
            {
               //oldVal = voVarMgr.getVariableValue(varObj);
               voVarMgr.setVariableValue(varName, paramVals[i]);
               
               // use converted param value 
               rs.setNamedWhereClauseParam(varName, voVarMgr.getVariableValue(varName));

               //newVal  = voVarMgr.getVariableValue(varName); 
            }
         }
      }

      rs.executeQuery();
   }



   protected Object invokeMethod(DCInvokeMethod method, OperationBinding action, java.util.Map paramsMap)
   {
      if (FINDVOWITHPARAMS.equals(method.getMethodName())) 
      {
         //verify if the parameters is three values - voname/variableManager/executeFlag
         OperationParameter params[] = method.getParameters();
         Object paramVals[] = new Object[params.length];
         for (int i = 0; i < params.length; i++) 
         {
            paramVals[i] = params[i].getValue();
         }
         String voName = (String)params[0].getValue();
         VariableManager varMgr = null;
         boolean toExecute = true;

         if (params.length == 3) 
         {
            if (VARAIBLE_MANAGER_CLASS.equals(params[1].getTypeName())) 
            {
               varMgr = (VariableManager)params[1].getValue();
               toExecute = ((Boolean)params[2].getValue()).booleanValue();
            }
         }
         if (varMgr == null) 
         {
            VariableValueManagerImpl copyVars = new VariableValueManagerImpl(null, null);
            VariableImpl variable;
            OperationParameter param;
            for (int i = 1; i < params.length; i++) 
            {
               param = params[i];
               copyVars.addVariable(param.getName());
               variable = (VariableImpl)copyVars.lookupVariable(param.getName());
               try
               {
                  variable.setJavaType(JBOClass.forName(param.getTypeName()));
               }
               catch (ClassNotFoundException cnfe)
               {
                  //ignore.
               }
               copyVars.setVariableValue(param.getName(), param.getValue());
            }
            varMgr = copyVars;
         }
         ApplicationModule am = (ApplicationModule)method.getInvokeInstance(this, getBindingContext());
         Object ret = am.findViewObjectWithParameters(voName, varMgr, toExecute);
         if (ret != null) 
         {
            cacheMethodResult(method, ret, paramVals);
         }
         return ret;
      }
      return super.invokeMethod(method, action, paramsMap);
   }

   final String VARIABLES_MAP = "variablesMap";
   final int VARIABLES_MAP_LENGTH = VARIABLES_MAP.length()+1;
   protected oracle.jbo.Variable findVariable(String path)
   {
      //only ViewObject variables are supported.
      int indx = path.indexOf(VARIABLES_MAP);
      if (indx > -1) 
      {
         String voname = path.substring(0, indx-1);
         String varname = path.substring(indx+VARIABLES_MAP_LENGTH);
         ViewObject vo = mAM.findViewObject(voname);
         if (vo != null) 
         {
            return vo.ensureVariableManager().lookupVariable(varname);
         }
      }
      return null;
   }


   /**
    * Reset any deferred exception in the row for the given attribute, for which
    * the AttrValException was raised. This method should be called after the 
    * attribute exception has been cached on the binding or handled by the user/view.
    */
   protected void resetAttributeExceptionInRow(DCIteratorBinding iter, Row row, AttributeDef def, AttrValException ave)
   {
      if (getBundledExceptionMode() == EXC_MODE_DEFERRED && row != null)
      {
         boolean txnModified = this.isTransactionModified();
         int index = def.getIndex();
         //reset the attribute value so that the deferred attribute exception
         //is removed.
         try
         {
            //suspend iterator event so that row's update event
            //is ignored (control bindings need to keep their
            //existing input values.
            iter.suspendRowSetEventsHandling(true);
            row.setAttribute(index, row.getAttribute(index));
         }
         finally
         {
            if (!txnModified)
            {
               //reset the txn state as it was unmodified to begin with.
               //restoring the attribute value to itself to get rid of 
               //exception should not modify the txn.
               transactionStateChanged(false);
            }
            iter.suspendRowSetEventsHandling(false);
         }
      }
   }


   class DCDomainRowSetIteratorImpl extends DCRowSetIteratorImpl
   {
      Class mJavaType;
      Row mOwner;

      DCDomainRowSetIteratorImpl(DCDataControl dc, Object data, String name, StructureDef def, Class javaType, Row owner)
      {
         super(dc, data, name, def);
         mJavaType = javaType;
         mOwner = owner;
         //set domain RSI to first row so that the rsi's fetched rowcount is always set to 1 or 0.
         //this makes sure buttons are create/remove enabled/disabled properly for domain rsis.
         first();
      }

      //only place where a row is created.
      protected Row internalCreateRowInstanceFor(Object rowData)
      {
         return new DomainRowImpl(rowData, this);
      }

      public Row createAndInitRow(AttributeList nvp)
      {
         Object rowObj = getDataControl().createRowData(new DCRowContext(this, getStructureDef(), nvp));
         if (rowObj != null)
         {
            return internalCreateRowInstanceFor(rowObj);
         }

         //this may throw exception but I'd leave it for later.
         throw new JboException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_CANNOT_CREATE_DOMAIN, null);
      }

      public Row getOwnerRow()
      {
         return mOwner;
      }


      final Class getDomainJavaType()
      {
         return mJavaType;
      }

   }

   class DomainRowImpl extends oracle.adf.model.generic.RowImpl
   {
      protected DomainRowImpl (Object rowDataProvider, DCRowSetIteratorImpl rowSetIterator)
      {
         super(rowDataProvider, rowSetIterator);
      }

      public Object getAttribute(int index)
      {
         return ((AttributeList)getDataProvider()).getAttribute(index);
      }

      public final Object getAttribute(String name)
      {
         return ((AttributeList)getDataProvider()).getAttribute(name);
      }

      public void setAttribute(int index, Object value)
      {
         ((AttributeList)getDataProvider()).setAttribute(index, value);
      }

      public void setAttribute(String name, Object value)
      {
         ((AttributeList)getDataProvider()).setAttribute(name, value);
      }
   }

}       
