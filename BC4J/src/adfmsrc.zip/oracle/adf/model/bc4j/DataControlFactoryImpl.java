package oracle.adf.model.bc4j;

import java.util.Map;
import java.util.HashMap;
import java.util.Properties;
import java.lang.reflect.Constructor;
import java.io.Serializable;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import oracle.adf.model.DataControl;
import oracle.adf.model.DataControlFactory;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.share.ADFContext;
import oracle.jbo.ApplicationModule;
import oracle.jbo.Session;
import oracle.jbo.JboContext;
import oracle.jbo.LocaleContext;
import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.NamedObjectImpl;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.ws.WSApplicationModuleImpl;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.binding.JUApplication;

import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.EnvInfoProvider;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookieFactory;
import oracle.jbo.common.ampool.AMPoolMessageBundle;
import oracle.jbo.common.ampool.ApplicationPoolException;

public class DataControlFactoryImpl implements DataControlFactory 
{
   final String CPX = "cpx";
   final String BATCH = "Batch";
   final String SYNC  = "Sync";
   
   public final static String VAL_MODE_REMOTE_STR  = "remoteOnly";
   public final static String VAL_MODE_ALWAYS_STR  = "always";
   public final static String VAL_MODE_NEVER_STR   = "never";

   final static String EXC_MODE_STRING = "ExceptionMode";
   final static String EXC_MODE_DEFERRED  = "Deferred";
   final static String EXC_MODE_IMMEDIATE = "Immediate";
   
   final static String PARAMETER_NAME = "name";
   final static String PARAMETER_VALUE = "value";

   private static int mSessionCounter = 0;
   private static Object mStaticSyncLock = new Object();


   public DataControlFactoryImpl()
   {
   }
   
   public DataControl createSession(BindingContext ctx, Node node, Map appParams)
   {
      
      String sName = null;
      
      if(node.getAttributes().getNamedItem(JUTags.NAME) != null)
        sName = node.getAttributes().getNamedItem(JUTags.NAME).getNodeValue();
      else
        sName = node.getAttributes().getNamedItem(JUTags.ID).getNodeValue();
        
      String configuration = node.getAttributes().getNamedItem(JUTags.Configuration).getNodeValue();
      String packageName = node.getAttributes().getNamedItem(JUTags.Package).getNodeValue();
      
      
      //this code to load the parameters list should be common to bc4j/bean DCs. However
      //for now keeping it separate just incase we diverge.
      NodeList list = null;
      Node contentNode = node.getFirstChild();
      if (contentNode != null)
      {
         list = contentNode.getChildNodes();
      }
      HashMap  parameters = new HashMap(10);
      
      parameters.put(JUTags.NAME, sName);
      parameters.put(JUTags.Configuration, configuration);
      parameters.put(JUTags.Package, packageName);
      
      Node childNode;
      if (list != null)
      {
         for(int i = 0; i < list.getLength(); i++)
         {
            childNode = list.item(i);
            if(childNode.getNodeName().equalsIgnoreCase(JUTags.Parameter))
            {
               String sParamName = childNode.getAttributes().getNamedItem(PARAMETER_NAME).getNodeValue();
               String sValue = childNode.getAttributes().getNamedItem(PARAMETER_VALUE).getNodeValue(); 
               parameters.put(sParamName, sValue);
            }
         }
      }
      return createSession(ctx, sName, appParams, parameters);
   }

   private SessionCookie findOrCreateSessionCookie(
      String dcName, BindingContext ctx, String poolName
      , String configPackage, String configSection, Properties poolProps
      , Properties cookieProps, boolean isBatch)
   {
      ADFContext adfCtx = ADFContext.getCurrent();

      SessionCookie cookie = null;

      // Tell our jndi implementation that
      // we are running insde an appserver
      if(poolProps == null)
      {
         poolProps = new Properties();
      }

      if (adfCtx.getContextType() != ADFContext.TYPE_GENERIC)
      {
         poolProps.put(JboContext.USE_DEFAULT_CONTEXT, "true");
      }

      // bug 4383350
      // For jclient running 3-tier set remote am pooling on dynamically at runtime
      // depending on whether SyncMode = Batch
      if (isBatch && (adfCtx.getContextType() == ADFContext.TYPE_GENERIC))
      {
         poolProps.put(PropertyConstants.ENV_JBO_EJB_USE_AMPOOL, "true");
      }

      ApplicationPool pool = PoolMgr.getInstance().findPool(
         poolName, configPackage, configSection, poolProps);

      try
      {
         cookie = pool.createSessionCookie(
            dcName, generateSessionId(dcName), cookieProps);
      }
      catch(ApplicationPoolException apex)
      {
         // Bug 2026193
         if (AMPoolMessageBundle.EXC_AMPOOL_COOKIE_ALREADY_EXISTS.
            equals(apex.getErrorCode()))
         {
            cookie = apex.getSessionCookie();
         }
         else
         {
            throw apex;
         }
      }

      Map adapter = adfCtx.getStateManager(ADFContext.SESSION_SCOPE, null);
      Object psState = adapter.get(dcName);

      if (psState != null && psState instanceof String)
      {
         cookie.setPassivationId(Integer.parseInt((String)psState));
      }
         
      return cookie;
   }
   
   public DataControl createSession(
      BindingContext ctx, String sName, Map appParams, Map parameters)
   {
      ADFContext adfCtx = ADFContext.getCurrent();

      String sPackage = (String)parameters.get(JUTags.Package);
      String sConfiguration = (String)parameters.get(JUTags.Configuration);
      String sAmName = (String)parameters.get(JUTags.NAME);
      
      EnvInfoProvider envInfo = (EnvInfoProvider)ctx.get(APP_PARAM_ENV_INFO);
      
      JUApplication app = null;

      Properties poolProps = null;
      Properties cookieProps = null;

      if (appParams != null)
      {
         poolProps = (Properties)appParams.get(APP_PARAM_POOL_PROPERTIES);
         cookieProps = (Properties)appParams.get(APP_PARAM_REQUEST_CONTEXT);
      }


      if (cookieProps == null)
      {
         if (adfCtx.getContextType() == ADFContext.TYPE_HTTP)
         {
            try
            {
               // JRS 08/12/05 dynamically instantiate this class.
               // otherwise the classloader attempts to locate the
               // class whenever DataControlFactoryImpl is loaded.  this
               // is bad if we are not a web application.
               cookieProps = (Properties)JBOClass.forName(
                  "oracle.jbo.http.HttpSessionCookieProperties")
                     .newInstance();
            }
            catch (Exception e)
            {
               throw new JboException(e);
            }

            cookieProps.put(
               SessionCookieFactory.PROP_IS_WEB_APP, new Boolean(true));
         }
         else
         {
            cookieProps = new Properties();
         }
      }

      // don't use the HttpContainer -- it will cache the container
      // in the session.  copied from HttpContainer.findSessionCookie
      SessionCookie sessionCookie = findOrCreateSessionCookie(
         sAmName
         , ctx
         , sPackage + "." + sConfiguration
         , sPackage
         , sConfiguration
         , poolProps
         , cookieProps
         , (BATCH.equals(parameters.get(JUTags.SYNC_MODE)) || BATCH.equals(parameters.get(SYNC))));


      if (envInfo != null && sessionCookie.getEnvInfoProvider() == null)
      {
         sessionCookie.setEnvInfoProvider(envInfo);
      }


      if (BATCH.equals(parameters.get(JUTags.SYNC_MODE)) || BATCH.equals(parameters.get(SYNC))) 
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("(oracle.adf.model.bc4j.DataControlFactoryImpl.SyncMode = Batch");
         }
         sessionCookie.setReferenceCounting(true);

         // JRS Why is this only preformed for batch?
         LocaleContext lctx = ctx.getLocaleContext();
         if (lctx == null)
         {
            lctx = new oracle.jbo.common.DefLocaleContext(null);
         }

         sessionCookie.setEnvironment(Session.JBO_SESSION_LOCALE, 
                                      lctx.getLocale());

         WSApplicationModuleImpl am =
            new WSApplicationModuleImpl(sessionCookie);
            

         app = instantiateDataControl(am, true);
      }
      else
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("(oracle.adf.model.bc4j.DataControlFactoryImpl.SyncMode = Immediate");
         }
         if (adfCtx.getContextType() == ADFContext.TYPE_GENERIC)
         {
            ApplicationModule am = sessionCookie.useApplicationModule();
            app = instantiateDataControl(am, true);
         }
         else
         {
            app = instantiateDataControl(sessionCookie, false);
         }
      }

      String param = (String)parameters.get(EXC_MODE_STRING);
      if ((adfCtx.getContextType() != ADFContext.TYPE_GENERIC)
         && param == null)
      {
         //by default webapps are set to deferred exception mode.
         app.setBundledExceptionMode(DCJboDataControl.EXC_MODE_DEFERRED);
      }
      else if (param != null)
      {
         if (EXC_MODE_DEFERRED.equals(param))
         {
            app.setBundledExceptionMode(DCJboDataControl.EXC_MODE_DEFERRED);
         }
         else if (EXC_MODE_IMMEDIATE.equals(param)) 
         {
            app.setBundledExceptionMode(DCJboDataControl.EXC_MODE_IMMEDIATE);
         }
      }

      param = (String)parameters.get(JUTags.VAL_MODE_STR);
      if (param == null || param.equals(VAL_MODE_ALWAYS_STR)) 
      {
         app.setValidationInBinding(DCJboDataControl.VAL_MODE_ALWAYS);
      }
      else if (param.equals(VAL_MODE_NEVER_STR))
      {
         app.setValidationInBinding(DCJboDataControl.VAL_MODE_NEVER);
      }
      else if (param.equals(VAL_MODE_REMOTE_STR))
      {
         app.setValidationInBinding(DCJboDataControl.VAL_MODE_REMOTE);
      }

      app.setName(sAmName);

      //need to setBindingContext before sessionCookie to avoid duplicate
      //bindingContext creation.
      app.setBindingContext(ctx);

      app.setSessionCookie(sessionCookie);
      


      if (envInfo != null)
      {
         //remove envinfo from binding context.
         ctx.put(APP_PARAM_ENV_INFO, null);
      }

      app.prepareSession();

      return app;
   }

   private String generateSessionId(String dcName)
   {
      int sessionCounter = 0;
      synchronized(mStaticSyncLock)
      {
         sessionCounter = mSessionCounter;
         mSessionCounter++;
      }

      return new StringBuffer(dcName)
         .append(':')
         .append(System.currentTimeMillis())
         .append(':')
         .append(sessionCounter)
         .toString();
   }

   private JUApplication instantiateDataControl(Object session, boolean isAM)
   {
      JUApplication app = null;
      try
      {
         Class dcClass = JBOClass.forName(getDataControlClassName());
         if (isAM)
         {
            Constructor cons = dcClass.getConstructor(new Class[]
               {ApplicationModule.class});
            if (cons != null)
            {
               app = (JUApplication)cons.newInstance(new Object[]
                  {(ApplicationModule)session});
            }
         }
         else
         {
            Constructor cons = dcClass.getConstructor(new Class[]
               {SessionCookie.class});

            if (cons != null)
            {
               app = (JUApplication)cons.newInstance(new Object[]
                  {(SessionCookie)session});
            }
         }
      }
      catch (Exception e)
      {
      }


      if (app == null)
      {
         System.out.println("**********Could not instantiate DataControl:  " + getDataControlClassName());
         if (isAM)
         {
            app = new JUApplication((ApplicationModule)session);

         }
         else
         {
            app = new JUApplication((SessionCookie)session);
         }
      }

      return app;
   }

   /**
    * A custom DataControlFactoryImpl should override this method to 
    * define a custom DataControl class.  All custom DataControl classes
    * should extend <tt>oracle.jbo.uicli.binding.JUApplication</tt>.
    */
   protected String getDataControlClassName()
   {
      return "oracle.jbo.uicli.binding.JUApplication";
   }
}
