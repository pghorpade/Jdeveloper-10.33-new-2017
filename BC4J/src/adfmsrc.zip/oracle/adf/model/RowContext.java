package oracle.adf.model;

import java.util.Map;

/**
 * Context passed into TransactionalDataControl apis when manipulating
 * a row.
 */
public interface RowContext extends oracle.binding.RowContext
{
   public Object getRowDataContainer();

   public String getMasterAccessorName();

   public int getCurrentRowIndex();

   public oracle.binding.OperationInfo getMasterOperationInfo();

}

