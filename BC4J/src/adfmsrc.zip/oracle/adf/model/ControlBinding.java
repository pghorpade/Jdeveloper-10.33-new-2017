package oracle.adf.model;

/**
 * Base interface for all bindings that allow binding a View component
 * to the data accessed via a datacontrol.
 */
public interface ControlBinding extends oracle.binding.ControlBinding
{
   public void release(int flags);
            
   /**
    * Add a listener that should be notified when the associated attribute value changes.
    */
   public void setListener(UpdateListener listener);
}
