package oracle.adf.model.servlet;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import oracle.jbo.SessionContext;

import oracle.adf.share.ADFContext;

class HttpSessionContextImpl implements SessionContext
{
   private HttpSession mHttpSession = null;

   public HttpSessionContextImpl()
   {
   }

   public HttpSessionContextImpl(HttpSession httpSession)
   {
      mHttpSession = httpSession;
   }

   public boolean equals(Object other) 
   {
      if(other == this)
      {
         return true;
      }
      if(other instanceof HttpSessionContextImpl)
      {
         return ((HttpSessionContextImpl)other).getHttpSession()
            .equals(getHttpSession());
      }
      return false;
   }

   public int getType()
   {
      return SessionContext.TYPE_HTTP_SESSION;
   }

   public int hashCode()
   {
      return getHttpSession().hashCode();
   }

   private HttpSession getHttpSession()
   {
      if (mHttpSession == null)
      {
         Object request = ADFContext.getCurrent().getEnvironment()
            .getRequest();

         if (request instanceof HttpServletRequest)
         {
            return ((HttpServletRequest)request).getSession(true);
         }
      }

      return mHttpSession;
   }
}

