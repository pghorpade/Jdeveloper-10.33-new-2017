package oracle.adf.model.servlet;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.model.DataControlFactory;

import oracle.adf.share.ADFContext;

/* $Header: ApplicationParameters.java 05-nov-2005.11:07:08 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051025 from 
                           main 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
    jsmiljan    08/11/05 - jsmiljan_bug-4367616
    jsmiljan    08/10/05 - Creation
 */

/**
 *  May be passed to {@link oracle.jbo.uicli.mom.JUMetaObjectManager#loadCpx(String, Map)}
 *  instead of a plain old HashMap.  The ApplicationParameters map
 *  supports the lazy retrieval of some http properties like
 *  {@link oracle.adf.model.DataControlFactory#APP_PARAM_HTTP_SESSION}.  The
 *  lazy instantiation of the session prevents session instantiation unless
 *  requested from the application.
 *  <p>
 *  This class is used by the ADFBindingFilter.
 *  <p>
 *  @version $Header: ApplicationParameters.java 05-nov-2005.11:07:08 rvangri Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class ApplicationParameters extends HashMap
{
   public ApplicationParameters()
   {
      new HashMap(4);
   }

   public Object get(Object key)
   {
      Object rtn = super.get(key);
      if (rtn == null && DataControlFactory.APP_PARAM_HTTP_SESSION.equals(key))
      {
         Object request = ADFContext.getCurrent().getEnvironment()
            .getRequest();

         if (request instanceof HttpServletRequest)
         {
            rtn = ((HttpServletRequest)request).getSession(true);
         }
      }

      return rtn;
   }
}
