package oracle.adf.model.servlet;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.SessionContextManagerImpl;

import oracle.adf.model.BindingContext;

import oracle.adf.share.ADFContext;

import java.io.Serializable;

public class HttpBindingContext extends BindingContext
   implements HttpSessionBindingListener
{
   private boolean mIsBindingListenerSuspended = false;
   
   public void valueBound(HttpSessionBindingEvent e)
   {
   }

   public void valueUnbound(HttpSessionBindingEvent e)
   {
      if (!mIsBindingListenerSuspended)
      {
         // 3450394 -- Must initialize the session context before release
         SessionContextManagerImpl.getInstance().setCurrentSession(
            new HttpSessionContextImpl(e.getSession()));
   
         release();
      }
   }

   /**
   * Return the ADF Model <code>BindingContext</code> given a ServletRequest
   *
   * @param request the current request
   */
   public static final BindingContext getContext(ServletRequest request)
   {
     return (BindingContext)ADFContext.getCurrent().getSessionScope()
        .get(CONTEXT_ID);
   }

   public void addPersistentState(String name, Serializable psState)
   {
      super.addPersistentState(name, psState);

      replicateStateChange();
   }

   public void removePersistentState(String name)
   {
      super.removePersistentState(name);

      replicateStateChange();
   }
   
   private void replicateStateChange()
   {
      try
      {
         mIsBindingListenerSuspended = true;
         
         // JRS tickle the session to force a state replication
         ADFContext.getCurrent().getSessionScope().put(CONTEXT_ID, this);
      }
      finally
      {
         mIsBindingListenerSuspended = false;
      }
   }
}
