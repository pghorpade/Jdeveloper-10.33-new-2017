package oracle.adf.model.servlet;

import java.io.IOException;

import java.lang.ref.WeakReference;

import java.util.logging.Level;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import oracle.adf.model.BindingRequestHandler;
import oracle.adf.share.perf.Timer;
import oracle.adf.share.perf.StateTracker;
import oracle.adf.share.perf.PerfUtil;

import oracle.jbo.common.ampool.ContextPoolManager;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboEnvUtil;

import oracle.adf.share.ADFContext;

/**
 * The ADFBindingFilter is used to pre-process any http requests to resources that may require access to the ADF runtime. 
 * It is responsible for:
 *
 *   - Initializing the Binding Context for a user's http session.
 *   - Serializing all incoming http requests within a session.
 *   - Notifying data control instances that a request is about to be served.
 *   - Notifying data control instances after the response has been served to the client.
 */
public class ADFBindingFilter implements Filter 
{
   public static final String INIT_PARAMETER_NAME = "CpxFileName";
   public static final String INIT_PARAMETER_ENCODING = "encoding";
   public static final String INIT_PARAMETER_UNAUTHORIZED_PAGE =
      "unauthorizedErrorPage";

   public static final String SESSION_INVALIDATE_BINDINGCONTAINER_DEF =
      BindingRequestHandler.SESSION_INVALIDATE_BINDINGCONTAINER_DEF;

   private FilterConfig mFilterConfig;
   
   // performance sensors
   private static String FILTER_SENSOR_GROUP = 
     "/oracle/adf/model/servlet/ADFBindingFilter";
   private static String FILTER_TIMER_NAME = "doFilter";
   private static String FILTER_URL_NAME = "url";
   
   private static Timer sFilterTimer = Timer.createTimer(
      Level.INFO, FILTER_SENSOR_GROUP, FILTER_TIMER_NAME, 
      "ADFBindingFilter doFilter timer");
   private static StateTracker sUrlState = StateTracker.createStateTracker(
      Level.INFO, FILTER_SENSOR_GROUP, FILTER_URL_NAME, 
      StateTracker.OBJECT, "", "ADFBindingFilter request URL");
   private boolean mIsDesignTime = false;
   
   // JRS 03/02/2004 Hold a weak reference to the current OC4J context.  This
   // is necessary to locate the application context PoolMgr in destroy below.
   // Decided to use a weak reference here so that we don't unintenionally
   // pin an OC4J application context.  The weak reference may go out of scope
   // if OC4J drops its strong reference before destory.  Oh well.  In this case
   // the ApplicationPool.finalize() should handle removing the
   // ApplicationModules.
   private WeakReference mOC4JContextRef = null;
   
   /**
    * initializes the servlet by retrieving the 'encoding' parameter and saving it's value for
    * subsequent use. The encoding is important for initalizing http request and response objects
    * to the correct encoding for support of NLS applications.
    * 
    * @param filterConfig
    * @throws javax.servlet.ServletException
    */
   public void init(FilterConfig filterConfig) throws ServletException
   {
      mFilterConfig = filterConfig;

      ServletContext servletContext = mFilterConfig.getServletContext();

      mOC4JContextRef = new WeakReference(
         BindingRequestHandler.loadApplication());

      // JRS 12/21/04 mIsDesignTime is used to disable some of the filter
      // behaviour when running in the JSP VE.  This should be removed once
      // a more general solution for handling filters has been implemented
      // by the JSP VE team.
      mIsDesignTime = "Design Time Engine Servlet Context".equals(
         servletContext.getServletContextName());
   }
   
   /**
    * Cleans up any applications-specific resources that where allocated.
    */
   public void destroy()
   {
      mFilterConfig = null;

      Object context = null;
      if ((context = mOC4JContextRef.get()) != null)
      {
         BindingRequestHandler.destroyApplication(context);
      }
      mOC4JContextRef = null;
   }


   /**
    *   The main filter function. This processes the http request and makes sure that the binding context
    *   is initialized for use by the controller and/or any web pages that use data binding.
    *   
    * @param request
    * @param response
    * @param chain
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doFilter(
      ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException
   {
      if (mIsDesignTime)
      {
         chain.doFilter(request, response);
         return;
      }
            
      // start the timer for the whole filter
      boolean isActive = sUrlState.isActive();
      if (isActive) 
      {
        sFilterTimer.start();
      }
      
      BindingRequestHandler requestHandler 
         = new HttpBindingRequestHandler(
            mFilterConfig.getServletContext()
            , (HttpServletRequest)request
            , (HttpServletResponse)response);

      requestHandler.setUnauthorizedPage(mFilterConfig.getInitParameter(
         INIT_PARAMETER_UNAUTHORIZED_PAGE));

      requestHandler.setTargetEncoding(
         mFilterConfig.getInitParameter(INIT_PARAMETER_ENCODING));

      requestHandler.setBindingContextDefName(
         mFilterConfig.getServletContext()
            .getInitParameter(INIT_PARAMETER_NAME));

      try
      {
         requestHandler.beginRequest();
         chain.doFilter(request, response);
      }
      finally
      {
         requestHandler.endRequest();
      }
                       
      if (isActive)
      {
        sUrlState.update(PerfUtil.getUrl((HttpServletRequest)request));
        sFilterTimer.stop();// stop the filter timer
      }
   }
}
