package oracle.adf.model.servlet;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.servlet.ServletContext;

import oracle.adf.model.servlet.HttpSessionContextImpl;

import oracle.adf.model.BindingContext;
import oracle.adf.model.BindingRequestHandler;

import oracle.adf.share.ADFContext;

import oracle.adf.share.http.ServletADFContext;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;

import oracle.jbo.JboException;
import oracle.jbo.SessionContext;

import oracle.jbo.http.HttpSessionCookieProperties;

public class HttpBindingRequestHandler extends BindingRequestHandler
{

   private final ServletContext mServletContext;
   private final HttpServletRequest mRequest;
   private final HttpServletResponse mResponse;


   public HttpBindingRequestHandler(
      ServletContext servletContext
      , HttpServletRequest request
      , HttpServletResponse response)
   {

      mServletContext = servletContext;
      mRequest = request;
      mResponse = response;
   }



   protected BindingContext createBindingContext(ADFContext adfContext)
   {
      return new HttpBindingContext();
   }

   protected SessionContext createSessionContext(ADFContext adfContext)
   {
      return new HttpSessionContextImpl();
   }

   protected ADFContext initADFContext()
   {
      ServletADFContext.initThreadContext(
         mServletContext, mRequest, mResponse);


      return ADFContext.getCurrent();
   }

   protected void resetADFContext()
   {
      ServletADFContext.resetThreadContext();
   }

   protected void handleAuthenticationFailure(ADFContext adfContext)
   {
      try
      {
         mResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
      }
      catch (IOException e)
      {
         throw new JboException(e);
      }
   }

   protected Properties initializeContextForDataControl(
      ADFContext adfContext, Properties context)
   {
      return new HttpSessionCookieProperties(
         super.initializeContextForDataControl(adfContext, context));
   }

   protected HashMap initializeContextForBeginRequest(
      ADFContext adfContext, HashMap context)
   {
      return initializeBeginEndRequestContext(adfContext
         , super.initializeContextForBeginRequest(adfContext, context));
   }

   protected HashMap initializeContextForEndRequest(
      ADFContext adfContext, HashMap context)
   {
      return initializeBeginEndRequestContext(adfContext
         , super.initializeContextForEndRequest(adfContext, context));
   }

   private HashMap initializeBeginEndRequestContext(ADFContext adfContext
      , HashMap context)
   {
      return new HashMap(context)
      {
         public Object get(Object key)
         {
            if (BindingContext.HTTP_REQUEST.equals(key))
            {
               return ADFContext.getCurrent().getEnvironment().getRequest();
            }
            else if (BindingContext.HTTP_RESPONSE.equals(key))
            {
               return ADFContext.getCurrent().getEnvironment().getResponse();
            }
            else
            {
               return super.get(key);
            }
         }
      };
   }
}
