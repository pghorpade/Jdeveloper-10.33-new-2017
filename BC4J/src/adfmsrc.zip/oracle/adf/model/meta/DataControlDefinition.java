package oracle.adf.model.meta;

/**
 * Oracle extension to the JSR227 meta interface. 
 * This interface defines yet-to-be-standard property types for
 * DataControlDefinition.
 * It should be removed from this package once the constants is
 * introduced to oracle.binding.meta.DataControlDefinition. 
 */
public interface DataControlDefinition extends oracle.binding.meta.DataControlDefinition
{
   /* Predefined keys for features that a datacontrol may support.
    * Caller can call getProperty passing one of these constants
    * as key to query whether the data control support the feature.
    */
   public final String SUPPORTS_FIND_MODE       = "_SupportsFindMode";
   public final String SUPPORTS_RANGE_SIZE      = "_SupportsRangeSize";
   public final String SUPPORTS_RESET_STATE     = "_SupportsResetState";
   public final String SUPPORTS_SEARCHING       = "_SupportsSearching";
   public final String SUPPORTS_SORT_COLLECTION = "_SupportsSortCollection";
   public final String SUPPORTS_TRANSACTION     = "_SupportsTransaction";
   public final String SUPPORTS_UPDATES         = "_SupportsuPDATES";
}
