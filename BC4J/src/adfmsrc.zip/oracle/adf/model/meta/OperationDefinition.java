package oracle.adf.model.meta;

/**
 * Oracle extension to the JSR227 meta interface. 
 * This interface defines yet-to-be-standard opcodes and 
 * names for standard operations.
 * It should be removed from this package once the constants is
 * introduced to oracle.binding.meta.OperationDefinition. 
 */
public interface OperationDefinition extends oracle.binding.meta.OperationDefinition
{
   // action Id for standard operations
   public static final int ACTION_EXECUTE = 0;
   public static final int ACTION_FIND    = 1;
   //BindingContainer actions
   public static final int ACTION_BINDING_CONTAINER_EXECUTE = ACTION_EXECUTE;
   public static final int ACTION_BINDING_CONTAINER_FIND    = ACTION_FIND;

   //IteratorBinding actions
   public static final int ACTION_ITERATOR_BINDING_EXECUTE= 2;
   public static final int ACTION_ITERATOR_BINDING_FIND   = 3;

   public static final int ACTION_NEXT = 10;
   public static final int ACTION_PREVIOUS = 11;
   public static final int ACTION_FIRST = 12;
   public static final int ACTION_LAST = 13;
   public static final int ACTION_NEXT_SET = 14;
   public static final int ACTION_PREVIOUS_SET = 15;

   public static final int ACTION_RESET = 20;
   public static final int ACTION_REMOVE_CURRENT_ROW = 30;
   public static final int ACTION_CREATE_INSERT_ROW = 40;
   public static final int ACTION_CREATE_ROW = 41;

   /**
    * Internal. Applications should not use these ids. (50-99)
    */
   public static final int ACTION_CUSTOM_EXECUTES_START = 50;
   public static final int ACTION_EXECUTE_WITH_PARAMS  = 95;
   public static final int ACTION_SETCURRENTROW_WITH_KEY      = 96;
   public static final int ACTION_SETCURRENTROW_WITH_KEYVALUE = 98;
   public static final int ACTION_REMOVEROW_WITH_KEY   = 99;

   //DataControl actions
   public static final int ACTION_COMMIT_TRANSACTION = 100;
   public static final int ACTION_ROLLBACK_TRANSACTION = 101;
   public static final int ACTION_RESET_STATE = 102;
   public static final int ACTION_INVOKE_METHOD = CUSTOM;   
}
