package oracle.adf.model;

/**
 * This Listener is invoked when a nested Region is being
 * processed by it's containee. This allows lifecycle implementations to 
 * be notified of events when a region is being refreshed or validated
 * so that they can take over calling of nested region's refresh of validate
 * operations. ADF bindingContainer implementation will make sure that the
 * RegionController registered with the bindingContainer is invoked at the
 * end of all RegionListeners registered with it for both refresh and 
 * validate operations.
 */
public interface RegionListener 
{
   /**
    * Notified when a contained region's refresh() method should be called.
    * Return true if region's refresh logic needs to proceed with invoking 
    * refresh() on the region binding. 
    */
   boolean refreshRegion(RegionContext regionCtx);

   /**
    * Notified when a contained region's validate() method should be called.
    * Return true if region's validate logic needs to proceed with invoking 
    * validate() on the region binding. 
    */
   boolean validateRegion(RegionContext regionCtx);

   /**
    * Notified when a contained region's isVisible check is done. 
    */
   boolean isRegionViewable(RegionContext regionCtx);

   /**
    * Identifier used to display in exceptions or logs when this listener
    * is being processed.
    */
   String getName();
}
