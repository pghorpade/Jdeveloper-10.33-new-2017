package oracle.adf.model;
import java.util.List;
import java.util.Map;

/**
 */
public interface OperationBinding extends ControlBinding, oracle.binding.OperationBinding
{
   /**
    * Whether the action binding is enabled or disabled.
    * @return True if the action is currently enabled. False otherwise.
    */
   public boolean isOperationEnabled();

   /**
    * Invokes this OperationBinding, for example, as a result of a UI button being pressed.
    * This should translate into invoking some operation on the underlying data control.
    * If there are exceptions within the invoke operation, these exceptions should be
    * accessible via getErrors().
    */
   public void invoke();

   /**
    * Returns a list of errors that were raised during the last invoke operation
    * call.
    *
    * @return A list of Throwable that were raised during setInputValue(). It
    *         returns null if there is no error occurred.
    *
    * @see #invoke()
    */
   public List getErrors();

   /**
    * Retuns a map of name-value pairs of arguments and argument values to be passed
    * to the bound operation.
    */
   Map getParamsMap();


   public Object getResult();
}
