package oracle.adf.model;

import java.util.List;
/**
 * A map that provides a name-space to locate binding objects
 * through which data is accessed on a view region.
 */
public interface RegionBinding extends oracle.binding.BindingContainer
{
    int TYPE_EXECUTABLE_REGION = 0;
    /**
     * Return a list of all nested RegionBindings contained by this RegionBinding.
     */
    List getRegionBindings();


    /**
     * Returns one of an enumeration of Executable binding types 
     * in the framework. 
     * <p>
     * int value of 0 is reserved for RegionBinding or BindingContainer
     * type.
     */
    int getExecutableType();


    /**
     * Returns an instance of RegionController that should
     * handle the lifecycle for this RegionBinding.
     * <p>
     * By default this will return null. For Regions that have
     * an overridden RegionController defined in the Region definition
     * this will return an instance of the RegionController implementation.
     * <p>
     * This RegionBinding controller is invoked when this RegionBinding needs to
     * refresh or validate it's contained RegionBindings.
     */
    RegionController getRegionController();

    /**
     * Returns an instance of java bean that may implement
     * event-handling for actions defined on this RegionBinding.
     * <p>
     * A controller should delegate to this event processor
     * for handling action events for those actions that
     * have a corresponding method. Otherwise controller
     * should invoke the ActionBinding directly.
     */
    Object getActionProcessor();


    public final static int REFRESH_UNKNOWN = -1; 
    public final static int EXECUTE_MODEL   = 0; 
    public final static int PREPARE_MODEL   = 1; 
    public final static int RENDER_MODEL    = 2; 
    /**
     * Refresh data for this regionBinding based on the given flag.
     */
    void refresh(int flag);

    /**
     * Consults security to return whether this region binding should
     * be visible in the current context or not. It is expected that
     * view technologies will consult this flag before processing
     * region's model. 
     */
    boolean isViewable();
}
