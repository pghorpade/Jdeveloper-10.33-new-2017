/*
 * @(#)UIMessageBundle.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model;

import oracle.jbo.common.StringManager;
import oracle.jbo.common.CheckedListResourceBundle;
import oracle.jbo.common.Diagnostic;

public class ADFmMessageBundle
   extends CheckedListResourceBundle
{
   //
   // Ranges:
   //   STR_ 02500 - 02699
   //   MSG_ 12500 - 12699
   //   EXC_ 34000 - 34999
   //

   static
   {
      Diagnostic.println("UIMessageBundle (language base) being initialized");
   }

   public static final String STR_DEF_APPLICATION               = "03000";
   
   /**
   ** <b>JBO-35000: JboException</b>
   ** <p>
   ** <b>Cause:</b>: Cannot find the named property in a resolved
   ** object from a spel-expression.
   ** <p>
   ** <b>Action:</b>: Provide the right name in the spel-expression
   */
   public static final String EXC_SPEL_ATTRIBUTE_NOT_RESOLVED = "35000";


   /**
   ** <b>JBO-35001: JboException</b>
   ** <p>
   ** <b>Cause:</b>: A binding is being reused in another view component.
   ** <p>
   ** <b>Action:</b>: Create another binding definition for the second
   ** component and bind that to the component.
   */
   public static final String EXC_CONTROLBINDING_NOT_REUSABLE = "35001";

   /**
   ** <b>JBO-35001: JboException</b>
   ** <p>
   ** <b>Cause:</b>: A mismatch occured between the argument count and
   ** the number of parameters set into this method action binding to
   ** call the bound method.
   ** <p>
   ** <b>Action:</b>: Provide the required set of parameters, one for
   ** each argument in the bound method.
   */
   public static final String EXC_ARG_PARAM_COUNT_MISMATCH = "35002";



   /**
   ** <b>JBO-35003: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: FindMode called on an iterator binding which 
   ** is associated with a datacontrol that does not support find mode.
   ** 
   ** <p>
   ** <b>Action:</b>: Do not set the containing BindingContainer or
   ** this iterator binding in find mode.
   */
   public static final String EXC_FIND_MODE_NOT_IMPLEMENTED = "35003";

   /**
   ** <b>JBO-35003: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: FindMode called on an iterator binding which 
   ** is associated with a datacontrol that does not support find mode.
   ** 
   ** <p>
   ** <b>Action:</b>: Do not set the containing BindingContainer or
   ** this iterator binding in find mode.
   */
   public static final String EXC_CANNOT_CREATE_DOMAIN = "35004";


   /**
   ** <b>JBO-35005: ValidationException</b>
   ** <p>
   ** <b>Cause:</b>: One of the RegionListeners returned false from
   ** regionValidate() during BindingContainer.validate() 
   ** <p>
   ** <b>Action:</b>: 
   ** Fix the cause for the RegionListener's failure.
   */
   public static final String EXC_REGION_LISTENER_VALIDATE = "35005";


   /**
   ** <b>JBO-35006: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: Too many rows found to delete in IteratorBinding.removeRowByKey.
   ** <p>
   ** <b>Action:</b>: Provide a key to this method such that only one row is found
   ** for removal.
   */
   public static final String EXC_TOO_MANY_ROWS_FOR_REMOVE = "35006";


   /**
   ** <b>JBO-35007: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: Currency for an Iterator Binging, in the restored state for this BindingContainer, does not match the currency in the token preserved on the page.
   ** <p>
   ** <b>Action:</b>: Either do not process state-token for this request if currency is not required to 
   ** be at the same state where the previous request left the server as, or fix the cause of the request
   ** that may be due to mutliple requests for the same action while one is being processed.
   */
   public static final String EXC_UNEXPECTED_CURRENT_ROW   = "35007";

   /**
   ** <b>JBO-35008: InvalidParamException</b>
   ** <p>
   ** <b>Cause:</b>: A row is being created for Null bean or map.
   ** <p>
   ** <b>Action:</b>: Fix the bean/map accessor so that a non-null bean or map
   ** is used to create a Row. A row with null bean/map will lead to a number
   ** of NullPointerExceptions down the chain in an ADF Application.
   */
   public static final String EXC_NULL_BEAN_FOR_ROW = "35008";

   /**
   ** <b>JBO-27008: ReadOnlyAttrException</b> 
   ** <p>
   ** <b>Cause:</b> Attempting to modify a Row attribute that is readonly
   ** <p>
   ** <b>Action:</b> Either change the Updateable flag for the Attribute or
   ** do not attempt to update readonly attributes.
   ** 
   */
   public static final String EXC_VAL_ATTR_SET_FAILED        = "35009";

  //////////////////////////////////////////////////////////////
  // Data Control Adapter exceptions
  /////////////////////////////////////////////////////////////

  /**
  ** <b>JBO-35100: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Un-Expected exception.
  ** <p>
  */
  public static final String EXC_UNEXPECTED = "35100";

  // Adapter Definition Exceptions 

  /**
  ** <b>JBO-35101: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: No "ClassName" attribute is defined for adapter.
  ** <p>
  ** <b>Action:</b>: Provide the "ClassName" attribute in adapter-definition.xml.
  */
  public static final String EXC_ADAPTER_CLASS_NOT_DEFINED = "35101";

  /**
  ** <b>JBO-35102: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Failed to load adapter class.
  ** <p>
  ** <b>Action:</b>: Check the class name and the class path.
  */
  public static final String EXC_ADAPTER_CLASS_LOAD_FAILED = "35102";

  /**
  ** <b>JBO-35103: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Exception throws from the adapter.
  ** <p>
  ** <b>Action:</b>: Check the detail message or the log file.
  */
  public static final String EXC_ADAPTER_EXCEPTION = "35103";

  /**
  ** <b>JBO-35104: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Failed to load adapter definition file.
  ** <p>
  ** <b>Action:</b>: The file name should be META-INF/adapter-definition.xml.
  */
  public static final String EXC_ADAPTER_DEF_LOAD_FAILED = "35104";

  /**
  ** <b>JBO-35105: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Failed to parse the adapter definition file.
  ** <p>
  ** <b>Action:</b>: Check the content of the file. Check for the XML syntax.
  */
  public static final String EXC_ADAPTER_DEF_SYNTAX = "35105";

  /**
  ** <b>JBO-35106: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Adapter is not defined for the type used.
  ** <p>
  ** <b>Action:</b>: Check the content of the adapter definition file.
  */
  public static final String EXC_ADAPTER_NOT_DEFINED_FOR_TYPE = "35106";

  /**
  ** <b>JBO-35107: AdapterException</b>
  ** <p>
  ** <b>Cause:</b>: Data Control class does not implement the required interfaces.
  ** <p>
  ** <b>Action:</b>: The data control class must implement the JSR 227 
  **                 interfaces. See the document.
  */
  public static final String EXC_DATACONTROL_BAD_IMPL = "35107";

  /**
   ** <b>JBO-35108: InvalidOperException</b>
   ** <p>
   ** <b>Cause:</b>: User do not have permission for the operation
   ** <p>
   ** <b>Action:</b>: Permission must be granted to user for the operation
  */
  public static final String EXC_ACTION_NO_PERMISSION = "35108";

  // key for standard action names
  public static final String ACTION_COMMIT         = "Commit";
  public static final String ACTION_ROLLBACK       = "Rollback";
  public static final String ACTION_CREATE         = "Create";
  public static final String ACTION_CREATE_INSERT  = "CreateInsert";
  public static final String ACTION_FIND           = "Find";
  public static final String ACTION_EXECUTE        = "Execute";
  public static final String ACTION_FIRST          = "First";
  public static final String ACTION_PREVIOUS       = "Previous";
  public static final String ACTION_PREVIOUS_SET   = "PreviousSet";
  public static final String ACTION_NEXT           = "Next";
  public static final String ACTION_NEXT_SET       = "NextSet";
  public static final String ACTION_LAST           = "Last";
  public static final String ACTION_DELETE         = "Delete";
  public static final String ACTION_RESET_STATE    = "ResetState";
  public static final String ACTION_REMOVEROW_WITH_KEY            = "removeRowWithKey";
  public static final String ACTION_SETCURRENTROW_WITH_KEY        = "setCurrentRowWithKey";
  public static final String ACTION_SETCURRENTROW_WITH_KEYVALUE   = "setCurrentRowWithKeyValue"; 
  public static final String ACTION_EXECUTE_WITH_PARAMS           = "ExecuteWithParams";
  public static final String ACTION_ITERATOR_BINDING_EXECUTE      = "IteratorExecute";
   
   /**
    * Gets the key-value association table.
    *
    * @return an array of key-value pairs.
    **/
   public Object[][] getContents()
   {
      return sMessageStrings;
   }


   /**
    * Private 2-D array of key-value pairs
    **/
   private static final Object[][] sMessageStrings =
   {
      { STR_DEF_APPLICATION            , "Application Definition" },
      
      { EXC_SPEL_ATTRIBUTE_NOT_RESOLVED, "Cannot resolve spel expression for attribute {0} in {1}" },
      { EXC_CONTROLBINDING_NOT_REUSABLE, "Binding cannot be reused with a different View or Control." },
      { EXC_ARG_PARAM_COUNT_MISMATCH,    "Size mismatch between argument types and parameters"},
      { EXC_FIND_MODE_NOT_IMPLEMENTED,   "Find mode not supported by DataControl associated with iterator binding:{0}."},
      { EXC_CANNOT_CREATE_DOMAIN,   "Domain instance cannot be created. Parent row invalid or may not exist."},
      { EXC_REGION_LISTENER_VALIDATE, "Region Listener:{0} failed to validate at index:{1} in BindingContainer:{2}"},
      { EXC_TOO_MANY_ROWS_FOR_REMOVE, "More than one row found with key:{0} in iterator binding:{1} for remove."},
      { EXC_UNEXPECTED_CURRENT_ROW, "Row currency has changed since the user interface was rendered. The expected row key was {0}"},
      { EXC_NULL_BEAN_FOR_ROW, "An attempt is being made to create a Row with a null bean or map of type {0}"},
      { EXC_VAL_ATTR_SET_FAILED, "Attribute set for {2} in object: {1} failed"},
      
    
      // Adapters
      { EXC_UNEXPECTED,   "Un-expected Exception."},
      { EXC_ADAPTER_CLASS_NOT_DEFINED, "The attribute \"ClassName\" is not defined for the adapter type: {0}."},
      { EXC_ADAPTER_CLASS_LOAD_FAILED, "Failed to load the adapter class: {0}."},
      { EXC_ADAPTER_EXCEPTION, "Adapter Exception: "},
      { EXC_ADAPTER_DEF_LOAD_FAILED, "Failed to load adapter definition file."},
      { EXC_ADAPTER_DEF_SYNTAX, "Adapter definition file has bad XML structure."},
      { EXC_ADAPTER_NOT_DEFINED_FOR_TYPE, "Adapter is not defined for the type: {0}."},
      { EXC_DATACONTROL_BAD_IMPL, "Data control implementation does not implement the required interfaces."},

      { EXC_ACTION_NO_PERMISSION, "No permission for action: {0}."},

      { ACTION_COMMIT, "Commit" },
      { ACTION_ROLLBACK, "Rollback" },
      { ACTION_CREATE, "Create" },
      { ACTION_CREATE_INSERT, "CreateInsert" },
      { ACTION_FIND, "Find" },
      { ACTION_EXECUTE, "Execute" },
      { ACTION_FIRST, "First" },
      { ACTION_PREVIOUS, "Previous" },
      { ACTION_PREVIOUS_SET, "Previous Set" },
      { ACTION_NEXT, "Next" },
      { ACTION_NEXT_SET, "Next Set" },
      { ACTION_LAST, "Last" },
      { ACTION_DELETE, "Delete" },
      { ACTION_REMOVEROW_WITH_KEY, ACTION_REMOVEROW_WITH_KEY },
      { ACTION_SETCURRENTROW_WITH_KEY, ACTION_SETCURRENTROW_WITH_KEY },
      { ACTION_SETCURRENTROW_WITH_KEYVALUE, ACTION_SETCURRENTROW_WITH_KEYVALUE },
      { ACTION_EXECUTE_WITH_PARAMS, ACTION_EXECUTE_WITH_PARAMS},
      { ACTION_ITERATOR_BINDING_EXECUTE, "Execute"},
   }  ;

   final public static String MSG_BUNDLE = "oracle.adf.model.ADFmMessageBundle"; 
   final public static String getResString(String id)
   {
      return StringManager.getString(MSG_BUNDLE, id, "", null); 
   }

}
