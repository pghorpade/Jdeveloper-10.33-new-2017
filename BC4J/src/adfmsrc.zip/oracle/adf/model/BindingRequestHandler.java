package oracle.adf.model;

import java.io.IOException;

import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;

import java.security.Principal;

import oracle.adf.model.binding.DCDataControlManagement;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFactory;
import oracle.adf.model.RegionBinding;

import oracle.adf.model.servlet.ApplicationParameters;

import oracle.adf.share.ADFContext;
import oracle.adf.share.ADFScope;
import oracle.adf.share.Environment;

import oracle.jbo.JboException;
import oracle.jbo.SessionContext;

import oracle.jbo.uicli.mom.JUMetaObjectManager;

import oracle.jbo.http.ORDRegisterer;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.DefLocaleContext;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.Lock;
import oracle.jbo.common.SessionContextManagerImpl;

import oracle.jbo.common.ampool.SessionCookieFactory;
import oracle.jbo.common.ampool.ContextPoolManager;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.JboEnvUtil;

import oracle.jbo.pool.ResourcePoolManager;

import oracle.jbo.server.ConnectionPoolManagerFactory;

public abstract class BindingRequestHandler
{   
   private static String AUTH_SUCCESS_URL = "success_url";
   private static String AUTH_SERVLET_NAME = "adfAuthentication"; 

   public static final String SESSION_INVALIDATE_BINDINGCONTAINER_DEF =
      "adf_session_invalidate_bindingcontainer_def";

   private static String REQUEST_BINDINGS_INITIALIZED =
      "_request_bindings_initialized_";

   private static String SESSION_LOCK = "_session_lock_";

   private String mBindingContextDefName = null;
   private String mTargetEncoding = null;
   private String mUnauthorizedPage = null;


   private BindingContext mBindingContext = null;
   private boolean mWasRequestBindingsInitialized = true;

   private Lock mSessionLock = null;

   public void setBindingContextDefName(String bindingContextDefName)
   {
      mBindingContextDefName = bindingContextDefName;
   }

   public void setTargetEncoding(String targetEncoding)
   {
      mTargetEncoding = targetEncoding;
   }

   public void setUnauthorizedPage(String unauthorizedPage)
   {
      mUnauthorizedPage = unauthorizedPage;
   }

   public boolean beginRequest()
   {
      ADFContext adfContext = initADFContext();

      // Need to set the sessionContext every time for the current thread.
      // -dm 4/11/2003
      // Come discuss with me if you have any questions.
      SessionContextManagerImpl.getInstance().setCurrentSession(
         createSessionContext(adfContext));

      Map sessionScope = adfContext.getSessionScope();
      Map requestScope = adfContext.getRequestScope();
      Environment adfEnv = adfContext.getEnvironment();

      synchronized(getClass())
      {
         mSessionLock = (Lock)sessionScope.get(SESSION_LOCK);
         if (mSessionLock == null)
         {
            mSessionLock = new Lock();
            sessionScope.put(SESSION_LOCK, mSessionLock);
         }
      }

      // if two threads for the same session entire concurrently then one
      // must wait.
      // use a different locking context then the session itself, not sure
      // where else the container may be synchronizing on the session.
      mSessionLock.lock(-1);

      if (mTargetEncoding != null)
      {
         try
         {
            adfEnv.setRequestCharacterEncoding(mTargetEncoding);
         }
         catch (IOException e)
         {
            throw new JboException(e);
         }
      }

      mBindingContext = (BindingContext)sessionScope.get(
         BindingContext.CONTEXT_ID);

      if (mBindingContext == null
         || mBindingContext.get(BindingContext.IS_INITIALIZED) == null)
      {
         initializeBindingContext(adfContext);
      }

      try
      {
         ORDRegisterer.registerRenderer(sessionScope);
      }
      catch (NoClassDefFoundError noClass)
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("**** FAILED To register ORDRegister"); //nonls
         }
      }


      adfContext.getADFConfig();

      //do this only once as in controller scenario we come in more than
      // once, for .do, for .jsp...
      if (requestScope.get(REQUEST_BINDINGS_INITIALIZED) == null)
      {
         mWasRequestBindingsInitialized = false;

         // set a request variable that indicates we've initialized the
         // bindingcontext and reset the inputstates on all
         // bindingcontainers thus far initialzied.
         requestScope.put(
            REQUEST_BINDINGS_INITIALIZED, REQUEST_BINDINGS_INITIALIZED);
      }

      if (!mWasRequestBindingsInitialized)
      {
         invokeBeginRequest(adfContext);
      }

      if (!isPageViewable())
      {
         if (!adfContext.getSecurityContext().isAuthenticated())
         {
            sessionScope.put(AUTH_SUCCESS_URL, adfEnv.getRequestURI());

            String url = adfEnv.encodeResourceURL(
               adfEnv.getRequestContextPath() + "/" + AUTH_SERVLET_NAME);   

            try
            {
               adfEnv.redirect(url);
            }
            catch (IOException e)
            {
               throw new JboException(e);
            }
         }


         if (mUnauthorizedPage != null && mUnauthorizedPage.length() > 0)
         {
            try
            {
               adfEnv.redirect(mUnauthorizedPage);
            }
            catch (IOException e)
            {
               throw new JboException(e);
            }
         }
         else
         {
            // give the handler provider an opportunity to handle the
            // failure in a handler specific way.
            handleAuthenticationFailure(adfContext);
         }
         return false;
      }

      return true;
  }

   public void endRequest()
   {
      try
      {
         ADFContext adfContext = ADFContext.getCurrent();

         if (!mWasRequestBindingsInitialized)
         {
            invokeEndRequest(adfContext);

         }
      }
      finally
      {
         mSessionLock.unlock();

         resetADFContext();
      }
   }

   /**
    * Return true if there no RegionBinding associated with this
    * page or if the page is viewable based on the RegionBinding info.
    * <p>
    * The session parameter has been deprecated and will no longer be passed.
    * Maintaining this method for backwards compatiblity.  Applications that
    * require the HttpSession should use:
    * <code>servletRequest.getSession(boolean)</code>
    * <p>
    */
   private boolean isPageViewable()
   {
      // No BindingContext means no way to check is the page require authorization
      if (mBindingContext == null)
      {
         return true;
      }
      
      Environment adfEnv = ADFContext.getCurrent().getEnvironment();
      
      // First retrieve the current path
      String path = adfEnv.getRequestPathInfo();
      if (path == null || path.length() == 0)
      {
         path = adfEnv.getRequestServletPath();
      }
      
      if (path == null || path.length() == 0)
      {
         return true;
      }
      
      // Use the path info to retrieve the RegionBinding
      RegionBinding bindings = mBindingContext.findBindingContainerByPath(path);

      // No RegionBinding means no way to check if the page is viewable.
      if (bindings == null)
      {
         return true;
      }
      
      Map sessionScope = ADFContext.getCurrent().getSessionScope();

      // Invalidate BindingContainer Def after logon
      Object val = sessionScope.get(SESSION_INVALIDATE_BINDINGCONTAINER_DEF);
      if (val != null)
      {
         JUMetaObjectManager.getJUMom().invalidateBindingContainerDef(
            mBindingContext,
            ((DCBindingContainer)bindings).getDef().getFullName());
         sessionScope.remove(SESSION_INVALIDATE_BINDINGCONTAINER_DEF);
      }

      return bindings.isViewable();
   }

   private void initializeBindingContext(ADFContext adfContext)
   {
      Environment adfEnv = adfContext.getEnvironment();
      Map sessionScope = adfContext.getSessionScope();

         
      //this is where we need to figure out if this session already has a
      //binding context
      mBindingContext = (BindingContext)sessionScope.get(
         BindingContext.CONTEXT_ID);

      if (mBindingContext == null)
      {
         mBindingContext = createBindingContext(adfContext);
      }

      SessionContext sessionContext =
         SessionContextManagerImpl.getInstance().getCurrentSession();

      if (sessionContext != null)
      {
         mBindingContext.setSessionContext(sessionContext);
      }

      HashMap map = new ApplicationParameters();

      mBindingContext.setErrorHandler(
         new oracle.adf.model.binding.DCErrorHandlerImpl(true));

      map.put(DataControlFactory.APP_PARAMS_BINDING_CONTEXT, mBindingContext);

      //Put the request in cookie properties. HttpSessionCookieFactory
      //retrieves request from cookie properties. If user principal is not
      //null, i.e., authenticated, it will get set in to SessionCookie
      //environment.
      Properties dataControlContext = initializeContextForDataControl(
         adfContext, new Properties());

      map.put(
         DataControlFactory.APP_PARAM_REQUEST_CONTEXT, dataControlContext);

      // this needs to be done on every request
      mBindingContext.setLocaleContext(
         new DefLocaleContext(adfEnv.getRequestLocale()));

      JUMetaObjectManager.loadCpx(mBindingContextDefName +".cpx", map);

      mBindingContext.put(
         BindingContext.IS_INITIALIZED, PropertyConstants.TRUE);

      sessionScope.put(BindingContext.CONTEXT_ID, mBindingContext);
   }

   private void invokeBeginRequest(ADFContext adfContext)
   {
      HashMap requestCtx = initializeContextForBeginRequest(
         adfContext, new HashMap(2));

      mBindingContext.beginRequest(adfContext, requestCtx);
   }

   private void invokeEndRequest(ADFContext adfContext)
   {
      HashMap requestCtx = initializeContextForEndRequest(
         adfContext, new HashMap(2));

      mBindingContext.endRequest(adfContext, requestCtx);
   }

   /**
    * This operation is exposed for legacy applications. The context is
    * available when invoking DataControl.beginRequest(HashMap).  New
    * applications and the ADF frameworks should not depend upon this
    * context and should use the ADFContext instead.
    */
   protected HashMap initializeContextForBeginRequest(
      ADFContext adfContext, HashMap context)
   {
      return context;
   }

   /**
    * This operation is exposed for legacy applications. The context is
    * available when invoking DataControl.endRequest(HashMap).  New
    * applications and the ADF frameworks should not depend upon this
    * context and should use the ADFContext instead.
    */
   protected HashMap initializeContextForEndRequest(
      ADFContext adfContext, HashMap context)
   {
      return context;
   }

   /**
    * This operation is exposed for legacy applications. The context is
    * available to the DataControl during DataControl creation as the
    * appParam, DataControlFactory.APP_PARAM_REQUEST_CONTEXT.
    * New applications and the ADF frameworks should not depend upon this
    * context and should use the ADFContext directly instead.
    */

   protected Properties initializeContextForDataControl(
      ADFContext adfContext, Properties context)
   {
      Principal userPrincipal = null;

      try
      {
         userPrincipal = adfContext.getSecurityContext()
            .getUserPrincipal();
      }
      catch (NoSuchMethodError e)
      {
         // ignore.  servlet 2.0 compatibility issue.
      }

      if (userPrincipal != null)
      {
         context.put(
            SessionCookieFactory.PROP_USER_PRINCIPAL_KEY, userPrincipal);
      }

      return context;
   }

   public static Object loadApplication()
   {
      if (JboEnvUtil.inOC4J())
      {
         return ADFContext.getCurrent().getApplication().getId();
      }

      return null;
   }

   public static void destroyApplication(Object applicationContext)
   {
      if (Diagnostic.isOn())
      {
         Diagnostic.println("Destroying BindingFacesBridgeLifecycleListener.  Removing ApplicationPools...");
      }
      
      PoolMgr manager = null;
      if (JboEnvUtil.inOC4J() && (applicationContext  != null))
      {
         manager = ((ContextPoolManager)PoolMgr.getInstance())
            .getApplicationPoolMgr(applicationContext);
      }
      else
      {
         manager = PoolMgr.getInstance();
      }
      
      manager.destroy();

      // bug 5449434.  
      // the connection pool manager is relying upon the class loader
      // of the application that first requested a connection.
      // application's should really use the datasource instead of the
      // BC4J connection pool when in oc4j.  applying this fix for now
      // so that we do not get exceptions when redeploying an app
      // in the embedded container.
      //
      // not sure that a permanent fix exists.  i don't think the j2ee 
      // contract supports statics.  one potential issue is that a 
      // class we loaded with the dead class loader later causes a class load.
      // we can't simply destroy the connection pool as we do the application
      // pool above because there may be other applications that depend upon it.
      ((ResourcePoolManager)ConnectionPoolManagerFactory.getConnectionPoolManager()).classLoaderShuttingDown(); 

   }

   protected abstract ADFContext initADFContext();
   protected abstract void resetADFContext();
   protected abstract BindingContext createBindingContext(ADFContext adfContext);
   protected abstract SessionContext createSessionContext(ADFContext adfContext);
   protected abstract void handleAuthenticationFailure(ADFContext adfContext);
}
