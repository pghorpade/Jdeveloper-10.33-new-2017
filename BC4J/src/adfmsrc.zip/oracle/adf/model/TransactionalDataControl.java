package oracle.adf.model;

import java.util.Map;

/**
 * DataControl is a collection of DataControls accessed by their key
 * This is only for internal purposes and implementing just this interface
 * will not work in ADF 9.0.5.1. This interface exists for future api
 * needs.
 */
public interface TransactionalDataControl extends DataControl, oracle.binding.TransactionalDataControl, oracle.binding.UpdateableDataControl
{
   // JRS 111805 -- Maintaining the old transactional data control interface
   // here by having this interface also extend UpdateableDC.  I believe
   // that this interface is deprecated so this should be okay.
   // see bug 4737504
   /**
   * Returns true if this transaction has been dirtied by this application.  
   */
   boolean isTransactionDirty();
   
   /**
   * Create a new row for the iterator associated with the given iterator-binding at the given index and return the new row.  
   */
   Object createRowData(RowContext ctx);
   
   /**
   * Called before the row in the RowContext object is modified/marked as removed.  
   */
   Object registerDataProvider(RowContext ctx);
   
   /**
   * This method is to remove the row object (the obj parameter) from the underlying data source.  
   */
   boolean removeRowData(RowContext ctx);
   
  
   /**
   * Helper method that invokes rollback on the current Transaction.  
   */
   void rollbackTransaction();
   
   /**
   * Invoke the transaction's commit() method to save all changes to the data source.  
   */
   void commitTransaction();
   
   /**
   * validate transaction if dirty. 
   */
   void validate();
}
