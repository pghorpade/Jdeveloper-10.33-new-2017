package oracle.adf.model;

/**
 * A map that provides a name-space to locate binding objects
 * through which data is accessed on a view.
 */
public interface BindingContainer 
{
}
