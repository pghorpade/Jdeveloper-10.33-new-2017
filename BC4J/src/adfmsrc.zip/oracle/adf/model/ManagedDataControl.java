package oracle.adf.model;

import java.util.Map;

/**
 * ManagedDataControl 
 */
public interface ManagedDataControl extends DataControl, oracle.binding.ManagedDataControl
{
   /**
    * Invoked in some contexts to signal the beginning of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the ADF framework before
    * control is forwarded to the first <tt>Servlet</tt> defined by the request.
    * <p>
    * Subclassing datacontrols may extend this method to perform request level
    * initialization of the <tt>DataControl</tt>.
    * <p>
    * This method is guaranteed to be called only once per browser request.
    * Page forwards should not result in multiple invocations.
    * <p>
    * @param requestCtx a HashMap representing request context.  Web 
    *    applications which require request context may use the
    *    <tt>BindingContext.HTTP_REQUEST</tt> and
    *    <tt>BindingContext.HTTP_RESPONSE</tt> keys to acquire a reference
    *    from from the BindingContext.
    */
   void beginRequest(java.util.HashMap requestCtx);
   
   /**
    * Invoked in some contexts to signal the end of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the ADF framework after
    * control is returned from the last <tt>Servlet</tt> defined by the request
    * page flow.
    * <p>
    * Subclassing datacontrols may extend this method to perform request level
    * cleanup of the <tt>DataControl</tt>.
    * <p>
    * This method is guaranteed to be called only once per browser request.
    * Page forwards should not result in multiple invocations.
    * <p>
    * @param requestCtx a HashMap representing request context.  Web 
    *    applications which require request context may use the
    *    <tt>BindingContext.HTTP_REQUEST</tt> and
    *    <tt>BindingContext.HTTP_RESPONSE</tt> keys to acquire a reference
    *    from from the BindingContext.
    */
   void endRequest(java.util.HashMap requestCtx);
   
   /**
    * Resets the DataControl.  DataControl providers should extend this method
    * to reset any model session state that may have been managed by this
    * DataControl.  For example:
    * <p>
    * The ADF/BC DataControl has extended resetState to release the DataControl 
    * ApplicationModule to the ApplicationPool in unmanaged release mode. 
    * <p>
    * An EJB DataControl provider may extend resetState to close the DataControl
    * EJB SessionBean
    * <p>
    * A Toplink DataControl provider may extend resetState to close the
    * DataControl UnitOfWork or ClientSession.
    * <p>
    * Please note that resetState may not occur immediately.  If beginRequest
    * has been invoked on the DataControl then resetState processing will be
    * deferred until endRequest processing.
    * <p>
    * Extending DataControl providers should invoke release(REL_DATA_REFS) after
    * performing and DataControl specific resetState handling.
    * <p>
    * @return true if resetState was processed immediately.  false if resetState
    *    was deferred to endRequest processing.
    */
   boolean resetState(); 
}
