/*
 * @(#)OperationInfo.java
 *
 * Copyright 2003-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model;

/**
 * Represents information about an operation that a datacontrol should use to invoke it.
 */
public interface OperationInfo extends oracle.binding.OperationInfo
{
   /**
    * An El-expression that identifies the object on which an operation has to be invoked.
    * This expression should be relative to the BindingContext for this application instance.
    */
   String getInstanceName();

   /**
    * Name of the operation to invoke
    */
   String getOperationName();

   /**
    * Returns an array of OperationParameters that this operation needs.
    * Returns null if no parameters are needed.
    */
   OperationParameter[] getParameters();
}
