/*
 * @(#)DataControlDefinitionFactory.java
 *
 * Copyright 2001-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model;

import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.model.binding.DCDefBase;
import oracle.adf.model.binding.DefinitionFactory;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;


public class DataControlDefinitionFactory implements DefinitionFactory
{
   public static final String DATACONTROL             = "DataControl";
   public static final String BC4J_DATACONTROL        = "BC4JDataControl";
   public static final String JAVABEAN_DATACONTROL    = "JavaBeanDataControl";
   public static final String ADAPTER_DATACONTROL     = "AdapterDataControl";
   public static final String EJB_DATACONTROL         = "EJBDataControl";
   public static final String TOPLINK_DATACONTROL     = "ToplinkDataControl";
   public static final String WEBSERVICE_DATACONTROL  = "WebServiceDataControl";

   private static final String clzBC4J_DCFACTORY = "oracle.adf.model.bc4j.DataControlFactoryImpl";
   private static final String clzBEAN_DCFACTORY = oracle.adf.model.generic.DataControlFactoryImpl.class.getName();

   private DCDataControlDef internalCreateDataControlDef(String subType, String dcFactoryName)
   {
      DCDataControlDef dcDef =  new DCDataControlDef();

      dcDef.setSubType(subType);

      if (dcDef.getFactoryClass() == null)
      {
         dcDef.setFactoryClass(dcFactoryName);
      }
      return dcDef;
   }

   public DCDefBase createDefinition(DefElement element)
   {
      DCDefBase   eInfo = null;
      String      defClassName = element.readString(JUTags.DefClass);
      String      elementName = element.getLocalName(); //RF: changed redundant call

      if (defClassName != null)
      {
         try
         {
            eInfo = (DCDefBase) JBOClass.forName(defClassName).newInstance();
         }
         catch (Exception e)
         {
            JboException rtEx = new JboException(
                                              CSMessageBundle.class,
                                              CSMessageBundle.EXC_CUSTOM_CLASS_NOT_FOUND,
                                              null);
            rtEx.addToDetails(e);
            throw rtEx;
         }
      }
      else if(elementName.equals("Session"))
      {
         eInfo = internalCreateDataControlDef(JUTags.BC4JDataControl,
                                              clzBC4J_DCFACTORY);
      }
      else if(elementName.equals(DATACONTROL))
      {
         eInfo = internalCreateDataControlDef(JUTags.JavaBeanDataControl,
                                              clzBEAN_DCFACTORY);
      }
      else if(elementName.equals(JAVABEAN_DATACONTROL))
      {
         eInfo = internalCreateDataControlDef(JUTags.JavaBeanDataControl,
                                              clzBEAN_DCFACTORY);
      }
      else if(elementName.equals(BC4J_DATACONTROL))
      {
         eInfo = internalCreateDataControlDef(JUTags.BC4JDataControl,
                                              clzBC4J_DCFACTORY);
      }
      else if(elementName.equals(EJB_DATACONTROL))
      {
         eInfo = new DCDataControlDef();
         eInfo.setSubType(JUTags.EJBDataControl);
      }
      else if(elementName.equals(TOPLINK_DATACONTROL))
      {
         eInfo = new DCDataControlDef();
         eInfo.setSubType(JUTags.ToplinkDataControl);
      }
       else if(elementName.equals(WEBSERVICE_DATACONTROL))
      {
         eInfo = new DCDataControlDef();
         eInfo.setSubType(JUTags.WebServiceDataControl);
      }
      else if(elementName.equals(ADAPTER_DATACONTROL))
      {
        eInfo = new oracle.adf.model.adapter.AdapterDataControlDef();
      }

      if(eInfo != null)
      {
         eInfo.loadFromXML(element);
      }
      return eInfo;
   }
}
