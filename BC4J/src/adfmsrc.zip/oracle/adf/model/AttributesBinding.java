package oracle.adf.model;

import java.util.List;

/**
 * A ControlBinding that binds a single attribute value exposed via a datacontrol
 * to a view component.
 */
public interface AttributesBinding extends ControlBinding, oracle.binding.AttributesBinding
{
   /**
    * Return the value that should be rendered on a view for the attribute
    * associated with this binding.
    */
   public Object getInputValue(int index);

   /**
    * Update the attribute value associated with this binding. If there are exceptions
    * while updating this attribute, these exceptions should be accessible via getErrors()
    */
   public void setInputValue(int index, Object inputVal);


   public boolean isUpdateable(int index);

   public String[] getLabelSet();

}
