package oracle.adf.model.utils;

import oracle.adf.model.meta.OperationDefinition;
import oracle.adf.model.ADFmMessageBundle;

import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.DefinitionContainer;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.Definition;
import oracle.binding.meta.MethodReturnDefinition;
import oracle.binding.meta.ArrayListDefinitionContainer;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.metaimpl.BaseValueObjectDefinition;
import oracle.jbo.AttributeHints;

import java.util.Hashtable;

/**
 * Definition for standard operations
 */
public class StandardOperationDef implements OperationDefinition
{
   private int mId;
   private DataControlDefinition mDataControlDefinition;
   private ArrayListDefinitionContainer mParameters;
   private StructureDefinition mParent;
   private String mName;
   private String mFullName;
   private Hashtable mProperties;
   private boolean mAllowAddParameters;

   /**
    * @param id The action id for the action. 
    *           See oracle.adf.model.meta.OperationDefinition for list.
    * @param name Name (key) for the action. This name should not be localized.
    */
   public StandardOperationDef(int id, String name)
   {
      mId = id;
      mName = name;
      mAllowAddParameters = false;
      mParameters = new ArrayListDefinitionContainer();
      // set default display label
      String defaultLabel = getDefaultLabelForId(id);
      setProperty(AttributeHints.ATTRIBUTE_LABEL, defaultLabel);
      switch(mId)
      {
         case OperationDefinition.ACTION_REMOVEROW_WITH_KEY: 
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE:
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY:
            {
               mParameters.add(new StandardOpParameterDefinition());
            }
            break;
         case OperationDefinition.ACTION_CREATE_INSERT_ROW:
            {
               // even though action is CREATE_INSERT, it should be displayed as "Create" in DC
               // Palette (see bug 4429595)
               setProperty(AttributeHints.ATTRIBUTE_LABEL, ADFmMessageBundle.getResString(ADFmMessageBundle.ACTION_CREATE));
            }
            break;
         case OperationDefinition.ACTION_EXECUTE_WITH_PARAMS:
            mAllowAddParameters = true;
            break;
      }      
   }
   
   public static int getOperationCodeFromId(String sId)
   {
      if(sId.equals(ADFmMessageBundle.ACTION_FIRST))
      {
         return OperationDefinition.ACTION_FIRST;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_LAST))
      {
         return OperationDefinition.ACTION_LAST;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_NEXT))
      {
         return OperationDefinition.ACTION_NEXT;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_PREVIOUS))
      {
         return OperationDefinition.ACTION_PREVIOUS;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_NEXT_SET))
      {
         return OperationDefinition.ACTION_NEXT_SET;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_PREVIOUS_SET))
      {
         return OperationDefinition.ACTION_PREVIOUS_SET;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_FIND))
      {
         return OperationDefinition.ACTION_ITERATOR_BINDING_FIND;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_EXECUTE))
      {
         return OperationDefinition.ACTION_EXECUTE;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_ITERATOR_BINDING_EXECUTE))
      {
         return OperationDefinition.ACTION_ITERATOR_BINDING_EXECUTE;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_CREATE))
      {
         return OperationDefinition.ACTION_CREATE_ROW;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_CREATE_INSERT))
      {
         return OperationDefinition.ACTION_CREATE_INSERT_ROW;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_DELETE))
      {
         return OperationDefinition.ACTION_REMOVE_CURRENT_ROW;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_COMMIT))
      {
         return OperationDefinition.ACTION_COMMIT_TRANSACTION;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_ROLLBACK))
      {
         return OperationDefinition.ACTION_ROLLBACK_TRANSACTION;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_REMOVEROW_WITH_KEY))
      {
         return OperationDefinition.ACTION_REMOVEROW_WITH_KEY;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEY))
      {
         return OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEYVALUE))
      {
         return OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE;
      }
      if(sId.equals(ADFmMessageBundle.ACTION_EXECUTE_WITH_PARAMS))
      {
         return OperationDefinition.ACTION_EXECUTE_WITH_PARAMS;
      }
      
      return OperationDefinition.ACTION_INVOKE_METHOD;
   }
  
   public static String getDefaultNameForId(int nId)
   {
      switch(nId)
      {
         case OperationDefinition.ACTION_FIRST:
            return ADFmMessageBundle.ACTION_FIRST;
         case OperationDefinition.ACTION_LAST:
            return ADFmMessageBundle.ACTION_LAST;
         case OperationDefinition.ACTION_NEXT:
            return ADFmMessageBundle.ACTION_NEXT;
         case OperationDefinition.ACTION_PREVIOUS:
            return ADFmMessageBundle.ACTION_PREVIOUS;
         case OperationDefinition.ACTION_NEXT_SET:
            return ADFmMessageBundle.ACTION_NEXT_SET;
         case OperationDefinition.ACTION_PREVIOUS_SET:
            return ADFmMessageBundle.ACTION_PREVIOUS_SET;
         case OperationDefinition.ACTION_FIND:
         case OperationDefinition.ACTION_ITERATOR_BINDING_FIND:
            return ADFmMessageBundle.ACTION_FIND;
         case OperationDefinition.ACTION_EXECUTE:
            return ADFmMessageBundle.ACTION_EXECUTE;
         case OperationDefinition.ACTION_ITERATOR_BINDING_EXECUTE:
            return ADFmMessageBundle.ACTION_EXECUTE; // use "Execute" as name
         case OperationDefinition.ACTION_CREATE_ROW:
            return ADFmMessageBundle.ACTION_CREATE;
         case OperationDefinition.ACTION_CREATE_INSERT_ROW:
            return ADFmMessageBundle.ACTION_CREATE_INSERT;
         case OperationDefinition.ACTION_REMOVE_CURRENT_ROW:
            return ADFmMessageBundle.ACTION_DELETE;
         case OperationDefinition.ACTION_COMMIT_TRANSACTION:
            return ADFmMessageBundle.ACTION_COMMIT;
         case OperationDefinition.ACTION_ROLLBACK_TRANSACTION:
            return ADFmMessageBundle.ACTION_ROLLBACK;
         case OperationDefinition.ACTION_REMOVEROW_WITH_KEY:
            return ADFmMessageBundle.ACTION_REMOVEROW_WITH_KEY;
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY:
            return ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEY;
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE:
            return ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEYVALUE;
         case OperationDefinition.ACTION_EXECUTE_WITH_PARAMS:
            return ADFmMessageBundle.ACTION_EXECUTE_WITH_PARAMS;
      }
      return "";
   }
   
   public static String getDefaultKeyForId(int nId)
   {
      switch(nId)
      {
         case OperationDefinition.ACTION_FIRST:
            return ADFmMessageBundle.ACTION_FIRST;
         case OperationDefinition.ACTION_LAST:
            return ADFmMessageBundle.ACTION_LAST;
         case OperationDefinition.ACTION_NEXT:
            return ADFmMessageBundle.ACTION_NEXT;
         case OperationDefinition.ACTION_PREVIOUS:
            return ADFmMessageBundle.ACTION_PREVIOUS;
         case OperationDefinition.ACTION_NEXT_SET:
            return ADFmMessageBundle.ACTION_NEXT_SET;
         case OperationDefinition.ACTION_PREVIOUS_SET:
            return ADFmMessageBundle.ACTION_PREVIOUS_SET;
         case OperationDefinition.ACTION_FIND:
         case OperationDefinition.ACTION_ITERATOR_BINDING_FIND:
            return ADFmMessageBundle.ACTION_FIND;
         case OperationDefinition.ACTION_EXECUTE:
            return ADFmMessageBundle.ACTION_EXECUTE;
         case OperationDefinition.ACTION_ITERATOR_BINDING_EXECUTE:
            return ADFmMessageBundle.ACTION_ITERATOR_BINDING_EXECUTE;
         case OperationDefinition.ACTION_CREATE_ROW:
            return ADFmMessageBundle.ACTION_CREATE;
         case OperationDefinition.ACTION_CREATE_INSERT_ROW:
            return ADFmMessageBundle.ACTION_CREATE_INSERT;
         case OperationDefinition.ACTION_REMOVE_CURRENT_ROW:
            return ADFmMessageBundle.ACTION_DELETE;
         case OperationDefinition.ACTION_COMMIT_TRANSACTION:
            return ADFmMessageBundle.ACTION_COMMIT;
         case OperationDefinition.ACTION_ROLLBACK_TRANSACTION:
            return ADFmMessageBundle.ACTION_ROLLBACK;
         case OperationDefinition.ACTION_REMOVEROW_WITH_KEY:
            return ADFmMessageBundle.ACTION_REMOVEROW_WITH_KEY;
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY:
            return ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEY;
         case OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE:
            return ADFmMessageBundle.ACTION_SETCURRENTROW_WITH_KEYVALUE;
         case OperationDefinition.ACTION_EXECUTE_WITH_PARAMS:
            return ADFmMessageBundle.ACTION_EXECUTE_WITH_PARAMS;
      }
      return "";
   }
   
   public static String getDefaultLabelForId(int nId)
   {
      String sKey = getDefaultKeyForId(nId);
      if(sKey.equals(""))
         return "";
         
      return ADFmMessageBundle.getResString(sKey);
   }
   
   public StandardOperationDef(int id)
   {
      // bug 4744840 - don't use localized name as action name
      this(id, getDefaultNameForId(id));
   }
   
   public DefinitionContainer getOperationParameters()
   {
      return mParameters;
   }

   public MethodReturnDefinition getOperationReturnType()
   {
      return null;
   }

   public int getOperationId()
   {
      return mId;
   }

   /**
    * Set the DataControlDefinition to be returned in the interface method
    * getDataControlDefinition.
    * 
    * @param dataControlDefinition The DataControlDefinition that this standard operation
    *                              belongs to.
    */ 
   public void setDataControlDefinition(DataControlDefinition dataControlDefinition)
   {
      mDataControlDefinition = dataControlDefinition;
   }
   
   public DataControlDefinition getDataControlDefinition()
   {
      if (mDataControlDefinition != null)
      {
         // if setDataControlDefinition is called, use the DataControlDefinition
         // set by that call.
         return mDataControlDefinition;
      }
      else if (mParent != null)
      {
         // otherwise, if the parent definition is set, return the parent's
         // DataControlDefinition.
         return mParent.getDataControlDefinition();
      }
      else
      {
         return null;
      }
   }

   
   /**
    * Set the parent definition to be returned in the interface method
    * getParent.
    * 
    * @param parent The parent definition of this action definition.
    */
   public void setParent(StructureDefinition parent)
   {
      mParent = parent;
   }
   
   public Definition getDefinitionParent()
   {
      return mParent;
   }

   /**
    * The name to be returned by the getName() interface method, should
    * the default one used in the constructor need to be overwritten.
    *  
    * @param name The name to be returned when getName() is called.
    */ 
   public void setName(String name)
   {
      mName = name;
   }
   
   public String getName()
   {
      return mName;
   }

   /**
    * Add a parameter to the standard operation. 
    * For use by adding parameter for the "ExecuteWithParam" operation.
    * 
    * @param name Name of the parameter.
    * @param javaType A String containing the Java type of the parameter.
    * @param fullName full name of the parameter.
    */ 
   public void addParameter(String name, String javaType, String fullName)
   {
      if (mAllowAddParameters)
      {
         mParameters.add(new StandardOpParameterDefinition(name, javaType, fullName));
      }
   }
   /**
    * The fullname to be returned by the getFullName() interface
    * method can be overriden by the value set by this method.
    * 
    * @param fullName The full name to be returned when getFullName() is called.
    */ 
   public void setFullName(String fullName)
   {
      mFullName = fullName;
   }
   
   public String getFullName()
   {
      if (mFullName != null)
      {
         // if setFullName has been called to set the fullname, return it
         return mFullName;
      }
      else if (mParent != null)
      {
         // if setFullName has not be called, and if parent is set,
         // append the parent's fullname with the action name as the
         // fullname.
         return mParent.getFullName() + "." + getName();
      }
      else
      {
         // if setFullName has not been called, and parent definition is
         // not set, return the action name as the fullname.
         return getName();
      }
   }

   public Object getProperty(String propertyName)
   {
      if (mProperties == null)
      {
         return null;
      }
      return mProperties.get(propertyName);
   }

   public Hashtable getProperties()
   {
      return mProperties;
   }

   public void setProperty(String propertyName, Object propertyValue)
   {
      if (mProperties == null)
      {
         mProperties = new Hashtable();
      }
      mProperties.put(propertyName, propertyValue);
   }
   
   public int getDefinitionType()
   {
      return TYPE_OPERATION;
   }
   
   class StandardOpParameterDefinition extends BaseValueObjectDefinition implements ParameterDefinition 
   {
      /**
       *  no arg constructor for use by removeRowWithKey, setCurrentRowWithKey, 
       *  and setCurrentRowWithKeyValue operations. 
       */ 
      public StandardOpParameterDefinition()
      {
         super("rowKey", StandardOperationDef.this, "rowKey", "java.lang.String");
      }
      
      /**
       * Constructor with parameter name and java type passed in. 
       * For use by adding parameter for ExecuteWithParam operation.
       * 
       * @param name Name of the parameter.
       * @param javaType A String containing the Java type of the parameter.
       * @param fullName full name of the parameter.
       */ 
      public StandardOpParameterDefinition(String name, String javaType, String fullName)
      {
         super(name, StandardOperationDef.this, fullName, javaType);
      }
      
      public boolean isStructured()
      {
         return false;
      }
      
      public StructureDefinition getStructure()
      {
         return null;
      }
      
      public boolean isCollection()
      {
         return false;
      }

      public boolean isScalarCollection()
      {
         return false;
      }
      
      public int getDefinitionType()
      {
         return TYPE_PARAMETER;
      }
   }

     /**
   ** @return true if this operation definition represents a static
   ** method.
   **/
   public boolean isStatic()
   {
      return false;
   }

}
