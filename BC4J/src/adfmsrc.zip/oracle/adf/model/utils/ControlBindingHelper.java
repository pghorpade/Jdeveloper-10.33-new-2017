package oracle.adf.model.utils;

import oracle.adf.model.ControlBinding;
import oracle.adf.model.BindingContext;

public interface ControlBindingHelper
{
   static public final int ANY       = 0;
   static public final int ACTION    = 1;
   static public final int LABEL     = 2;
   static public final int TEXTFIELD = 3;
   static public final int TABLE     = 4;
   public void bindControl(BindingContext ctx, int type, Object renderer, String bindingPath);
}

