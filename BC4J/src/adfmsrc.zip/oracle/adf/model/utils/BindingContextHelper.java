package oracle.adf.model.utils;

import oracle.adf.model.BindingContext;

public interface BindingContextHelper
{
   static final int DATACONTROL=1;
   static final int BINDINGCONTAINER=2;
   public void startContextObject(BindingContext ctx, int type, String name, String fullName);
}


