package oracle.adf.model.utils;

import oracle.adf.model.UpdateListener;
import oracle.adf.model.OperationInfo;

public class Adapt227
{
   static public UpdateListener wrapJSRUpdateListener(oracle.binding.UpdateListener listener)
   {
      class MyUpdateListener implements UpdateListener
      {
         oracle.binding.UpdateListener jsrListener;
         MyUpdateListener(oracle.binding.UpdateListener listener)
         {
            jsrListener = listener;
         }
         public void updateRenderer ()
         {
            jsrListener.updateRenderer();
         }
      }
      return new MyUpdateListener(listener);
   }

   /*
   static public OperationInfo wrapMethodInfo(oracle.binding.OperationInfo jsrObj)
   {
      class MyMethodInfo implements MethodInfo
      {
         oracle.binding.MethodInfo jsrObj;
         MyMethodInfo(oracle.binding.MethodInfo obj)
         {
            jsrObj= obj;
         }

         public String getInstanceName()
         {
            return jsrObj.getInstanceName();
         }

         public String getMethodName()
         {
            return jsrObj.getMethodName();
         }

         public String getReturnName()
         {
            return jsrObj.getReturnName();
         }

      }
      return new MyMethodInfo(jsrObj);
   }
   */
}

