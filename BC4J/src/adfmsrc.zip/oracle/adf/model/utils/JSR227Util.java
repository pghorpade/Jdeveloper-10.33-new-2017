package oracle.adf.model.utils;

import oracle.binding.meta.OperationDefinition;
import oracle.binding.meta.DefinitionContainer;
import oracle.binding.meta.Definition;
import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.NamedDefinition;
import oracle.binding.meta.AccessorDefinition;
import oracle.binding.meta.MethodReturnDefinition;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.ParameterDefinition;

import java.util.Iterator;

/**
 * Utility methods for runtime classes to create OperationDefinition 
 * instances for standard operations.
 * 
 * This class is for use by internal RT classes.
 */ 
public class JSR227Util
{
   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "FIRST".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "FIRST" standard operation.
    */ 
   public static StandardOperationDef createFirstAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_FIRST);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "LAST".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "LAST" standard operation.
    */ 
   public static StandardOperationDef createLastAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_LAST);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "NEXT".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "NEXT" standard operation.
    */ 
   public static StandardOperationDef createNextAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_NEXT);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "PREVIOUS".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "PREVIOUS" standard operation.
    */ 
   public static StandardOperationDef createPreviousAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_PREVIOUS);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "NEXT_SET".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "NEXT_SET" standard operation.
    */ 
   public static StandardOperationDef createNextSetAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_NEXT_SET);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "PREVIOUS_SET".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "PREVIOUS_SET" standard operation.
    */ 
   public static StandardOperationDef createPreviousSetAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_PREVIOUS_SET);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "FIND".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "FIND" standard operation.
    */ 
   public static StandardOperationDef createFindAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_ITERATOR_BINDING_FIND);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "EXECUTE".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "EXECUTE" standard operation.
    */ 
   public static StandardOperationDef createExecuteAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_ITERATOR_BINDING_EXECUTE);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "ExecuteWithParam".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "ExecuteWithParam" standard operation.
    */ 
   public static StandardOperationDef createExecuteWithParamAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_EXECUTE_WITH_PARAMS);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "CREATE".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "CREATE" standard operation.
    */ 
   public static StandardOperationDef createCreateAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_CREATE_ROW);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "CREATEINSERT".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "CREATEINSERT" standard operation.
    */ 
   public static StandardOperationDef createCreateInsertAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_CREATE_INSERT_ROW);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "REMOVE".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "REMOVE" standard operation.
    */ 
   public static StandardOperationDef createRemoveAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_REMOVE_CURRENT_ROW);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "COMMIT".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "COMMIT" standard operation.
    */ 
   public static StandardOperationDef createCommitAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_COMMIT_TRANSACTION);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "ROLLBACK".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "ROLLBACK" standard operation.
    */ 
   public static StandardOperationDef createRollbackAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_ROLLBACK_TRANSACTION);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "REMOVEROW_WITH_KEY".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "REMOVEROW_WITH_KEY" standard operation.
    */ 
   public static StandardOperationDef createRemoveRowWithKeyAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_REMOVEROW_WITH_KEY);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "SETCURRENTROW_WITH_KEY".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "SETCURRENTROW_WITH_KEY" standard operation.
    */ 
   public static StandardOperationDef createSetCurrentRowWithKeyAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_SETCURRENTROW_WITH_KEY);
   }

   /**
    * Utility method for creation a OpreationDefinition for the
    * standard operation "SETCURRENTROW_WITH_KEYVALUE".
    * Caller needs to set the parent and dataControlDefinition of
    * the OperationDefinition returned.
    * 
    * @return A StandardOperationDef which is an OperationDefinition
    *         for the "SETCURRENTROW_WITH_KEYVALUE" standard operation.
    */ 
   public static StandardOperationDef createSetCurrentRowWithKeyValueAction()
   {
      return new StandardOperationDef(oracle.adf.model.meta.OperationDefinition.ACTION_SETCURRENTROW_WITH_KEYVALUE);
   }
   
   /**
    * Find the OperationDefinition from the given definition container with
    * the given action id. If there are more than one OperationDefinition
    * with the given action id, any one of them will be returned.
    * 
    * @param defs The DefinitionContainer to be searched.
    * @param actionId Look for OperationDefinition with this Action Id. 
    * @return An OperationDefinition contained in the given definition container
    *         with the given action id, if one is found. Null if none is found.s
    */ 
   public static OperationDefinition findOperationDefinitionByActionId(DefinitionContainer defs, int actionId)
   {
      if (defs == null)
      {
         return null;
      }
      OperationDefinition defFound = null;
      
      Iterator defIter = defs.iterator();
      while (defIter.hasNext() && defFound == null)
      {
         Definition def = (Definition) defIter.next();
         if (def.getDefinitionType() == Definition.TYPE_OPERATION)
         {
            OperationDefinition oDef = (OperationDefinition)def;
            if (oDef.getOperationId() == actionId)
            {
               defFound = oDef;
            }
         }
      }
      return defFound;
   }
   
   /**
    * Utility method to get the StructureDefinition from a given named definition,
    * if the named definition is one of the definition types that contains
    * a structure.
    * 
    * @param def The NamedDefinition whose StructureDefinition should be returned
    * @return The StructureDefinition from calling getStructure() on the given
    *         definition.
    */ 
   public static StructureDefinition getStructureDefinition(NamedDefinition def)
   {
      StructureDefinition sDef = null;
      if (def != null)
      {
         int type = def.getDefinitionType();
         switch (type)
         {
            case Definition.TYPE_ACCESSOR:
               {
                  sDef = ((AccessorDefinition)def).getStructure();
                  break;
               }
            case Definition.TYPE_METHODRETURN:
               {
                  sDef = ((MethodReturnDefinition)def).getStructure();
                  break;
               }
            case Definition.TYPE_DATACONTROL:
               {
                  sDef = ((DataControlDefinition)def).getStructure();
                  break;
               }
            case Definition.TYPE_PARAMETER:
               {
                  sDef = ((ParameterDefinition)def).getStructure();
                  break;
               }
         }
      }
      return sDef;
   }
}
