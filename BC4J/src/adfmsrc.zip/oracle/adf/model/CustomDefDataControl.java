package oracle.adf.model;

public interface CustomDefDataControl extends DataControl
{
   /**
    * Initialize this datacontrol from the properties sent in in this Map.
    * Included in this should be a data structure holding onto the custom
    * xml-element in the datacontrol metadata.
    */
   void initFromMetadata(java.util.Map map);
}
