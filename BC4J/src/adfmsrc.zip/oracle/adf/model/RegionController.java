package oracle.adf.model;

/**
 * *** For internal framework use only ***
 * For use by ADF Controller to indicate that a RegionListener
 * is a controller class that will take the responsiblity of 
 * calling region's refresh and validate methods.
 */
public interface RegionController extends RegionListener
{
   /**
    * Overridden from RegionListener.
    * Return value is ignored for the RegionController registered
    * on a BindingContainer. It is assumed that RegionController
    * will invoke the refresh() call on the given region via
    * controller apis.
    */
   boolean refreshRegion(RegionContext region);
}
