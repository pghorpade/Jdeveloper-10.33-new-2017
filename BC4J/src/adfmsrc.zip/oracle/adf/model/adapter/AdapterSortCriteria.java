/*
 * @(#)AdapterSortCriteria.java
 *
 * Copyright 2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter;

import oracle.jbo.SortCriteria;


/**
 * Sort criteria that can be defined for the data controls.
 *
 * @version 1.0
 * @since 10.1.3
 */
public final class AdapterSortCriteria 
{
  // the arrribute name to sort on
  private String mSortOn = null;
  // Flag to indiacte sorting order
  private boolean mFlag;
   
  //===========================================================================
  // Constructors 
  //===========================================================================

  /**
   * Creates a new <code>AdapterSortCriteria</code> instance from the passed
   * sort criteria.
   * @param criteria passed sort criteria from where this object will be built.
   */
  public AdapterSortCriteria(SortCriteria criteria)
  {
    setSortOn(criteria.getAttributeName());
    setDescending(criteria.isDescending());
  }

  /**
   * Creates a new <code>AdapterSortCriteria</code> instance.
   */
  public AdapterSortCriteria()
  {
  }

  /**
   * Gets the attributes to be sorted on
   */
  public String getSortOn()
  {
    return mSortOn;
  }

  /**
   * Sets the attribute to be sorted on
   */
  public void setSortOn(String sortOn)
  {
    mSortOn = sortOn;
  }
  
  /**
   * Returns true if sort criteria is defined in descending order.
   */
  public boolean isDescending()
  {
    return mFlag;
  }

  /**
   * Sets the sorting's value.
   * @param flag value is true if the sort is to be performed in descending order.
   */
   public void setDescending(boolean flag)
   {
     mFlag = flag;
   }	

}
