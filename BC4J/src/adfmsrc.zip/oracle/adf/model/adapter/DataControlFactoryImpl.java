/*
 * @(#)DataControlFactoryImpl.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.Map;
import java.util.List;

import java.util.logging.Level;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import oracle.adf.model.DataControl;
import oracle.adf.model.DataControlFactory;
import oracle.adf.model.BindingContext;

import oracle.jbo.common.NamedObjectImpl;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;

import oracle.adf.model.adapter.utils.NodeAttributeHelper;
import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.share.logging.ADFLogger;
import java.util.logging.Handler;


/**
 * Factory class to create a data control instance from the XML metadata.
 * ADF runtime calls this factory to create the data control.
 *
 * @see oracle.adf.model.DataControl
 */
public class DataControlFactoryImpl implements DataControlFactory
{
  /** Tag to define data control's name. */
  public static final String ID = "id";
  /** Tag for the definition file name. */
  public static final String DEFINITION = "Definition";

  // Key to store the definition paramas in the temporary map
  private static final String DEF_PARAM = "dc_def_params";
  
  // Debug logger
  private ADFLogger mDbgLog = AdapterContext.getDefaultContext().getLogger();

  /**
   * Creates a blank factory class.
   */
  public DataControlFactoryImpl()
  {
  }


  /**
   * Creates a data control.
   * <p>
   * Incase of HttpSession, add APP_PARAM properties into applicationParams
   * before calling createSession. For types for these three properties see
   * HttpContainer.findSessionCookie().
   *
   * @param appParams   Application parameters.
   * @param ctx         Binding context.
   * @param node        Definition node.
   * @return Created data control object.
   */
  public DataControl createSession(
    BindingContext ctx,
    Node node,
    Map appParams)
  {    
    mDbgLog.entering(getClass().getName(),"createSession");

    // We'll create a Def object to load the node.
    mDbgLog.fine("Creating new data control definition from the node.");
    AdapterDataControlDef def = new AdapterDataControlDef();
    def.retrieveFromNode(node);

    String name = def.getName();
    if (name == null)
    {
      name = (String) def.get(JUTags.ID);
    }

    // Call to create a dat control from the def. The Def is extended from Map
    DataControl dc = createSession(ctx, name, appParams, def);

    mDbgLog.exiting(getClass().getName(),"createSession");
    return dc;
  }

  /**
   * Creates a data control.
   * <p>
   * Incase of HttpSession, add APP_PARAM properties into applicationParams
   * before calling createSession. For types for these three properties see
   * HttpContainer.findSessionCookie().
   *
   * @param ctx         Binding context.
   * @param sName       Name of the data control.
   * @param appParams   Application parameters.
   * @param cpxMetaData Contains the metadata for the data control.
   * @return Created data control object.
   */
  public DataControl createSession(
    BindingContext ctx,
    String sName,
    Map appParams,
    Map cpxMetaData)
  {
    try
    {
      mDbgLog.entering(getClass().getName(), "createSession");

      String defFileName = (String) cpxMetaData.get(JUTags.DefinitionClass);
      String implDefClass = 
        (String) cpxMetaData.get(AdapterDataControlDef.IMPL_DEF);
      Node srcDefNode = 
        (Node) cpxMetaData.get(AdapterDataControlDef.SOURCE);
      
      // ToDo: Check for null objects

      // Load the definition class
      mDbgLog.fine("Loading definition.");
      Object defObj = 
        oracle.jbo.common.JBOClass.forName(implDefClass).newInstance();
      if (!(defObj instanceof oracle.adf.model.adapter.AbstractDefinition))
      {
        mDbgLog.severe("ImplDef defined for the data control is not according to the specification. It must be a subclass of oracle.adf.model.adapter.AbstractDefinition.");
        //ToDo: resource
        throw new Exception("ImplDef is not a subclass of oracle.adf.model.adapter.AbstractAdapter.");
      }
      
      // cpxMetaData should be an instance of the AdapterDataControlDef class.
      // Still we'll check its type in case that's not the case.
      // If this is not an instance of AdapterDataControlDef we'll simply set
      // the cpxMetaData as the source for parameters for the data control 
      // instance.
      if (cpxMetaData instanceof AdapterDataControlDef)
      {
        Map params = ((AdapterDataControlDef)cpxMetaData).getParameters();
        appParams.putAll(params);
      }
      else
      {
        appParams.putAll(cpxMetaData);
      }

      // Create the adapter context
      AdapterContext adapterCtx = new AdapterContext(ctx);
      
      // Now we need to load the metadata by this def class
      AbstractDefinition defImpl = (AbstractDefinition)defObj;
      defImpl.setName(sName);
      defImpl.setAdapterContext(adapterCtx);
      defImpl.loadFromMetadata(srcDefNode, appParams);

      // Now we need to create the data control
      mDbgLog.fine("Creating data control.");
      oracle.binding.DataControl dcImpl = defImpl.createDataControl();

      mDbgLog.fine("Creating generic data control.");
      AdapterDCService dc =
        new AdapterDCService(sName, defFileName, dcImpl, defImpl);
        
      return dc;
    }
    catch (Exception e)
    {
      mDbgLog.log(Level.SEVERE, "Exception: ", e);
      throw new oracle.jbo.JboException(e);
    }
    finally
    {
      mDbgLog.exiting(getClass().getName(),"createSession");
    }
  }

  //////////////////////////// Class Helper ////////////////////////////////////

  



}
