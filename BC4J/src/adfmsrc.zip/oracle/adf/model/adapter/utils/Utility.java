/*
 * @(#)Utility.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.utils;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import oracle.adf.model.utils.SimpleStringBuffer;

/**
 * Common utilities.
 *
 * @since 10.1.3
 */
public final class Utility 
{
  /**
   * Throws an exception if the flag is set to false. 
   */
  public static final void ASSERT(boolean flag) throws RuntimeException
  {
    if (!flag) throw new RuntimeException("Assertion Failure.");
  }
 
 /**
  * Search for a child Element given a parent element and the child name
  */
  public static Element getChildElement(
    Node parent,
    String  childNodeName
  )
  {
    NodeList listChld = parent.getChildNodes();
    int cnt = listChld.getLength();
    Node chld = null;
    for (int i = 0; i < cnt; i++)
    {
      chld = listChld.item(i);
      if(chld.getNodeName().equalsIgnoreCase(childNodeName) && 
         chld.getNodeType() == Node.ELEMENT_NODE)
        break;     
    }
    return (Element)chld;
  }
 
 /**
  * Search for the First child Node of a parent given the child name
  */
  public static Node getFirstChild(
    Node parent,
    String childName
  )
  {
    Node childNode = null;
    NodeList children = parent.getChildNodes();
    for(int i = 0; i < children.getLength(); i++)
    {
      childNode = children.item(i);
      if(childNode.getNodeName().equalsIgnoreCase(childName))
       return childNode;           
    }
    return null;
  }
  
  /**
   * Normalize a string to play by the JSR 227 DT rules. 
   * Cannot have java keywords or strings with '-' in when building the 
   * StructureDefinition. 
   * 
   * @param name The String to be normalized. 
   * 
   * @return The normalized string
   */
  public static String normalizeString(String name)
  {
    if ((name == null) || (name.length() == 0))
    {
      return name;
    }

    final String KEYWORD_RETURN = "return";
    final char UNDERSCORE = '_';  


    // Init cap all the java keywords that may appear in the 
    // JSR 227 structure def. I do not know if there is another
    // way of doing this without hardcoding any keyword that may
    // appear. 
    if(KEYWORD_RETURN.equals(name))
    {
      StringBuffer retBuf = new StringBuffer(name);
      char ch = name.charAt(0);   
      retBuf.setCharAt(0, (char)(ch - 32));
      return retBuf.toString();
    } 

    // Parse the string to replace unwanted characters    
    SimpleStringBuffer buff = new SimpleStringBuffer(name.length() + 4);
    // If the first character is digit, prefix with '_'.
    if (Character.isDigit(name.charAt(0)))
    {
      buff.append(UNDERSCORE);
    }

    int len = name.length();
    for (int i = 0; i < len; i++)
    {
      char ch = name.charAt(i);

      // Replace with '_' if not '_', letter, digit
      if ((ch != UNDERSCORE) && !Character.isLetterOrDigit(ch))
      {
        buff.append(UNDERSCORE);
      } 
      else
      {
        buff.append(ch);
      } 
    }

    return buff.toString();
  }  
  
  /**
   * Check if a given name is valid. A Name is valid iff
   * <PRE>
   * <ul>
   *   <li> It begins with a character </li>
   *   <li> The remaining characters are either alphanumeric i.e 
   *        <code>Character.isLetterOrDigit()</code> must return true,
   *         or is an underscore. </li>
   *   <li> The Last character must be alphanumeric. Names cannot 
   *        end with underscores. </li>
   * </PRE>
   * 
   * The caller is responsible for trimming any leading and trailing 
   * spaces in the parameter. 
   * 
   * @param name The input name which must be checked for compliance
   *             
   * @return <code>true</code> if the input name satisfies the conditions
   *         described above. <code>false</code> if any of the above 
   *         conditions fail.
   */
  public static boolean isNameValid(
   String name
  )
  {
    final char UNDERSCORE = '_';
    
    if(name != null)
    {
      // First character must be a letter. 
      if(!Character.isLetter(name.charAt(0)))
        return false;
      
      // get the chars in the String
      int length = name.length();  
      char[] chars = new char[length];
      name.getChars(0, length, chars, 0);
      
      // Last character must be alpha numeric.. 
      // cannot have names like "test___"
      if(!Character.isLetterOrDigit(chars[length - 1]))
       return false; 
      
      int i = 0;
      // Start from second chracter, only alpha numerics and 
      // underscore is allowed in the name. 
      // no other character can appear.
      // consider only till length - 2 since the last char has also
      // been tested.
      while( i++ < length - 2) 
       if(!(Character.isLetterOrDigit(chars[i]) || 
            chars[i] == UNDERSCORE))
       {
         return false;
       }
       
      return true;
    }
    return false;
  }
}
