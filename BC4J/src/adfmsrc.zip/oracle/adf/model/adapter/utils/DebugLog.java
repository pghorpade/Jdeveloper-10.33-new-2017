/*
 * @(#)DebugLog.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;

import oracle.jbo.common.Diagnostic;

import oracle.adf.model.utils.SimpleStringBuffer;


/**
 * A <code>DebugLog</code> object can be used to log debug messages.
 * <p>
 * A class that wants to use this class should create an instant by passing its
 * name.
 * <p>
 * Following is an example of typical use of this class.
 * <pre>
 * public class MyClass
 * {
 *   // Creating the logger Debug logger
 *   private DebugLog mDbgLog = new DebugLog(this);
 *
 *   ...
 *
 *   public void myMethod()
 *   {
 *     mDbgLog.startMethod("myMethod");
 *     mDbgLog.log("Start.");
 *
 *     try
 *     {
 *       ...
 *       mDbgLog.log("This is a debug log message.");
 *       ...
 *     }
 *     finally
 *     {
 *       mDbgLog.endMethod();
 *     }
 *   }
 *
 * }
 * </pre>
 */
public class DebugLog
{
  /**
   * Sets to force the logging to appear on the System.out. Used only for the
   * development time test purpose. 
   */
  public static boolean forceLog = false;

  private final String mClassName;
  private SimpleStack mMethodStack = new SimpleStack();

  /**
   * Creates a <code>DebugLog</code> object for a class.
   * @param obj Object for the class that uses this logger.
   */
  public DebugLog(Object obj)
  {
    mClassName = obj.getClass().getName();
  }

  /**
   * Creates a <code>DebugLog</code> object for a class.
   * @param name Name of the class that uses this logger.
   */
  public DebugLog(String name)
  {
    mClassName = name;
  }


  /**
   * Sets the current method name.
   * @param methodName Name of the method that is using the logger currently.
   */
  public void startMethod(String methodName)
  {
    mMethodStack.push(methodName);
  }

  /**
   * Ends the current method.
   */
  public void endMethod()
  {
    mMethodStack.pop();
  }

  /**
   * Logs a message.
   * @param msg Message to log.
   */
  public void log(Object msg)
  {
    if ((Diagnostic.getInstance() != null)
        && !Diagnostic.isOn()
        && !forceLog) 
    {
      return;
    }

    SimpleStringBuffer buf = new SimpleStringBuffer(100).append(mClassName);
    String methodName = mMethodStack.top();
    if (methodName != null)
    {
      buf.append(":").append(methodName);
    }

    buf.append(" => ");

    if (msg instanceof Map)
    {
      showMap(buf, (Map) msg);
    }
    else 
    {
      buf.append(msg);
    }

    if (forceLog)
    {
      System.out.println(buf.toString());
      return;
    }

    if (Diagnostic.getInstance() == null)
    {
      System.out.println(buf.toString());
    }
    else
    {
      Diagnostic.println(buf.toString());
    }
  }

  /**
   * Logs a message.
   * @param msg1 Message to log.
   * @param msg2 Message to log.
   */
  public void log(String msg1, String msg2)
  {
    log(new SimpleStringBuffer(100).append(msg1).append(msg2).toString());
  }


  /**
   * Shows the content of a map.
   */
  private void showMap(SimpleStringBuffer buf, Map map)
  {
    buf.append("Map [").append(map.size()).append("]");
    Iterator it = map.entrySet().iterator();
    while (it.hasNext())
    {
      Map.Entry entry = (Map.Entry) it.next();
      buf.append("{");
      buf.append((String)entry.getKey()).append(" = ");
      Object obj = entry.getValue();
      if (obj instanceof String)
      {
        buf.append((String)obj);
      }
      else if (obj instanceof Map)
      {
        showMap(buf, (Map)obj);
      }
      else
      {
        buf.append(obj);
      }
      buf.append("}");
    }
      
  }

  ///////////////////////////// Class Helper ///////////////////////////////

  /**
   * Simple non-synchronized stack.
   */
  private class SimpleStack
  {
    private List mItems = new java.util.ArrayList(10);

    void push(String item)
    {
      mItems.add(item);
    }

    String pop()
    {
      if (mItems.isEmpty()) return null;
      return (String) mItems.remove(mItems.size() - 1);
    }

    String top()
    {
      if (mItems.isEmpty()) return null;
      return (String) mItems.get(mItems.size() - 1);
    }
  }

  // Temporary
  static FileWriter __tfw = null;
  private static synchronized void write(String msg)
  {
     try
     {
       if(__tfw == null)
       {
         //__tfw = new FileWriter("/private1/armukher/work/repemd.log", true);
         __tfw = new FileWriter("d:\\temp\\ddc.log", true);
       }
       __tfw.write(msg + System.getProperty("line.separator"));
       __tfw.flush();
     }
     catch(Exception e)
     {
       throw new RuntimeException(e.toString());
       //System.out.println("Error creating file");
     }
  }


}
