/*
 * @(#)NodeAttributeHelper.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter.utils;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * Helper class to find value of attributes from an XML <code>Node</code>
 * object.
 */
public final class NodeAttributeHelper
{
  private NamedNodeMap mNamedMap;

  /** Creats an empty helper. */
  public NodeAttributeHelper()
  {
  }

  /** Creates the object from a <code>NamedNodeMap</code>. */
  public NodeAttributeHelper(NamedNodeMap namedMap)
  {
    mNamedMap = namedMap;
  }

  /** Sets the name node map. */
  public void setNamedNodeMap(NamedNodeMap namedMap)
  {
    mNamedMap = namedMap;
  }

  /**
   * Gets the value of the attribute.
   * @param name Name of the attribute.
   * @return The value.
   */
  public String getValue(String name)
  {
    if (mNamedMap == null) return null;
    Node nd = mNamedMap.getNamedItem(name);
    if (null == nd) return null;
    return nd.getNodeValue();
  }

  /**
   * Gets the value of the attribute.
   * @param name Name of the attribute.
   * @return The boolean value.
   */
  public boolean getValueBoolean(String name)
  {
    String val = getValue(name);
    if ("true".equalsIgnoreCase(val))
    {
      return true;
    }
    return false;
  }

  /**
   * Gets the value of the attribute.
   * @param name Name of the attribute.
   * @return The integer value.
   */
  public int getValueInt(String name)
  {
    String val = getValue(name);
    return Integer.parseInt(val);
  }

}
