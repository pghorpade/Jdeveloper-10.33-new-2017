/*
 * @(#)AbstractAdapter.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import org.w3c.dom.Node;

import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.DataControlDefinition;


/**
 * Abstract base class to adapt a data source into ADF design time.
 * <p>
 * Data control implementations should implement this class in order to provide
 * metadata information that the design time generates.
 * <p>
 * Application design time (e.g. JDeveloper or WorkPlace editor) supports 
 * creation of data controls by dragging and dropping a data source connection
 * to a drop location. The design time picks up the adapter that declares itself
 * capable of handling the data source dropped.
 * <p>
 * The design time will instantiate the concrete implementation of this 
 * class and call the {@link #initialize(Object,DTContext) initialize} method by passing  
 * the source object that can be used to get the information about the  
 * data source. Depending on the design time context, the source object can
 * be of different form. Adapter implementations must know the type of data that
 * they are expecting from the design time context.</p>
 * Once the adapter instance is created, the design time calls (@link #invokeUI()}
 * to ask the adapter to show any UI if required to gather information to define
 * a data control. Method {@link #getDefinition()} returns the data control 
 * definition.
 * 
 * Created: Tue Jul 13 12:16:40 2004
 *
 * @version 1.0
 */
public abstract class AbstractAdapter 
{
  
   
  /**
   * Initializes the adapter from a source object.
   * <p>
   * The source object can be different thing depending on the context of the 
   * design time that the adapter is used in. For JDeveloper, the object will
   * be a JDeveloper node, for workplace aplication it can be a connection
   * object.
   * <p>
   * Adapter implementations will check the <code>"ctx"</code> parameter to
   * get the current design time context. The source object will be used to 
   * extract the information for the data source. 
   * @param sourceObj Object that contains information about the data source 
   *            that will be used to define the data control.
   * @param ctx Current design time context.
   */
  public abstract void initialize(Object sourceObj, DTContext ctx);

  /**
   * Invlokes the UI at the design time. 
   * <p>
   * This method is a call back from the JDeveloper design time environment to
   * the adapters to bring up any UI if required to gather information about 
   * the data source they represent. 
   * 
   * @return false if the user cancels the operation. The default retrun value
   * is true.
   */
  public boolean invokeUI()
  {
    return true;
  }

  /**
   * Returns the definition of the created data control.
   * <P> 
   * The implementation of this method will extract the structure information
   * from the data source.
   */
  public abstract AbstractDefinition getDefinition();
  

  /**
   * Decides if the adapter can create a data control from the given source.
   * <p>
   * Adapter definition defines the object type that it can create a data 
   * control from. This method is called after an adapter is picked up for 
   * a source type for more precise decision. This method can decide if the 
   * adapter can create a data control for a perticular instance of the source
   * type that it can handle.
   * <p>
   * The default implementation always returns true.
   *
   * @return true if it can create a data control from the source.
   */
  public boolean canCreateDataControl(Object source)
  {
    return true;
  }
  
  /**
   * Hook to allow specific adapter implementations to configure a client
   * project.
   * 
  * @param sourceObj Object that contains information about the data source 
  *            that will be used to define the data control.
  * @param ctx Current design time context.
   */
  public void configureClientProject( Object sourceObj, DTContext ctx )
  {
  }

 
  ////////////////////////// Helper Methods /////////////////////////////////
  


}
