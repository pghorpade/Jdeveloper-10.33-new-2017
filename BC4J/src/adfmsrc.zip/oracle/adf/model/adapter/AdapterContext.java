/*
 * @(#).java
 *
 * Copyright 2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter;

import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;

import oracle.adf.model.BindingContext;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;


/**
 * Defines the context for an adapter.Adapters can get the information like
 * request, connection informstion etc from this context.
 * <p>
 * Design time context is derived from this context class. Design time 
 * context stores or overrides information that are relevant for the design time
 * only.
 *
 * @version 1.0
 * @see oracle.adf.model.adapter.DTContext
 */
public class AdapterContext extends HashMap
{
  //============================================================================
  // Public Keys
  //============================================================================

  public static final String HTTP_REQUEST = BindingContext.HTTP_REQUEST;
  public static final String HTTP_RESPONSE = BindingContext.HTTP_RESPONSE;

  /** Name of the connection file. */
  public static final String CONNECTION_FILE_NAME = "connections.xml";

  /** Context factory impl name. */
  public static final String INITIAL_CONTEXT_FACTORY =
    "oracle.adf.share.jndi.InitialContextFactoryImpl";

  /**
   * Key to extract connection information from a parameter map.
   * <p>
   * Adapters can use connection information to access a data source. The 
   * adapter definition contains the name of the connection used by the adapter.
   */
  public static final String CONNECTION_INFO   = "connection_info";


  //============================================================================
  // Implementation
  //============================================================================

  private BindingContext mBindingCtx = null;

  // logger for this context
  private ADFLogger mLogger = null;



  ////////////////////////////// Static ////////////////////////////////////////
  /**
   * Gets the default static instance of the adapter context.
   */
  private static AdapterContext sCtx = null;
  public static AdapterContext getDefaultContext()
  {
    if (sCtx == null)
    {
      sCtx = new AdapterContext();
    }
    return sCtx;
  }


  /**
   * Sets the current design time implementation of this class.
   */
  public static void setCurrentContextImpl(DTContext impl)
  {
    sCtx = impl;
  }


  ////////////////////////////////// Constructors //////////////////////////////

  /** Creates an empty context. */
  public AdapterContext()
  {
    super(10);
  }     

  /** 
   * Creates an context from a binding context. 
   * The common runtime will use this constructor to create the execution 
   * context.
   * @param ctx The binding context for the application.
   */
  public AdapterContext(BindingContext ctx)
  {
    this();
    mBindingCtx = ctx;
  }     


  /////////////////////////////// Public Methhods //////////////////////////////

  /**
   * Gets the context for the connections.
   * Connections that are created at the design time can be retrieved by looking 
   * up the conext returned by this method.
   * The connection context will be created from the ADFContext. 
   * @return the read-only initial context.
   */
  public Context getConnectionContext() throws Exception
  {
    return ADFContext.getCurrent().getConnectionsContext();    
  }

  /**
   * Gets the binding context associated with this context.
   * @return the binding context. If not available returns null.
   */
  public BindingContext getBindingContext()
  {
    return mBindingCtx;
  }

  /**
   * Returns the logger for this context.
   */
  public ADFLogger getLogger()
  {
    if (mLogger == null)
    {
      mLogger =
        (ADFLogger) ADFLogger.createADFLogger("oracle.adf.model.adapter");
    }

    return mLogger;
  }
}
