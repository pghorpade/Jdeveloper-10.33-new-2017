/*
 * @(#)AdapterDataControlDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.HashMap;
import com.sun.java.util.collections.ArrayList;

import java.util.logging.Level;
import oracle.xml.parser.v2.XMLAttr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

import oracle.xml.parser.v2.XMLDocument;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.DefElementImpl;
import oracle.jbo.mom.xml.DefNode;
import oracle.jbo.uicli.mom.JUTags;

import oracle.adf.model.binding.DCDataControlDef;
import oracle.adf.share.logging.ADFLogger;
import java.util.logging.Handler;


/**
 * Definition class for adapter created data controls.
 * <p>
 * This class loads the ddata control definition from an XML definition node.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class AdapterDataControlDef extends DCDataControlDef 
{
  /**
   * Name of the data control tag in the dcx file. 
   */
  public static final String ADAPTER_DC = "AdapterDataControl";

  /** 
   * Data control definition attribute to define the implementation 
   * class name. 
   */
  //public static final String ATTR_IMPL_CLASS = "ImplClass";

  /** 
   * Data control definition attribute to define the definition class
   * that can create the data control. 
   */
  public static final String IMPL_DEF = "ImplDef";

  /** "Source" node to store the metadata for the data controls. */
  public static final String SOURCE = "Source";

  private ADFLogger mDbgLog = AdapterContext.getDefaultContext().getLogger();


  //////////////////////////  Constructors //////////////////////////////////
  /**
   * Creates a new <code>AdapterDataControlDef</code> instance. This will 
   * let the framework to create this instance from a definition class name.
   */
  public AdapterDataControlDef()
  {
  }


  //////////////////////////// Public Methods //////////////////////////////

  /**
   * Returns null so that the definition class is used to load the definition.
   */
  public String getSubType()
  {
    return null;
  }

  /**
   * Initializes the object from a collection of data.
   */
  public void init(HashMap initValues)
  {
    super.init(initValues);
    put(JUTags.DesignTimeClass, 
        "oracle.adf.dt.datacontrols.JUDTAdapterDataControl");
  }


  /**
   * Retrieves the definition from an XML node.
   * @param nodeDef the data control definition as an XML node.
   */
  public void retrieveFromNode(Node nodeDef)
  {
    try
    {      
      mDbgLog.entering(getClass().getName(),"retrieveFromNode");

      // Create a DefElement for the given node.
      mDbgLog.fine("Creating a DefElement from the node.");
      DefElementImpl defEl = makeDefElement(nodeDef);
      if (defEl == null) return;

      // The def element is set now. We'll call the other method to load it.
      mDbgLog.fine("Retrieving info from the DefElement created.");
      HashMap map = new HashMap(10);
      retrieveFromXML(defEl, map);

      // Now load the def from the map
      init(map);
    }
    catch (Exception e)
    {
      mDbgLog.info("Failed to retrieve definition: " + e.getLocalizedMessage());
    }
    finally
    {
      mDbgLog.exiting(getClass().getName(), "retrieveFromNode");
    }
    
  }

  //////////////////////// Overridden methods ///////////////////////////////// 
  /**
   * Retrieves the attributes of the data control from an XML definition. This 
   * method puts the info read from the XML definition into the map supplied.
   *
   * @param xmlElement XML element defines the data control metadata.
   * @param valueTab a <code>HashMap</code> value to put the read info.
   */
  protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
  {
    super.retrieveFromXML(xmlElement, valueTab);
    //readXMLString(xmlElement, ATTR_IMPL_CLASS, valueTab);
    readXMLString(xmlElement, IMPL_DEF, valueTab);
  }

  
  /**
   * Loads child definitions from the data control's XML definition.
   *
   * @param xmlElement contains the XML definition of the data control.
   */
  protected void loadChildrenFromXML(DefElement xmlElement)
  {
    super.loadChildrenFromXML(xmlElement);
    try
    {      
      mDbgLog.entering(getClass().getName(),"loadChildrenFromXML");

      mDbgLog.fine("Loading SOURCE definition.");
      // Get the source node
      DefElement source = xmlElement.findChildElement(SOURCE);
      
      if (source == null)
      {
        mDbgLog.info("No 'Source' is defined for the data control.");
        return;
      }
      
      // Get the Node object of the def and store it.
      Node nd = getNodeFrom(new XMLDocument(), source);
      put(SOURCE, nd);
    }
    catch (Exception e)
    {
      mDbgLog.log(Level.SEVERE, "Exception => ", e);
    }
    finally
    {
      mDbgLog.exiting(getClass().getName(), "loadChildrenFromXML");
    }
  }


  ////////////////////////// Class Helpers ///////////////////////////////////

  /**
   * Creates a <code>DefElement</code> from an XML <code>Node</code>.
   */
  private DefElementImpl makeDefElement(Node nodeDef) throws Exception
  {
    if (nodeDef == null) return null;

    // Create a DefElement for the given node.
    DefElementImpl defEl = new DefElementImpl(nodeDef.getNodeName());

    // Get the attributes and set it.
    NamedNodeMap attribs = nodeDef.getAttributes();
    int len = attribs.getLength();
    for (int i = 0; i < len; i++)
    {
      Node nd = attribs.item(i);
      String ns = nd.getNamespaceURI();
      if ((ns != null) && (ns.length() > 0))
      {
        defEl.setAttributeNS(ns, nd.getNodeName(), nd.getNodeValue());
      }
      else
      {
        defEl.setAttribute(nd.getNodeName(), nd.getNodeValue());
      }
    }

    // Add the child nodes
    NodeList children = nodeDef.getChildNodes();
    len = children.getLength();
    for (int i = 0; i < len; i++)
    {
      Node nd = children.item(i);
      defEl.appendChild(nd);
    }

    return defEl;
  }

  /**
   * Gets the <code>Node</code> from the <code>DefElement</code> object.
   */
  private Node getNodeFrom(XMLDocument doc, DefElement def)
  {
    // Get the namespace from the def element 
    String ns = def.getNamespaceURI();
    if ((ns != null) && (ns.length() == 0))
    {
      ns = null;
    }

    // Create the node to return
    Element elRet = doc.createElementNS(ns, def.getElementName());

    //
    // set the attributes 
    //

    // load the attributes of the def
    ArrayList defAttrs = def.getAttrsList(); 
    int cnt = defAttrs.size();
    for (int i = 0; i < cnt; i++)
    {
      /** this is commented out because DefElement implementation is rolled back
       * Use XMLAttr instead.
       */              
      //  !JWETHERB to avoid CCE's, enabling compatibility with both elem types
      final Object obj = defAttrs.get(i);
      if ( obj instanceof DefNode )
      {
        DefNode nd = (DefNode)obj;
        String name = nd.getNodeName();
        String val = nd.getNodeValue();

        // add the attribute to the DOM node
        elRet.setAttribute(name, val);
      }
      else
      {
        XMLAttr nd = (XMLAttr)obj;
        String name = nd.getName();
        String val = nd.getValue();

        // add the attribute to the DOM node
        elRet.setAttribute(name, val);
      }
    }

    // Loop through the children of the def element and load them as well.
    ArrayList lst = def.getChildrenList();
    cnt = lst.size();
    for (int i = 0; i < cnt; i++)
    {
      DefElement nd = (DefElement)lst.get(i);
      // Get the def elements with the same name
      ArrayList listChild = def.getChildrenList(nd.getNodeName());
      int cntChild = listChild.size();
      for (int j = 0; j < cntChild; j++)
      {
        DefElement chldDef = (DefElement)listChild.get(j);
        
        Node chldNode = getNodeFrom(doc,chldDef);
        elRet.appendChild(chldNode);
      }
    }


    return elRet;
  }


}
