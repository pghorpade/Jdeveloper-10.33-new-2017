/*
 * @(#)MetaDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.Map;
import java.util.Collections;

import oracle.binding.meta.DataControlDefinition;

/**
 * This is a helper class that helps to create and modify data control 
 * definitions. It provides an abstract layer on top of different systems that
 * handles data control metadata differently. 
 * <p>
 * Different system registers handler to this calss to handle the data control 
 * metadata. The implementation of this class deligates he calls to the 
 * underlying handlers.
 * <p>
 * For a given application context, this class can create the required metadata 
 * for the data controls. The application contexts identify the handler that 
 * creates the metadata. Applications register their respective handlers to this
 * class.
 * <p>
 * To create an instance of this class, the caller needs to pass the context to
 * indicate the underlying systems. If a handler for the context is registered,
 * the method calls will be deligated to that handler.
 * 
 * @see oracle.adf.model.adapter.ContextHandler
 * @since 10.1.3
 */ 
public class MetaDef
{
  // Supported contexts
  /** JDeveloper context name. */
  public static final String CTX_JDEVELOPER = "jdev";
  
  /** Workplace context name. */
  public static final String CTX_WORKPLACE = "wp";


  /**
   * Map to store the handlers for different context names.
   */
  private static Map mHandlers = 
    Collections.synchronizedMap(new java.util.HashMap());

  // Name of the context
  private String mCtxName;
  
  // map to store the context specific properties 
  private Map mProperties = new java.util.HashMap(5);

  //////////////////////////////// Constructors ////////////////////////////////

  /**
   * Creates an instance for a given application context. 
   * @param ctxName name of the context.
   * 
   * @see #CTX_JDEVELOPER
   * @see #CTX_WORKPLACE
   */
  public MetaDef(String ctxName)
  {
    mCtxName = ctxName;
  }

  /////////////////////////////// Public Methods //////////////////////////////
 
  /**
   * Sets the property to pass to the underlying context handlers. Caller may 
   * set properties to be passed to the underlying context handlers. 
   * <p>
   * The callers must know the right property name that the underlying context
   * understands.
   * 
   * @param key property name.
   * @param value value of the property.
   */
  public void setProperty(String key, Object value) 
  {
    mProperties.put(key, value);
  }
 
  /**
   * Creates a data control metadata from the data control definition.
   * The metadata gets serialized by the registered application context handler.
   *
   * @param def the data control definition.
   * @exception AdapterException is thrown if fails to create the metadata.
   */
  public void createDataControl(AbstractDefinition def)
  {
    try
    {
      // get the handler
      Object handler = mHandlers.get(mCtxName);
      if (handler != null)
      {
        ((ContextHandler) handler).createMetaDC(def, mProperties);
      }
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Gets the definition of the data control specified by the name.
   * This method calls the registered context handler to get the definition.
   *
   * @param name name of the data control.
   * @return definition of the data control specified by the given name.
   *         If the data control doesn't exist, it returns null.
   */
  public DataControlDefinition getDataControlDefinition(String name)
  {
    // get the handler
    Object handler = mHandlers.get(mCtxName);
    if (handler != null)
    {
      return ((ContextHandler) handler).getDefinition(name, mProperties);
    }

    return null;
  }

  /**
   * Refreshes the data control's metadata from a given definition.
   * <p>
   * It updates the data control's definition in the data control registry
   * file. It doesn't update the structure defintion of the output as
   * serialized as part of data control metadata.
   */
  public void refreshDefinition(AbstractDefinition def)
  {
    try
    {
      // get the handler
      Object handler = mHandlers.get(mCtxName);
      if (handler != null)
      {
        ((ContextHandler) handler).refreshDCDef(def, mProperties);
      }
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Refreshes the data control's structure definition.
   * <p>
   * It updates the structure defintion of the output as serialized as 
   * part of data control metadata. This method doesn't update the data control
   * metadata in the data control registry.
   * <p>
   * This method should be called only to refresh the structure definition 
   * of the output of the data control.
   */
  public void refreshStructureDefinition(AbstractDefinition def)
  {
    try
    {
      // get the handler
      Object handler = mHandlers.get(mCtxName);
      if (handler != null)
      {
        ((ContextHandler) handler).refreshDCStructureDef(def, mProperties);
      }
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }



  /**
   * Registers a handler for an application context.
   * @param ctxName context name.
   * @param handler the class name for the handler.
   * @throws AdapterException if fails to load the handler class.
   */
  public static void registerHandler(String ctxName, ContextHandler handler)
  {
    mHandlers.put(ctxName, handler);
  }



}

