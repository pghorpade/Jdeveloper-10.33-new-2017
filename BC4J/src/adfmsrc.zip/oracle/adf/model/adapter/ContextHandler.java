/*
 * @(#)ContextHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter;

import java.util.Map;

import oracle.binding.meta.DataControlDefinition;

/**
 * Context handlers creates and stores data control metadata. Applications 
 * define their context handlers to store and modify data control metadata from
 * a data control definition.
 *
 * Created: Wed Dec 08 19:05:10 2004
 *
 * @see oracle.adf.model.adapter.MetaDef
 * @since 10.1.3
 */
public interface ContextHandler 
{
  /**
   * Creates a data control metadata from its definition.
   * <p>
   * It create a metadata that defines the data control along with the 
   * definitions representing the output structuires. This method
   * serializes the metadata represented by various files for the
   * data control definition.
   * <p>
   * If the data control with the same name exists, this will overwrite
   * the existing data control with the new definition and also
   * overwrite the serialized structure definition of
   * the output data. This may result to a loss of decoration that the 
   * user may have made on the structure definitions.In case of overwrite,
   * this method calls the data control definition's
   * <code>isStructureDirty()</code> method with the supplied flag
   * to true. If the method returns false, it wont overwrite
   * the structure.
   *
   * @param def the data control definition.
   * @param properties any properties set by the caller that may be used by the
   *        context handler. 
   * @exception Exception if fails to store the metadata.
   */
  public void createMetaDC(AbstractDefinition def, Map properties) 
  throws Exception;

  /**
   * Returns the data control definition for a given data control name.
   * @param name of the data control.
   * @param properties any properties set by the caller that may be used by the
   *        context handler. 
   * @return the data control definition for the given name. If the data control 
   *         with that name is not available it returns null.
   */
  public DataControlDefinition getDefinition(String name, Map properties);

  /**
   * Refreshes the data control's metadata from the given definition.
   * It updates the data control's definition in the data control registry
   * file. It doesn't update the structure defintion of the output as
   * serialized as a part of data control metadata.
   *
   * @param def the data control definition.
   * @param properties any properties set by the caller that may be used by the
   *        context handler. 
   * @exception Exception if fails to refresh the structures.
   */
  public void refreshDCDef(AbstractDefinition def, Map properties) 
  throws Exception;

  /**
   * Refreshes the data control's structure defintion of the output as
   * serialized as a part of data control metadata. It doesn't update the data
   * control metadata in the data control registry file.
   *
   * @param def the data control definition.
   * @param properties any properties set by the caller that may be used by the
   *        context handler. 
   * @exception Exception if fails to refresh the structures.
   */
  public void refreshDCStructureDef(AbstractDefinition def, Map properties) 
  throws Exception;

}
