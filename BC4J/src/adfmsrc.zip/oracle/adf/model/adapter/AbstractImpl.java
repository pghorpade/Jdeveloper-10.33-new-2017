/*
 * @(#)AbstractImpl.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

import org.w3c.dom.Node;

import oracle.binding.OperationBinding;
import oracle.binding.OperationInfo;
import oracle.binding.meta.Definition;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.adapter.dataformat.StructureDef;

import oracle.adf.model.BindingContext;
import oracle.adf.model.generic.StructureDefImpl;
import oracle.adf.model.adapter.dataformat.AttributeDef;
import oracle.adf.model.adapter.dataformat.AccessorDef;
import oracle.adf.model.binding.DCUtil;

  
/**
 * An abstract base class for all metadata driven data control implementations.
 * <p>
 * Data Controls implementations, child classes of this abstract class, must 
 * also implement any of the Data Control interfaces defined by the JSR 227 
 * specification. The data control interfaces are available under 
 * "oracle.binding" package.
 *
 * @since 10.1.3
 */
public abstract class AbstractImpl
{

  //===========================================================================
  // Public Keys
  //===========================================================================

  /** 
   * Name of the method to create the adapter instance. 
   * Data control implementations should look for this method name from the 
   * <code>OperationBinding</code> passed to the <code>invokeAction</code>
   * call.
   */
  public static final String METHOD_CREATE = "loadData";

  /** 
   * Name of the method to execute the adapter instance. 
   * Data control implementations should look for this method name from the 
   * <code>OperationBinding</code> passed to the <code>invokeAction</code>
   * call.
   */
  public static final String METHOD_EXECUTE = "adapter_execute";

  /** 
   * Key name for the sort criteria set for the data control. Sort criteria 
   * are passed to the data control's <code>invokeOperation</code> method via
   * the <code>MethodOperationBinding</code> object. 
   * Implementation may use <code>getSortCriteria</code> helper method to
   * get the sort criteria.
   */
  public static final String SORT_CRITERIA = "__sort_criteria__";


  //===========================================================================
  // Class variables
  //===========================================================================

  /**
   * Name of the data control.
   */
  protected String mName;
  

  // Definition parameters defined for the data control.
  private Map mDefParams = new java.util.HashMap(5);
  
  // Data control definition.
  private AbstractDefinition mDCDef;

  // Structure def of the data in the jsr 227 specified format.
  private StructureDefinition mStructDef = null;

  // adapter context
  private AdapterContext mAdapterCtx = null;


  //===========================================================================
  // Overridable methods
  // The framework calls these methods to get further information from the data 
  // control implementations to take any decision.
  //===========================================================================

  /**
   * Determines if a method should be reexecuted. 
   * <p>
   * If the parameter value of a method changes, the framework executes the 
   * method. If the parameter values are not changed or the method has no
   * parameters, the framework asks if the method should be reexecuted or the
   * values that are already fetched before can be used.
   * @return the default implementation returns false.
   */
  public boolean shouldReexecuteOperation(OperationInfo operationInfo)
  {
    return false;
  }




  //===========================================================================
  // Public Methods 
  // Implementations can use these methods to get the framework support.
  //===========================================================================


  //////////////////////////// Name of the data control ///////////////////////
  /**
   * Sets the name of the data control implementation.
   */
  public final void setName(String name)
  {
    mName = name;
  }


  ///////////////////////////// Sort criteria /////////////////////////////////

  /**
   * Extracts and returns the sort criteria, if any, defined for the
   * method action.
   * @param action the operation for which the sort criteria can be defined.
   * @return the sort criteria defined for the operation.
   */
  public final AdapterSortCriteria[] getSortCriteria(OperationBinding action)
  {
    Map params = action.getParamsMap();
    if (params != null)
    {
      return (AdapterSortCriteria[]) params.get(SORT_CRITERIA);
    }
    return null;
  }

  /////////////////////////// Parameters //////////////////////////////////////

  /**
   * Returns the name of the parameters set to this data control instance.
   */
  public final String[] getParameterNames()
  {
    String[] names = new String[mDefParams.size()];
    
    Iterator it = mDefParams.keySet().iterator();
    for (int i = 0; i < names.length; i++)
    {
      names[i] = (String) it.next();
    }

    return names;
  }
  
  /**
   * Gets the value of an existing definition parameter.
   *
   * @param name Name of the parameter.
   * @return value of the parameter. If the parameter is not available, it 
   *         returns null.
   */
  public final String getParameterValue(String name)
  {
    return (String) mDefParams.get(name);
  }

  /**
   * Sets the value of an existing definition parameter.
   *
   * @param name Name of the parameter.
   * @param val Value of the parameter.
   */
  public final void setParameterValue(String name, String val)
  {
    mDefParams.put(name, val);
  }

  /**
   * Adds a parameter to the data control.
   * @param name name of the parameter.
   * @param val value of the parameter.
   */
  public final void addParameter(String name, String val)
  {    
    mDefParams.put(name, val);
  }


  /////////////////////////// Structure Defs //////////////////////////////////

  /**
   * Sets the structure definition of the data for this data control.
   */
  public final void setStructureDef(StructureDefImpl def)
  {
    mStructDef = convertStructureDef(def, new HashMap(10));
  }

  /**
   * Gets the structure defintion for the data for this data control.
   */
  public final StructureDefinition getStructureDef()
  {
    return mStructDef;
  }

  //////////////////////////// Abstract Defs //////////////////////////////////

  /**
   * Sets the definition of this data control.
   */
  public final void setDefinition(AbstractDefinition def)
  {
    mDCDef = def;
  }

  /**
   * Gets the data control definition.
   */
  public final AbstractDefinition getDefinition()
  {
    return mDCDef;
  }


  //////////////////////////// Method Invoke related //////////////////////////

  /**
   * Processes result created by the adapter's invokeOperation call. 
   * <p>
   * ADFm expects the result of a method call should be set to the binding
   * context in a way that the framework can retrieve it according to the bind
   * path created in the page definiion. This method takes the result and sets
   * it properly in thge binding context properly.
   * <p>
   * Adapters should call this method from their <code>invokeOperation</code>
   * call after fetching the data from the data source.
   *
   * @param result returned result of the method call.
   * @param bindingContext the binding context.
   * @param action action that is called on the data control.
   */
  public final void processResult(
    Object result, 
    Map bindingContext, 
    OperationBinding action)
  {
      // put the result into the bindig context 
      // check for non-null results. One way operations / void operations 
      // do not have any result to be put in the binding path. 
      
      //sjv fix bug 4674868 - void methods do not have return names. So check for returnname instead of 
      //return values as methods that return values can return null and that should be updated on the cache.
      if ((action != null) && (action.getOperationInfo() != null && action.getOperationInfo().getReturnName() != null))
        //(result != null))
      {
         //bindingContext.put(action.getOperationInfo().getReturnName(), 
         //                   result);
         DCUtil.putValueInPath((oracle.adf.model.BindingContext)bindingContext, action.getOperationInfo().getReturnName(), result);
      } 
  }



  ////////////////////////// Adapter Context //////////////////////////////////

  /**
   * Returns the current adapter context.
   */ 
  public final AdapterContext getAdapterContext()
  {
    if (mDCDef != null)
    {
      return mDCDef.getAdapterContext();
    }

    return null;
  }



  //===========================================================================
  // Package scoped methods
  //===========================================================================


  /**
   * Sets the parameters defined for this data control instance.
   * 
   * @param params Definition parameters defined for the data control.
   */
  final void setParameters(Map params)
  {
    mDefParams.putAll(params);
  }




  //===========================================================================
  // Helper methods
  //===========================================================================


  /**
   * Converts a runtime structure def to a jsr 227 defined structure.
   * [Note: the common RT should support jsr 227 natively. Until that happens
   * adapters get the structure def converted from the RT objects.]
   */
  private StructureDef convertStructureDef(StructureDefImpl rtStruct, Map visited)
  {
    if (rtStruct == null) return null;

    String strName = rtStruct.getName();
    StructureDef structDef = new StructureDef(strName);

    // Adding the newly created structure into the visited list
    visited.put(strName, structDef);

    // get the attributes
    oracle.jbo.AttributeDef[] rtAttrs = rtStruct.getAttributeDefs();
    if (rtAttrs != null)
    {
      for (int i = 0; i < rtAttrs.length; i++)
      {
        AttributeDef attrDef = new AttributeDef(rtAttrs[i].getName(),
          structDef,
          rtAttrs[i].getJavaType().getName(),
          (rtAttrs[i].getUpdateableFlag() == oracle.jbo.AttributeDef.READONLY),
          rtAttrs[i].isPrimaryKey());
      
        // Add the attribute to the def
        structDef.addAttribute(attrDef);
      }
    }
    
    // And the accessors
    StructureDefImpl rtAcc[] = rtStruct.getAccessors();
    if (rtAcc != null)
    {
      for (int i = 0; i < rtAcc.length; i++)
      {
        // Create the structure def for this accessor
        String accStrName = rtAcc[i].getName();

        // Lets see if this structure is already availabe
        // (circular definition case).
        StructureDef accStruct = (StructureDef) visited.get(accStrName);
        // if not created yet...
        if (accStruct == null)
        {
          accStruct = convertStructureDef(rtAcc[i], visited);
        }
        if (accStruct != null)
        {
          AccessorDef accDef = new AccessorDef(rtAcc[i].getName(),
                                               structDef,
                                               accStruct,
                                               rtAcc[i].isCollection());
          structDef.addAccessor(accDef);
        }
      }
    }
    
    return structDef;
  }


}


 
