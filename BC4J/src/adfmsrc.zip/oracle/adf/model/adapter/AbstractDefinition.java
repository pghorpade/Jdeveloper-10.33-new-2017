/*
 * @(#)AbstractDefinition.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.Map;
import java.util.Hashtable;

import org.w3c.dom.Node;

import oracle.binding.DataControl;
import oracle.binding.meta.Definition;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.StructureDefinition;

/**
 * Definition of a data control instance.
 * <p>
 * There are several ways that this class can be generated.
 * <ul>
 * <li><B>Created by Adapters</B>: 
 * Data control adapters can create the definition for the data controls from
 * a data source that it can handle. In design time (e.g. JDeveloper), adapters
 * are invoked to react in responce to the user actions (e.g. drag and drop) to
 * create data control definition. 
 * <li><B>Created by "File-New" wizard</B>: 
 * An data control implementation may provide way to create a data control from
 * a menu selection. In this case the wizard creates this class for the data 
 * control it creates.
 * </li>  
 * <li><B>Created by Framework</B>: 
 * The framework will create this class to create a data control from the 
 * data control metadata. The framework creates this class from the class name
 * and calls {@link #loadFromMetadata(Node,Map) load} to load from the metadata definition.
 * Once the definition is loaded, it calls the {@link #createDataControl()} to
 * create the data control instance.
 * </li>  
 * </ul>
 * The implementation of this class <b>MUST</b> have a default constructor.
 * <p>
 * <b>Note:</b> When the definition loaded at the runtime, runtime sets the name 
 * of the definition as stored in the metadata. The implementation of this
 * class MUST use {@link #getName()} to get the name of the definition.
 *
 * @see oracle.adf.model.adapter.AbstractAdapter
 */
public abstract class AbstractDefinition implements DataControlDefinition
{
   public static int CACHE_TO_SOURCEPATH = 0;
   public static int CACHE_TO_CLASSPATH  = CACHE_TO_SOURCEPATH + 1;
   public static int DONT_CACHE = CACHE_TO_CLASSPATH + 1;
   
  // Name of the DC, set by the adapter def at RT
  private String mName;

  // Storing properties for the definition.
  // alai 8/1/05: changed from HashMap to Hashtable to support getProperties method
  private Hashtable mProps = new java.util.Hashtable(10);

  // The adapter context.
  private AdapterContext mCtx;

  // flag to indicate if the project needs to be compiled when a data control
  // is created.
  private boolean mRequiredCompileProjectOnCreate = false;

  //========================================================================
  // Overridable Methods 
  //========================================================================

  /**
   * Returns the element that defines the metadata for the data control.
   * 
   * @return a <code>Node</code> that defines the metadata for this instance.
   *         This metadata will be used at the runtime to fetch data from the
   *         data source. 
   */
  public abstract Node getMetadata();
  
  /**
   * Gets the structure definition of the output data.
   * @return Definition of the output data structure.
   */
  public abstract StructureDefinition getStructure();

  /**
   * Type of definition
   * @return TYPE_DATACONTROL. All subclasses are definitions for Data controls.
   */ 
  public int getDefinitionType()
  {
     return TYPE_DATACONTROL;
  }

   public int getCachingMode()
   {
       return CACHE_TO_SOURCEPATH;
   }
   
  /**
   * Loads the definition from a metadata <code>Node</code>.
   * @param node the metadata node. It can be null if no metadata is defined. 
   * @param params context parameters.
   */
  public abstract void loadFromMetadata(Node node, Map params);

  /** 
   * Creates an instance of data control generated from the metadata definition.
   *
   * @return the data control instance.
   */
  public abstract DataControl createDataControl();
  
  /**
   * Returns the name of the data control.
   */
  protected abstract String getDCName();




  //========================================================================
  // Overridable Methods 
  //========================================================================

  /**
   * Returns the name of the corresponding adapter type, if any. The framework
   * calls this method to find out a corresponding adapter for this definition.
   *
   * @return name of the corresponding adapter that matches this definition.
   *         If there is no adapter defined for this type, the method returns
   *         null. The default implementation returns null.
   * @see oracle.adf.model.adapter.AdapterDefinition
   */
  public String getAdapterType()
  {
    return null;
  }

  /**
   * Returns the class name of the definition class that will load the metadata
   * that describes the data control.
   * <p>
   * The framework will call this method at the design time to store the 
   * definition class name that will load the metadata.
   * The returned class must be a derived class of this astract class. The 
   * default implementation returns the class name of this instance only. The 
   * derived class needs to override this only if the definition class that may 
   * load a metadata is different than this instance.
   */
  public String getDefClassName()
  {
    return this.getClass().getName();
  }
  
  /**
   * Indicates if the structure definition returned by {@link #getStructure()}
   * should be serialized. 
   * <p>
   * If this method returns "true", the structure
   * definitions get serialized at the design time and get loaded at the 
   * runtime by the framework.
   * <p>
   * The default implementation return "true".
   * @deprecated use 
   */
  public boolean shouldStoreStructureDefinition()
  {
    return true;
  }

  /**
   * Indicates whether the definition delegates to the framework the task of
   * deserializing its StructureDefinition (for example, from bean .xml 
   * files on disk).
   * @return by default true.
   */
  public boolean usePersistedStructure()
  {
    return true;
  }

  /** 
   * The implementation should return true if the structure of the back end data
   * is changed. The framework will not call {@link #getStructure()} is this 
   * method returns false. 
   * @param refresh flag to indicate if the refresh is requested for the 
   * structure.
   * @return true if the implementation decides that the structure of the 
   * data should be generated. The default implementation always returns false. 
   */ 
   public boolean isStructureDirty(boolean refresh) 
   { 
     return false; 
   } 
  
  /**
   * Returns the parameters that are defined for the data control metadata.
   * <p>
   * The implementation should override this method if the definition uses
   * parameters. The default implementatiaon returns null.
   */
  public ParameterDefinition[] getParameters()
  {
    return null;
  }

  /**
   * Gets the name of the data control. 
   * <p>
   * At runtime, the name is set from the metadata information. At 
   * design time it calls {@link #getDCName()} to get the name of this
   * definition.
   */
  public String getName()
  {
    if (mName == null)
    {
      mName = getDCName();

      // ADF doesn't allow ID to have "." in it for EL to work properly
      // we should check if the data controls create an id like that, 
      // we'll substitute with "_".
      mName = mName.replace('.', '_');
    }

    return mName;
  }


  /**
   * Indicates if the adapter support things like sorting, transaction etc. 
   * Adapter data control definition should overwrite this method to provide 
   * the info specific to the data control instance.
   *
   * @param flag one of the values defined in 
   *        {@link oracle.adf.model.meta.DataControlDefinition}.
   *
   * @return boolean true if supported. The default implementation returns 
   *         "false" for all flags.
   */
  public boolean isSupported(String flag)
  {
    return false;
  } 


  /**
   * Data controls which do not already have their own package structure
   * need to use a default package.  Bean-based data controls, or others
   * whose names embed their package structure, should override this to
   * return false.
   *  
   * @return true by default.
   */
  public boolean assignDefaultPackage()
  {
    return true;
  }

  /**
   * Indicates if the project needs to be compiled when a data control is 
   * created from this definition.
   * <p>
   * <b>Note:</b>
   * If the data control create is invoked from within a UI operation (e.g. you
   * are invoking creation of data control while responding to a property change
   * action of the data control metadata), this method must return false.
   * A data control can be created by calling the method 
   * <code>createDataControl</code> on class {@link oracle.adf.model.adapter.MetaDef}.
   * @return by default it returns false.
   */
  public boolean shouldCompileProjectOnCreate()
  {
    return mRequiredCompileProjectOnCreate;
  }

  public Definition getDefinitionParent()
  {
    return null;
  }

  public String getFullName()
  {
    return getName();
  }
  



  //========================================================================
  // Public Methods 
  //========================================================================

  /**
   * Stores a property value.
   */
  public final void setProperty(String name, Object val)
  {
    mProps.put(name, val);
  }

  /**
   * Gets a property value.
   */
  public final Object getProperty(String name)
  {
    return mProps.get(name);
  }

  /**
   * Gets a hashtable of all properties. 
   * @return properties
   */ 
  public Hashtable getProperties()
  {
    return mProps;
  }


   /**
   * Sets the name of the definiiton.
   */
  public final void setName(String name)
  {
    mName = name;
  }

  /**
   * Sets the adapter context. 
   */
  public final void setAdapterContext(AdapterContext ctx)
  {
    mCtx = ctx;
  }

  /**
   * Gets the adapter context.
   */
  public final AdapterContext getAdapterContext()
  {
    return mCtx;
  }

  /**
   * Sets the flag to indicate the requirement of compilation when a data 
   * control will be created from this definition.
   */
  public void setCompileProjectOnCreate(boolean flag)
  {
    mRequiredCompileProjectOnCreate = flag;
  }

}
