/*
 * @(#)AdapterException.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.ResourceBundle;

import oracle.jbo.JboException;


/**
   * <code>AdapterException</code> is thrown from the adapter common runtime layer.
 */
public final class AdapterException extends JboException
{
  public static final String DCA_PRODUCT_CODE = "DCA";


  /**
   * Creates an adapter exception from an error code.
   * @param resClass The resource bundle class for the exceptions.
   * @param errCode The error code defined as a key in the reaource bundle.
   */
  public AdapterException(Class resClass, String errCode)
  {
    super(resClass, errCode, null);
  }

  /**
   * Creates an adapter exception from an error code that takes parameter values.
   * @param resClass The resource bundle class for the exceptions.
   * @param errCode The error code defined as a key in the reaource bundle.
   * @param params Parameters passed to the error text.
   */
  public AdapterException(Class resClass, String errCode, Object[] params)
  {
    super(resClass, errCode, params);
  }

  /**
   * Creates an exception for another exception as a cause.
   */
  public AdapterException(Throwable cause)
  {
    super(cause);
  }

  /**
   * Sets the cause exception for what this exception is thrown.
   * @param ex  The cause exception.
   */
  public AdapterException setCause(Throwable ex)
  {
    setDetails(new Object[]{ex});
    return this;
  }


  /**
  * Returns a message's product code.
  * @return Returns product code as <code>"DCA"</code>.
  **/
  public String getProductCode()
  {
    return DCA_PRODUCT_CODE;
  }


  /**
   * Creates a JboException from an AdapterException.
   */
  private class CauseException extends JboException
  {
    private String mPrdCode;

    public CauseException(Class resBndl, AdapterException ae, String prdCode)
    {
      super(resBndl, ae.getErrorCode(), ae.getErrorParameters());
      Throwable cause = ae.getCause();
      if (cause != null)
      {
        setDetails(new Object[]{cause});
      }
      mPrdCode = prdCode;
    }

    public String getProductCode()
    {
      return mPrdCode;
    }
  }
}
