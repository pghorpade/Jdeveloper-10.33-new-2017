/*
 * @(#)XMLSchemaDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat.xml;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import java.net.URL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.w3c.dom.Node;

import oracle.binding.meta.ArrayListDefinitionContainer;
import oracle.binding.meta.AttributeDefinition;

import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.dataformat.AccessorDef;
import oracle.adf.model.adapter.dataformat.AttributeDef;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.dataformat.xml.SchemaParser;
import oracle.adf.model.adapter.utils.Utility;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XMLSchemaNode;
import oracle.xml.parser.schema.XSDAnnotation;
import oracle.xml.parser.schema.XSDAttribute;
import oracle.xml.parser.schema.XSDComplexType;
import oracle.xml.parser.schema.XSDConstantValues;
import oracle.xml.parser.schema.XSDConstrainingFacet;
import oracle.xml.parser.schema.XSDElement;
import oracle.xml.parser.schema.XSDException;
import oracle.xml.parser.schema.XSDGroup;
import oracle.xml.parser.schema.XSDNode;
import oracle.xml.parser.schema.XSDSimpleType;
import oracle.xml.parser.schema.XSDTypeConstants;

import oracle.xml.parser.v2.XMLAttr;



/**
 * The <code>XMLSchemaDef</code> class parses an XML Schema definition
 * document and provide helper methods to query the schema's structure.
 * 
 * <p>
 * Input must be set using any of the <code>addSchema</code> methods. The
 * method <code>build</code> must be called after adding the required schema
 * documents. This method initialises the member variables and sets up the
 * object for use. Otherwise, all the helper methods return <code>null</code>.
 * </p>
 * <p>
 * A lookup table of all the global elements against its namespace is
 * maintained as
 * <code>AccessorDef<code> objects. The method <code>getType</code>
 * may be used to obtain an element by name and namespace.
 * </p>
 * <p>
 * We then build a list of all the top-level elements in 
 * <code>buildElementSet</code>. The method <code>buildSchemaTree</code>
 * descends into the top-level elements and creates a tree representing the
 * schema's structure.
 * </p>
 * <p>
 * The <code>getXSDTree</code> method returns the tree representation of the
 * input schema document/s.
 * </p>
 * <p>
  * On the resolution of each global element, it is added to a lookup table of
  * elements against its namespace. This allows the method
  * <code>getType</code> to quickly lookup a type by name and namespace and
  * return its <code>AccessorDef</code> representation. The
  * member variable <code>mTypesSet</code> encloses the lookup table against
  * each namespace declared in the schema document.
  * </p>
  * <p>
  * The tree structure is in accordance with JSR227 specification. An item of
  * data (<code>&lt;element&gt;</code>) is represented by a
  * <code>StructureDef</code>. The <code>&lt;element&gt;</code>'s
  * attributes can be obtained calling <code>StructureDef</code>'s
  * <code>getAttribute</code> method. If the <code>&lt;element&gt;</code>
  * has child elements, they can be obtained by calling the
  * <code>getAccessors</code> method. This returns a container of
  * <code>AccessorDef</code> objects. It's
  * <code>getStructure</code> method returns a <code>StructureDef</code>
  * which represents the parent's child element. XML specific information
  * against <code>&lt;element&gt;</code> such as <code>maxOccurs</code>,
  * <code>nillable</code> and other such Annotations and Facets can be
  * obtained by calling <code>AttributeDef</code>'s<code>getProperty</code>
  * or <code>getProperties</code> method.
  * </p>
  * 
  */
public class XMLSchemaDef
{
  /**
   * A set of constants that are retrieved from a type and stored in its
   * 'properties'.
   */
  public static final String TYPE        = XSDConstantValues._type;
  public static final String ENUMERATION = XSDConstantValues._enumeration;
  public static final String MIN_OCCURS  = XSDConstantValues._minOccurs;
  public static final String MAX_OCCURS  = XSDConstantValues._maxOccurs;
  public static final String NILLABLE    = XSDConstantValues._nillable;
  public static final String NAMESPACE   = XSDConstantValues._targetNS;

  /** Schema parser used to create the XSD Tree and other functionality */
  SchemaParser mParser;
  
  /** XML Schema object */
  XMLSchema mXMLSchema;
  
  /** Lookup table of resolved types against their namespace */
  Map mTypesSet;
  
  /** List of namespaces declared in this schema */
  String[] mNamespaceURLs;
  
  /** Tree representation of the Schema document */
  StructureDefinition mTree;
  
  /** Name of the root <code>AttributeDef</code> object */
  private String mRootName;
  
  /**
   * Used to create unique id for <code>StructureDef</code> and
   * <code>AttributeDef</code>.
   */
  private long mID = 0;
  

  ////////////////////////////// Constructor ///////////////////////////////////

  public XMLSchemaDef()
  {
    mParser = new SchemaParser();
  }
  
  
  /**
   * Initialises the XML Data Structure with a name.
   * @param rootName Name for the XML data structure
   */
  public XMLSchemaDef(String rootName)
  {
    this();
    mRootName = rootName;
  }


  ///////////////////////////// Public Methods /////////////////////////////////
 
  /**
   * Add a schema defintion specified by its URL location to the pipeline.
   * 
   * @param xsdLocation URL location of the schema defintion.
   * @throws AdapterException If error occurs while adding this
   *           defintion to the list. The URL location might be invalid or
   *           inaccessible.
   */
  public void addSchema(String xsdLocation) throws AdapterException
  {
    try
    {
      mParser.addSchema(xsdLocation);
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  
  /**
   * Add a schema defintion specified by its URL to the pipeline.
   * 
   * @param xsdURL URL of the schema definition.
   * @throws AdapterException If error occus while adding this
   *           definition to the list. The URL might be invalid or
   *           inaccessible.
   */
  public void addSchema(URL xsdURL) throws AdapterException
  {
    try
    {
      mParser.addSchema(xsdURL);
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  
  /**
   * Add a schema defintion specified by its Reader to the pipeline.
   * 
   * @param xsdReader <code>Reader</code> object containing the schema
   *                  definition.
   */
  public void addSchema(Reader xsdReader)
  {
    mParser.addSchema(xsdReader);
  }
  
  
  /**
   * Add a schema definition specified by its InputStream to the pipeline.
   * 
   * @param xsdStream <code>InputStream</code> object containing the schema
   *                  definition.
   */
  public void addSchema(InputStream xsdStream)
  {
    mParser.addSchema(xsdStream);
  }
  
  /**
   * Add a schema defintion specified by the <code>Node</code>.
   * 
   * @param node Root node of the schema defintion.
   */
  public void addSchema(Node node)
  {
    mParser.addSchema(node);
  }
  
  
  /**
   * Builds the object and initialises the member variables for use.
   * <p>
   * This method must be called after setting up the input using any of the
   * <code>addSchema</code> methods and before calling any of the helper
   * methods.</code>
   * 
   * @throws AdapterException If error occurs while parsing the
   *                                schema.
   */
  public void build() throws AdapterException
  {
    try
    {
      mXMLSchema = mParser.parse();
      
      // Obtain the schema's top-level elements and build a tree
      mNamespaceURLs = this.getAllTargetNS();
      mTypesSet = this.buildElementSet();
      mTree = this.buildSchemaTree();
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }
  

  /**
   * Returns the XSD tree in the form of <code>StructureDefinition</code>.
   * 
   * @return A <code>StructureDefinition</code> object representing the
   *         structure of top-level elements of the XML Schema document.
   */
  public StructureDefinition getSchemaTree()
  {
    return mTree;
  }
  
  
  /**
   * Returns the <code>AccessorDef</code> or a <code>AttributeDef</code>
   * representation of a type given its namespace. To obtain the underlying
   * data structure of a <code>AccessorDef</code>, call it's
   * <code>getStructure</code> method.
   * 
   * @param namespace Namespace to which the <code>type</code> belongs.
   * @param typeName Name of the <code>type</code>.
   * @return Returns either a <code>AccessorDef</code> or a
   *         <code>AttributeDef</code> object if the <code>type</code> is
   *         found, otherwise returns <code>null</code>.
   */
  public Object getType(String namespace, String typeName)
  {
    Object type = null;

    Utility.ASSERT(mTypesSet != null);
    
    if (mTypesSet.containsKey(namespace))
    {
      Map typeSet = (Map) mTypesSet.get(namespace);
      if (typeSet.containsKey(typeName))
        type = typeSet.get(typeName);
    }
    
    return type;
  }
  
  
  /**
   * Determines if the elements in the given namespace is qualified.
   * 
   * @param targetNamespace Namespace whose property needs to be queried.
   * @return Returns <code>true</code> if the elements in the given
   *         namespace are qualified. Returns <code>false</code> if the
   *         elements are unqualified or the given namespace does not exist.
   */
  public boolean isElementFormDefault(String targetNamespace)
  {
    boolean retval = false;
    SchemaMetadata metaData = mParser.getSchemaMetadata(targetNamespace);
    
    if (metaData != null)
      retval = metaData.isElementFormDefault();
      
    return retval;
  }
  
  
  /**
   * Determines if the attributes in the given namespace is qualified.
   * 
   * @param targetNamespace Namespace whose property needs to be queried.
   * @return Retruns <code>true</code> if the attributes in the given
   *         namespace are qualified. Returns <code>false</code> if the
   *         attributes are unqualified or the given namespace does not exist.
   */
  public boolean isAttributeFormDefault(String targetNamespace)
  {
    boolean retval = false;
    SchemaMetadata metaData = mParser.getSchemaMetadata(targetNamespace);
    
    if (metaData != null)
      retval = metaData.isAttributeFormDefault();
      
    return retval;
  }
  
  
  /**
   * Returns the property value of the schema given its namespace and name.
   * 
   * @param targetNamespace Namespace whose property needs to be queried.
   * @param name Name of the property whose value is to be fetched.
   * @return Returns the property value if both the namespace and the property
   *         exists. Otherwise returns <code>null</code>.
   */
  public String getSchemaProperty(String targetNamespace, String name)
  {
    String retval = null;
    SchemaMetadata metaData = mParser.getSchemaMetadata(targetNamespace);
    
    if (metaData != null)
      retval = metaData.getProperty(name);
      
    return retval;
  }
  
  
  /**
   * Determines if the given namespace is defined in the current schema.
   * 
   * @param namespace Name of the namespace.
   * @return Returns <code>true</code> if this namespace is defined in this
   *         schema, otherwise returns <code>false</code>.
   */
  public boolean isNamespaceDefined(String namespace)
  {
    return mTypesSet.containsKey(namespace);
  }
  
  
  /**
   * Returns all the target namespaces that is referred by the schema
   * document.
   * 
   * @return An array of <code>String</code> s consisting of the target
   *         namespaces referred by the schema document.
   */
  private String[] getAllTargetNS()
  {
    Utility.ASSERT(mXMLSchema != null);
    
    String[] allTargets = mXMLSchema.getAllTargetNS();
    List namespaceURLs = new ArrayList();
    
    for (int i = 0; i < allTargets.length; i++)
    {
      // Skip over the "http://www.w3.org/2001/XMLSchema" namespace
      if (allTargets[i].compareTo(XSDConstantValues.XSDRECNS) == 0)
        continue;
        
      namespaceURLs.add(allTargets[i]);
    }
    
    String []retval = new String[namespaceURLs.size()];
    return (String []) namespaceURLs.toArray(retval);
  }
  

  /**
   * Builds a Set of the top-level elements of all the namespaces
   * 
   * @return A <code>Map</code> of all the top-level elements against their
   *         namespace.
   */
  private Map buildElementSet()
  {
    Utility.ASSERT(mXMLSchema != null);
    
    Map typeSet = new HashMap();

    for (int i = 0; i < mNamespaceURLs.length; i++)
    {
      XMLSchemaNode schemaNode =
        mXMLSchema.getSchemaByTargetNS(mNamespaceURLs[i]);

      XSDNode[] complexTypes = schemaNode.getComplexTypeSet();
      XSDNode[] simpleTypes  = schemaNode.getSimpleTypeSet();
      XSDNode[] elements     = schemaNode.getElementSet();
      
      List types = new ArrayList();

      // Obtain all the top-level elements and add it to this namespace's type
      // list.
      for (int j = 0; j < complexTypes.length; j++)
        types.add(complexTypes[j]);
        
      for (int j = 0; j < simpleTypes.length; j++)
        types.add(simpleTypes[j]);
        
      for (int j = 0; j < elements.length; j++)
        types.add(elements[j]);
        
      typeSet.put(mNamespaceURLs[i], types.iterator());
    }
    
    return typeSet;
  }


  /**
   * Builds a tree of elements originating from the top-level elements.
   * 
   * @return A <code>StructureDefinition</code> object representing the data
   *         structure.
   * @throws AdapterException
   */
  private StructureDefinition buildSchemaTree()
  {
    StructureDef xsdTree = new StructureDef(mRootName);
    int i = 0;
    
    // Obtain a list of all the top-level elements for each namespace declared
    // in this schema document.
    Iterator topLevelTypes = this.getTopLevelTypes();
    
    while (topLevelTypes.hasNext())
    {
      // Obtain the top-level item and if possible descend into its child
      // elements.
      Iterator types = (Iterator) topLevelTypes.next();
      
      while (types.hasNext())
      {
        XSDNode node = (XSDNode) types.next();
        int nodeType = node.getNodeType();
        String colName = node.getName();
        String ns = node.getTargetNS();
        
        if (nodeType == XSDConstantValues.ELEMENT_CHILD)
        {
          // This is a simple type. Create a AttributeDef for this type.
          int basicType = ((XSDSimpleType) node).getBasicType();
          AttributeDef attr = 
            new AttributeDef(colName, xsdTree, TypeMap.getJavaType(basicType));
          this.setAttributeProperty((XSDSimpleType) node, attr);
          this.addType(ns, colName, attr);
        }
        else if (nodeType == XSDConstantValues.TYPE)
        {
          // This is a complexType. Descend into this type.
          StructureDef struct = new StructureDef(colName, xsdTree);
          AccessorDef acc = new AccessorDef(colName, xsdTree, struct, true);
          
          resolveComplexType((XSDComplexType) node, struct);
          
          this.addType(ns, colName, acc);
        }
        else if (nodeType == XSDConstantValues.ELEMENT)
        {
          // This is an element. This can either be a leaf-element or a
          // complexType.
          
          XSDNode elem = ((XSDElement) node).getType();
          ns = elem.getTargetNS();
          int elemType = elem.getNodeType();
          
          if (elemType == XSDConstantValues.TYPE)
          {
            // This is a complexType. Descend into this type.
            StructureDef struct = new StructureDef(colName, xsdTree);
            AccessorDef acc = new AccessorDef(colName, xsdTree, struct, true);
            resolveComplexType((XSDComplexType) elem, struct);

            this.setElementProperty((XSDElement) node, acc);
            this.addType(ns, colName, acc);
            xsdTree.addAccessor(acc);
          }
          else if (elemType == XSDConstantValues.ELEMENT_CHILD)
          {
            // This is a simpleType. Create a AttributeDef for this type.
            int basicType = ((XSDSimpleType) elem).getBasicType();
            AttributeDef attr = 
              new AttributeDef(colName, xsdTree, TypeMap.getJavaType(basicType));
            this.setAttributeProperty((XSDSimpleType) elem, attr);

            this.setElementProperty((XSDElement) node, attr);
            this.addType(ns, colName, attr);
            xsdTree.addAttribute(attr);
          }
          
        }
        else if (nodeType == XSDConstantValues.ANY)
        {
          // An <any> element corresponds to DOM's Element object.
          //StructureDef struct = new StructureDef(XSDConstantValues._any, xsdTree);
          AccessorDef acc = new AccessorDef(XSDConstantValues._any, 
                                            xsdTree, 
                                            "org.w3c.dom.Element"); //NOTRANS
          this.addType(ns, XSDConstantValues._any, acc);
          xsdTree.addAccessor(acc);
        }
      }
      
      i++;
    }
    
    return xsdTree;
  }
  
  
  /**
   * Resolves a <code>complexType</code> definition by descending into its
   * structure.
   * 
   * @param complexNode The <code>complexType</code> that needs to be
   *                    resolved.
   * @param parentStruct Parent <code>StructureDef</code> that encloses this
   *                  <code>complexType</code>.
   * @throws AdapterException
   */
  private void resolveComplexType(XSDComplexType complexNode,
                                  StructureDef parentStruct)
  {
    // Add all the attributes of this node to the column.
    XSDAttribute []attrs = complexNode.getAttributeDeclarations();
    
    for (int i = 0; i < attrs.length; i++)
    {
      String attrName = attrs[i].getName();
      XSDSimpleType attr = (XSDSimpleType) attrs[i].getType();
      int basicType = attr.getBasicType();
      AttributeDef attrCol = new AttributeDef(attrName,
                                        parentStruct,
                                        TypeMap.getJavaType(basicType));
      parentStruct.addAttribute(attrCol);
      this.setAttributeProperty(attr, attrCol);
      
      XSDAnnotation anno = attrs[i].getAnnotation();
      if (anno != null)
      {
        Map props = new HashMap();
          
        props.put(attrName, anno.getAttributes());
        attrCol.addProperties(props);
      }
    }
      
    
    // Add all the elements of this node to the column.
    XSDNode []elems = complexNode.getElementSet();
    
    if (elems == null)
      return;
    
    for (int i = 0; i < elems.length; i++)
    {
      String elemName = elems[i].getName();
      int elemType = elems[i].getNodeType();
      StructureDef thisStruct = null;

      if (elemType == XSDConstantValues.ELEMENT_CHILD)
      {
        // This is a simpleType. Create a AttributeDef for this type.
        int basicType = ((XSDSimpleType) elems[i]).getBasicType();
        AttributeDef attr = 
          new AttributeDef(elemName, parentStruct, TypeMap.getJavaType(basicType));
        this.setAttributeProperty((XSDSimpleType) elems[i], attr);
        parentStruct.addAttribute(attr);
      }
      else if (elemType == XSDConstantValues.ELEMENT)
      {
        // This is an element. This can either be a leaf-element or a
        // complexType.
        resolveElement((XSDElement) elems[i], parentStruct);
      }
      else if (elemType == XSDConstantValues.GROUP)
      {
        if (elemName == null)
        {
          elemName = ((XSDGroup) elems[i]).getRefLocalname();

          // Do not create a AttributeDef for anonymous <group> elements
          if (elemName != null)
          {
            thisStruct = new StructureDef(elemName, parentStruct);
            AccessorDef acc = new AccessorDef(elemName, parentStruct,
                                  thisStruct, true);
            this.addType(elems[i].getTargetNS(), elemName, acc);
            parentStruct.addAccessor(acc);
          }
        }
          
        // This is a group object. Descend into this group.
        resolveGroup((XSDGroup) elems[i],
                     (thisStruct == null) ? parentStruct : thisStruct);
      }
      else if (elemType == XSDConstantValues.ANY)
      {
        // An <any> element corresponds to DOM's Element object.
        //StructureDef thisStruct = 
        //  new StructureDef(XSDConstantValues._any, parentStruct);
        AccessorDef acc = new AccessorDef(XSDConstantValues._any, 
                                          parentStruct,
                                          "org.w3c.dom.Element"); //NOTRANS
        parentStruct.addAccessor(acc);
      }
    }
  }



  /**
   * Resolves a <code>group</code> definition by descending its structure.
   * 
   * @param groupNode The <code>group</code> that needs to be resolved.
   * @param parentStruct Parent <code>AttributeDef</code> object that encloses
   *                     this <code>group</code>.
   */
  private void resolveGroup(XSDGroup groupNode, StructureDef parentStruct)
  {
    Vector particles = groupNode.getNodeVector();
    
    for (int i = 0; i < particles.size(); i++)
    {
      XSDNode node = (XSDNode) particles.elementAt(i);
      int nodeType = node.getNodeType();
      
      if (nodeType == XSDConstantValues.GROUP)
      {
        // This is a group element. Descend futher into this group.
        resolveGroup((XSDGroup) node, parentStruct);
      }
      else if (nodeType == XSDConstantValues.ELEMENT)
      {
        // This is an element. This can either be a leaf-element or a
        // complexType.
        resolveElement((XSDElement) node, parentStruct);
      }
      else if (nodeType == XSDConstantValues.ANY)
      {
        // An <any> element corresponds to DOM's Element object.
        //StructureDef thisStruct = new StructureDef(XSDConstantValues._any,
        //                                           parentStruct);
        AccessorDef acc = new AccessorDef(XSDConstantValues._any, 
                                          parentStruct,
                                          "org.w3c.dom.Element"); //NOTRANS
        parentStruct.addAccessor(acc);
      }
    }
  }
  
  
  /**
   * Resolves an <code>element</code> definition by descending its
   * structure.
   * 
   * @param elemNode The <code>element</code> that needs to be resolved
   */
  private void resolveElement(XSDElement elemNode, StructureDef parentStruct)
  {
    XSDNode element = elemNode.getType();
    int elemType = element.getNodeType();
    String nodeName = elemNode.getName();
    
    if (elemType == XSDConstantValues.TYPE)
    {
      // See if this complexType is already resolved.
      Object type = this.getType(elemNode.getTargetNS(), nodeName);
      
      AccessorDef acc = null;
      StructureDef thisStruct = null;
  
      if (type == null)
      {
        thisStruct = new StructureDef(nodeName, parentStruct);
        acc = new AccessorDef(nodeName, parentStruct, thisStruct, true);
        
        resolveComplexType((XSDComplexType) element, thisStruct);
        
        this.addType(elemNode.getTargetNS(), nodeName, acc);
      }
      else
      {
        acc = (AccessorDef) type;
        thisStruct = new StructureDef(nodeName, parentStruct);
        acc = acc.clone(thisStruct, getNextID());
      }
      parentStruct.addAccessor(acc);
      this.setElementProperty(elemNode, acc);
    }
    else if (elemType == XSDConstantValues.ELEMENT_CHILD)
    {
      // This is a simpleType. Create a AttributeDef for this type.
      int basicType = ((XSDSimpleType) element).getBasicType();
      AttributeDef attr = new AttributeDef(nodeName, 
                                           parentStruct, 
                                           TypeMap.getJavaType(basicType));
      this.setAttributeProperty((XSDSimpleType) element, attr);
      parentStruct.addAttribute(attr);
      this.setElementProperty(elemNode, attr);
    }
    
  }
  
  
  /**
   * Sets some of the element's properties such as <code>nillable</code>,
   * <code>minOccurs</code> etc., into its corresponding
   * <code>AttributeDef</code>.
   * 
   * @param node <code>XSDElement</code> whose properties have to be
   *             retrieved.
   * @param elem <code>AttributeDef</code> object into which the properties
   *               have to be set.
   */
  private void setElementProperty(XSDElement node, AttributeDef elem)
  {
    int minOccurs = node.getMinOccurs();
    int maxOccurs = node.getMaxOccurs();
    boolean isNillable = node.isNillable();
    
    elem.addProperty(MIN_OCCURS, String.valueOf(minOccurs));
    elem.addProperty(MAX_OCCURS, String.valueOf(maxOccurs));
    elem.addProperty(NILLABLE, String.valueOf(isNillable));
    elem.addProperty(NAMESPACE, node.getTargetNS());
  }
  
  
  /**
   * Sets properties such as type, facets of a <code>simpleType</code>
   * element to a <code>AttributeDef</code>
   * 
   * @param attr <code>XSDSimpleType</code> whose properties have to be
   *             retrieved.
   * @param column <code>AttributeDef</code> object into which the properties
   *               have to be set.
   * @throws AdapterException
   */
  private void setAttributeProperty(XSDSimpleType attr, AttributeDef column)
    throws AdapterException
  {
    Map props = new HashMap();
    
    this.setBaseType(attr, props);
    this.getFacets(attr, props);
    column.addProperties(props);
  }
  
  
  /**
   * Retrieves the base type of the XML <code>&lt;simpleType&gt;</code> and
   * sets it into the <code>AttributeDef</code> object as string
   * representation.
   * <p>
   * If the type is a reference, this method descends the reference until the
   * base type is an XML Schema primitive type.
   * </p>
   * 
   * @param simpleType Schema artefact whose base type is to be found.
   * @param props Property <code>Map</code> into which the base type is stored.
   * @exception AdapterException
   */
  private void setBaseType(XSDSimpleType simpleType, Map props)
    throws AdapterException
  {
    try
    {
      XSDSimpleType base;
      String baseName = simpleType.getName();
      Map builtInTypes = XSDSimpleType.getBuiltInDatatypes();
      
      // If the type is derived by restriction, it's type must be obtained from
      // its base.
      if (baseName == null)
      {
        base = simpleType.getBase();
        
        // If this type is an anonymous simpleType, get its item type
        if (base == null)
          base = simpleType.getItemType();
        
        baseName = base.getName();
      }
      else
      {
        base = simpleType;
      }
        
      
      // See if the base name is one of the build-in types. Otherwise we
      // descent into the simpleType and resolve its basic type.
      while (builtInTypes.containsKey(baseName) == false)
      {
        XSDSimpleType baseElem = base.getBase();
        
        // Base type will be null if the type is enclosed in a <list>. We
        // obtain its itemType and resolve it.
        if (baseElem == null)
          base = base.getItemType();
        else
          base = baseElem;

        baseName = base.getName();
        
        // Base type is a <union>. Assume "string"
        if (baseName == null)
        {
          baseName = XSDTypeConstants.STRING;
          break;
        }
      }
      
      // Push the type into the AttributeDef object.
      props.put(TYPE, baseName);
    }
    catch (XSDException e)
    {
      throw new AdapterException(e);
    }
  }
  
  
  /**
   * Determines if the element has facets. If it has, adds them to
   * <code>facetMap</code>.
   * 
   * @param type XSD Simple Type object
   * @param facetMap A <code>Map</code> into which all the facets will be
   *          stored.
   */
  private void getFacets(XSDSimpleType type, Map facetMap)
  {
    XSDConstrainingFacet []facets = type.getFacets();
    
    if (facets != null)
    {
      for (int i = 0; i < facets.length; i++)
      {
        if (facets[i] != null)
        {
          // Retrieve the facet's lexical value or enumeration.
          Object facetVal = facets[i].getLexicalEnumeration();
          
          if (facetVal == null)
            facetVal = facets[i].getLexicalValue();
          
          facetMap.put(facets[i].getName(), facetVal);
        }
      }
    }
  }
  
  
  /**
   * Adds a <code>type</code> to the global list of types.
   * 
   * @param namespace Namespace to which this <code>type</code> belongs.
   * @param name Name of this <code>type</code>.
   * @param type <code>AccessorDef</code> or <code>AttributeDef</code> object
   *          containing the structure/attribute of the type.
   * @return Returns <code>true</code> either if this <code>type</code> is
   *         added to the global list or it was already added to the global
   *         list, otherwise returns <code>false</code>.
   */
  private boolean addType(String namespace, String name, Object type)
  {
    boolean addedToSet = false;
    
    // Add this type to the types' lookup table only if it is not already
    // added
    if (mTypesSet.containsKey(namespace))
    {
      Map typeSet = (Map) mTypesSet.get(namespace);
      
      if (typeSet.containsKey(name) == false)
        typeSet.put(name, type);
      
      addedToSet = true;
    }
    
    return addedToSet;
  }

  
  /**
   * Returns an <code>Iterator</code> of the top-level elements in all the
   * namespaces defined in this schema.
   * 
   * <p>
   * Further, this method replaces the <code>Iterator</code> installed in
   * <code>mTypeSet</code> with <code>Map</code>. The <code>Map</code>
   * s serve as a lookup table of all the types defined in the namespace.
   * </p>
   * 
   * @return An <code>Iterator</code> of the top-level elements.
   */
  private Iterator getTopLevelTypes()
  {
    List list = new ArrayList();
    
    for (int i = 0; i < mNamespaceURLs.length; i++)
    {
      Iterator topLevelTypes = (Iterator) mTypesSet.get(mNamespaceURLs[i]);
      list.add(topLevelTypes);
      
      // Replace the Iterator with a Map that consists of resolved types
      // in this namespace
      mTypesSet.put(mNamespaceURLs[i], new HashMap());
    }
      
    return list.iterator();
  }
  
  
  /**
   * Returns the next unique id to be used while creating a new
   * <code>BaseDefinitionDefinition</code>.
   * 
   * @return A unique ID in the form of "XSDn", where n is a positive number.
   */
  private String getNextID()
  {
    return ("XSD" + String.valueOf(mID++)); //NOTRANS
  }
  
  
  
  
  
  
  //////////////////////////////////////////////////////////////////////////
  /////                                                                /////
  /////                     TEST HARNESS METHODS                       /////
  /////                                                                /////
  //////////////////////////////////////////////////////////////////////////
  
  public void printTree(StructureDefinition struct, int indent)
  {
    char []pad = new char[indent];
    Arrays.fill(pad, ' ');
    String padding = new String(pad);
    
    // Print the attributes of this element
    ArrayListDefinitionContainer attrs =
      (ArrayListDefinitionContainer) struct.getAttributeDefinitions();
    
    for (int i = 0; i < attrs.size(); i++)
    {
      AttributeDefinition attr = (AttributeDefinition) attrs.item(i);
      System.out.println(padding+"  "+attr.getName()+": "+attr.getJavaTypeString());
      printProperties(((AttributeDef) attr).getProperties(), padding+"  ");
    }
    
    // Process all the accessors of this structure element
    ArrayListDefinitionContainer accs =
      (ArrayListDefinitionContainer) struct.getAccessorDefinitions();
    
    for (int i = 0; i < accs.size(); i++)
    {
      AccessorDef acc = (AccessorDef) accs.item(i);
      StructureDef thisStruct = (StructureDef) acc.getStructure();
      
      if (thisStruct == null)
      {
        System.out.println(padding+acc.getName() + ": " + acc.getJavaTypeString());
        printProperties(acc.getProperties(), padding+"  ");
      }
      else
      {
        System.out.println(padding+thisStruct.getName());
        printProperties(acc.getProperties(), padding);
        printTree(thisStruct, indent+2);
      }
    }
  }
  
  
  public void printProperties(Map props, String padding)
  {
    Iterator keys = props.keySet().iterator();
    
    while (keys.hasNext())
    {
      String key = (String) keys.next();
      Object value = props.get(key);
      
      if (value instanceof Vector)
      {
        Iterator vals = ((Vector) value).iterator();
      
        while (vals.hasNext())
        {
          Object object = vals.next();
          if (object instanceof XMLAttr)
            System.out.println(padding+"  "+key+":"+((XMLAttr) object).getNodeValue());
          else
            System.out.println(padding+"  "+key+":"+object);
        }
      }
      else if (value instanceof String)
      {
        System.out.println(padding+"  "+key+":"+value);
      }
    }
  }
  
  
  public void printAllTypes()
  {
    if (mNamespaceURLs == null)
    {
      System.out.println("Object is not initialised. Call getSchemaTree() method.");
      return;
    }
    
    for (int i = 0; i < mNamespaceURLs.length; i++)
    {
      Map types = (Map) mTypesSet.get(mNamespaceURLs[i]);
      
      Iterator keys = types.keySet().iterator();
      
      System.out.println("-----| Namespace |-----" + mNamespaceURLs[i]);
      while (keys.hasNext())
      {
        System.out.println("  " + (String) keys.next());
      }
    }
  }
  
  
  public void printSchemaMetadata()
  {
    if (mNamespaceURLs == null)
    {
      System.out.println("Object is not initialised. Call getSchemaTree()" +
                         " method.");
      return;
    }
    
    System.out.println("-----| Schema metadata |-----");
    
    for (int i = 0; i < mNamespaceURLs.length; i++)
    {
      System.out.println("Namespace: " + mNamespaceURLs[i]);
      System.out.println("  isElementFormDefault: " +
                         this.isElementFormDefault(mNamespaceURLs[i]));
      System.out.println("  isAttributeFormDefault: " +
                         this.isAttributeFormDefault(mNamespaceURLs[i]));
    }
  }
  
  
  //
  // Test harness
  //
  public static void main(String []args)
  {
    try
    {
      XMLSchemaDef xmlSchemaDef = new XMLSchemaDef("XMLDC1");
      
      if (args.length < 1)
        return;
      
      System.setProperty("http.proxyHost", "www-proxy.us.oracle.com");
      System.setProperty("http.proxyPort", "80");

      for (int i = 0; i < args.length; i++)
      {
        URL xsdURL = new URL(args[i]);
        InputStream content = xsdURL.openStream();
        xmlSchemaDef.addSchema(new InputStreamReader(content));
      }

      xmlSchemaDef.build();
      StructureDefinition struct = xmlSchemaDef.getSchemaTree();
      System.out.println(struct.getName());
      xmlSchemaDef.printTree(struct, 0);
      xmlSchemaDef.printAllTypes();
      xmlSchemaDef.printSchemaMetadata();
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
    }
  }
}
