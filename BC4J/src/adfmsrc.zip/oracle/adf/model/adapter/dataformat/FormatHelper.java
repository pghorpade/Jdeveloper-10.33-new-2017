/*
 * @(#)FormatHelper.java
 *
 * Copyright 2004,2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import oracle.binding.meta.NamedDefinition;
import oracle.binding.meta.DefinitionContext;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.utils.SimpleStringBuffer;
import oracle.adf.model.utils.JSR227Util;
import oracle.adf.model.utils.StandardOperationDef;

/**
 * Format structure handlers create structure from a source according to the 
 * jsr227 specification. This class will provide some common way to generate
 * structure for some different use cases.
 * <p>
 * For some sources, e.g. a CSV data source, data is returned as a collection
 * of rows. The structure definition must identify the returned collection as 
 * an Accessor so that the user can drop them on a view page from Data Control 
 * Palette. Moreover, the data control can be defined so that the definition
 * depends on some parameters. For example CSV data control can define a URL
 * source that takes a parameter, e.g. http://my.bugs?status=##STATUS##. The 
 * definition parameters should be exposed through the data control structure
 * definition so that they can be bound to the page parameter etc. for a 
 * specific usage in a page.
 * <p>
 * This class supports method <code>
 * {@link StructureHelper#getRootMethod(StructureDefinition,boolean,DefinitionContext)}
 * </code> to create
 * a virtual method wrapped over the structure definition returned by the data
 * control adapter. The virtual method exposes the definition parameters as the
 * method parameters. The data returned by the data control is then returned by 
 * the method. So when an element under this method, which are exposed by the 
 * data control adapter, is dropped on a page a MethodActionBinding is generated
 * and the parameter values can be set.  
 * <p>
 * This class also supports method <code>
 * {@link StructureHelper#getRootAccessor(StructureDefinition,boolean,DefinitionContext)}
 * </code> 
 * to create a root accessor in case the data control definition is not
 * parameterized. The accesor creates all required binding paths required to be
 * created for the data structure.  
 *
 * @version 1.0
 * @since 10.1.3
 */
public final class FormatHelper
{
  /**
   * Name of the wrapper method that a structure definition can be wrapped with.
   */
  public static final String METHOD_CREATE = 
    oracle.adf.model.adapter.AbstractImpl.METHOD_CREATE;

  /**
   * Name of the collection returned by the wrapper method. 
   */
  public static final String DATA = "Data";

  /**
   * Name of the accessor to have the standard operations.
   */
  public static final String OPERATIONS = "Operations";

  //=======================================================================
  // Static methods to get proper helper
  //=======================================================================

  /**
   * Gets the structure definition helper for a 
   * <code>FormatStructureHandler</code>.
   * @param handler format structure handler that generates structure definition
   *                from a specifc data source.
   */
  public static final StructureHelper getStructureHelper(
    FormatStructureHandler handler)
  {
    return new StructureHelper(handler);
  }

  /**
   * Gets the helper for a <code>FormatDataHandler</code>.
   * @param handler format data handler that extracts data from a specific data
   *                source.
   */
  public static final DataHelper getDataHelper(
    FormatDataHandler handler)
  {
    return new DataHelper(handler);
  }


  //=======================================================================
  // Public Methods
  //=======================================================================

  /**
   * Adds standard set of methods for a colection.
   * @param parent parent structure definition.
   */
  public static StructureDef createStandardCollectionOpStructure(
    NamedDefinition parent)
  {
    // create a new structure def to hold the operations
    StructureDef opDef = 
      new StructureDef(new SimpleStringBuffer(50)
                       .append((parent != null) ? parent.getFullName() : "")
                       .append("_")
                       .append(OPERATIONS).toString(),
                       parent);

    ////////////////////////////////
    // add the common methods to it
    ////////////////////////////////

    // Method - Execute
    opDef.addMethod(createParentedOp(JSR227Util.createExecuteAction(), opDef));
    // Method - First
    opDef.addMethod(createParentedOp(JSR227Util.createFirstAction(), opDef));
    // Method - Priv
    opDef.addMethod(createParentedOp(JSR227Util.createPreviousAction(), opDef));
    // Method - Next
    opDef.addMethod(createParentedOp(JSR227Util.createNextAction(), opDef));
    // Method - Last
    opDef.addMethod(createParentedOp(JSR227Util.createLastAction(), opDef));

    return opDef;
    //parent.addAccessor(new AccessorDef(OPERATIONS, parent, opDef, false));
  }



  //=======================================================================
  // Specific format helper classes
  //=======================================================================

  /**
   * Class that provides different helper methods for the structure definition
   * extracted from a format structure handler.
   */
  public static class StructureHelper
  {
    private FormatStructureHandler _handler;

    //////////////////////// class constructors ////////////////////////////

    private StructureHelper(FormatStructureHandler handler)
    {
      _handler = handler;
    }

    //////////////////////////// public methods ////////////////////////////

    /**
     * Creates a wrapper method definition to define a virtual method 
     * {@link #METHOD_CREATE} as if that returns the structure definition created
     * by the <code>FormatStructureHandler</code> implementation.The returned 
     * collection will have a name "Data".
     * <p>
     * This virtual method will facilitate to pass definition parameters to the 
     * data control instances.
     * The caller should add the parameters to the returned method if any. The
     * return value of the method is the structure definition that the concrete
     * implementation class returns.
     *
     * @param parent parent of the returned method definition.
     * @param isCollection if the method returns a collection.
     * @param ctx current definition context.
     * @return the virtual method definition.
     *
     * @see oracle.adf.model.adapter.dataformat.FormatStructureHandler#getStructure
     */
    public MethodDef getRootMethod(
      StructureDefinition parent,
      boolean isCollection,
      DefinitionContext ctx)
    {
      if ((_handler == null) || (parent == null))
      {
        return null;
      }

      // Create the virtual method
      MethodDef method = new MethodDef(METHOD_CREATE, parent);
      //method.setReturnName(DATA);

      // Call the implementation to get the structure def.

      // create the structure def name prepended with the dc name + method name
      String struName = new SimpleStringBuffer(50)
        .append(parent.getName()).append(".").append(METHOD_CREATE)
        .append("_").append(DATA).toString();
      StructureDefinition origDef = _handler.getStructure(struName, ctx);
      if (origDef != null)
      {
        method.setReturnType(origDef, isCollection);
        // if the returned structure is a collection, it should have the 
        // standard methods added.
        if (isCollection)
        {
          method.setReturnCollectionStructure(
            createStandardCollectionOpStructure(origDef));
        }
      }

      return method;
    }


    /**
     * Creates a wrapper accessor definition as if that returns the structure 
     * definition created by the <code>FormatStructureHandler</code> 
     * implementation.The return accessor will have a name "Data".
     *
     * @param parent parent of the returned method definition.
     * @param isCollection if the method returns a collection.
     * @param ctx current definition context.
     * @return the accessor definition.
     *
     * @see oracle.adf.model.adapter.dataformat.FormatStructureHandler#getStructure
     */
    public AccessorDef getRootAccessor(
      StructureDefinition parent,
      boolean isCollection,
      DefinitionContext ctx)
    {
      if ((_handler == null) || (parent == null))
      {
        return null;
      }

      // Name of the accessor's structure, this'd be the name of the bean xml
      // file
      String accStrucName = new SimpleStringBuffer(50).append(parent.getName())
         .append("_").append(DATA).toString();                                        
      // create the structure
      StructureDefinition def = _handler.getStructure(accStrucName, ctx);

      // Create the accessor definition
      AccessorDef accDef = 
        new AccessorDef(DATA, parent, def, isCollection);
      accDef.setBindPath(new SimpleStringBuffer(50)
        .append(parent.getFullName())
        .append(".")
        .append(oracle.adf.model.adapter.AdapterDCService.DC_ROOT_ACC_NAME)
        .toString());

      // if the returned structure is a collection, it should have the 
      // standard methods added.
      if (isCollection)
      {
        accDef.setCollectionStructure(createStandardCollectionOpStructure(def));
      }


      return accDef;
    }


  }



  //----------------------------------------------------------------------------
  // Data Helper class
  //----------------------------------------------------------------------------


  /**
   * Class that provides different helper methods for the data extracted from 
   * a format data handler.
   */
  public static class DataHelper
  {

    //////////////////////// class variables ///////////////////////////////
    private FormatDataHandler _handler;


    //////////////////////// class constructors ////////////////////////////
    private DataHelper(FormatDataHandler handler)
    {
      _handler = handler;
    }
  }


  //============================================================================
  // Class Helpers
  //============================================================================

  private static StandardOperationDef createParentedOp(
    StandardOperationDef op, 
    StructureDef parent)
  {
    if (op != null)
    {
      op.setParent(parent);
    }
    return op;
  } 
}
