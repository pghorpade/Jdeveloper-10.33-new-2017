/*
 * @(#)SchemaMetadata.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat.xml;

import java.util.HashMap;
import java.util.Map;

/** 
 * Class to store schema metadata.
 */
public class SchemaMetadata
{

  private boolean mElementFormDefault;
  private boolean mAttributeFormDefault;
  private String  mTargetNamespace;
  private Map     mProperties = new HashMap();


  SchemaMetadata(String targetNamespace)
  {
    mTargetNamespace = targetNamespace;
  }
  
  
  /**
   * Determine if the schema's attributes are qualified.
   * @return Returns the isAttributeFormDefault.
   */
  public boolean isAttributeFormDefault()
  {
    return mAttributeFormDefault;
  }
  
  
  /**
   * Determine if the schema's elements are qualified.
   * @return Returns the isElementFormDefault.
   */
  public boolean isElementFormDefault()
  {
    return mElementFormDefault;
  }
  
  
  /**
   * Returns the property given its name.
   * @param name Name of the property whose value is to be retrieved.
   * @return Returns the value of the property.
   */
  public String getProperty(String name)
  {
    return (String) mProperties.get(name);
  }
  
  
  /**
   * Sets the <code>attributeFormDefault</code> property.
   * @param attributeFormDefault 
   */
  public void setAttributeFormDefault(boolean attributeFormDefault)
  {
    mAttributeFormDefault = attributeFormDefault;
  }
  
  
  /**
   * Sets the <code>elementFormDefault</code> property.
   * @param elementFormDefault The isElementFormDefault to set.
   */
  public void setElementFormDefault(boolean elementFormDefault)
  {
    mElementFormDefault = elementFormDefault;
  }
  
  
  /**
   * Sets a property pertaining to a schema document.
   * @param name Name of the property.
   * @param value Value of the property.
   */
  public void setProperty(String name, String value)
  {
    mProperties.put(name, value);
  }
    
}
