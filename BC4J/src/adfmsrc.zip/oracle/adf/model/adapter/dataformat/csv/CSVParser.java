/*
 * @(#)CSVParser.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat.csv;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;

import oracle.adf.model.utils.SimpleStringBuffer;

/**
 * Excel CSV Parser.
 *
 * If no encoding is passed to the constructor, the default encoding used
 * to read the CSV file is "UTF8".
 * Rules of Excel CSV
 * <ui>
 *   <li>1. Seperator character: any character, supports more than one 
 *   separators. The default separator is "," (comma).</li>
 *   <li>2. Quote character: " or '</li>
 *   <li>3. Quote character itself inside quoted string: "" (double quote)</li>
 *   <li>4. Quote only takes effect at the first character of a value
 *   <pre>
 *      Examples:
 *        1. ,"abc 123", => abc 123
 *        2. ,"abc" "123', => abc "123"
 *        3. ,abc "123", => abc "123" 
 *    </pre></li>
 *   <li>5. Comment start characters: N/A</li>
 * </ui>
 *   
 */
public final class CSVParser 
{
  /////////////////////////////// Constants ////////////////////////////////////

  /** UTF8 encoding, used for hadling data in different languages. */
  public static final String UTF8_ENCODING = "UTF8";

  /** Quote character */
  private static char CHAR_QUOTE = '"';

  /** Comma (seperator) character */
  private static char CHAR_COMMA = ',';


  /////////////////////////////// Class Variables //////////////////////////////

  /**
   * CSV stream reader
   */
  private LineNumberReader mReader;  

  /** Buffer to store one line of values.  */
  private ArrayList mValueArrayList = new ArrayList(); 

  /** Buffer to store one string value.  */
  private SimpleStringBuffer mValueBuffer = new SimpleStringBuffer(256);

  /** Current processed line.  */
  private String mLine = null;

  /** Current character position in the current line.  */
  private int mLinePosition = -1;

  /** Length of current line. */
  private int mLineLength = 0;

  /** If last character is comma. */
  private boolean mLastCharIsComma = false;
  
  /** Value separator character set. The separator can be one of these values.*/
  private char[] mSepCharSet = {CHAR_COMMA};
  
  /** Quote character. */
  private char mQuoteChar = CHAR_QUOTE;


  ////////////////////////////// Constructors //////////////////////////////////

  /**
   * Constructor
   *
   * @param pInputStream CSV input stream
   * @throws Exception any error occurred
   */
  public CSVParser(InputStream pInputStream) throws Exception
  {
    // If no encoding is passed in, use "UTF-8" encoding
    this(pInputStream, UTF8_ENCODING);
  }

  /**
   * Constructor
   *
   * @param pInputStream CSV input stream
   * @param pEnc character encoding
   * @throws Exception any error occurred
   */
  public CSVParser(InputStream pInputStream, String pEnc) throws Exception
  {
    if (pInputStream == null)
    {
      throw new Exception("Null Input Stream."); //TODO: Resource
    }
    
    mReader = new LineNumberReader(new InputStreamReader(pInputStream, pEnc));
  }

  ///////////////////////////// Public Methods /////////////////////////////////

  /**
   * Sets the separator characters as a list of possible separators for the 
   * data. CSV data may have more than one separators. By default this parser
   * considers comma (,) as the data separator.
   * @param seps  Array of separator charactors.
   */
  public void setSeparators(char[] seps)
  {
    if ((seps != null) && (seps.length > 0))
    {
      mSepCharSet = seps;
    }
  }
  
  /**
   * Sets the quote character.
   * @param ch Quote character.
   */
  public void setQuoteChar(char ch)
  {
    mQuoteChar = ch;
  }

  /**
   * Moves to the next line of the data.
   * @return returns false if the end of data reached.
   * @throws Exception any error occurred
   */
  public boolean nextLine() throws Exception 
  {
    setLine(mReader.readLine());
    if (mLine == null)
    {
      // End of file
      mValueArrayList.clear();
      return false;
    }

    parseLine();

    return true;
  }

  /**
   * Gets values of next line.
   * @return next line elements from input stream. If end of data reached, 
   *         it returns null.
   * @throws Exception any error occurred
   */
  public String[] getLineValues() throws Exception 
  {
    if (mValueArrayList.size() > 0) 
    {
      String[] ret = new String[mValueArrayList.size()];
      return (String[]) mValueArrayList.toArray(ret);
    }
    
    return null;
  }  



  //////////////////////////// Class Helpers ///////////////////////////////////

  /**
   * Checks if the character is a valid separator.
   */
  private boolean isSeparator(char ch)
  {
    for (int i = 0; i < mSepCharSet.length; i++)
    {
      if (ch == mSepCharSet[i]) 
      {
        return true;
      }
    }
    
    return false;
  }

  /**
   * Tests if end of line has reached.
   * @return true if end of line.
   */
  public boolean isEndOfLine() 
  {
    // If last char is comma, must return at least one more value
    return (mLinePosition >= mLineLength) && (!mLastCharIsComma);
  }


  /**
   * Sets current line to be processed
   *
   * @param line the line to be processed
   */
  private void setLine(String line) 
  {
    mLine = line;
   
    if (line != null)
    {
      mLineLength = line.length();
      mLinePosition = 0;
    }

  }

  /**
   * If next character is quote character
   *
   * @return true if next character is quote
   */
  private boolean isNextCharQuote() 
  {    
    if ((mLinePosition + 1) >= mLineLength) 
    {
      // no more char in the line
      return false; 
    } 
    else 
    {
      char ch = mLine.charAt(mLinePosition + 1);
      if (ch == mQuoteChar) 
      {
        return true;
      } 
      else 
      {
        return false;
      }
    }
  }

  /**
   * Parse one line.
   *
   * @return values of the line
   * @throws Exception any error occurred
   */
  private void parseLine() throws Exception 
  {
    mValueArrayList.clear();
        
    String[] values = null;
    String value = null;

    while (!isEndOfLine())
    {
      value = getNextValue();
      mValueArrayList.add(value);
    }    
  }

  /**
   * Gets next value from current line.
   * @return next data value.
   */
  private String getNextValue() throws Exception 
  {  
    mLastCharIsComma = false;

    // Clean up value buffer first 
    if (mValueBuffer.length() > 0) 
    {
      mValueBuffer.setLength(0);
    }

    boolean insideQuote = false;
    boolean firstChar = true;    
    boolean endValue = false;

    // Scan char by char
    while ((mLinePosition < mLineLength) && !endValue) 
    {
      boolean copyChar = true;    
      char ch = mLine.charAt(mLinePosition);
      
      // If first char
      if (firstChar) 
      {
        // Only check quote at first char
        if (ch == mQuoteChar) 
        {
          insideQuote = true;
          copyChar = false;  
        }
        // Also need to check comma at first char
        else if (isSeparator(ch)) 
        {
          copyChar = false;
          endValue = true;
          mLastCharIsComma = true;
        }
        
        firstChar = false;
      } 
      // Not first char but inside quote
      else if (insideQuote) 
      {
        // Check end quote 
        if (ch == mQuoteChar) 
        {        
          copyChar = false;
          // Two sucesstive quote chars inside quote means quote char itself
          if (isNextCharQuote()) 
          {
            mLinePosition++;
          } 
          // Otherwise it is ending quote
          else 
          {
            insideQuote= false;
          }
        }
      }
      // Not first char and outside quote
      else 
      {
        // Check comma 
        if (isSeparator(ch)) 
        {
          copyChar = false;
          endValue = true;
          mLastCharIsComma = true;
        }        
      }

      if (copyChar) 
      {
        mValueBuffer.append(ch);
      }

      mLinePosition++;
    }

    if (mValueBuffer.length() > 0) 
    {
      return mValueBuffer.toString();
    } 
    else 
    {
      return null;
    }
  }

}
