/* $Header: FormatDataEvent.java 14-aug-2006.13:17:55 armukher Exp $ */

/* Copyright (c) 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    armukher    08/11/06 - Creation
 */
package oracle.adf.model.adapter.dataformat;

/**
 * Format data events are thrown by format data handlers during data access.
 * 
 * @version $Header: FormatDataEvent.java 14-aug-2006.13:17:55 armukher Exp $
 * @since   10.1.3.1
 * 
 * @see oracle.adf.model.adapter.dataformat.FormatDataEventListener
 * @see oracle.adf.model.adapter.dataformat.FormatDataHandler
 */
public class FormatDataEvent
{
  private String _name;
  private Object _data;

  /**
   * Constructs an event with a name and data associted with the event.
   * @param name name of the event.
   * @param data data associated with this event.
   */
  public FormatDataEvent(String name, Object data)
  {
    _name = name;
    _data = data;
  }
  
  /**
   * Gets the name of this event.
   */
  public String getName()
  {
    return _name;
  }
  
  /**
   * Gets the data associated with this event.
   * @return the associated data. Returns NULL if none.
   */
  public Object getEventData()
  {
    return _data;
  }
  
  /**
   * Sends event to the event listener.
   */
  public void sendEvent(FormatDataEventListener listener)
  {
    if (listener == null) return;
    
    // send this event
    listener.onEvent(this);
  }
}