/*
 * @(#)CSVHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import java.io.InputStream;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import java.util.logging.Level;

import oracle.binding.meta.AccessorDefinition;
import oracle.binding.meta.AttributeDefinition;
import oracle.binding.meta.DefinitionContext;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.utils.SimpleStringBuffer;
import oracle.adf.share.logging.ADFLogger;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.model.adapter.dataformat.csv.ConditionDefinition;
import oracle.adf.model.adapter.dataformat.csv.CSVParser;
import oracle.adf.model.adapter.utils.Utility;
import oracle.adf.share.perf.Timer;

/**
 * Format handler for character separated values.
 * <p>
 * This class generates structures according to the JSR 227 specification from
 * a CSV data stream by parsing the data. The data types are guessed from the 
 * value of the first data line. It can extract values from a CSV data stream 
 * as well.
 * <p>
 * Data controls that deals with CSV data can use this class to generate data 
 * and structure.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class CSVHandler implements FormatDataHandler, FormatStructureHandler
{
  // key name to get the data type at runtime.
  public static final String FILTERING_COLTYPE_MAP = "ColTypeMap";
  // key name to get the data format at runtime.
  public static final String FILTERING_COLFORMAT_MAP = "ColFormatMap";

  /** End of data event. */
  public static final String EV_EOD = "__ev_eod__";
  
  // stream containing the data.
  private InputStream mDataStream;

  // if the first row contains the names
  private boolean mIsFirstRowNames = false;

  // Encoding styles
  private String mEncStyle;

  // Character value separator 
  private String mDelimiter;

  // Character used to quote a multi-word string
  private String mQuoteChar;

  // Param names
  private ParameterDefinition[] mParams;

  // Filtering condition matchAll or matchAny flag
  private boolean mIsAll = true;
  
  // Filtering condtions
  private String[] mConditions = null;
  private Vector mValidConditions = new Vector();
  
  //Filtering colName-Type Map
  private Map mColTypeMap = null;

  //Filtering colName-format Map
  private Map mColFormatMap = null;
  
  // Column names
  private List mColNames = null; 
  
  // data event listener
  private FormatDataEventListener mEventListener = null;
  
  // logger  
  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger();

  // performance sensors
  private static Timer sGetStructureTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/dataformat/CSVHandler",
                       "getStructure",
                       "Creating the structure definition from csv data");
  private static Timer sGetResultTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/dataformat/CSVHandler",
                       "getResult",
                       "Creating the collection iterators for csv data");
  
  ////////////////////////////// Constructors //////////////////////////////////

  /**
   * Creats a CSV format handler object.
   *
   * @param is input stream that contains the CSV data.
   * @param isFirstRowNames flag to indicate if the first row of the CSV data 
   *        can be treated as column names.
   * @param encodingStyle encoding style of the data.
   * @param delim character value separators.
   * @param quoteChar value that can be treated as quote.
   */
  public CSVHandler(
    InputStream is,
    boolean isFirstRowNames, 
    String encodingStyle,
    String delim, 
    String quoteChar)
  {
    mDataStream = is;
    mIsFirstRowNames = isFirstRowNames;
    mEncStyle = encodingStyle;
    mDelimiter = delim;
    mQuoteChar = quoteChar;
  } 


  //============================================================================
  // Public Methods 
  //============================================================================

  /**
   * Sets the data event listener.
   */
  public void setDataEventListener(FormatDataEventListener listener)
  {
    mEventListener = listener;
  }

  /**
   * Sets the parameter names for the definition. 
   * The parameter names will be used to define the structure of the data.
   */
  public void setParameters(ParameterDefinition[] params)
  {
    mParams = params;
  }

  /**
   * Sets the filtering conditions for the csv data.
   */
  public void setFilterConditions(boolean isAll, String[] conditions)
  {
    mIsAll = isAll;
    mConditions = conditions;
  }
  
  /**
   * Sets the map for column name -type.
   */
  public void setColTypeMap(Map colTypeMap)
  {
    mColTypeMap = colTypeMap;
  }
  
  /**
   * Sets the map for column name - format.
   */
  public void setColFormatMap(Map colFormatMap)
  {
    mColFormatMap = colFormatMap;
  }

  ///////////////////// Impl of FormatHandler //////////////////////////////////

  /**
   * Returns the structure definition extracted for the data format.
   * <p>
   *
   * @param name name of the root structure.
   * @param ctx definition context information.
   * @return the structure information extracted.
   */
  public StructureDefinition getStructure(String name, DefinitionContext ctx)
  {
    StructureDef attrParent = null;
      
    try
    {
      mLogger.finer("Creating the structure definitions from the CSV source.");
      CSVParser parser;
       
      sGetStructureTimer.start();
        
      if (mEncStyle == null)
      {
        parser = new CSVParser(mDataStream);
      }
      else
      {
        parser = new CSVParser(mDataStream, mEncStyle);
      }

      parser.setSeparators(mDelimiter.toCharArray());
      if (mQuoteChar != null && mQuoteChar.length() != 0)
      {
        parser.setQuoteChar(mQuoteChar.charAt(0));
      }

      // Get the column names
      Iterator colNames = getColNames(parser).iterator();

      // Create the structure definition
      attrParent = new StructureDef(name);

      // Parse the data to get the attributes
      if (mIsFirstRowNames)
      {
        parser.nextLine();
      }

      mLogger.finer("Attributes Added: ");
      String[] vals = parser.getLineValues();
      if (vals != null)
      {
        int i = 0;
        while (colNames.hasNext())
        {
          String type = "java.lang.String";
          if (i < vals.length)
          {
            type = checkType(vals[i]);
            ++i;
          }
          AttributeDef attr = 
            new AttributeDef((String) colNames.next(), attrParent, type);
          attrParent.addAttribute(attr);
          mLogger.finer(attr.getName());
        }
      }
      else
      {
        while (colNames.hasNext())
        {
          AttributeDef attr = 
            new AttributeDef((String) colNames.next(), 
                             attrParent, "java.lang.String");
          attrParent.addAttribute(attr);
          mLogger.finer(attr.getName());
        }
      }
      sGetStructureTimer.stop();
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
    finally
    {
      sGetStructureTimer.cleanup();
    }    

    return attrParent;

  }

  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containig the context information.
   * @param returnType data type of the returned value. This can be passed as null.
   *        If no return type is specified, an Iterator of Map will be returned.
   * @return Object of the type defined by the <code>returnType</code> parameter.
   *         If the type is available, an instance of that object is created. If no
   *         type is specified an <code>Iterator</code> of <code>Map</code> objects 
   *         for the result will be created.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other 
   *         <code>Map</code>s as well.
   */
  public Object getResult(Map params, String returnType)
  {
    return getResult(params);
  }


  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containig the context information.
   * @return <code>Iterator</code> of <code>Map</code> objects for the result.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other iterator of
   *         <code>Map</code>s as well.
   */
  public Iterator getResult(Map params)
  {
    try
    {
      mLogger.finer("Creating result from the CSV source.");
        
      sGetResultTimer.start();
      
      if (mColTypeMap == null)
      {
        mColTypeMap = (Map)params.get(FILTERING_COLTYPE_MAP);
      }
      
      if (mColFormatMap == null)
      {
        mColFormatMap = (Map)params.get(FILTERING_COLFORMAT_MAP);
      }

      checkConditions();

      final CSVParser parser;
      if (mEncStyle == null)
      {
        parser = new CSVParser(mDataStream);
      }
      else
      {
        parser = new CSVParser(mDataStream, mEncStyle);
      }

      parser.setSeparators(mDelimiter.toCharArray());
      if (mQuoteChar != null && mQuoteChar.length() != 0)
      {
        parser.setQuoteChar(mQuoteChar.charAt(0));
      }

      final List cols = getColNames(parser);
      final boolean bEndOfData = (mIsFirstRowNames) ? !parser.nextLine() : false;

      mLogger.finer("Creating data iterator.");      
      //return the data iterator
      Iterator returnIter = new Iterator()
      {
        CSVParser _parser = parser;
        List _names = cols;
        boolean _eof = bEndOfData;
        // to guarntee we doesn't return null value
        Object nextValue = nextValidValue();
        
        public void remove()
        {
        }
        
        public boolean hasNext()
        {
          if (nextValue != null)
          {
            return true;
          }
          else 
          {            
            return false;    
          }
        }
        
        public Object next()
        {
          Object returnValue = nextValue;
          nextValue = nextValidValue();
          return returnValue;
        }
        
        private Object nextValidValue()
        {
          try
          {
            if (_eof)
            {
              return null;
            }
            mLogger.finer("Row fetched.");
            Iterator _colNames = _names.iterator();
            //create the current row as Map
            java.util.HashMap map = new java.util.HashMap(5);
            String[] data = _parser.getLineValues();
            
            // get the next data line.
            _eof = !_parser.nextLine();
            // if end of file, send the event to the listener
            if (_eof && (mEventListener != null))
            {
              CSVDataEvent event = new CSVDataEvent(EV_EOD);
              event.sendEvent(mEventListener);
            }
            
            // skip empty lines, get the next lines
            if (data == null) 
            {
              return nextValidValue();   
            }
            else
            {
              int i = 0;
              while (_colNames.hasNext())
              {
                String val = null;
                if (i < data.length)
                {
                  val = data[i];
                }
                map.put(_colNames.next(),val);
                i++;
              }
                       
              if (isValidForConditions(map))
              {
                //  return map;
                return map;
              }
              else
              {
                // doesn't meet the filter criteria, get the next data line.
                mLogger.finer("Skiping row, doesn't match the filter criteria.");
                return nextValidValue();
              }
            }
          }
          catch (Exception e)
          {
            mLogger.warning("Exception fetching CSV data. Cause: " + 
                            e.toString());
            throw new AdapterException(e);
          }
        }
      };
      sGetResultTimer.stop();
      return returnIter;
        
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
    finally
    {
      sGetResultTimer.cleanup();
    }    
  }
  
  /**
   * Event that the CSV handler sends during processing csv data.
   */
  public class CSVDataEvent extends FormatDataEvent
  {
    public CSVDataEvent(String name)
    {
      super(name, null);
    }
  }


  //============================================================================
  // Class Helper Methods 
  //============================================================================

  
  /**
   * Attempts to obtain the Java type from the string value.
   * @param data String value whose datatype has to be guessed.
   * @return Java type name.
   */
  private String checkType(String data)
  {
    try
    {
      // We first try to convert the value into a long number.
      // If successful, we will use long; if it throws NumberFormatException,
      // we will attempt to convert it to float. If this too fails, we return
      // string.
      if (data != null)
      {
        try
        {
          // Try to conver the value into an integer number.
          long numTest = Long.parseLong(data);
          return "java.lang.Long"; //NOTRANS
        }
        catch (NumberFormatException nfe)
        {
          // Try to convert the value into float number.
          float numTest = Float.parseFloat(data);
          return "java.lang.Float"; //NOTRANS
        }
      }
      else
      {
        return "java.lang.String"; //NOTRANS
      }
    }
    catch (NumberFormatException nfe)
    {
      // If conversion failed, we assume this is a string.
      return "java.lang.String";
    }
  }

  /**
   * Gets the column names.
   */
  /**
   * Gets the column names.
   */
  private List getColNames(CSVParser parser)
  {
    try
    {
      if (mColNames == null)
      {
        // Get the first row. If the first row is NOT the column names, we need
        // to generate column names for them.
  
        if (!parser.nextLine())
        {
          // No data found.
          // ToDo: resource
          new Exception("No data");
        }
  
        mColNames = new java.util.ArrayList(10);
  
        String[] cols = parser.getLineValues();
        if (mIsFirstRowNames)
        {
          makeValidColumnNames(cols);
          for (int i = 0; i < cols.length; i++)
          {
            mColNames.add(cols[i]);
          }
        }
        else
        {
          for (int i = 0; i < cols.length; i++)
          {
            String colName = 
              new SimpleStringBuffer(20).append("Column").append(i).toString();
            mColNames.add(colName);
          }
        }
      }

      return mColNames;
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Check whether the row meets with filtering condition.
   * @param map the row data 
   * @return true if row data meets with filtering condition
   */
  private boolean isValidForConditions(Map map)
  {
    boolean isValid = true;

    if (mValidConditions != null && mValidConditions.size() >0)
    {
      if (!mIsAll)
      {
         for (int i = 0; i < mValidConditions.size(); i++)
         {
           ConditionDefinition condDef = (ConditionDefinition)mValidConditions.elementAt(i);
           
           String colName = condDef.getColumn();
           String colValue = (String)map.get(colName);
           String colOperator = condDef.getOperator();
           String conditionValue = condDef.getValue();
           String colType = (String)mColTypeMap.get(colName);
           String colFormat = (String)mColFormatMap.get(colName);
           
           if (colOperator.equalsIgnoreCase("startsWith"))
           {
             if (colValue.startsWith(conditionValue))
             {
               isValid = true;
               break;
             }
             else
             {
               isValid = false;
             }
           } 
           if (colOperator.equalsIgnoreCase("endsWith"))
           {
             if (colValue.endsWith(conditionValue))
             {
               isValid = true;
               break;
             }
             else
             {
               isValid = false;
             }
           } 
           
           if (colOperator.equalsIgnoreCase("contains"))
           {
             if (colValue.indexOf(conditionValue) != -1)
             {
               isValid = true;
               break;
             }
             else
             {
               isValid = false;
             }
           }
           
           if (colOperator.equalsIgnoreCase("notContains"))
           {
             if (colValue.indexOf(conditionValue) == -1)
             {
               isValid = true;
               break;
             }
             else
             {
               isValid = false;
             }
           } 
           
           if (colOperator.equals(">") ||
                colOperator.equals("<") ||
                colOperator.equals(">=") ||
                colOperator.equals("<=") ||
                colOperator.equals("!=") ||
                colOperator.equals("="))  
           {
               if (colValue.length() > 0)
               {
                 try 
                 {
                   if (colType.compareToIgnoreCase("java.util.Date") == 0)
                   {
                     SimpleDateFormat sdf1 = new SimpleDateFormat(colFormat);
                     Date v = sdf1.parse(colValue);
                     Date conVal = sdf1.parse(conditionValue);
                     if (colOperator.equals(">"))
                     {
                        if (v.after(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                     if (colOperator.equals("<"))
                     {
                        if (v.before(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                     
                     if (colOperator.equals("<="))
                     {
                        if (v.before(conVal) || v.equals(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                     
                     if (colOperator.equals(">="))
                     {
                        if (v.after(conVal) || v.equals(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                     
                     if (colOperator.equals("!="))
                     {
                        if (!v.equals(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                     
                     if (colOperator.equals("="))
                     {
                        if (v.equals(conVal))
                        {
                          isValid = true;
                          break;
                        }
                        else
                        {
                          isValid = false;
                        }
                     }
                   }
                   else
                   {
                     DecimalFormat nf1 = new DecimalFormat(colFormat);
                     Number v = nf1.parse(colValue);
                     Number conVal = nf1.parse(conditionValue);

                   if (colOperator.equals(">"))
                   {
                      if (v.doubleValue() > conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   if (colOperator.equals("<"))
                   {
                      if (v.doubleValue() < conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   
                   if (colOperator.equals("<="))
                   {
                      if (v.doubleValue() <= conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   
                   if (colOperator.equals(">="))
                   {
                      if (v.doubleValue() >= conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   
                   if (colOperator.equals("!="))
                   {
                      if (v.doubleValue() != conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   
                   if (colOperator.equals("="))
                   {
                      if (v.doubleValue() == conVal.doubleValue())
                      {
                        isValid = true;
                        break;
                      }
                      else
                      {
                        isValid = false;
                      }
                   }
                   }
                }
                catch (Exception e)
                { 
                  isValid = false;
                }
              }
            }
             
         }
        }
                  
      if (mIsAll)
      {
        for (int j = 0; j < mValidConditions.size(); j++)
        {
          ConditionDefinition condDef = (ConditionDefinition)mValidConditions.elementAt(j);
              
            String colName = condDef.getColumn();    
            String colValue = (String)map.get(colName);
            String colOperator = condDef.getOperator();
            String conditionValue = condDef.getValue();            
            String colType = (String)mColTypeMap.get(colName);
            String colFormat = (String)mColFormatMap.get(colName);
          
           if (colOperator.equalsIgnoreCase("startsWith"))
           {
             if (!colValue.startsWith(conditionValue))
             {
               isValid = false;
               break;
             }
           } 
            if (colOperator.equalsIgnoreCase("endsWith"))
           {
             if (!colValue.endsWith(conditionValue))
             {
               isValid = false;
               break;
             }
 
           } 
           
            if (colOperator.equalsIgnoreCase("contains"))
           {
             if (colValue.indexOf(conditionValue) == -1)
             {
               isValid = false;
               break;
             }
           }
           
            if (colOperator.equalsIgnoreCase("notContains"))
           {
             if (colValue.indexOf(conditionValue) != -1)
             {
               isValid = false;
               break;
             }
 
           } 
           
            if (colOperator.equals(">") ||
                colOperator.equals("<") ||
                colOperator.equals(">=") ||
                colOperator.equals("<=") ||
                colOperator.equals("!=") ||
                colOperator.equals("="))  
            {
               if (colValue.length() > 0)
               {
                 try 
                 {
                  if (colType.compareToIgnoreCase("java.util.Date") == 0)
                  {
                    SimpleDateFormat sdf1 = new SimpleDateFormat(colFormat);
                    Date v = sdf1.parse(colValue);
                    Date conVal = sdf1.parse(conditionValue);
                    if (colOperator.equals(">"))
                    {
                       if (!v.after(conVal))
                       {
                         isValid = false;
                         break;
                       }

                    }
                    if (colOperator.equals("<"))
                    {
                       if (!v.before(conVal))
                       {
                         isValid = false;
                         break;
                       }
                    }
                    
                     if (colOperator.equals("<="))
                    {
                       if (v.after(conVal))
                       {
                         isValid = false;
                         break;
                       }
                    }
                    
                    if (colOperator.equals(">="))
                    {
                       if (v.before(conVal))
                       {
                         isValid = false;
                         break;
                       }
                    }
                    
                    if (colOperator.equals("!="))
                    {
                       if (v.equals(conVal))
                       {
                         isValid = false;
                         break;
                       }
                    }
                    
                     if (colOperator.equals("="))
                    {
                       if (!v.equals(conVal))
                       {
                         isValid = false;
                         break;
                       }
                    }
                  }
                  else
                  {
                    DecimalFormat nf1 = new DecimalFormat(colFormat);
                    Number v = nf1.parse(colValue);
                    Number conVal = nf1.parse(conditionValue);
                    
                   if (colOperator.equals(">"))
                   {
                      if (v.doubleValue() <= conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }

                   }
                   if (colOperator.equals("<"))
                   {
                      if (v.doubleValue() >= conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }
                   }
                   
                    if (colOperator.equals("<="))
                   {
                      if (v.doubleValue() > conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }
                   }
                   
                   if (colOperator.equals(">="))
                   {
                      if (v.doubleValue() < conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }
                   }
                   
                   if (colOperator.equals("!="))
                   {
                      if (v.doubleValue() == conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }
                   }
                   
                    if (colOperator.equals("="))
                   {
                      if (v.doubleValue() != conVal.doubleValue())
                      {
                        isValid = false;
                        break;
                      }
                   }
                  }
                }
                catch (Exception e)
                { 
                  isValid = false;
                }
              }
            }
        }
      }
 
    }        
    return isValid;          
    
  }
  
  /**
   * Check whether the condition is valid or not. If valid, add to 
   * ConditionDefinition list.
   */
  private void checkConditions()
  {
 //   Map map = getColNameType(); 
    if (mConditions != null && mConditions.length >0)
    {
      for (int i = 0; i < mConditions.length; i++)
      {
        String condition = mConditions[i];
        if (condition.indexOf("=") != -1 || 
            condition.indexOf("<") != -1 || 
            condition.indexOf(">") != -1 ||
            condition.indexOf("!=") != -1 || 
            condition.indexOf("<=") != -1 || 
            condition.indexOf(">=") != -1)
        {
          int index = 0;
          String operator = null;
          if (condition.indexOf("=") != -1)
          {
            index = condition.indexOf("=");
            operator = "=";
          }
          if(condition.indexOf(">") != -1)
          {
            index = condition.indexOf(">");
            operator = ">";
          }
          if(condition.indexOf("<") != -1)
          {
            index = condition.indexOf("<");
            operator = "<";
          }
          if (condition.indexOf("!=") != -1)
          {
            index = condition.indexOf("!=");
            operator = "!=";
          }
          if (condition.indexOf(">=") != -1)
          {
            index = condition.indexOf(">=");
            operator = ">=";
          }
          if (condition.indexOf("<=") != -1)
          {
            index = condition.indexOf("<=");
            operator = "<=";
          }
          
          String columnName = condition.substring(0, index).trim();
          if (mColTypeMap.containsKey(columnName))
          {
            String type = (String)mColTypeMap.get(columnName);
            String colFormat = (String)mColFormatMap.get(columnName);
            String value = condition.substring(index+operator.length()).trim();
            
            if (!type.equals("java.lang.String") 
                && !type.equals("java.util.Date"))
            {
               try 
              {
                DecimalFormat nf1 = new DecimalFormat(colFormat);
                Number v = nf1.parse(value);
                ConditionDefinition condDef = new ConditionDefinition(columnName,operator,value);
                mValidConditions.add(condDef);
              }
              catch (Exception e)
              { 
                 // report exception - todo 
              }
            }
            else if (!type.equals("java.lang.String") 
                && type.equals("java.util.Date"))
            {
              try 
              {
                SimpleDateFormat sdf1 = new SimpleDateFormat(colFormat);
                Date v = sdf1.parse(value);
                ConditionDefinition condDef = new ConditionDefinition(columnName,operator,value);
                mValidConditions.add(condDef);
              }
              catch (Exception e)
              {
                // report exception - todo 
              }
            }
          }
        }
        else if (condition.indexOf("startsWith") != -1 || 
            condition.indexOf("contains") != -1 || 
            condition.indexOf("endsWith") != -1 ||
            condition.indexOf("notContains") != -1)
        {
          int index =0;
          String operator = null;
          if (condition.indexOf("startsWith") != -1)
          {
            index = condition.indexOf("startsWith");
            operator = "startsWith";
          }
          else if(condition.indexOf("contains") != -1)
          {
            index = condition.indexOf("contains");
            operator = "contains";
          }
          else if(condition.indexOf("endsWith") != -1)
          {
            index = condition.indexOf("endsWith");
            operator = "endsWith";
          }
          else
          {
            index = condition.indexOf("notContains");
            operator = "notContains";
          }
          
          String columnName = condition.substring(0, index).trim();
          if (mColTypeMap.containsKey(columnName))
          {
            String type = (String)mColTypeMap.get(columnName);
            if (type.equals("java.lang.String"))
            {
              String value = condition.substring(index+operator.length()).trim();
              ConditionDefinition condDef = new ConditionDefinition(columnName,operator,value);
              mValidConditions.add(condDef);
            }
          }
        }       

      }
    }
  }
  
  /**
    * Make valid column names for all columns in CSV data source.
    *
    * This method applies the following rules to translate the given string
    * to a valid column name which can be accepted by EL:
    * 
    * 1. If the first character of the string is digit,  
    *    prefix the string with '_'.
    * 2. Translate any characters other than letter, digit, or '_'  to '_'. 
    * 
    *
    */
  private String[] makeValidColumnNames(String[] cols) 
  {
    for (int i = 0; i <cols.length; i++)
    { 
       // Trim out leading or ending white spaces
      if (cols[i] != null && cols[i].length() > 0)
      {
        cols[i] = cols[i].trim();
      }
       
      if (cols[i] == null || cols[i].length() == 0)
      {
         // Default as "column1", "column2", ... if column name null 
        cols[i] = new SimpleStringBuffer("column").append(i+1).toString();
      }
      else
      {
        // Check special characters
        try 
        {
          cols[i] = Utility.normalizeString(cols[i]);
        }
        catch (Exception e)
        {
           // On error, simply default to "columnX". 
          cols[i] = new SimpleStringBuffer("column").append(i+1).toString();  
        }
      }
    }
    return cols;
  }
   
}

