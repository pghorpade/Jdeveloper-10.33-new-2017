/*
 * @(#)TypeMap.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat.xml;

import java.util.HashMap;
import java.util.Map;

import oracle.xml.parser.schema.XSDConstantValues;
import oracle.xml.parser.schema.XSDTypeConstants;

/**
 * This class maps XML Schema Definition types to Java types. 
 */
public class TypeMap 
{
  /**
   * Maps an XML Schema Definition type to its corresponding Java type.
   * 
   * @param xsdType Type of the <code>&lt;simpleType&gt;</code> element
   * @return Java type for the given XSD type. If the schema type is not found
   *         or supported, <code>"java.lang.Object"</code> is returned.
   */
  public static String getJavaType(int xsdType)
  {
    String javaType = "java.lang.Object";
    Integer type = new Integer(xsdType);
    
    
    if (sXSDJavaMap1.containsKey(type))
      javaType = (String) sXSDJavaMap1.get(type);
      
    return javaType;
  }
  
  
  /**
   * Maps an XML Schema Definition type to its corresponding Java type.
   * 
   * @param xsdType Type of the <code>&lt;simpleType&gt;</code> element
   * @return Java type for the given XSD type. If the schema type is not found
   *         or supported, <code>"java.lang.Object"</code> is returned.
   */
  public static String getJavaType(String xsdType)
  {
    String javaType = "java.lang.Object";
    
    if (sXSDJavaMap2.containsKey(xsdType))
      javaType = (String) sXSDJavaMap2.get(xsdType);
    
    return javaType;
  }
  
  
  /**
   * Maps a Java type to its corresponding XML Schema Definition type.
   * 
   * @param javaType Fully qualified name of Java type
   * @return Equivalient schema type for the given Java type. If the type is
   *         not found or supported, <code>"string"</code> is returned.
   */
  public static String getSchemaType(String javaType)
  {
    String schemaType = "string";
    
    if (sJavaXSDMap.containsKey(javaType))
      schemaType = (String) sJavaXSDMap.get(javaType);
      
    return schemaType;
  }
  
  
  /** Table to map XML Schema Definition types to Java types */
  static Map sXSDJavaMap1; // XSD -> Java (Integer to String)
  static Map sXSDJavaMap2; // XSD -> Java (String to String)
  static Map sJavaXSDMap;  // Java -> XSD
  
  static
  {
    //
    // XSD -> Java mapping (Integer to String)
    //
    sXSDJavaMap1 = new HashMap();
    
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iANY_SIMPLE),    "java.lang.String"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iSTRING),        "java.lang.String"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iBOOLEAN),       "java.lang.Boolean"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iDECIMAL),       "java.math.BigDecimal"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iFLOAT),         "java.lang.Float"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iDOUBLE),        "java.lang.Double"); // NOTRANS
//    sXSDJavaMap.put("duration"                      "");
    //sXSDJavaMap1.put(new Integer(XSDTypeConstants.iDATE),          "java.util.GregorianCalendar"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iDATE),          "java.util.Date"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iTIME),          "java.util.Date"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iDATE_TIME),     "java.util.Date"); // NOTRANS
//    sXSDJavaMap.put("gYearMonth",                   "");
//    sXSDJavaMap.put("gYear",                        "");
//    sXSDJavaMap.put("gMonthDay",                    "");
//    sXSDJavaMap.put("gDay",                         "");
//    sXSDJavaMap.put("gMonth",                       "");
//    sXSDJavaMap.put("unsignedByte",                 "java.lang.Byte"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iHEX_BINARY),    "java.lang.Byte[]"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iBASE64_BINARY), "byte[]"); // NOTRANS
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iANY_URI),       "java.lang.String"); // NOTRANS
//    sXSDJavaMap.put("QName",                        "");
    sXSDJavaMap1.put(new Integer(XSDTypeConstants.iNOTATION),      "java.lang.String"); // NOTRANS
//    sXSDJavaMap.put("normalizedString",             "java.lang.String"); // NOTRANS
//    sXSDJavaMap.put("integer",                      "java.lang.Integer"); // NOTRANS
//    sXSDJavaMap.put("long",                         "java.lang.Long"); // NOTRANS
//    sXSDJavaMap.put("int",                          "java.lang.Integer"); // NOTRANS
//    sXSDJavaMap.put("unsignedInt",                  "java.lang.Integer"); // NOTRANS
//    sXSDJavaMap.put("short",                        "java.lang.Short"); // NOTRANS
//    sXSDJavaMap.put("byte",                         "java.lang.Byte"); // NOTRANS
//    sXSDJavaMap.put("any",                          "org.w3c.dom.Element"); // NOTRANS
    

    
    //
    // XSD -> Java Mapping (String to String)
    //
    
    
    sXSDJavaMap2 = new HashMap();
    
    sXSDJavaMap2.put(XSDConstantValues._anySimpleType, "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.STRING,          "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.BOOLEAN,         "java.lang.Boolean"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.DECIMAL,         "java.math.BigDecimal"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.FLOAT,           "java.lang.Float"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.DOUBLE,          "java.lang.Double"); // NOTRANS
    // sXSDJavaMap.put("duration" "");
    //sXSDJavaMap2.put(XSDTypeConstants.DATE,            "java.util.GregorianCalendar"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.DATE,            "java.util.Date"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.TIME,            "java.util.Date"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.DATE_TIME,       "java.util.Date"); // NOTRANS
    // sXSDJavaMap.put("gYearMonth", "");
    // sXSDJavaMap.put("gYear", "");
    // sXSDJavaMap.put("gMonthDay", "");
    // sXSDJavaMap.put("gDay", "");
    // sXSDJavaMap.put("gMonth", "");
    sXSDJavaMap2.put(XSDTypeConstants.UNSIGNED_BYTE,   "java.lang.Short"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.HEX_BINARY,      "java.lang.Byte[]"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.BASE64_BINARY,   "byte[]"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.ANY_URI,         "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.QNAME,           "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.SNOTATION,       "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put("normalizedString",               "java.lang.String"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.INTEGER_STR,     "java.lang.Integer"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.LONG,            "java.lang.Long"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.INT,             "java.lang.Integer"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.UNSIGNED_INT,    "java.lang.Long"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.SHORT,           "java.lang.Short"); // NOTRANS
    sXSDJavaMap2.put(XSDTypeConstants.BYTE,            "java.lang.Byte"); // NOTRANS
    sXSDJavaMap2.put(XSDConstantValues._any,           "org.w3c.dom.Element"); // NOTRANS
    
    
    
    //
    // Java -> XSD Mapping
    //
    sJavaXSDMap = new HashMap();
    
//    sJavaXSDMap.put("void", "nil"); // NOTRANS
//
//    sJavaXSDMap.put("boolean",                      "boolean"); // NOTRANS
//    sJavaXSDMap.put("char",                         "string");
//    sJavaXSDMap.put("char[]",                       "string");
//    sJavaXSDMap.put("byte",                         "byte"); // NOTRANS
//    sJavaXSDMap.put("byte[]",                       "base64Binary"); // NOTRANS
//    sJavaXSDMap.put("short",                        "short"); // NOTRANS
//    sJavaXSDMap.put("int",                          "int"); // NOTRANS
//    sJavaXSDMap.put("long",                         "long"); // NOTRANS
//    sJavaXSDMap.put("float",                        "float"); // NOTRANS
//    sJavaXSDMap.put("double",                       "double"); // NOTRANS

    sJavaXSDMap.put("java.lang.String",             XSDTypeConstants.STRING); // NOTRANS
    sJavaXSDMap.put("java.lang.Boolean",            XSDTypeConstants.BOOLEAN); // NOTRANS
    sJavaXSDMap.put("java.lang.Double",             XSDTypeConstants.DOUBLE); // NOTRANS
    sJavaXSDMap.put("java.lang.Float",              XSDTypeConstants.FLOAT); // NOTRANS
    sJavaXSDMap.put("java.lang.Byte",               XSDTypeConstants.BYTE);  // NOTRANS
    sJavaXSDMap.put("java.lang.Byte[]",             XSDTypeConstants.BASE64_BINARY); // NOTRANS
    sJavaXSDMap.put("java.util.GregorianCalendar",  XSDTypeConstants.DATE); // NOTRANS
    sJavaXSDMap.put("java.util.Date",               XSDTypeConstants.DATE_TIME); // NOTRANS
    sJavaXSDMap.put("java.lang.Integer",            XSDTypeConstants.INT); // NOTRANS
    sJavaXSDMap.put("java.lang.Long",               XSDTypeConstants.LONG); // NOTRANS
    sJavaXSDMap.put("java.lang.Short",              XSDTypeConstants.SHORT); // NOTRANS
    sJavaXSDMap.put("java.math.BigDecimal",         XSDTypeConstants.DECIMAL); // NOTRANS
    sJavaXSDMap.put("org.w3c.dom.Element",          XSDConstantValues._any); // NOTRANS
    sJavaXSDMap.put("org.w3c.dom.DocumentFragment", XSDConstantValues._any); // NOTRANS
  }
}
