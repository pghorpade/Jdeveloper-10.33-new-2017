/*
 * @(#)MethodReturnDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.MethodReturnDefinition;
import oracle.binding.meta.OperationDefinition;

public class MethodReturnDef extends ParamDef implements MethodReturnDefinition
{
  // colelction structures, contains the standard methods
  private StructureDefinition mCollectionStruct = null;

  //============================================================================
  // Implementation
  //============================================================================

  ////////////////////////// Constructors //////////////////////////////////////
  public MethodReturnDef(
    String name, 
    String javaType, 
    OperationDefinition parent, 
    boolean isCollection)
  {
    super(name, javaType, parent, isCollection);
  }

  public MethodReturnDef(
    String name,
    OperationDefinition parent,
    String javaType,
    String elementJavaType)
  {
    super(name, parent, javaType, elementJavaType);
  }

  public MethodReturnDef(
    String name, 
    StructureDefinition def, 
    OperationDefinition parent, 
    boolean isCollection)
  {
    super(name, def, parent, isCollection);
  }

  public MethodReturnDef(
    String name, 
    StructureDefinition def, 
    OperationDefinition parent, 
    boolean isCollection,
    boolean isScalarCollection)
  {
    super(name, def, parent, isCollection, isScalarCollection);
  }

  /////////////////////////////// Impl of interface ////////////////////////////
  public StructureDefinition getCollectionStructure()
  {
    return mCollectionStruct;
  }

  public int getDefinitionType()
  {
     return TYPE_METHODRETURN;
  }
   
  //============================================================================
  // Public Methods
  //============================================================================
  
  /**
   * Set the structure definition for the collection if the return is a 
   * collection. Collection structures usually contain methods applicable for
   * the collection.
   */
  public void setCollectionStructure(StructureDefinition def)
  {
    mCollectionStruct = def;
  }

}
