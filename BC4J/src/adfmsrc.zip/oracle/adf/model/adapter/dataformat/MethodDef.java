/* $Header: MethodDef.java 23-nov-2005.09:03:54 jloropez Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   MODIFIED    (MM/DD/YY)
      jloropez  11/23/05 - XbranchMerge jloropez_bug4737515_dtwork from main 
      rvangri   11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
      armukher  08/11/05 - getFullName uses the bindpath, if set.
      alai      08/03/05 - 
      alai      08/01/05 - 
      alai      07/22/05 - 
      jwetherb  07/14/05 - Remove addParameter() overload 
 */
package oracle.adf.model.adapter.dataformat;

import java.util.Hashtable;

import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.MethodReturnDefinition;
import oracle.binding.meta.ArrayListDefinitionContainer;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.OperationDefinition;
import oracle.binding.meta.DefinitionContainer;
import oracle.binding.meta.Definition;
import oracle.binding.meta.NamedDefinition;

import oracle.adf.model.utils.SimpleStringBuffer;

/**
 * Defines a method of a data control.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class MethodDef implements OperationDefinition
{
  // Name of the return parameter.
  public static final String RET_NAME = "Return";


  //============================================================================
  // Implementation
  //============================================================================
  
  // Method name
  private String mName;

  // Method params
  private ArrayListDefinitionContainer mParamContainer;

  // Return name
  private String mReturnName = RET_NAME;
  // Return java type string
  private String mRetTypeStr = null;

  // Return type
  private MethodReturnDef mReturn;

  // Parent
  private StructureDefinition mParent;

  // bind path
  private String mBindPath = null;

  private boolean mIsStaticMethod = false;
  
  /////////////////////////////// Constructor //////////////////////////////////

  /**
   * Creates a method definition. The default return type is void.
   * @param name name of the method.
   * @param parent structure definition that contains this method.
   */
  public MethodDef(String name, StructureDefinition parent)
  {
    mName = name;
    mParent = parent;
    mParamContainer = new ArrayListDefinitionContainer();
  }

  /**
   * Creates a method definition with a simple return type.
   * @param name name of the method.
   * @param parent structure definition that contains this method.
   * @param retType the class name of the simple return type.
   */
  public MethodDef(String name, StructureDefinition parent, String retType)
  {
    this(name, parent);
    mRetTypeStr = retType;
    // Create a return param for the ret type
    //-- mReturn = new MethodReturnDef(mReturnName, retType, this, false);
  }




  //============================================================================
  // Public Methods
  //============================================================================
  

  /**
   * Sets the return name.
   * Return names are displayed when a method returns a complex structure. The 
   * default name is "Return".
   */
  public void setReturnName(String name)
  {
    mReturnName = name;
  }

  /**
   * Adds a parameter to the method.
   * @param paramDef definition of the parameter.
   */
  public void addParameter(ParameterDefinition paramDef)
  {
    mParamContainer.add(paramDef);
  }

  /**
   * Adds a parameter to the method.
   * @param name name of the parameter.
   * @param type simple type name of the parameter.
   */
  public void addParameter(String name, String type)
  {
    mParamContainer.add(new ParamDef(name, type, this, false));
  }

  /**
   * Sets a return type.
   * @param def a structure that describes a complex return type.
   */
  public void setReturnType(MethodReturnDef def)
  {
    mReturn = def;
  }

  /**
   * Sets a return type.
   * @param def a structure that describes a complex return type.
   */
  public void setReturnType(StructureDefinition def)
  {
    setReturnType(def, true);
  }

  /**
   * Sets a return type.
   * @param type a simple java type.
   */
  public void setReturnType(String type)
  {
    setReturnType(type, false);
  }

  /**
   * Sets a return type.
   * @param def a structure that describes a complex return type.
   * @param collection true if the return type is a collection.
   */
  public void setReturnType(StructureDefinition def, boolean collection)
  {
    mReturn = new MethodReturnDef(mReturnName, def, this, collection);
  }

  /**
   * Sets a return type.
   * @param type a simple java type.
   * @param collection true if the return type is a collection.
   */
  public void setReturnType(String type, boolean collection)
  {
    mReturn = new MethodReturnDef(mReturnName, type, this, collection);
  }

  /**
   * Sets the collection structure for the return type. Collection structures 
   * usually contain methods applicable for
   * the collection.
   */
  public void setReturnCollectionStructure(StructureDefinition def)
  {
    MethodReturnDef ret = (MethodReturnDef) getOperationReturnType();
    ret.setCollectionStructure(def);
  }

  ///////////////////////////////// Bind paths /////////////////////////

  /**
   * Sets the bind path.
   */
  public void setBindPath(String path)
  {
    mBindPath = path;
  }

  /**
   * Gets the bind path of the definition if set.
   */
  public String getBindPath()
  {
    return mBindPath;
  }

  //============================================================================
  // Implementation of Interfaces
  //============================================================================
  

  /**
   * Returns the name of this method.
   *
   * @return method name.
   */
  public String getName()
  {
    return mName;
  }

  /**
   * Returns the parent of this method.
   *
   * @return a <code>StructureDefinition</code> that contains this method.
   */
  public Definition getDefinitionParent()
  {
    return mParent;
  }

  /**
   * Returns the full name of the definition. 
   * @return If the bind path is defined it returns the bind path. If
   *         bind path is not defined and the parent is defined then it returns 
   *         &lt;parent_path&gt;.&lt;this_name&gt;. Otherwise it returns the name of the 
   *         definition.
   */
  public String getFullName()
  {
    String bindPath = getBindPath();
    if (bindPath != null)
    {
      return new SimpleStringBuffer(50)
        .append(bindPath)
        .append(".")
        .append(getName()).toString();
    }
    else
    {
      Definition parent = getDefinitionParent();
      if ((parent != null) && (parent instanceof NamedDefinition))
      {
        return new SimpleStringBuffer(50)
        .append(((NamedDefinition)parent).getFullName())
          .append(".")
          .append(getName()).toString();
      }
      else
      {
        return getName();
      }
    }
  }

  public Object getProperty(String propertyName)
  {
    return null;
  }

  public Hashtable getProperties()
  {
    return null;
  }

   public int getDefinitionType()
  {
    return TYPE_OPERATION;
  }

  /**
   * Returns the return type of the method.
   *
   * @return a <code>MethodReturnDefinition</code> for the return type.
   */
  public MethodReturnDefinition getOperationReturnType()
  {
    // for complex return types there is a return param 
    // defined
    if(mReturn == null)
    {
      // For void method, the return types are not set, in this case 
      // we'll return null according to JSR 227 spec.
      if (mRetTypeStr == null)
      {
        return null;
      }
  
      // Otherwise we'll create the return type if it's not set already.
      mReturn = new MethodReturnDef(mReturnName, mRetTypeStr, this, false);
    }

    return mReturn;
  }

  /**
   * Returns the definition of the DataControl that this method belongs to.
   * @return a <code>DataControlDefinition</code> of the DataControl that this
   *        method belongs to.
   */ 
  public DataControlDefinition getDataControlDefinition()
  {
    if (mParent != null)
    {
      return mParent.getDataControlDefinition();
    }
    return null;
  }
   
  /**
   * @return CUSTOM as the operation id since this class is used for
   *         custom methods.
   */ 
  public int getOperationId()
  {
    return CUSTOM;
  }

  /**
   * Gets the parameters defined for the method.
   *
   * @return a <code>DefinitionContainer</code> containing the parameter
   *         definitions.
   */
  public DefinitionContainer getOperationParameters()
  {
    return mParamContainer;
  }

  /**
   ** @return true if this operation definition represents a static
   ** method.
   **/
  public boolean isStatic()
  {
     return mIsStaticMethod;
  }
}
