/*
 * @(#)ParamDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import oracle.binding.meta.Definition;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.ParameterDefinition;
import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.OperationDefinition;

import java.util.Hashtable;

/**
 * Defines a method parameter of a data control.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class ParamDef implements ParameterDefinition
{
  // Name of the parameter
  private String mName;
  // type
  private String mJavaType;

  // if the parameter is a complex structure
  private StructureDefinition mStruct;

  // Parent
  private OperationDefinition mParent;

  // isCollection
  private boolean mIsCollection;

  // isScalarCollection
  private boolean mIsScalarCollection;
   
  //////////////////////////////// Constructors ////////////////////////////////

  /**
   * Creates a parameter without a return type.
   * @param name name of the parameter.
   * @param parent the parent definition of this object.
   */
  private ParamDef(String name, OperationDefinition parent)
  {
    mName = name;
    mParent = parent;
  }
  /**
   * Creates a new instance of simple type.
   *
   * @param name name of the parameter.
   * @param javaType java type of the parameter.
   * @param parent the parent definition of this object.
   * @param isCollection true if this parameter is a collection
   */
  public ParamDef(
    String name, 
    String javaType,
    OperationDefinition parent, 
    boolean isCollection)
  {
    // TODO: revisit callers to see if they are passing the correct isCollection flag
    this(name, parent);
    mJavaType = javaType;
    mIsCollection = isCollection;
  }

  /**
   * Creates a new instance of a collection of scalar type.
   *
   * @param name name of the parameter.
   * @param parent the parent definition of this object.
   * @param javaType java type of the parameter.
   * @param elementJavaType java type of each collection element.
   */
  public ParamDef(
    String name,
    OperationDefinition parent,
    String javaType,
    String elementJavaType)
  {
    this(name, javaType, parent, true);
    mIsScalarCollection = true;
    mStruct = new StructureDef(name, this);
    AttributeDef elementAttrDef = new AttributeDef("element", mStruct, elementJavaType);
    ((StructureDef)mStruct).addAttribute(elementAttrDef);
  }
   
  /**
   * Creates a complex paramter.
   *
   * @param name name of the parameter.
   * @param def the complex definition of this paramter.
   * @param parent the parent definition of this object.
   * @param isCollection true if this parameter is a collection
   */
  public ParamDef(
    String name, 
    StructureDefinition def, 
    OperationDefinition parent, 
    boolean isCollection)
  {
    // TODO: revisit callers to see if they are passing the correct isCollection flag
    this(name, def, parent, isCollection, false);
  }
   
  /**
   * Creates a complex paramter.
   * This constructor can be used for creating definition for a parameter
   * that is a collection of a scalar type.
   *
   * @param name name of the parameter.
   * @param def the complex definition of this paramter.
   * @param parent the parent definition of this object.
   * @param isCollection true if this parameter is a collection
   * @param isScalarCollection indicates if the accessor is a collection of scalars.
   */
  public ParamDef(String name, StructureDefinition def, OperationDefinition parent, boolean isCollection,
                  boolean isScalarCollection)
  {
    // TODO: revisit callers to see if they are passing the correct isCollection flag
    this(name, parent);
    mStruct = def;

    // store the java type name as the full name of the structure.
    if (mStruct != null)
    {
      mJavaType = mStruct.getFullName();
    }

    mIsCollection = isCollection;
    mIsScalarCollection = isScalarCollection;
  }

  ///////////////////////////// Impl of the interfaces /////////////////////////

  // Implementation of oracle.binding.meta.NamedDefinition

  public final String getName()
  {
    return mName;
  }

  public final Definition getDefinitionParent()
  {
    return mParent;
  }

  public final String getFullName()
  {
    return getName();
  }

   public Object getProperty(String propertyName)
   {
      return null;
   }

   public Hashtable getProperties()
   {
      return null;
   }

   // Implementation of oracle.binding.meta.VariableDefinition

   public final String getJavaTypeString()
  {
    return mJavaType;
  }

   public DataControlDefinition getDataControlDefinition()
   {
      if (mParent != null)
      {
         return mParent.getDataControlDefinition();
      }
      return null;
   }
   
   public int getDefinitionType()
   {
      return TYPE_PARAMETER;
      /* alai changed to always return TYPE_PARAMETER on 3/30/05
      if (mIsCollection)
      {
         return TYPE_COLLECTION;
      }
      else if (mStruct != null)
      {
         return TYPE_OBJECT;
      }
      else
      {
         return TYPE_PRIMITIVE;
      }
      */
   }

   // Implementation of oracle.binding.meta.ParameterDefinition

  public final boolean isStructured()
  {
    if (mStruct != null)
    {
      return true;
    }
    return false;
  }

  public final StructureDefinition getStructure()
  {
    return mStruct;
  }

  public final boolean isCollection()
  {
    return mIsCollection;
  }

  public boolean isScalarCollection()
  {
    return mIsScalarCollection;
  }

   //////////////////////////// Public Methods //////////////////////////////////

  /**
   * Sets a parent to this definition.
   */
  public void setParent(OperationDefinition parent)
  {
    mParent = parent;
  }

}
