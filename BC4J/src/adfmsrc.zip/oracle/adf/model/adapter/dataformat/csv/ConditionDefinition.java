/* $Header: ConditionDefinition.java 05-nov-2005.11:17:22 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
    jfwang      08/10/05 - 
    jfwang      02/14/05 - jfwang_csvfiltering
    jfwang      02/14/05 - Creation
 */

/**
 *  @version $Header: ConditionDefinition.java 05-nov-2005.11:17:22 rvangri Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.model.adapter.dataformat.csv;

/**
 * A ConditionDefinition class.
 *
 * Defines a filter condition.
 *
 */
public class ConditionDefinition 
{
  /* These variables are for elements under condition element. */
  private String mColumn;
  private String mOperator;
  private String mValue;
  private String mType;
  private String mFormat;

  ///////////////////////// Construction /////////////////////////
  
  /**
   * Constructs and initializes a new ConditionDefinition object.
   * @param columnName column name for the condition
   * @param operator condition operator
   * @param value condition limit
   */
  public ConditionDefinition(String columnName, String operator, String value)
  {
    mColumn = columnName;
    mOperator = operator;
    mValue = value;
  }


  ///////////////////////// Members /////////////////////////

  /**
   * Public accessor for column attribute.
   *           
   */
  public String getColumn()
  {
    return mColumn;
  }
  /**
   * Sets the value of the column attribute. 
   *
   * @param s Value for column is passed
   */
  public void setColumn(String s) 
  {    
    mColumn = s;
  }
  
  /**
   * Public accessor for type attribute.
   *           
   */
  public String getType()
  {
    return mType;
  }
  /**
   * Sets the value of the type attribute. 
   *
   * @param s Value for type is passed
   */
  public void setType(String s) 
  {    
    mType = s;
  }
  
  /**
   * Public accessor for format attribute.
   *           
   */
  public String getFormat()
  {
    return mFormat;
  }
  /**
   * Sets the value of the type attribute. 
   *
   * @param s Value for format is passed
   */
  public void setFormat(String s) 
  {    
    mFormat = s;
  }
  
  /**
   * Public accessor for operator attribute.
   *           
   */
  public String getOperator() 
  {
    return mOperator;
  }
  /**
   * setOperator sets the value of the operator attribute. 
   *
   * @param s Value for operator is passed
   */
  public void setOperator(String s) 
  {    
    mOperator = s;
  }
  /**
   * public accessor for value attribute.
   *           
   */
  public String getValue()
  {
    return mValue;
  }
  /**
   * setValue sets the value of the value attribute.
   *
   * @param s value for value operator is passed
   */
  public void setValue(String s) 
  {    
    mValue = s;
  }
}
