/*
 * @(#)DOMDataHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat.xml;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import oracle.xml.parser.schema.XMLSchema;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLAttr;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLNode;
import oracle.xml.parser.v2.XMLParser;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.dataformat.FormatDataHandler;

/**
 * Retrieves data from an XML DOM tree.
 *
 * @see oracle.adf.model.adapter.dataformat.XMLHandler
 */
public class DOMDataHandler implements FormatDataHandler
{
  // Root node of the data
  private Node mData;

  public DOMDataHandler(Node nd)
  {
    mData = nd;
  }
  
  /**
   * Returns the resulting data extracted from the input.
   * @param properties parameters passed containing the context information.
   * @return <code>Iterator</code> of <code>Map</code> objects for the result.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other 
   *         <code>Map</code>s as well.
   * @exception AdapterException 
   */
  public Iterator getResult(Map properties)
  {
    if (mData == null)
      return null;
    
    return getResult(mData);
  }
  
  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containing the context information.
   * @param returnType data type of the returned value. This can be passed as null.
   *        If no return type is specified, an Iterator of Map will be returned.
   * @return Object of the type defined by the <code>returnType</code> parameter.
   *         If the type is available, an instance of that object is created. If no
   *         type is specified an <code>Iterator</code> of <code>Map</code> objects 
   *         for the result will be created.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other 
   *         <code>Map</code>s as well.
   */
  public Object getResult(Map params, String returnType)
  {
    return getResult(params);
  }
  
  
  //////////////////////////// Class Helper ////////////////////////////////////
  
  /**
   * Returns the result of the execution
   * 
   * @param root Root node of the XML scrap whose result is required.
   * @return An <code>Iterator</code> consisting of <code>Map</code> s
   *         each representing a data row.
   * @exception AdapterException 
   */
  private Iterator getResult(Node root)
  {
    try
    {
      List resultList = new ArrayList();
      Map resultMap = new HashMap();
      resultList.add(resultMap);
    
      Node childNode = root.getFirstChild();
      
      // The node does not have child nodes
      if (childNode == null)
        resultList.iterator();
      
      List childList = new ArrayList();
      Map childMap = new HashMap();
      
      resultMap.put(childNode.getNodeName(), childList);
      childList.add(childMap);
      
      parseXML(childNode, resultMap, childMap);

      return resultList.iterator();
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }    
  }
  
  
  /**
   * Recursively parses the XML document and builds the output data structure.
   * 
   * @param node XML node that needs to be parsed
   * @param parentMap Parent's <code>Map</code>. All siblings of the node
   *          will be added to this map.
   * @param thisMap <code>Map</code> of this node. All children of this node
   *          will be added to this map.
   */
  private void parseXML(Node node, Map parentMap, Map thisMap)
  {
    // Add attributes of this node
    addAttributes(node, thisMap);
    
    //
    // If this node has child nodes, recurse into it.
    //
    Node child = node.getFirstChild();
    
    if (child != null)
    {
      short childType = child.getNodeType();
      
      switch (childType)
      {
        case Node.CDATA_SECTION_NODE:
        case Node.TEXT_NODE:
          String childName = child.getParentNode().getNodeName();
          thisMap.put(childName, child.getNodeValue());

          Node nextChild = child.getNextSibling();
          child = nextChild;

          if (nextChild == null)
            break;

          //FALLTHROUGH

        default:
          childName = child.getNodeName();
          List childList;

          if (thisMap.containsKey(childName) == false)
            thisMap.put(childName, childList = new ArrayList());
          else
            childList = (List) thisMap.get(childName);

          Map childMap = new HashMap();
          childList.add(childMap);

          parseXML(child, thisMap, childMap);
          break;
      }
    }
    else
    {
      // Do nothing.
    }

    
    //
    // If this node has a sibling node, recurse into it.
    //
    Node sibling = node.getNextSibling();
    
    if (sibling != null)
    {
      short siblingType = sibling.getNodeType();
      
      switch (siblingType)
      {
        case Node.CDATA_SECTION_NODE:
        case Node.TEXT_NODE:
          String siblingName = sibling.getParentNode().getNodeName();
          parentMap.put(siblingName, sibling.getNodeValue());
          break;

        default:
          List siblingList;
          siblingName = sibling.getNodeName();

          if (parentMap.containsKey(siblingName) == false)
            parentMap.put(siblingName, siblingList = new ArrayList());
          else
            siblingList = (ArrayList) parentMap.get(siblingName);

          Map siblingMap = new HashMap();
          siblingList.add(siblingMap);
          parseXML(sibling, parentMap, siblingMap);
          break;
      }
    }
    else
    {
      // While unwinding from the recursive call, convert all the instances of
      // ArrayList contained in the Map to Iterator.
      Iterator keys = parentMap.keySet().iterator();
      
      while (keys.hasNext())
      {
        String key = (String) keys.next();
        Object object = parentMap.get(key);
        
        if (object instanceof ArrayList)
          parentMap.put(key, ((ArrayList) object).iterator());
      }
    }
  }

  
  /**
   * Adds attributes of a given <code>Node</code> to the <code>Map</code>.
   * @param node XML Node whose attributes have to be retrieved.
   * @param row Map into which the attributes are added.
   */
  private void addAttributes(Node node, Map row)
  {
    //  Obtain the attributes of this element
    
    NamedNodeMap attrs = node.getAttributes();
    
    if (attrs != null)
    {
      for (int i = 0; i < attrs.getLength(); i++)
      {
        XMLAttr attr = (XMLAttr) attrs.item(i);
        row.put(attr.getNodeName(), attr.getNodeValue());
      }
    }
  }


  //////////////////////////////  Test Harness /////////////////////////////////

  /**
   * Test harness method.
   */
  public static void main(String []args)
  {
    if (args.length < 2)
      return;

    try
    {
    }
    catch (AdapterException e)
    {
      System.out.println(e.getErrorCode());
    }
  }
  
}
