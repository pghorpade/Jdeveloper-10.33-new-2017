/* $Header: FormatDataEventListener.java 14-aug-2006.13:18:24 armukher Exp $ */

/* Copyright (c) 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    armukher    08/11/06 - Creation
 */
package oracle.adf.model.adapter.dataformat;
 
/**
 * Data format event listners listens to different events a data format handler
 * can raise during data access; e.g. end of data etc. Listners can be 
 * registered for different data format handlers if they support it. 
 * 
 * A data format handler can support streaming fetch. I.e. the data can only be 
 * fetched on demand from the common ADF runtime. Listeners can be useful tools
 * to maintain connections etc. that needs to know the state of data access.
 * 
 * @version $Header: FormatDataEventListener.java 14-aug-2006.13:18:24 armukher Exp $
 * @since   10.1.3.1
 * @see oracle.adf.model.adapter.dataformat.FormatDataEvent
 * @see oracle.adf.model.adapter.dataformat.FormatDataHandler
 */
public interface FormatDataEventListener
{
  /**
   * Listens to different events of data access. Evenrtts are difined by the 
   * data format handlers in question.
   * 
   * @param event data access event as thrown by a data format handler.
   * @param data data associated to this event.
`   */
  public void onEvent(FormatDataEvent event); 
}