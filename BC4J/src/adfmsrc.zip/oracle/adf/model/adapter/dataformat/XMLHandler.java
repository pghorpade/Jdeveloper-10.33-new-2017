/*
 * @(#)XMLHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Constructor;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;
import java.util.logging.Level;
import java.util.Calendar;
import java.util.Date;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.model.adapter.dataformat.xml.SchemaParser;
import oracle.adf.model.adapter.dataformat.xml.TypeMap;
import oracle.adf.model.adapter.utils.Utility;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XSDConstantValues;
import oracle.xml.parser.schema.XSDTypeConstants;
import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLAttr;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLDocumentFragment;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XMLNode;
import oracle.xml.parser.v2.XSLException;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;

import oracle.jbo.format.DefaultDateFormatter;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * The <code>XMLHandler</code> class XML data formats. XML handler can extract
 * data from an XML data stream.
 * <p>
 *   Since the way <code>XSDHandler</code> class handles the leaf element, we
 *   handle it in the corresponding way:
 *   Example 1:
 *    <company>
 *     <dept>Sales Departments </dept>
 *    </company>
 *
 *    The text node: Sales Departments is added to
 *    parent map(Key: dept, value: Sales Deparements)
 *
 *    Example 2:
 *     <company>
 *       <dept no="10">Sales Departments</dept>
 *     </company>
 *
 *   The text node: Sales Departments are mapped to _text attribute for dept
 *   element.
 * </p>
 *
 */
public class XMLHandler implements FormatDataHandler
{
  // Root node of the data
  private Node mDataNode;
  
  // This is the root reference node from which href=#ID need to be resolved
  // for webservices this will be the SOAP body node. 
  // the SOAP body may have #ref's for content appearing later in the 
  // payload which needs to be resolved.
  private Node mReferenceRoot = null;
  
  // Lookup map for the ID's. Map created to optimize performance and 
  // avoid iteration when handling every node.
  private Map mReferenceMap = null;
  
  //The document for the XML data being handled
  private Document mDoc = null;

  // input stream
  private InputStream mDataStream;

  //input schema stream
  private InputStream mXsdStream;

  //input InputStream mXsltStream;
  private InputStream mXsltStream;

  private ADFLogger _logger = AdapterContext.getDefaultContext().getLogger();

  // data event listener
  private FormatDataEventListener mEventListener = null;

  /** End of data event. */
  public static final String EV_EOD = "__ev_eod__";          

  //===========================================================================
  //   Some public constants
  //==========================================================================
  // client key to provide the reference root for this handler
  public static final String REFERENCE_ROOT  = "ReferenceRoot";
  
  //===========================================================================
  // Private constants 
  //===========================================================================
                          
  // The href attribute to reference node ID.
  // href = #id.
  private static final String HREF         = "href";
  // ArrayItem in a collection
  private static final String ARRAY_ITEM   = XSDHandler.ARRAY_ITEM;
  
  //===================================================================== 
  // WebService Specific constants
  //=====================================================================
  
  // SOAP Array Type node.
  private static final String SOAP_ARRAY_TYPE = "arrayType";      
  // SOAP arrayType 
  private static final String SOAP_ARRAY      = "Array";

  private static final String SOAP_ENC_NS     = 
                                 "http://schemas.xmlsoap.org/soap/encoding";

  // performance sensors
  private static Timer sInitTimer = Timer.createTimer(Level.FINER,
                          "/oracle/adf/model/adapter/dataformat/XMLHandler",
                          "init",
                          "Instantiating the XMLHandler ");
  private static Timer sGetSimpleResultTimer = Timer.createTimer(Level.FINER,
                          "/oracle/adf/model/adapter/dataformat/XMLHandler",
                          "getSimpleResult",
                          "Fetching the result for simple type");
  private static Timer sGetComplexResultTimer = Timer.createTimer(Level.FINER,
                          "/oracle/adf/model/adapter/dataformat/XMLHandler",
                          "getComplextResult",
                          "Creating the collection iterators for complex data");
  private static Timer sHandleSoapTimer = Timer.createTimer(Level.FINER,
                          "/oracle/adf/model/adapter/dataformat/XMLHandler",
                          "handleSoapEncodedCollections",
                          "Creating collection iterator for array");
                          
  //////////////////////////// Constructors ////////////////////////////////////
  /**
   * Creates a data handler for XML data type.
   * @param is input stream of the data.
   * @param supportStreaming if to support the streaming fetch of the data.
   *        If this value is false, the XML data is loaded as a DOM tree.
   * @exception AdapterException if falis to load the DOM tree from the
   *            input stream.
   */
  public XMLHandler(InputStream is, boolean supportStreaming)
  {
    supportStreaming = false; // ToDo: delete when support streaming fetch
    try
    {
      if (supportStreaming)
      {
        mDataStream = is;
      }
      else
      {
        parseDataStream(is, null);
      }
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }


  /**
   * Creates a data handler for XML data type.
   * @param is input stream of the data.
   * @param xsltStream stream of the xslt definition
   * @param supportStreaming if to support the streaming fetch of the data.
   *        If this value is false, the XML data is loaded as a DOM tree.
   * @exception AdapterException if falis to load the DOM tree from the
   *            input stream.
   */
  public XMLHandler(InputStream is, 
                    InputStream xsltStream,boolean supportStreaming)
  {
    supportStreaming = false; // ToDo: delete when support streaming fetch
    try
    {
      if (supportStreaming)
      {
        mDataStream = is;
      }
      else
      {
        parseDataStream(is, xsltStream);
      }
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Creates an XML data handler for a DOM node.
   * @param root the root node of the data.
   */
  public XMLHandler(Node root)
  {
    mDataNode = root;
  }
  
  /**
   * Instantiate this XMLHandler for the root node and an optional
   * transformation to be applied on the root node.
   *
   * @param root The root data node for this format handler instance
   * @param xslTransform The Transformation Reader that references the 
   *                     XSL transformation to be applied on this root 
   *                     node.
   * 
   * @throws {@link AdapterException} if the transformation cannot be 
   *         applied on the root node.
   */
  public XMLHandler(Node root, Reader xslTransform) throws AdapterException
  {
    try
    {
      sInitTimer.start();

      mDataNode = root;
    
      // if we have a XSL transformation to be done..
      if(xslTransform != null)
      {
        XSLProcessor xslProc = new XSLProcessor();
        XMLDocumentFragment transNode = null;
        
        // create a style sheet from that URL.
        XSLStylesheet xss = xslProc.newXSLStylesheet(xslTransform);
        if(root instanceof XMLElement)
        {
          transNode = xslProc.processXSL(xss, (XMLElement)root);
          // if we had a valid transformation.
          if(transNode != null)
            mDataNode = transNode.getFirstChild();
            
          _logger.finest("Dumping Transformed node structure for : " 
                                          + mDataNode.getNodeName());
          dumpNode(mDataNode);
        }
      }
      
      sInitTimer.stop();
    }
    catch(XSLException xe)
    {
      _logger.severe("Failed to create style sheet due to : " +
                       xe.getMessage());
      throw new AdapterException(xe);
    }
    finally
    {
      sInitTimer.cleanup();
    }
  }

  /**
   * Sets the data event listener.
   */
  public void setDataEventListener(FormatDataEventListener listener)
  {
    mEventListener = listener;
  }


  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containig the context information.
   * @param returnType data type of the returned value. This can be passed as null.
   *        If no return type is specified, an Iterator of Map will be returned.
   * @return Object of the type defined by the <code>returnType</code> parameter.
   *         If the type is available, an instance of that object is created. If no
   *         type is specified an <code>Iterator</code> of <code>Map</code> objects
   *         for the result will be created.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other
   *         <code>Map</code>s as well.
   */
  public Object getResult(Map params, String returnType)
  {
    if(returnType == null)
    {
      // We'll return a collection to contain the result iterator
      List list = getResult(params);
      if (list == null)
      {
        list = new ArrayList();
      }
       return new DataCollection(list);
    }

    Object result = null;
    String retVal = null;

    final String _DATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    
    try
    {
      sGetSimpleResultTimer.start();
      // get the value of the leaf node from this response
      // XML structure
      retVal = parseXML(mDataNode);

      if(retVal == null || retVal.length() == 0) 
       return null;

      // Map this XSD type to a java return type.
      String retClassName = TypeMap.getJavaType(returnType);

      if(retClassName.equals("java.lang.String") ||
         retClassName.equals("java.lang.Object") || 
         retClassName.equals("byte[]") || 
         returnType.equals(XSDConstantValues._any))
      {
        result = retVal;
      }
      // Dates ??? 
      else if(returnType.equals(XSDTypeConstants.DATE_TIME) || 
              returnType.equals(XSDTypeConstants.TIME))
      {
        // We don;t really know what format the XSD date is comming in...
        // So lets us try for the complete format, which is usually the case, 
        // incase the parsing of the string to a date instance fails
        // return the string instance of the date as is. The 
        // client can convert the string instance of the date to the required
        // format.

        SimpleDateFormat format = new SimpleDateFormat(_DATEFORMAT);
        String dateStr = retVal;

        //yyyy-MM-ddTHH:mm:ss.SSS  
        // this is 23, the Z stands for time zone which is the 24th character 
        // for XSD it is defined as +(-)hh:mm but java needs to be +(-)hhmm.
        if(retVal.length() > 23)
        {
	  char timeZoneOffset = retVal.charAt(23);
          if(timeZoneOffset == '+' || timeZoneOffset == '-')
	  { 
            StringBuffer sbuf = new StringBuffer(retVal);
            sbuf.deleteCharAt(dateStr.length() - 3);
            dateStr = sbuf.toString();
	  }
        }

        result = format.parse(dateStr, new ParsePosition(0));
      }
      // Calendar
      else if(returnType.equals(XSDTypeConstants.DATE))
      { 
        try
        {
	  Class calClass = Class.forName("java.util.Calendar");
           
          Class retTypeClass = Class.forName(retClassName);
          Constructor constructor =
                 retTypeClass.getConstructor(new Class[0]);

          if(constructor != null)   
          {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            
            Date thisDate = format.parse(retVal, new ParsePosition(0));

            //For all subclasses of the calendar.... 
            // see if we can build this instance.
            Object calInstance = constructor.newInstance(new Object[0]);
        
            /// We Have a calendar instance 
            if(calInstance != null && thisDate != null && 
               calClass.isInstance(calInstance))
            {
              ((Calendar)calInstance).setTime(thisDate); 
              result = calInstance;
            }          
	  }
        }
        catch(Exception ex)
        {
          result = null;
          _logger.fine("Error :> " + ex.toString() + " encountered Converting the return "+
                         "value to type: " + retClassName); 
	}
      }
      else // Numeric and Boolean types
      {
        try
        {
          Class returnTypeClass = Class.forName(retClassName);
          // Most of the Java basic type classes can be instantiated
          // with a String representation of the corresponding value.
          // so we will try and pick that constructor. If this is a
          // valid type, then an instance is created successfully.
          Constructor constructor =
                   returnTypeClass.getConstructor(new Class[]{String.class});

	  if(constructor != null)
          {
            // create the result instance.
            result = constructor.newInstance(new Object[]{retVal});
	  }
	}
        catch(Exception e)
        {
          result = null;   
          _logger.fine("Error :> " + e.toString() + " encountered Converting the return "+
                         "value to type: " + retClassName); 
	}
      }
            
      sGetSimpleResultTimer.stop();
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
    finally
    {
      sGetSimpleResultTimer.cleanup();    

      // we operate on the DOM tree .. so no need to cache the stream.
      XMLDataEvent event = new XMLDataEvent(EV_EOD);
      event.sendEvent(mEventListener);
    }

    // We did not have any result ... .return as is ..
    if(result == null) 
      result = retVal;

    return result;
  }

  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containig the context information.
   * @return <code>Map</code> objects for the result.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other iterator of
   *         <code>Map</code>s as well.
   */
  public List getResult(Map params)
  {
    if (mDataNode == null)
    {
      return null;
    }

    List resultList = new ArrayList();
    Map resultMap = new HashMap();
    resultList.add(resultMap);
    
    try
    {
      sGetComplexResultTimer.start();
      // Set up the root Reference node . For webservices this will be 
      // the SOAP body node. 
      // See if the caller has supplied the Reference Root 
      mReferenceRoot = (Node)params.get(REFERENCE_ROOT);
      // Set up the owner document.
      mDoc = mDataNode.getOwnerDocument();
      // set up the reference map, this is a fast look up map for 
      // fetching ID's vs Nodes.
      if (mReferenceRoot != null) // to avoid NULLPOINT exception
      {
        prepareReferenceMap();
      }
      
      Node childNode = getFirstChild(mDataNode);

      // The node does not have child nodes
      if (childNode == null)
      {
        return resultList; //.iterator();
      }

       // handle SOAP collections.
      if(isNodeSOAPEncodedCollection(mDataNode))
      {
        handleSoapEncodedCollections(mDataNode, resultMap);
      }
      else
      {
        short childType = childNode.getNodeType();
        
        if (childType == Node.TEXT_NODE)
        {
          resultMap.put(mDataNode.getLocalName(), childNode.getNodeValue());
        } 
        else
        {
          // add root node in the map      
          List rootList = new ArrayList();
          Map rootMap = new HashMap();
             
          resultMap.put(getNormalizedName(mDataNode.getLocalName()), rootList);
          rootList.add(rootMap);
             
          // add first child
          List childList = new ArrayList();
          Map childMap = new HashMap();
            
          rootMap.put(getNormalizedName(childNode.getLocalName()), childList);
             
          childList.add(childMap);
             
          parseXML(childNode, rootMap, childMap);
          
          // convert all the lists to iterators;
          convertToCollection(rootMap);
        }
      }
      
      sGetComplexResultTimer.stop();
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
    finally
    {
      sGetComplexResultTimer.cleanup();

      // we operate on the DOM tree .. so no need to cache the stream.
      XMLDataEvent event = new XMLDataEvent(EV_EOD);
      event.sendEvent(mEventListener);
    }
 
    return resultList; //.iterator();
  }

  /**
   * Parses XML stream.
   * @param is input stream of the data.
   * @param xsltStream stream of the xslt definition
   * @exception AdapterException if falis to load the DOM tree from the
   *            input stream.
   */
  private void parseDataStream(InputStream inXML, 
                               InputStream xsltStream)
  {
    try
    {
      InputStream parsedXML = inXML;
      if (xsltStream != null) 
      {          
        XSLStylesheet xsltFilter = new XSLStylesheet(xsltStream, null);
        BufferedInputStream bis = new BufferedInputStream(inXML);
        // Get the XMLDocument object
        DOMParser parser  = new DOMParser();
        parser.setPreserveWhitespace(false);
        parser.setAttribute(oracle.xml.parser.v2.XMLParser.STANDALONE, 
                              Boolean.TRUE);
        parser.parse(bis);
        XMLDocument xmlDoc = parser.getDocument();
        bis.close();
        // Now apply the xslt on that
        XSLProcessor processor = new XSLProcessor();
        ByteArrayOutputStream outXml = new ByteArrayOutputStream();
        processor.processXSL(xsltFilter, xmlDoc, outXml);

        ByteArrayInputStream retInStream = 
              new ByteArrayInputStream(outXml.toByteArray());

        outXml.close();

        parsedXML =   retInStream;                    
      }
      DOMParser domParser = new DOMParser();
      domParser.setPreserveWhitespace(false);
      domParser.parse(parsedXML);
      mDataNode = domParser.getDocument().getDocumentElement();
    }
    catch (Exception e)
    {
      _logger.severe("Failed to create the DOM tree for the source. Resaon: " +
                     e.getLocalizedMessage());
      throw new AdapterException(e);
    }
  }

  /**
   * Recursively parses the XML document and builds the output data structure.
   *
   * @param node XML node that needs to be parsed
   * @param parentMap Parent's <code>Map</code>. All siblings of the node
   *          will be added to this map.
   * @param thisMap <code>Map</code> of this node. All children of this node
   *          will be added to this map.
   */
  private void  parseXML(Node node, Map parentMap, Map thisMap)
  {

    processNode(node,parentMap,thisMap);  
    //
    // get all other sibling nodes, process each of them.
    //
    Node sibling = getNextSibling(node);
    while (sibling != null)
    {
      if (sibling != null)
      {
        short siblingType = sibling.getNodeType();

        switch (siblingType)
        {
          case Node.CDATA_SECTION_NODE:
          case Node.TEXT_NODE:
            String siblingName =
                   getNormalizedName(sibling.getParentNode().getLocalName());
            thisMap.put(XSDHandler.LEAFELEMENT_DATA, sibling.getNodeValue());

            break;

          default:
        
          // handle the SOAP encoded collection if this sibling node
          // represents a SOAP array
         if(isNodeSOAPEncodedCollection(sibling))
         {
           handleSoapEncodedCollections(sibling, parentMap);
         }
         else
         {
           List siblingList = null;
           siblingName = getNormalizedName(sibling.getLocalName());

           // Add the List only if the node contains a valid child or has
           // valid attributes.

           Map siblingMap = new HashMap();
           if( getFirstChild(sibling) != null || hasDeclaredAttributes(sibling))
           {
             if (parentMap.containsKey(siblingName) == false)
             {
               parentMap.put(siblingName, siblingList = new ArrayList());
             }
             else
             {
               Object sibVal = parentMap.get(siblingName);
      
               if(sibVal instanceof List)
               {
                 siblingList = (ArrayList)sibVal;
               }
               else
               {
                 // Hit a simple collection .....
                 // update the sibling list to collect all the
                 // members of this collection.
                 siblingList = new ArrayList();
                 HashMap item = new HashMap();
                 item.put(ARRAY_ITEM, sibVal);
                 siblingList.add(item);
                 parentMap.put(siblingName, siblingList);
               }
             }
             siblingList.add(siblingMap);
           }
           processNode(sibling, parentMap, siblingMap);
           break;
         }
        }
      }
      else
      {
      
      }
      
      sibling = getNextSibling(sibling);
    }
  }

  /**
   * process the XMLnode.
   *
   * @param node XML node that needs to be parsed
   * @param parentMap Parent's <code>Map</code>. All siblings of the node
   *          will be added to this map.
   * @param thisMap <code>Map</code> of this node. All children of this node
   *          will be added to this map.
   */  
  private void  processNode(Node node, Map parentMap, Map thisMap)
  {
    // Add attributes of this node, only if this is a normal node.
    if(! isNodeSOAPEncodedCollection(node))
    {
      addAttributes(node, thisMap);
    }
    //
    // If this node has child nodes, recurse into it.
    //
    Node child = getFirstChild(node);

    if (child != null)
    {
      short childType = child.getNodeType();

      switch (childType)
      {
        case Node.CDATA_SECTION_NODE:
        case Node.TEXT_NODE:
          String childName =
                     getNormalizedName(child.getParentNode().getLocalName());

           Object val = parentMap.get(childName);
           
          // if attributes other than implcit namespace attributes
          // exists or not, if implicit name space
          // attributes exist, then this node must be treated as though
          // no attributes exist and becomes a JSR227 attribute.
          if(hasDeclaredAttributes(node))
          {
            thisMap.put(XSDHandler.LEAFELEMENT_DATA, child.getNodeValue());
          }
          else // Is this a a simple 1D XSD collection..
          if(val instanceof List && ((List)val).size() > 1)
          {
            thisMap.put(ARRAY_ITEM, child.getNodeValue());
          }
          else
          {
            parentMap.put(childName, child.getNodeValue());
          }
          Node nextChild = getNextSibling(child);
          child = nextChild;

          if (nextChild == null)
            break;

          //FALLTHROUGH

        default:

          if(isNodeSOAPEncodedCollection(node))
          {
            handleSoapEncodedCollections(node, parentMap);
          }
          else
          {
            childName = getNormalizedName(child.getLocalName());
            List childList = null;

            // Add the List only if the node contains a valid child or has
            // valid attributes.

            Map childMap = new HashMap();
            if(getFirstChild(child) != null || hasDeclaredAttributes(child))
            {
              if (thisMap.containsKey(childName) == false)
              {
               thisMap.put(childName, childList = new ArrayList());
              }
              else
              {
                Object sibVal = thisMap.get(childName);

                if(sibVal instanceof List)
                {
                  childList = (ArrayList)sibVal;
                }
                else
                {
                  // Hit a simple collection ...
                  // remove the item from the map and create 
                  // a new array list for the collection.
                  childList = new ArrayList();
                  HashMap item = new HashMap();
                  item.put(ARRAY_ITEM, sibVal);
                  childList.add(item);
                  // put the list for this childname.
                  thisMap.put(childName, childList);
                }  
              }
              childList.add(childMap);
            }
           
            parseXML(child, thisMap, childMap);
            break;
          }
      }
    }
    else
    {
      // Do nothing
    }
  }
  
  /**
   * Fetch the value of the leaf node , for this XML DOM fragment.
   * This need not be represented in Map / Iterator format
   * Ideally the DOM fragment is expected to be very simple
   *
   * @param node The XML node representing the root of the DOM
   *             fragment.
   *
   * @return The Value of the leaf node for this fragment.
   */
  private String parseXML(Node node)
  {
    // Nothing !! return null..
    if(node == null)
       return null;

    Node child = getFirstChild(node);

    if (child != null)
    {
      // If a Text node is hit return its value.
      if(child.getNodeType() == Node.TEXT_NODE)
         return child.getNodeValue();
      // recurse on descendants...
      return parseXML(child);
    }
    else
     // recurse on siblings.
     return parseXML(getNextSibling(node));
  }

  /**
   * Adds attributes of a given <code>Node</code> to the <code>Map</code>.
   * @param node XML Node whose attributes have to be retrieved.
   * @param row Map into which the attributes are added.
   */
  private void addAttributes(Node node, Map row)
  {
    //  Obtain the attributes of this element
    NamedNodeMap attrs = node.getAttributes();

    if (attrs != null)
    {
      // normalize the attributes before updating them in RSI
      normalizeAttributes(attrs);

      for (int i = 0; i < attrs.getLength(); i++)
      {
        XMLAttr attr = (XMLAttr) attrs.item(i);
        row.put(getNormalizedName(attr.getLocalName()), attr.getNodeValue());
      } 
    }
  }

  /**
   * Get the First Child of a given parent. Strips out any
   * white space text nodes that are siblings of this parent and may
   * get returned as the first child, in a normal node.getFirstChild()
   * call
   *
   * @param parent The Parent Node
   * @return the First non-white space child of this parent.
   */
  private Node getFirstChild(Node parent)
  {
    Node actualParent = resolveRefs(parent);
  
    Node child = actualParent.getFirstChild();

    if(isWhiteSpace(child))
      child = getNextSibling(child);

    return child;
  }

  /**
   * Resolve the references for this node. This node may be a reference to 
   * the actual data node later in the stream. Resolve the reference and fetch
   * the actual node.
   * 
   * @param referenceNode The Node which has href to the actual node in the 
   *                      XML stream.
   * @return the actual Node by resolving the ID referenced by the href 
   *         attribute of the reference node. If no such node is present , the
   *         referenceNode is returned.
   */
  private Node resolveRefs(
   Node referenceNode
  )
  {
    NamedNodeMap attrs = referenceNode.getAttributes();
    String nodeID = null;
    
    // get the href attribute for this node.
    if(attrs != null)
    {
      XMLAttr attr = (XMLAttr)attrs.getNamedItem(HREF);
      if(attr != null)
      {
        nodeID = attr.getNodeValue();
        // the href may begin with #ID1....
        if(nodeID != null && nodeID.charAt(0) == '#')
        {
          nodeID = nodeID.substring(1, nodeID.length());
        }
        // Can the DOM implementation resolve this reference for us.
        Node thisNode = mDoc.getElementById(nodeID);
        if(thisNode == null)
        {
          // The DOM implementation did not have any sort of idea on what 
          // an ID was .. We need to resolve all the href references WRT to 
          // the root Reference Node. 
          thisNode = (Node)mReferenceMap.get(nodeID);
        }
        // A referenced node was found. return that node.
        if(thisNode != null)
         return thisNode;
      }
    }
    return referenceNode;
  }

  /**
   * Create a Fast lookup Map for the Nodes and the associated ID's
   */
  private void prepareReferenceMap()
  {
    mReferenceMap = new HashMap();
    String idVal = null;
    
    NodeList children = mReferenceRoot.getChildNodes();
    // Prepare the reference Map.
    for(int i = 0; i < children.getLength(); i++)
    {
      Node kid = children.item(i);
      NamedNodeMap attrs = kid.getAttributes();
      
      if(attrs != null)
      {
        XMLAttr attr = (XMLAttr)attrs.getNamedItem(XSDConstantValues._id);
        if(attr != null)
        {
          idVal = attr.getNodeValue();
          if(idVal != null)
          {
            mReferenceMap.put(idVal, kid);
          }
        }
      }
    }  
  }


  /**
   * Get the Next non-white space sibling of a given node, which may otherwise
   * be returned on a normal node:getNextSibling() call.
   *
   * @param thisNode The node whose next non-white space sibling is needed
   *
   * @return the First non-white space sibling of this node.
   */
  private Node getNextSibling(Node thisNode)
  {
    Node sibling = thisNode.getNextSibling();

    while(isWhiteSpace(sibling))
     sibling = sibling.getNextSibling();

    return sibling;
  }
  
  /**
   * Make a mundane check if this node is a white space descendent of its
   * parent.
   *
   * @return true If Node represents a white space text node, false otherwise.
   */
  private boolean isWhiteSpace(Node thisNode)
  {
    if(thisNode != null &&
       thisNode.getNodeType() == Node.TEXT_NODE &&
       thisNode.getNodeValue().trim().length() == 0)
      return true;

    return false;
  }

  /**
   * Check if the attributes of this node are the ones
   * declared in the schema , or is it simply name space
   * declaration on this node.
   */
  private boolean hasDeclaredAttributes(Node thisNode)
  {
    NamedNodeMap attrs = thisNode.getAttributes();

    if(attrs == null)
      return false;

    // Normalize and check if there are any valid attributes
    normalizeAttributes(attrs);

    return (attrs.getLength() > 0);
  }

  /**
   * Normalize the attributes, A normalization means here to remove all
   * those attributes that need not be the part of the JSR 227 strcuture
   * that is displayed on the view page.
   * These attributes are implicit name space / data type attributes or any
   * other attributes that are not defined by the schema, but put in
   * implicitly by the XML generator.
   */
  private void normalizeAttributes(NamedNodeMap attrs)
  {
    if(attrs == null)
      return;

    for (int i = 0; i < attrs.getLength();)
    {
      XMLAttr attr = (XMLAttr) attrs.item(i);
      if(shouldRemoveAttribute(attr))
      {
        attrs.removeNamedItem(attr.getNodeName());
      }
      else
        i++;
    }
  }

  /**
   * Check if the attribute is an implicit attribute and must be removed.
   * All namespace and type attributes are implicit and are not needed in the
   * RSI.
   */
  private boolean shouldRemoveAttribute(XMLAttr attr)
  {
    if(attr.getPrefix() != null &&
       attr.getPrefix().equalsIgnoreCase(XSDConstantValues._xmlns))
    {
      return true;
    }

    // Bug 5696086	
    // Ignore namespace attribute with attribute name 'xmlns'
    if(attr.getPrefix() == null && attr.getLocalName() != null) 
    {
        if(attr.getLocalName().equalsIgnoreCase(XSDConstantValues._xmlns))
          return true;
    }

    if(attr.getLocalName() != null && attr.getNamespaceURI() != null)
    {
      if(attr.getLocalName().equalsIgnoreCase(SOAP_ARRAY_TYPE) ||
         attr.getNamespaceURI().equals(SOAP_ENC_NS))

        return true;
    }
    
    if(attr.getLocalName() != null)
    {
      if(attr.getLocalName().equalsIgnoreCase(XSDConstantValues._type))
        return true;

      //Bug 5376910 
      //Attributes of the form xsi:nil needs to be ignored while extracting data
      if(attr.getLocalName().equalsIgnoreCase(XSDConstantValues._nil))
          return true;
    }

    return false;
  }

  /**
   * Normalize the name. Java Keywords, hyphens are names that will get
   * banished by JSR227.
   * Names which are java keywords are initCapped, hyphes are replaced with
   * under scores.
   */
  private String getNormalizedName(String name)
  {
    return Utility.normalizeString(name);
  }
  
  /**
   * Iterate through the list. If any instance in the list entry
   * is a map , fix up the map entries to convert all the lists
   * to iterators.
   */ 
  private void fixUpList(
   List rootList
  )
  {
    Iterator iter = ((ArrayList)rootList).iterator();
    while(iter.hasNext())
    {
      Object listEntry = iter.next();
      if(listEntry instanceof Map)
      {
        convertToCollection((Map)listEntry);
      }
    }
  }
  
  /**
   * convert all the list entries in the map to the 
   * corresponding collections.
   */ 
  private void convertToCollection(Map rootMap)
  {
    // While unwinding from the recursive call, convert all the instances of
    // ArrayList and Maps contained in the Map to collection.
    Iterator keys = rootMap.keySet().iterator();

    while (keys.hasNext())
    {
      String key = (String) keys.next();
      Object object = rootMap.get(key);

      if (object instanceof ArrayList)
      {
        DataCollection coll = new DataCollection((List) object);
        rootMap.put(key, coll);
        fixUpList((List) object);  
      }
      else if(object instanceof Map)
      {
        DataCollection coll = new DataCollection((Map) object);
        rootMap.put(key, coll);
        convertToCollection((Map)object);
      }
    }
  }
  
//============================================================================
//  WebService Data control Specific API's to handle SOAP encoded collections
//============================================================================
  
  /**
   * Handle SOAP encoded collections , if this node is a SOAP array. SOAP 
   * collection for any N dimension are handled. All the dimensions are 
   * flattened out into a single iterator , so that the view can display
   * this collection as a table.
   * 
   * @param collectionNode The Node in the payload whose contents are SOAP 
   *                       Encoded collection.
   * @param parentMap      The parent Map which will recieve the list of map
   *                       for this collection
   */
  private void handleSoapEncodedCollections(
   Node collectionNode, 
   Map parentMap
  )
  {
    try
    {
      // get the collection name
      String collectionName = getNormalizedName(collectionNode.getLocalName());
      
      sHandleSoapTimer.start();
      
      
      _logger.finer("Creating collection for SOAP encoded array: " 
                                                 + collectionName);
      // new list to hold the entire collection.
      ArrayList collectionList = new ArrayList();
      // update the parent map for this collection.
      parentMap.put(collectionName, collectionList);
      Node arrayItemNode = getFirstChild(collectionNode);    
      // recursively collect each dimension starting from the top.
      collectThisDimension(arrayItemNode, parentMap, collectionList);   
      
      sHandleSoapTimer.stop();
        
      _logger.finer("Array has " + collectionList.size() + " items");
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      sHandleSoapTimer.cleanup();
    }
  }

  /**
   * Recursively collect each dimension for this arrayItem node. 
   * The arrayItem node could be the toplevel node for a nested N dimension 
   * array. Each dimesnion is flattened out into a single list of maps.
   * 
   * @param arrayItemNode  The topLevel Array item node.
   * @param parentMap      The parent map in which the list is to be placed
   * @param collectionList The collection list to collect data for each 
   *                        dimension.
   */
  private void collectThisDimension(
   Node arrayItemNode, 
   Map parentMap,
   List collectionList
  )
  {
    _logger.finer("Collecting items for each dimension of the SOAP Array");
    
    while(arrayItemNode != null)
    {
      // fetch the item val for this array item
      Node itemVal = getFirstChild(arrayItemNode);
      // This is a array item. start of the nested dimension. 
      // recurse until the last dimension is reached.
      if(isNodeSOAPArrayItem(itemVal))
      {
        collectThisDimension(itemVal, parentMap, collectionList);
      }
      // we have reached the bottom most dimension.
      else
      {
       // begin adding to the collection.
        Map itemMap = new HashMap();
        collectionList.add(itemMap);
        // Array of simple Types
        if(itemVal.getNodeType() == Node.CDATA_SECTION_NODE ||
           itemVal.getNodeType() == Node.TEXT_NODE)
        {
          itemMap.put(ARRAY_ITEM, itemVal.getNodeValue());
        }
        //collection of complex types.
        else
        {
          // resolve if this is a reference. 
          Node actualItemNode = resolveRefs(arrayItemNode);
          NamedNodeMap attrs = actualItemNode.getAttributes();
          // remove the ID attribute, clashes if there is another
          // child element by name ID.
          if(attrs.getNamedItem(XSDConstantValues._id) != null)
          {
            attrs.removeNamedItem(XSDConstantValues._id);
          }
          // call back to parse this node as a normal element node.   
          parseXML(actualItemNode, parentMap, itemMap);
          
          _logger.finer("Collected " + collectionList.size() 
                                              + " items for this dimension");
        }
      }
      // fetch the next item in this array.
      arrayItemNode = getNextSibling(arrayItemNode);
    }
  }

  /**
   * Test if the node is a SOAP array item
   * 
   * @param thisNode The node to be tested
   * @return <code>true</code> if the node represents a SOAP array item. 
   *         <code>false</code>otherwise.
   */
  private boolean isNodeSOAPArrayItem(Node thisNode)
  {
    return (
            thisNode != null && 
            thisNode.getNodeType() == Node.ELEMENT_NODE && 
            thisNode.getLocalName().equalsIgnoreCase(ARRAY_ITEM) 
           );
  }

  /**
   * Test if this Node is a soap encoded collection. 
   * 
   * @param thisNode The Node to tested 
   * @return <code>true</code> if this node represents a SOAP encoded 
   *         collection, <code>false</code> otherwise.
   */
  private boolean isNodeSOAPEncodedCollection(Node thisNode)
  {
    Node collectionNode = resolveRefs(thisNode);
    NamedNodeMap attrs = collectionNode.getAttributes();
   
    if(attrs != null)
    {
      XMLAttr attr = (XMLAttr)attrs.getNamedItemNS(XSDConstantValues.XSIRECNS, 
                                                   XSDConstantValues._type);
      String type = null;
      
      if(attr != null)
      {
        type = attr.getNodeValue(); 
      }
      // if the Namespace is older than one pointed by the constant value,
      // then processing the Array will fail. In this case the backup is 
      // to manually iterate over the attributes and see if the type 
      // is a SOAP array ; irrespective of the name space.
      else
      {
        for(int i = 0; i < attrs.getLength(); i++)
        {
          attr = (XMLAttr)attrs.item(i); 
          String name = attr.getLocalName();
          
          if(name != null && name.equalsIgnoreCase(XSDConstantValues._type))
          {
            type = attr.getNodeValue();
            break;
          } 
        }
      }
      
      // If there is a type.. 
      if(type != null)
      {
        // Take out the prefix.
        int idx = type.indexOf(':');
        if(idx > 0)
        {
          type = type.substring(idx + 1, type.length());
        }
        // check if the type is a SOAP array.
        return type.equals(SOAP_ARRAY);
      }
      
      return false;
    }
    
    return false;
  }

  //=================================================================
  // -- private API's to dump node structure to logger
  //=================================================================
  private void dumpNode(Node thisNode)
  {
    try
    {
      if(thisNode instanceof oracle.xml.parser.v2.XMLNode)
      {
        XMLNode writableNode = (XMLNode)thisNode;
        java.io.ByteArrayOutputStream bos = 
                         new java.io.ByteArrayOutputStream();
        writableNode.print(bos);
        String nodeStr = bos.toString();
        _logger.finest(nodeStr);
        bos.close();
      }
    }
    catch(Exception e)
    {
      // don;t care ....
    }
  }



  //============================================================================
  // Representing a collection that creates the data iterator on request.
  //============================================================================

  /**
   * Provides a collection on top of the Map or List objects. This class will
   * implement the <code>getIterator</code> to return the iterators from the
   * underlying object.
   * <p>
   * ADF RT expects a collection to get an iterator for the return data set. We
   * can return an iterator itself instead of the collection, but the iterators
   * are uni-directional and that can not support the use cases for master-detail 
   * from the same result set.
   * 
   */
  private class DataCollection extends AbstractCollection
  {
    private Map _map = null;
    private List _list = null;

    private DataCollection(Map map)
    {
      _map = map;
    }

    private DataCollection(List list)
    {
      _list = list;
    }

    public Iterator iterator()
    {
      if (_list != null)
      {
        return _list.iterator();
      }

      if (_map != null)
      {
        return _map.values().iterator();
      }

      return null;
    }

    public int size()
    {
      if (_list != null)
      {
        return _list.size();
      }

      if (_map != null)
      {
        return _map.size();
      }

      return 0;
    }
  }


  /**
   * Event that the CSV handler sends during processing csv data.
   */
  public class XMLDataEvent extends FormatDataEvent
  {
    public XMLDataEvent(String name)
    {
      super(name, null);
    }
  }
}
