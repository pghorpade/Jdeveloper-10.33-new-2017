/*
 * @(#)AttributeDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter.dataformat;

import java.util.Map;
import java.util.Iterator;
import java.util.Hashtable;

import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.Definition;
import oracle.binding.meta.NamedDefinition;
import oracle.adf.model.utils.SimpleStringBuffer;
import oracle.binding.metaimpl.BaseAttributeDefinition;

/**
 * Implements an attrtibute.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class AttributeDef extends BaseAttributeDefinition
{
  
  public static final String LEAFELEMENT_HINT        = "LeafElement_hint";
  public static final String LEAFELEMENT_NO_ATTRIBUTE   = "LeafElement_no_attribute";
  public static final String LEAFELEMENT_WITH_ATTRIBUTE   = "LeafElement_with_attribute";
  
  /** Stores custom properties as needed by the XML Schema handler */
  /* alai 8/1/05 changed mProps from Map for new NamedDefinition method
                 getProperties() */
  private Hashtable mProps = new java.util.Hashtable(15);

  // Displayable name
  private String mName;

  // bind path
  private String mBindPath = null;

  //////////////////////////// Constructors ////////////////////////////////////

  /**
   * Creates an attribute definition.
   *
   * @param name name of this attribute.
   * @param parent parent of this attribute.
   * @param javaType equivalent Java type of this attribute
   *                 (e.g. java.lang.String).
   * @param isReadOnly flag to determine if the value of this attribute is
   *                   read-only.
   * @param isKey flag to indicate if the attribute is a key.
   */
  public AttributeDef(
    String name,
    StructureDefinition parent,
    String javaType,
    boolean isReadOnly,
    boolean isKey)
  {
    super(name, parent, javaType, isReadOnly, isKey);
  }

  /**
   * Creates an attribute definition.
   *
   * @param name name of this attribute.
   * @param parent parent of this attribute.
   * @param javaType equivalent Java type of this attribute
   *                 (e.g. java.lang.String).
   */
  public AttributeDef(
    String name,
    StructureDefinition parent,
    String javaType)
  {
    // calling the super with
    // isReadOnly = true because we don't support transaction.
    // isKey = false
    this(name, parent, javaType, true, false);
  }

  //////////////////////////////// Public Methods //////////////////////////////

  /**
   * Sets a displyable name.
   */
  public void setName(String name)
  {
    mName = name;
  }

  /**
   * Gets the displyable name.
   */
  public String getName()
  {
    if (mName != null)
      return mName;
    return super.getName();
  }

  ///////////////////////////// Properties ///////////////////////////////////
  /**
   * Adds a custom property to this object.
   * @param propName Name of the custom property
   * @param value Value of the custom property
   */
  public void addProperty(String propName, Object value)
  {
    if ((propName != null) && (value != null))
    {
      mProps.put(propName, value);
    }
  }
  /**
   * Returns a custom property value given its name.
   *
   * @param propName Name of the custom property whose value is to be
   *                 retrieved.
   * @return custom property set against this column-like artefact.
   */
  public Object getProperty(String propName)
  {
    return mProps.get(propName);
  }

  /**
   * Adds custom properties to this object.
   * @param props properties have to be added.
   */
  public void addProperties(Map props)
  {
    if (props != null)
    {
      mProps.putAll(props);
    }
  }
  /**
   * Returns a <code>Hashtable</code> containing all the custom properties set
   * against this object.
   *
   * @return a <code>Hashtable</code> consisting of all the custom properties.
   */
  public Hashtable getProperties()
  {
    //return new java.util.HashMap(mProps);
     return mProps;
  }


  ///////////////////////////////// Bind paths /////////////////////////

  /**
   * Sets the bind path.
   */
  public void setBindPath(String path)
  {
    mBindPath = path;
  }

  /**
   * Gets the bind path of the definition if set.
   */
  public String getBindPath()
  {
    return mBindPath;
  }

  ////////////////////////////////// Overrides /////////////////////////////

  /**
   * Returns the full name of the definition. 
   * @return If the bind path is defined it returns the bind path. If
   *         bind path is not defined and the parent is defined then it returns 
   *         <parent_path>.<this_name>. Otherwise it returns the name of the 
   *         definition.
   */
  public String getFullName()
  {
    String bindPath = getBindPath();
    if (bindPath != null)
    {
      return new SimpleStringBuffer(50)
        .append(bindPath)
        .append(".")
        .append(getName()).toString();
    }
    else
    {
      Definition parent = getDefinitionParent();
      if ((parent != null) && (parent instanceof NamedDefinition))
      {
        return new SimpleStringBuffer(50)
        .append(((NamedDefinition)parent).getFullName())
          .append(".")
          .append(getName()).toString();
      }
      else
      {
        return getName();
      }
    }
  }
  
  public int getDefinitionType()
  {
    return TYPE_ATTRIBUTE;
  }
}
