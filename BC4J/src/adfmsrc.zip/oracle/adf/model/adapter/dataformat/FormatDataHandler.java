/*
 * @(#)FormatDataHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import java.util.Map;
import java.util.Iterator;

/**
 * Interface to define a data handler for specific data format. The data handler
 * extracts the data from the data stream with a specific format, e.g. XML, CSV
 * etc.
 * <p>
 * Given the data set of that format, format handler can extract data and present
 * them as an <code>Iterator</code> of <code>Map</code>. The <code>Map</code>
 * contains the value of attributes as defined in the data structure. For complex
 * data, <code>Map</code>s can contain other <code>Iterator</code> of
 * <code>Map</code>s as well.
 *
 * @version 1.0
 * @since 10.1.3
 */
public interface FormatDataHandler 
{
  /**
   * Returns the resulting data extracted from the input.
   * @param params parameters passed containig the context information.
   * @param returnType data type of the returned value. This can be passed as null.
   *        If no return type is specified, an Iterator of Map will be returned.
   * @return Object of the type defined by the <code>returnType</code> parameter.
   *         If the type is available, an instance of that object is created. If no
   *         type is specified an <code>Iterator</code> of <code>Map</code> objects 
   *         for the result will be created.
   *         If no data found it can return null. The <code>Map</code>
   *         contains the value of attributes as defined in the data structure.
   *         For complex data, <code>Map</code>s can contain other 
   *         <code>Map</code>s as well.
   */
  public Object getResult(Map params, String returnType);  
}
