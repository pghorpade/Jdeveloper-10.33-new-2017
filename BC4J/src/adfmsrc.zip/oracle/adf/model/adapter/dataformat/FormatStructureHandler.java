/*
 * @(#)FormatStructureHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import oracle.binding.meta.DefinitionContext;
import oracle.binding.meta.StructureDefinition;


/**
 * Interface to define a handler that can extract structure definition from a 
 * given input of a specific format, e.g. XML, CSV etc.
 *
 * @version 1.0
 * @since 10.1.3
 */
public interface FormatStructureHandler 
{
  /**
   * Returns the structure definition extracted for the data format.
   * @param name name of the root structure.
   * @param ctx definition context information.
   * @return the structure information extracted.
   */
  public StructureDefinition getStructure(String name, DefinitionContext ctx);
}
