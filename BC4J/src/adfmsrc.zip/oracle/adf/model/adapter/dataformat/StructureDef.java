/*
 * @(#)StructureDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter.dataformat;

import java.util.Hashtable;
import java.util.Map;

import oracle.binding.meta.AccessorDefinition;
import oracle.binding.meta.ArrayListDefinitionContainer;
import oracle.binding.meta.AttributeDefinition;
import oracle.binding.meta.DataControlDefinition;
import oracle.binding.meta.Definition;
import oracle.binding.meta.DefinitionContainer;
import oracle.binding.meta.OperationDefinition;
import oracle.binding.meta.StructureDefinition;


/**
 * Defines the structure definition of a data control.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class StructureDef implements StructureDefinition
{

  public static final int TYPE_ACCESSOR       = 1;
  
  private String mName;
  private String mFullName;
  private Definition mParent;
  private String mPkgName;

  // parent type for this structure def
  //private int mParentType = -1;

  private ArrayListDefinitionContainer mAttribs = 
    new ArrayListDefinitionContainer();

  private ArrayListDefinitionContainer mAccessors = 
    new ArrayListDefinitionContainer();

  // Methods
  private ArrayListDefinitionContainer mMethods = 
    new ArrayListDefinitionContainer();

  //Constructor Methods
  private ArrayListDefinitionContainer  mConstructors =
     new ArrayListDefinitionContainer();
  
  // alai 8/1/05 changed from Map to Hashtable for NamedDefinition's getProperties
  private Hashtable mProps = new java.util.Hashtable(10);


  ///////////////////////////////// Constructors ///////////////////////////////
 
  /** 
   * Creates a structure definition with a name.
   */
  public StructureDef(String fullName)
  {
    int index = fullName.lastIndexOf('.');
    
    if (index != -1)
    {
      mFullName = fullName;      
      mName = fullName.substring(index + 1);
      mPkgName = fullName.substring(0, index);
    }
    else 
    {
      mName = fullName;    
    }
  }

  /** 
   * Creates a structure definition with a name and a parent
   */
  public StructureDef(String name, Definition parent)
  {
    this(name);
    mParent = parent;
  }


  /////////////////////////// Impl StructureDefinition /////////////////////////

  public DefinitionContainer getAttributeDefinitions()
  {
    return mAttribs;
  }

  public DefinitionContainer getOperationDefinitions()
  {
    return mMethods;
  }

  public DefinitionContainer getAccessorDefinitions()
  {
    return mAccessors;
  }

  public DefinitionContainer getConstructorOperationDefinitions()
  {
     return mConstructors;
  }
  
  public DataControlDefinition getDataControlDefinition()
  {
    if (mParent != null) 
    {
      switch (mParent.getDefinitionType())
      {
        case TYPE_STRUCTURE:
          return ((StructureDefinition) mParent).getDataControlDefinition();
        case TYPE_DATACONTROL:
          return (DataControlDefinition) mParent;
      }
    }

    return null;
  }
  /**
   * Returns the full name of the definition. 
   * Full names are used to create the file name to serialize the structure
   * definition.
   * @return the full name in the form of <i>package_name.name</i>. 
   */
  public String getFullName()
  {
    if (mFullName != null) return mFullName;
    if ((mPkgName != null) && (mPkgName.length() > 0))
    {
      return mPkgName + "." + getName();
    }

    return getName();
  }

  public String getName()
  {
    return mName;
  }

  public Definition getDefinitionParent()
  {
    return mParent;
  }

  public int getDefinitionType()
  {
    return TYPE_STRUCTURE;
  }

  
  //////////////////////////////// Public Methods /////////////////////////////

  // TODO: Needs to be removed
  /**
   * Sets the parent type of this structure definition. 
   */
  public void setParentType(int type)
  {
    // mParentType = type;
  }

  /**
   * Sets the full name.
   * @param fullName the full name of the structure.
   */
  public void setFullName(String fullName) 
  {
    mFullName = fullName;
  }
  
  /**
   * Sets the pacakge name for this definition. 
   * Package names are used to serialize the structure definitions.
   */
  public void setPackageName(String pkg)
  {
    mPkgName = pkg;
  }

  /**
   * Adds an attribute to the structure definition.
   * @param attr The attribute as a part of the structure.
   */
  public void addAttribute(AttributeDefinition attr)
  {
    if (attr != null)
    {
      mAttribs.add(attr);
    }
  }
  
  /**
   * Adds an accessor to the structure definition.
   * @param accr The attribute as a part of the structure.
   */
  public void addAccessor(AccessorDefinition accr)
  {
    if (accr != null)
    {
      mAccessors.add(accr);
    }
  }

  /**
   * Adds a method to the structure definition. 
   * @param method The method as a part of the structure.
   */
  public void addMethod(OperationDefinition method)
  {
    if (method != null)
    {
      mMethods.add(method);
    }
  }


  /**
   * Adds a method to the structure definition. 
   * @param method The method as a part of the structure.
   */
  public void addConstructorMethod(OperationDefinition method)
  {
     if (method != null)
     {
        mConstructors.add(method);
     }
  }
  
  /**
   * Sets a parent to this definition.
   */
  public void setParent(Definition parent)
  {
    mParent = parent;
  }
  
  /**
   * Adds a custom property to this object.
   * @param propName Name of the custom property
   * @param value Value of the custom property
   */
  public void addProperty(String propName, Object value)
  {
    if ((propName != null) && (value != null))
    {
      mProps.put(propName, value);
    }
  }
  
  /**
   * Returns a custom property value given its name.
   * 
   * @param propName Name of the custom property whose value is to be
   *                 retrieved.
   * @return custom property set against this column-like artefact.
   */
  public Object getProperty(String propName)
  {
    return mProps.get(propName);
  }



   /**
   * Adds custom properties to this object.
   * @param props properties have to be added.
   */
  public void addProperties(Map props)
  {
    if (props != null)
    {
      mProps.putAll(props);
    }
  }
  
  /**
   * Returns a <code>Hashtable</code> containing all the custom properties set
   * against this object.
   * 
   * @return a <code>Hashtable</code> consisting of all the custom properties.
   */
  public Hashtable getProperties()
  {
    return mProps;
  }

}
