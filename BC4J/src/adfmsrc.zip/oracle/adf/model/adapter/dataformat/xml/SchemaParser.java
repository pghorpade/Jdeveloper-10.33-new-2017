/*
 * @(#)SchemaParser.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 * 
 * MODIFIED        (MM/DD/YY) 
 *    vpamadi       03/03/05 - Fix to enable parsing of schema URI's 
 *                             referenced by xmlns attribute in the top level 
 *                             schema. 
 *    vpamadi       01/05/05 - Provide public access for parse() and 
 *                             getSchemaMetadata API's since these are now 
 *                             accessed outside the package scope by the 
 *                             XSDHandler 
 * 
 */


package oracle.adf.model.adapter.dataformat.xml;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XSDBuilder;
import oracle.xml.parser.schema.XSDConstantValues;
import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLElement;

import oracle.adf.model.adapter.utils.Utility;


/**
 * Attempts to parses the given XSD document even in cases where the
 * <code>&lt;import&gt;</code> elements do not specify schemaLocation
 * attribute.
 * <p>
 * The parser works in a recursive fashion and parses the imported schemas and
 * namespaces in all the referred schemas. It builds a list of all the schemas
 * referred directly or indirectly and calls
 * <code>XSDBuilder.build(XMLDocument[], URL)</code> to build the schema.
 * <p>
 * Input for parsing can be set using any of the <code>addSchema</code>
 * methods. Alternatively, if only one schema document is to be parser, one of
 * the <code>parse</code> methods may be used. The <code>parse</code>
 * methods return <code>XMLSchema</code> object representing the parsed
 * schema document.
 */
public class SchemaParser
{
  /**
   * Stores metadata of a schema document (such as the &lt;schema&gt;
   * element's attributes)
   */ 
  private Map mSchemaMetadata = new HashMap();
  
  /**
   * List of documents that will be parsed
   */
  private List mDocuments = new ArrayList();

  /**
   * List of all the distinct schemas included/imported and referred to by the
   * input schema
   */
  private Map mSchemaList = new HashMap();

  
  
  /**
   * Creates a blank parser.
   */
  public SchemaParser()
  {
  }


  /**
   * Parses the schema definition specified by its URL location.
   * @param xsdLocation Location of the XSD document that is to be parsed.
   * @return Returns the parsed schema as an <code>XMLSchema</code> object.
   * @throws java.lang.Exception If error occurs while parsing the schema/s.
   */
  public XMLSchema parse(String xsdLocation) throws Exception
  {
    if (xsdLocation != null)
      this.addSchema(xsdLocation);
    
    return this.parse();
  }
  
  
  /**
   * Parses the schema definition specified by its URL.
   * @param xsdURL URL of the XSD document that is to be parsed.
   * @return Returns the parsed schema as an <code>XMLSchema</code> object.
   * @throws Exception If error occurs while parsing the schema/s.
   */
  public XMLSchema parse(URL xsdURL) throws Exception
  {
    if (xsdURL != null)
      this.addSchema(xsdURL);
    
    return this.parse();
  }
  
  
  /**
   * Parses the schema definition specified by its Reader.
   * @param xsdReader Reader object containing the schema defintion.
   * @return Returns the parsed schema as an <code>XMLSchema</code> object.
   * @throws Exception If error occurs while parsing the schema/s.
   */
  public XMLSchema parse(Reader xsdReader) throws Exception
  {
    if (xsdReader != null)
      this.addSchema(xsdReader);
    
    return this.parse();
  }
  
  
  /**
   * Parses the schema definition specified by its InputStream.
   * @param xsdStream InputStream containing the schema definition.
   * @return Returns the parsed schema as an <code>XMLSchema</code> object.
   * @throws Exception If error occurs while parsing the schema/s.
   */
  public XMLSchema parse(InputStream xsdStream) throws Exception
  {
    if (xsdStream != null)
      this.addSchema(xsdStream);
    
    return this.parse();
  }
  
  
  /**
   * Add a schema defintion specified by its URL location to the pipeline.
   * 
   * @param xsdLocation URL location of the schema defintion.
   * @throws Exception If error occurs while adding this defintion to the
   *                   list. The URL location might be invalid or inaccessible.
   */
  public void addSchema(String xsdLocation) throws Exception
  {
    if (xsdLocation != null)
      mDocuments.add(this.getReader(xsdLocation));
  }
  
  
  /**
   * Add a schema defintion specified by its URL to the pipeline.
   * 
   * @param xsdURL URL of the schema definition.
   * @throws Exception If error occus while adding this definition to the
   *           list. The URL might be invalid or inaccessible.
   */
  public void addSchema(URL xsdURL) throws Exception
  {
    if (xsdURL != null)
      mDocuments.add(this.getReader(xsdURL));
  }
  
  
  /**
   * Add a schema defintion specified by its Reader to the pipeline.
   * 
   * @param xsdReader <code>Reader</code> object containing the schema
   *          definition.
   */
  public void addSchema(Reader xsdReader)
  {
    if (xsdReader != null)
      mDocuments.add(xsdReader);
  }
  
  
  /**
   * Add a schema definition specified by its InputStream to the pipeline.
   * 
   * @param xsdStream <code>InputStream</code> object containing the schema
   *          definition.
   */
  public void addSchema(InputStream xsdStream)
  {
    if (xsdStream != null)
      mDocuments.add(this.getReader(xsdStream));
  }

  /**
   * Add a schema defintion specified by the <code>Node</code>.
   * 
   * @param node Root node of the schema defintion.
   */
  public void addSchema(Node node)
  {
    if (node != null)
      mDocuments.add(node);
  }
  
  /**
   * Returns meta data of the schema given its target namespace.
   * 
   * @param targetNamespace Target namespace of the schema document whose meta
   *          data is required
   * @return Returns a <code>SchemaMetadata</code> object enclosing the
   *         schema's meta data. If the target namespace does not exist,
   *         <code>null</code> is returned.
   */
  public SchemaMetadata getSchemaMetadata(String targetNamespace)
  {
    SchemaMetadata smd = null;
    
    if (targetNamespace != null && targetNamespace.length() != 0)
      smd = (SchemaMetadata) mSchemaMetadata.get(targetNamespace);
    
    return smd; 
  }

  /**
   * Iterates the schema list, scans and parses the schema definitions
   * specified therein.
   * 
   * @return Parsed XML Schema document
   * @throws Exception If error occurs while parsing the schema definitions.
   */
  public XMLSchema parse() throws Exception
  {
    int size = mDocuments.size();

    Utility.ASSERT(size != 0);
    
    for (int i = 0; i < mDocuments.size(); i++)
    {
      Object obj = mDocuments.get(i);
      if (obj instanceof Node)
      {
        generateSchemaList((Node) obj, null);
      }
      else if (obj instanceof Reader)
      {
        generateSchemaList((Reader) obj, null);
      }
    }
    
    XSDBuilder xsdBuilder = new XSDBuilder();
    Collection values = mSchemaList.values();
    Object []objArray = values.toArray();
    XMLDocument []schemaArray = new XMLDocument[objArray.length];
    System.arraycopy(objArray, 0, schemaArray, 0, objArray.length);

    return xsdBuilder.build(schemaArray, null);
  }


  ///////////////////////////// Class Helper ///////////////////////////////////
   
  //
  // A set of methods to return a Reader object for the given 'type' of schema
  // definition.
  //
  private Object getReader(InputStream xsdStream)
  {
    return new InputStreamReader(xsdStream);
  }

  private Reader getReader(String location) throws Exception
  {
    URL url = new URL(location);
    return this.getReader(url);
  }
  
  private Reader getReader(URL url) throws Exception
  {
    InputStream content = url.openStream();
    return new InputStreamReader(content);
  }

  /**
   * Finds a node from the child nodes identified by its name.
   * @param root the node to search in.
   * @param name name of the node to search.
   */
  private List findNodes(Node root, String name)
  {
    List ret = new ArrayList(5);
    NodeList children = root.getChildNodes();
    int cnt = children.getLength();
    for (int i = 0; i < cnt; i++)
    {
      Node nd = children.item(i);
      if (nd.getNodeName().equals(name))
      {
        ret.add(nd);
      }
    }
    return ret;
  }
  
  /**
   * Scans the schema specified by its <code>Reader</code> for namespaces
   * and imports. Attempts to follow the namespace URLs and scan the
   * namespaces and import that it may in turn contain.
   * 
   * @param xsdReader <code>Reader</code> object of the schema document
   * @param location URL location of the schema document. May be
   *          <code>null</code>.
   */
  private void generateSchemaList(Reader xsdReader, String location)
  {
    XMLDocument xsdDoc;

    //
    // Attempt to follow the URL and load the document as an XML. If it fails,
    // we return as the URL could be symbolic or may not be a valid schema
    //

    try
    {
      DOMParser parser = new DOMParser();
      parser.parse(xsdReader);
      xsdDoc = parser.getDocument();
    }
    catch (Exception e)
    {
      //System.out.println("ERROR: " + e.getMessage());
      return;
    }
    Node root = xsdDoc.getDocumentElement();

    // If the location is not supplied, create a key for the location
    // to store the schema doc.
    if (location == null)
    {
      location = Integer.toString(xsdReader.hashCode());
    }

    generateSchemaList(root, location);
  }
  
  /**
   * Scans the schema specified by its <code>Reader</code> for namespaces
   * and imports. Attempts to follow the namespace URLs and scan the
   * namespaces and import that it may in turn contain.
   * 
   * @param xsdReader <code>Reader</code> object of the schema document
   * @param location URL location of the schema document. May be
   *          <code>null</code>.
   */
  private void generateSchemaList(Node root, String location)
  {
    if (root == null) return;

    // See if the root element of this (valid XML) document is a schema

    if (!isSchemaNode(root.getNodeName()))
      return; // Not a valid schema document. Return...

    
    setSchemaMetadata(root);
    
    // Add this schema into the table against its namespace URL (or its
    // hashCode if its namespace URL is null).
    if (location != null)
    {
      mSchemaList.put(location, root.getOwnerDocument());
    }
    else
    {
      mSchemaList.put(Integer.toString(root.hashCode()), 
                      root.getOwnerDocument());
    }

    //System.out.println("Document: " +
    //                   (location == null ? "<<Reader>>" : location));

    //
    // A list of all the distinct namespaces, imports defined in this document.
    // At the end of processing this document, we recursively attempt follow
    // the namespace and import URLs
    //
    Set namespaceUrls = new HashSet();

    // Get the schema element and extract all namespace declarations. 
    NamedNodeMap schemaAttrs = null;

    // The schema nodes have to be fetched from the document and 
    // not the root node. The document can have multiple top level
    // schema node. 
    NodeList schemaNodes =
                      root.getOwnerDocument().getElementsByTagName(
                                                  XSDConstantValues._schema);
    if (schemaNodes.getLength() > 0)
    {
      schemaAttrs = ((Node) schemaNodes.item(0)).getAttributes();
    }
    
    if (schemaAttrs != null)
    {
      int len = schemaAttrs.getLength();
      for (int i = 0; i < len; i++)
      {
        Node attr = schemaAttrs.item(i);
        String nodeName = attr.getNodeName();

        // Only if this attribute starts with xmlns
        if (nodeName.startsWith(XSDConstantValues._xmlns) == true)
        {
          String attrValue = attr.getNodeValue();
          //System.out.println("  Namespace: " + attrValue);

          //
          // Only if this attribute does not point to the default schema AND
          // If is not already loaded
          // 
          if ((attrValue.compareToIgnoreCase(XSDConstantValues.XSDRECNS) != 0) &&
              (mSchemaList.containsKey(attrValue) == false))
            namespaceUrls.add(attrValue);
        }
      }
    }

    // Obtain <import> elements and extract its schemaLocation or namespace URL
    List importNodes = findNodes(root, XSDConstantValues._import);

    int cnt = importNodes.size();
    for (int i = 0; i < cnt; i++)
    {
      Node importElem = (Node) importNodes.get(i);
      NamedNodeMap attrs = importElem.getAttributes();

      // See if schemaLocation attribute is specified
      Node schemaLocationNode =
        attrs.getNamedItem(XSDConstantValues._schemaLocation);

      // If schemaLocation is specified XDK Schema builder parses just fine
      if (schemaLocationNode != null)
      {
        continue;
      }
      else
      {
        // If schemaLocation is not specified use namespace attribute
        schemaLocationNode =
          attrs.getNamedItem(XSDConstantValues._namespace);
      }

      if (schemaLocationNode != null)
      {
        String schemaLocationName = schemaLocationNode.getNodeValue();
        //System.out.println("  Import: " + schemaLocationName);

        if (mSchemaList.containsKey(schemaLocationName) == false)
        {
          namespaceUrls.add(schemaLocationName);
        }
      }
    }


    // Iterate over all the namespace URLs specified in this schema
    Iterator schemas = namespaceUrls.iterator();

    while (schemas.hasNext())
    {
      String xsdLocation = (String) schemas.next();
      Reader reader;

      //
      // Create a Reader and recurse into this schema definition. If this
      // URL location is invalid/inaccessible, just continue with the next.
      //
      try
      {
        reader = this.getReader(xsdLocation);
      }
      catch (Exception e)
      {
        continue;
      }

      generateSchemaList(reader, xsdLocation);
    }
  }


  /**
   * Retrieves the metadata of the given schema. (All attributes in the
   * <code>&lt;schema&gt;</code> element).
   * 
   * @param schemaNode Root node of the schema document.
   */
  private void setSchemaMetadata(Node schema)
  {
    NamedNodeMap attributes = schema.getAttributes();
    Node ndNS = attributes.getNamedItem(XSDConstantValues._targetNS);
    String namespace = null;
    if (ndNS != null)
    {
      namespace = ndNS.getNodeValue();
    }

    if ((namespace != null) && (namespace.length() != 0))
    {
      SchemaMetadata metadata = new SchemaMetadata(namespace);

      // Add the rest of the properties
      for (int i = 0; i < attributes.getLength(); i++)
      {
        Node attr = attributes.item(i);
        String name = attr.getNodeName();
        String val = attr.getNodeValue();
        if (XSDConstantValues._attrFormDefault.equals(name))
        {
          metadata.setAttributeFormDefault(
            val.equalsIgnoreCase(XSDConstantValues._qualified));
        }
        else if (XSDConstantValues._elemFormDefault.equals(name))
        {
          metadata.setAttributeFormDefault(
            val.equalsIgnoreCase(XSDConstantValues._qualified));
        }
        // We'll ignore the namespace attribute also
        else if (!XSDConstantValues._targetNS.equals(name))
        {
          metadata.setProperty(name, val);
        }
      }
    }
  }
  
  
  

  /**
   * Determines if the given node name is a schema node
   * @param nodeName Name of the node
   * @return Returns true if the given node is a schema node otherwise
   * returns false
   */
  private boolean isSchemaNode(String nodeName)
  {
    int strLen = nodeName.length();
    int idxColon = nodeName.indexOf(":"); //NOTRANS

    if (++idxColon > strLen)
      return false;

    String str = nodeName.substring(idxColon, strLen);

    return (str.compareTo(XSDConstantValues._schema) == 0);
  }
  
  
  
  
  //////////////////////////////////////////////////////////////////////////
  /////                                                                /////
  /////                     TEST HARNESS METHODS                       /////
  /////                                                                /////
  //////////////////////////////////////////////////////////////////////////
  
  public static void main(String []args)
  {
    if (args.length < 1)
      return;

    System.setProperty("http.proxyHost", "www-proxy.us.oracle.com");
    System.setProperty("http.proxyPort", "80");

    try
    {
      SchemaParser xsdParser = new SchemaParser();
      
      for (int i = 1; i < args.length; i++)
        xsdParser.addSchema(args[i]);
      
      XMLSchema schema = xsdParser.parse(args[0]);
      
      System.out.println("----- XSD Parsed successfully -----");
      
      
    }
    catch (Exception e)
    {
      Class cls = e.getClass();
      String className = cls.getName();

      System.out.println("EXCEPTION OCCURED:");
      System.out.println(className + ": " + e.getMessage());
      e.printStackTrace(System.out);
    }
  }
}
