/*
 * @(#)AccessorDef.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter.dataformat;

import oracle.binding.meta.AccessorDefinition;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.utils.SimpleStringBuffer;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.binding.meta.Definition;
import oracle.binding.meta.NamedDefinition;
import oracle.binding.meta.MethodReturnDefinition;

/**
 * Defines an accessor.
 *
 * @version 1.0
 * @since 10.1.3
 */
public class AccessorDef extends AttributeDef implements AccessorDefinition
{
  private StructureDefinition mStruct;
  private boolean mIsCollection = false;

  // Collection structiure
  private StructureDefinition mCollectionStruct = null;

  // whether accessor contains a collection of scalars 
  private boolean mIsScalarCollection = false;

  // The definition to be returned by getParentAccessor.
  // This must be either an AccessorDefinition or an MethodReturnDefinition.
  private NamedDefinition mParentAccessor = null;

  // Debug logger
  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger();
   
  //============================================================================
  // Constructors
  //============================================================================

  /**
   * Creates a new accessor definition as a java type collection. 
   * 
   * @param id unique id for the definition.
   * @param parent parent structure definition that this accessor is a part of.
   * @param type the data type defined as a java type available for the system. 
   */
  public AccessorDef(
    String id, 
    StructureDefinition parent,
    String type)
  {
    super(id, parent, type);
    mIsCollection = true;
  }
  
  /**
   * Creates a new accessor definition as a collection of a scalar type.
   * 
   * @param id unique id for the definition
   * @param parent parent structure definition that this accessor is a part of.
   * @param type the data type defined as a java type available for the system.
   * @param elementType the java type of each element in the collection.
   */ 
  public AccessorDef(
    String id, 
    StructureDefinition parent,
    String type,
    String elementType)
  {
    this(id, parent, type);
    mIsScalarCollection = true;
    mStruct = new StructureDef(id, this);
    AttributeDef elementAttrDef = new AttributeDef("element", mStruct, elementType);
    ((StructureDef)mStruct).addAttribute(elementAttrDef);
  }
  
  /**
   * Creates a new accessor definition as a complex type.
   * <p>
   * Accessors can be used to define the complex structure for which a java
   * type may not be defined.
   * 
   * For accessors that are collection of scalar types, use the constructor with
   * the additional isScalarCollection parameter. 
   *
   * @param id unique id for the definition.
   * @param parent parent structure definition that this accessor is a part of.
   * @param struct the complex structer that describes this accessor. 
   * @param isCollection indicates if the accessor is a collection.
   */
  public AccessorDef(
    String id, 
    StructureDefinition parent,
    StructureDefinition struct,
    boolean isCollection)
  {
     this(id, parent, struct, isCollection, false);
  }
   
  /**
   * Creates a new accessor definition as a complex type.
   * <p>
   * Accessors can be used to define the complex structure for which a java
   * type may not be defined.
   *
   * @param id unique id for the definition.
   * @param parent parent structure definition that this accessor is a part of.
   * @param struct the complex structer that describes this accessor. 
   * @param isCollection indicates if the accessor is a collection.
   * @param isScalarCollection indicates if the accessor is a collection of scalars.
   */
  public AccessorDef(
    String id, 
    StructureDefinition parent,
    StructureDefinition struct,
    boolean isCollection,
    boolean isScalarCollection)
  {
    super(id, parent, null);
    if (struct != null)
    {
      mStruct = struct;
      if (mStruct instanceof StructureDef)
      {
        StructureDef strdef = (StructureDef) mStruct;
        strdef.setParent(this);
      }
    }
    mIsCollection = isCollection;
    mIsScalarCollection = isScalarCollection;
  }

  /**
   * Creates a new accessor definition as a complex type.
   * <p>
   * Accessors can be used to define the complex structure for which a java
   * type may not be defined.
   *
   * @param id unique id for the definition.
   * @param parent parent structure definition that this accessor is a part of.
   * @param isCollection indicates if the accessor is a collection.
   */
  public AccessorDef(
    String id, 
    StructureDefinition parent,
    boolean isCollection)
  {
    super(id, parent, null);
    mIsCollection = isCollection;
  }


  //============================================================================
  // Implementation of interfaces
  //============================================================================

  /**
   * Returns the bind path for this accessor. 
   * Runtime fetches data depending on the bind path defined.
   * @return a dot (.) separated <code>String</code> value. If the bind path 
   * is set, it returns <bind_path>.<this_name>. Otherwise it returns 
   * <parent_path>.<this_name>.
   */
  public String getFullName()
  {
    return super.getFullName();
  }

  public boolean isCollection()
  {
    return mIsCollection;
  }

  public boolean isScalarCollection()
  {
    return mIsScalarCollection;
  }

   public StructureDefinition getStructure()
  {
    return mStruct;
  }

  //FIXME If you always return an empty structure, an empty bean xml file will be generated
  // you may want to reconsider this.
  public StructureDefinition getCollectionStructure()
  {
    //Removed this logic, change approved by Arnab
    // if the collection struct is not set yet, return an empty one
   /* if (mCollectionStruct == null)
    {
      mCollectionStruct = new StructureDef(new SimpleStringBuffer(50).
                                           append(getName()).
                                           append("Collection").
                                           toString());
                                           
    }*/
    return mCollectionStruct;
  }

  public NamedDefinition getParentAccessor()
  {
      mLogger.fine(new SimpleStringBuffer(100)
                   .append("Parent accessor is called for accessor: ")
                   .append(getName())
                   .toString());
    // if setParentAccessor has been called with some definition, return
    // that.
    if (mParentAccessor != null)
    {
      mLogger.fine("Parent accessor is already defined for this accessor.");
      return mParentAccessor;
    }
    // otherwise, determine parent accessor from the definition hierarchy...
    NamedDefinition parentAccessor = null;
    Definition parent = getDefinitionParent();
    // parent of AccessorDefinition should be a StructureDefinition
    if (parent != null && parent.getDefinitionType() == TYPE_STRUCTURE)
    {
      // the parent accessor would be the parent of the StructureDefinition
      // if it is an accessor, or if it is a method return value that is
      // of a collection type.
      Definition grandParent = ((StructureDefinition)parent).getDefinitionParent(); 
      if (grandParent != null)
      {
         if (grandParent.getDefinitionType() == TYPE_ACCESSOR)
         {
            parentAccessor = (NamedDefinition) grandParent;
            mLogger.fine("Parent accessor - returns the grandparent accessor.");
         }
         else if (grandParent.getDefinitionType() == TYPE_METHODRETURN)
         {
            MethodReturnDefinition methodReturnDef = (MethodReturnDefinition) grandParent;
            parentAccessor = (NamedDefinition)grandParent;
            mLogger.fine("Parent accessor - returns the grandparent method return def.");
         }
      }
    }
    return parentAccessor;
  }
  
  public int getDefinitionType()
  {
    return TYPE_ACCESSOR;
  }



  //============================================================================
  // Public Methods
  //============================================================================
   

  /**
   * Set the structure definition for the collection if the return is a 
   * collection. Collection structures usually contain methods applicable for
   * the collection.
   */
  public void setCollectionStructure(StructureDefinition def)
  {
    mCollectionStruct = def;
  }
  
  public void setStructure(StructureDefinition struct) 
  { 
    mStruct = struct; 
  } 

  public void setParentAccessor(AccessorDefinition parentAccessor)
  {
     mParentAccessor = parentAccessor;
  }
   
  public void setParentAccessor(MethodReturnDefinition parentAccessor)
  {
     mParentAccessor = parentAccessor;
  }
   
  /**
   * Clones the accessor with a new id and a new parent.
   * @param parentStruct the parent structure definition of the cloned accessor.
   * @param id id of the new accessor.
   * @return a cloned <code>AccessorDef</code> value.
   */
  public AccessorDef clone(StructureDef parentStruct, String id)
  {
    AccessorDef newAccDefn;
 
    newAccDefn = new AccessorDef(id,
        parentStruct,
        mStruct, 
        isCollection());

    return newAccDefn;
  }
  

}
