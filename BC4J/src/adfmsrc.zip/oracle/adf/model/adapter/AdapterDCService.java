/*
 * @(#)AdapterDCService.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;

import java.util.logging.Handler;
import java.util.logging.Level;
import oracle.binding.DataControl;
import oracle.binding.OperationInfo;
import oracle.binding.OperationBinding;

import oracle.jbo.SortCriteria;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.model.generic.DCGenericDataControl;
import oracle.adf.model.generic.StructureDefImpl;
import oracle.adf.model.utils.SimpleStringBuffer;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;

/**
 * Provides services to the adapter created data controls for handling 
 * collection and bean based data.
 * <p>
 * This class is created by the {@link DataControlFactoryImpl} to create 
 * a service for the data controls that the ADF stacks uses.
 *
 * Created: Thu Nov 04 12:07:04 2004
 *
 * @version 1.0
 * @since 10.1.3
 */
public class AdapterDCService extends DCGenericDataControl 
{
  // performance sensors
  private static Timer sExecuteTimer = Timer.createTimer(Level.FINE,
                                      "/oracle/adf/model/adapter",
                                      "invokeOperation.Execute",
                                      "Invoking the adapter to execute.");
  private static Timer sInvokeOperationTimer = Timer.createTimer(Level.FINE,
                                      "/oracle/adf/model/adapter",
                                      "invokeOperation",
                                      "Invoking the adapter method.");

  /**
   * Map to store the property information for the RSI, properties are defined
   * for the iterators that calls data controls to execute.
   * The information are stored with the RSI name as the key with an associated
   * InfoBag object.
   */
  private Map mRSIInfo = new java.util.HashMap(5);

  // Debug logger
  private ADFLogger mDbgLog = AdapterContext.getDefaultContext().getLogger();

  // AbstractImpl instance
  private AbstractImpl mImpl = null;

  //=============================================================================
  // Implementations
  //=============================================================================

  /**
   * Creates a new <code>AdapterDCService</code> instance.
   * @param name Name of the data control.
   * @param def The location of the structure definition metadata.
   * @param dcInstance the data control instance.
   * @param dcDef the data control definition that has created this service.
   */
  AdapterDCService(
    String name, 
    String def, 
    Object dcInstance, 
    AbstractDefinition dcDef)
  {
    super(name, def, dcInstance, false);

    // if the dc is an instance of AbstractImpl 
    if (dcInstance instanceof AbstractImpl)
    {
      mImpl = (AbstractImpl) dcInstance;
      mImpl.setName(name);
      // set the structure def (jsr 227 form).
      mImpl.setStructureDef(mDef);

      // set the def
      mImpl.setDefinition(dcDef);
    }
  }

  ///////////////////////////// Overrides ///////////////////////////////////////

  /**
   * Fetches the data from the data control.
   */
  protected Object fetchProviderProperty(String propName)
  {
    mDbgLog.entering(getClass().getName(), "fetchProviderProperty");

    try
    {
      mDbgLog.fine("Property = " + propName);

      //
      // We'll find out if the property name is one of the RSI names known
      // to the system. RSI names are the root names defined by the data
      // controls. A common root name is "root".
      //

      if (isDefinedRSI(propName))
      {
        mDbgLog.fine("Fetching the attribute value for root.");

        // At this point it's supposed to return the value of the attributes
        // at the root level.
        // We'll call the data control's invoke method and the method name 
        // will be passed as "adapter_execute". This mehthod will indicate to fetch
        // data from a data source that does not support a method call, e.g. a CSV
        // or XML data file.

        if (mDataProvider instanceof DataControl)
        {
          mDbgLog.fine("Data provider is a jsr data control.");

          sExecuteTimer.start();
    
          //
          // Get the info that the method action will expose.
          //

          // The data control name
          final String dcName = getName();

          // action name as dc_name.rsi_name (myDC_root)
          final String actionName = new SimpleStringBuffer(50).append(dcName)
            .append("_").append("execute").toString();

          // bind name as myDC.root
          final String bindName = new SimpleStringBuffer(50).append(dcName)
            .append("_").append(propName).toString();

          // sort criteria if any
          final Map paramMap = new java.util.HashMap(10);
          InfoBag bag = (InfoBag) mRSIInfo.get(propName);
          AdapterSortCriteria[] criteria = 
            (bag != null) ? bag.getSortCriteria() : null;
          paramMap.put(AbstractImpl.SORT_CRITERIA, criteria);

          // The method
          OperationBinding action = new OperationBinding()
          {
             public String getName()
             {
                return actionName;
             }

             public boolean isOperationEnabled()
             {
                return true;
             }

             public boolean resolvePath(java.util.Map map)
             {
                return true;
             }

             public void setListener(oracle.binding.UpdateListener l)
             {
             }

             public void release(int x)
             {
             }

             public String getPath()
             {
                return null;
             }

             public Object execute()
             {
                return null;
             }

             public Object getResult()
             {
                return null;
             }

             public java.util.List getErrors()
             {
               return null;
             }

             public OperationInfo getOperationInfo()
             {
               return new OperationInfo()
               {
                 public String getInstanceName() 
                 { 
                   return bindName; 
                 }

                 public String getOperationName() 
                 { 
                   return AbstractImpl.METHOD_EXECUTE; 
                 }

                 public String getReturnName() 
                 {
                   return bindName + "_" + AbstractImpl.METHOD_EXECUTE;
                 }
               };
             }
             public Map getParamsMap()
             {
               return paramMap;
             }

          };

          // Call the data control impl 
          mDbgLog.fine("Invoking method.");
          ((DataControl)mDataProvider).invokeOperation(getBindingContext(), action);

          // We get the result from the binding context as put by the data control.

          //Object res =  getBindingContext().get(action.getOperationInfo().getReturnName());
          Object res = DCUtil.findContextObject(getBindingContext(),
             action.getOperationInfo().getReturnName());

          if (res == null) 
          {
            mDbgLog.fine("Returned object is null.");
            return null;
          }

          // We'll create an iterator for the result if its a Map
          if (res instanceof Map)
          {
            mDbgLog.fine("Returned object is a Map.");
            ArrayList al = new ArrayList(2);
            al.add(res);
            return al.iterator();
          }

          sExecuteTimer.stop();
          return res;
        }
      }

      mDbgLog.fine("No RSI found, calling super.");
      return super.fetchProviderProperty(propName);
    }
    finally
    {
      sExecuteTimer.cleanup();

      mDbgLog.exiting(getClass().getName(), "fetchProviderProperty");
    }
  }
  
  /**
   * Invokes the action associated with this data control. The WebService data
   * control invokes the operation to return the data collection assoicated
   * with the operation invocation.
   * 
   * @param bindingContext A binding context that provide access to all 
   *                       binding related objects.
   * @param action         The action to be performed by the data control.
   *                       For the Webservice data control, the action to 
   *                       be invoked is the webservice operation.
   *
   * @return               <code>true</code> if this datacontrol has handled
   *                       this action, </code>false</code> if the action 
   *                       should be interpreted in the bindings framework or
   *                       in the caller.
   */
  public boolean invokeOperation(Map bindingContext, OperationBinding action)
  {
    try
    {

      // we need to synchronize this call, this can be called by multiple bindings
      // if multiple pages are executed simultaneously.
      synchronized(this)
      {
        sInvokeOperationTimer.start();

        boolean stat = super.invokeOperation(bindingContext, action);

        sInvokeOperationTimer.stop();

        return stat;
      }
    }
    finally
    {
      sInvokeOperationTimer.cleanup();
    }
  }

  /**
   * Check if the operation params has changed during an iterator execution.
   * This method decides whether to call a method. If the parameter values are
   * changed the method will be called again to get the result for the changed
   * value. Otherwise it'll call the AbstractImpl (if implemented) to decide 
   * whether to call the method again.
   * 
   * @param operationInfo The {@link oracle.binding.OperationInfo} whose parameters 
   *                      need to evaluated to decide this params changed
   *                      condition.
   * 
   * @return <code>true</code> if the operation parameters have changed.
   *         Otherwise calls the impl to decide. If the impl is not available, i.e.
   *         the data control is not an AbstractImpl, it returns false.
   *         
   */
  public boolean hasOperationParamsChanged(OperationInfo operationInfo)
  {
    // Call the super to check if it the param values have changed. If the 
    // params are changed it shoild be called anyway.
    if (super.hasOperationParamsChanged(operationInfo))
    {
      return true;
    }

    // Params values are not changed, lets give the impl a chance to decide
    // whether to call the method.
    if (mImpl != null)
    {
      return mImpl.shouldReexecuteOperation(operationInfo);
    }
    
    return false;
  }
 

  /**
   * Sets the sort critiera that will be applied next time when the 
   * source for this iteratorBinding is executed.
   */
  protected void applySortCriteria(DCIteratorBinding iter, SortCriteria[] sortby)
  {
    // get the rsi name
    String rsiName = iter.getRowSetIterator().getName();
    // convert the sort criteria to adapter version
    AdapterSortCriteria[] criteria = new AdapterSortCriteria[sortby.length];
    for (int i = 0; i < criteria.length; i++)
    {
      criteria[i] = new AdapterSortCriteria(sortby[i]);
    }

    // store it in the bag and put the bag for the rsi
    Object obj = mRSIInfo.get(rsiName);
    InfoBag bag = (obj == null) ? new InfoBag() : (InfoBag) obj;
    bag.putSortCriteria(criteria);
    mRSIInfo.put(rsiName, bag);

    //passing through to DCGenericDataControl for it to perform default 
    //sort implementation. bug 4739340 
    super.applySortCriteria(iter,sortby);
  }


  //=============================================================================
  // Class helpers
  //=============================================================================

  /**
   * Finds out if a RSI is defined by this data control structure info.
   */
  private boolean isDefinedRSI(String name)
  {
    if (name == null) return false;
    if ((mRSIs != null) && (mRSIs.get(name) != null))
    {
      return true;
    }
    return false;
  }



  ///////////////////////////// Helper classes /////////////////////////////////

  /**
   * Gets the "bag" to store the information for a RSI.
   */


  /**
   * Location to store information associated with an item.
   */
  private class InfoBag
  {
    private static final int SORT_CRITERIA = 1;
    private Object[] _store = new Object[2];

    // Sort cretia as defined by ADFm
    void putSortCriteria(AdapterSortCriteria[] criteria)
    {
      _store[SORT_CRITERIA] = criteria;
    }

    AdapterSortCriteria[] getSortCriteria()
    {
      return (AdapterSortCriteria[]) _store[SORT_CRITERIA];
    }


  }
}
