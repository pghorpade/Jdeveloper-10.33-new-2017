/*
 * @(#)AdapterDefinition.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.adapter;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.List;

import java.util.logging.Level;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLParseException;

import oracle.jbo.common.JBOClass;

import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.utils.NodeAttributeHelper;
import oracle.adf.share.logging.ADFLogger;
import java.util.logging.Handler;

/**
 * Adapter definition contains the definitions of the adapters available for 
 * the system. Adapters are the drivers that can handle different data sources
 * to connect and execute queries. Data controls use adapters to connect to data
 * sources. 
 * <p>
 * Adapter definition defines the class name that implements the adapter. It 
 * also defines the data source type that it can handle. The data source type 
 * information contains the class name that represent a data source in the 
 * JDeveloper connection navigator.
 * <p>
 * Every adapter implementation must have a definition file defined for it. The
 * definition file must be named as <i><b>adapter-definition.xml</b></i>. The 
 * file should be in the application class path under the folder <b>meta-inf</b>. 
 * <p>
 * Adapter definitions are loaded once per JVM. The <code>{@link #initialize}()</code>
 * method call triggers the loading of the files, if it's not already loaded by 
 * another thread. Once loaded the information is shared across different thread 
 * running for the JVM.
 */
public class AdapterDefinition
{

  public static final String DEF_FILE = "meta-inf/adapter-definition.xml";
  //
  // Tag Names
  //

  /** Tag name for adapter. */
  public static final String TAG_ADAPTER     = "Adapter";
  public static final String ATTR_TYPE_NAME  = "Name";
  public static final String ATTR_TYPE_CLASS = "ClassName";

  /** Tag "Source". */
  public static final String TAG_SOURCE_TYPE = "Source";
  public static final String TAG_TYPE        = "Type";

  /** 
   * Attribute name to get the JDev class name for the node that the adapter 
   * can handle. 
   */
  public static final String ATTR_JDEV_NODE  = "JDevNode";

  /** Tag "Schema". */
  public static final String TAG_SCHEMA      = "Schema";
  public static final String ATTR_NS         = "Namespace";
  public static final String ATTR_LOCATION   = "Location";

  /** 
   * Tag "Dependencies".
   * Defines the libraries that the adapter RT will depend on.
   */
  public static final String TAG_DEPENDENCIES = "Dependencies";
  public static final String TAG_LIBRARY = "Library";
  public static final String ATTR_PATH = "Path";

  /** 
   * Tag "JDevHook".
   * It defines the class that provides the contextual info when a data
   * control is selected in the structure pane. 
   */
  public static final String TAG_JDEV_CTX_HOOK = "JDevContextHook";
  public static final String ATTR_JDEV_CTX_HOOK_CLASS = "Class";


  /** Tag "Properties" */  
  public static final String TAG_PROPERTIES  = "Properties";
  public static final String TAG_PROPERTY    = "Property";
  public static final String ATTR_PROP_NAME  = "Name";
  public static final String ATTR_PROP_VALUE = "Value";


  //===========================================================================
  // Globals 
  //===========================================================================
  

  /**
   * Class loader that loads the adapter definition files.
   */
  private static ClassLoader sClassLoader = null;

  /**
   * Global store of loaded definitions, used across threads.
   */
  private static Map sDefinitionStore;

  /**
   * Flag to indicate if the definition is already loaded.
   */
  private static boolean sLoaded = false;

  //===========================================================================
  // Class Variables
  //===========================================================================
  

  // Debug logger
  private ADFLogger mDbgLog = AdapterContext.getDefaultContext().getLogger();

  // Name of the adapter1
  private String mName;
  // Class instance of the adapter
  private Class mClass;
  
  // Schema: schema namespace are used as key to store the locations
  private Map mSchema = new java.util.HashMap(5);
  

  /**
   * Map that stores the "Source" information for this adapter. The type
   * name is the key of the map and the JDev node class name is stored as a 
   * value.
   */
  private Map mSupportedSourceTypes = new java.util.HashMap(5);

  /** Class name for the jdev context hook. */
  private String mJDevCtxHookName;

  /** 
   * Properties defined in the definition file.
   */
  private Map mProperties = new java.util.HashMap(5);

  /**
   * Library paths that the adapter runtime depends on.
   */
  private List mLibraries = new java.util.ArrayList(10);

  /** Lock object to support multi-threading. */
  private Object mLock = new Object();


  //===========================================================================
  // Public static methods
  //===========================================================================
  

  /**
   * Initializes the definition system by loading the definitions.
   */
  public static synchronized void initialize()
  {
    ADFLogger dbgLog = AdapterContext.getDefaultContext().getLogger();
    dbgLog.entering("oracle.adf.model.adapter.AdapterDefinition",
                     "initialize");
    try
    {
      // Check for the next caller thread in sysnchronized queue.
      if (sLoaded) return;

      dbgLog.fine("Start loading adapters defined for the system.");
      // Look for all definition files defined in the class path
      java.util.Enumeration enum = null;
      try
      {
        // If the class loader is not set, use the thread's one.
        ClassLoader loader = sClassLoader;
        if (loader == null)
        {
          dbgLog.fine("Loading by the current thread's class loader.");
          loader = Thread.currentThread().getContextClassLoader();
        }

        if (loader != null)
        {
          enum = loader.getResources(DEF_FILE);
        }
      }
      catch (Exception e)
      {
        dbgLog.log(Level.SEVERE,"Exception: ", e);
      }
      
      if (enum == null)
      {
        dbgLog.fine("Trying to load by system class loader.");
        enum = ClassLoader.getSystemResources(DEF_FILE);
      }

      if (!enum.hasMoreElements())
      {
        dbgLog.fine("No adapter definition found in the class path.");
        sLoaded = true;
        return;
      }
      
      sDefinitionStore = new java.util.HashMap(15);
      while (enum.hasMoreElements())
      {
        dbgLog.fine("Loading adapter definition.");
        URL url = (URL) enum.nextElement();
        try
        {
          loadAdapterDefinition(url.openStream());
        }
        catch (Exception e)
        {
          dbgLog.log(Level.SEVERE,"Failed to load the adapter: ", e);
        }
      }

      sLoaded = true;
    }
    catch (Exception e)
    {
      dbgLog.log(Level.SEVERE, "Adapter initialization failed: ", e);
    }
    finally
    {
      dbgLog.exiting("oracle.adf.model.adapter.AdapterDefinition","initialize");
    }

  }
  

  /**
   * Sets the class loader that loads the adapter definition files from the
   * class path. 
   * <p>
   * Different IDE system can set the calss loader relavant for them. By default
   * the calling thread's class loader will be used.
   */
  public static void setClassLoader(ClassLoader cl)
  {
    sClassLoader = cl;
  }

  /**
   * Returns the definition object for a type name.
   * @param typeName Name of the adapter type.
   * @return Definition object for the type. If no definition is found for the
   *         type, it returns null.
   */
  public static AdapterDefinition getDefinition(String typeName)
  {
    if (sDefinitionStore == null) return null;
    return (AdapterDefinition) sDefinitionStore.get(typeName);
  }
  
  /**
   * Enumerates all adapters defined for the system.
   * @return  An iterator of <code>AdapterDefinition</code> objects.
   */
  public static Iterator enumAdapters()
  {
    if (sDefinitionStore == null) return new java.util.ArrayList().iterator();
    return sDefinitionStore.values().iterator();
  }
  



  //===========================================================================
  // Public Methods
  //===========================================================================
  

  /**
   * Gets the type name of the adapter.
   */
  public String getName()
  {
    return mName;
  }

  ////////////// Registered schema information //////////////////

  /**
   * Enumerates all namespace names defined for the adapter.
   * @return  An iterator of namespace name strings. 
   */
  public Iterator enumSchemaNS()
  {
    return mSchema.keySet().iterator();
  }
  
  
  /**
   * Enumerates all namespace locations defined for the adapter.
   * @return  An iterator of location strings. 
   */
  public Iterator enumSchemaLocations()
  {
    return mSchema.values().iterator();
  }
  
  /** 
   * Gets the schema location.
   * @param ns Namespace for the schema location.
   * @return Namespace location. If not defined, returns null.
   */
  public String getSchemaLocation(String ns)
  {
    return (String) mSchema.get(ns);
  }

  ///////////////// JDev Context Hook /////////////////////
  public String getJDevCtxHookName()
  {
    return mJDevCtxHookName;
  }

  ///////////////// Property info /////////////////////////

  /** 
   * Gets the value of a property defined for the adapter.
   */
  public String getPropertyValue(String name)
  {
    return (String)mProperties.get(name);
  }

  ///////////////// Adapter class ////////////////////////
  /**
   * Gets the class name of the adapter.
   */
  public String getClassName()
  {
    if (mClass != null) return mClass.getName();
    return null;
  }

  ///////////////// Dependent libs ////////////////////////
  /**
   * Gets the library paths that the adapter depends on.
   */
  public Iterator getLibraries()
  {
    return mLibraries.iterator();
  }




  /**
   * Creates an instance of the adapter by loading the adapter class.
   * 
   * @return A blank instance of the adapter.
   */
  public AbstractAdapter createAdapterInstance()
  {
    if (mClass == null)
    {
      throw new AdapterException(ADFmMessageBundle.class, 
        ADFmMessageBundle.EXC_ADAPTER_CLASS_LOAD_FAILED);
    }

    try
    {
      return (AbstractAdapter) mClass.newInstance();
    }
    catch (Exception e)
    {
      throw new AdapterException(ADFmMessageBundle.class, 
        ADFmMessageBundle.EXC_ADAPTER_CLASS_LOAD_FAILED).setCause(e);
    }
  }

  /**
   * Gets the source type names that this adapter can handle.
   * <p>
   * The source type names identify specific data source types for an 
   * application.
   * 
   * @return An iterator of String that contains the source type names.
   */
  public Iterator getSupportedSourceNames()
  {
    return mSupportedSourceTypes.keySet().iterator();
  }

  /**
   * Gets the source types that this adapter can handle.
   * Source types are the class name of the source that this adapter can handle.
   * @return An iterator of String that contains the source type class names.
   */
  public Iterator getSupportedSourceTypes()
  {
    return mSupportedSourceTypes.values().iterator();
  }
  
  /**
   * Gets the source type classes that this adapter can handle.
   * <p>
   * The source type classes identify specific data source types presented
   * in the JDeveloper connection navigator window.
   * 
   * @return  An iterator of <code>java.lang.Class</code> representing nodes in 
   *          the JDeveloper coinnection pane that this adapter can accept as
   *          a data source connection.
   */
  public Iterator getSupportedSourceClasses()
  {
    java.util.List listNodes = new java.util.ArrayList(5);
    
    Iterator it = mSupportedSourceTypes.values().iterator();
    while (it.hasNext())
    {
      String clsName = (String) it.next();
      // Load this class
      try
      {
        Class clz = JBOClass.forName(clsName);
        listNodes.add(clz);
      }
      catch (Exception e)
      {
        // Noop
      }
    }
    
    return listNodes.iterator();
  }
  
  /**
   * Checks if a specific data source type can be handled by this adapter.
   * 
   * @param obj The object that can be used as a data source connection node. 
   *            It can either the name of the data source type or the node
   *            object that represents the data source in the JDeveloper 
   *            connection navigator.
   */
  public boolean canHandle(Object obj)
  {
    mDbgLog.entering(getClass().getName(),"CanHandle");
    Class clsType = null;
    try
    {
      if (obj == null)
      {
        mDbgLog.severe("Object null.");
        return false;
      }

      // If the object passed is a string, it can be a data type name or a class
      // name of the data type. Otherwise it should be a class instance that
      // represents a connection node.
      if (obj instanceof String)
      {
        // Check if the obj is a known type name. 
        if (mSupportedSourceTypes.get(obj) != null)
        {
          mDbgLog.fine("Matched supported type = " + obj.toString());
          return true;
        }

        // If the obj is a known class name, where the class name mentioned is 
        // an exact string match with the type of the object.
        String clsName = (String) obj;
        Iterator it = getSupportedSourceTypes();
        while (it.hasNext())
        {
          if (clsName.equals((String) it.next()))
          {
            mDbgLog.fine("It can handle = " + clsName);
            return true;
          }
        }
      }
      else
      {
        // Now we'll check if the object is an instance of the known types.
        // We'll create a class object from the known types.
        // In this case, we should also need to ask the adapter as well if it
        // can handle the source. Because the obj may be of a base type of 
        // what the adapter said to handle but not exactly the thing that it
        // can handle. 
        clsType = obj.getClass();

        Iterator it = getSupportedSourceClasses();
        while (it.hasNext())
        {
          Class cls = (Class) it.next();
          if (cls.isInstance(obj))
          {
            mDbgLog.fine("Object is an instance. Need to ask the adapter.");
            mDbgLog.fine("Creating adapter instance...");
            AbstractAdapter adapter = createAdapterInstance();
            if (adapter.canCreateDataControl(obj))
            {
              return true;
            }
          }
        }
      }

    }
    catch(Exception e)
    {
      mDbgLog.log(Level.SEVERE, "Exception: ", e);
    }
    finally
    {
      mDbgLog.exiting(getClass().getName(), "CanHandle");
    }
    
    return false;
  }
     

  //===========================================================================
  // Class Helpers
  //===========================================================================
  

  ///////////////////////////// Construction /////////////////////////////////////

  /**
   * Creates a definition object from the XML Node. 
   */
  private AdapterDefinition(Node nd)
  {    
    mDbgLog.entering(getClass().getName(),"Constructor(Node)");
    try
    {
      // Load the definition
      NodeAttributeHelper attribs = new NodeAttributeHelper(nd.getAttributes());
      mName = attribs.getValue(ATTR_TYPE_NAME);
      mDbgLog.fine("Adapter name: " + mName);

      String className = attribs.getValue(ATTR_TYPE_CLASS);
      if (className == null)
      {
        mDbgLog.severe("Exception: No implementation class name is defined.");
        throw new AdapterException(ADFmMessageBundle.class, 
          ADFmMessageBundle.EXC_ADAPTER_CLASS_NOT_DEFINED,
          new Object[]{mName});
      }

      try
      {
        mDbgLog.fine("Trying to load class.");
        mClass = JBOClass.forName(className);
        mDbgLog.fine("Class load successful.");
      }
      catch (ClassNotFoundException e)
      {
        mDbgLog.log(Level.SEVERE, "Exception: Class load failed - ", e);
        throw new AdapterException(ADFmMessageBundle.class,
          ADFmMessageBundle.EXC_ADAPTER_CLASS_LOAD_FAILED,
          new Object[]{className}).setCause(e);
      }
      
      NodeList nodes = nd.getChildNodes();
      int cnt = nodes.getLength();
      for (int i = 0; i < cnt; i++)
      {
        Element ndTmp = (oracle.xml.parser.v2.XMLElement) nodes.item(i);
        if (TAG_SOURCE_TYPE.equalsIgnoreCase(ndTmp.getNodeName()))
        {
          //
          // Load Source tag definitions
          //
          
          NodeList ndTypes = ndTmp.getElementsByTagName(TAG_TYPE);
          int typeCnt = ndTypes.getLength();
          for (int j = 0; j < typeCnt; j++)
          {
            attribs.setNamedNodeMap(ndTypes.item(j).getAttributes());
            mDbgLog.fine("Supports JDev Node: " + attribs.getValue(ATTR_JDEV_NODE));
            mSupportedSourceTypes.put(
              attribs.getValue(ATTR_TYPE_NAME), 
              attribs.getValue(ATTR_JDEV_NODE));
          }
        }
        else if (TAG_SCHEMA.equalsIgnoreCase(ndTmp.getNodeName()))
        {
          // Load the schema tag
          attribs.setNamedNodeMap(ndTmp.getAttributes());
          mDbgLog.fine("Schema: " + attribs.getValue(ATTR_LOCATION));
          mSchema.put(attribs.getValue(ATTR_NS), 
                      attribs.getValue(ATTR_LOCATION));
        }  
        else if (TAG_DEPENDENCIES.equalsIgnoreCase(ndTmp.getNodeName()))
        {
          // Load the jars if any
          NodeList ndLibs = ndTmp.getElementsByTagName(TAG_LIBRARY);
          int cntLib = ndLibs.getLength();
          for (int j = 0; j < cntLib; j++)
          {
            attribs.setNamedNodeMap(ndLibs.item(j).getAttributes());
            mDbgLog.fine("Library: " + attribs.getValue(ATTR_PATH));
            mLibraries.add(attribs.getValue(ATTR_PATH));
          }
        }
        else if (TAG_JDEV_CTX_HOOK.equalsIgnoreCase(ndTmp.getNodeName()))
        {
          // Get the jdev context hook class name
          mJDevCtxHookName = ndTmp.getAttribute(ATTR_JDEV_CTX_HOOK_CLASS);
          
        }
        else if (TAG_PROPERTIES.equalsIgnoreCase(ndTmp.getNodeName()))
        {
          // Load the properties
          NodeList ndTypes = ndTmp.getElementsByTagName(TAG_PROPERTY);
          int typeCnt = ndTypes.getLength();
          for (int j = 0; j < typeCnt; j++)
          {
            attribs.setNamedNodeMap(ndTypes.item(j).getAttributes());
            mProperties.put(
              attribs.getValue(ATTR_PROP_NAME), 
              attribs.getValue(ATTR_PROP_VALUE));
          }
        }  
      }
    }
    finally
    {

    }
  }
  


  /**
   * Loads a definition file.
   */
  private static void loadAdapterDefinition(InputStream is)
  {
    try
    {
      // Get the input stream
      if (is == null)
      {
        throw new AdapterException(ADFmMessageBundle.class, 
          ADFmMessageBundle.EXC_ADAPTER_DEF_LOAD_FAILED);
      }

      // Parse it
      DOMParser dp = new DOMParser();
      dp.setPreserveWhitespace(false);
      dp.parse(is);
      XMLDocument xd = dp.getDocument();
      Node root = xd.getDocumentElement();

      // Load it
      NodeList nodes = root.getChildNodes();
      int cnt = nodes.getLength();
      NodeAttributeHelper attribs = new NodeAttributeHelper();
      for (int i = 0; i < cnt; i++)
      {
        Node nd = nodes.item(i);
        if (TAG_ADAPTER.equalsIgnoreCase(nd.getNodeName()))
        {
          AdapterDefinition def = new AdapterDefinition(nd);
          sDefinitionStore.put(def.getName(), def);
        }
      }

    }
    catch (IOException e)
    {
      throw new AdapterException(ADFmMessageBundle.class, 
        ADFmMessageBundle.EXC_ADAPTER_DEF_LOAD_FAILED);
    }
    catch (SAXException e)
    {
      throw new AdapterException(ADFmMessageBundle.class, 
        ADFmMessageBundle.EXC_ADAPTER_DEF_SYNTAX);
    }
    finally
    {

    }

  }


}
