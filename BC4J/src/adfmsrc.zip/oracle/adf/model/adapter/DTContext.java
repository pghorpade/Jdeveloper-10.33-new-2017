/*
 * @(#)DTContext.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.adapter;

import java.util.HashMap;
import java.util.Map;

import oracle.adf.share.logging.ADFLogger;

/**
 * Design time context holds the context information required to get information 
 * from the data source to define an instance.
 * <p>
 * When a  design time starts, it creates a <code>DTContext</code> for it and
 * registers it with this class. 
 * Each implementation should override the <code>getConnectionContext()</code> 
 * method to provide a design time specific context.
 */
public abstract class DTContext extends AdapterContext
{
  //============================================================================
  // Key names 
  //============================================================================

  /** Key to get the JDeveloper context. */
  public static final String JDEV_CONTEXT = "jdev_context";

  //============================================================================
  // Static Methods 
  //============================================================================

  // Current DT context
  private static DTContext sCurCtx = null;
  // Logger
  private ADFLogger mLogger;

  /**
   * Sets the current design time implementation of this class.
   */
  public static void setCurrentContextImpl(DTContext impl)
  {
    sCurCtx = impl;
  }

  /**
   * Gets the design time context as implemented by the current design time.
   */
  public static DTContext getInstance()
  {
    // if this method is called even before the current ctx impl is set, return
    // the null impl
    if (sCurCtx == null)
    {
      sCurCtx = new NullDTContext();
    }

    return sCurCtx;
  }

  //===========================================================================
  // Implementations
  //===========================================================================

  /**
   * Returns the logger for this context.
   */
  public ADFLogger getLogger()
  {
    if (mLogger == null)
    {
      mLogger =
        (ADFLogger) ADFLogger.createADFLogger("oracle.adf.model.adapter.dt");
    }

    return mLogger;
  }

}


/**
 * A default implementation of the DTContext. It does nothing but a place holder
 * for a null implementation.
 */
class NullDTContext extends DTContext
{
}
