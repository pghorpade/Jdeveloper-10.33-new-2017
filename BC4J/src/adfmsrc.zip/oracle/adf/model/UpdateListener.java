package oracle.adf.model;

/**
 * This Listener will be notified that the associated attribute
 * has been updated and hence the renderer needs to re-render
 * the attribute value.
 */
public interface UpdateListener extends oracle.binding.UpdateListener
{
   /**
    * Notification to the listener that the attribute value has
    * changed and needs to be rendered again.
    */
   public void updateRenderer ();
}

