/*
 * @(#)DCTransactionStateListener.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

/**
 * Implemented by controls/classes that need to react to a change in a
 * transaction's state. Typically, controls like status bar and navigation bar
 * need to update their display with a dirty flag/button that indicates whether
 * the ensuing transaction is clean or not. Those classes can implement this
 * interface and add themselves to the DCApplication's transaction state listener's list 
 * so that they get notified of the change.
 *
 * @see oracle.jbo.uicli.controls.JUNavigationBar
 * @see oracle.jbo.uicli.binding.JUApplication
 */
public interface DCTransactionStateListener
{
   /**
   * Invoked when the transaction is either marked dirty or clean. 
   * @param state Indicates if the transaction was marked clean (true) or dirty (false).
   * Controls like NavigationBar then disables/enables the Save button to indicate 
   * there are changes that need to be saved/committed to the database.
   */
   void transactionStateChanged(boolean state);
   
   /**
    * Framework calls this method when it needs to indicate that the connection to is being released. 
    */
   void release();
}
