/*
 * @(#)DCBindingContainerValidationAdapter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

/**
 * Default implementation for DCBindingContainerValidationListener interface.
 * This implementation simply prints a diagnostic message for each
 * event it receives. JClient design time creates a subclass of this
 * adapter with overridden methods as per an application's choice
 * when the Event Inspector is used to generate DCBindingContainerValidationEvent
 * listener code.
 */
public class DCBindingContainerValidationAdapter implements DCBindingContainerValidationListener
{
   public void beforeSetAttribute(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSetAttribute");   //NONLS
   }
   
   public void beforeCurrencyChange(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeCurrencyChange"); //NONLS
   }

   public void beforeSaveTransaction(DCBindingContainerValidationEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeSaveTransaction");//NONLS
   }
}
