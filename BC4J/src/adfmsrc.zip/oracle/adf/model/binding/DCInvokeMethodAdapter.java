/*
 * @(#)DCInvokeMethodAdapter.java
 *
 * Copyright 2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

/**
 * Default adapter for DCInvokeMethodListener event.
 */
public class DCInvokeMethodAdapter implements DCInvokeMethodListener
{
   public void beforeInvokeMethod(DCInvokeMethodEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("beforeInvokeMethod :" + ev.getMethodInfo().getOperationName());
   }

   public void afterInvokeMethod(DCInvokeMethodEvent ev)
   {
      oracle.jbo.common.DebugDiagnostic.println("afterInvokeMethod :" + ev.getMethodInfo().getOperationName());
   }
}
