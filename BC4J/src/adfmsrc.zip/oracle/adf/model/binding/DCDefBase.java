/*
 * @(#)DCDefBase.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * //NONLS
 */

package oracle.adf.model.binding;

import java.util.HashMap;
import java.util.ArrayList;
import oracle.jbo.PersistenceException;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;

abstract public class DCDefBase extends DefinitionObject
{
   private String mDefClassName;
   private String mSubType;
   private boolean mIsDirty;

   public static final String DEF_XMLNS_BASE = "http://xmlns.oracle.com/adfm/"; //RF: allow reuse
   public static final String DEF_XMLNS = DEF_XMLNS_BASE+"uimodel";
   public static final String PNAME_Action            =  "DCAction";
   public static final String PNAME_Button            =  "DCButton";
   public static final String PNAME_ButtonGroup       =  "DCButtonGroup";
   public static final String PNAME_ComboBox          =  "DCComboBox";
   public static final String PNAME_DefaultControl    =  "DCDefaultControl";
   public static final String PNAME_FormattedTextField=  "DCFormattedTextField";
   public static final String PNAME_Graph             =  "DCGraph";
   public static final String PNAME_Label             =  "DCLabel";
   public static final String PNAME_ListSingleSel     =  "DCListSingleSel";
   public static final String PNAME_LovButton         =  "DCLovButton";
   public static final String PNAME_NavigationBar     =  "DCNavigationBar";
   public static final String PNAME_ScrollBar         =  "DCScrollBar";
   public static final String PNAME_ScrollBarAttr     =  "DCScrollBarAttr";
   public static final String PNAME_Spinner           =  "DCSpinner";
   public static final String PNAME_Table             =  "DCTable";
   public static final String PNAME_DynamicTable      =  "DCDynamicTable";
   public static final String PNAME_TextField         =  "DCTextField";
   public static final String PNAME_Tree              =  "DCTree";
   public static final String PNAME_Panel             =  "DCPanel";
   public static final String PNAME_Range             =  "DCTable";
   public static final String PNAME_Boolean           =  "DCListSingleSel";
   public static final String PNAME_Parameter         =  "DCParameter";
   public static final String PNAME_ProgressBar       =  "DCProgressBar";
   public static final String PNAME_ProgressBarAttr   =  "DCProgressBarAttr";
   public static final String PNAME_Slider            =  "DCSlider";
   public static final String PNAME_SliderAttr        =  "DCSliderAttr";
   public static final String PNAME_Iterator          =  "DCIterator";
   public static final String PNAME_MethodIterator    =  "DCMethodIterator";
   public static final String PNAME_AccessorIterator  =  "DCAccessorIterator";
   public static final String PNAME_ToplinkIterator   =  "DCToplinkIterator";
   public static final String PNAME_EnumList          =  "DCEnumList";

   public static final String PNAME_HGrid             =  "DCHGrid";

   public static final String PNAME_LOVList           = "DCLOVList";
   public static final String PNAME_NavigationList    = "DCNavigationList";
   public static final String PNAME_MethodAction      = "DCMethodAction";
   public static final String PNAME_DataControlAction = "DCDataControlAction";

   public DCDefBase()
   {
      setDefClassName(getClass().getName());

      initSubType();
   }


   public DCDefBase(String name)
   {
      setDefClassName(getClass().getName());

      setName(name);

      initSubType();
   }


   public void init(HashMap initValues)
   {
      Object val;

      if ((val = initValues.get(JUTags.DefClass)) != null)
      {
         setDefClassName(mDefClassName);
      }

      if ((val = initValues.get(JUTags.NAME)) != null)
      {
         setName(val.toString());
      }

      // It will be name or id, look for both
      if ((val = initValues.get(JUTags.ID)) != null)
      {
         setName(val.toString());
      }

      if ((val = initValues.get(JUTags.SubType)) != null)
      {
         setSubType(val.toString());
      }
   }


   protected void initSubType()
   {
      mSubType = JboNameUtil.getLastPartOfName(getClass().getName());

      if (mSubType.endsWith("Def"))
      {
         mSubType = mSubType.substring(0, mSubType.length() - "Def".length());
      }
   }


   public String getSubType()
   {
      return mSubType;
   }


   public void setSubType(String subType)
   {
      mSubType = subType.intern();
   }


   public String getDefClassName()
   {
      return mDefClassName;
   }


   public void setDefClassName(String defClassName)
   {
      mDefClassName = defClassName;
   }


   public boolean isDirty()
   {
      return mIsDirty;
   }


   public void setDirty(boolean isDirty)
   {
      mIsDirty = isDirty;
   }


   public boolean isNew()
   {
      return false;
   }


   public void setNew(boolean isNew)
   {
   }


   static public void readXMLString(DefElement xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, str);
      }
   }


   static public void readXMLInt(DefElement xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, new Integer(str));
      }
   }


   static public void readXMLBoolean(DefElement xmlElement, String name, HashMap valueTab)
   {
      String str = xmlElement.readString(name);

      if (str != null)
      {
         valueTab.put(name, new Boolean(str));
      }
   }


   static public void readXMLStringArray(DefElement xmlElement, String name, HashMap valueTab)
   {
      com.sun.java.util.collections.ArrayList arrList = xmlElement.readStringArrayListElement(name);

      if (arrList != null && arrList.size() > 0)
      {
         String[] arr = new String[arrList.size()];

         arrList.toArray(arr);

         valueTab.put(name, arr);
      }
   }

   static public void readXMLStringArrayList(DefElement xmlElement, String name, ArrayList list)
   {
      com.sun.java.util.collections.ArrayList arrList = xmlElement.readStringArrayListElement(name);

      if (arrList == null)
         return;

      for(int i = 0 ; i < arrList.size(); i++)
      {
         list.add(arrList.get(i));
      }
   }

   static public void readXMLStringArrayList(DefElement xmlElement, String name, HashMap valueTab)
   {
      com.sun.java.util.collections.ArrayList arrList = xmlElement.readStringArrayListElement(name);
      int size = arrList.size();
      if (size > 0)
      {
         java.util.ArrayList al = new java.util.ArrayList(size);
         for (int i = 0; i < size; i++)
         {
            al.add(arrList.get(i));
         }
         valueTab.put(name, al);
      }
   }



   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      readXMLString(xmlElement, JUTags.ID, valueTab);
      readXMLString(xmlElement, JUTags.NAME, valueTab);
      readXMLString(xmlElement, JUTags.SubType, valueTab);
   }


   protected void loadChildrenFromXML(DefElement xmlElement)
   {
   }


   public void loadFromXML(DefElement xmlElement)
   {
      HashMap initValues = new HashMap(20);

      retrieveFromXML(xmlElement, initValues);

      init(initValues);

      // load children outside of the <Contents> section
      loadChildrenFromXML(xmlElement);

      // load children inside of <Contents> Section
      DefElement container = xmlElement.findChildElement(JUTags.Contents);
      if(container != null)
      {
         loadChildrenFromXML(container);
      }
   }


   static public DCDefBase createAndLoadFromXML(DefElement xmlElement, String defSubType)
   {
      DCDefBase defObj = null;
      String defClassName = xmlElement.readString(JUTags.DefClass);
      String subTypeName = xmlElement.readString(JUTags.SubType);

      if(defClassName != null)
      {
         defObj = (DCDefBase) DCUtil.createNewInstance(defClassName);
         defObj.setDefClassName(defClassName);
      }
      else if (JUMetaObjectManager.getJUMom().getControlDefFactory() != null)
      {
         if (subTypeName == null)
         {
            subTypeName = defSubType;
         }

         if(subTypeName != null)
         {
            defObj = JUMetaObjectManager.getJUMom().getControlDefFactory().createDefinition(xmlElement);
         }
         else
         {
           String nameSpace = xmlElement.getNamespaceURI();

           if(nameSpace == null || nameSpace.equals(""))
           {
              //
              // xmlElement.getNamespaceURI() will return null or ""
              // if the parser that created xmlElement is not namespace-aware.
              // That is currently the case for the DOMParser that the non-MDS
              // implementation creates.
              //
              // As a hack, we look for the xmlns attribute.
              // This works for top-level elements and for lower-level elements
              // that explicitly specify the xmlns attribute.
              //
              nameSpace = xmlElement.getAttribute("xmlns");
              if (nameSpace == null || nameSpace.equals(""))
              {
                 nameSpace = DEF_XMLNS;
              }
           }

           // get the namespace factory, all 10.1.3 creations are done here
           DefinitionFactory factory;

           factory = JUMetaObjectManager.getJUMom().getDefinitionFactory(nameSpace);
           defObj = factory.createDefinition(xmlElement);
         }
      }

      if (defObj == null)
      {
         throw new PersistenceException(UIMessageBundle.class,
                                        UIMessageBundle.EXC_DEF_CLASS_NAME_MISSING,
                                          new String[] { xmlElement.getTagName() });
      }

      if (defObj != null)
      {
         defObj.loadFromXML(xmlElement);
      }

      return defObj;
   }

   abstract public String getXMLElementTag();

   static public int convertToInt(Object val)
   {
      if (val instanceof Integer)
      {
         return ((Integer) val).intValue();
      }
      else
      {
         return new Integer((String) val).intValue();
      }
   }


   static public boolean convertToBoolean(Object val)
   {
      if (val instanceof Boolean)
      {
         return ((Boolean) val).booleanValue();
      }
      else
      {
         return new Boolean((String) val).booleanValue();
      }
   }


   static public int[] convertToIntArray(Object[] arr)
   {
      int[] retVal = new int[arr.length];

      for (int j = 0; j < arr.length; j++)
      {
         Object elm = arr[j];

         if (elm instanceof Integer)
         {
            retVal[j] = ((Integer) elm).intValue();
         }
         else
         {
            retVal[j] = new Integer(elm.toString()).intValue();
         }
      }

      return retVal;
   }
}
