/*
 * @(#)DCControlBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.common.JboBeanUtils;
import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.UpdateListener;
import oracle.adf.model.BindingContext;
import oracle.adf.model.PermissionInfo;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttrValException;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.Transaction;
import oracle.jbo.ValidationException;
import oracle.jbo.ViewObject;

import java.util.List;

/**
 * The base class for all binding objects in the ADF framework that bind
 * a View control/model to an object or an attribute of an object in a DataControl. This class manages:
 * <ul>
 * <li>The references to the View control object.
 * <li>The IteratorBinding with which the binding object is in association
 * <li>The container binding that this binding belongs to
 * <li>The internal-state for findMode
 * </ul>
 * <p>
 * This class also implements helper methods to access DataProvider objects like the DataProvider object itself,
 * the current Application Module, the ViewObject or the DataProvider object that this control binding is working with,
 * the current RowIterator, the current Row in the iterator that this control binding
 * is associated with.
 *
 *
 * @javabean.class name=DCControlBinding
 */
abstract public class DCControlBinding extends JboAbstractMap
{
   String mName;
   private Object mControl;
   private DCIteratorBinding mIterBinding;

   //package private only for use in DCparameter to set custom logic for bc.
   DCBindingContainer mBindingContainer;
   private DCControlBindingDef mControlDef;

   protected UpdateListener mAttributeListener;

   protected PermissionInfo mPermissionInfo = null;

   protected DCControlBinding()
   {
   }

   /**
   * Constructor used in the framework to pass in the Swing control and the Iterator Binding
   * with which this binding object works to get it's data.
   */
   public DCControlBinding(Object control, DCIteratorBinding iterBinding)
   {
      mControl = control;
      mIterBinding = iterBinding;

      //why do we do this? This leads to an early addition of this binding
      //in the bindingContainer and when we set the name again, the 
      //container has to adjust.
      //if (iterBinding != null)
      //{
      //   setBindingContainer(iterBinding.getBindingContainer());
      //}
   }

   
   /**
   * @internal *** For internal framework use only *** 
   */
   //abstract public void addControlToPanel(Object panel, Object layoutObject, Object layoutCons);

   
   /**
   * @internal *** For internal framework use only ***
   *
   */
   public final String getName()
   {
      return mName;
   }

   protected void internalSetName(String name)
   {
      mName = name;
   }

   void setDCIteratorBinding(DCIteratorBinding iter)
   {
      if (iter != mIterBinding /*&& mIterBinding != null*/)
      {
         mIterBinding = iter;
         
         //also set the right bindingcontainer from the new iterator.
         //this call removes me from the current BC and adds me to the 
         //new one (if different).
         setBindingContainer (iter.getBindingContainer());
      }
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void setName(String name)
   {
      if (mName == null && name == null)
      {
         return;
      }
      
      if (mName != null)
      {
         if (mName.equals(name))
         {
            return;
         }

         if (mBindingContainer != null)
         {
            mBindingContainer.removeControlBinding(this);
         }
      }

      mName = name;
      
      if (mBindingContainer != null)
      {
         mBindingContainer.addControlBinding(this);
      }
   }
                           
   public final String getFullName()
   {
      StringBuffer sBuff = new StringBuffer();

      sBuff.append(getBindingContainer().getFullName())
           .append(DCUtil.SEP_DOT_CHAR)
           .append(getName());

      return sBuff.toString();
   }
   
   public String getDefName()
   {
      if (mControlDef != null)
      {
         mControlDef.getName();
      }

      return null;
   }

   public String getDefFullName()
   {
      if (mControlDef != null)
      {
         mControlDef.getFullName();
      }

      return null;
   }

   /**
   * Report the given exception via the containing BindingContainer object.
   */
   public void reportException(Exception ex)
   {
      getBindingContainer().reportException(ex);
   }


   /**
   * Returns the form binding object that this control binding is part
   * of.
   *
   */
   public final DCBindingContainer getBindingContainer()
   {
      //move logic to fetch a bindingContainer from iteratorBinding here
      //for old JClient cases where constructor used to do this, and didn't
      //set binding names and then call addControlBinding.
      if (mBindingContainer == null && mIterBinding != null) 
      {
         setBindingContainer(mIterBinding.getBindingContainer());
      }
      return mBindingContainer;
   }

   
   /**
   * @internal *** For internal framework use only *** 
   */
   public void setBindingContainer(DCBindingContainer formBnd)
   {
      if (formBnd != mBindingContainer)
      {
         if (mBindingContainer != null)
         {
            mBindingContainer.removeControlBinding(this);
         }

         mBindingContainer = formBnd;

         if (mBindingContainer != null)
         {
            mBindingContainer.addControlBinding(this);
         }
      }
   }

   
   /**
   * @internal *** For internal framework use only *** 
   */
   public final DCControlBindingDef getDef()
   {
      return mControlDef;
   }
   
   /**
   * @internal *** For internal framework use only *** 
   */
   void setDef(DCControlBindingDef controlDef)
   {
      mControlDef = controlDef;
   }
   
   
   /**
   * Returns the iterator binding with which this control binding is
   * associated to get it's data.
   *
   */
   public final DCIteratorBinding getDCIteratorBinding()
   {
      return mIterBinding;
   }

   
   /**
   * Returns the Transaction object for the current BC4J session.
   *
   */
   public Transaction getTransaction()
   {
      if (mIterBinding == null)
      {
         return null;
      }
      
      synchronized(mIterBinding.getSyncLock())
      {
         ApplicationModule am = getApplicationModule();

         if (am != null)
         {
            return getApplicationModule().getTransaction();
         }
         else
         {
            return null;
         }
      }
   }

   
   /**
   * Returns the Application Module to which this control's ViewObject belongs. 
    * Returns null in case of non-bc4j bound DataControls.
    *
   */
   public ApplicationModule getApplicationModule()
   {
      if (mIterBinding == null)
      {
         return null;
      }
      
      synchronized(mIterBinding.getSyncLock())
      {
         ViewObject vo = getViewObject();

         if (vo != null)
         {
            return getViewObject().getApplicationModule();
         }
         else
         {
            return null;
         }
      }
   }

   
   /**
   * Returns the ViewObject for which this control is displaying data.
   * Returns null in case of non-bc4j bound data-controls.
   *
   */
   public ViewObject getViewObject()
   {
      return (mIterBinding != null) ? mIterBinding.getViewObject() : null;
   }


   /**
   * Returns the current RowIterator with which this control binding is working. 
   * This will return an instance of ViewCriteria object if the associated IteratorBinding
   * is in find mode. Otherwise, it returns an instance of
   * RowSetIterator.
   *
   */
   public RowIterator getRowIterator()
   {
      return (mIterBinding != null) ? mIterBinding.getNavigatableRowIterator() : null;
   }

   
   /**
   * Calls DCIteratorBinding.executeQuery which in turn executes the query to repopulate
   * the rows for the RowSet with which this control is working.
   */
   public void executeQuery()
   {
      mIterBinding.executeQuery();
   }

   /**
   * Calls DCIteratorBinding.executeQueryIfNeeded which in turn executes the query to repopulate
   * the rows for the RowSet with which this control is working, if it is not already executed.
   */
   public void executeQueryIfNeeded()
   {
      mIterBinding.executeQueryIfNeeded();
   }

   
   /**
   * Returns the current row for which this control is displaying data. In find mode, this will
   * return an instance of ViewCriteriaRow, whereas in data mode it returns a Row object.
   * This method should be used to get the current Row to which this control is bound in order
   * to perform any validations on the control-value or data stored in
   * the row.
   *
   */
   public Row getCurrentRow()
   {
      if (mIterBinding != null)
      {
         return mIterBinding.getCurrentRow();
      }
      return null;
   }

   
   /**
   * Returns the row of given range index.
   *
   * @param rangeIndex range index of the row.
   */
   public Row getRowAtRangeIndex(int rangeIndex)
   {
      return mIterBinding.getRowAtRangeIndex(rangeIndex);
   }

   
   /**
   * Returns the rows in current range in the RowIterator with which
   * this control binding is working.
   *
   */
   public Row[] getAllRowsInRange()
   {
      return (mIterBinding != null) ? mIterBinding.getAllRowsInRange() : null;
   }

   
   /**
   * Gets the associated View (Swing) control.
   */
   public Object getControl()
   {
      return mControl;
   }


   /**
   * Gets the associated View's model object. By default return this binding
   * object. If subclasses have their own View models that work with like say
   * ButtonModel for JUButtonBinding, then return that.
   * <p>
   * This method is primarily for use by the generated binding calls so that
   * it returns a proper 'typed' model object for that binding type and control 
   * combination.
   */
   public Object getControlModel(Object control)
   {
      return this;
   }


   /**
   * Sets the associated Swing control.
   * @internal *** For internal framework use only *** 
   */
   public void setControl(Object control)
   {
      if (mControl == null)
      {
         mControl = control;
      }
      else if (mControl != control && control != null)
      {
         throw new JboException(ADFmMessageBundle.EXC_CONTROLBINDING_NOT_REUSABLE);
      }
   }


   /**
   * @internal *** For internal framework use only *** 
   */
   public Object getLayoutObject()
   {
      return mControl;
   }

   /**
   * Returns true if this control can participate in find form. Note that some controls
   * like ProgressBar cannot participate in a find form as they do no accept user inputs.
   * By default this method returns false and it's up to the individual control bindings
   * to determine whether they can participate in a find mode.
   * @internal *** For internal framework use only *** 
   */
   protected boolean isControlQueriable()
   {
      return false;
   }

   /**
    * Primarily for spel support. Returns cached exception for some bindings.
    * <p>
    * Returns exception that occured on last setInputValue 
    */
   protected JboException getError()
   {
      return null;
   }

   /**
    * Primarily for spel support. Returns cached exceptions for some bindings.
    * <p>
    * Returns a list of exceptions that occured on last setInputValue 
    */
   protected List getErrors()
   {
      return null;
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   protected void processInputException(ValidationException vex)
   {
      //do nothing.
      //those bindings interested in input exceptions will process this.
   }

   /**
   * Resets any exceptions and client-side values that this binding may hold.
    * This is used by control-bindings to reset their state before refreshing
    * values from the MT.
   * @internal *** For internal framework use only *** 
   */
   protected abstract void resetInputState();

   /**
    * Invoked when the bindingContainer is being initialized for the first
    * time or after it's locale is changed. This gives subclasses a chance
    * to drop their initialized locale based resources.
    */
   protected abstract void initResources();
   
   /**
   * Updates the values in a control that is bound using an Iterator already in use.
   * (a valid row iterator)
   * If you do not call this method, your control won't update unless you refresh the Iterator.
   */
   public abstract void refreshControl();

   //not public as we don't anticipate individual controls to unbind from BC4J. It should
   //be done at the "Iterator" or "Panel" binding levels.
   /**
   * @internal *** For internal framework use only *** 
    */
   protected void release(int flags)
   {
      if (flags == DCDataControl.REL_ALL_REFS)
      {
         setBindingContainer(null);
         if (mIterBinding != null) 
         {
            mIterBinding = null;
         }
      }

      if ((flags & DCDataControl.REL_VIEW_REFS) > 0)
      {
         mControl = null;
      }
   }

   //return true if needs to fetch estimated row count eagerly.
   //Table, Scrollbar, ProgressBar, Slider needs this.
   protected boolean needsEstimatedRowCount()
   {
      return false;
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   protected void removeFromDCExceptions()
   {
      DCIteratorBinding iterB = mIterBinding;
      DCDataControl dc = null;

      if (iterB != null)
      {
         dc = iterB.getDataControl();
      }

      if (dc == null && getBindingContainer() != null)
      {
         dc = getBindingContainer().getDataControl();
      }

      if (dc != null)
      {
         dc.removeBindingWithExc(getFullName());
      }
   }


   /**
   * @internal *** For internal framework use only *** 
    * Used to reset the attribute value in row to original attribute value
    * so that any cached exceptions are dropped.
   */
   protected void resetAttributeExceptionInRow(Row row, AttributeDef def, AttrValException ave)
   {
      DCIteratorBinding iterB = mIterBinding;
      DCDataControl dc = null;

      if (iterB != null)
      {
         dc = iterB.getDataControl();
      }

      if (dc == null && getBindingContainer() != null)
      {
         dc = getBindingContainer().getDataControl();
      }

      if (dc != null)
      {
         dc.resetAttributeExceptionInRow(iterB, row, def, ave);
      }
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   protected void addToDCExceptions(JboException e)
   {
      DCIteratorBinding iterB = mIterBinding;
      DCDataControl dc = null;

      if (iterB != null)
      {
         dc = iterB.getDataControl();
      }

      if (dc == null && getBindingContainer() != null)
      {
         dc = getBindingContainer().getDataControl();
      }

      if (dc != null)
      {
         dc.addBindingWithExc(getFullName());
      }
      /**
      else
      {
           ** Bug#3107876
           **We should not throw here, if the error cannot be added to the data
           **control, let it be added to the binding container by the caller
          
          //throw e; //should this rethrow or eat this up.!
      }
      **/
   }

   //this is the public api that should be visible to spel via code-insight
   //we need to do a bean info for each of the control bindings to indicate
   //what apis are exposed in this method.
   static public final String ROW_KEY_STR              = "rowKeyStr";       //NONLS
   static public final String ATTR_ITER                = "iteratorBinding";       //NONLS
   static public final String ATTR_DEF                 = "def";        //NONLS
   static public final String ATTR_ERROR               = "error";      //NONLS
   static public final String ATTR_ERRORS              = "errors";    //NONLS
   static public final String ATTR_FULLNAME            = "fullName";   //NONLS
   static public final String ATTR_NAME                = "name";       //NONLS
   static public final String ATTR_CURRENTROW          = "currentRow";       //NONLS
   
   /**
    * @see #internalGet(String) for valid keyObj values 
   */
   public final Object get(Object keyObj)
   {
      //since el engines won't introspect once a class is found to be a bean.
      //need to check for null returns and then call beanutils.
      Object retObj;
      if (keyObj instanceof String)
      {
         String key = ((String)keyObj).intern();

         //set mInternalGet_KeyResolved when internalGet resolves this key
         mInternalGet_KeyResolved = false;
         retObj = internalGet(key);
         if (retObj == null  && !mInternalGet_KeyResolved)
         {
            //try bean lookup as current spel stuff won't do that otherwise.
            try
            {
               retObj = JboBeanUtils.getProperty(this, key);
            }
            catch (Exception e)
            {
               //ignore any exceptions.
               retObj = null;
            }
         }
      }
      else
      {
         retObj = super.get(keyObj);
      }
      return retObj;
   }

   protected boolean mInternalGet_KeyResolved = false;
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>def</code> - returns getDef()</li>
    * <li><code>error</code>  - returns getError()</li>
    * <li><code>errors</code>  - returns getErrors()</li>
    * <li><code>fullName</code> - returns getFullName()</li>
    * <li><code>name</code> - returns getName()</li>
    * <li><code>currentRow</code> - returns getCurrentRow()</li>
    * <li><code>iteratorBinding</code> - returns getDCIteratorBinding()</li>
    * <li><code>rowKeyStr</code> - returns String format of the current row's key</li>
    */
   protected Object internalGet(String key)
   {
      key = key.intern();

      //we could implement a better scheme here but to start with 
      //go with if/then/else.
      if (key == ATTR_ITER)
      {
         mInternalGet_KeyResolved = true;
         return getDCIteratorBinding();
      }
      if (key == ROW_KEY_STR)
      {
         return getCurrentRow().getKey().toStringFormat(true);
      }
      if (key == ATTR_DEF)
      {
         mInternalGet_KeyResolved = true;
         return getDef();
      }
      if (key == ATTR_ERROR)
      {
         mInternalGet_KeyResolved = true;
         return getError();
      }
      if (key == ATTR_ERRORS)
      {
         mInternalGet_KeyResolved = true;
         return getErrors();
      }
      if (key == ATTR_CURRENTROW)
      {
         mInternalGet_KeyResolved = true;
         return getCurrentRow();
      }
      if (key == ATTR_FULLNAME)
      {
         mInternalGet_KeyResolved = true;
         return getFullName();
      }
      if (key == ATTR_NAME)
      {
         mInternalGet_KeyResolved = true;
         return getName();
      }
      return super.internalGet(key);
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public int hashCode()
   {
      return (mName != null) ? mName.hashCode() : super.hashCode();
   }

   public String toString()
   {
      return getName();
   }

   public void setListener(UpdateListener listener)
   {
      mAttributeListener = listener;
   }

   public void setListener(oracle.binding.UpdateListener listener)
   {
      mAttributeListener = oracle.adf.model.utils.Adapt227.wrapJSRUpdateListener(listener);
   }

   DCBindingContainer internalGetBindingContainer()
   {
      return mBindingContainer;
   }

  /**
   * @internal *** For internal framework use only *** 
   */
   protected boolean internalHasPermission(String action)
   {
      return true; 
   }

  /**
   * @internal *** For internal framework use only *** 
   */
   protected boolean internalHasPermission(String target, String action)
   {
      return true; 
   }

   public String getPermissionTargetName()
   {
      if (mIterBinding != null)
      {
	 return mIterBinding.getPermissionTargetName();
      }
      return mName;
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.ROWSET_PERMISSION);
      }
      return mPermissionInfo;
   }
}
