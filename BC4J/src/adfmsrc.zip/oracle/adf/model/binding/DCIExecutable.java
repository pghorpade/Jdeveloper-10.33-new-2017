package oracle.adf.model.binding;

/**
 * *** For internal framework use only ***
 * Implemented by RegionBinding, IteratorBinding and ActionReference,
 * the three default executable binding implementations.
 */
public interface DCIExecutable
{
   static final int EXECUTABLE_REGION          = DCIExecutableDef.EXECUTABLE_REGION;
   static final int EXECUTABLE_ITERATORBINDING = DCIExecutableDef.EXECUTABLE_ITERATORBINDING;
   static final int EXECUTABLE_ACTION          = DCIExecutableDef.EXECUTABLE_ACTION;

   void refresh(int id);
   int getExecutableType();
   void release(int flags);
   String getName();
   void setName(String name);
   int getRefreshOption();
   String getRefreshExpression();
   void setRefreshOption(int x);
   void setRefreshExpression(String x);
   void setRefreshed(boolean flag);
   boolean isRefreshed();
   boolean refreshIfNeeded();

   /**
    * Called by isRefreshable to find out if the parameters
    * for this executable has changed/mutated and thus the
    * executable should be refreshed. If true, then in
    * case of optimized or default refresh steps, the
    * executable binding is refreshed.
    */
   boolean hasRefreshParametersChanged();

   DCIExecutableDef getExecutableDef();
   void setExecutableDef(DCIExecutableDef execdef);

   void setBindingContainer(DCBindingContainer ctr);
   DCBindingContainer getBindingContainer();
}
