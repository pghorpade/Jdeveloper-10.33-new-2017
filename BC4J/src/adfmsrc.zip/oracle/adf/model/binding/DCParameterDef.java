/*
 * @(#)DCParameterDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.HashMap;


import oracle.jbo.uicli.mom.JUTags;

import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.StringManager;
import oracle.jbo.mom.xml.DefElement;

import oracle.jbo.ReadOnlyAttrException;
import oracle.jbo.CSMessageBundle;

public class DCParameterDef extends DCControlBindingDef implements DCIBaseParameterDef
{
   
   private boolean mReadOnly;
   private boolean mIsLazy = false;
   String mExpression;
   private int mOption = PARAM_DEFAULT;

   public DCParameterDef()
   {
   }

   protected void initSubType()
   {
      setSubType(JUTags.parameter);
   }

   protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd)
   {
      //kava creates bindings with null iterators as well.
      //do not set bindingContainer here. That needs to be done after name
      //is set on this parameter.
      return new DCParameter(getExpression());
   }

   public final String getExpression()
   {
      return mExpression;
   }

   public final void setExpression(String value)
   {
      if (isReadOnly()) 
      {
         throw new ReadOnlyAttrException(ReadOnlyAttrException.TYP_COMPONENT_OBJECT,
                                         CSMessageBundle.class,
                                         CSMessageBundle.EXC_VAL_VR_ATTR_SET_FAILED,
                                         getBindingContainerDef().getName(),
                                         getName());
      }
      mExpression = value;
   }

   /**
    * Return false if this parameter's expression is allowed to be updateable at runtime via setExpression
    */
   public final boolean isReadOnly()
   {
      return mReadOnly;
   }

   /**
    * Return true if a value for this parameter has to be passed in in the usage of this parameter's container.
    */
   public final boolean isMandatory()
   {
      return mOption == PARAM_MANDATORY;
   }


   public final boolean isOptional()
   {
      return mOption == PARAM_OPTIONAL;
   }

   /**
    * A usage cannot override this parameter expression.
    */
   public final boolean isFinal()
   {
      return mOption == PARAM_FINAL;
   }

   public int getOptionFlag()
   {
      return mOption;
   }

   /**
    * May be used to skip parameter evaluation during refresh.
    */
   final boolean isLazy()
   {
      return mIsLazy;
   }

   //*********************
   //*** load routines ***
   //*********************
   public static final String PNAME_Value         ="value";
   public static final String PNAME_Option        ="option";
   public static final String PNAME_ReadOnly      ="readonly";
   public static final String PNAME_Lazy          ="lazy";

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      readXMLInt(xmlElement, PNAME_Option, valueTab);
      readXMLBoolean(xmlElement, PNAME_ReadOnly, valueTab);
      readXMLBoolean(xmlElement, PNAME_Lazy, valueTab);

      String str = xmlElement.readString(PNAME_Value);
      if (str != null) 
      {
         valueTab.put(PNAME_Value, str);
      }
   }

   /**
    * For internal use only.
    */
   public void init(HashMap initValues)
   {
      super.init(initValues);
      Object val;
      
      if ((val = initValues.get(PNAME_Option)) != null)
      {
         mOption = convertToInt(val);
      }

      if ((val = initValues.get(PNAME_ReadOnly)) != null)
      {
         mReadOnly = convertToBoolean(val);
      }

      if ((val = initValues.get(PNAME_Value)) != null)
      {
         mExpression = (String)val;
      }

      if ((val = initValues.get(PNAME_Lazy)) != null)
      {
         mIsLazy = convertToBoolean(val);
      }
  }

}

