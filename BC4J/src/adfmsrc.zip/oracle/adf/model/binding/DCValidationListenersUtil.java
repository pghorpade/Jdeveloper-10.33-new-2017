/*
 * @(#)ValidationBeanLoader.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.ArrayList;
import java.beans.BeanInfo;
import java.beans.Introspector;
import oracle.jbo.AttrSetValException;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowValException;
import oracle.jbo.ValidationException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.mom.PropertyNameValueDef;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * @since JDevloper 3.0
 */
//class used in generated code to load validation beans in domains.
public class DCValidationListenersUtil
{
   static ArrayList loadValidationListenersFromXML(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList children = xmlElement.getChildrenList(JTXMLTags.VALIDATION_BEAN);

      // Load All attributes from XML
      String attrName;
      ArrayList al = new ArrayList(children.size());

      //let the for loop be here for future support of multiple validators
      //on a domain.
      for ( int i = 0; i < children.size(); i++ )
      {
         DefElement elem = (DefElement)children.get(i);
         al.add(createNewValidatorInstance(elem));
      }
      return al;
   }
   
   
   static private DCBindingContainerValidationListener createNewValidatorInstance(DefElement xmlElement) 
   {
      try
      {
         String valClassStr  = xmlElement.readString("BeanClass");//NONLS
         if (valClassStr == null)
         {
             valClassStr = xmlElement.readString("ValidationBeanClass");//NONLS
             //this will handle the case where a custom rule defined prior
             //to 10.1.3 release is edited in 10.1.3. The BeanClass
             //attribute has been renamed to ValidationBeanClass in 10.1.3
         }
         Class valClass = JBOClass.forName(valClassStr);
         DCBindingContainerValidationListener val = (DCBindingContainerValidationListener)valClass.newInstance();
         BeanInfo beanInfo = Introspector.getBeanInfo(valClass);

         //if DefPersitable load via interface.
         com.sun.java.util.collections.ArrayList v= xmlElement.getChildrenList(JTXMLTags.NAMED_DATA);
         if ( (v != null) )
         {
            PropertyNameValueDef  jnd = new PropertyNameValueDef();
            for ( int i=0; i < v.size(); i++ )
            {
               //create * load named data.
               jnd.loadFromXMLFile((DefElement)v.get(i));

               //use nameddata to set loaded property into bean
               jnd.setBeanProperty(beanInfo, val);
            }
         }
         return val;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }


   public static void raiseException(Class resBundleClass,
                         String errorCode,
                         Object source,
                         String attrName,
                         Object newVal,
                         String methodName,
                         Exception detail)
   {
      int objType = -1;
      String objName = null;
      ValidationException valEx;

      objType = AttrSetValException.TYP_VIEW_OBJECT;
      objName = ((DCBindingContainer) source).getName();

      if (newVal instanceof Row)
      {
         valEx = new RowValException(resBundleClass,
                                     errorCode, objName,
                                     ((Row) newVal).getKey(),
                                     null,
                                     methodName);
      }
      else
      {
         AttrSetValException jboEx = new AttrSetValException(objType,
                                          resBundleClass,
                                          errorCode,
                                          objName,
                                          attrName,
                                          newVal,
                                          methodName);
         if (source instanceof Row) 
         {
            jboEx.setRowKey(objType, ((Row) source).getKey());
         }
         valEx = jboEx;
      }

      if (oracle.jbo.common.JboResourceBundle.class.isAssignableFrom(resBundleClass)) 
      {
         valEx.setAppendCodes(false);
      }

      if (detail != null)
      {
         valEx.addToDetails(detail);
      }

      throw valEx;
   }
}
