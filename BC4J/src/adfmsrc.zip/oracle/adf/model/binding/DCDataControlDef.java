/*
 * @(#)DCDataControlDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.common.JboNameUtil;

public class DCDataControlDef extends DCDefBase implements Map
{
   private static final String OLD_DCX_CONTAINER = "DataControls";
   public static final String STR_TRUE = "true";

   protected DefPersistable mOuter = null;

   // JRS The internal map must be synchronized b/c we may have threads
   // at RT mutating the map after creation
   // (see DCDataControlReference.createSession).  This may be relaxed
   // if we can declare the def as immutable.
   //private Map mInternalMap = Collections.synchronizedMap(new HashMap(10));

   //use simple HashMap and synchronize the put operations.
   private Map mInternalMap = new HashMap(10);

   // JRS Is this used?  Maintaining for DT.
   protected Object     mDacObj;


   protected DCParameterSetDef mParameters;
   
   // made this public since I need to create a new one during design time. JO
   public DCDataControlDef()
   {
   }

   public DCDataControlDef(String name)
   {
      super(name);
   }

   protected DCDataControlDef(DefPersistable outer)
   {
      mOuter = outer;
   } 

   public void init(HashMap initValues)
   {
      super.init(initValues);
      putAll(initValues);

      // Ensure that the name is mapped into the internal map
      // so that it may be accessed from there as well.
      String name = getName();
      if (name != null)
      {
         put(JUTags.NAME, name);
      }
   }

   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLString(xmlElement, JUTags.SYNC_MODE, valueTab);
      readXMLString(xmlElement, JUTags.VAL_MODE_STR, valueTab);
      readXMLString(xmlElement, JUTags.SupportsTransactions, valueTab);
      readXMLString(xmlElement, JUTags.SupportsFindMode, valueTab);
      readXMLString(xmlElement, JUTags.SupportsSortCollection, valueTab);
      readXMLString(xmlElement, JUTags.ProjectConfigurer, valueTab);
      readXMLString(xmlElement, JUTags.Package, valueTab);
      readXMLString(xmlElement, JUTags.DefinitionClass, valueTab);
      readXMLString(xmlElement, JUTags.BeanClass, valueTab);
      readXMLString(xmlElement, JUTags.Configuration, valueTab);
      readXMLString(xmlElement, JUTags.FactoryClass, valueTab);
      //readXMLString(xmlElement, JUTags.DesignTimeClass, valueTab);
   }

   
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);

      //load parameters
      com.sun.java.util.collections.ArrayList values = null;
      DefElement contentsElement =
         xmlElement.findChildElement(JUTags.Contents);
      
      if(contentsElement == null)
      {
         values = xmlElement.getChildrenList(JUTags.Parameters);
      }
      else
      {
         values = contentsElement.getChildrenList(JUTags.Parameters);
      }
      
      //we only support one parameter child
      mParameters = new DCParameterSetDef();
      if(values != null && values.size() > 0)
      {
         DefElement paramsElement = (DefElement)values.get(0);
         
         mParameters.loadFromXML(paramsElement);
      }

      // JRS This looks weird.  Here is the motivation:
      // DataControlFactory.createSession used to resolve
      // the DCDataControlDef into a parameter map.  This logic
      // has now been unified into the def which is a parameter map.
      // 
      // The resolution logic does have to account for the custom
      // parameters that are loaded here.  The createSession logic
      // used to get the parameterValues from the def and then apply
      // the "defined" def attributes to that map.  This logic
      // performs the exact same.  Basically, we are saying that the
      // "defined" def attributes take precedence over the custom
      // parameters.
      //
      // JRS 09/20/04 bug 3860022 Must clone the parameters values map.  The
      // map cached and mutating the mInternalMap will result
      // in a mutation of the parameters map.
      Map oldContextMap = mInternalMap;
      //mInternalMap = Collections.synchronizedMap((Map)mParameters.getValues().clone());
      mInternalMap = (Map)mParameters.getValues().clone();
      mInternalMap.putAll(oldContextMap);
   }

// From JUDataControlDefImpl


   public boolean supportsTransactions()
   {
      return  STR_TRUE.equals(get(JUTags.SupportsTransactions));  
   }
   
   public boolean supportsFindMode()
   {
      return STR_TRUE.equals(get(JUTags.SupportsFindMode));   
   }
   
   public HashMap getParameters()
   {
      if(mParameters == null)
         mParameters = new DCParameterSetDef();
      return mParameters.getValues();
   }
   
   public void setDacObj(Object obj)
   {
      mDacObj = obj;
   }

   public Object getDacObj()
   {
      return mDacObj;
   }

   public String getDTClassName()
   {
      return (String)get(JUTags.DesignTimeClass);
   }
   
   public void setPackageName(String name)
   {
      put(JUTags.Package, name);
   }

   public String getPackageName()
   {
      return (String)get(JUTags.Package);
   }


   public void setConfiguration(String name)
   {
      put(JUTags.Configuration, name);
   }
   
   public String getConfiguration()
   {
      return (String)get(JUTags.Configuration);
   }

   public boolean isBeanSession()
   {
      return (getFactoryClass() != null);
   }

   public void setFactoryClass(String name)
   {
      put(JUTags.FactoryClass, name);
   }

   public String getFactoryClass()
   {
      return (String)get(JUTags.FactoryClass);
   }

   public void setBeanClass(String name)
   {
      put(JUTags.BeanClass, name);
   }
   
   public String getBeanClass()
   {
      String beanClass = (String)get(JUTags.BeanClass);
      if (beanClass == null)
      {
         //this set is synchronized in put().
         setBeanClass((beanClass = getDefinitionClass()));
      }
      return beanClass;
   }

   public void setDefinitionClass(String name)
   {
      put(JUTags.DefinitionClass, name);
   }
   
   public String getDefinitionClass()
   {
      return (String)get(JUTags.DefinitionClass); 
   }
   
   public String getProjectConfigurer()
   {
      return (String)get(JUTags.ProjectConfigurer);
   }

   public void setProjectConfigurer(String projectConfigurer)
   {
      put(JUTags.ProjectConfigurer, projectConfigurer);
   }

   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      return JUTags.DataControl;
   }

   static private String getNameSpace(DefElement xmlElement)
   {
       String nameSpace = xmlElement.getNamespaceURI();
       if(nameSpace == null || nameSpace.equals(""))
         nameSpace = "http://xmlns.oracle.com/adfm/datacontrol";
       return nameSpace;
   }
   
   static DefinitionFactory getDefinitionFactory(DefElement xmlElement)
   {
      return JUMetaObjectManager.getJUMom().getDefinitionFactory(getNameSpace(xmlElement));
   }

   static public DCDefBase createAndLoadFromXML(DefElement xmlElement, String appName)
   {
      return invokeFactory(xmlElement);
   }

   private static DCDefBase invokeFactory(DefElement xmlElement)
   {
      DefinitionFactory factory = getDefinitionFactory(xmlElement);
      return factory.createDefinition(xmlElement);
   }

   static DCDataControlDef createDef(DefElement xmlElement)
   {
      return (DCDataControlDef)invokeFactory(xmlElement);
   }
   
   // Everything below is unused.
   public HashMap getDCProperties()
   {
      // JRS Let's get rid of this.  The "properties" are now properly typed.
      return null;
   }

   public int size()
   {
      return mInternalMap.size();
   }

   public boolean isEmpty()
   {
      return mInternalMap.isEmpty();
   }

   public boolean containsKey(Object key)
   {
      return mInternalMap.containsKey(key);
   }

   public boolean containsValue(Object value)
   {
      return mInternalMap.containsValue(value);
   }

   public Object get(Object key)
   {
      return mInternalMap.get(key);
   }

   public Object put(Object key, Object value)
   {
      synchronized (mInternalMap)
      {
         return mInternalMap.put(key, value);
      }
   }

   public Object remove(Object key)
   {
      synchronized (mInternalMap)
      {
         return mInternalMap.remove(key);
      }
   }

   public void putAll(Map t)
   {
      synchronized (mInternalMap)
      {
         mInternalMap.putAll(t);
      }
   }

   public void clear()
   {
      synchronized (mInternalMap)
      {
         mInternalMap.clear();
      }
   }

   public Set keySet()
   {
      return mInternalMap.keySet();
   }

   public Collection values()
   {
      return mInternalMap.values();
   }

   public Set entrySet()
   {
      return mInternalMap.entrySet();
   }

   static public DCDataControlDef findDefObject(String objectName)
   {

      // Can't have this until DataControl definitions are first class def objects. 
      // In their current incarnation they are defined inside .dcx file. 
      // -dm 5/27/05
      //return (DCDataControlDef)JUMetaObjectManager.getJUMom().findDefinitionObject(defName, 
      //                                                    JUMetaObjectBase.TYP_DEF_DATACONTROL,
      //                                                    DCDataControlDef.class,
      //                                                    true, /* sub */ 
      //                                                    true /* loadIfNecessary*/);




      String containerName = JboNameUtil.getContainerPartOfName(objectName);
      String dcDefName = JboNameUtil.getLastPartOfName(objectName);
      
      
      DCDataControlConfigDef container = null;
      try
      {
         if(containerName != null)
         {
            String contObjectName = JboNameUtil.getLastPartOfName(containerName);
            container = DCDataControlConfigDef.findDefObject(containerName + 
                                                    "." + 
                                                    contObjectName + 
                                                    JboNameUtil.DCX_EXTENSION);

         }

      }
      catch(oracle.jbo.NoDefException ex)
      {
         // Backward compatibility. -dm 6/15/2005
         container = DCDataControlConfigDef.findDefObject(containerName + 
                                                 "." + 
                                                 OLD_DCX_CONTAINER + 
                                                 JboNameUtil.DCX_EXTENSION);
      }

      // More backward compatibility stuff 
      // Old dcx files may not be in a package.
      // Aargh - dm 8/18/05
      if(containerName == null && container == null)
      {
         container = DCDataControlConfigDef.findDefObject(OLD_DCX_CONTAINER + 
                                                          JboNameUtil.DCX_EXTENSION);
      }
      return container.findDataControlDef(dcDefName);

   }

}
