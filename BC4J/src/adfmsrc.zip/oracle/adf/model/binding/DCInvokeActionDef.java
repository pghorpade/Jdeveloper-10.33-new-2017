/*
 * @(#)DCInvokeActionDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.HashMap;
//import java.util.Map;

import oracle.adf.model.OperationBinding;
import oracle.adf.model.BindingContext;
//import oracle.adf.model.meta.OperationDefinition;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;

import com.sun.java.util.collections.ArrayList;

import java.security.Permission;

public class DCInvokeActionDef extends DCExecutableBindingDef
{
   public static final String PNAME_InvokeAction = JUTags.PNAME_invokeAction;
   private String mBindsName;
   
   public DCInvokeActionDef()
   {
      setSubType(PNAME_InvokeAction);
   }

   public DCInvokeActionDef(String name)
   {
      super(name);
      setSubType(PNAME_InvokeAction);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      if ((val = initValues.get(JUTags.PNAME_Binds)) != null)
      {
         mBindsName = val.toString();
      }
   }

   final String getBindsName()
   {
      return mBindsName;
   }

   public String getXMLElementTag()
   {
      return PNAME_InvokeAction;
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      readXMLString(xmlElement, JUTags.PNAME_Binds, valueTab);
   }

   public int getExecutableType()
   {
      return EXECUTABLE_ACTION;
   }

   public Object createExecutableBinding(BindingContext ctx, DCBindingContainer ctr)
   {
      DCInvokeAction ref = new DCInvokeAction(this, ctr, getRefreshOption(), getRefreshExpression());
      ref.setName(getName());
      ref.setExecutableDef(this);
      return ref;
   }

   protected boolean internalHasPermission(DCBindingContainer ctr)
   {
      if (!PermissionHelper.isAuthorizationEnabled())
      {
         return true;
      }

      DCDataControl dc = ctr.getDataControl();
      DCControlBinding binding = ctr.findCtrlBinding(getBindsName());
      if (binding instanceof oracle.jbo.uicli.binding.JUCtrlActionBinding)
      {
         Object methodInfo = ((oracle.jbo.uicli.binding.JUCtrlActionBinding) binding).getOperationInfo();
         if (methodInfo instanceof DCInvokeMethod) 
         {
            String permClassName = PermissionHelper.getPermissionClassName(PermissionHelper.METHOD_PERMISSION);
            if (permClassName == null)
            {
               return true;
            }
            
            String targetName = ((DCInvokeMethod)methodInfo).getPermissionTargetName();
            Permission p = (Permission)PermissionHelper.createPermissionInstance(permClassName, targetName, PermissionHelper.INVOKE_ACTION);
           
            if (dc != null && !dc.hasPermission(p))
            {
               return false;
            }
         }
      }
      return true;
   }

   class DCInvokeAction extends DCExecutableBinding 
   {
      DCInvokeActionDef mDef;
      boolean mMethodType;
      OperationBinding mAction;
      DCBindingContainer mContainer;
      boolean mInternalGet_KeyResolved;
      //private boolean mNotExecuteAction = true;

      DCInvokeAction(DCInvokeActionDef def, DCBindingContainer container,
                               int refreshOption, String refreshExpression)
      {
         mDef = def;
         mContainer = container;
         setRefreshOption(refreshOption);
         setRefreshExpression(refreshExpression);
      }

      public void refresh(int refreshFlag)
      {
         setRefreshed(true);
         
         OperationBinding oper = getActionBinding();
         //if (refreshFlag != DCBindingContainer.EXECUTE_MODEL || mNotExecuteAction) 
         {
            oper.invoke();
         }
      }

      public int getExecutableType()
      {
         return mDef.getExecutableType();
      }

      public boolean hasRefreshParametersChanged()
      {
         getActionBinding();
         if (mMethodType)
         {
            DCDataControl dc = ((oracle.jbo.uicli.binding.JUCtrlActionBinding)mAction).getDataControl();
            return (dc != null) 
                       ? dc.hasOperationParamsChanged(mAction.getOperationInfo()) 
                       : ((DCInvokeMethod)mAction.getOperationInfo()).hasParameterValuesChanged();
         }
         return true;
      }

      public DCIExecutableDef getExecutableDef()
      {
         return mDef;
      }

      public final OperationBinding getActionBinding()
      {
         if (mAction == null)
         {
            mAction = (OperationBinding)mContainer.findCtrlBinding(mDef.getBindsName());
            Object methodInfo = mAction.getOperationInfo();
            if (methodInfo instanceof DCInvokeMethod) 
            {
               mMethodType = true;
               ((DCInvokeMethod)methodInfo).setCacheResolvedValues(true);
            }
            /*
            else if (((Integer)((Map)mAction).get("actionId")).intValue() 
                      == OperationDefinition.ACTION_EXECUTE)
            {
               mNotExecuteAction = false;
            }
            */
         }
         return mAction;
      }

      public final Object getResult()
      {
         return getActionBinding().getResult();
      }

      public DCInvokeActionDef getDef()
      {
         return mDef;
      }

      public int hashCode()
      {
         return mName.hashCode() + getActionBinding().hashCode();
      }

      static final String GET_action = "action";   //NONLS
      static final String GET_result = "result";   //NONLS
      protected Object internalGet(String key)
      {
         key = key.intern();
         Object ret = null;
         if (key == GET_action)
         {
            mInternalGet_KeyResolved = true;
            return getActionBinding();
         }
         if (key == GET_result)
         {
            mInternalGet_KeyResolved = true;
            return getResult();
         }

         return super.internalGet(key);
      }

   }
}


