/*
 * @(#)DCDataControl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Properties;
import oracle.jbo.LocaleContext;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttrValException;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.NameClashException;
import oracle.jbo.Transaction;
import oracle.jbo.Key;
import oracle.jbo.JboEvent;
import oracle.jbo.JboException;
import oracle.jbo.JboExceptionHandler;
import oracle.jbo.JboWarning;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.StructureDef;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.common.NamedObjectImpl;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.SessionContextManagerImpl;
import oracle.jbo.uicli.mom.JUApplicationDefImpl;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.TransactionStateEvent;
import oracle.jbo.SessionContextManager;
import oracle.jbo.SessionContext;
import oracle.jbo.SortCriteria;
import oracle.jbo.ViewCriteria;

import oracle.adf.model.generic.StructureDefImpl;
import oracle.adf.model.generic.DCRowSetIteratorImpl;
import oracle.adf.model.generic.DCGenericRowSetIteratorImpl;
import oracle.adf.model.generic.DCRowContext;

import oracle.adf.model.DataControl;
import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;
import java.security.Permission;
import java.security.Principal;

import oracle.binding.meta.Definition;

/**
 * The application class that manages connection to a 
 * Data Provider object. The DCDataControl class provides:<p>
 * <ul>
 * <li>Methods to connect to a Data Provider Object, if this 
 * is the root DCDataControl object. 
 * <li>Handles exceptions raised by the framework and passes it on
 * to registered Error handler. 
 * <li>Manages control-binding containers that contain iterator-bindings that 
 * bind iterators of the RowIterators in the Data-provider object.
 * <li>If this DCDataControl is the root, manages TransactionStateListeners
 * so that the Transaction's state events are passed on to the listeners.
 * <li>Routes all status bar messages to all status bars registered with 
 * this application. Framework uses this class to route all status bar messages.
 * </ul>
 * @version  PUBLIC
 * @see oracle.jbo.ApplicationModule
 * @see oracle.jbo.Transaction
 * @see DCTransactionStateListener
 * @see DCErrorHandler
 *
 *
 * @javabean.class name=DCDataControl
 * 
 *
 * 
 */
abstract public class DCDataControl extends JboAbstractMap  implements DataControl, DCDataControlManagement
{
   private DCDataControlDef     mDCDef;
   protected boolean mIsRoot;
   protected DCDataControl mParent;
   protected DCDataControl mRootApplication;
   protected Object mUserData;
   protected String mName;

   protected ArrayList mBindingContainerList = new ArrayList(4);

   protected DCErrorHandler mErrorHandler;
   protected DCErrorHandler mErrorHandlerThrow;
   protected boolean mErrorHandlerActive = true;

   protected LocaleContext mLocaleCtx;
   static public byte ABSTRACT = BindingContext.CLIENT_TYPE_ABSTRACT;
   static public byte JCLIENT  = BindingContext.CLIENT_TYPE_JCLIENT;

   static public final byte OPER_DATA_ROW_UPDATE         = 0;
   static public final byte OPER_DATA_ROW_CREATE         = 1;  
   static public final byte OPER_DATA_ROW_REMOVE         = 2;
   static public final byte OPER_FIND_MODE               = 3;
   static public final byte OPER_CTRL_BINDING_VALIDATION = 4;
   static public final byte OPER_EXECUTE                 = 5;
   static public final byte OPER_SORT_COLLECTION         = 6;

   
   boolean mTxnModified = false;
   private BindingContext mBindingContext = null;
   private boolean mResetStateDeferred = false;
   private int     mUseCount = 0;
   protected Object mDataProvider;
   private Map mTransientDataMap;

   private Map mUserParams = null;
   private HashMap mReleasedIterators = null;


   static public final String GET_MethodResults  = "MethodResults";         //NONLS
   static public final String GET_ApplicationModule  = "ApplicationModule"; //NONLS
   static public final String GET_DataProvider  = "DataProvider";           //NONLS
   static public final String GET_dataProvider  = "dataProvider";           //NONLS
   static public final String GET_Name = "Name";                            //NONLS

   class MethodResultsMap extends HashMap
   {
      Map mUseCountMap = new HashMap(10);

      MethodResultsMap(int size)
      {
        super(size);
      }
      //when setting a value, 
      public Object put(Object key, Object value)
      {
         Object obj = super.get(key);
         if (obj != null)
         {
            if (obj != value)
            {
               Integer useCount = (Integer)mUseCountMap.get(key);
               useCount = (useCount != null) ? new Integer(useCount.intValue()+1) : new Integer(1);
               mUseCountMap.put(key, useCount);
            }
         }
         return super.put(key, value);
      }

      int getUseCount(Object key)
      {
         Integer useCount = (Integer)mUseCountMap.get(key);
         return (useCount != null) ? useCount.intValue() : 0;
      }

      public void putAll(Map m)
      {
         throw new  UnsupportedOperationException("DCDataControl.MethodResultsMap.putAll()"); //NO NLS
      }

      public Object remove(Object key)
      {
         mUseCountMap.remove(key);
         return super.remove(key);
      }

      public void clear()
      {
         mUseCountMap.clear();
         super.clear();
      }

      public Object clone()
      {
         throw new  UnsupportedOperationException("DCDataControl.MethodResultsMap.clone()"); //NO NLS
      }
   }

   MethodResultsMap mMethodResults;

   
   public static int REL_ALL_REFS     = -1;
   public static int REL_DATA_REFS    = 0x1;
   public static int REL_VIEW_REFS    = 0x2;

   // JRS 3/8/2004  This is a weak data release.  This may be specified by
   // a DataControl to release data refs that do not rely upon any session state
   // like iterator currency.  These references are typical cache references and
   // may be rebuilt at any time using the DataControl.  For example, BC4J uses
   // this release flag to release JUCtrlListBinding references to BC4J rows.
   // These rows are cached for performance but also may be re-fetched from the
   // DataControl at any time.
   // 
   // REL_DATA_REFS should take precendence over this release mode.
   // NB:  Theoretically, all release listeners should be able to rebuild
   // their data refs.  However, firing this event at the end of every request
   // was deemed to large a change late in the 9.0.5.1 cycle.
   public static int REL_WEAK_DATA_REFS = 0x4;

   private HashMap mBindingsWithExc = null;


   public static final String PNAME_Type = "Session"; // backward compatible  //NONLS
   
   /**
   * DCStatusBarInterface objects that are notified with status bar messages.
   **/
   protected ArrayList mStatusBarList;

   /**
   * DCTransactionStateListener objects that are notified of commit or rollback events
   * when generated from the data-provider layer.
   */
   protected ArrayList mTxnListeners;

   // only added for design time.
   protected DCDataControl()
   {
      this(false, null);
   }

   /**
   * Constructs a root DCDataControl object that connects to a Data Provider
   * of the given name.
   * @param root If this DCDataControl is a root DCDataControl managing the transaction.
   * @param userData Data to store with the DCDataControl object.
   */
   protected DCDataControl(boolean root, Object userData)
   {
      super();
      mIsRoot = root;
      mParent = null;
      mRootApplication = (root) ? this : null;

      mErrorHandlerThrow = new DCErrorHandlerThrow();
      
      //donot set this as same. if the base one is not set, we'd go 
      //to JUMetaObjectManager to raise exception.
      //mErrorHandler = mErrorHandlerThrow;
      mUserData = userData;
   }
   
   
   /**
   * Returns the instance name of this DCDataControl object.
   * @internal *** For internal framework use only ***
   *
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * Sets the instance name of this DCDataControl Object
   * @internal *** For internal framework use only *** 
   */
   public final void setName(String name)
   {
      mName = name;
   }

   
   /**
   * Returns the definition object for this DCDataControl
   * @internal *** For internal framework use only *** 
   */
   public final DCDataControlDef getDef()
   {
      return mDCDef;
   }

   
   /**
   * Sets the definition object of the ApplicationObject for older apps
   * @internal *** For internal framework use only *** 
   */
   //public final void setAppDef(JUApplicationDefImpl appDef)
   //{
   //   mAppDef = appDef;
   //}

   /**
   * Returns the definition object for this DCDataControl
   * @internal *** For internal framework use only *** 
   */
   //public final JUApplicationDefImpl getAppDef()
   //{
   //   return mAppDef;
   //}

   
   /**
   * Sets the definition object of this DCDataControl Object
   * @internal *** For internal framework use only *** 
   */
   public final void setDef(DCDataControlDef appDef)
   {
      mDCDef = appDef;
   }

   public void initializeFromMetadata(Map map)
   {
      //do nothing.
   }
   
   /**
   * *** Advanced method ***
   * <p>
   * Creates a connection to the data-provider layer.
   */
   public void initialize()
   {
      if (mIsRoot)
      {
         connect();
      }
   }

   /**
    ** @javabean.property
    **/
   public Object getDataProvider()
   {
      return mDataProvider;
   }

   protected void setDataProvider(Object obj)
   {
      mDataProvider = obj;
   }

   
   /**
   * This method is used by all framework binding objects to report
   * exceptions. If this DCDataControl is not the root, it calls the
   * equivalent method on the root.
   * <p>
   * If the error handler is set to active state, then this method
   * calls the registered error handler's reportException method.
   * Othewise, it simply throws the given exception as a JboException.
   * @see DCErrorHandler
   * @see oracle.jbo.JboException
   */
   public final void reportException(DCBindingContainer formBnd, Exception ex)
   {
      if (!mIsRoot)
      {
         getRootDataControl().reportException(formBnd, ex);
      }
      else
      {
         if (getApplicationModule() != null && (ex instanceof JboException))
         {
            JboException jex = (JboException)ex;
            if (jex.needsEntityToVOMapping())
            {
               jex.doEntityToVOMapping(getApplicationModule(), formBnd.getOrderedVOUsageList(this));
            }
         }

         if (mErrorHandlerActive)
         {
            if (mErrorHandler != null)
            {
               mErrorHandler.reportException(formBnd, ex);
            }
            else if (getBindingContext().getErrorHandler() != null)
            {
               getBindingContext().getErrorHandler().reportException(formBnd, ex);
            }
            else
            {
               JUMetaObjectManager.reportException(formBnd, ex);
            }  
         }
         else
         {
            mErrorHandlerThrow.reportException(formBnd, ex);
         }
      }
   }
   

   /**
   * Returns the DCErrorHandler registered with the root DCDataControl.
   * By default an ADF Application has an instance of DCErrorHandlerDialog
   * registered as the default DCErrorHandler. 
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   *
   *  @javabean.property
   */
   public final DCErrorHandler getCurrentErrorHandler()
   {
      return getRootDataControl().mErrorHandler;
   }

   
   /**
   * Registers a DCErrorHandler with the root DCDataControl.
   * By default an ADF application has an instance of DCErrorHandlerDialog
   * registered as the default DCErrorHandler. 
   * Applications should use this method to register custom error handling
   * object so that all errors raised in the framework goes through the Application's
   * error handling object. Custom error handlers need to implement the DCErrorHandler
   * interface.
   * <p>
   * Custom error handlers may also implement oracle.jbo.JboExceptionHandler
   * to handle batched Exceptions raised during client-side processing
   * of Exceptions thrown in the Business Components tier. 
   * after the DCErrorHandler is set with DCDataControl in this method.
   * <p>
   * Note that errors are sent to the registered error handler only when
   * the error handler state is marked active (which is true by default)
   * using the setErrorHandlerActive method.
   * @param errHandlerObj An implementation of DCErrorHandler interface
   * that may optionally implement JboExceptionHandler interface too.
   * If errHandler implements the JboExceptionHandler, this method sets
   * it as the ExceptionHandler on the root ApplicationModule that this
   * client Application is connected with. Else, method sets a default 
   * ExceptionHandler which will collect all Exceptions
   * and throw a new JboException with these Exceptions set as in the new 
   * JboException's details list, for the errHandler to display
   * as one JboException with a bag of Exceptions.
   *
   * @see oracle.jbo.uicli.binding.JUErrorHandler
   * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
   * @see oracle.jbo.JboExceptionHandler
   * @see oracle.jbo.ApplicationModule
   */
   public void setErrorHandler(Object errHandlerObj)
   {
      if (errHandlerObj instanceof DCErrorHandler)
      {
         DCErrorHandler errHandler = (DCErrorHandler)errHandlerObj;
         getRootDataControl().mErrorHandler = errHandler;
         ApplicationModule am = getRootDataControl().getApplicationModule();
         if (am != null) 
         {
            if (errHandler instanceof JboExceptionHandler) 
            {
               am.setExceptionHandler((JboExceptionHandler)errHandler);
            }
            else
            {
               am.setExceptionHandler(new JboExceptionHandler()
               {
                  ArrayList al = null;
                  public void handleException(Exception ex, boolean lastEntryInPiggyback)
                  {
                     if (al == null) 
                     {
                        al = new ArrayList(5);
                     }

                     al.add(ex);
                  }

                  public void handleWarning(JboWarning warn)
                  {
                     if (oracle.jbo.common.Diagnostic.isOn()) 
                     {
                        oracle.jbo.common.Diagnostic.println(warn.getMessage());
                     }
                  }

                  public void finishedProcessingPiggyback(Exception[] exArray)
                  {
                     if (al != null && al.size() > 0)
                     {
                        JboException ex = new JboException(UIMessageBundle.class,
                                                           UIMessageBundle.EXC_SYNC_ERROR,
                                                           null,
                                                           (Exception[])al.toArray(new Exception[al.size()]));
                        al = null;
                        throw ex;  //so that DCI can catch and call reportException.
                     }
                  }
               }
               );
            }
         }
      }
   }

   
   /**
   * Returns the error-handler active state of the root DCDataControl object.
   * This is used to control whether to throw an exception raised by the framework
   * (which is used by automated regression tests to trap exceptions and log them).
   * By default the state is set to true - meaning raise all exceptions via the 
   * registered error handler.
   *
   */
   public final boolean getErrorHandlerActive()
   {
      return getRootDataControl().mErrorHandlerActive;
   }

   
   
   /**
   * *** Advanced method ***
   * <p>
   * Sets the error-handler active state of the root DCDataControl object.
   * This is used to control whether to throw an exception raised by the framework
   * (which is used by automated regression tests to trap exceptions and log them).
   * By default the state is set to true - meaning raise all exceptions via the 
   * registered error handler.
   */
   public final void setErrorHandlerActive(boolean b)
   {
      getRootDataControl().mErrorHandlerActive = b;
   }

   
   /**
   * If this DCDataControl is root, this method invokes the corresponding BC4J Transaction's
   * connect() method to create a database connection. Also this method is used
   * to register the application as a TransactionStateListener on the BC4J Transaction object.
   */
   protected void connect()
   {
   }

   /**
   * Returns the locale for this Application
   *
   */
   public LocaleContext getLocaleContext()
   {
      if (mLocaleCtx == null)
      {
         //if none, get one from bindingContext.
         BindingContext ctx = getBindingContext();

         if (ctx != null)
         {
            mLocaleCtx = ctx.getLocaleContext();
         }
      }
      return mLocaleCtx;
   }
   
   /**
   * Helper method that sets the locale in the current Application.
   */
   public void setLocaleContext(LocaleContext locale)
   {
      mLocaleCtx = locale;
   }

   /**
    * For all nonbc4j Applications, this should return null.
    * Returns the associated oracle.jbo.ApplicationModule object
    *
   */
   public ApplicationModule getApplicationModule()
   {
      return null;
   }

   
   /**
    * Given the name of an RSI, find if it's already created and cached on the datacontrol
    */
   abstract protected RowSetIterator getRowSetIterator(String masterName);


   /**
    * 
    */
   abstract protected Object getAccessorValue(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName);

   /**
    * creates a accessor RSI using the current or the first row of the masterRSI and calling
    * the get&lt;accName&gt; method on it to get the RSI dataprovider.
    */
   public RowSetIterator createAccessorRowSetIterator(RowSetIterator masterRSI, 
                                                      DCIteratorBinding iter,
                                                      String accName, 
                                                      String beanClass)
   {
      Row row = masterRSI.getCurrentRow();
      if (row == null)
      {
         row = masterRSI.first();
      }
      return createAccessorRowSetIterator(masterRSI, row, iter, accName, beanClass, true);
   }

   public RowSetIterator createAccessorRowSetIterator(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName, String beanClass)
   {
      return createAccessorRowSetIterator(masterRSI, row, iter, accName, beanClass, false);
   }

   protected RowSetIterator createAccessorRowSetIterator(RowSetIterator masterRSI, Row row, DCIteratorBinding iter, String accName, String beanClass, boolean trackMaster)
   {
      Object result = (row != null) ? getAccessorValue(masterRSI, row, iter, accName): null;
      RowSetIterator rsi = null;
      if (result instanceof RowSetIterator)
      {
         rsi = (RowSetIterator)result;
      }
      else if(row instanceof oracle.adf.model.generic.RowImpl)
      {
         //generic row.
         if (beanClass == null)
         {
           beanClass = ((oracle.adf.model.generic.StructureDefImpl)
           ((oracle.adf.model.generic.RowImpl)row).getStructureDef()).getAccessorDef(accName).getBeanClassName();
         }
         else if (oracle.adf.model.generic.BeanUtils.skipMetaData(beanClass))
         {
            //no need for beanClass as scalar accessor is inlined and it's definition
            //is found from the master via accessor name.
            beanClass = null;
         }
         rsi = createRowSetIteratorImpl(iter, beanClass, result, masterRSI);
         if (rsi instanceof DCRowSetIteratorImpl)
         {
            DCRowSetIteratorImpl dcrsi = (DCRowSetIteratorImpl)rsi;
            dcrsi.setAccessorName(accName);
            if (dcrsi instanceof DCGenericRowSetIteratorImpl)
            {
               rsi = ((DCGenericRowSetIteratorImpl)dcrsi).setMasterInfo((DCGenericRowSetIteratorImpl)masterRSI, 
                                   (oracle.adf.model.generic.RowImpl)row, accName,
                                   trackMaster);
            }
            dcrsi.setName(accName);

         }
      }
      else if (result instanceof Row) 
      {
         //what do we do about bc4j rows.
         Object strDef = DCUtil.findSpelObject(result, "rowSet");
         if (strDef instanceof RowSetIterator)
         {
            rsi = (RowSetIterator)strDef;
         }
      }

      iter.bindRowSetIterator(rsi, false);
      return rsi;
   }
   
   public RowSetIterator findOrCreateMethodRowSetIterator(
      DCIteratorBinding iter
      , String beanClass
      , Object result)
   {
      // base implementation always creates a new one
      return createRowSetIteratorImpl(iter, beanClass, result, null);
   }

   /**
    * Use findOrCreateAccessorRowSetIterator(DCIteratorBinding masterIter....) instead.
    * @deprecated since 10.1.2 
    */
   public RowSetIterator findOrCreateAccessorRowSetIterator(RowSetIterator masterRSI, 
                                                      DCIteratorBinding iter,
                                                      String accName, 
                                                      String beanClass)
   {
      // base implementation always creates a new one
      return createAccessorRowSetIterator(masterRSI, iter, accName, beanClass);
   }

   protected Row internalGetCurrentRow(DCIteratorBinding iter)
   {
      // base implementation always creates a new one
      RowSetIterator masterRSI = iter.getRowSetIterator();
      Row row = null;
      try
      {
         //getCurrentRow in iteratorbinding would return ReservedRow (reserved for updates during prepareModel
         //we need the binding's cached new row or RSI's current row
         row = (iter.isFindMode()) ? masterRSI.getCurrentRow() : iter.internalGetCurrentRowInBinding();
      }
      catch (oracle.jbo.InvalidOperException ioe)
      {
         //ignore ioe as we may have to sync to get master row.
         if (iter.isAccessorIterator())
         {
            throw ioe;
         }
         //ignore.
      }
      return row;
   }

   public RowSetIterator findOrCreateAccessorRowSetIterator(DCIteratorBinding masterIter, 
                                                      DCIteratorBinding iter,
                                                      String accName, 
                                                      String beanClass)
   {
      Row row = internalGetCurrentRow(masterIter);
      RowSetIterator masterRSI = masterIter.getRowSetIterator();
      if (row == null)
      {
         return createAccessorRowSetIterator(masterRSI, iter, accName, beanClass);
      }
      return createAccessorRowSetIterator(masterRSI, row, iter, accName, beanClass, true);
   }



   /**
    * Create a DCRowSetIteratorImpl or a subclass thereof for the give
    * defName element types, using the given source collection/object and
    * optionally the master RSI if there is a dependency defined on the master.
   */
   abstract protected RowSetIterator createRowSetIteratorImpl(
                                                           String defName, 
                                                           Object sourceObj, 
                                                           RowSetIterator master);

   protected RowSetIterator findOrCreateRowSetIteratorImpl(DCIteratorBinding iter,
                                                  String defName, 
                                                  Object sourceObj, 
                                                  RowSetIterator master)
   {
      return createRowSetIteratorImpl(defName, sourceObj, master);
   }

   /**
    * Creates an RSI for a given iterator and source collection/object.
    */
   public final RowSetIterator createRowSetIteratorImpl(DCIteratorBinding iter,
                                                  String defName, 
                                                  Object sourceObj, 
                                                  RowSetIterator master)
   {
      if (iter != null) 
      {
         RowSetIterator  rsi = findOrCreateRowSetIteratorImpl(iter, defName, sourceObj, master);
         DCIteratorBindingDef iterDef = (DCIteratorBindingDef)iter.getDef();
         if (iterDef != null 
             && DCDefBase.PNAME_MethodIterator.equals(iterDef.getSubType())
             && rsi instanceof DCRowSetIteratorImpl)
         {
            DCRowSetIteratorImpl rsiImpl = (DCRowSetIteratorImpl)rsi;
            rsiImpl.setProviderMethodResultName(JboNameUtil.getLastPartOfName(iter.getSourceName()));
         }
         return rsi;
      }
      return createRowSetIteratorImpl(defName, sourceObj, master);
   }

   
   /**
   * Returns true if this DCDataControl is the root DCDataControl. Root DCDataControl
   * is responsible for establishing connection to a DataProvider and setting up Transaction
   * objects.
   */
   public final boolean isRoot()
   {
      return mIsRoot;
   }

   
   /**
   * Returns the container DCDataControl object if any. This should be null in case this
   * application object is the root.
   *
   */
   public final DCDataControl getParent()
   {
      return mParent;
   }

   
   /**
   * Returns the root DCDataControl object.
   *
   */
   public final DCDataControl getRootDataControl()
   {
      if (mRootApplication == null) 
      {
         if (getParent() == null) 
         {
            mIsRoot = true;
            mRootApplication = this;
         }
         else
         {
            mRootApplication = getParent().getRootDataControl();
         }
      }
      return mRootApplication;
   }

   
   /**
   * @internal *** For internal framework use only *** 
   */
   public final Object getUserData()
   {
      return mUserData;
   }

   
   /**
   * Remove the DCBindingContainer object of the given name (if any).
   */
   //noneed.
   protected final void removeBindingContainer(DCBindingContainer formBnd)
   {
      //String name = formBnd.getName();
      //Object obj = mBindingContainers.get(name);
      //if (obj != null) 
      {
         //mBindingContainers.remove(name);
         mBindingContainerList.remove(formBnd);
      }

      //how about removing from the binding context?
   }

   /**
   * Register the given form binding object with this application. If this
   * form binding object has no name or null name, framework generates a unique
   * name for the object (in the context of this application module).
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   */
   public final void addBindingContainer(DCBindingContainer formBnd)
   {
      addBindingContainer(formBnd.getName(), formBnd);
   }
   
   /**
   * Register the given form binding object with this application. If this
   * form binding object has no name or null name, framework generates a unique
   * name for the object (in the context of this application module).
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   */
   public final void addBindingContainerRef(NamedObjectImpl formBnd)
   {
      BindingContext ctx = getBindingContext();
      if (ctx.get(formBnd.getName()) != null) 
      {
         // should this replace the existing object?
         Object exists = ctx.get(formBnd.getName());
         if (exists instanceof DCBindingContainer) 
         {
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Replacing Binding Container :"+((DCBindingContainer)exists).getName() + "with a reference."); //NONLS
            }
         }
         else if (exists instanceof NamedObjectImpl) 
         {
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Replacing Binding Container Reference :"+((NamedObjectImpl)exists).getName() + "with another.");//NONLS
            }
         }
         ctx.remove(exists);
      }
      ctx.put(formBnd.getName(), formBnd);

      //do not add references into the local namespace. Only de-referenced ones
      //should belong in these lists.
      //mBindingContainerList.add(formBnd);
      //mBindingContainers.put(formBnd.getName(), formBnd);
   }
   
   
   /**
   * Register the given form binding object with this application with the given name.
   * @throws oracle.jbo.InvalidObjNameException If the given name does not follow the BC4J component or Java Identifier
   * naming rules.
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   * @see oracle.jbo.common.JboNameUtil#isNameValid(String)
   */
   public final void addBindingContainer(String name, DCBindingContainer formBnd, DCBindingContainerDef formDef)
   {
      addOrCreateBindingContainer(name, formBnd, formDef, false, false);
   }

   /**
   * Register the given form binding object with this application with the given name.
   * @throws oracle.jbo.InvalidObjNameException If the given name does not follow the BC4J component or Java Identifier
   * naming rules.
   * @throws oracle.jbo.NameClashException If there is another object of the same name already registered, this 
   * method will throw this exception.
   * @see oracle.jbo.common.JboNameUtil#isNameValid(String)
   */
   public final void addBindingContainer(String name, DCBindingContainer formBnd)
   {
      addOrCreateBindingContainer(name, formBnd, formBnd.getDef(), false, false);
   }
   
   //this is where subclasses for generic beans would override to return their DCIteratorBindings.
   protected void initializeBindingContainer(DCBindingContainerDef formDef, DCBindingContainer formBnd, boolean initialize)
   {
      //better still do an assert here.
      if (getApplicationModule() != null)
      {
        if (initialize)
        {
          formBnd.initializeFromDef(getBindingContext(), getApplicationModule());     
        }
        else
        {
          formDef.createIterBindings(formBnd, getBindingContext(), getApplicationModule());
        }
      }
      else
      {
        oracle.jbo.common.Diagnostic.println("Generic Application - needs to override"); //NONLS
      }
   }

   protected DCBindingContainer addOrCreateBindingContainer(String name, DCBindingContainer formBnd,
                                        DCBindingContainerDef formDef, boolean initialize, boolean replace)
   {
      Object exists = null;
      if (formBnd != null && formBnd.getRegionContainer() != null) 
      {
         if (mBindingContainerList.contains(formBnd)) 
         {
            exists = formBnd;
         }
      }
      else
      {
         BindingContext ctx = getBindingContext();
         boolean genFormName = (name == null);

         while (true)
         {
            if (genFormName)
            {
               name = DCUtil.generateContainerName(formBnd);
            }
            else  if (!JboNameUtil.isNameValid(name))
            {
               throw new InvalidObjNameException(JUMetaObjectBase.TYP_FORM_BINDING,
                                                 name);
            }

            if (!replace)
            {
               exists = ctx.get(name);
               if (exists == formBnd)
               {
                  break;
               }
               if (exists != null)
               {
                  if (!genFormName)
                  {
                     throw new NameClashException(JUMetaObjectBase.TYP_FORM_BINDING,
                                                  name);
                  }
                  //try another name.
                  genFormName = true;
                  continue;
               }
            }
            break;
         }

         if (formBnd == null)
         {
            formBnd = formDef.createBindingContainer(this, initialize);
            formBnd.setName(name);
            formBnd.setDataControl(this);
            formBnd.setDef(formDef);
            initializeBindingContainer(formDef, formBnd, initialize);
         }
         else
         {
            formBnd.setName(name);
            //since this datacontrol is leading to creation of binding container
            //use internal access to formBInding's dc to figure out if this DC
            //should be set into it.
            if (formBnd.internalGetDataControl() == null)
            {
               formBnd.setDataControl(this);
            }
            if (formBnd.getDef() != formDef)
            {
               formBnd.setDef(formDef);
            }
         }


         exists = ctx.get(formBnd.getName());
         if (exists != null && exists != formBnd) 
         {
            // should this replace the existing object?
            if (exists instanceof DCBindingContainer) 
            {
               if (Diagnostic.isOn()) 
               {
                  Diagnostic.println("Replacing Binding Container :"+((DCBindingContainer)exists).getName() + "with another."); //NONLS
               }
            }
            else if (exists instanceof NamedObjectImpl) 
            {
               if (Diagnostic.isOn()) 
               {
                  Diagnostic.println("Replacing Binding Container Reference :"+((NamedObjectImpl)exists).getName() + "with a reference."); //NONLS
               }
            }
            ctx.remove(exists);
         }
         ctx.put(formBnd.getName(), formBnd);

         //mark this 903 style bindingcontainer as refreshed
         //always.
         formBnd.setRefreshed(true);
      }

      int loc = -1;
      if(exists != null && (loc = mBindingContainerList.indexOf(exists)) > -1)
      {
         mBindingContainerList.set(loc, formBnd);
      }
      else
      {
         mBindingContainerList.add(formBnd);
      }

      return formBnd;
   }


   /**
   * Return the DCBindingContainer instance registered with this DCAppication with the given name.
   * If the name does not match, return null.
   */
   public final DCBindingContainer findBindingContainer(String name)
   {
      //Object obj = mBindingContainers.get(name);
      Object obj = getBindingContext().get(name);
      if(obj instanceof NamedObjectImpl) 
      {
         NamedObjectImpl namedObj = (NamedObjectImpl)obj;
         return addOrCreateBindingContainer(namedObj.getName(), null, 
                                            DCBindingContainerDef.findDefObject(namedObj.getFullName()), 
                                            true, true);
      }
      return (DCBindingContainer)obj;
   }


   /**
   * Create a DCBindingContainer instance using the given name and form definition.
   * @internal *** For internal framework use only *** 
   */
   public final DCBindingContainer createBindingContainer(String name, String formDefName, boolean initialize)
   {
      return addOrCreateBindingContainer(name, null, DCBindingContainerDef.findDefObject(formDefName), initialize, false);
   }
   /**
    **
   **/
   public boolean isJClientApp()
   {
     return (getBindingContext() != null) ? getBindingContext().isJClientApp() : false;
   }
   
   public void setClientApp(byte clientType)
   {
      if (getBindingContext() != null)
      {
         getBindingContext().setClientAppType(clientType);
      }
   }
   
   //need to create a factory semantics to create these bindings.
   public DCBindingContainer createBindingContainerInstance(String mBindingContainerClassName)
   {
     if (this.isJClientApp())
     {
        if (DCBindingContainer.class.getName().equals(mBindingContainerClassName))
        {
           return (DCBindingContainer) DCUtil.createNewInstance("oracle.jbo.uicli.jui.JUPanelBinding"); //NONLS
        }
     }
     return (DCBindingContainer) DCUtil.createNewInstance(mBindingContainerClassName);
   }

   
   /**
   * @internal *** For internal framework use only *** 
   */
   public void initializeContainerFromDef(String name)
   {
      DCBindingContainer form = findBindingContainer(name);
      if (form != null)
      {
         if (getApplicationModule() != null)
         {
            form.initializeFromDef(getBindingContext(), getApplicationModule());
         }
         else
         {
            initializeBindingContainer(form.getDef(), form, true);
         }
      }

   }

   /**
   * Add the given status bar object to this application's list.
   * Messages sent via displayMessage method will be given out to all 
   * registered status bar instances.
   */
   public final void addStatusBarInterface(DCStatusBarInterface statusBar)
   {
      if (mStatusBarList == null) 
      {
         mStatusBarList = new ArrayList(5);
      }
      mStatusBarList.add(statusBar);
   }

   /**
   * Remove the given instance of status bar interface if found.
   */
   public final void removeStatusBarInterface(DCStatusBarInterface statusBar)
   {
      if (mStatusBarList != null) 
      {
         mStatusBarList.remove(statusBar);
      }
   }

   /**
   * Send the given message Id and parameter list along with the current iterator binding object
   * to all status bar instances registered with this Application. This method is used by the
   * framework to display status bar messages from the oracle.jbo.uicli.UIMessageBundle
   */
   public final void displayStatus(DCIteratorBinding iterBinding, String msgId, Object[] params)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCStatusBarInterface)al.get(i)).displayStatus(iterBinding, msgId, params); 
         }
      }
   }

   /**
   * Send the given message to all status bar interface objects registered with this application.
   */
   public final void displayStatus(String msg)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCStatusBarInterface)al.get(i)).displayStatus(msg); 
         }
      }
   }


   /**
   * This method is used by the framework to display currency information in the status bars.
   * When a control bound to a given attribute for a given iterator binding gets focus, this
   * method is invoked to update all status bars.
   * @internal *** For internal framework use only *** 
   */
   public final void focusGained(DCIteratorBinding iterBinding, DCControlBinding binding, int attrIndex)
   {
      if (mStatusBarList != null) 
      {
         ArrayList al = mStatusBarList;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCStatusBarInterface)al.get(i)).focusGained(iterBinding, binding, attrIndex);
         }
      }
   }

   public final boolean hasBindingsWithExc()
   {
      return (mBindingsWithExc != null && mBindingsWithExc.size() > 0);
   }

   /**
    * Called when datacontrol changes needs to be validated after updates
    * have been processed for a page.
    */
   public void validate()
   {
      Diagnostic.println("Default validate Transaction is a no-op");
   }

   /**
   * Invokes the BC4J transaction's commit() method to save 
   * all changes to the database.
   */
   public void commitTransaction()
   {
      Diagnostic.println("Default Commit Transaction : resetting transaction state!");
      transactionStateChanged(false);
   }

   /**
   * Helper method that invokes beforeSaveTransaction event on all DCPanelBinding
   * objects and then invokes the BC4J transaction's commit() method to save 
   * all changes to the database.
   */
   public final void callCommitTransaction()
   {
      if (hasBindingsWithExc())
      {
         //check with bindings for any cached exceptions.
         Iterator iter = mBindingsWithExc.keySet().iterator();
         ArrayList al = new ArrayList(mBindingsWithExc.size());
         boolean found = false;
         Object excObj;
         Object errBinding;
         while (iter.hasNext())
         {
            errBinding = mBindingContext.get(iter.next());
            if (errBinding != null)
            {
               if (errBinding instanceof DCControlBinding)
               {
                  excObj = ((DCControlBinding)errBinding).getError();
               }
               else 
               {
                  excObj = ((DCIteratorBinding)errBinding).getError();
               }

               if (excObj != null)
               {
                  al.add(excObj);
                  found = true;
               }
            }
         }

         if (found)
         {
            //have exceptions throw it now.
            if (al.size() > 1)
            {
               JboException ex = new JboException(UIMessageBundle.class, UIMessageBundle.EXC_SYNC_ERROR, new Object[0]);
               ex.setExceptions((JboException [])al.toArray(new JboException[al.size()]));
            }
            else
            {
               throw (JboException)al.get(0);
            }
         }
      }

      DCBindingContainer panel;
      for (int i = 0; i < mBindingContainerList.size(); i++) 
      {
         panel = ((DCBindingContainer)mBindingContainerList.get(i));
         panel.callBeforeSaveTransaction(this);
         if (!panel.isEditingStopped())
         {
            //do not commit.
            return;
         }
      }

      commitTransaction();
   }  

   /**
   * Helper method that invokes rollback on the current Transaction.
   */
   public void rollbackTransaction()
   {
      Diagnostic.println("Default rollback Transaction : resetting transaction state!");
      transactionStateChanged(false);
   }

   /**
   * Returns true if this DCDataControl has modified attribute values.
   */
   public final boolean isTransactionModified()
   {
      return mTxnModified;
   }

   /**
   * If this transaction is not in modified state, this method sets it to
   * a modified state. This method is invoked in the framework to set the
   * transaction state to modified status. Also all DCTransactionStateListeners
   * are notified of this state-change so that status bars and navigation bars
   * could update their display.
   */
   public void setTransactionModified()
   {
      if (!mTxnModified) 
      {
         //set the transaction to modified state and let listeners know about that.
         //this is dirtying the listeners from the client side without consulting
         //the middle tier transaction state as one may not have gone to the 
         //middle tier but have changes in the clientside cache.
         mTxnModified = true;
         if (mTxnListeners != null) 
         {
            ArrayList al = mTxnListeners;
            for (int i = 0; i < al.size(); i++) 
            {
               ((DCTransactionStateListener)al.get(i)).transactionStateChanged(true);
            }
         }
      }
   }

   protected void internalSetTransactionStateChanged(boolean state)
   {
      mTxnModified = state;
      if (mTxnListeners != null) 
      {
         ArrayList al = mTxnListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCTransactionStateListener)al.get(i)).transactionStateChanged(state);
         }
      }
   }

   /**
   * Use this method to notify all transaction state change listeners of the change
   */
   public final void transactionStateChanged(boolean state)
   {
      if (state != mTxnModified) 
      {
         internalSetTransactionStateChanged(state);
      }
   }

   
   /**
   * Adds listeners like StatusBar and NavigationBars that have to listen and react
   * to transaction's modified state. 
   */
   public final void addTransactionStateListener(DCTransactionStateListener statusBar)
   {
      if (mTxnListeners == null) 
      {
         mTxnListeners = new ArrayList(5);
      }
      mTxnListeners.add(statusBar);
   }

   /**
   * Remove the given object from JUTransactionStateListener list.
   */
   public final void removeTransactionStateListener(DCTransactionStateListener statusBar)
   {
      if (mTxnListeners != null) 
      {
         mTxnListeners.remove(statusBar);
      }
   }

   /**
    * Implementation of oracle.jbo.TransactionStateListener interface.
    * Sends the transactionStateChanged event to all DCTransactionStateListeners
    * registered with this application.
    * @param event A description of the event.
    */
   public final void doneCommit(TransactionStateEvent event)
   {
      transactionStateChanged(false); //txn clean so, send in false
   }

   /**
    * Implementation of oracle.jbo.TransactionStateListener interface.
    * Sends the transactionStateChanged event to all DCTransactionStateListeners
    * registered with this application.
    * @param event A description of the event.
    */
   public final void doneRollback(TransactionStateEvent event)
   {
      transactionStateChanged(false); //txn clean so, send in false
   }

   /**
    * Invoked in some contexts to signal the beginning of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the ADF framework before
    * control is forwarded to the first <tt>Servlet</tt> defined by the request.
    * <p>
    * Subclassing datacontrols may extend this method to perform request level
    * initialization of the <tt>DataControl</tt>.
    * <p>
    * This method is guaranteed to be called only once per browser request.
    * Page forwards should not result in multiple invocations.
    * <p>
    * @param requestCtx a HashMap representing request context.  Web 
    *    applications which require request context may use the
    *    <tt>BindingContext.HTTP_REQUEST</tt> and
    *    <tt>BindingContext.HTTP_RESPONSE</tt> keys to acquire a reference
    *    from from the BindingContext.
    */
   public void beginRequest(HashMap requestCtx)
   {
      mUseCount++;
   }

   /**
    * Invoked in some contexts to signal the end of a model request.
    * For example, if the <tt>DataControl</tt> is referenced in a web
    * application then this method will be invoked by the ADF framework after
    * control is returned from the last <tt>Servlet</tt> defined by the request
    * page flow.
    * <p>
    * Subclassing datacontrols may extend this method to perform request level
    * cleanup of the <tt>DataControl</tt>.
    * <p>
    * This method is guaranteed to be called only once per browser request.
    * Page forwards should not result in multiple invocations.
    * <p>
    * @param requestCtx a HashMap representing request context.  Web 
    *    applications which require request context may use the
    *    <tt>BindingContext.HTTP_REQUEST</tt> and
    *    <tt>BindingContext.HTTP_RESPONSE</tt> keys to acquire a reference
    *    from from the BindingContext.
    */
   public void endRequest(HashMap requestCtx)
   {
      if (mUseCount == 0) return;

      --mUseCount;

      if (mReleasedIterators != null)
      {
         Iterator iters = mReleasedIterators.values().iterator();
         while (iters.hasNext())
         {
            releaseData((DCIteratorBinding)iters.next());
         }
         mReleasedIterators = null;
      }

      if (mResetStateDeferred)
      {
         resetState();
      }

      //clean out transient data.
      mTransientDataMap = null;
   }

   /**
    * Calls release(REL_ALL_REFS);
    */
   public void release()
   {
      release(REL_ALL_REFS);
   }

   public Definition getDefinition(String name, Class type)
   {
      return null;
   }

   /**
    * Based on the value of the flags parameter, releases all references to 
    * the objects in the data provider layer (BC4J or other data-provider objects).
    * Valid values for flags are:
    * <ul>
    *    <li><code>REL_ALL_REFS</code> - if this data control
    *        should release all references to both the view and model 
    *        objects.
    *    <li><code>REL_DATA_REFS</code> - if this data control
    *        should release all references to data provider objects. The
    *        likely usage would be when say an Application Module is to 
    *        be checked into a pool and this data-control may be given
    *        that or another checked out AM to work with subsequently.
    *    <li><code>REL_VIEW_REFS</code> - if this data control
    *        should release all references to the UI/View layer objects.
    * </ul>
    **/
   public void release(int flags)
   {
      ArrayList al;
      if ((flags & DCDataControl.REL_VIEW_REFS) > 0)
      {
         if (mStatusBarList != null) 
         {
            al = (ArrayList)mStatusBarList.clone();
            DCStatusBarInterface sb;
            for (int i = 0; i < al.size(); i++)
            {
               sb = (DCStatusBarInterface)al.get(i);
               sb.release();
            }
            mStatusBarList = null;
         }

         if (mTxnListeners != null) 
         {
            al = (ArrayList)mTxnListeners.clone();
            DCTransactionStateListener sb;
            for (int i = 0; i < al.size(); i++)
            {
               sb = (DCTransactionStateListener)al.get(i);
               sb.release();
            }
            mTxnListeners = null;
         }
      }

      boolean relDataRefs = ((flags & REL_DATA_REFS) > 0);
      
      if (relDataRefs || ((flags & REL_WEAK_DATA_REFS) > 0))
      {
         if (relDataRefs)
         {
            mMethodResults = null;
         }
         
         DCBindingContainer form;
         al = (ArrayList)mBindingContainerList.clone();
         for (int i = 0; i < al.size(); i++)
         {
            form = (DCBindingContainer)al.get(i);
            form.release(flags);
         }
      }
      
      if (flags == REL_ALL_REFS)
      {
         // JRS Why is this necessary?
         mBindingContainerList = new ArrayList(2);

         BindingContext bindingCtx = getBindingContext();

         // bindingCtx may be null if this is re-entered?
         if (bindingCtx != null)
         {
            String name = getName();
            bindingCtx.remove(name);

            // only replace with the reference if we have a 
            // DataControlDef.  The old behaviour of release is maintained
            // for old style applications -- release will blow away the DC
            // for good.
            if (mDCDef != null)
            {
               DCDataControlReference dcRef = new DCDataControlReference(mDCDef);
               dcRef.setUserParams(
                  (Map)get(DCDataControlReference.USER_PARAMS_KEY));

               bindingCtx.put(name, dcRef);
            }
         }
         setName(null);
      }
   }

   public boolean releaseData(DCIteratorBinding iter)
   {
      
      if (mUseCount > 0)
      {
         // queue up the iter for release during endRequest proecessing
         if (mReleasedIterators == null)
         {
            mReleasedIterators = new HashMap(4);
         }
         mReleasedIterators.put(iter.getFullName(), iter);
         return false;
      }
      else
      {
         releaseIterator(iter);
         return true;
      }
   }

   private void releaseIterator(DCIteratorBinding iter)
   {
      iter.invalidateCache();
   }

   /**
    * override hashmap.get()
    */
   public Object get(Object keyObj)
   {
      if (keyObj instanceof String)
      {
        String key = JboNameUtil.toUpperCaseFirstChar((String)keyObj).intern();
        Object retVal = internalGet(key);
        if (retVal != null)
        {
           return retVal;
        }
      }
      return super.get(keyObj);
   }

   /**
    * For EL evaluation.
    * Properties returned vis getter on this control bindings are:
    * <li><code>dataProvider</code>  - returns getDataProvider()</li>
    * <li><code>name</code> - returns getName()</li>
   * <li><code>applicationModule</code> - returns getApplicationModule()</li>
    */
   protected Object internalGet(String key)
   {
      oracle.jbo.common.DebugDiagnostic.println("DataControl:Looking for :"+key); //NONLS
      Object retObj = findBindingContainer(key);
      if (retObj != null)
      {
         return retObj;
      }
      if (GET_MethodResults == key)
      {
         return getMethodResults();
      }
      if (GET_dataProvider == key || GET_DataProvider == key)
      {
         return getDataProvider();
      }
      if (GET_ApplicationModule == key)
      {
         return getApplicationModule();
      }
      if (GET_Name == key)
      {
         return getName();
      }
      if (DCDataControlReference.USER_PARAMS_KEY.equals(key))
      {
         return mUserParams;
      }
      return null;
   }

   protected void internalPut(String key, Object value)
   {
      if (DCDataControlReference.USER_PARAMS_KEY.equals(key))
      {
         mUserParams = (Map)value;
      }
      else
      {
         super.internalPut(key, value);
      }
   }
   
   
   public void cleanup(){};
   
   public int hashCode()
   {
     return mName.hashCode();
   }

   protected void rebuildIteratorIfNeeded(DCIteratorBinding iterBinding)
   {
      //this is where we can 'reset the RSIs if they were recreated'.
      if (iterBinding.allowsRefreshControl() && iterBinding.getViewObject() == null)
      {
         //generic usecase.
         DCRowSetIteratorImpl rsiImpl = (DCRowSetIteratorImpl)iterBinding.getRowSetIterator();
         int useCount = getMethodResultUseCount(rsiImpl.getProviderMethodResultName());  
         if (useCount != rsiImpl.getProviderMethodResultUseCount())
         {
            rsiImpl.setProviderMethodResultUseCount(useCount);
            rsiImpl.rebuildIteratorUpto(0);
         }
      }
   }
   
   /**
    * Implies forced execute of the collection that this iterator binding
    * is bound to. Incase of database based collections, ideally, this should 're-execute'
    * the database query. This method is invoked via the Execute control binding action.
    */
   abstract protected void executeIteratorBinding(DCIteratorBinding iterBinding);
   
   /**
    * This method is invoked when a bindingcontainer is 'refreshing' itself before
    * it's data is displayed. Only execute the collections bound to this iterator
    * if they're not executed yet. Incase of method-result bound collections, this
    * method may refresh the collection references in the associated RSIs.
    */
   abstract protected void executeIteratorBindingIfNeeded(DCIteratorBinding iterBinding);
   
   /**
    * Return attribute definition for the given iterator binding and for the given set
    * of attributes from the elements-definition of the mapped collection.
    */
   public AttributeDef[] getAttributeDefs(DCIteratorBinding iterBinding, String[] attrNames)
   {
      return  new AttributeDef[0];
   }

   public boolean isAttributeSortable(DCIteratorBinding iter, AttributeDef ad)
   {
      boolean retVal = false;
      if (isOperationSupported(iter, OPER_SORT_COLLECTION)) 
      {
         return (ad.isQueriable());
      }
      return retVal;
   }

   /**
    * Returns true for operation = OPER_CTRL_BINDING_VALIDATION
    * Returns false for all other cases.
    */
   public boolean isOperationSupported(DCIteratorBinding iterBinding, byte operation)
   {
      DCDataControlDef def = getDef();
      switch (operation)
      {
         case OPER_CTRL_BINDING_VALIDATION:
            return true;

         case OPER_SORT_COLLECTION:
            return (def != null && DCDataControlDef.STR_TRUE.equals(def.get(JUTags.SupportsSortCollection)));

         case OPER_DATA_ROW_UPDATE:
            return (def != null && def.supportsTransactions());

         default:
            return false;
      }
   }

   /**
   * @internal *** For internal framework use only *** 
    */
   public final void setBindingContext(BindingContext ctx)
   {
      mBindingContext = ctx;
      if (ctx.get(getName()) != this)
      {
         ctx.put(getName(), this);
      }
   }

   /**
    * Returns the binding context in which this datacontrol is registered
    */
   public final BindingContext getBindingContext()
   {
      return (mBindingContext != null) ? mBindingContext : oracle.jbo.uicli.mom.JUMetaObjectManager.getJUMom().getBindingContext();
   }

   
   /**
    * @deprecated since 10.1.3. not called anymore.
    * Use invokeOperation() instead.
    */
   public Object invokeMethod(DCInvokeMethodDef methodInfo, java.util.ArrayList params)
   {
      return methodInfo.invokeMethod(this, params);
   }

  /**
   * Override this method if a datacontrol wants to implement custom invocation
   * of a method and avoid introspection and invoke method call using reflection.
   * ADF calls this method to invoke a methods bound via custom method-action binding.
   */
   protected Object invokeMethod(DCInvokeMethod method, OperationBinding action, java.util.Map params)
   {
      return method.invokeMethod(this, params);
   }

   public boolean invokeOperation(Map ctx, oracle.binding.OperationBinding action)
   {
      if (action instanceof oracle.jbo.uicli.binding.JUCtrlActionBinding) 
      {
         ((oracle.jbo.uicli.binding.JUCtrlActionBinding)action).doIt();
         return true;
      }
      else
      {
         //datacontrol should handle this action in subclass.
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("Warning! invokeAction ignored. DataControl subclass should handle this action");
         }
      }
      return false;
   }


   /**
   * @internal *** For internal framework use only *** 
    */
   //adds a control-binding name to the list of bindings with exceptions
   //this list is consulted during commit to see if this datacontrol
   //is clear to call commit()
   public void addBindingWithExc(String name)
   {
      if (mBindingsWithExc == null)
      {
         mBindingsWithExc = new HashMap(10);
      }
      mBindingsWithExc.put(name, name);
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   //removes a control binding exception cached at the datacontrol level.
   public void removeBindingWithExc(String name)
   {
      if (mBindingsWithExc != null)
      {
         mBindingsWithExc.remove(name);
      }
   }

   /**
    ** Returns true if this transaction has been dirtied by this application.
    */
   abstract public boolean isTransactionDirty();

   /**
    ** Returns true in case of BC4J client-tier app.
    */
   public boolean isClientTier()
   {
      return false;
   }

   public String toString()
   {
      return getName();
   }

   /**
    * Primarily used in ADFBC which returns true, if it is deployed in batchmode.
    */
   public boolean syncNeeded()
   {
      return false;
   }

   /**
    * Incase syncNeeded, then use this event to synchronize data from remote tier in batch.
    * This event differs from sync() in that this event synchronizes only
    * if some client operation has marked that a visit to middle tier is necessary.
    * sync() will visit middle tier regardless.
    */
   public void syncIfNeeded(String syncFromDiagnostic)
   {
      //noop. 
      //in case of syncNeeded, use this method to synchronize data from backend.
   }

   /**
    * Incase syncNeeded, then use this event to synchronize data from remote tier in batch.
    */
   public void sync(String syncFromDiagnostic)
   {
      //noop. 
      //in case of syncNeeded, use this method to synchronize data from backend.
   }

   /**
    * Implement estimated row count logic in this method and return
    * the row count for a collection bound to this iterator.
    */
   abstract protected long getEstimatedRowCount(DCIteratorBinding iter);

   public void setSessionContext(SessionContext sessionContext)
   {
      SessionContextManager mgr = getSessionContextManager();
      mgr.setCurrentSession(sessionContext);
   }

   public SessionContext getSessionContext()
   {
      SessionContextManager mgr = getSessionContextManager();
      return mgr.getCurrentSession();
   }


   protected SessionContextManager getSessionContextManager()
   {
      return SessionContextManagerImpl.getInstance();
   }

   /**
    * This method works for Collections with only one Key attribute and not for multi-part attribute keys.
    * <p>
    * Converts the stringValue into a Row key (using collection's key metadata) and then 
    * calls findByKey on the RowSetIterator to find the row matching this key. If a row
    * is found, that row is set as current.
    */
   public abstract void setCurrentRowWithKeyValue(DCIteratorBinding iter, String stringValue);
   
   /**
    * Converts the serialized stringKey into a Row key object (using collection's key metadata) and then 
    * calls findByKey on the RowSetIterator to find the row matching this key. If a row
    * is found, that row is set as current.
    */
   public abstract void setCurrentRowWithKey(DCIteratorBinding iter, String stringKey);

   /**
    * Use the given key to set the current row in the RowSetIterator for the given 
    * iteratorbinding.
    */
   public abstract void setCurrentRowWithKey(DCIteratorBinding iter, Key keyObj);

   
   /**
    * Called before the row in the RowContext object is modified/marked as removed.
    * This gives datacontrol implementations a chance to register the row's data-provider
    * as a modified object in the associated model.
    */
   public Object registerDataProvider(DCRowContext ctx)
   {
      return ctx.getRowDataProvider();
   }

   /**
    * @internal *** For internal framework use only ***
    * 
    * Called primarily for find mode to allow findmode to save out row changes 
    * incase of batchmode.
    */
   public void setAttributeInRow(DCIteratorBinding iterBind, Row row, AttributeDef ad, Object value)
   {
      row.setAttribute(ad.getIndex(), value);

      //for the first case when transaction is clean and on setAttr, the txn has
      //to be set to modified state (even though the middletier is not in modified
      //state yet as no sync has occured thus far.

      //check if in find mode. in that case do not set the txnmodified state to true.
      if (iterBind.isFindMode() || isTransactionModified() || ad instanceof oracle.jbo.Variable) 
      {
         return;
      }
      setTransactionModified();
   }

   /**
    * Create a new row for the iterator associated with the given iterator-binding
    * at the given index and return the new row.
    */
   public Object createRowData (DCRowContext ctx)
   {
      throw new UnsupportedOperationException("DataControl:createRowData"); //NONLS
   }

   /**
    * This method is to remove the row object (the <code>obj</code> parameter)
    * from the underlying data source.
    * <p>
    *
    * @param ctx  the row context to be removed.
    * @return     <code>true</code> if the operation was successful.
    *             <code>false</code> otherwise.
    */
   public boolean removeRowData (DCRowContext ctx)
   {
      throw new UnsupportedOperationException("DataControl:removeRowData"); //NONLS
   }
   

   /**
    * This method is to remove the row object (the <code>obj</code> parameter)
    * from the collection.  It should not remove the row from the underlying
    * data source.
    * <p>
    *
    * @param ctx  the row context to be removed.
    * @return     <code>true</code> if the operation was successful.
    *             <code>false</code> otherwise.
    */
   public boolean removeRowDataFromCollection (DCRowContext ctx)
   {
      return true;
   }

   /**
    * @internal *** For internal framework use only ***
    */
   protected AttributeDef[] resolveAttributeDefs(StructureDef def, String[] attrNames)
   {
      if (def == null)
      {
         return null;
      }
      if (attrNames == null)
      {
         return def.getAttributeDefs();
      }
      int size = attrNames.length;
      AttributeDef[] attrs = new AttributeDef[size];
      while (--size >= 0)
      {
         attrs[size] = def.findAttributeDef(attrNames[size]);
      }
      return attrs;
   }

   /**
    * @internal *** For internal framework use only ***
    * Sets the sort critiera that will be applied next time when the 
    * source for this iteratorBinding is executed.
    */
   protected abstract void applySortCriteria(DCIteratorBinding iter, SortCriteria[] sortby);

   /**
    * @internal *** For internal framework use only ***
    * Returns an ordered array of SortCriteria that will be applied when
    * the source for this iteratorBinding is executed.
    */
   protected abstract SortCriteria[] getSortCriteria(DCIteratorBinding iter);

   /**
    * For looking up method results stored in this DataControl.
    * Application and/or subclasses may cleanup the stored result
    * when the result is no longer needed by calling getMethodResults().remove()
    */
   public Map getMethodResults()
   {
      //do not return clone as the caller has to modify this map.
      if (mMethodResults == null) 
      {
        mMethodResults = new MethodResultsMap(10);
      }
      return mMethodResults;
   }

   /**
    * @internal *** For internal framework use only ***
    * RSI implementation may consult this
    * usecount and if the count does not match the count in the RSI
    * then it may reset it's source-collection reference, so that
    * it's fetched again.
    */
   public int getMethodResultUseCount(Object key)
   {
      return (mMethodResults != null) ? mMethodResults.getUseCount(key) : 0;
   }

   /**
    * Resets the DataControl.  DataControl providers should extend this method
    * to reset any model session state that may have been managed by this
    * DataControl.  For example:
    * <p>
    * The ADF/BC DataControl has extended resetState to release the DataControl 
    * ApplicationModule to the ApplicationPool in unmanaged release mode. 
    * <p>
    * An EJB DataControl provider may extend resetState to close the DataControl
    * EJB SessionBean
    * <p>
    * The Toplink DataControl provider extends resetState to reset the
    * DataControl's UnitOfWork and associated RowSetIterators.
    * <p>
    * Please note that resetState may not occur immediately.  If beginRequest
    * has been invoked on the DataControl then resetState processing will be
    * deferred until endRequest processing.
    * <p>
    * Extending DataControl providers may optionally invoke release(REL_DATA_REFS) after
    * performing and DataControl specific resetState handling.
    * <p>
    * @return true if resetState was processed immediately.  false if resetState
    *    was deferred to endRequest processing.
    */
   public boolean resetState()
   {
      if (mUseCount > 0)
      {
         mResetStateDeferred = true;
         return false;
      }

      mResetStateDeferred = false;
      return true;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   abstract public void applyViewCriteria(ViewCriteria vc, DCIteratorBinding iter, RowSetIterator rsi);

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Return viewCriteria associated with the given iterator binding's collection.
    */
   public ViewCriteria getViewCriteria(DCIteratorBinding iter)
   {
      return null;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Create a new viewCriteria associated with the given iterator binding's collection.
    */
   public ViewCriteria createViewCriteria(DCIteratorBinding iter)
   {
      return null;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   Map getTransientCreatedRowObjects()
   {
      return mTransientDataMap;
   }

   void setTransientCreatedRowObject(String rsiName, Object keyVal)
   {
      if (mTransientDataMap == null)
      {
         mTransientDataMap = new HashMap(4);
      }
      mTransientDataMap.put(rsiName, keyVal);
   }

   void releaseTransientCreatedRowObject(String rsiName)
   {
      if (mTransientDataMap != null)
      {
         mTransientDataMap.remove(rsiName);
         if (mTransientDataMap.size() == 0)
         {
            mTransientDataMap = null;
         }
      }
   }

   /**
    * @internal *** For internal framework use only ***
    * Reset any deferred exception in the row for the given attribute, for which
    * the AttrValException was raised. The default implementation is a noop.
    */
   protected void resetAttributeExceptionInRow(DCIteratorBinding iter, Row row, AttributeDef def, AttrValException ave)
   {
   }

   public boolean hasPermission(DCControlBinding binding, String target, String actions)
   {
      return (!PermissionHelper.isAuthorizationEnabled()) ? true : binding.internalHasPermission(target, actions);
   }

   public boolean hasPermission(DCControlBinding binding, String actions)
   {
      return (!PermissionHelper.isAuthorizationEnabled()) ? true : binding.internalHasPermission(actions);
   }

   public boolean hasPermission(Permission permission)
   {
      return PermissionHelper.hasPermission(getSecurityContext(), permission);
   }


   public SecurityContext getSecurityContext()
   {
       return ADFContext.getCurrent().getSecurityContext();
   }

   /**
   * @internal *** For internal framework use only ***
    */
   public boolean hasOperationParamsChanged (oracle.binding.OperationInfo info)
   {
      if (info instanceof DCInvokeMethod) 
      {
         DCInvokeMethod methodInfo = (DCInvokeMethod)info;
         return methodInfo.hasParameterValuesChanged();
      }
      return true;
   }

   /**
   * @internal *** For internal framework use only ***
    */
   protected void cacheMethodResult(DCInvokeMethod method, Object result, Object paramVals)
   {
      DCInvokeMethodDef def = method.getDef();
      BindingContext ctx = getBindingContext();
      String returnName = def.getReturnName();
      if ((returnName != null) && (ctx != null))
      {
         // should use expression engine here.
         DCUtil.putValueInPath(ctx, returnName, result);
         String paramsCache = def.getCachedParamsName(); 
         if (paramsCache != null) 
         {
            //append with ~paramvals and put the parameters in there too.
            DCUtil.putValueInPath(ctx, paramsCache, paramVals);
         }
      }
   }

   protected Object invalidateMethodResult(DCInvokeMethod method)
   {
      DCInvokeMethodDef def = method.getDef();
      BindingContext ctx = getBindingContext();
      String returnName = def.getReturnName();
      Object retVal = null;
      if ((returnName != null) && (ctx != null))
      {
         // should use expression engine here.
         retVal = DCUtil.removeValueFromPath(ctx, returnName);
         String paramsCache = def.getCachedParamsName(); 
         if (paramsCache != null) 
         {
            DCUtil.removeValueFromPath(ctx, paramsCache);
         }
      }

      return retVal;
  }

   /**
   * @internal *** For internal framework use only ***
    */
   protected boolean isBoundRowIteratorEvent(DCIteratorBinding iter, JboEvent ev)
   {
      return (iter.getNavigatableRowIterator() == ev.getSource());
   }

   /**
   * @internal *** For internal framework use only ***
    */
   protected oracle.jbo.Variable findVariable(String path)
   {
      return (oracle.jbo.Variable)DCUtil.findSpelObject(this, path, DCUtil.isElExpr(path));
   }

   /**
   * @internal *** For internal framework use only ***
    */
   public void executeIteratorBindingWithParams(DCIteratorBinding iter, OperationParameter[] params, Object[] paramVals)
   {
      executeIteratorBinding(iter);
   }
}  



