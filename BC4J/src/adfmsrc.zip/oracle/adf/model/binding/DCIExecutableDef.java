package oracle.adf.model.binding;

import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;

interface DCIExecutableDef
{
   public static final int EXECUTABLE_REGION          = RegionBinding.TYPE_EXECUTABLE_REGION;
   public static final int EXECUTABLE_ITERATORBINDING = 1;
   public static final int EXECUTABLE_ACTION          = 2;
   
   String getName();

   int getRefreshOption();
   String getRefreshExpression();


   /** 
    * Return EXECUTABLE_REGION, EXECUTABLE_ITERATORBINDING or EXECUTABLE_ACTION
    * based on what kind of binding this definition creates.
   */
   int getExecutableType();

   /**
    * Calculate whether the given executable instance is to be refreshed
    * based on the refreshFlag which is the flag sent into BindingContainer.refresh()
    * Return true if this executable has to be refreshed.
    */
   boolean isRefreshable(DCBindingContainer ctr, DCIExecutable exec, int refreshFlag);

   /**
    * Create an executable binding instance based on this definition in the given 
    * BindingContainer.
    */
   Object createExecutableBinding(BindingContext ctx, DCBindingContainer bindingContainer);
}
