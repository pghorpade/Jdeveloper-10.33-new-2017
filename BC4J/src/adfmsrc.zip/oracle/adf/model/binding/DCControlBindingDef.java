/*
 * @(#)DCControlBindingDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.HashMap;

import oracle.adf.model.layout.DCLayoutConsDef;

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;

abstract public class DCControlBindingDef extends DCDefBase
{
   private DCBindingContainerDef mFormDef;
   private DCLayoutConsDef mLayoutCons;
   
   private String mControlClassName;
   private String mControlBindingClassName;
   private String mIterBindingName;
   private Object mInitialValue;
   private String mDesignTimeClass;
   
   public static final String PNAME_TYPE = "DCControl";                          //NONLS   
   public static final String PNAME_ControlClass = "ControlClass";               //NONLS 
   public static final String PNAME_ControlBindingClass = "BindingClass";        //NONLS
   public static final String PNAME_IterBinding = "IterBinding";                 //NONLS
   public static final String PNAME_InitialValue = "InitialValue";               //NONLS
   public static final String PNAME_CustomInputHandler = "CustomInputHandler";   //NONLS
   
   protected DCControlBindingDef()
   {
      setDefClassName(getClass().getName());
   }


   protected DCControlBindingDef(String name, String controlClassName,
                       String controlBindingClassName, String iterBindingName)
   {
      super(name);

      mControlClassName = controlClassName;
      mControlBindingClassName = controlBindingClassName;
      mIterBindingName = iterBindingName;
   }

   
   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;

      if ((val = initValues.get(PNAME_ControlClass)) != null)
      {
         mControlClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_ControlBindingClass)) != null)
      {
         mControlBindingClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_IterBinding)) != null)
      {
         mIterBindingName = val.toString();
      }
      
      if ((val = initValues.get(PNAME_InitialValue)) != null)
      {
         mInitialValue = val;
      }
      
      if ((val = initValues.get(JUTags.DesignTimeClass)) != null)
      {
         mDesignTimeClass = val.toString();
      }
      
   }

   public String getDesignTimeClass()
   {
      return mDesignTimeClass;
   }
   
   public String getControlClassName()
   {
      return mControlClassName;
   }

   public void setControlClassName(String controlClassName)
   {
      mControlClassName = controlClassName;
   }

   
   public String getControlBindingClassName()
   {
      return mControlBindingClassName;
   }

   
   public void setControlBindingClassName(String controlBindingClassName)
   {
      mControlBindingClassName = controlBindingClassName;
   }

   
   public String getIterBindingName()
   {
      return mIterBindingName;
   }

   
   protected void setBindingContainerDef(DCBindingContainerDef formDef)
   {
      mFormDef = formDef;

      super.setParent(formDef);
   }

   public final DCBindingContainerDef getBindingContainerDef()
   {
      return mFormDef;
   }
   
   
   public DCIteratorBinding getIterBinding(DCBindingContainer formBnd)
   {
      //do not throw from here. The caller should handle if iter is null
      return formBnd.findIteratorBinding(mIterBindingName);
   }

   
   public DCLayoutConsDef getLayoutCons()
   {
      return mLayoutCons;
   }

   
   void setLayoutCons(DCLayoutConsDef layoutCons)
   {
      mLayoutCons = layoutCons;

      /* FIXME is this needed
       * layoutCons.setParent(this);*/
   }

   
   public Object getInitialValue()
   {
      return mInitialValue;
   }

   
   public void setInitialValue(Object initialValue)
   {
      mInitialValue = initialValue;
   }

   
   public Object createControl()
   {
      return (mControlClassName != null && mControlClassName.length() > 0) ? DCUtil.createNewInstance(mControlClassName) : null;
   }

   
   abstract protected DCControlBinding createControlBindingInstance(Object control, DCBindingContainer formBnd);

   public DCControlBinding createControlBinding(Object control, DCBindingContainer formBnd)
   {
      DCControlBinding controlBnd = createControlBindingInstance(control, formBnd);
      controlBnd.setDef(this);
      return controlBnd;
   }

   public DCControlBinding createControlBinding(DCBindingContainer formBnd)
   {
      return createControlBinding(createControl(), formBnd);
   }


   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }
   
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, PNAME_ControlClass, valueTab);
      readXMLString(xmlElement, PNAME_ControlBindingClass, valueTab);
      readXMLString(xmlElement, PNAME_IterBinding, valueTab);
      readXMLString(xmlElement, PNAME_InitialValue, valueTab);
      readXMLString(xmlElement, JUTags.DesignTimeClass, valueTab);
   }
   
      
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      loadLayoutDef(xmlElement);
   }

   
   void loadLayoutDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList layouts = xmlElement.getChildrenList(DCLayoutConsDef.PNAME_TYPE);

      if (layouts.size() > 0)
      {
         DefElement layoutXML = (DefElement) layouts.get(0);
         DCLayoutConsDef layout = (DCLayoutConsDef) DCDefBase.createAndLoadFromXML(layoutXML, null);

         setLayoutCons(layout);
      }
   }

   /**
    * called after a binding's loadFromXML is done and it needs to load extra metadata
    * like properties, validations etc. BindingContainerDef is already set by this time
    * on the controldef.
   */
   protected void loadCustomDef(DefElement xmlElement)
   {
      //do nothing.
   }
     
}
