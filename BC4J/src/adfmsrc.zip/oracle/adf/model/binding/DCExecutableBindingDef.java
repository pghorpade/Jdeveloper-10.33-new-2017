/*
 * @(#)DCExecutableBindingDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.HashMap;

import oracle.adf.model.BindingContext;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;

import com.sun.java.util.collections.ArrayList;

import java.security.Permission;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;

abstract public class DCExecutableBindingDef extends DCDefBase implements DCIExecutableDef
{
   public static final String PNAME_option = JUTags.Refresh;
   public static final String PNAME_optionExpr = JUTags.RefreshCondition;
   public static final String PNAME_option_DEFAULT     = "ifNeeded";
   public static final String PNAME_option_PREPARE     = "prepareModel";
   public static final String PNAME_option_RENDER      = "renderModel";
   public static final String PNAME_option_PREPARE_OPT = "prepareModelIfNeeded";
   public static final String PNAME_option_RENDER_OPT  = "renderModelIfNeeded";
   public static final String PNAME_option_ALWAYS      = "always";
   public static final String PNAME_option_DEFER       = "deferred";
   public static final String PNAME_option_NEVER       = "never";

   //DEPRECATED
   public static final String PNAME_option_REFRESH_OPT = PNAME_option_RENDER_OPT;
   public static final String PNAME_option_REFRESH     = PNAME_option_RENDER;


   public final static int RC_DEFAULT     = -1;     //11111111 11111111
   public final static int RC_PREPARE     = 0x0001; //00000000 00000001
   public final static int RC_PREPARE_OPT = 0x0002; //00000000 00000010
   public final static int RC_RENDER      = 0x0010; //00000000 00010000
   public final static int RC_RENDER_OPT  = 0x0020; //00000000 00100000
   public final static int RC_ALWAYS      = 0x0011; //00000000 00010001
   public final static int RC_NEVER       = 0x0000; //00000000 00000000
   public final static int RC_DEFER       = 0x8000; //10000000 00000000

   //DEPRECATED
   public final static int RC_REFRESH     = RC_RENDER;
   public final static int RC_REFRESH_OPT = RC_RENDER_OPT;


   private int mRefreshOption = RC_DEFAULT; //default is to execute only if necessary
   private String mRefreshExpression = null;
   
   public DCExecutableBindingDef()
   {
      setSubType(PNAME_Iterator);
   }

   public DCExecutableBindingDef(String name)
   {
      super(name);
      setSubType(PNAME_Iterator);
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;
      
      if ((val = initValues.get(PNAME_option)) != null)
      {
         mRefreshOption = internalGetRefreshOptionFromString((String)val);
      }
      if ((val = initValues.get(PNAME_optionExpr)) != null)
      {
         mRefreshExpression = (String)val;
      }
   }

   public final int getRefreshOption()
   {
      return mRefreshOption;
   }

   public final String getRefreshExpression()
   {
      return mRefreshExpression;
   }

   /**
    * *** For internal framework use only ***
    */
   static public int internalGetRefreshOptionFromString(String str)
   {
      if (str != null) 
      {
         str = str.intern();
         if (str == PNAME_option_DEFAULT) 
         {
            return RC_DEFAULT;
         }
         if (str == PNAME_option_DEFER) 
         {
            return RC_DEFER;
         }
         if (str == PNAME_option_PREPARE) 
         {
            return RC_PREPARE;
         }
         if (str == PNAME_option_RENDER) 
         {
            return RC_RENDER;
         }
         if (str == PNAME_option_PREPARE_OPT) 
         {
            return RC_PREPARE_OPT;
         }
         if (str == PNAME_option_RENDER_OPT) 
         {
            return RC_RENDER_OPT;
         }
         if (str == PNAME_option_ALWAYS) 
         {
            return RC_ALWAYS;
         }
         if (str == PNAME_option_NEVER) 
         {
            return RC_NEVER;
         }
      }
      return RC_DEFAULT;
   }

   public String getXMLElementTag()
   {
      return PNAME_option;
   }
   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      readXMLString(xmlElement, PNAME_option, valueTab);
      readXMLString(xmlElement, PNAME_optionExpr, valueTab);
   }

   public abstract int getExecutableType();

   public abstract Object createExecutableBinding(BindingContext ctx, DCBindingContainer ctr);

   public boolean isRefreshable(DCBindingContainer ctr, DCIExecutable exec, int refreshFlag)
   {
      if (!internalHasPermission(ctr))
      {
         return false;
      }

      int refreshOption = exec.getRefreshOption();

      boolean retVal = false;
      switch (refreshOption) 
      {
      case RC_DEFER:
         //never make it refreshable. This has to be refreshed
         //at the usage time
         retVal = (refreshFlag == DCBindingContainer.REFRESH_UNKNOWN);
         break;

      case RC_PREPARE:
         //true only if incoming flag is for preparemodel
         retVal = (refreshFlag == DCBindingContainer.PREPARE_MODEL);
         break;

      case RC_PREPARE_OPT:
         //true only if incoming flag is prepareModel
         //and parameters have changed.
         if (refreshFlag == DCBindingContainer.PREPARE_MODEL) 
         {
            retVal = (exec.hasRefreshParametersChanged());
         }
         break;

      case RC_RENDER:
         //true only if incoming flag is for rendermodel
         retVal = (refreshFlag == DCBindingContainer.RENDER_MODEL);
         break;

      case RC_RENDER_OPT:
         //true only if incoming flag is renderModel
         //and parameters have changed.
         if (refreshFlag == DCBindingContainer.RENDER_MODEL) 
         {
            retVal = (exec.hasRefreshParametersChanged());
         }
         break;
      
      case RC_ALWAYS:
         retVal = true;
         break;

      case RC_NEVER:
         retVal = false;
         break;
      }

      if (retVal || refreshOption == RC_DEFAULT) 
      {
         String expr = exec.getRefreshExpression();
         boolean invalidExpr = true;
         if (expr != null && expr.length() > 0)
         {
            Object obj = ctr.evaluateParameter(exec.getRefreshExpression(), true);
            if (obj != null) 
            {
               invalidExpr = false;
               if (!(obj instanceof Boolean) )
               {
                  retVal =  Boolean.valueOf((String)obj.toString()).booleanValue();
               }
               else
               {
                  retVal = ((Boolean)obj).booleanValue();
               }
            }
            else
            //no special case for values evaluating to null.
            //if (refreshOption != RC_DEFAULT)
            {
               retVal = false;
            }
         }
         //for default option, go to parameters to see if this needs refresh
         //or if the executable is not refreshed, make it refreshable.
         //iteratorbinding are marked released/not refreshed at the end of
         //each request.
         //
         // JRS 4674093 The isRefreshed check in this stmt is causing
         // an incongruency between the IfNeeded and PrepareModelIfNeeded
         // refresh options because we are always setting the executable
         // as not refreshed in prepareModel.  Removing the check for
         // non-iterator bindings.  Retaining the check for iterator bindins
         // because of regression concerns.
         if (invalidExpr && refreshOption == RC_DEFAULT) 
         {
            retVal= exec.hasRefreshParametersChanged()
               //|| !exec.isRefreshed()
               || (exec.getExecutableType() == EXECUTABLE_ITERATORBINDING && !exec.isRefreshed())
               || refreshFlag == DCBindingContainer.EXECUTE_MODEL;
         }
      }
      return retVal;
   }

   protected boolean internalHasPermission(DCBindingContainer ctr)
   {
      SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
      if (!secContext.isAuthorizationEnabled())
      {
         return true;
      }

      DCDataControl dc = ctr.getDataControl();

      String permClassName = getPermissionClassName();
      if (permClassName == null)
      {
         return true;
      }

      String target = getPermissionTargetName();
      if (target != null)
      {
         Permission p = (Permission)PermissionHelper.createPermissionInstance(permClassName, target, PermissionHelper.getReadAction(permClassName));

         if (dc != null && !dc.hasPermission(p))
         {
            return false;
         }
      }
      return true;
   }

   protected String getPermissionTargetName()
   {
      return getFullName();
   }

   protected String getPermissionClassName()
   {
      return PermissionHelper.getPermissionClassName(PermissionHelper.REGION_PERMISSION);
   }
}
