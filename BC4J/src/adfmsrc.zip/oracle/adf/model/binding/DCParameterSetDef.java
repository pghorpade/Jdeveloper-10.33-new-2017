package oracle.adf.model.binding;

import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.mom.xml.DefElement;
import java.util.HashMap;

public class DCParameterSetDef extends DCDefBase 
{
   private HashMap _values = new HashMap();
   
   public DCParameterSetDef()
   {
   }

   public HashMap getValues()
   {
      return _values;   
   }
   
   public String getXMLElementTag()
   {
      return  JUTags.Parameters;
   }
   
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);
      
      com.sun.java.util.collections.ArrayList values = xmlElement.getChildrenList(JUTags.Parameter);

      if(values == null)
        return;
        
      for (int i = 0; i < values.size(); i++)
      {
         DefElement valueXML = (DefElement) values.get(i);
         
         String sName = valueXML.getAttribute("name");                 //NONLS
         String sValue = valueXML.getAttribute("value");               //NONLS
         
         if(sName != null)
          _values.put(sName, sValue);
      }
   }
}