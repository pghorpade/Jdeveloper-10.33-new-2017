/*
 * @(#)DCIteratorBinding.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.BindingContext;
import oracle.adf.model.PermissionInfo;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboEvent;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.NavigationEvent;
import oracle.jbo.NoObjException;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowNotAvailableException;
import oracle.jbo.RowSetIterator;
import oracle.jbo.RowSetListener;
import oracle.jbo.RowSetManagementEvent;
import oracle.jbo.RowSetManagementListener;
import oracle.jbo.ScrollEvent;
import oracle.jbo.SortCriteria;
import oracle.jbo.UpdateEvent;
import oracle.jbo.ValidationException;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.ws.WSRowSet;


/**
 * DCIteratorBinding is the binding class that interacts with RowIterator objects
 * to iterate over rows and provide the current row(s) for use in a client application
 * or to view via various control bindings. DCIteratorBinding objects are uniquely identified
 * by name in a  DCBindingContainer which acts as a container of iterator bindings.
 * This class handles the events generated from the associated RowIterator and sends the
 * current Row (rows in range) over to individual control bindings to display current data.
 * This class also manages the findMode data for the associated iterator and ViewObject(incase of BC4J).
 * <p>
 * At runtime, an application can bind an instance of oracle.jbo.NavigatableRowIterator
 * to a DCIteratorBinding object using the <code>bindRowSetIterator</code> method.
 *
 *
 * @javabean.class name=DCIteratorBinding
 */
public abstract class DCIteratorBinding extends DCExecutableBinding implements RowSetListener, RowSetManagementListener
{
   protected ApplicationModule mAM;
   private String mSourceName;
   private String mRSIName;
   private ViewObject mVO;
   private ViewCriteria mVC;
   private SortCriteria[] mSC;
   private String mViewDefName;
   private NavigatableRowIterator mRSI;
   private NavigatableRowIterator mOldRSI;
   private ArrayList mValueBindingList;
   private ArrayList mActionBindingList;
   private boolean mIsBound = true;
   private boolean mIsAlive = true;
   private boolean mFindMode = false;
   private boolean mAllowFindMode = true;
   private boolean mRowSetEventsEnabled = true;
   protected int mRangeSize = RANGESIZE_DO_NOT_OVERRIDE; //from 1 so that JClient
                                                         //does not set this forcefully
                                                         //for old jclient apps.

   private boolean mInitVisible = false;
   private boolean mNeedsEstimatedRC  = false;
   protected DCDataControl mDC;
   private boolean mDCNotInitialized = true;
   protected boolean inExecute = false;
   private DCIteratorBindingDef mDef;
   private JboException mErrExc;
   private boolean mRowNotPrepared = true;
   private boolean mSuspendRowSetEvents = false;
   private Row mReservedRow;
   protected Row mCreatedRowRef;
   private boolean mTokenDisabled;
   public static int RANGESIZE_DO_NOT_OVERRIDE = 0;
   public static int RANGESIZE_UNLIMITED = -1;

   private static String ROOTAM = "Root";

   protected DCIteratorBinding()
   {
      mName = ""; //NONLS
   }

   protected DCIteratorBinding(DCIteratorBinding iterBinding)
   {
      mAM = iterBinding.mAM;
      mSourceName = iterBinding.mSourceName;
      mRSIName = iterBinding.mRSIName;
      mRangeSize = iterBinding.mRangeSize;
   }


   /**
   * Use this constructor if a usage needs a specific range size on the associated iterator.
   * Objects of type DCCtrlRangeBinding may use this constructor to specify a default
   * range size for the iterator.
   */
   protected DCIteratorBinding(BindingContext ctx, String dcName, String sourceName, String rsiName, int rangeSize)
   {
      mDC = (DCDataControl)DCUtil.findContextObject(ctx, dcName);

      if (mDC != null)
      {
         mAM = mDC.getApplicationModule();
      }
      mSourceName = sourceName;
      mRSIName = rsiName;
      mRangeSize = rangeSize;
   }
   /**
   * Use this constructor if a usage needs a specific range size on the associated iterator.
   * Objects of type DCCtrlRangeBinding may use this constructor to specify a default
   * range size for the iterator.
   */
   protected DCIteratorBinding(ApplicationModule am, String voName, String rsiName, int rangeSize)
   {
      mAM = am;
      mSourceName = voName;
      mRSIName = rsiName;
      mRangeSize = rangeSize;
   }

   /**
   * When the usage only needs one row at a time, use this constructor to create
   * an iterator binding.
   */
   protected DCIteratorBinding(ApplicationModule am, String voName, String rsiName)
   {
      this (am, voName, rsiName, 1);
   }

   /**
   * When an application has a RowSet it should use this constructor.
   */
   protected DCIteratorBinding(DCDataControl dc, RowSetIterator rsi)
   {
      mDC = dc;
      if(mDC != null)
      {
         mAM = mDC.getApplicationModule();
      }
      if (rsi != null)
      {
         bindRowSetIterator(rsi, false);
         ViewObject vo = getViewObject();
         if (vo != null)
         {
            mAM = vo.getApplicationModule();
         }
         mRangeSize = rsi.getRangeSize();
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * After creation sets the def used to create this iterator binding.
    */
   protected void setDef(DCIteratorBindingDef def)
   {
      mDef = def;
      setExecutableDef(def);
   }


   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * @internal *** For internal framework use only ***
    */
   public DCIteratorBindingDef getDef()
   {
      return mDef;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Called on this binding before a binding returns from processInputValue
    * This gives the iterator binding a chance to mark new row state to STATUS_NEW
    * from initialized and hence submit the new row even if there are no changes
    * on the row.
   * @internal *** For internal framework use only ***
    */
   public void prepareForInput()
   {
      if (mRowNotPrepared)
      {
         mRowNotPrepared = false;
         Row r = getCurrentRow();
         if (r != null)
         {
            r.setNewRowState(Row.STATUS_NEW);
         }

         //track that binding has led to a change in model.
         getBindingContainer().prepareForInput();
      }
   }

   /**
    * Is this bound to a collection returned from a bean accessor?
    */
   public boolean isAccessorIterator()
   {
      return getDef() != null && getDef().isAccessorType();
   }

   void doneInput()
   {
     mRowNotPrepared = true;
   }


   /**
    * Returns the name of this IteratorBinding.
    */
   public final String getDisplayName()
   {
     if (isIteratorMadeVisible() && getViewObject() != null)
     {
       return getViewObject().getName();
     }
     return getName();
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the name of the ViewObject instance of the iterator to which this iterator binding is associated.
   */
   public String getVOName()
   {
      return mSourceName;
   }

   /**
   * Returns the name of the collection instance to which this iterator binding is bound to.
   */
   public String getSourceName()
   {
      return mSourceName;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the name of the ViewDefinition object.
   */
   public final String getViewDefName()

   {
      return mViewDefName;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * @internal *** For internal framework use only ***
   */
   void setViewDefName(String viewDefName)
   {
      mViewDefName = viewDefName;
   }


   /**
   * Utility method to report exceptions via the containing binding container.
    * If the exception is not JboException, this method creates a JboException that
    * contains the input exception object and passes only JboException to the
    * bindingcontainer. If BindingContainer is null then this method rethrows
    * the JboException.
    * @param markDead if this iterator binding should be marked as not alive for
    * any further usage.
    * @param ex Exception object to be reported via the BindingContainer.
   */
   public void reportException(boolean markDead, Exception ex)
   {
      JboException je;
      if (ex instanceof JboException)
      {
         je = (JboException)ex;
      }
      else
      {
         je = new JboException(ex);
      }

      //since I'm raising this exception, if source is not set,
      //I should handle this exception back when it comes in processInputException.
      if (je.getSource() == null)
      {
         je.setSource(getRowSetIterator());
      }

      //get the RSI before marking it dead.
      if (markDead)
      {
         mIsAlive = false;
      }

      if (getBindingContainer() != null)
      {
         getBindingContainer().reportException(je);
      }
      else //if (mDC != null)
      {
         //no body to pass this to.
         throw je;
         //mDC.reportException(je);
      }
   }

   /**
   * Use this method to bind a new instance of RowIterator from a Business Service
   * to this binding. This method should be used to display data from a different
   * RowIterator of the same Collection type in a given form. For example, if
   * a tree is used to navigate Departments and their employees, upon selecting
   * an employee node, an application can pass the Employee node's RowIterator
   * over to this iterator binding, to update the display in another panel of Employee
   * data with the currently selected Employee.
   * <p>
   * This method will not directly update the control-bindings for non-ADFJClient apps.
   * The caller can optionally call <code>navigated(null)</code> method, with null for
   * the Event parameter to notify each control bound to this iterator binding to update
   * it's displayed  value with the new iterator's current row.
   * @param iter RowIterator instance from which to display data in bound controls.
   * @param initRangeSize determines whether this iterator's range size should be
   * adjusted to this binding's range size. This should be used to extend the range size
   * from the default in the RowIterator to whatever is required by this iterator
   * binding. For example, if a RowIterator whose range size is 1 is passed to this
   * method and a grid control is bound to this iterator binding, then the grid
   * may need more than one row to display from the current range. So, this
   * flag should be true in that case to allow the grid to get the full range
   * of rows to display, rather than updating its display one row at a time.
   */
   public void bindRowSetIterator(NavigatableRowIterator iter, boolean initRangeSize)
   {
      NavigatableRowIterator oldRsi = mRSI;
      if (mRSI != null)
      {
         if (mRSI instanceof RowSetIterator)
         {
            ((RowSetIterator)mRSI).removeManagementListener(this);
         }
         mRSI.removeListener(this);
         removeDependentListeners();
      }

      mRSI = iter;

      if ((mIsBound = (iter != null)))
      {
         if (!mFindMode)
         {
            RowSetIterator rsi = (RowSetIterator)iter;
            if(rsi instanceof java.lang.reflect.Proxy)
            {
             RowSetIterator wsvo = null;
             oracle.jbo.common.ws.WSProxy wspro = (oracle.jbo.common.ws.WSProxy)(java.lang.reflect.Proxy.getInvocationHandler(rsi));
             wsvo = wspro.getInternalRowSetIter();
             rsi = wsvo;
             mRSI = rsi;
            }


            if (rsi.getRowSet() != null)
            {
               mVO = rsi.getRowSet().getViewObject();
               mSourceName = createAbsoluteVOName(mVO.getFullName());
            }
            mRSIName = rsi.getName();
            rsi.addManagementListener(this);
         }

         mRSI.addListener(this);

         if (initRangeSize && mRangeSize != RANGESIZE_DO_NOT_OVERRIDE)
         {
            mRSI.setRangeSize(mRangeSize);
         }

         addDependentListeners();

         //mark the Iterator alive again as it's been rebound to a non null
         //RSI. gvbm2 sv33
         setAlive(true);
      }

      //this immediate refresh is only required for JClient apps.
      //Webcases would pull the new data when ready to draw page.
      //
      // jrs 5716842.  only perform this work if we are going to fire the
      // range refreshed event (iter != oldRSI).  this method is 
      // re-entered during release in some scenarios and can cause an
      // exception during dc acquisition.
      if ((iter != oldRsi) && (isIteratorMadeVisible() || allowsRefreshControl()))
      {
         DCDataControl dc = getDataControl();
         if (dc != null && dc.isJClientApp())
         {
            rangeRefreshed(null); //force a repaint of rows.
         }
      }
   }

   public final boolean isBoundRowIteratorEvent(JboEvent ev)
   {
      return (hasRSI() && getDataControl().isBoundRowIteratorEvent(this, ev));
   }

   //
   // abstract RowSetListener implementation
   //
   //
   // RowSetListener implementation
   //

   /**
    * @internal *** For internal framework use only ***
    */
   public final boolean isIteratorMadeVisible()
   {
      return mInitVisible;
   }

   /**
    * @internal *** For internal framework use only ***
    */
   protected void setIteratorMadeVisible(boolean flag)
   {
      mInitVisible = flag;
   }

   /**
    * Returns true if this IteratorBinding should notify the containing BindingContainer's RowSetListeners of RowSet events.
    **/
   public final boolean isRowSetEventsEnabled()
   {
      return mRowSetEventsEnabled;
   }

   /**
    * Set this flag if this IteratorBinding should pass on the rowset events to containing BindingContainer's RowSetListeners.
    * Applications should turn off this flag for IteratorBindings used for readonly purposes like LOVs, etc which do not
    * need any UI overrides like enabling/disabling a control etc.
    **/
   public final void setRowSetEventsEnabled(boolean flag)
   {
      mRowSetEventsEnabled = flag;
   }

   /**
    * Set this flag to turn off reacting to RowSetIterator events. BindingContainer
    * uses this during refreshControl() during batch datacontrol operations. Also
    * when this iterator is released the events-handling may be turned off by
    * using this suspend.
    */
   public void suspendRowSetEventsHandling(boolean flag)
   {
      mSuspendRowSetEvents = flag;
   }

   /**
    * Returns true if this IteratorBinding is not reacting to any RowSetIterator events.
    */
   public boolean isSuspendRowSetEventsHandling()
   {
      return mSuspendRowSetEvents;
   }

   /**
   * @internal *** For internal framework use only ***
   */
   void resetInputState()
   {
      //binding container's refreshControl() method calls this.
      mErrExc = null;
      mRowNotPrepared = true;
      if (mCreatedRowRef != null)
      {
         releaseCachedRow();
      }
      if (getDataControl() != null) 
      {
         getDataControl().removeBindingWithExc(getFullName());
      }
      ArrayList ctrls = mValueBindingList;
      if (ctrls != null)
      {
         for (int i = 0; i < ctrls.size(); i++)
         {
            ((DCControlBinding)ctrls.get(i)).resetInputState();
         }
      }
      ctrls = mActionBindingList;
      if (ctrls != null)
      {
         for (int i = 0; i < ctrls.size(); i++)
         {
            ((DCControlBinding)ctrls.get(i)).resetInputState();
         }
      }
   }


   /**
   * @internal *** For internal framework use only ***
    */
   public boolean allowsRefreshControl()
   {
      return true;
   }

   /**
    * @internal *** For internal framework use only ***
    * If this binding's RSI has a current row, make that ready for
    * refreshControl to pass it on to various bindings to display
    * data. Override allows accessor Iterators to verify their
    * currency wrt. the current master before proceeding with use
    * of this row.
    */
   protected Row prepareCurrentRow()
   {
      return getCurrentRow();
   }

   /**
   * @internal *** For internal framework use only ***
   */
   void refreshControl()
   {
      if (!allowsRefreshControl())
      {
         return;
      }
      setRefreshed(true);
      DCBindingContainer formBinding = getBindingContainer();
      synchronized(getSyncLock())
      {
         DCDataControl dc = getDataControl();
         NavigatableRowIterator rsi = getNavigatableRowIterator();
         if (rsi != null)
         {
            //simply notify to update from the current row.
            boolean setToFirst = false;

            //go to DC everytime as the created row may have been
            //updated by backbutton followed by another create in the
            //originating bindingContainer.
            mCreatedRowRef = null;

            //check if not in findMode, if datacontrol has Transient data and I am a VO based
            //RSI (not a generic/domain RSI).
            Map map;
            if ( !mFindMode && getViewObject() != null
                 && (dc != null && ((map = dc.getTransientCreatedRowObjects()) != null)))
            {
               Object keyObj = map.get(getCachedRSIName((RowSetIterator)rsi));
               if (keyObj != null)
               {
                  if (keyObj instanceof Row)
                  {
                     //if this refreshControl is after sync, then check if
                     //this key has a valid rowHandle by now. If so cache that on the
                     //datacontrol.
                     mCreatedRowRef = ((Row)keyObj);
                     Key k = mCreatedRowRef.getKey();

                     if (((Integer)k.getRowHandle()).intValue() > 0)
                     {
                        //update datacontrol as row handle should be updated by now due to sync.
                        getDataControl().setTransientCreatedRowObject(getCachedRSIName(getRowSetIterator()), k);
                     }
                     //else we have a cached row but we do not have it's handle resolved yet.
                     //leave this alone for now and come back in next refreshControl to resolve
                     //the handle.
                  }
                  else if (keyObj instanceof Key)
                  {
                     Row rows[] = rsi.findByKey((Key)keyObj, 1);
                     if (rows != null && rows.length == 1)
                     {
                        mCreatedRowRef = rows[0];
                     }
                  }
               }
            }

            if (mCreatedRowRef == null)
            {
               int rowSlot = -1;

               try
               {
                  rowSlot = rsi.getCurrentRowSlot();
               }
               catch (oracle.jbo.RowNotAvailableException rnaex)
               {
                  if (!dc.syncNeeded())
                  {
                     reportException(false /*markDead*/, rnaex);
                  }

                  return;
               }

               if (rowSlot != RowSetIterator.SLOT_VALID)
               {
                  setToFirst = mInitVisible;
                  if (formBinding != null && dc.isJClientApp())
                  {
                     java.awt.Component panel = ((java.awt.Component)formBinding.getViewComponent());
                     setToFirst =  (setToFirst || (panel != null && panel.isVisible()));
                  }
               }
            }

            Row row = null;
            if(!inExecute)
            {
               if (setToFirst)
               {
                  try
                  {
                     row = rsi.first();
                  }
                  catch (oracle.jbo.RowNotAvailableException rnaex)
                  {
                     if (!dc.syncNeeded())
                     {
                        reportException(false /*markDead*/, rnaex);
                     }

                     boolean returnForMoreRows = true;
                     try
                     {
                        //may be at the end of the dataset, so check if
                        //more rows exist and if so visit MT during next
                        //sync.
                        if (!rsi.hasNext())
                        {
                           row = null;
                           returnForMoreRows = false;
                        }
                     }
                     catch (Exception e)
                     {
                        //eat this and return
                     }

                     if (returnForMoreRows)
                     {
                        return;
                     }
                  }
               }
               else
               {
                  row = prepareCurrentRow();
               }
            }

            setIteratorMadeVisible(true);
            //for setToFirst case, in case of Rangesize = 1, we've already sent navigation
            //event via rsi.first() call which should update the "controls" with the current
            //row.
            if (!setToFirst || mRangeSize != 1)
            {
               updateValuesFromRows(getAllRowsInRange(), row, true);
            }
            else if (setToFirst && mRangeSize == 1 && row == null)
            {
               // JRS 7/15/2003 if we setToFirst and the row was null
               // then a navigation event will not be be fired by rsi.first()
               // above.  Let's reset the iterator here.
               // need a navigation event to force the UIs to redisplay.
               navigated(new NavigationEvent(rsi, null, null));
            }
            // sim 6/24/04 -- Removing the catch block below.
            //    If error handler is used with the throw option
            //    true, and if getAllRowsInRange() above
            //    throws a RowNotAvailableException, we were eating
            //    up the exception throw.
            // catch (oracle.jbo.RowNotAvailableException rnaex)
            // {
            //    if (!dc.syncNeeded())
            //    {
            //       reportException(false /*markDead*/, rnaex);
            //    }
            // }
         }
      }
   }

   /**
   * Handles the rangeRefereshed event generated by the current RowIterator.
   * If the range size of this binding is 1, then calls updateValuesFromRow()
   * with the current row as the argument to notify all control bindings
   * associated with this iterator binding of the change in current row.
   * If the range size is not 1, then this method calls updateValuesFromRows()
   * passing in the current range of rows to all DCCtrlRangeBinding control bindings.
   * @internal *** For internal framework use only ***
   */
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      if (mSuspendRowSetEvents)
      {
         return;
      }

      refreshControl();

      if (mRowSetEventsEnabled)
      {
         DCBindingContainer formBinding = getBindingContainer();
         if (formBinding != null)
         {
            formBinding.rangeRefreshed(this, event);
         }
      }
   }


   /**
   * This method invokes updateRangeScrolled method on all instances of
   * DCCtrlRangeBinding objects associated with this iterator binding,
   * to notify them of the change in current range of rows.
   * @internal *** For internal framework use only ***
   */
   public void rangeScrolled(ScrollEvent event)
   {
      if (mRowSetEventsEnabled)
      {
         DCBindingContainer formBinding = getBindingContainer();
         if (formBinding != null)
         {
            formBinding.rangeScrolled(this, event);
         }
      }
   }


   /**
   * If range size of this iterator binding is not 1,
   * this method invokes updateRowInserted method on all instances of
   * DCCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   * @internal *** For internal framework use only ***
   */
   public void rowInserted(InsertEvent event)
   {
      if (!isFindMode())
      {
         if (getDataControl() != null)
         {
            mDC.transactionStateChanged(true);
         }
      }
      if (mSuspendRowSetEvents)
      {
        return;
      }
      if (mRowSetEventsEnabled)
      {
         if (mCreatedRowRef != null)
         {
            releaseCachedRow();
         }
         DCBindingContainer formBinding = getBindingContainer();
         if (formBinding != null)
         {
            formBinding.rowInserted(this, event);
         }
      }
   }


   public void internalGetNextRangeSet()
   {
      //currency is set on the first row in the rangeby this guy
      RowSetIterator iter = getRowSetIterator();
      int curRangeStart = iter.getRangeStart();

      try
      {
         //so that incase of JTable this does not lead to infinite cycles.
         suspendRowSetEventsHandling(true);
         iter.getNextRangeSet();
      }
      finally
      {
         suspendRowSetEventsHandling(false);
      }

      if (getDataControl().isJClientApp())
      {
         rangeRefreshed(null); //force a repaint of rows.
      }

      int rangeSize = iter.getRowCountInRange();
      if (rangeSize > 0)
      {
         if (getRangeStart() == curRangeStart)
         {
            //iter.setCurrentRowAtRangeIndex(rangeSize-1);
            //in jclient table, when next is pressed, we need
            //the focus to be on the first row of the next set
            //just like in jsp.
            //this.rangeScrolled(new ScrollEvent(iter, curRangeStart));
         }
         else if(iter.getRowAtRangeIndex(0) != null)
         {
            iter.setCurrentRowAtRangeIndex(0);
            this.rangeScrolled(new ScrollEvent(iter, curRangeStart));
         }
         else
         {
            iter.setRangeStart(iter.getRangeStart());
            getDataControl().sync("DCIteratorBinding.internalGetNextRangeSet");  //nonls
         }
      }
   }

   public void internalGetPreviousRangeSet()
   {
      //currency is set on the first row in the rangeby this guy
      NavigatableRowIterator iter = getNavigatableRowIterator();

      int curRangeStart = iter.getRangeStart();
      int curRowIndex = iter.getCurrentRowIndex()-1;
      try
      {
         suspendRowSetEventsHandling(true);
         ((RowSetIterator)iter).getPreviousRangeSet();
      }
      finally
      {
         suspendRowSetEventsHandling(false);
      }

      if (getDataControl().isJClientApp())
      {
         rangeRefreshed(null); //force a repaint of rows.
      }

      int rangeSize = iter.getRangeSize();
      if (iter.getRangeStart() == curRangeStart - rangeSize)
      {
         iter.setCurrentRowAtRangeIndex(rangeSize-1);
      }
      else
      {
         curRangeStart = iter.getRangeStart();
         if ((curRowIndex > curRangeStart) && (curRowIndex < (curRangeStart+rangeSize)))
         {
            iter.setCurrentRowAtRangeIndex(curRowIndex-curRangeStart);
         }
         else
         {
            iter.setCurrentRowAtRangeIndex(0);
         }
      }
   }


   /**
   * If range size of this iterator binding is not 1,
   * this method invokes updateRowDeleted method on all instances of
   * DCCtrlValueBinding objects associated with this iterator binding,
   * to notify them of the newly inserted row.
   * <p>
   * This method also sets the currency on the RowIterator to
   * the next row (if available) or previous row (if available)
   * or simply a NO row by calling navigated() with no current row.
   * @internal *** For internal framework use only ***
   */
   public void rowDeleted(DeleteEvent event)
   {
      if (!isFindMode())
      {
         if (getDataControl() != null)
         {
            mDC.transactionStateChanged(true);
         }
      }

     if (mSuspendRowSetEvents)
     {
        return;
     }

      NavigatableRowIterator iter = getNavigatableRowIterator();
      if (iter.getCurrentRowSlot() == RowSetIterator.SLOT_DELETED)
      {

         if (iter.hasNext())
         {
            //tryPrevious = false;
            if (!getDataControl().syncNeeded())
            {
               iter.next();
            }
            else
            {
               try
               {
                  iter.next();
               }
               catch (RowNotAvailableException rnae)
               {
                  int curIndex = iter.getCurrentRowIndex();
                  int rangeStart = iter.getRangeStart();

                  //if current row is in the rangeIndex, then sync and
                  //set currency to the next row.
                  if (curIndex >= rangeStart
                     && curIndex < rangeStart + iter.getRangeSize())
                  {
                     getDataControl().sync("DCIteratorBinding.rowDeleted().next, on RowNotAvailableException"); //nonls
                     if (iter.hasNext())
                     {
                        iter.next();
                     }
                  }
                  else
                  {
                     //deleted row has been sent out of the range
                     //due to change in rangeSize. So set the first row
                     //in the current range as current.
                     iter.setCurrentRowAtRangeIndex(0);
                  }
               }
            }
         }
         else if (iter.hasPrevious())
         {
            if (!getDataControl().syncNeeded())
            {
               iter.previous();
            }
            else
            {
               try
               {
                  iter.previous();
               }
               catch (RowNotAvailableException rnae)
               {
                  getDataControl().sync("DCIteratorBinding.rowDeleted().previous, on RowNotAvailableException"); //nonls

                  if (iter.hasPrevious())
                  {
                     iter.previous();
                  }
               }
            }
         }
         else
         {
            if (mRowSetEventsEnabled)
            {
               DCBindingContainer formBinding = getBindingContainer();
               if (formBinding != null)
               {
                  formBinding.rowDeleted(this, event);
               }
            }
            //try to handle no row situation.
            navigated(new NavigationEvent(iter, null, null));
            //if (getDataControl().syncNeeded())
            //{

               //force a reset event so that details go to null.
               iter.reset();

            //}
            return;
         }
      }

      if (mRowSetEventsEnabled)
      {
         DCBindingContainer formBinding = getBindingContainer();
         if (formBinding != null)
         {
            formBinding.rowDeleted(this, event);
         }
      }
   }

   /**
   * Invokes updateValuesFromRow() to notify all control bindings of
   * a change in an attribute in the row.
   * @internal *** For internal framework use only ***
   */
   public void rowUpdated(UpdateEvent event)
   {
      if (!isFindMode())
      {
         /*
         if (getDataControl() != null)
         {
            mDC.transactionStateChanged(true);
         }
         */
      }
     if (mSuspendRowSetEvents)
     {
        return;
     }
      synchronized(getSyncLock())
      {
         notifyUpdateEvent(event);
      }
      if (mRowSetEventsEnabled)
      {
         DCBindingContainer formBinding = getBindingContainer();
         if (formBinding != null)
         {
            formBinding.rowUpdated(this, event);
         }
      }
   }

   /**
   * Calls updateNavigated() for all DCCtrlRangeBinding instances associated
   * with this iterator binding object, or calls updateValuesFromRow() on
   * all other control binding instances, passing in the current row instance
   * from the RowIterator.
   * @internal *** For internal framework use only ***
   */
   public void navigated(NavigationEvent event)
   {
     if (mSuspendRowSetEvents)
     {
        return;
     }
     if (mRowSetEventsEnabled)
     {
        if (mCreatedRowRef != null)
        {
           releaseCachedRow();
        }
        DCBindingContainer formBinding = getBindingContainer();
        if (formBinding != null)
        {
           formBinding.navigated(this, event);
        }
     }

      ArrayList l = this.getActionBindingList();
      DCControlBinding binding;
      if (l != null)
      {
         for (int i = 0; i < l.size(); i++)
         {
            binding = (DCControlBinding)l.get(i);
            if (binding.mAttributeListener != null)
            {
               binding.mAttributeListener.updateRenderer();
            }
         }
      }
   }

   /**
    * called when rowUpdated event is received from the model.
    */
   protected abstract void notifyUpdateEvent(UpdateEvent event);


   /**
   * Calls updateValuesFromRows() on each instance of DCCtrlRangeBinding object
   * associated with this iterator binding object. These objects are then responsible for
   * updating their display with the latest set of rows.
   */
   protected abstract void updateValuesFromRows(Row[] rows, Row row, boolean clear);


   /**
   * Calls updateValueFromRow() on each instance of DCCtrlValueBinding objects
   * associated with this iterator binding object. These control binding objects are
   * responsible for updating their display with values from the given Row.
   */
   protected abstract void updateValuesFromRow(Row row);

   /**
   * @internal *** For internal framework use only ***
   */
   public final Object getSyncLock()
   {
      if (mAM != null)
      {
         return mAM.getSyncLock();
      }
      if (mDC  != null)
      {
         return mDC.getRootDataControl();
      }
      return this;
   }


   //
   // RowSetManagementListener implementation
   //

   /**
   * Notifies rangeRefreshed to all bindings so that
   * they can update their display.
   * @internal *** For internal framework use only ***
   */
   public void iteratorReset(RowSetManagementEvent event)
   {
      // show no row
     if (mSuspendRowSetEvents)
     {
        return;
     }

     if (mCreatedRowRef != null)
     {
        releaseCachedRow();
     }
     rangeRefreshed(null);
   }


   /**
   * Resets the internal state of this binding object and marks it as unusable.
   * @internal *** For internal framework use only ***
   */
   public void iteratorClosed(RowSetManagementEvent event)
   {
      synchronized(getSyncLock())
      {
         /*
         bindRowSetIterator(null, false);
         mAM = null;
         mVO = null;
         mVC = null;
         mOldRSI = null;

         mIsAlive = false;
         mFindMode = false;
         */
         releaseDataInternal();
      }
   }


   //
   // Accessors
   //
   public ViewCriteria getViewCriteria()
   {
      if (mVC == null)
      {
         if (mRSI == null && mOldRSI == null)
         {
            //initialize the rsi.
            getRowSetIterator();
         }
         mVC = getDataControl().getViewCriteria(this);
      }
      return mVC;
   }

   /**
   * Returns the ViewObject to which this iterator binding is associated with (via the binding
   * definition). If the rowSetIterator that this binding is associated with is changed at runtime
   * then the rowsetIterator should be used to get the current ViewObject for a running instance
   * of IteratorBinding. In general applications should use hasRSI() to find out if this
   * IteratorBinding has an instance of associated RowSetIterator and if so, use
   * rsi.getRowSet().getViewObject() to get the current ViewObject instance. Use this method
   * only if hasRSI() returns false.
   * <p>
   * Returns null for non-bc4j collection bound IteratorBindings.
   */
   public ViewObject getViewObject()
   {
      if (mVO == null)
      {
         RowSetIterator rsi = (RowSetIterator)((mFindMode) ? mOldRSI : mRSI);
         if (rsi != null)
         {
            if (rsi.getRowSet() != null)
            {
               mVO = rsi.getRowSet().getViewObject();
            }
         }
         if (mVO == null && getApplicationModule() != null)
         {
           synchronized(getSyncLock())
           {
              //if the rsi was killed, or
              //if this iterator's rsi (by name) was bound to null rsi, then
              //return null.
              if (!(mIsAlive && mIsBound) && !(!mIsAlive && !mIsBound))
              {
                 return null;
              }

              if (mVO == null)
              {
                 try
                 {
                    //find use getVOName as it's overridden in
                    //method iterator case.
                    String voname = getVOName();
                    try
                    {

                       if (Diagnostic.isOn())
                       {
                          Diagnostic.println("Resolving VO:"+voname+" for iterator binding:"+getName());
                       }
                       //see if this source name has been parameterized and overridden.
                       Object obj = getBindingContainer().evaluateParameter(voname, false, true);
                       if (obj instanceof ViewObject)
                       {
                          mVO = (ViewObject)obj;
                       }
                       else if (obj instanceof String)
                       {
                          //el returned String. that should be used as name for this vo.
                          //it could return the same name.
                          voname = (String)obj;
                       }
                       if (mVO == null)
                       {
                          //sjvtodo add root.
                          //if (voname.indexOf(DCUtil.SEP_DOT_CHAR) < 1) 
                          {
                             mVO = mAM.findViewObject(voname);
                          }
                          /*
                          else
                          {   
                             StringBuffer voBuf = new StringBuffer()
                                                  .append(ROOTAM)
                                                  .append(DCUtil.SEP_DOT_CHAR)
                                                  .append(voname);
                             mVO = mAM.findViewObject(voBuf.toString());
                          }
                          */
                       }
                    }
                    catch (oracle.jbo.NoObjException noex)
                    {
                       if (mDC != null)
                       {
                          //since voname can be parameterized and in that
                          //case it's set into voname.
                          String strName = voname;
                          if (strName.startsWith(mDC.getName()))
                          {
                             strName = strName.substring(mDC.getName().length()+1);
                             try
                             {
                                //sjvtodo add root.
                                //if (strName.indexOf(DCUtil.SEP_DOT_CHAR) < 1) 
                                {
                                   mVO = mAM.findViewObject(strName);
                                }
                                /*
                                else
                                {   
                                   StringBuffer voBuf = new StringBuffer()
                                                        .append(ROOTAM)
                                                        .append(DCUtil.SEP_DOT_CHAR)
                                                        .append(strName);
                                   mVO = mAM.findViewObject(voBuf.toString());
                                }
                                */
                             }
                             catch (Exception inne)
                             {
                                //ignore inne;
                                if (Diagnostic.isOn())
                                {
                                   Diagnostic.printStackTrace(inne);
                                }
                             }
                          }
                       }
                       if (mVO == null)
                       {
                          throw noex;
                       }
                    }


                    if (mVO == null)
                    {
                       if (mViewDefName == null)
                       {
                          throw new NoObjException(NoObjException.TYP_VIEW_OBJECT, mSourceName);
                       }

                       mVO = mAM.createViewObject(mSourceName, mViewDefName);
                    }
                 }
                 catch(Exception ex)
                 {
                    reportException(true /*markDead*/, ex);
                 }
              }
           }
         }

      }
      return mVO;
   }

   /**
   * Sets this iterator binding and it's associated RowIterator's range size to the
   * greater of this either the iterator's range size and the given range size. If either is -1,
   * then that takes precedence, so that range size = all rows.
   */
   public void resolveRangeSize(int rangeSize)
   {
      int myRange = mRangeSize;
      if (myRange > RANGESIZE_DO_NOT_OVERRIDE && myRange != rangeSize)
      {
         if (rangeSize == RANGESIZE_UNLIMITED)
         {
            myRange = RANGESIZE_UNLIMITED;
         }
         else
         if (rangeSize > myRange)
         {
            myRange = rangeSize;
         }

         if (myRange != mRangeSize)
         {
            RowSetIterator rsi = getRowSetIterator();
            if (rsi != null)
            {
               mRangeSize = myRange;
               setRangeSizeForRSI(rsi, myRange);
            }
         }
      }
   }

   /**
   * returns true if a RowSetIterator has been bound to this iterator.
   */
   public boolean hasRSI()
   {
      return (((RowSetIterator)((mFindMode) ? mOldRSI : mRSI)) != null);

   }

   /**
   * Returns the current data RowSetIterator that holds rows with which this iterator binding
   * object and its associated control-bindings are working.
   */
   public RowSetIterator getRowSetIterator()
   {
      RowSetIterator rsi = (RowSetIterator)((mFindMode) ? mOldRSI : mRSI);

      if (rsi != null)
      {
         return rsi;
      }

      synchronized(getSyncLock())
      {
         // JRS 02/12/2004 mIsAlive = false and mIsBound = false
         // represents the "zombie" state.  go to initSourceRSI
         // if we are in the zombie state.

         if (!(mIsAlive && mIsBound) && !(!mIsAlive && !mIsBound))
         {
            return null;
         }

         setAlive(true);

         if (mCallInitSourceRSI
             /*
             //perhaps we can perform a isrefreshable check here as well
             //if we do not want to even get an RSI. No usecase for now so
             //leaving this out.
             && (getDef() != null && getDef().isRefreshable(getBindingContainer(),
                                                          this,
                                                          DCExecutableBindingDef.RC_DEFAULT))
             */
             )
         {
            //so that initRSI will be retried. If rsi returns null,
            mIsBound = true;
            rsi = callInitSourceRSI();
            mIsBound = (rsi != null);
         }

         return rsi;
      }
   }
   private boolean mCallInitSourceRSI = true; //avoid cycles in initSourceRSI on exception.
   private RowSetIterator callInitSourceRSI()
   {
      DCIteratorBindingDef def = getDef();
      RowSetIterator rsi = null;
      {
         try
         {
            mCallInitSourceRSI = false;
            rsi = initSourceRSI();
            if (mSC == null && def != null && def.getSortCriteria() != null)
            {
               applySortCriteria(def.getSortCriteria());
            }
            //moved mIsBound setting into initSourceRSI as
            //for method iterator, this method needs to retry getting
            //RSI again if the input values were not set the first time.
         }
         catch (Exception ex)
         {
            mIsBound = (rsi != null);
            reportException(true /*markDead*/, ex);
         }
         finally
         {
            mCallInitSourceRSI = true;
         }
      }
      return rsi;
   }



   protected RowSetIterator initSourceRSI()
   {
      RowSetIterator rsi = null;
      if (getApplicationModule() != null)
      {
         ViewObject vo = getViewObject();

         if (vo == null)
         {
            return null;
         }

         if (mRSIName == null)
         {
            rsi = vo;
         }
         else
         {
            //datacontrol knows it's a working set case.
            if (!getDataControl().syncNeeded())
            {
               rsi = vo.findRowSetIterator(mRSIName);

               if (rsi == null)
               {
                  rsi= vo.createRowSetIterator(mRSIName);
               }
            }
            else
            {
               rsi = ((WSRowSet) vo).findOrCreateRowSetIterator(mRSIName);
            }
         }
      }
      else
      {
         String srcName = mSourceName;
         if (srcName != null)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Resolving collection source:"+srcName+" for iterator binding:"+getName());
            }
            //see if this source name has been parameterized and overridden.
            Object obj = getBindingContainer().evaluateParameter(srcName, false, true);

            if (obj instanceof RowSetIterator)
            {
               rsi = (RowSetIterator)obj;
            }
            else if (obj instanceof String)
            {
               //el returned String. that should be used as name for this vo.
               //it could return the same name.
               srcName = (String)obj;
            }

            if (rsi == null)
            {
               DCDataControl dc = getDataControl();
               if (srcName != null && srcName.startsWith(dc.getName()))
               {
                  if (srcName.length() > dc.getName().length())
                  {
                     srcName = srcName.substring(dc.getName().length()+1);
                  }
                  else if (srcName.equals(dc.getName()))
                  {
                     srcName = oracle.adf.model.generic.DCGenericDataControl.DC_ROOT_ACC_NAME;
                  }
               }

               if (Diagnostic.isOn())
               {
                  Diagnostic.println("Looking for RSI with name :"+srcName+" for iterator binding:"+getName());
               }
               rsi = getDataControl().getRowSetIterator(srcName);
            }
         }
         else
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Warning! DCIteratorBinding.initSourceRSI - <null> sourceName not expected");
            }
         }
      }
      if (rsi != null)
      {
         if (mFindMode)
         {
            mOldRSI = rsi;
         }
         else
         {
            if(rsi instanceof java.lang.reflect.Proxy)
            {
               RowSetIterator wsvo = null;
               oracle.jbo.common.ws.WSProxy wspro = (oracle.jbo.common.ws.WSProxy)(java.lang.reflect.Proxy.getInvocationHandler(rsi));
               wsvo = wspro.getInternalRowSetIter();
               rsi = wsvo;
            }

            mRSI = rsi;
            rsi.addListener(this);
            rsi.addManagementListener(this);
            addDependentListeners();
            //doing this here means the last iterator binding get's it settings
            //into the RSI. This is a problem if more-than-one bindings talk to the same
            //rsi - like if a grid and a navigationbar are looking at the same rsi, both
            //need to share this iterator, otherwise, whichever iterator-binding is
            //created last will have it's settings forced onto the RSI.
            //do this only for JClient.
            int rangeSize = rsi.getRangeSize();
            if (getDataControl().isJClientApp())
            {
               if (rangeSize > mRangeSize)
               {
                  resolveRangeSize(rangeSize);
               }
            }

            //this is the first time RowSetIterator is used. Set the client
            //side - rangeSize so that we get the required set of rows
            //in both batch/non-batch modes.
            if (rangeSize != mRangeSize && mRangeSize != RANGESIZE_DO_NOT_OVERRIDE)
            {
               setRangeSizeForRSI(rsi, mRangeSize);
            }
         }

      }

      //set whether the first time this binding was bound or not.
      //if not it needs an explicit bindRowSetIterator call before
      //any operations on this binding would return any rows.
      mIsBound = (rsi != null);
      return rsi;
   }

   /**
   * Returns the current RowIterator, which can be a data RowSetIterator or a find mode ViewCriteria
   * based on the find mode.
   */
   public NavigatableRowIterator getNavigatableRowIterator()
   {
      if (mFindMode)
      {
         return getViewCriteria();
      }
      return getRowSetIterator();
   }

   void removeDependentListeners()
   {
      List al = getDependents();
      if (al != null) 
      {
         Object l;
         RowSetListener listener;
         for (int i = 0; i < al.size(); i++) 
         {
            l = al.get(i);
            if (l instanceof DCIteratorBinding) 
            {
               if ((listener = ((DCIteratorBinding)l).getMasterListener())
                  != null) 
               {
                  mRSI.removeListener(listener);
               }
            }
         }
      }
   }

   void addDependentListeners()
   {
      List al = getDependents();
      if (al != null) 
      {
         Object l;
         RowSetListener listener;
         for (int i = 0; i < al.size(); i++) 
         {
            if ((l = al.get(i)) instanceof DCIteratorBinding) 
            {
               if ((listener = ((DCIteratorBinding)l).getMasterListener()) != null) 
               {
                  mRSI.addListener(listener);
               }
            }
         }
      }
   }

   protected RowSetListener getMasterListener()
   {
      return null;
   }

   /**
    * Advanced Internal
    * This method is for list bindings to mark the source binding to not
    * go into find mode.
    */
   public final void setAllowFindMode(boolean flag)
   {
      mAllowFindMode = flag;
   }

   public final boolean isFindModeAllowed()
   {
      return mAllowFindMode;
   }


   /**
   * Calls setFindMode(boolean mode, boolean applyCriteria) with applyCriteria = true;
   */
   public final void setFindMode(boolean mode)
   {
      setFindMode (mode, true);
   }

   /**
   * Sets this iterator to findMode or not. If mode = false, then it applies the
   * current ViewCriteria to this binding's ViewObject to execute the criteria if
    * applyVC = true;
   */
   public final void setFindMode(boolean mode, boolean applyVC)
   {
      if (mAllowFindMode)
      {
         if (mode != mFindMode)
         {
            if (mode)
            {
               //am setting findmode. see if my datacontrol allows it.
               if (!getDataControl().isOperationSupported(this, DCDataControl.OPER_FIND_MODE))
               {
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.println("Warning! Find mode not supported by DataControl associated with iterator binding:"+getName());
                  }
                  mAllowFindMode = false;
                  return;
               }
            }

            //cache this early to avoid cycles when mode is switched.
            ViewObject vo = getViewObject();

            mFindMode = mode;
            NavigatableRowIterator iter;
            if (mode)
            {
               mOldRSI = mRSI; //set this before getting the ViewCriteria RSI.
               iter = getNavigatableRowIterator();
               setupFindMode();
            }
            else
            {
               iter = mOldRSI;
               if (iter == null)
               {
                  //this will use the VO to get a WSRSI in case of batchmode.
                  if (mCallInitSourceRSI)
                  {
                     iter = callInitSourceRSI();
                  }
               }

               //was true before. now turning to false to execute, so set criteria
               if (applyVC && mVC != null)
               {
                  mVC.trimNoDataRows();
                  if (mVC.getRowCount() > 0)
                  {
                     getDataControl().applyViewCriteria(mVC, this, (vo != null) ? vo : (RowSetIterator)iter);
                  }
                  else
                  {
                     //clean out the view critiera.
                     getDataControl().applyViewCriteria(null, this, (vo != null) ? vo : (RowSetIterator)iter);
                  }
               }
               //if not applyVC / cancel find mode and in batchmode, then
               //clean out the criteria. Also if mVC was null, set criteria to
               //null if we have a valid rsi.
               else if (vo != null && (iter != null || (!applyVC && getDataControl().syncNeeded())))
               {
                  //for accesors, this may be null. in that case
                  //we do not want to reset the VC as it should
                  //be already null or whatever MT is set into.
                  getDataControl().applyViewCriteria(null, this, (vo != null) ? vo : (RowSetIterator)iter);
               }
               mVC = null; //get it from VO next time.
            }

            //rebind the iterator to make sure new row inserted in VC is
            //displayed/rendered on the direct bound UIs (Jclient).
            bindRowSetIterator(iter, false);
         }
      }
   }

   /**
   * Returns true if this iterator binding is in find mode.
   * @javabean.property 
   */
   public final boolean isFindMode()
   {
      return mFindMode;
   }

   public final boolean needsEstimatedRowCount()
   {
      return mNeedsEstimatedRC;
   }

   void initForRefresh()
   {
      mIsBound = true;
      mIsAlive = true;
   }

   /**
   * Executes the query or the RowSet behind this iterator binding object.
   */
   public void executeQuery()
   {
      synchronized(getSyncLock())
      {
         //if it's properly bound or if RSI was released
         //and this is an attempt to rebind.
         if (mIsAlive && mIsBound)
         {
            try
            {
               if (mCreatedRowRef != null)
               {
                  releaseCachedRow();
               }
               doExecuteQuery();
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }
      }
   }


   /**
   * Executes the query or the RowSet behind this iterator binding object if not already executed.
   */
   public void executeQueryIfNeeded()
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound)
         {
            getDataControl().executeIteratorBindingIfNeeded(this);
            if (!mInitVisible) 
            {
               setIteratorMadeVisible(true);
            }

            //mark it refreshed as we now have access to data in this collection.
            //iteratorbindings with refresh=never will be marked refreshed
            //when executed/or executeQueryIfNeeded
            setRefreshed(true);
         }
      }
   }

   /**
    * Calls datacontrol.executeIteratorBinding.
    */
   protected void doExecuteQuery()
   {
      getDataControl().executeIteratorBinding(this);
      if (!mInitVisible) 
      {
         setIteratorMadeVisible(true);
      }
      //mark it refreshed as we now have access to data in this collection.
      //iteratorbindings with refresh=never will be marked refreshed
      //when executed/or executeQueryIfNeeded
      setRefreshed(true);
   }


   /**
   * Returns the current row of the iterator with which this binding object is associated. In find mode,
   * this returns an instance of ViewCriteriaRow.
    *
    * @javabean.property
   */
   public Row getCurrentRow()
   {
      if (mReservedRow != null)
      {
         return mReservedRow;
      }
      return internalGetCurrentRowInBinding();
   }

   /**
    ** <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected Row internalGetCurrentRowInBinding()
   {
      //if iterator is not refreshed, refresh it which should prepare the
      //rsi for this iterator binding. 
      if (!isRefreshed())
      {
         refreshIfNeeded();
      }

      if (!isFindMode())
      {
         if (mCreatedRowRef != null)
         {
            return mCreatedRowRef;
         }
      }
      synchronized(getSyncLock())
      {
         //do not force getNavigatableRowIterator as this leads to iterator
         //binding being executed = even though it might not be ready to be
         //executed. !isRefreshed followed by refreshIfNeeded above should
         //have prepared the RSI for this iteratorbinding.

         NavigatableRowIterator iter = (mFindMode || hasRSI()) ? getNavigatableRowIterator() : null;
         if (mIsAlive && mIsBound && iter != null)
         {
            DCDataControl dc = getDataControl();
            try
            {
               if (iter.getCurrentRowSlot() == RowSetIterator.SLOT_BEFORE_FIRST)
               {
                  //should come in this case via JSP/web apps when there's no execute done thus far.
                  //should I execute the containing panel binding here?
                  if (dc != null && !dc.isJClientApp())
                  {
                     try
                     {
                        //break the cycle otherwise you'd come here the first time in cycles.
                        if (!inExecute)
                        {
                           //set init visible to true as this is web case and we want
                           //the focus on first row.
                           setIteratorMadeVisible(true);
                           inExecute = true;

                           if(iter.getCurrentRowSlot() == RowIterator.SLOT_BEFORE_FIRST && refreshIfNeeded())
                           {
                              iter.first();
                           }
                        }
                     }
                     finally
                     {
                       inExecute = false;
                     }
                  }
               }
               return iter.getCurrentRow();

            }
            catch (oracle.jbo.RowNotAvailableException rnaex)
            {
               if (!dc.syncNeeded())
               {
                  reportException(false /*markDead*/, rnaex);
               }
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }

         return null;
      }
   }


   /**
   * Returns the row of given range index.
   *
   * @param rangeIndex The range index of the row.
   *
   */
   public Row getRowAtRangeIndex(int rangeIndex)
   {
      synchronized(getSyncLock())
      {
         if (mIsAlive && mIsBound && refreshIfNeeded())
         {
            try
            {
               return getNavigatableRowIterator().getRowAtRangeIndex(rangeIndex);
            }
            catch(Exception ex)
            {
               reportException(false /*markDead*/, ex);
            }
         }

         return null;
      }
   }

   /**
   * Returns an array of rows in the current range of the current RowIterator.
   * @javabean.property
   */
   public Row[] getAllRowsInRange()
   {
      synchronized(getSyncLock())
      {
         if (refreshIfNeeded() && mIsAlive && mIsBound)
         {
            {
               try
               {
                  NavigatableRowIterator rsi = getNavigatableRowIterator();
                  return (rsi != null) ? rsi.getAllRowsInRange() : null;
               }
               catch(Exception ex)
               {
                  reportException(false /*markDead*/, ex);
               }
            }
         }

         return null;
      }

   }


   /**
   * @internal *** For internal framework use only ***
   */
   public void setBindingContainer(DCBindingContainer formBnd)
   {
      if (formBnd != null)
      {
         if (mDC != null)
         {
            mDC.addBindingContainer(formBnd);
         }
      }
      super.setBindingContainer(formBnd);
      //mBindingContainer = formBnd;
   }

   /**
   * Helper method to return the DCDataControl from this binding's BindingContainer.
   *
   * @javabean.property
   */
   public final DCDataControl getDataControl()
   {
      if (mDC == null && mDCNotInitialized)
      {
         mDCNotInitialized = false;
         internalSetDataControl(initDataControl());
      }
      return mDC;
   }

   /**
    * @internal
    */
   protected DCDataControl initDataControl()
   {
      if (getDef() != null)
      {
         String dcName = getDef().getDataControlName();
         if (dcName != null)
         {
            //Use this chokepoint to redirect to DCName aliasing in bindingContainer
            //return getBindingContainer().getBindingContext().findDataControl(dcName);
            return getBindingContainer().findDataControl(dcName);
         }
      }
      return ((getBindingContainer() != null) ? getBindingContainer().getDataControl() : null);
   }

   /**
    * @internal
    */


   void internalSetDataControl(DCDataControl dc)
   {
      mDC = dc;
      if (mDC != null && getBindingContainer().getRegionContainer() == null)
      {
         //add bindingcontainer to datacontrol so that
         //on release this dc removes the data references from
         //binding container and it's containees.
         mDC.addBindingContainer(this.getBindingContainer());
      }
   }


   private String resolveViewObjectName()
   {
      String voName = getVOName();
      if (DCUtil.isElExpr(voName))
      {
         ViewObject vo = getViewObject();
         return (vo != null) ? createAbsoluteVOName(vo.getFullName()) : getVOName();
      }
      return voName;
   }

   private String createAbsoluteVOName(String name)
   {
      //sjvtodo add root.
      return name;
   }

   protected void fetchAttributeProperties()
   {
      DCDataControl dc = getDataControl();
      if (dc != null && (dc.isClientTier() || dc.syncNeeded())) 
      {
         ApplicationModule am = dc.getApplicationModule();
         if (am != null && mValueBindingList != null)
         {
            String[] attrNames;
            ArrayList al = new ArrayList();
            for (int i = 0; i < mValueBindingList.size(); i++)
            {
               attrNames = ((oracle.jbo.uicli.binding.JUCtrlValueBinding)
                                  mValueBindingList.get(i)).getAttributeNames();
               if (attrNames != null)
               {
                  for (int j = 0; j < attrNames.length; j++)
                  {
                     if (!al.contains(attrNames[j]))
                     {
                        al.add(attrNames[j]);
                     }
                  }
               }
            }
            String[][] names = (al.size() > 0) ? new String[][] {(String[])al.toArray(new String[al.size()])} : null;
            //find the VO here so that parameterized VO names are bound right.
            //otherwise we end up with expressions as VOName.
            String voName = resolveViewObjectName();
            if (voName != null)
            {
               DCBindingContainer form = getBindingContainer();
               if (form != null)
               {
                  am.fetchAttributeProperties(new String[] {voName}, names, form.getLocaleContext());
               }
               else if (mDC != null)
               {
                  am.fetchAttributeProperties(new String[] {voName}, names, mDC.getLocaleContext());
               }
               else
               {
                  am.fetchAttributeProperties(new String[] {voName}, names, am.getSession().getLocaleContext());
               }
            }
         }
      }
   }

   //
   // VALUE binding mgmt
   //

   /**
   * Returns a list of DCCtrlValueBinding objects that are associated with this iterator binding.
   * Returns null if no control binding is registered with this object.
   */
   public ArrayList getValueBindingList()
   {
      return (ArrayList)((mValueBindingList != null) ? mValueBindingList.clone() : null);
   }

   /**
   * Adds the given control binding object to its list.
   */
   public void addValueBinding(DCControlBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mValueBindingList == null)
         {
            mValueBindingList = new ArrayList(4);
         }

         if (bnd.needsEstimatedRowCount())
         {
            mNeedsEstimatedRC = true;
         }

         mValueBindingList.add(bnd);
      }
   }

   /**
   * Removes the given control binding object from its list. Returns
   * true if remove was successful.
   */
   public boolean removeValueBinding(DCControlBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mValueBindingList == null)
         {
            return false;
         }

         return mValueBindingList.remove(bnd);
      }
   }


   //
   // ACTION binding mgmt
   //

   /**
   * Returns a list of DCCtrlActionBinding objects that are associated with this iterator binding.
   * Returns null if no action control binding is registered with this object.
   */
   public ArrayList getActionBindingList()
   {
      return (ArrayList)((mActionBindingList != null) ? mActionBindingList.clone() : null);
   }


   /**
   * Adds the given action control binding object to its list.
   */
   public void addActionBinding(DCControlBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mActionBindingList == null)
         {
            mActionBindingList = new ArrayList(4);
         }
         DCIteratorBinding iter = bnd.getDCIteratorBinding();
         if (iter != this)
         {
            if (iter != null)
            {
               iter.removeActionBinding(bnd);
            }
            bnd.setDCIteratorBinding(this);
         }

         mActionBindingList.add(bnd);
      }
   }

   public void removeCurrentRow()
   {
      NavigatableRowIterator rsi = getNavigatableRowIterator();
      if (rsi != null)
      {
         boolean findMode = isFindMode();
         if (!findMode && mCreatedRowRef != null)
         {
            if (mCreatedRowRef != null)
            {
               releaseCachedRow();
            }
            rowDeleted(new oracle.jbo.DeleteEvent(rsi, mCreatedRowRef, -1, -1, -1));
            return;
         }

         if (!isRefreshed())
         {
            this.refreshIfNeeded();
         }

         rsi.removeCurrentRow();
         if (findMode)
         {
            DCDataControl dc = getDataControl();
            if (dc.syncNeeded())
            {
               //this forces dataControl to reapply view criteria.
               dc.getViewCriteria(this);
            }
         }
      }
   }

   /**
   * Removes the given action control binding object from its list. Returns
   * true if remove was successful.
   */
   public boolean removeActionBinding(DCControlBinding bnd)
   {
      synchronized(getSyncLock())
      {
         if (mActionBindingList == null)
         {
            return false;
         }

         return mActionBindingList.remove(bnd);
      }
   }

   /**
   * @internal *** For internal framework use only ***
   */
   public RowSetIterator getLovRowSetIterator()
   {
      if (mRSIName == null)
      {
         mRSIName = getName();
      }
      return getRowSetIterator();
   }

   //do we need another version of release that will also "remove" the ViewObjet/RSIs?
   public void release()
   {
      release(DCDataControl.REL_ALL_REFS);
   }

   public void releaseData()
   {
      getDataControl().releaseData(this);
   }

   protected void releaseDataInternal()
   {
      //release cached row before resetting the RSI pointers.
      if (mCreatedRowRef != null)
      {
         releaseCachedRow();
      }

      List al = getDependents();
      if (al != null) 
      {
         al = (List)((ArrayList)al).clone();
         Object l;
         for (int i = 0; i < al.size(); i++) 
         {
            if ((l = al.get(i)) instanceof DCExecutableBinding) 
            {
               if (l instanceof DCIteratorBinding)
               {
                  // jrs 5677549 -- be sure to release the dependent
                  // DCIteratorBinding *before* we remove it from the
                  // executable list.  If we don't do this then we may get
                  // memory leak because the dependent iterator release
                  // depends upon the RSI of the master binding (this).
                  // if the dependent release occurs after this release
                  // (the master release) has been executed then it won't 
                  // be able to access the RSI.  See JUAccexxorIteratorDef.
                  // MyIteratorBinding.releaseDataInternal() to see how
                  // the dependent iterator depends upon its master's state.
                  ((DCIteratorBinding)l).releaseDataInternal();
               }
               removeDependentExecutable((DCExecutableBinding)l);
            }
         }
      }
      bindRowSetIterator(null, false);
      mAM = null;
      mVO = null;
      mRSI = null;
      mOldRSI = null;
      mVC = null;
      mErrExc = null;
      mRowNotPrepared = true;

      //this lets initSourceRSI to recreate the RSI on demand.
      mIsAlive = false;
      mFindMode = false;
      mAllowFindMode = true;
   }

   /**
   * @internal *** For internal framework use only ***
   */
   public void invalidateCache()
   {
      NavigatableRowIterator rsi = mRSI;
      ViewObject vo = getViewObject();

      release(DCDataControl.REL_DATA_REFS);

      if (vo != null)
      {
         vo.clearCache();
      }
      else if (rsi != null && (rsi instanceof RowSetIterator))
      {
         ((RowSetIterator)rsi).closeRowSetIterator();
      }
   }

   public void release(int flags)
   {
      ArrayList al;
      if (mValueBindingList != null)
      {
         al = (ArrayList)mValueBindingList.clone();
         DCControlBinding ctrl;
         for (int i = 0; i < al.size(); i++)
         {
            ctrl = (DCControlBinding)al.get(i);
            ctrl.release(flags);
         }
      }

      if (mActionBindingList != null)
      {
         al = (ArrayList)mActionBindingList.clone();
         DCControlBinding ctrl;
         for (int i = 0; i < al.size(); i++)
         {
            ctrl = (DCControlBinding)al.get(i);
            ctrl.release(flags);
         }
      }


      if ((flags & DCDataControl.REL_DATA_REFS) > 0)
      {
         bindRowSetIterator(null, false);
         releaseDataInternal();
      }
      else if ((flags & DCDataControl.REL_WEAK_DATA_REFS) > 0)
      {
         // From DCBindingContainer where this was originally implemented.
         // This fix depends upon row set events being re-enabled by
         // refreshControl.
         //
         // JRS 3284980 Suspend row set events handling for all other binding
         // containers.  This assumes that the other binding containers are not
         // active and will refresh themselves once activated.
         //
         // In JClient this may not completely work.  I suppose that a JPanel
         // could contain control bindings/iterator bindings that are in
         // different binding containers.  In this scenario an execute on one
         // binding container may refresh the RSI that is shared between the two
         // iterator bindings in separate containers but the iterator binding/
         // control binding in the binding container on which execute was *not*
         // invoked would not get notified of the refresh.
         //
         // There are a number of potential further fixes.  One is to make the
         // execute service more global and to have it operate on all binding
         // containers.  This would resolve the issue mentinoed above.
         //
         // Another fix would be to share iterator bindings between the
         // containers (i.e. one-to-one between iterator binding and rsi).
         // This has been discussed for other reasons concerning range sizes.
         // If we agree to share iterator bindings then this code could go.
         //
         // See guava.batchmode.js01 for regression.
         //
         // JRS Moved to release.  endRequest/release processing should suspend
         // the request BC's IBs event handling.  Next refreshControl will only
         // restore the current BC's IBs event handling.
         suspendRowSetEventsHandling(true);

         //remove reference to createRowRef.
         //datacontrol reference will get cleanedout in datacontrol's endRequest()
         //by now the validationToken of this iterator should contain
         //the new row key.
         if (mCreatedRowRef != null)
         {
            mCreatedRowRef = null;
         }
      }

      if (flags == DCDataControl.REL_ALL_REFS)
      {

         mValueBindingList = null;
         mActionBindingList = null;

      }
      super.release(flags);
   }

   /**
   * @internal *** For internal framework use only ***
   */
   void validateCurrentRow()
   {
      if (getNavigatableRowIterator().getCurrentRowSlot() == RowSetIterator.SLOT_VALID)
      {
         if (!isRefreshed())
         {
            this.refreshIfNeeded();
         }
         try
         {
            getNavigatableRowIterator().getCurrentRow().validate();
         }
         catch (JboException e)
         {
            //need to convert exception into vo layer exceptions
            mErrExc = e;
            reportException(false, mErrExc);
         }
         catch (Exception e)
         {
            mErrExc = new JboException(e);
            reportException(false, mErrExc);
         }
      }
   }

   /**
    * @deprecated use processInputException(JboException);
    */
   public void processInputException()
   {
      processInputException (mErrExc);
   }

   /**
   * @internal *** For internal framework use only ***
    * Applications should not use this method.
   */
   public void processInputException(JboException errExc)
   {
      Object exSrc = errExc.getSource();
      if (exSrc instanceof RowSetIterator)
      {
         RowSetIterator rsi = (RowSetIterator)exSrc;
         if (getRowSetIterator() != null && !rsi.getName().equals(getRowSetIterator().getName()))
         {
            return;
         }
      }

      if (errExc instanceof ValidationException && mValueBindingList != null)
      {
         ValidationException rve = (ValidationException)errExc;
         ArrayList ctrls = mValueBindingList;
         for (int i = 0; i < ctrls.size(); i++)
         {
            ((DCControlBinding)ctrls.get(i)).processInputException(rve);
         }
      }
      else
      {
         mErrExc = errExc;
      }
      if (getDataControl() != null) 
      {
         getDataControl().addBindingWithExc(getFullName());
      }
   }

   /**
   * @internal *** For internal framework use only ***
   * Applications should not use this method.
    *
   */
   public JboException getError()
   {
      return mErrExc;
   }

   /**
   * @internal *** For internal framework use only ***
   */
   final String getFullName()
   {
      StringBuffer sBuff = new StringBuffer();

      sBuff.append(BindingContext.CONTEXT_ID)
            .append(DCUtil.SEP_DOT_CHAR)
            .append(getBindingContainer().getName())
            .append(DCUtil.SEP_DOT_CHAR)
            .append(getName());

      return sBuff.toString();
   }


   /**
    * get all attribute defs for the RSI that this iterator binding is bound to.
   **@javabean.property
    */
   public AttributeDef[] getAttributeDefs()
   {
      if (mDC != null && mDC.getApplicationModule() != null)
      {
         refreshIfNeeded();
         if (getViewObject() != null)
         {
            return getViewObject().getAttributeDefs();
         }
      }
      if (mDC instanceof oracle.adf.model.generic.DCGenericDataControl)
      {
         return ((oracle.adf.model.generic.DCGenericDataControl)mDC).getAttributeDefs(this, null);
      }
      RowSetIterator rsi = getRowSetIterator();
      if (rsi instanceof oracle.adf.model.generic.DCRowSetIteratorImpl)
      {
         return ((oracle.adf.model.generic.DCRowSetIteratorImpl)getRowSetIterator()).getStructureDef().getAttributeDefs();
      }
      if(Diagnostic.isOn())
      {
         Diagnostic.println("No ViewObject or Generic RowSetIterator found for this binding");
      }
      return null;
   }

   public String getIteratorDefName()
   {
      if (mDC != null && mDC.getApplicationModule() != null && getViewObject() != null)
      {
         return getViewObject().getDefFullName();
      }
      RowSetIterator rsi = getRowSetIterator();
      if (rsi instanceof oracle.adf.model.generic.DCRowSetIteratorImpl)
      {
         return ((oracle.adf.model.generic.StructureDefImpl)
         ((oracle.adf.model.generic.DCRowSetIteratorImpl)getRowSetIterator()).getStructureDef()).getBeanClassName();
      }
      return null;
   }

   /**
    * return attribute defs for attributes that are named in the given array.
    * If this array is null, return only those attribute defs that are
    * not marked with control hint of hide. To get all attributes, use
    * DCIteratorBinding.getAttributeDefs()
    *
    */
   public AttributeDef[] getAttributeDefs(String[] attrNames)
   {
      ViewObject vo = getViewObject();
      if(vo instanceof java.lang.reflect.Proxy)
      {
         ViewObject wsvo = null;
         oracle.jbo.common.ws.WSProxy wspro = (oracle.jbo.common.ws.WSProxy)(java.lang.reflect.Proxy.getInvocationHandler(vo));
         wsvo = wspro.getWSViewObject();
         vo = wsvo;
      }

      AttributeDef attrs[] = null;
      DCBindingContainer ctr= getBindingContainer();
      oracle.jbo.LocaleContext lCtx = (ctr != null) ? ctr.getLocaleContext() : null;
      if (vo == null)
      {
         attrs = getDataControl().getAttributeDefs(this, attrNames);
         if (attrNames == null && attrs != null)
         {
            //if AttributeNames is null then only return displayable attributes.
            ArrayList al = new ArrayList(attrs.length);
            for (int i = 0; i < attrs.length; i++)
            {
               if(!AttributeHints.ATTRIBUTE_DISPLAY_HINT_HIDE.equals
                  (attrs[i].getUIHelper().getDisplayHint(lCtx)))
               {
                  al.add(attrs[i]);
               }
            }
            attrs = (AttributeDef[]) (al.toArray(new AttributeDef[al.size()]));
         }
      }
      else
      {
         refreshIfNeeded();
         if (attrNames == null)
         {
            AttributeDef[] voAttrs = vo.getAttributeDefs();
            ArrayList al = new ArrayList(voAttrs.length);
            int kind = 0;

            //if AttributeNames is null then only return displayable attributes.
            for (int i = 0; i < voAttrs.length; i++)
            {
               kind = voAttrs[i].getAttributeKind();
               if (kind == AttributeDef.ATTR_ASSOCIATED_ROW
                   || kind == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR)
               {
                  continue;
               }

               if(!AttributeHints.ATTRIBUTE_DISPLAY_HINT_HIDE.equals
                  (voAttrs[i].getUIHelper().getDisplayHint(lCtx)))
               {
                  al.add(voAttrs[i]);
               }
            }

            attrs = (AttributeDef[]) (al.toArray(new AttributeDef[al.size()]));
         }
         else
         {
            attrs = new AttributeDef[attrNames.length];
            for (int j = 0; j < attrNames.length; j++)
            {
               attrs[j] = vo.findAttributeDef(attrNames[j]);
            }
         }
      }
      return attrs;
   }

   /*
    * Methods for el-access to range variables - rangestart/size/currentindex
    */

   /**
    * Returns current rowsetiterator's range size
    *
    * @javabean.property
    */
   public int getRangeSize()
   {
      return (hasRSI()) ? getRowSetIterator().getRangeSize() : mRangeSize;
   }

   /**
    * Set current rowsetiterator's range size
    */
   public void setRangeSize(int val)
   {
      mRangeSize = val;
      if (/*hasRSI() && */val != RANGESIZE_DO_NOT_OVERRIDE)
      {
         setRangeSizeForRSI(getRowSetIterator(), val);
      }
   }

   void setRangeSizeForRSI(RowSetIterator rsi, int rangeSize)
   {
      if (rsi == null)
      {
         return;
      }
      // JRS 3323415 Request the estimated row count here since
      // the range size change will result in a query re-execution
      DCDataControl dc = getDataControl();
      if (dc != null && dc.syncNeeded() && needsEstimatedRowCount())
      {
         if(rsi instanceof java.lang.reflect.Proxy)
         {
            RowSetIterator wsvo = null;
            oracle.jbo.common.ws.WSProxy wspro = (oracle.jbo.common.ws.WSProxy)(java.lang.reflect.Proxy.getInvocationHandler(rsi));
            wsvo = wspro.getInternalRowSetIter();
            rsi = wsvo;
         }

         WSRowSet rs = (WSRowSet)rsi.getRowSet();
         if (rs != null)
         {
            rs.requestEstimatedRowCount();
         }
      }

      if (rsi.getRangeSize() != rangeSize)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Changing iterator range size from :"+rsi.getRangeSize()+" to :"+rangeSize);
         }
         rsi.setRangeSize(rangeSize);
      }
   }

   /**
    * Returns current rowsetiterator's range start
    *
    * @javabean.property
    */
   public int getRangeStart()
   {
      return (hasRSI()) ? getRowSetIterator().getRangeStart() : 0;
   }

   /**
    * Set current rowsetiterator's range start
    */
   public void setRangeStart(int val)
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      getRowSetIterator().setRangeStart(val);
   }

   /**
    * Returns current row index in the current Range in the Rowsetiterator
    *
    */
   public int getCurrentRowIndexInRange()
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      RowIterator rsi = getNavigatableRowIterator();
      int curIdx = rsi.getCurrentRowIndex();
      if (curIdx > -1)
      {
         return curIdx - getRangeStart();
      }
      return -1;
   }

   /**
    **
    * @javabean.method
    *
    * Returns current row at the given range Index in the Rowsetiterator
    */
   public void setCurrentRowIndexInRange(int val)
   {
      getNavigatableRowIterator().setCurrentRowAtRangeIndex(val);
   }

   /**
    * Find the row in the associated row iterator based on the value for a key attribute and if found
    * set that as the current row. This method only works for cases where there's one key attribute
    * on the collection.
    *
    * @param stringKeyValue String form of the Key object created using Key.toStringFormat(true/false)
    */
   public void setCurrentRowWithKeyValue(String stringKeyValue)
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      if (stringKeyValue != null)
      {
         getDataControl().setCurrentRowWithKeyValue(this, stringKeyValue);
      }
      else
      {
         Diagnostic.println("** Warning! NoOp in setCurrentRowWithKeyValue as the string key is null!");
      }
   }
   
   /**
    * Returns String version of the row key for the current row in the associated iterator.
    * This key string can be used in setCurrentRowWithKey(). This method will return null
    * if there is no current row in the associated iterator.
    */
    
   public String getCurrentRowWithKeyValue()
   {
      return getCurrentRowKeyString();
   }

   /**
    * Returns String version of the row key for the current row in the associated iterator.
    * This key string can be used in setCurrentRowWithKey(). This method will return null
    * if there is no current row in the associated iterator.
    */
   public String getCurrentRowKeyString()
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      Row r = getCurrentRow();
      if (r != null)
      {
         return r.getKey().toStringFormat(true);
      }
      return null;
   }

   /**
    * Given the key string, convert it to a Key using the associated
    * RowSetIterator's StructureDef.
    */
   public Key createKey(String stringKey)
   {
      if (stringKey != null)
      {
         RowSetIterator rsi = (RowSetIterator)((mFindMode) ? mOldRSI : mRSI);
         if (rsi != null)
         {
            if (rsi instanceof oracle.adf.model.generic.DCRowSetIteratorImpl)
            {
               return ((oracle.adf.model.generic.DCRowSetIteratorImpl)rsi).createKey(stringKey);
            }
            else
            {
               oracle.jbo.RowSet rowset = rsi.getRowSet();
               if (rowset != null)
               {
                  try
                  {
                     return new Key(stringKey, rowset.getViewObject().getKeyAttributeDefs());
                  }
                  catch (Exception e)
                  {
                     if (Diagnostic.isOn())
                     {
                        Diagnostic.printStackTrace(e);
                     }
                  }
               }
            }
         }
      }
      return null;
   }

   /**
    * Find the row in the associated row iterator based on the Key object and if found
    * set that as the current row.
    * @param stringKey String form of the Key object created using Key.toStringFormat(true/false)
    *
    * @javabean.method
    * @javabean.param
    *    name = "stringKey"
    */
   public void setCurrentRowWithKey(String stringKey)
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      if (stringKey != null)
      {
         getDataControl().setCurrentRowWithKey(this, stringKey);
      }
      else
      {
         Diagnostic.println("** Warning! NoOp in setCurrentRowWithKey as the string key is null!");
      }
   }

   /**
    * Find a row with the given key in the current row iterator and if one found, remove it.
    * If more than one row is found, throw a TooMayObjectsException.
    * Otherwise this method is a no-op.
    *
    * @javabean.method
    *    name = "removeRowWithKey"
    * @javabean.param
    *    name = "stringKey"
    */
   public void removeRowWithKey(String stringKey)
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      if (stringKey != null)
      {
         RowIterator ri = this.getNavigatableRowIterator();
         Row rows [] = ri.findByKey(createKey(stringKey), -1);
         if (rows != null && rows.length > 0)
         {
            if (rows.length == 1)
            {
               rows[0].remove();
            }
            else
            {
               throw new oracle.jbo.InvalidOperException(ADFmMessageBundle.class,
                                                         ADFmMessageBundle.EXC_TOO_MANY_ROWS_FOR_REMOVE,
                                                         new Object[]{stringKey, getName()});
            }
         }
      }
      else
      {
         Diagnostic.println("** Warning! NoOp in removeCurrentRowWithKeyValue as the string key is null!");
      }
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   **/
   protected void setAlive(boolean flag)
   {
      mIsAlive = flag;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   **/
   public boolean isAlive()
   {
      return mIsAlive;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   **/
   public final boolean isBound()
   {
      return mIsBound;
   }

   /**
   * @javabean.property
   */
   public long getEstimatedRowCount()
   {
      if (!isRefreshed())
      {
         this.refreshIfNeeded();
      }
      if (isFindMode())
      {
         RowIterator ri = getNavigatableRowIterator();
         return (ri != null) ? ri.getRowCount() : 0;
      }

      //if RSI exists, the operation to get to it has been 
      //executed, so getEstimatedRowCount should succeed.
      //For method returned VOs, this enables updating the
      //table displays with right dataset.
      if (!hasRSI() && getDef() != null && !getDef().isRefreshable(getBindingContainer(), 
                                                     this, 
                                                     DCExecutableBindingDef.RC_DEFAULT))
      {
         return 0;
      }

      return getDataControl().getEstimatedRowCount(this);
   }

   /**
    * Sets the sort critiera that will be applied next time when the
    * source for this iteratorBinding is executed.
    */
   public void applySortCriteria(SortCriteria[] sortby)
   {
      if (isSortable()) 
      {
         mSC = sortby;
         if (mSC != null)
         {
            getDataControl().applySortCriteria(this, sortby);
         }
      }
      else if (Diagnostic.isOn()) 
      {
         Diagnostic.println("Warning! Sorting is disabled for IteratorBinding :"+getName());
      }
   }

   /**
    * Returns an ordered array of SortCriteria that will be applied when
    * the source for this iteratorBinding is executed.
    */
   public SortCriteria[] getSortCriteria()
   {
      if (mSC == null)
      {
         mSC = getDataControl().getSortCriteria(this);
      }
      if (mSC == null)
      {
         mSC = new SortCriteria[0];
      }
      return mSC;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean isSortable()
   {
      return ((getDef() == null || getDef().isSortable())
              && isOperationSupported(DCDataControl.OPER_SORT_COLLECTION));
   }

   /**
    * View layer bindings may consult this to find out if an attribute
    * in this iteratorBinding is sortable or not.
    */
   public boolean isAttributeSortable(AttributeDef ad)
   {
      DCDataControl dc = getDataControl();
      return (isSortable() && dc != null && dc.isAttributeSortable(this, ad));
   }

   public boolean isOperationSupported(byte oper)
   {
      return (getDataControl() != null) ? getDataControl().isOperationSupported(this, oper) : false;
   }

   private ApplicationModule getApplicationModule()
   {
      if (mAM == null)
      {
         mAM = getDataControl().getApplicationModule();
      }
      return mAM;
   }

   void setupFindMode()
   {
      mFindMode = true;
      NavigatableRowIterator iter = getNavigatableRowIterator();
      if (iter != mRSI && !(mRSI instanceof ViewCriteria)) 
      {
         mOldRSI = mRSI;
      }
      if (iter != null)
      {
         if (iter.getRowCount() == 0)
         {
            try
            {
               Row newRow = iter.createRow();
               if (newRow != null)
               {
                  iter.insertRow(newRow);
               }
            }
            catch (InvalidOperException ioe)
            {
               if (getDataControl().syncNeeded())
               {
                  //ignore this. This means we're in sync=batch mode
                  //and the view critieria will have no rows in it.
                  //A workaround would be to add one row in it in the findAction
                  //if no rows are found (after sync).
                  //But this will have to be done in controller code or somehow
                  //managed in refreshControl() in web apps, as the button action
                  //is long gone before the ViewCritiera is ready to create/insert
                  //a new row.
                  oracle.jbo.common.Diagnostic.println("Warning! Setting find mode in the startup. You will need to create a new findmode row");
               }
               else
               {
                  throw ioe;
               }
            }
         }
         else if (iter.getCurrentRow() == null)
         {
            iter.first();
         }
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public void internalReserveCurrentRow()
   {
      //Used by JUCtrlValueBinding to reserve current row in iterators before values
      //are updated in setInputValue.
      if (mReservedRow == null)
      {
         mReservedRow = getCurrentRow();
      }
   }

   void releaseCurrentRow()
   {
      mReservedRow = null;
   }

   String getPathToRootContainer()
   {
      StringBuffer buf = new StringBuffer();
      DCBindingContainer bnd = getBindingContainer();
      while (bnd.getRegionContainer() != null)
      {
         buf.insert(0, new StringBuffer(bnd.getName()).append('.'));
         bnd = bnd.getRegionContainer();
      }
      buf.append(getName());
      return buf.toString();
   }


   static final String FIND_MODE_INDICATOR_DATA = "-D-"; //nonls
   static final String FIND_MODE_INDICATOR_NA   = "-N-"; //nonls
   static final String FIND_MODE_INDICATOR_FIND = "-F-"; //nonls
   static final int    FIND_MODE_INDICATOR_LENGTH = FIND_MODE_INDICATOR_DATA.length();

   static final String CREATED_ROW_INDICATOR = "%C%"; //nonls
   static final int    CREATED_ROW_INDICATOR_LENGTH = CREATED_ROW_INDICATOR.length();
   void buildFormToken(StringBuffer buffer, boolean tokenValEnabled)
   {
      //we do not need to build token for unexecuted iterators.
      if (mTokenDisabled || !mIsAlive || !isBound())
      {
         return;
      }

      if (isFindMode())
      {
         //append the fact that this binding is in find mode.
         buffer.append(getName()).append('=').append(FIND_MODE_INDICATOR_FIND).append(DCBindingContainerState.STATE_TOKEN_DELIMITER);
      }
      else
      {
         buffer.append(getName()).append('=');
         if (isFindModeAllowed())
         {
            buffer.append(FIND_MODE_INDICATOR_DATA);
         }
         else
         {
            buffer.append(FIND_MODE_INDICATOR_NA);
         }

         //consult the iteratorDef if this iteratorbinding needs to be validated for currency.
         //if not, then only for findmode or for created row it adds itself to the token.
         tokenValEnabled = (tokenValEnabled && (getDef() != null && getDef().isStateValidationEnabled()));

         //build token only when there is an rsi already created for this iterator-binding.
         //gvcustomdc sv05
         if ((tokenValEnabled || mCreatedRowRef != null) && hasRSI())
         {
            Row row = null;
            NavigatableRowIterator iter = getNavigatableRowIterator();
            if (mCreatedRowRef != null || (iter != null && iter.getCurrentRowIndex() > -1))
            {
               row = getCurrentRow();
            }
            //sync has occurred and this row has a valid handle now.
            if(row != null && row.getKey() != null)
            {
               String sKey = (mCreatedRowRef == null)
                           ? row.getKey().toStringFormat(false)
                           : mCreatedRowRef.getKey().toStringFormat(true);

               if (mCreatedRowRef != null)
               {
                  buffer.append(CREATED_ROW_INDICATOR);
               }
               buffer.append(sKey);
            }
         }
         //end token for this iteratorbinding.
         buffer.append(DCBindingContainerState.STATE_TOKEN_DELIMITER);
      }
   }

   String parseKeyValue(String sKeyValue)
   {
      if (sKeyValue.length() > DCIteratorBinding.FIND_MODE_INDICATOR_LENGTH)
      {
         sKeyValue = sKeyValue.substring(DCIteratorBinding.FIND_MODE_INDICATOR_LENGTH);
         if (sKeyValue.length() != 0)
         {
            if (sKeyValue.indexOf(DCIteratorBinding.CREATED_ROW_INDICATOR) == 0)
            {
               sKeyValue = sKeyValue.substring(DCIteratorBinding.CREATED_ROW_INDICATOR_LENGTH);
            }
         }
      }
      return sKeyValue;
   }

   boolean processFormToken(String sKeyValue, Map map)
   {

      if (sKeyValue.indexOf(FIND_MODE_INDICATOR_FIND) == 0)
      {
         RowSetIterator rsi = getRowSetIterator();
         if (rsi != null) //this will recreate the RSI/VO/etc.
         {
            setupFindMode();
         }
      }
      else
      {
         RowSetIterator rsi = hasRSI() ? getRowSetIterator() : null;
         if (sKeyValue.indexOf(FIND_MODE_INDICATOR_NA) == 0)
         {
            setAllowFindMode(false);
         }
         sKeyValue = sKeyValue.substring(FIND_MODE_INDICATOR_LENGTH);
         if (sKeyValue.length() == 0)
         {
            return true;
         }

         Key k;
         Row row;
         if (sKeyValue.indexOf(CREATED_ROW_INDICATOR) == 0)
         {
            //force deferred refresh if needed since we need the rsi to get the
            //current row resolved.
            if (rsi == null)
            {
               refreshIfNeeded();
               rsi = getRowSetIterator();
            }
            sKeyValue = sKeyValue.substring(CREATED_ROW_INDICATOR_LENGTH);
            try
            {
               k = new Key(sKeyValue, rsi.getRowSet().getViewObject().getKeyAttributeDefs());
            }
            catch (Exception ex)
            {
               ex.printStackTrace();
               return false;
            }

            Row rows[] = rsi.findByKey(k, 1);
            if (rows.length != 1)
            {
               return false;
            }
            map.put(this, rows[0]);
            /*
            row = rows[0];
            rsi.insertRow(row);
            row.setNewRowState(Row.STATUS_NEW);
            if (mCreatedRowRef != null)
            {
               releaseCachedRow();
            }
            */
         }
         else
         {
            //processing another token means I'd loose my created row
            //if I had any.
            if (Diagnostic.isOn())
            {
               if (mCreatedRowRef != null)
               {
                  Diagnostic.println("Warning! New/Created row on this iterator will now be lost!");
               }
            }
            if (mCreatedRowRef != null)
            {
               releaseCachedRow();
            }
            
            //force an rsi to be created as it was there when this token
            //was built.
            if (!hasRSI()) 
            {
               //refreshIfNeeded won't work here as the binding
               //may not be refreshable at this time.
               getNavigatableRowIterator();
            }
            row  = getCurrentRow();
            if (row == null)
            {
               return false;
            }

            k = row.getKey();
            if (k == null)
            {
               return false;
            }

            if (!k.toStringFormat(false).equals(sKeyValue))
            {
               return false;
            }
         }
      }
      return true;
   }


   void findAndInsertNewRow(Row row)
   {
      RowSetIterator rsi = getRowSetIterator();
      rsi.insertRow(row);
      row.setNewRowState(Row.STATUS_NEW);

      //this should be the only place where we make an unprotected call to releaseCachedRow
      //so that even if my createdRowRef is null, I end up cleaning the ref. from datacontrol.
      releaseCachedRow();
   }

   void insertCreatedRow()
   {
      if (mCreatedRowRef != null)
      {
         Row row = mCreatedRowRef;

         releaseCachedRow();

         RowSetIterator rsi = getRowSetIterator();
         rsi.insertRow(row);
         row.setNewRowState(Row.STATUS_NEW);
      }
   }

   protected void cacheCreatedRow(RowSetIterator rsi, Row row)
   {
      this.mCreatedRowRef = row;
      getDataControl().setTransientCreatedRowObject(getCachedRSIName(rsi), row);
      //set dependents to refreshed= false so that they are refreshed due
      //to change in current row as far as this iterator binding is concerned.
      resetDependentsRefresh();
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   private final String getCachedRSIName(RowSetIterator rsi)
   {
      oracle.jbo.RowSet rs = rsi.getRowSet();
      return (new StringBuffer()
                            .append(rs.getViewObject().getFullName())
                            .append('_')
                            .append(rs.getName())
                            .append('_')
                            .append(rsi.getName())).toString();
   }

   private void releaseCachedRow()
   {
      mCreatedRowRef = null;
      DCDataControl dc = getDataControl();
      if (dc != null)
      {
         if (hasRSI() && dc.getTransientCreatedRowObjects()  != null)
         {
            dc.releaseTransientCreatedRowObject(getCachedRSIName(getRowSetIterator()));
         }
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public int getExecutableType()
   {
      return DCIExecutable.EXECUTABLE_ITERATORBINDING;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void refresh(int id)
   {
      if (id == DCExecutableBindingDef.RC_DEFER)
      {
         //if bindingcontainer not in ondemand mode as well
         //if that's the case that means bindingcontainer
         //is being refreshed and we do  not need sync here.
         if (getBindingContainer().getTransientRefreshFlag() != id)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Executing and syncing on IteratorBinding.refresh from :"+getName());
            }

            boolean syncNeeded = (getDataControl().syncNeeded());
            try
            {
               //only in case of refreshControl()
               //release iterator current row state so that it gets rebuilt
               //in updatemodel/prepareForInput.
               releaseCurrentRow();

               //enable events handling as this binding container is being refreshed.
               if (syncNeeded)
               {
                  suspendRowSetEventsHandling(true);
               }

               if (!isFindMode())
               {
                  //set this for every bindingContainer.refreshControl(),
                  //as each page may have it's own setting.
                  //--- modified --- this logic use the larger of the two range size settings!

                  if (mRangeSize != RANGESIZE_DO_NOT_OVERRIDE)
                  {
                     //iter.resolveRangeSize(iter.getRowSetIterator().getRangeSize());
                     //force my range size over what's set so that I see only
                     //the number of rows I'm interested in
                     setRangeSize(mRangeSize);
                  }

                  //makes sure I have a valid RSI that can be executed.
                  getRowSetIterator();

                  //iterator is referred in the subsequent panels, we need to
                  //execute only if not executed.
                  executeQueryIfNeeded();
               }
               else
               {
                  getViewCriteria();
               }

               if (syncNeeded)
               {
                  fetchAttributeProperties();
                  getDataControl().syncIfNeeded("DCIteratorBinding.refresh(DEFER)");
               }
            }
            finally
            {
               if (syncNeeded)
               {
                  suspendRowSetEventsHandling(false);
               }
            }

            if (isRefreshed())
            {
               return;
            }
         }
      }
      else if (id == DCExecutableBindingDef.RC_DEFAULT)
      {
         if (!hasRSI()) 
         {
            //force an RSI before refreshControl
            //as allowsRefreshControl checks for it's existence
            //in method iterator case.
            getNavigatableRowIterator();
         }
      }
      refreshControl();
   }


   public boolean hasRefreshParametersChanged()
   {
      return true;
   }

   public DCIExecutableDef getExecutableDef()
   {
      return getDef();
   }

   //these are public apis accessible via spel.
   static final String GET_Def  = "Def";        //NONLS
   static final String GET_Name = "Name";       //NONLS
   static final String GET_AllRowsInRange = "allRowsInRange";       //NONLS
   static final String GET_CurrentRow = "currentRow";       //NONLS
   static final String GET_CurrentRowKeyString = "currentRowKeyString";       //NONLS
   static final String GET_EstimatedRowCount = "estimatedRowCount";       //NONLS
   static final String GET_NavigatableRowIterator = "navigatableRowIterator";       //NONLS
   static final String GET_RowSetIterator = "rowSetIterator";       //NONLS
   static final String GET_RangeSize = "rangeSize";       //NONLS
   static final String GET_RangeStart = "rangeStart";       //NONLS
   static final String GET_BindingContainer = "bindingContainer";       //NONLS
   static final String GET_FindMode = "findMode";       //NONLS
   static final String GET_ViewObject = "viewObject";       //NONLS

   protected Object internalGet(String key)
   {
      key = key.intern();
      Object ret = null;

      //now check for getters accessible via EL
      if (key == GET_Name)
      {
         mInternalGet_KeyResolved = true;
         return getName();
      }
      else if (key == GET_Def)
      {
         mInternalGet_KeyResolved = true;
         return getExecutableDef();
      }
      else if (key == GET_AllRowsInRange)
      {
         mInternalGet_KeyResolved = true;
         return getAllRowsInRange();
      }
      else if (key == GET_CurrentRow)
      {
         mInternalGet_KeyResolved = true;
         return getCurrentRow();
      }
      else if (key == GET_CurrentRowKeyString)
      {
         mInternalGet_KeyResolved = true;
         return getCurrentRowKeyString();
      }
      else if (key == GET_EstimatedRowCount)
      {
         mInternalGet_KeyResolved = true;
         return new Long(getEstimatedRowCount());
      }
      else if (key == GET_NavigatableRowIterator)
      {
         mInternalGet_KeyResolved = true;
         return getNavigatableRowIterator();
      }
      else if (key == GET_RowSetIterator)
      {
         mInternalGet_KeyResolved = true;
         return getRowSetIterator();
      }
      else if (key == GET_RangeSize)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getRangeSize());
      }
      else if (key == GET_RangeStart)
      {
         mInternalGet_KeyResolved = true;
         return new Integer(getRangeStart());
      }
      else if (key == GET_BindingContainer)
      {
         mInternalGet_KeyResolved = true;
         return getBindingContainer();
      }
      else if (key == "hasCriteriaData") //only for testing purposes.
      {
         mInternalGet_KeyResolved = true;
         if (getViewCriteria() != null)
         {
            if (getViewCriteria().getRowCount() > 0)
            {
               return new Boolean(((oracle.jbo.ViewCriteriaRow)(getViewCriteria().first())).hasData());
            }
         }
         return Boolean.FALSE;
      }
      else if (key == GET_FindMode)
      {
         // JRS 3/28/2005 Added the following because of problems that the
         // JavaBean introspector was having evaluating the findMode
         // property in the linux environment.  Why is this not an issue
         // on windows.  BC4J diagnostics reported that JDK was 1.4.
         //
         // Please see me before removing this change.
         mInternalGet_KeyResolved = true;
         return new Boolean(isFindMode());
      }
      else if (key == GET_ViewObject)
      {
         mInternalGet_KeyResolved = true;
         return getViewObject();
      }

      return super.internalGet(key);
   }

   public String getPermissionTargetName()
   {
       StringBuffer strBuf = new StringBuffer();

      //check for alive iteratorBindings to avoid exceptions in isOperationEnabled calls from NavBar
      //in closed Apps after the AM is disconnected, but UI is still going down. gvbatch sv19
      if (mDC != null && mDC.getApplicationModule() != null && isAlive() && getViewObject() != null)
      {
	 strBuf.append(mDC.getName()).append('.');
	 strBuf.append( getViewObject().getName());
	 return strBuf.toString();
      }

      if (mSourceName == null && mName.equals("variables")) //NOTRANS
      {
	 if (getBindingContainer() != null)
         {
            return getBindingContainer().getDef().getFullName();
         }
      }

      if (mDC != null)
      {  
	 strBuf.append(mDC.getName());

         if (mSourceName != null && mSourceName.endsWith(".result")) //NOTRANS
	 {
            strBuf.append('.').append(mSourceName.substring(0, mSourceName.lastIndexOf('.')));
         }
	 else if (mSourceName != null && !mSourceName.equals("root")) //NOTRANS
	 {
            strBuf.append('.').append(mSourceName);
	 }
	 return strBuf.toString();
      }

      return mSourceName;
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.ROWSET_PERMISSION);
      }
      return mPermissionInfo;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected void disableTokenValidation()
   {
      mTokenDisabled = true;
   }

   public void setRefreshed(boolean flag)
   {
      boolean wasRefreshed = isRefreshed();
      super.setRefreshed(flag);

      if (!wasRefreshed && flag)
      {
         DCIteratorBindingDef def = getDef();

         if (def != null && !def.isCacheResults())
         {
            releaseData();
         }
      }
   }
}
