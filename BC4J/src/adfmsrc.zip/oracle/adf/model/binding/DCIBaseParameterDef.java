package oracle.adf.model.binding;

interface DCIBaseParameterDef
{
   /**
    * Binding definition has the expression to get to the value that should be used for this parameter.
    */
   public final static int PARAM_FINAL    = 1; 
   
   /**
    * Binding definition's value is used only if the parameter is not specifically set by the caller.
    * This is the default.
    */
   public final static int PARAM_OPTIONAL = 2; 
   
   /**
    * Parameter value has to be set by the caller.
    */
   public final static int PARAM_MANDATORY = 3;
   

   /**
    * For internal use only.
    */
   public final static int PARAM_DEFAULT = PARAM_OPTIONAL;

   /**
    * Return true if a value for this parameter has to be passed in in the usage of this parameter's container.
    */
   boolean isMandatory();


   boolean isOptional();

   /**
    * A usage cannot override this parameter expression.
    */
   boolean isFinal();
}

