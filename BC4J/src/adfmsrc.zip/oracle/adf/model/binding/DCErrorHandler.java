/*
 * @(#)DCErrorHandler.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

/**
 * Implements reporting of all ADF exceptions raised in the context
 * of a DCBindingContainer.
 * <p>
 * Applications could customize exception reporting in JClient by implementing
 * this interface and providing a custom implementation to display/handle ADF exception 
 * including BC4J and JClient exceptions in case of an application using those layers.
 * <p>
 * By default DCErrorHandlerThrow implements this interface and throws all
 * exceptions as a JboException which is a generic Java runtime exception and base
 * class for all ADF exceptions.
 * <p>
 * For generated applications from wizards, the wizards generate a call
 * to set DCErrorHandlerDialog as the default error handler so that all exceptions
 * are displayed in an error dialog.
 *
 * @see oracle.jbo.JboException
 * @see oracle.jbo.uicli.binding.JUErrorHandlerThrow
 * @see oracle.jbo.uicli.jui.JUErrorHandlerDialog
 */
public interface DCErrorHandler
{
   /**
   * Implements how to handle the given exception raised within the JClient framework
   * in the context of the given form binding.
   */
   public void reportException(DCBindingContainer formBnd, Exception ex);
}
