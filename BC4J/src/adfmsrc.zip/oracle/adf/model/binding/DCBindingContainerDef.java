/*
 * @(#)DCBindingContainerDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oracle.binding.ControlBinding;
import oracle.binding.OperationBinding;

import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.RegionController;
import oracle.adf.model.layout.DCLayoutConsDef;
import oracle.adf.model.layout.DCLayoutDef;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Variable;
import oracle.jbo.VariableManager;
import oracle.jbo.VariableManagerOwner;
import oracle.jbo.VariableValueManager;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.mom.xml.ElementDefElement;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.VariableImpl;
import oracle.jbo.common.VariableValueManagerImpl;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DCBindingContainerDef extends DCExecutableBindingDef
       implements VariableManagerOwner
{
   protected DCLayoutDef mLayoutDef;
   protected String mFormClassName;
   protected String mBindingContainerClassName = DCBindingContainer.class.getName();
   protected DefPersistable mOuter = null;
   protected String     mPackage;


   protected DCBindingContainerDef mParentDef;
   protected ArrayList mExecutables = new ArrayList(5);
   protected ArrayList mIterators   = new ArrayList(5);
   protected ArrayList mControls    = new ArrayList(10);
   protected boolean    mFindMode = false;               // the default for find mode is false
   protected boolean    mEnableTokenValidation = true;
   private   String     mViewable;
   protected String     msgBundleClassName;
   protected String     mControllerClassName;
   protected String     mActionProcessorClassName;
   private   ArrayList mParameters = new ArrayList(3);

   public static final String PNAME_TYPE = "DCContainer";                          //NONLS
   public static final String PNAME_FormClass = "ViewClass";                       //NONLS
   public static final String PNAME_BindingContainerClass = "BindingClass";        //NONLS
   public static final String PNAME_Package = "Package";                           //NONLS
   public static final String PNAME_FindMode = "FindMode";                         //NONLS
   public static final String PNAME_Viewable      = "viewable";                    //NONLS
   public static final String PNAME_EnableTokenValidation = "EnableTokenValidation"; //NONLS
   public static final String PNAME_MsgBundleClass = "MsgBundleClass";            //NONLS

   protected ArrayList mValidators;

   // made this public since I need to create a new one during design time. JO
   public DCBindingContainerDef()
   {
   }


   protected DCBindingContainerDef(DefPersistable outer)
   {
      mOuter = outer;
   }

   protected DCBindingContainerDef(DCLayoutDef layoutDef, String formClassName, String formBindingClassName)
   {
      setLayoutDef(layoutDef);

      mFormClassName = formClassName;
      mBindingContainerClassName = formBindingClassName;
   }


   public void init(HashMap initValues)
   {
      super.init(initValues);

      Object val;
      if ((val = initValues.get(PNAME_FormClass)) != null)
      {
         mFormClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_BindingContainerClass)) != null)
      {
         mBindingContainerClassName = val.toString();
      }

      if ((val = initValues.get(PNAME_Package)) != null)
      {
         mPackage = val.toString();
      }

      if ((val = initValues.get(PNAME_FindMode)) != null)
      {
         mFindMode = val.toString().equalsIgnoreCase("true");
      }
      if ((val = initValues.get(PNAME_EnableTokenValidation)) != null)
      {
         mEnableTokenValidation = val.toString().equalsIgnoreCase("true");
      }

      if ( (val = initValues.get(PNAME_MsgBundleClass)) != null )
      {
          msgBundleClassName = val.toString();
      }

      if ( (val = initValues.get(JUTags.ControllerClassName)) != null )
      {
          mControllerClassName = val.toString();
      }

      if ( (val = initValues.get(JUTags.ActionProcessorClassName)) != null )
      {
          mActionProcessorClassName = val.toString();
      }

      if ( (val = initValues.get(PNAME_Viewable)) != null )
      {
          mViewable = val.toString();
      }

    }


   static public DCBindingContainerDef findDefObjectNoSub(String name)
   {
      return (DCBindingContainerDef) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_FORM_BINDING,
                                           DCBindingContainerDef.class,
                                           false /*sub*/);
   }


   static public DCBindingContainerDef findDefObject(String name)
   {
      return (DCBindingContainerDef) JUMetaObjectManager.getJUMom().findDefinitionObject(name,
                                           JUMetaObjectBase.TYP_DEF_FORM_BINDING,
                                           DCBindingContainerDef.class,
                                           true /*sub*/);
   }

   public String getFullName()
   {
      if (mOuter != null)
      {
         return mOuter.getFullName();
      }
      else
      {
         return super.getFullName();
      }
   }

   public void setBindingContainerDef(DCBindingContainerDef def)
   {
      //setParent def.
      mParentDef = def;
   }


   /**
    * Return true if the bindingContainer instances should start in findMode.
    */
   public boolean getFindMode()
   {
      return mFindMode;
   }
   public boolean isTokenValidationEnabled()
   {
      return mEnableTokenValidation;
   }

   public String getFormClassName()
   {
      return mFormClassName;
   }


   public void setFormClassName(String formClassName)
   {
      mFormClassName = formClassName;
   }

   public final String getMessageBundleClassName()
   {
      return msgBundleClassName;
   }

   public final String getControllerClassName()
   {
      return mControllerClassName;
   }

   public final String getActionProcessorClassName()
   {
      return mActionProcessorClassName;
   }

   public String getBindingContainerClassName()
   {
      return mBindingContainerClassName;
   }

   public String getViewableString()
   {
      return mViewable;
   }

   public String getPackage()
   {
      return mPackage;
   }

   public void setPackage(String sValue)
   {
      mPackage = sValue;
   }

   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public DCLayoutDef getLayoutDef()
   {
      return mLayoutDef;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setLayoutDef(DCLayoutDef layoutDef)
   {
      mLayoutDef = layoutDef;

      if (layoutDef != null)
      {
         layoutDef.setBindingContainerDef(this);
      }
   }


   void createIterBindings(DCBindingContainer formBnd, BindingContext ctx, ApplicationModule anchorAM)
   {
      for (int j = 0; j < mIterators.size(); j++)
      {
         DCIteratorBindingDef iterDef = (DCIteratorBindingDef) mIterators.get(j);
         DCIteratorBinding iterBnd = iterDef.createIterBinding(ctx, formBnd, anchorAM);
         iterBnd.setDef(iterDef);
         formBnd.addIteratorBinding(iterDef.getName(), iterBnd);
      }
   }

   private void createExecutables(DCBindingContainer formBnd, BindingContext ctx)
   {
      DCIExecutableDef  exec;
      DCIExecutable     execBinding;
      DCIteratorBinding iterBnd;
      int type;
      Object bindingObj;
      for (int i = 0; i < mExecutables.size(); i++)
      {
         exec = (DCIExecutableDef)mExecutables.get(i);
         bindingObj = exec.createExecutableBinding(ctx, formBnd);
         if (bindingObj instanceof DCIExecutable)
         {
            execBinding = (DCIExecutable)bindingObj;
         }
         else
         {
            execBinding = adaptExecutableBinding(exec.getName(), bindingObj);
            execBinding.setExecutableDef(exec);
         }

         type = exec.getExecutableType();
         if (type == EXECUTABLE_ITERATORBINDING)
         {
            DCIteratorBindingDef iterDef = (DCIteratorBindingDef) exec;
            iterBnd = (DCIteratorBinding)execBinding;
            formBnd.addIteratorBinding(iterDef.getName(), iterBnd);
         }
         else
         {
            formBnd.addExecutableBinding(execBinding);
         }
      }
   }

   private void createParameters(DCBindingContainer formBnd, BindingContext ctx)
   {
      for (int j = 0; j < mParameters.size(); j++)
      {
         DCControlBindingDef controlDef = (DCControlBindingDef) mParameters.get(j);
         DCParameter controlBnd = (DCParameter)controlDef.createControlBinding(formBnd);
         formBnd.addParameter(controlBnd, controlDef.getName());
      }
      //these are not currently wired up to be UI controls. But they could be.
      //formBnd.initializeViewComponent(mParameters);
   }


   //for use by generic DCDataControl to create iterbindings for RSIs that they
   //get on their own.

   //this used to be public in 1012 but was not intended for use as public api.
   void createIterBindings(DCDataControl dc, DCBindingContainer formBnd)
   {
      DCIteratorBindingDef iterDef;
      DCIteratorBinding iter;
      for (int j = 0; j < mIterators.size(); j++)
      {
         iterDef = (DCIteratorBindingDef) mIterators.get(j);
         //iter = iterDef.createIterBinding((RowSetIterator)dc.findRowSetIterator(iterDef));
         //iter = iterDef.createIterBinding((RowSetIterator)dc.getRowSetIterator());
         iter = iterDef.createIterBinding(dc.getBindingContext(), formBnd);
         iter.setDef(iterDef);
         formBnd.addIteratorBinding(iterDef.getName(), iter);
      }
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public ArrayList createControls(DCBindingContainer formBnd)
   {
      ArrayList retArr = null;

      for (int j = 0; j < mControls.size(); j++)
      {
         if (retArr == null)
         {
            retArr = new ArrayList(mControls.size());
         }

         DCControlBindingDef controlDef = (DCControlBindingDef) mControls.get(j);
         DCControlBinding controlBnd = controlDef.createControlBinding(formBnd);

         formBnd.addControlBinding(controlDef.getName(), controlBnd);

         retArr.add(controlBnd);
      }

      if (retArr == null)
      {
         retArr = new ArrayList(1);
      }

      return retArr;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   DCBindingContainer createBindingContainer(DCDataControl app, boolean initialize)
   {
      DCBindingContainer formBnd = app.createBindingContainerInstance(mBindingContainerClassName);
      formBnd.setDef(this);
      //formBnd.setName(generateInstanceName(app.getBindingContext(), formBnd));
      formBnd.setApplicationModule(app.getApplicationModule());
      if (getFindMode())
      {
         //by default bindingContainer is created in data mode.
         formBnd.setFindMode(true);
      }

      formBnd.setEnableTokenValidation(isTokenValidationEnabled());

      return formBnd;
   }


   /**
    * @deprecated since 10.1.3. Use createBindingContainer(BindingContext ctx, DCBindingContainer parent, String name) 
    * instead.
    */
   public DCBindingContainer createBindingContainer(BindingContext ctx)
   {
      return createBindingContainer(ctx, null, null);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public DCBindingContainer createBindingContainer(BindingContext ctx, DCBindingContainer parent, String name)
   {
      DCBindingContainer formBnd = (DCBindingContainer) DCUtil.createNewInstance(mBindingContainerClassName);
      formBnd.setDef(this);
      formBnd.setName(name);
      formBnd.setBindingContext(ctx);
      formBnd.setRegionContainer (parent);
      createParameters(formBnd, ctx);
      createExecutables(formBnd, ctx);
      ArrayList controls = createControls(formBnd);
      formBnd.initializeViewComponent(controls);
      if (getFindMode())
      {
         //by default bindingContainer is created in data mode.
         formBnd.setFindMode(true);
      }

      formBnd.setEnableTokenValidation(isTokenValidationEnabled());
      //formBnd.setRefreshOption(getRefreshOption());
      //formBnd.setRefreshExpression(getRefreshExpression());

      return formBnd;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public DCBindingContainer createBindingContainer(ApplicationModule anchorAM)
   {
      DCBindingContainer formBnd = (DCBindingContainer) DCUtil.createNewInstance(mBindingContainerClassName);
      formBnd.setDef(this);

      initializeBindingContainer(formBnd, anchorAM);
      if (getFindMode())
      {
         //by default bindingContainer is created in data mode.
         formBnd.setFindMode(true);
      }

      formBnd.setEnableTokenValidation(isTokenValidationEnabled());
      //formBnd.setRefreshOption(getRefreshOption());
      //formBnd.setRefreshExpression(getRefreshExpression());

      return formBnd;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Object createExecutableBinding(BindingContext ctx, DCBindingContainer formBnd)
   {
      return createBindingContainer(ctx, formBnd, null);
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void initializeBindingContainer(DCBindingContainer formBnd, ApplicationModule anchorAM)
   {
      formBnd.setApplicationModule(anchorAM);
      createIterBindings(formBnd, formBnd.getBindingContext(), anchorAM);

      if (mFormClassName != null)
      {
         Object panel = DCUtil.createNewInstance(mFormClassName);
         formBnd.setViewComponentInternal(panel);
      }

      ArrayList controls = createControls(formBnd);
      formBnd.initializeViewComponent(controls);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void initializeBindingContainer(DCDataControl dc, DCBindingContainer formBnd, boolean initialize)
   {
      createIterBindings(dc, formBnd);
      if (formBnd.getDataControl().isJClientApp())
      {
         formBnd.setViewComponentInternal(DCUtil.createNewInstance(mFormClassName));
      }
      if (initialize)
      {
         ArrayList array = createControls(formBnd);
         if (formBnd.getDataControl().isJClientApp())
         {
            formBnd.initializeViewComponent(array);
         }
      }
   }

   public ArrayList getIterators()
   {
      return mIterators;
   }


   public void addIterator(DCIteratorBindingDef iter)
   {
      if (!mIterators.contains(iter))
      {
         mIterators.add(iter);
      }
      if (!mExecutables.contains(iter))
      {
         mExecutables.add(iter);
      }

      iter.setBindingContainerDef(this);
   }


   public ArrayList getControlDefs()
   {
      return mControls;
   }

   public DCControlBindingDef getControlDef(String name)
   {
      int size = mControls.size();
      DCControlBindingDef def;
      for (--size; size >= 0; size--)
      {
         def = (DCControlBindingDef)mControls.get(size);
         if (def.getName().equals(name))
         {
           return def;
         }
      }
      return null;
   }


   public void addControlDef(DCControlBindingDef control)
   {
      mControls.add(control);

      control.setBindingContainerDef(this);
   }


   public void addControlDef(DCControlBindingDef control, DCLayoutConsDef layoutCons)
   {
      addControlDef(control);

      control.setLayoutCons(layoutCons);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);

      readXMLString(xmlElement, PNAME_FormClass, valueTab);
      readXMLString(xmlElement, PNAME_BindingContainerClass, valueTab);
      readXMLString(xmlElement, PNAME_Package, valueTab);
      readXMLBoolean(xmlElement, PNAME_FindMode, valueTab);
      readXMLBoolean(xmlElement, PNAME_EnableTokenValidation, valueTab);
      readXMLString(xmlElement, PNAME_MsgBundleClass, valueTab);
      readXMLString(xmlElement, JUTags.ControllerClassName, valueTab);
      readXMLString(xmlElement, JUTags.ActionProcessorClassName, valueTab);
      readXMLString(xmlElement, PNAME_Viewable, valueTab);
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);

      loadLayoutDef(xmlElement);
      loadParameterDefs(xmlElement);
      loadVariables(xmlElement);
      loadExecutables(xmlElement);
      loadControlDefs(xmlElement);
      loadContainerValidationRules(xmlElement);
   }

   void loadContainerValidationRules(DefElement xmlElement)
   {
      ArrayList al = DCValidationListenersUtil.loadValidationListenersFromXML(xmlElement);
      if (al.size() > 0)
      {
         mValidators = al;
      }
   }


   void loadLayoutDef(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList layouts = xmlElement.getChildrenList(DCLayoutDef.PNAME_TYPE);

      if (layouts.size() > 0)
      {
         DefElement layoutXML = (DefElement) layouts.get(0);
         DCLayoutDef layout = (DCLayoutDef) DCDefBase.createAndLoadFromXML(layoutXML, null);

         setLayoutDef(layout);
      }
   }


   void loadExecutables(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList iters = xmlElement.getSimilarChildrenList(DCIteratorBindingDef.PNAME_TYPE);

      ArrayList defIters = new ArrayList(iters.size());
      ArrayList accIters = null;
      for (int j = 0; j < iters.size(); j++)
      {
         DefElement iterXML = (DefElement) iters.get(j);
         DCIteratorBindingDef iter = (DCIteratorBindingDef) DCDefBase.createAndLoadFromXML(iterXML, DCDefBase.PNAME_Iterator);
         iter.setBindingContainerDef(this);

         if (iter.isAccessorType())
         {
            if (accIters == null)
            {
               accIters = new ArrayList(iters.size());
            }
            accIters.add(iter);
         }
         else
         {
            defIters.add(iter);
            mExecutables.add(iter);
         }
      }

      if (accIters != null)
      {
         defIters.addAll(accIters);
         mExecutables.addAll(accIters);
      }

      // load control definitions inside of the <bindings> element
      DefElement iterators = xmlElement.findChildElement(JUTags.executables);
      if(iterators != null)
      {
         accIters = null;
         DefElement           defElem;
         DCIExecutableDef     exec = null;
         DCIteratorBindingDef iter;

         com.sun.java.util.collections.ArrayList list =
            iterators.getChildrenList();

         int size = list.size();
         for (int i = 0; i < size; i++)
         {
            defElem = (DefElement)list.get(i);
            if (defElem.getLocalName().equals(JUTags.pageDefinitionUsage)) //RF: getLocalName
            {
               DCBindingContainerReference ref = JUMetaObjectManager.loadBindingContainerRef(defElem);
               exec = ref;
               ref.setAliasesMap(loadParameterAliases(defElem));
               HashMap initValues = new HashMap(10);
               ref.retrieveFromXML(defElem, initValues);
               ref.init(initValues);
            }
            else
            {
               exec = (DCIExecutableDef) DCDefBase.createAndLoadFromXML(defElem, null);
               if (exec.getExecutableType() == EXECUTABLE_ITERATORBINDING)
               {
                  iter = (DCIteratorBindingDef)exec;
                  iter.setBindingContainerDef(this);
                  if (iter instanceof oracle.jbo.uicli.binding.JUVariableIteratorDef)
                  {
                     loadVariableValidators(((VariableManagerOwner)iter).getVariableManager(),
                                            defElem);
                  }
                  if (iter.isAccessorType())
                  {
                     if (accIters == null)
                     {
                        accIters = new ArrayList(iters.size());
                     }
                     accIters.add(iter);
                  }
                  else
                  {
                     defIters.add(iter);
                  }
               }
            }
            mExecutables.add(exec);
         }

         if (accIters != null)
         {
            defIters.addAll(accIters);
         }
      }

      //mIterators has some iterators already? variables get in there. what else?
      mIterators.addAll(defIters);
   }


   void loadVariableValidators(VariableManager varmgr, DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList list =
              xmlElement.getChildrenList();

      int size = list.size();
      if (size > 0)
      {
         DefElement[] defElems = new DefElement[size];
         for (int i = 0; i < size; i++)
         {
            defElems[i] = (DefElement)list.get(i);
         }

         Variable[] vars = varmgr.getVariables();
         for (int i = 0; i < vars.length; i++)
         {
            oracle.jbo.rules.RulesBeanUtils.loadValidators(defElems[i], (DCVariableImpl)vars[i], getMessageBundleClass()) ;
         }
      }
   }

   HashMap loadParameterAliases(DefElement xmlElement)
   {
      //load ReferenceMap.
      HashMap map = null;
      com.sun.java.util.collections.ArrayList list =
         xmlElement.getChildrenList();

      if (list.size() > 0)
      {
         DefElement aliases = (DefElement)list.get(0);

         com.sun.java.util.collections.ArrayList children =
            aliases.getChildrenList();

         int size = children.size();
         if (size > 0)
         {
            map = new HashMap(size);
            for ( int i=0; i < size; i++ )
            {
               DefElement elem = (DefElement)children.get(i);

               map.put(elem.getAttribute(JUTags._NAME),
                       elem.getAttribute(JUTags.VALUE));
            }
         }
      }
      return map;
   }

   void loadControlDefs(DefElement xmlElement)
   {
      com.sun.java.util.collections.ArrayList controls = xmlElement.getChildrenList(DCControlBindingDef.PNAME_TYPE);

      for (int j = 0; j < controls.size(); j++)
      {
         DefElement controlXML = (DefElement) controls.get(j);
         DCControlBindingDef control = (DCControlBindingDef) DCDefBase.createAndLoadFromXML(controlXML, null);

         addControlDef(control);
         control.loadCustomDef(controlXML);
      }

      // load control definitions inside of the <bindings> element
      DefElement bindings = xmlElement.findChildElement("bindings");
      if(bindings != null)
      {
         com.sun.java.util.collections.ArrayList list =
            bindings.getChildrenList();

         int size = list.size();
         for (int i = 0; i < size; i++)
         {
            DefElement elem = (DefElement)list.get(i);

            DCControlBindingDef control =
               (DCControlBindingDef)DCDefBase.createAndLoadFromXML(elem, null);

            addControlDef(control);
            control.loadCustomDef(elem);
         }
      }
   }

   /**
   * Loads the information about page parameters to the Def
   */
   void loadParameterDefs(DefElement xmlElement)
   {
      // load control definitions inside of the <bindings> element
      DefElement bindings = xmlElement.findChildElement(JUTags.parameters);
      if(bindings != null)
      {
         com.sun.java.util.collections.ArrayList list =
            bindings.getChildrenList();

         int size = list.size();
         for (int i = 0; i < size; i++)
         {
            DefElement elem = (DefElement)list.get(i);

            DCControlBindingDef control =
               (DCControlBindingDef)DCDefBase.createAndLoadFromXML(elem, null);
            control.setBindingContainerDef(this);
            mParameters.add(control);
         }
      }
   }

   /**
    * Returns the parameterSet of all parameters to the page/region
    */
   public ArrayList getParameterDefs()
   {
      return (ArrayList)mParameters.clone();
   }

   public DCControlBindingDef getParameterDef(String name)
   {
      int size = mParameters.size();
      DCControlBindingDef def;
      for (--size; size >= 0; size--)
      {
         def = (DCControlBindingDef)mParameters.get(size);
         if (def.getName().equals(name))
         {
           return def;
         }
      }
      return null;
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public DCControlBindingDef createControlDef(HashMap initValues)
   {
      return null;  // Don't know how to create control defs
   }

   public int getExecutableType()
   {
      return EXECUTABLE_REGION;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Returns the class of the reference object.
    * @return the class of the reference object.
   */
   public final Class getMessageBundleClass()
   {
      try
      {
         return JBOClass.forName(getMessageBundleClassName());
      }
      catch (Exception e)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("Ignoring exception on loading Message bundle for :"+getName());
         }
      }
      return null;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected void loadVariables(DefElement xmlElement)
   {
      DefElement iterators = xmlElement.findChildElement(JUTags.variables);
      if (iterators != null)
      {
         com.sun.java.util.collections.ArrayList list =
            iterators.getChildrenList();

         int size = list.size();
         if (size > 0)
         {
            DefElement[] defElems = new DefElement[size];
            for (int i = 0; i < size; i++)
            {
               defElems[i] = (DefElement)list.get(i);
            }
            ((VariableValueManagerImpl)ensureVariableManager()).loadFromXML(defElems);
         }
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   protected VariableManagerOwner getVariableManagerOwner()
   {
      Object obj;
      for (int i = 0; i < mIterators.size(); i++)
      {
         obj = mIterators.get(i);
         if (obj.getClass().getName().equals("oracle.jbo.uicli.binding.JUVariableIteratorDef"))
         {
            return ((VariableManagerOwner)obj);
         }
      }
      return null;
   }

   public final VariableValueManager getVariableManager()
   {
      VariableManagerOwner varMgrOwner = getVariableManagerOwner();
      return (varMgrOwner != null) ? varMgrOwner.getVariableManager() : null;
   }

   public final boolean hasVariables()
   {
      return (getVariableManager() != null);
   }

   public VariableValueManager ensureVariableManager()
   {
      //this should be implemented in JU binding as that's
      //where we have Variable IteratorBinding
      //and to avoid import from uicli.binding.
      return null;
   }

   DCIExecutable adaptExecutableBinding(String name, Object obj)
   {
      DCIExecutable adaptedObject = null;
      if (obj instanceof RegionBinding)
      {
         class RegionBindingAdapter extends DCExecutableBinding implements RegionBinding, DCIExecutableAdapter
         {
            static final String GET_ADAPTEE = "adaptee";       //NONLS
            RegionBinding myRegionBinding;
            RegionBindingAdapter (String name, RegionBinding obj)
            {
               setName(name);
               myRegionBinding = obj;
            }
            public int getExecutableType()
            {
               return DCIExecutable.EXECUTABLE_REGION;
            }
            public Object getAdaptee()
            {
               return myRegionBinding;
            }

            protected Object internalGet(String key)
            {
               Object ret = null;
               key = key.intern();

               //now check for getters accessible via EL
               if (key == GET_ADAPTEE)
               {
                  mInternalGet_KeyResolved = true;
                  return getAdaptee();
               }
               return super.internalGet(key);
            }
            public void release(int flags)
            {
               myRegionBinding.release(flags);
            }
            public List getRegionBindings()
            {
               return myRegionBinding.getRegionBindings();
            }
            public RegionController getRegionController()
            {
               return myRegionBinding.getRegionController();
            }
            public Object getActionProcessor()
            {
               return myRegionBinding.getActionProcessor();
            }
            public void refresh()
            {
               myRegionBinding.refresh();
            }
            public void refresh(int flag)
            {
               myRegionBinding.refresh(flag);
               setRefreshed(true);
            }
            public ControlBinding getControlBinding(String name)
            {
               return myRegionBinding.getControlBinding(name);
            }
            public OperationBinding getOperationBinding(String name)
            {
               return myRegionBinding.getOperationBinding(name);
            }
            public List getControlBindings()
            {
               return myRegionBinding.getControlBindings();
            }
            public List getAttributeBindings()
            {
               return myRegionBinding.getAttributeBindings();
            }
            public List getOperationBindings()
            {
               return myRegionBinding.getOperationBindings();
            }
            public void validate()
            {
               myRegionBinding.validate();
            }
            public boolean isTokenValidationEnabled()
            {
               return myRegionBinding.isTokenValidationEnabled();
            }
            public void validateToken(String sState)
            {
               myRegionBinding.validateToken(sState);
            }
            public String getStateToken()
            {
               return myRegionBinding.getStateToken();
            }
            public boolean hasRefreshParametersChanged()
            {
               return true;
            }
            public boolean isViewable()
            {
               return myRegionBinding.isViewable();
            }
         }

         adaptedObject = new RegionBindingAdapter(name, (RegionBinding)obj);
      }
      return adaptedObject;
   }

}
