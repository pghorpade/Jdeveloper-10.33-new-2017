/*
 * @(#)PermissionBinding.java
 *
 * Copyright 2003-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.binding;

import java.security.Permission;

import oracle.adf.model.PermissionInfo;
import oracle.adf.model.BindingContext;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;

import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.common.NamedObjectImpl;

import java.util.Map;



public class PermissionBinding extends JboAbstractMap implements PermissionInfo
{
   String          mTarget;
   String          mPermClassName;
   Map             mLabels = null;
   BindingContext  mBindingContext = null;

   private static final String ALLOWS_PREFIX = "allows";//NOTRANS 


   public PermissionBinding(String target, int permType)
   {
      mTarget = target;
      mPermClassName = PermissionHelper.getPermissionClassName(permType);
   }

   public PermissionBinding(String target, int permType, BindingContext ctx)
   {
      this(target, permType);
      mBindingContext = ctx;
   }

   public PermissionBinding(String target, int permType, Map labels)
   {
       this(target, permType);
       mLabels = labels;
   }

   public Object get(String key)
   {
      if (key.startsWith(ALLOWS_PREFIX)) 
      {
         key = key.substring(ALLOWS_PREFIX.length());
      }
      else if (mLabels != null && mLabels.get(key) != null) 
      {
	 StringBuffer sbuf = new StringBuffer(mTarget);
	 sbuf.append(DCUtil.SEP_DOT_CHAR).append(key);
         return new PermissionBinding(sbuf.toString(), PermissionHelper.ATTRIBUTE_PERMISSION);
      }
      else if (mBindingContext != null)
      {
	  Object obj = mBindingContext.get(key);
	  if (obj != null && JboAbstractMap.class.isAssignableFrom(obj.getClass()))
	  {
	     Object permInfo = ((JboAbstractMap)obj).get("permissionInfo"); //NOTRANS
	     if (permInfo != null)
             {
	         return (PermissionInfo)permInfo;
	     }
	  }
      }
      Permission p = (Permission)PermissionHelper.createPermissionInstance(mPermClassName, mTarget, key);
      return new Boolean(PermissionHelper.hasPermission(ADFContext.getCurrent().getSecurityContext(), p));
   }

   public Object get(Object keyObj)
   {
     if (keyObj instanceof String)
     {
        return get((String) keyObj);
     }
     return Boolean.FALSE;
  }
}
