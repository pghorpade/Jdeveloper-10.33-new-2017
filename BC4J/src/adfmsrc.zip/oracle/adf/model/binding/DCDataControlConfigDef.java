package oracle.adf.model.binding;

import java.util.HashMap;
import java.util.List;
import java.util.Iterator;


import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.DefPersistable;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;
import oracle.jbo.uicli.mom.JUTags;

public class DCDataControlConfigDef extends DCDefBase
{
   private HashMap mDataControlDefs = new HashMap(3); 

   protected void loadChildrenFromXML(DefElement xmlElement) 
   {
      com.sun.java.util.collections.Iterator dataControlElements = xmlElement.getChildrenList().iterator();
      while(dataControlElements.hasNext())
      {
         DefElement elem = (DefElement)dataControlElements.next();
         DCDataControlDef dcDef = DCDataControlDef.createDef(elem);
         mDataControlDefs.put(dcDef.getName(), dcDef);
      }
   }

   static DCDataControlConfigDef findDefObject(String defName)
   {
      return (DCDataControlConfigDef)JUMetaObjectManager.getJUMom().findDefinitionObject(defName, 
                                                          JUMetaObjectBase.TYP_DEF_DATACONTROL_CONFIG,
                                                          DCDataControlConfigDef.class,
                                                          true, /* sub */ 
                                                          true /* loadIfNecessary*/);
   }

   static public DCDataControlConfigDef createAndLoadFromXML(DefElement xmlElement)
   {
       DCDataControlConfigDef def = new DCDataControlConfigDef();
       def.loadFromXML(xmlElement);
       return def;
   }

   DCDataControlDef findDataControlDef(String dcDefName)
   {
      return (DCDataControlDef)mDataControlDefs.get(dcDefName);
   }

   public String getXMLElementTag()
   {
      return JUTags.DataControlConfigs;
   }

}

