/*
 * @(#)DCMethodParameterDef.java
 *
 * Copyright 1998-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import oracle.jbo.mom.PropertyNameValueDef;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.JTXMLTags;

import oracle.jbo.Row;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.domain.DataCreationException;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.generic.BeanUtils;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class DCMethodParameterDef extends PropertyNameValueDef implements Serializable, DCIBaseParameterDef, OperationParameter
{
   /**
    * Binding definition has the expression to get to the value that should be used for this parameter.
    */
   public static int PARAM_FINAL    = 1; 
   
   /**
    * Binding definition's value is used only if the parameter is not specifically set by the caller.
    * This is the default.
    */
   public static int PARAM_OPTIONAL = 2; 
   
   /**
    * Parameter value has to be set by the caller.
    */
   public static int PARAM_REQUIRED = 3;
   

   static int DEFAULT = PARAM_OPTIONAL;
   
   private int mOption = DEFAULT;
   private boolean m1012Expr;


   public DCMethodParameterDef ()
   {
      super(true);
   }

   public DCMethodParameterDef ( String name,
                                String type,
                                Object value,
                                int    scope ) 
   {
      super(name, type, value, true);
      mOption = scope;
   }

   public DCMethodParameterDef ( String name,
                                String type,
                                Object value)
   {
      super(name, type, value, true);
   }
   
   public DCMethodParameterDef(DCMethodParameterDef other ) 
   {
      super(other);
      if( other != null )
      {
         mOption = other.mOption;
      }
   }

   DCMethodParameter createParameterInstance(DCBindingContainer bc)
   {
      return new DCMethodParameter(this, bc);
   }

   public int getOption()
   {
      return mOption;
   }

   public void setOption(int scope)
   {
      Diagnostic.println("Setting scope on a method definition :"+scope);
      mOption = scope;
   }

   private void readObject( ObjectInputStream is ) throws
                                           IOException,
                                           ClassNotFoundException
   {
      mOption = is.readInt();
   }

   private void writeObject( ObjectOutputStream os ) throws
                                           IOException
   {
      os.writeInt(mOption);
   }

   public void loadFromXMLFile(DefElement xmlElement)
   {
      super.loadFromXMLFile(xmlElement);
      mOption = xmlElement.readInt("NDOption");
      if (mOption == 0)
      {
         mOption = DEFAULT;
      }
      org.w3c.dom.Node node = xmlElement.getOwnerDocument().getDocumentElement();
      if (node.getNodeName().equals(DCBindingContainerDef.PNAME_TYPE))
      {
         m1012Expr = true;
      }
   }

   public final boolean isFinal()
   {
      return (mOption == PARAM_FINAL);
   }

   public final boolean isOptional()
   {
      return (mOption == PARAM_OPTIONAL);
   }

   public final boolean isMandatory()
   {
      return (mOption == PARAM_REQUIRED);
   }

   /**
    * @deprecated since 10.1.3
    */
   public final boolean isParamFinal()
   {
      return isFinal();
   }

   /**
    * @deprecated since 10.1.3
    */
   public final boolean isParamRequired()
   {
      return isMandatory();
   }

   static Object resolveParameterValue(DCMethodParameterDef def, BindingContext ctx, DCBindingContainer bctr, Object paramValue)
   {
      boolean goForRow = false;
      //if parameter is final, return the binding context lookup value.
      if (def.isParamFinal())
      {
         if (paramValue != null && Diagnostic.isOn())
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("*** Warning, ignoring parameterValue :"+paramValue+" for "+ def.getName());
            }
            //so that it gets calculated from the expression.
            paramValue = null;
         }
      }
      else
      {
         //if parameter is required, return given parameter value.
         if (def.isParamRequired())
         {
            return TypeFactory.getInstance(def.getTypeName(), paramValue);
         }

         //optional, if parameter not null return that otherwise
         //return binding context lookup value.
         if (paramValue != null) 
         {
            return TypeFactory.getInstance(def.getTypeName(), paramValue);
         }
      }

      if (paramValue == null)
      {
         Object exprObj = def.getValue();
         if (exprObj instanceof String)
         {
            String expr = (String)exprObj;
            if (def.m1012Expr)
            {   
               //1012
               paramValue = DCUtil.findContextObject(ctx, (String)def.getValue());
            }
            //if (DCUtil.isElExpr(expr)) 
            else
            {
               goForRow = true;
               if (bctr != null) 
               {
                  //paramValue = DCUtil.elEvaluate(ctx, bctr, expr);
                  paramValue = bctr.evaluateParameter(expr, true, true);
               }
            
               if (paramValue == null || bctr == null)
               {
                  paramValue = DCUtil.elEvaluate(ctx, ctx, expr);
               }
            }
         }
         else
         {
            paramValue = exprObj;
         }
      }

      try
      {
         return TypeFactory.getInstance(def.getTypeName(), paramValue);
      }
      catch (DataCreationException dce)
      {
         try
         {
            if (goForRow) 
            {
               String expr = (String)def.getValue();
               if (expr.endsWith("Row}")) 
               {
                  //param is a Row and it's not assignable to the requested class. Try dataProvider.
                  Class clz = JBOClass.forName(def.getTypeName());
                  if (paramValue instanceof Row && !Row.class.isAssignableFrom(clz))
                  {
                     if (paramValue instanceof oracle.adf.model.generic.RowImpl) 
                     {
                        Object dataProvider = ((oracle.adf.model.generic.RowImpl)paramValue).getDataProvider();
                        if (clz.isInstance(dataProvider)) 
                        {
                           if (Diagnostic.isOn()) 
                           {
                              Diagnostic.println("Warning! Missing '.dataProvider' in an expression : "+def.getValue());
                              Diagnostic.println("Unwrapping Row into it's dataProvider object before passing it to an operation.");
                           }
                           return dataProvider;
                        }
                     }
                  }
               }
            }
         }
         catch (Throwable e)
         {
         }
         throw dce;
      }
   }
}

