package oracle.adf.model.binding;

/**
 * *** For internal framework use only ***
 * Implemented by RegionBinding, IteratorBinding and ActionReference,
 * the three default executable binding implementations.
 */
interface DCIExecutableAdapter extends DCIExecutable
{
   static final int EXECUTABLE_REGION          = DCIExecutableDef.EXECUTABLE_REGION;
   static final int EXECUTABLE_ITERATORBINDING = DCIExecutableDef.EXECUTABLE_ITERATORBINDING;
   static final int EXECUTABLE_ACTION          = DCIExecutableDef.EXECUTABLE_ACTION;

   Object getAdaptee();
}

