/*
 * @(#)DCUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import oracle.adf.share.el.ADFExpressionEvaluator;
import oracle.adf.share.ADFContext;

import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.BindingContext;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.CustomClassNotFoundException;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboBeanUtils;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.ord.im.OrdDomainIOInterface;
import oracle.ord.im.OrdDomainUtil;
import oracle.ord.im.OrdFileSource;


/**
 * Contains some static utility methods used by the framework.
 */
public class DCUtil extends JboBeanUtils
{
   final static String DATA = BindingContext.CONTEXT_ID;

   public static final String DATA_PREFIX = "VB_";     // Value Binding Prefix
   public static final char SEP_DOT_CHAR = '.';   //NONLS
   public static final char SEP_SLASH_CHAR = '/'; //NONLS
   public static final String DOT = ".";          //NONLS

   public final static String DESIGNTIME_PROPERTY = "inJUIDesigntime";  //NONLS
   /**
   * *** For internal framework use only ***
   */
   static public Class findClass(String className)
   {
      try
      {
         return JBOClass.forName(className);
      }
      catch(Exception e)
      {
         DebugDiagnostic.println("Could not load class: " + className); //NONLS
         DebugDiagnostic.printStackTrace(e);
         throw new CustomClassNotFoundException(className, e);
      }
   }


   /**
   * *** For internal framework use only ***
   */
   static public Object createNewInstance(String className)
   {
      Class cls = findClass(className);

      try
      {
         return cls.newInstance();
      }
      catch(Exception e)
      {
         DebugDiagnostic.println("Could not create an instance: " + className); //NONLS
         DebugDiagnostic.printStackTrace(e);
         throw new CustomClassNotFoundException(className, e);
      }
   }


   /**
   * *** For internal framework use only ***
   */
   static public String generateContainerName(DCBindingContainer formBnd)
   {
      String className = null;
      if (formBnd.getDef() != null)
      {
         className = formBnd.getDef().getName();
      }

      if(className == null)
      {
         Object panel = formBnd.getViewComponent();

         if (panel != null)
         {
            className = panel.getClass().getName();
         }
         else
         {
            className = "noPanel_" + formBnd.getClass().getName(); //NONLS
         }
      }
      return JboNameUtil.getInstNameFromDefName(className);
   }


   /**
   * *** For internal framework use only ***
   */
   static public String generateIteratorName(DCIExecutable iterBnd)
   {
      String className;

      className = iterBnd.getClass().getName();

      return JboNameUtil.getInstNameFromDefName(className);
   }


   /**
   * *** For internal framework use only ***
   */
   static public String generateControlName(DCControlBinding controlBnd)
   {
      String className;
      Object control = controlBnd.getControl();

      if (control != null)
      {
         className = control.getClass().getName();
      }
      else
      {
         className = "noCtrl_" + controlBnd.getClass().getName(); //NONLS
      }

      return JboNameUtil.getInstNameFromDefName(className);
   }


   /**
   * *** For internal framework use only ***
   */
   static public boolean isEmptyString(String s)
   {
      return (s == null || s.equals("")); //NONLS
   }

   public static boolean inDesignTime()
   {
      try
      {
         if (System.getProperty(DESIGNTIME_PROPERTY) != null)
         {
            return true;
         }
      }
      catch(Exception e)
      {
         return false;
      }

      return false;
   }

   /**
    * Replace the dot characters in this dot seperated name with the
    * give seperator. This is a utility method for ADFc to
    * call so that it can convert the dot-seperated spel expression
    * to a single-name string to place on a jsp page and then use
    * this string to execute a model-binding -action like calling
    * invoke method or setInputValue on the binding.
    */
   public static String encodePath(String dotSeperatedName, char sep)
   {
      return dotSeperatedName.replace(SEP_DOT_CHAR, sep);
   }


   /**
    * Replace the 'sep' characters in this name with dots so that
    * the converted name is a spel expression which ADFc
    * would call to execute a method or setInputValue via
    * a control-binding
    */
   public static String decodePath(String encodedString, char sep)
   {
      return encodedString.replace(sep, SEP_DOT_CHAR);
   }

   static final String EL_start = JboBeanUtils.EL_start;
   static final String EL_end = JboBeanUtils.EL_end;
   static final String ELC_start = "${'";
   static final String ELC_end = "'}";
   static final int EL_start_length = EL_start.length();
   static final int EL_end_length = EL_end.length();
   static final int ELC_start_length = ELC_start.length();
   static final int ELC_end_length = ELC_end.length();


   /**
    * If the given expression is to be evaluated as el (has {''} or is a static value, pass true
    * for hasElSyntax.
    */
   public static Object findSpelObject(Object rootObj, String expression, boolean hasElSyntax)
   {
      if (hasElSyntax && expression != null)
      {
         if (isElExpr(expression))
         {
            if (expression.startsWith(ELC_start))
            {
               expression = expression.substring(ELC_start_length, expression.length() - ELC_end_length);
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("Returning constant :"+expression);
               }
               return expression;
            }
            //make it a .separated el expression now
            expression = expression.substring(EL_start_length, expression.length() - EL_end_length);
         }
         else
         {
            //static string. return it as is.
            return expression;
         }
      }

      //.seprated name-expressions or stripped out el-expressions.
      return findSpelObject(rootObj, new StringBuffer(expression), !hasElSyntax);
   }

   /**
    * @deprecated since 10.1.3. use evaluate() or findSpelObject(Object rootObj, String expression, boolean hasElSyntax).
    */
   public static Object findSpelObject(Object rootObj, String expression)
   {
      return findSpelObject(rootObj, new StringBuffer(expression));
   }

   public static Object findSpelObject(Object rootObj, StringBuffer tokenizer)
   {
      return findSpelObject (rootObj, tokenizer, true);
   }

   static Object findSpelObject(Object rootObj, StringBuffer tokenizer, boolean throwEx)
   {
      int index = 0;
      String nextTok;
      Object nextObj = rootObj;
      Object currObj;
      boolean firstObj = true;
      while (nextObj != null && tokenizer.length() > 0 && index != -1)
      {
         currObj = null;

         index = tokenizer.indexOf(DOT);
         nextTok = (index < 0) ? tokenizer.toString() : tokenizer.substring(0, index);

         if (nextObj instanceof java.util.Map)
         {
            currObj = ((java.util.Map)nextObj).get(nextTok);

            if(firstObj && index < 0)
            {
               //trying to get to datacontrol or binding container.
               //deref binding container if so.

               //we could do this implicitly in the BindingContext.get() code
               //too!
               if (currObj instanceof DCBindingContainerReference)
               {
                  currObj = ((DCBindingContainerReference)currObj).getBindingContainer();
               }
            }

            if (currObj == null && nextObj instanceof BindingContext)
            {
               return null;
            }
         }
         if (currObj == null)
         {
            currObj = getProperty(nextObj, nextTok);
            if (currObj == null)
            {
               if (index < 0)
               {
                  return null;
               }
               if (throwEx)
               {
                  throw new JboException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_SPEL_ATTRIBUTE_NOT_RESOLVED, new Object[]{nextTok, nextObj.toString()});
               }
            }
         }
         if (currObj != null)
         {
            tokenizer.delete(0, index+1);
            nextObj = currObj;
         }
         else
         {
            if (throwEx)
            {
               throw new JboException(ADFmMessageBundle.class, ADFmMessageBundle.EXC_SPEL_ATTRIBUTE_NOT_RESOLVED, new Object[]{nextTok, nextObj.toString()});
            }
            nextObj = null;
         }

         firstObj = false;
      }

      if (Diagnostic.isOn())
      {
         if (nextObj != null)
         {
            Diagnostic.println("DCUtil, returning:"+nextObj.getClass().getName()+", for "+tokenizer.toString());  //NONLS
         }
         else
         {
            Diagnostic.println("DCUtil, RETURNING: <null> for "+tokenizer.toString());  //NONLS
         }
      }

      return nextObj;
   }


   static public Object findContextObject(BindingContext ctx, String objFullName)
   {
      if (objFullName == null)
      {
         return null;
      }

      if (objFullName != null && isElExpr(objFullName))
      {
         return elEvaluate(ctx, ctx, objFullName);
      }

      /*
      StringBuffer tokenizer = new StringBuffer(objFullName);
      Object nextObj;
      nextObj = ctx;
      int index;

      index = tokenizer.indexOf(DOT);
      String nextTok = (index < 0) ? tokenizer.toString() : tokenizer.substring(0, index);

      if (DATA.equals(nextTok))
      {
         tokenizer.delete(0, index+1);
         if (index == -1)
         {
            if (DATA.equals(tokenizer.toString()))
            {
               return ctx;
            }
         }
         index = tokenizer.indexOf(DOT);
      }
      return findSpelObject(nextObj, tokenizer, false);
      */
      return findSpelObject(ctx, objFullName, false);
   }

   static public boolean isValueBindingPath(String path)
   {
      return path.startsWith(DATA_PREFIX);
   }

   static public String getValueBindingNameFromPath(String path)
   {
      return path.substring(DATA_PREFIX.length());
   }

   static public JUCtrlValueBinding getValueBinding(BindingContext bctx,
                                                           String path,
                                                           char sep)
   {
      String modelRef = DCUtil.decodePath(path, sep);

      // This should eventually using EL
      modelRef = modelRef.substring(0, modelRef.lastIndexOf(".inputValue"));
      Object dcControl = findContextObject(bctx, modelRef);
      try
      {
         return (JUCtrlValueBinding) dcControl;
      }
      catch (Exception ex)
      {
         return null;
      }
   }


   static public JUCtrlValueBinding getValueBinding(DCBindingContainer bindingContainer, String path)
   {
      try
      {
         if(!isValueBindingPath(path))
            return null;

         String modelRef = getValueBindingNameFromPath(path);

         // This should eventually using EL
        // modelRef = modelRef.substring(0, modelRef.lastIndexOf(".inputValue"));
         Object dcControl = bindingContainer.findCtrlBinding(modelRef);

         return (JUCtrlValueBinding) dcControl;
      }
      catch (Exception ex)
      {
         return null;
      }
   }

   /**
    * Set the value of a AttrsBinding
    */
   static public boolean setBindingValueFromPath(BindingContext bctx,
                                                 String path,
                                                 String value,
                                                 char sep)
   {
      JUCtrlValueBinding binding = getValueBinding(bctx, path, sep);

      if (binding != null)
      {
         binding.setInputValue(value);
         return true;
      }

      return false;
   }

   static public boolean isActionBindingPath(String path)
   {
      return (path.startsWith(DATA) && path.endsWith("invoke"));
   }

   static public JUCtrlActionBinding getActionBinding(BindingContext bctx,
                                                     String path,
                                                     char sep)
   {
      String modelRef = DCUtil.decodePath(path, sep);

      // This should eventually using EL
      modelRef = modelRef.substring(0, modelRef.lastIndexOf(".invoke"));
      Object dcControl = findContextObject(bctx, modelRef);
      try
      {
         return (JUCtrlActionBinding) dcControl;
      }
      catch (Exception ex)
      {
         return null;
      }
   }

   static public void putValueInPath(BindingContext bctx, String path, Object value)
   {
      if (isElExpr(path))
      {
         path = path.substring(EL_start_length, path.length() - EL_end_length);
      }
      String objPath = JboNameUtil.getContainerPartOfName(path);
      String propertyName = JboNameUtil.getLastPartOfName(path);

      Object obj = (objPath != null)
                    ? findContextObject(bctx, objPath)
                    : bctx;

      if (obj != null)
      {
         if (Diagnostic.isOn())
         {
            StringBuffer buf = new StringBuffer("putValueInPath :");
            buf.append(path).append(" = ").append(value);
            Diagnostic.println(buf.toString());
         }
         if (obj instanceof Map)
         {
            ((Map)obj).put(propertyName, value);
         }
         else
         {
            setProperty(obj, propertyName, value);
         }
      }
   }

   static public Object removeValueFromPath(BindingContext bctx, String path)
   {
      if (isElExpr(path))
      {
         path = path.substring(EL_start_length, path.length() - EL_end_length);
      }
      String objPath = JboNameUtil.getContainerPartOfName(path);
      String propertyName = JboNameUtil.getLastPartOfName(path);

      Object obj = (objPath != null)
                    ? findContextObject(bctx, objPath)
                    : bctx;

      Object retVal = null;
      if (obj != null)
      {
         if (Diagnostic.isOn())
         {
            StringBuffer buf = new StringBuffer("removeValueFromPath :");
            buf.append(path);
            Diagnostic.println(buf.toString());
         }
         if (obj instanceof Map)
         {
            retVal = ((Map)obj).remove(propertyName);
         }
         else
         {
            setProperty(obj, propertyName, null);
         }
      }

      return retVal;
   }

   /**
    * Invoke an actionBinding with a list of parameter values
    */
   static public Object invokeActionBindingFromPath(BindingContext bctx,
                                                    String path,
                                                    ArrayList methodParams,
                                                    char sep)
   {
      String modelRef = DCUtil.decodePath(path, sep);

      // This will eventually be replaced by evaluating the EL expression
      modelRef = modelRef.substring(0, modelRef.lastIndexOf(".invoke"));

      return invokeActionBinding(bctx, modelRef, null);
   }

   /**
    * Invoke an actionBinding with a list of parameter values
    */
   static public Object invokeActionBinding(BindingContext bctx,
                                            String modelRef,
                                            ArrayList methodParams)
   {
      Object dcControl = null;

      // Retrieve the actionBinding instance
      dcControl = findContextObject(bctx, modelRef);
      if (dcControl == null)
      {
         return null;
      }

      if (dcControl instanceof JUCtrlActionBinding)
      {
         JUCtrlActionBinding actionBinding = (JUCtrlActionBinding)dcControl;

         if (methodParams != null && methodParams.size() > 0)
         {
            actionBinding.setParams(methodParams);
         }

         actionBinding.invoke();

         return actionBinding.getResult();
      }

      return null;
   }


  /**
   * *** For internal framework use only ***
   */
  public static BindingContext getBindingContext(HttpServletRequest request)
  {
    BindingContext ctx = (BindingContext) request.getSession().getAttribute
      (BindingContext.CONTEXT_ID);
    return ctx;
  }

  /**
   * *** For internal framework use only ***
   */
  public static DCBindingContainer initializeBindingContainer(
   HttpServletRequest request,
   BindingContext ctx,
   String model)
  {
    // find the binding container
    DCBindingContainer container = DCUtil.getBindingContainer(request);
    if(container == null)
    {
      container = findBindingContainer(ctx, model);
      if(container != null)
      {
        setBindingContainer(request, container);
        //container.refreshControl();
      }
    }
    return container;
  }

  /**
   * *** For internal framework use only ***
   */
  public static void setBindingContainer(HttpServletRequest request,
                                         DCBindingContainer container)
  {
    request.setAttribute("bindings", container);
  }

  /**
   * *** For internal framework use only ***
   */
  public static DCBindingContainer getBindingContainer(HttpServletRequest request)
  {
     return (DCBindingContainer) request.getAttribute("bindings");
  }

  public static DCBindingContainer findBindingContainer(BindingContext ctx,
                                                        String model)
  {
    DCBindingContainer bc = null;
    Object obj = findContextObject(ctx, model);
    if (obj instanceof DCBindingContainerReference)
    {
      DCBindingContainerReference formRef = (DCBindingContainerReference)obj;
      bc = formRef.getBindingContainer();
    }
    else if (obj instanceof DCBindingContainer)
    {
      bc = (DCBindingContainer) obj;
    }
    return bc;
  }

  /**
   * Get an interMedia object for an InputStream
   * @param inStream the inputStream to read from
   * @param contentType the mime-type of the stream
   * @param binding the binding for which the interMedia object must be created
   */
  public static OrdDomainIOInterface getOrdObject(InputStream inStream,
                                                  String contentType,
                                                  JUCtrlValueBinding binding)
  {

    AttributeDef      attrDef = binding.getAttributeDef();
    Row               row = binding.getDCIteratorBinding().getCurrentRow();
    ApplicationModule am =
      binding.getDCIteratorBinding().getDataControl().getApplicationModule();

    String sName = attrDef.getName();

    //String filename = file.getFileName();


    String tmpDir = JboEnvUtil.getBC4JTempDir(am);

    try
    {
      //
      // Make a copy of the browser uploaded content to a temp file. Use
      // this temp file for database upload and passivation/activation. The
      // browser uploaded content will be released when the request is
      // complete.
      //
      OrdFileSource tempFile =
        OrdDomainUtil.createTempFile(inStream, contentType, tmpDir);



      OrdDomainIOInterface obj = null;

      // KM: MERGE_TODO 19Oct04 - what should be used in 10.1.3?
      obj = OrdDomainUtil.getOrdObject(attrDef, tempFile, row, am, contentType);

      return obj;
    }
    // regrettably, OrdDomainUtil seems to throw plain-old Exception:
    catch (Exception e)
    {
      throw new JboException(e);
    }
  }

  public static List getLocalizedExceptionsList(List excs, LocaleContext lCtx)
  {
     if (excs != null)
     {
        ArrayList al = new ArrayList(excs.size());
        Object exc;
        JboException jex;
        for (int i = 0; i < excs.size(); i++)
        {
           exc = excs.get(i);
           if (!(exc instanceof JboException))
           {
              jex = new JboException((Exception)exc);
           }
           else
           {
              jex = (JboException)exc;
           }

           //this will cascade this context onto internal JboExceptions.
           jex.setLocaleContext(lCtx);
           al.add(jex);
        }
        excs = al;
     }
     return excs;
  }

   /**
    * If an ADFExpressionEvaluatorFactory is registered in the environment, then
    * use that to fetch a static ADFExpressionEvaluator and run the given expression
    * through it and return the evaluated result.
    * <p>
    * 10.1.2 and earlier applications which are not migrated by designtime should
    * continue to work without starting with '${' and ending with '}' syntax. For 10.1.3 onwards,
    * all expressions should follow the el-expression syntax starting with '${' and ending with '}'.
    *
    * @param context may refer to ADFContext. This may be used to setup a evaluator factory.
    * @param onObject Object on which to run the expression on.
    * @param expression String to Evaluate on the given object.
    */
   static public Object elEvaluate (
      Object context, Object onObject, String expression)
   {
      // try the evaluator first.  if that fails then attempt to use
      // findSpelObject
      Object rtn = null;
      if (context instanceof BindingContext)
      {
         if (onObject != context
            && onObject instanceof DCBindingContainer)
         {
            rtn = ADFContext.getCurrent().getExpressionEvaluator()
               .evaluate(expression, new DCVariableResolverImpl((BindingContext)context
                  , (DCBindingContainer)onObject));
         }
         else
         {
            rtn = ADFContext.getCurrent().getExpressionEvaluator()
               .evaluate(expression, new DCVariableResolverImpl((BindingContext)context));
         }
      }


      if (rtn == null
         && onObject != context
         && onObject instanceof DCBindingContainer
         && context instanceof BindingContext)
      {
         rtn = findSpelObject(context, expression, true);
      }

      if (rtn == null)
      {
         rtn = findSpelObject(onObject, expression, true);
      }

      return rtn;
   }
}
