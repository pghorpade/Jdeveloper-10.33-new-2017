package oracle.adf.model.binding;

import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;
import oracle.adf.model.BindingContext;
import java.util.Map;

/**
 ** @javabean.class name=DCBindingContainerReference
 ** 
 **/
public class DCBindingContainerReference extends DCExecutableBindingDef implements Cloneable, DCIExecutableDef
{
   private String mName;
   private String mFullName;
   private Map mAliasesMap;
   private BindingContext mCtx;
   
   public DCBindingContainerReference(BindingContext ctx, String name, String fullName)
   {
      mName = name;
      mFullName = fullName;
      mCtx = ctx;
   }

   public void setBindingContext(BindingContext ctx)
   {
      mCtx = ctx;
   }

   public DCBindingContainerReference(String name, String fullName)
   {
      this(null, name, fullName);
   }

   /**
    **
    **@javabean.property
    **/
   public DCBindingContainer getBindingContainer()
   {
      //since this will be converted into reference 
      mCtx.remove(mName);
      DCBindingContainer formBnd = createBindingContainer(null);
      mCtx.put(mName, formBnd);
      return formBnd;
   }

   DCBindingContainer createBindingContainer(DCBindingContainer parent)
   {
      try
      {
         DCBindingContainerDef formDef = DCBindingContainerDef.findDefObject(mFullName);
         DCBindingContainer formBnd = formDef.createBindingContainer(mCtx, parent, mName);
         formBnd.setAliasesMap(mAliasesMap);
         formBnd.setRefreshOption(getRefreshOption());
         formBnd.setRefreshExpression(getRefreshExpression());
         return formBnd;
      }
      catch (JboException e)
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("Failed to create BindingContainer from reference :"+getName());
            Diagnostic.printStackTrace(e);
         }
         throw e;
      }
      catch (Exception e)
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("Failed to create BindingContainer from reference :"+getName());
            Diagnostic.printStackTrace(e);
         }
         throw new JboException(e);
      }
   }

   public Object get(Object key)
   {
      DCBindingContainer formBnd = getBindingContainer();
      return formBnd.get(key);
   }

   void setAliasesMap(Map map)
   {
      mAliasesMap = map;
   }

   /**
    **@javabean.property
    **/

   public String getName()
   {
      return mName;
   }

   /**
    **@javabean.property
    **/

   public String getFullName()
   {
      return mFullName;
   }
   
   public String toString()
   {
      return getName()+"_ContainerReference";
   }

   public Object clone() throws CloneNotSupportedException
   {
      return super.clone();
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Object createExecutableBinding(BindingContext ctx, DCBindingContainer ctr)
   {
      mCtx = ctx;
      return createBindingContainer(ctr);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   /*
   public int getRefreshOption()
   {
      return DCExecutableBindingDef.RC_DEFAULT;
   }
   */

   public int getExecutableType()
   {
      return DCExecutableBindingDef.EXECUTABLE_REGION;
   }

   public boolean isRefreshable(DCBindingContainer ctr, DCIExecutable exec, int refreshFlag)
   {
      return true;
   }
}
