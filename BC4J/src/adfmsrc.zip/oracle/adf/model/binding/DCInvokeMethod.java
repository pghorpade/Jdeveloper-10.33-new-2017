
/*
 * @(#)DCInvokeMethod.java
 *
 * Copyright 2003-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.binding;
import java.beans.MethodDescriptor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;

import java.util.Map;
import java.util.ArrayList;

import oracle.jbo.uicli.mom.JUTags;
 
import oracle.adf.model.OperationParameter;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.generic.BeanUtils;
import oracle.adf.model.generic.RowImpl;
import oracle.adf.model.PermissionInfo;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.Exportable;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.Variable;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.VariableValueManagerImpl;
import oracle.jbo.common.Diagnostic;


/**
 * Implements metadata and logic to invoke a custom action binding method.
 * <p>
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * @javabean.class name=DCInvokeMethod
 */
public class DCInvokeMethod implements oracle.adf.model.OperationInfo
{
   boolean mCacheVals;
   Object mVals[];
   DCMethodParameter[] mArgs;
   Method mMethod;
   Constructor mCons;
   DCBindingContainer mBC;
   DCInvokeMethodDef mDef;
   OperationBinding mAction;
   ArrayList mListeners;

   Object mTransientVals[];

   PermissionInfo mPermissionInfo = null;

   DCInvokeMethod(DCInvokeMethodDef def, DCBindingContainer ctr, OperationBinding action)
   {
      mDef = def;
      mBC = ctr;
      mAction = action;
   }

   void initArgs()
   {
      OperationParameter defs[] = mDef.getParameters();
      if (defs != null) 
      {
         mArgs = new DCMethodParameter[defs.length];
         for (int i = 0; i < defs.length; i++) 
         {
            mArgs[i] = ((DCMethodParameterDef)defs[i]).createParameterInstance(mBC);
         }
      }
      else
      {
         mArgs = new DCMethodParameter[0];
      }
   }

   public OperationParameter[] getParameters()
   {
      if (mArgs == null) 
      {
         initArgs();
      }
      return mArgs;
   }

   public boolean hasParameterValuesChanged()
   {
      BindingContext ctx = mBC.getBindingContext();
      boolean valsCompare = true;
      Object newVals[] = null;
      Object cacheVals[] = null;
      
      String paramsCache = getDef().getCachedParamsName(); 
      if (paramsCache != null) 
      {
         //if paramsCache exists.
         int ix = paramsCache.lastIndexOf('.');
         String methodResultsMapName = paramsCache.substring(0, ix);
         String paramsName = paramsCache.substring(ix+1);
         Map map = (Map)DCUtil.findSpelObject(ctx, methodResultsMapName);
         if (map != null && paramsName != null && paramsName.length() > 0) 
         {
            cacheVals = (Object[])map.get(paramsName);
         }

         if (mVals == null && cacheVals == null) 
         {
            //null parameters, check if map contains the parameter
            //entry if so, method has been called with  null.
            return (!map.containsKey(paramsName));
         }
      }
      

      if (cacheVals == null) 
      {
         //if cached values in the dc is null, then see if this
         //invokeaction has cached parameter vals. if so use
         //these as these were cached in an earlier call.
         cacheVals = mVals;
      }

      if (cacheVals != null)
      {
         //get new parameters
         newVals = fetchAndSaveParameterValues(ctx, mAction.getParamsMap(), false); 
         if (newVals != null) 
         {
            if (cacheVals.length == newVals.length) 
            {
               //if parameter lengths are same, compare them one by one.
               Object src, tar;
               int i = cacheVals.length-1;
               for (; i >= 0; --i) 
               {
                  src = cacheVals[i];
                  tar = newVals[i];
                  if (!((src == tar) || (src != null && tar != null && src.equals(tar)))) 
                  {
                     //src does not match tar
                     break;
                  }
               }
               if (i < 0) 
               {
                  //all matched
                  return false;
               }
            }
         }
      }
      else 
      {
         //nothing cached. see if result exists. if not, call the method.
         return (DCUtil.findSpelObject(mAction, "result") == null);
      }

      return true;
   }
   
   /**
    * Internal use only.  Application developers should not extend.
    */
   public Object callMethod (DCDataControl dc, OperationBinding action, Map paramsMap)
   {
      if (mArgs == null) 
      {
         initArgs();
      }
      if (dc == null)
      {
         if (mBC != null)
         {
            dc = mBC.getDataControl();
         }
         if (dc == null)
         {
            throw new UnsupportedOperationException("DCInvokeMethod.null datacontrol");
         }
      }

      try
      {
         BindingContext ctx = dc.getBindingContext();
         mTransientVals = fetchAndSaveParameterValues(ctx, paramsMap, true);
         
         /*
         OperationParameter methodparams[] = getParameters();
         if (methodparams.length > 0) 
         {
            for (int i = 0; i < mTransientVals.length; i++) 
            {
               paramsMap.put(methodparams[i].getName(), mTransientVals[i]);
            }
         }
         */

         boolean txnDirty = dc.isTransactionDirty();
         
         DCInvokeMethodEvent eventObj = null;
         if (mListeners != null) 
         {
            notifyBeforeInvokeMethod((eventObj = new DCInvokeMethodEvent(this, getInvokeInstance(dc, ctx), mTransientVals)));
         }

         Object retVal = dc.invokeMethod(this, action, paramsMap);

         if (txnDirty != dc.isTransactionDirty()) 
         {
            dc.internalSetTransactionStateChanged(!txnDirty);
         }

         if (eventObj != null) 
         {
            notifyAfterInvokeMethod(eventObj);
         }

         return retVal;
      }
      finally
      {
         mTransientVals = null;
      }

   }

   static Object resolveAsExpression(Object bindingContext, Object rootObj, String expression)
   {
      if (!(expression.startsWith(DCUtil.EL_start) && expression.endsWith(DCUtil.EL_end))) 
      {
         //convert by adding elexpression syntax
         expression = (new StringBuffer()
                      .append(DCUtil.EL_start)
                      .append(expression)
                      .append(DCUtil.EL_end))
                      .toString();
      }
      return DCUtil.elEvaluate(bindingContext, rootObj, expression);
   }

  /**
   * For internal framework use only.  Application developers should not use this method.
   */
   public Object[] fetchParameterValues(BindingContext ctx, Map paramsMap)
   {
      return fetchAndSaveParameterValues(ctx, paramsMap, false);
   }

   private Object[] fetchAndSaveParameterValues(BindingContext ctx, Map paramsMap, boolean save)
   {
      if (mArgs == null) 
      {
         initArgs();
      }

      int argsize = (mArgs != null) ? mArgs.length : 0;
      
      Object[] objs = new Object[argsize];
      if (paramsMap == null) 
      {
         paramsMap = new java.util.HashMap(argsize);
      }

      String paramName;
      for (int i = 0; i < argsize; i++)
      {
         paramName = mArgs[i].getName();
         objs[i] = mArgs[i].resolveParameterValue(ctx, paramsMap.get(paramName)); 
         if (save) 
         {
            paramsMap.put(paramName, objs[i]);
         }
      }
      return objs;
   }
   
   /**
    * For internal framework use only.  Application developers should not use this method.
    */
   public Object getInvokeInstance(DCDataControl dc, BindingContext ctx)
   {
      if (ctx == null)
      {
         throw new InvalidObjAccessException("BindingContext", null); //NONLS
      }

      String instanceName = mDef.getInstanceName();
      Object instance = null;
      if (instanceName == null)
      {
         try
         {
            instance = JBOClass.forName(mDef.getClassName());
         }
         catch (Exception e)
         {
            throw new InvalidObjNameException("className", mDef.getClassName());  //NONLS
         }
      }
      else if (!mDef.getIsViewObjectMethod())
      {
         //TODO:if it's a new expression, then we need to store that it's a static
         //value and hence not call resolveAsExpression.
         if (mDef.getIsLocalObjectReference() && mBC != null)   
         {
            instance = resolveAsExpression(ctx, mBC, instanceName);
         }
         else
         {
            try
            {
               instance = resolveAsExpression(ctx, ctx, instanceName);
            }
            catch (oracle.jbo.JboException je)
            {
               throw je;
            }
            catch (RuntimeException re)
            {
               //now check if this instanceName is for a Nested AM!
               //this is a fix for bug 4605577. Real fix with el2.1 would
               //be to install a resolver for bc4j objects. But till then
               //we still need to resolve nested am names.
               if (dc != null && dc.getApplicationModule() != null && dc.getName() != null) 
               {
                  String name = ((new StringBuffer(dc.getName()))
                                          .append(DCUtil.SEP_DOT_CHAR)
                                          .append(DCDataControl.GET_dataProvider)).toString();
                  if (instanceName.startsWith(name)) 
                  {
                     //could be an AM lookup.
                     String lookupName = instanceName.substring(name.length()+1);
                     try
                     {
                        instance = ((oracle.jbo.ApplicationModule)dc.getDataProvider()).findApplicationModule(lookupName);
                     }
                     catch (Exception e)
                     {
                        //ignore. send the outer exception.
                     }
                  }
               }
               if (instance == null) 
               {
                  throw new JboException(re);
               }
            }
         }

         if (instance instanceof oracle.adf.model.generic.RowImpl)
         {
            instance = ((RowImpl)instance).getDataProvider();
         }
      }
      else
      {
         String dcName = dc.getName();
         if (dcName != null) 
         {
            StringBuffer strBuf = new StringBuffer(dc.getName()).append(DCUtil.SEP_DOT_CHAR);
            if (instanceName.startsWith(strBuf.toString()))
            {
               instanceName = instanceName.substring(strBuf.length());
               
               if (instanceName.startsWith(DCDataControl.GET_dataProvider)) 
               {
                  instanceName = instanceName.substring(DCDataControl.GET_dataProvider.length()+1);
               }
            }
         }
         instance = dc.getApplicationModule().findViewObject(instanceName);
      }
      return instance;
   }

   //called by datacontrol
   Object invokeMethod(DCDataControl dc, Map paramsMap)
   {
      
      BindingContext ctx = dc.getBindingContext();
      Object instance = getInvokeInstance(dc, ctx);


      int i;
      int argsize = (mArgs != null) ? mArgs .length : 0;

      try
      {
         if (mMethod == null && mCons == null)
         {
            String instanceClassName = mDef.getClassName();
            String methodName = mDef.getMethodName();
            Class[] argClasses = new Class[argsize];
            for (i = 0; i < argsize; i++)
            {
               argClasses[i] = mArgs[i].getType();
            }

            // JRS The instanceClassName may be null
            if (instanceClassName != null && methodName.equals(
               JboNameUtil.getLastPartOfName(instanceClassName)))
            {
               Constructor cons = JboNameUtil.findConstructor(
                  (Class)instance, argClasses);

               if (cons == null)
               {
                  throw new InvalidOperException(
                     CSMessageBundle.class
                     , CSMessageBundle.EXC_INVALID_METHOD_CALL
                     , new Object[] { instanceClassName +"."+ methodName+"()" });
               }

               mCons = cons;

            }
            else if ((!(instance instanceof Exportable))
               && (instanceClassName != null || instance != null))
            {
               Method mth = JboNameUtil.findMethod(
                  instanceClassName != null ? JBOClass.forName(instanceClassName) : instance.getClass()
                  , methodName
                  , argClasses
                  , null
                  , true); //return statics 

               if (mth == null)
               {
                  throw new InvalidOperException(
                     CSMessageBundle.class
                     , CSMessageBundle.EXC_INVALID_METHOD_CALL
                     , new Object[] { mDef.getInstanceName()+"."+methodName+"()" });
               }

               mMethod = mth;
            }
         }

         Object[] objs = (mTransientVals != null) ? mTransientVals: fetchAndSaveParameterValues(ctx, paramsMap, true);

         Object retVal;
         if (Diagnostic.isOn())
         {
            if (mDef.getInstanceName() != null)
            {
               Diagnostic.println("DCInvokeMethod:Invoking "+mDef.getInstanceName()+"."+mDef.getMethodName()+"()");
            }
            else
            {
               Diagnostic.println("DCInvokeMethod:Invoking "+mDef.getClassName()+"."+mDef.getMethodName()+"()");
               
            }
         }

         if(instance instanceof Exportable)
         {
            if (objs != null) 
            {
               for (int k = 0; k < objs.length; k++) 
               {
                  if (objs[k] instanceof DCVariableValueManagerImpl) 
                  {
                     DCVariableValueManagerImpl varmgr = new DCVariableValueManagerImpl();
                     Variable[] vars = ((DCVariableValueManagerImpl)objs[k]).getVariables();
                     Object[] values = ((DCVariableValueManagerImpl)objs[k]).getVariableValues(vars);
                     varmgr.mergeVariableValues(vars, values);
                     objs[k] = varmgr;
                  }
               }
            }
            //cache vals early to avoid calling the same method again
            //due to events generated from within invoke.
            if (mCacheVals) 
            {
               mVals = objs;
            }

            retVal = ((Exportable)instance).invokeExportedMethod(mDef.getMethodName(),
                                                                 mDef.getArgTypes(),
                                                                 objs);
         }
         else
         {

            //cache vals early to avoid calling the same method again
            //due to events generated from within invoke.
            if (mCacheVals) 
            {
               mVals = objs;
            }

            if (mMethod != null)
            {
               retVal = mMethod.invoke(instance, objs);
            }
            else
            {
               retVal = mCons.newInstance(objs);
            }
         }
 
         //place method results in el location before the after event 
         //is generated so that listeners could get the result value 
         //via method result location.
         dc.cacheMethodResult(this, retVal, mTransientVals);

         return retVal;
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (InvocationTargetException e)
      {
         Throwable t = e.getCause();
         if ( t == null )
         {
           t = e;
         }
         throw new JboException( t );
      }
      catch (Throwable e)
      {
         throw new JboException(e);
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getInstanceName()
   {
      return mDef.getInstanceName();
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getOperationName()
   {
      return mDef.getMethodName();
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getMethodName()
   {
      return mDef.getMethodName();
   }

   public final String getReturnName()
   {
      return mDef.getReturnName();
   }


   public DCInvokeMethodDef getDef()
   {
      return mDef;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Called by ActionBindingRef & MethodIteratorDef to imply that values once
    * fetched need to be cached so that it can be compared
    * against the new set of values on the next call to 
    * ascertain if the call should be ignored (if the
    * parameter=values are same)
    */
   public void setCacheResolvedValues(boolean flag)
   {
      mCacheVals = flag;
   }

   public void release(int flag)
   {
      if (flag == DCDataControl.REL_ALL_REFS
           || flag == DCDataControl.REL_DATA_REFS)
      {
         //clean out mVals so that the method gets
         //reexecuted again if needed.
         mVals = null;

      }
   }

   public void invalidateMethodResults()
   {
      // bug 4887190.  guava test guava.customdc.js06.
      // ensure that release on the DCInvokeMethod will invalidate the
      // method results in the DC cache as well.  this codepath should
      // be entered when we release a method iterator binding.
      DCDataControl dc = mBC.getDataControl();
      if (dc != null)
      {
         dc.invalidateMethodResult(this);
      }
   }

   /**
   * Returns a list of JUInvokeMethodListener  (returns an empty list if no such listener was registered).
   */
   public final ArrayList getInvokeMethodListeners()
   {
      return (mListeners != null) ? (ArrayList)mListeners.clone() : new ArrayList(0);
   }
   
   /**
   * Adds the given listener to this Action Binding's listeners list.    
   */
   public final void addInvokeMethodListener(DCInvokeMethodListener l)
   {
      if (mListeners == null) 
      {
         mListeners = new ArrayList(4);
      }
      if (!mListeners.contains(l)) 
      {
         mListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this Action Binding's listeners list.
   */
   public final void removeInvokeMethodListener(DCInvokeMethodListener l)
   {
      if (mListeners != null) 
      {
         mListeners.remove(l);
         if (mListeners.size() == 0)
         {
            mListeners = null;
         }
      }
   }

   void notifyBeforeInvokeMethod(DCInvokeMethodEvent ev)
   {
      ArrayList listeners = mListeners;
      for (int i = 0; i < listeners.size(); i++) 
      {
         ((DCInvokeMethodListener)listeners.get(i)).beforeInvokeMethod(ev);
      }
   }

   void notifyAfterInvokeMethod(DCInvokeMethodEvent ev)
   {
      ArrayList listeners = mListeners;
      for (int i = 0; i < listeners.size(); i++) 
      {
         ((DCInvokeMethodListener)listeners.get(i)).afterInvokeMethod(ev);
      }
   }

   public String getPermissionTargetName()
   {
      String instanceName = null;
      DCDataControl dc = mBC.getDataControl();
      StringBuffer  strBuf = new StringBuffer();

      if (mDef.getIsViewObjectMethod())
      {
         strBuf.append(mDef.getInstanceName());
      }
      else
      {
         if (mCons == null && mDef.getInstanceName() != null)
         {
            instanceName = mDef.getInstanceName();
	    if (instanceName.startsWith("bindings")) //NONLS
	    {
	       instanceName = dc.getName();
	    }
	    else
	    {
              int ix = instanceName.indexOf(DCDataControl.GET_dataProvider);
              if (ix > 0)
              {
                 instanceName = instanceName.substring(0, ix - 1);
              }
	    }
         }
         else
         {
            instanceName = mDef.getClassName();
         }
	 strBuf.append(instanceName);
      }
      strBuf.append(DCUtil.SEP_DOT_CHAR).append(mDef.getMethodName());
      return strBuf.toString();
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.METHOD_PERMISSION);
      }
      return mPermissionInfo;
   }
}

