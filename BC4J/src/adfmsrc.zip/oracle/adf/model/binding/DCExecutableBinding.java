package oracle.adf.model.binding;

import java.util.ArrayList;
import java.util.List;

import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.common.JboNameUtil;

import oracle.adf.model.PermissionInfo;


abstract public class DCExecutableBinding extends JboAbstractMap implements DCIExecutable
{
   String mName;
   private DCIExecutableDef mExecDef;
   transient private int mRefreshOption = DCBindingContainerDef.RC_DEFAULT; //default is to execute only if necessary
   transient private String mRefreshExpression = null;
   transient private boolean mRefreshed = false;
   transient private ArrayList mDependents = null;
   transient private DCBindingContainer mBC;
   protected PermissionInfo mPermissionInfo = null;
   
   /**
   * Returns the instance name of this DCBindingContainer object.
    * <p>
   */
   public final String getName()
   {
      return mName;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   * Sets the instance name of this DCBindingContainer object.
   */
   public final void setName(String name)
   {
      mName = name;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   */
   public final void setRefreshOption(int option)
   {
      mRefreshOption = option;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public final void setRefreshExpression(String expr)
   {
      mRefreshExpression = expr;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public final int getRefreshOption()
   {
      return mRefreshOption;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public final String getRefreshExpression()
   {
      return mRefreshExpression;
   }

   /**
    * Lookup the keyObj in the namespace of this binding-container. If the keyObj is
    * a string and matches one of the iterator bindings or container bindings return
    * that. Otherwise lookup if the keyObj matches the name of one of the public spel-accessible
    * values in this object and if so return that.
    */
   protected boolean mInternalGet_KeyResolved;
   public Object get(Object keyObj)
   {
      if (keyObj instanceof String)
      {
         Object ret;
         String key = (String)keyObj;
         //check with the passed in key first. If key is 'name' this
         //will handle that case instead of conflicting with Name which
         //is also a reserved word. Also the uppercased Name will be the
         //last thing looked for, so this should return bindings with
         //name/Name keyword if any.
         mInternalGet_KeyResolved = false;
         if (((ret = internalGet(key)) != null) || mInternalGet_KeyResolved)
         {
            return ret;
         }

         //only go down to uppercased search if the first char is not upper
         //case to begin with.
         key = JboNameUtil.toUpperCaseFirstChar(key);
         if (!key.equals(keyObj))
         {
            //if first char was upper-cased.
            if (((ret = internalGet(key)) != null) || mInternalGet_KeyResolved)
            {
               return ret;
            }
         }
      }
      return super.get(keyObj);
   }
   

   //these are public apis accessible via spel.
   static final String GET_Def  = "def";        //NONLS
   static final String GET_Name = "name";       //NONLS
   static final String GET_RefreshParametersChanged = "refreshParametersChanged";       //NONLS
   static final String GET_Refreshed = "refreshed";       //NONLS

   protected Object internalGet(String key)
   {
      Object ret = null;
      key = key.intern();

      //now check for getters accessible via EL
      if (key == GET_Name)
      {
         mInternalGet_KeyResolved = true;
         return getName();
      }
      else if (key == GET_Def)
      {
         mInternalGet_KeyResolved = true;
         return getExecutableDef();
      }
      else if (key == GET_Refreshed)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isRefreshed()); 
      }
      else if (key == GET_RefreshParametersChanged)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(hasRefreshParametersChanged()); 
      }

      return super.internalGet(key);
   }

   abstract public int getExecutableType();

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void release(int flags)
   {
      mRefreshed = false;
      if (flags == DCDataControl.REL_ALL_REFS)
      {
         if (mBC != null)
         {
            mBC.removeExecutableBinding(getName());
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   abstract public boolean hasRefreshParametersChanged();

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public DCIExecutableDef getExecutableDef()
   {
      return mExecDef;
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void setBindingContainer(DCBindingContainer ctr)
   {
      mBC = ctr;
   }

   
   /**
   * Return form binding object of this iterator binding's container.
   * 
   */
   public DCBindingContainer getBindingContainer()
   {
      return mBC;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void setExecutableDef(DCIExecutableDef execdef)
   {
      mExecDef = execdef;
      if (execdef != null) 
      {
         setRefreshOption(execdef.getRefreshOption());
         setRefreshExpression(execdef.getRefreshExpression());
      }
   }

   private final boolean isRefreshable(int flag)
   {
      //only if my container is refreshed, I should be refreshable.
      DCBindingContainer ctr = getBindingContainer();
      DCIExecutableDef def = getExecutableDef();

      //if oldstyle iterator bindings, there are no defs.
      return (def != null) 
              ? (ctr.isRefreshed() && def.isRefreshable(ctr, this, flag))
              : true;
   }


   /**
   * *** For internal framework use only ***
   * <p>
   */
   public boolean refreshIfNeeded()
   {
      if (isRefreshed()) 
      {
         return true;
      }

      //add this isRefershable when we add custom eval for each refresh
      //option type. commented out for now.
      if ((getRefreshOption() == DCBindingContainerDef.RC_DEFER) 
          /*&& isRefreshable(DCBindingContainerDef.RC_DEFER)*/) 
      {
         refresh(DCBindingContainerDef.RC_DEFER);
         return true;
      }
      else if (isRefreshable(DCBindingContainerDef.RC_DEFAULT))
      {
         refresh(DCBindingContainerDef.RC_DEFAULT);
         return true;
      }

      return false;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void setRefreshed(boolean flag)
   {
      boolean changeRefreshed = (mRefreshed != flag);
      mRefreshed = flag;
      if (changeRefreshed)
      {
         resetDependentsRefresh();
      }
   }


   protected List getDependents()
   {
      return mDependents;
   }

   protected void resetDependentsRefresh()
   {
      if (mDependents != null) 
      {
         for (int i = 0; i < mDependents.size(); i++) 
         {
            ((DCExecutableBinding)mDependents.get(i)).setRefreshed(false);
         }
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public boolean isRefreshed()
   {
      return mRefreshed;
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void addDependentExecutable(DCExecutableBinding exec)
   {
      if (mDependents == null) 
      {
         mDependents = new ArrayList(4);
      }

      if (!mDependents.contains(exec)) 
      {
         mDependents.add(exec);
      }
   }

   /**
   * *** For internal framework use only ***
   * <p>
   */
   public void removeDependentExecutable(DCExecutableBinding exec)
   {
      if (mDependents != null) 
      {
         mDependents.remove(exec);
         if (mDependents.size() == 0) 
         {
            mDependents = null;
         }
      }
   }

   public String getPermissionTargetName()
   {
      if (mBC != null)
      {
	  return mBC.getDef().getFullName();
      }
      return null;
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         mPermissionInfo = new PermissionBinding(getPermissionTargetName(), PermissionHelper.REGION_PERMISSION);
      }
      return mPermissionInfo;
   }

}

