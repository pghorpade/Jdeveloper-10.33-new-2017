/*
 * @(#)DCBindingContainer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Iterator;
import java.util.StringTokenizer;

import oracle.adf.model.AttributeBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.RegionContext;
import oracle.adf.model.RegionController;
import oracle.adf.model.RegionListener;
import oracle.adf.model.ADFmMessageBundle;
import oracle.adf.model.PermissionInfo;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboException;
import oracle.jbo.JboExceptionHandler;
import oracle.jbo.JboWarning;
import oracle.jbo.LocaleContext;
import oracle.jbo.NameClashException;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.ViewObject;
import oracle.jbo.ValidationException;
import oracle.jbo.Variable;
import oracle.jbo.VariableManagerOwner;
import oracle.jbo.VariableValueManager;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.VariableValueManagerImpl;
import oracle.jbo.uicli.UIMessageBundle;
import oracle.jbo.uicli.mom.JUMetaObjectBase;
import oracle.jbo.uicli.mom.JUMetaObjectManager;

import java.security.Permission;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;

/**
 * Corresponds to a Swing JFrame or a JSP Page instance and manages bindings used in a 
 * frame. The DCBindingContainer class provides:
 * <ul>
 * <li>Management of iterator binding instances. 
 * <li>Management of control bindings.
 * <li>Manages the findMode status and switches the iterator bindings into approrpriate mode.
 * <li>Helper methods for sending out messages to status/navigation bar components.
 * </ul>
 * <p>
 *
 * <hr>
 * <h3>Expression language usage</h3>
 * 
 *    <p>The binding container properties are accessed  via SPEL. Any of the getter methods can be invoked
 *    via expressions. The expression language can also traverse any of the collection exposed by this object.
 *    
 *    <p>
 *       The binding container provides access to all the contained bindings. It implements the map interface which makes it 
 *       convenient for using SPEL to locate the children of the binding container. A common usage in JSP pages is to access
 *       the binding container within the page's context via the <strong>bindings</strong> variable. 
 *       
 *       Somce sample expressions using <a href="http://java.sun.com/j2ee/1.4/docs/tutorial/doc/JSTL.html#wp74644">JSTL</a> are as follows:
 *       <p><br>
 *          //output the binding container's name <br>
 *          &lt;c:out value="${bindings.name" /&gt;
 *          <br>
 *          // print out the editing mode string<br>
 *          &lt;c:out value="${bindings.editingMode" /&gt;
 *          <br>
 *          // print out the input value of a control binding called 'deptno'<br>
 *          &lt;c:out value="${bindings.deptno.inputValue" /&gt;
 *       </p>
 *    </p>
 * <hr>
 * @see oracle.jbo.uicli.jui.JUPanelBinding
 * 
 * @javabean.class name=DCBindingContainer
 * 
 */
public class DCBindingContainer extends DCExecutableBinding
             implements RegionBinding, JboExceptionHandler, VariableManagerOwner

{
   protected DCDataControl mDataControl;
   private DCBindingContainerDef mBindingContainerDef;
   private Object mViewComponent;
   
   private ArrayList mExcs;
   
   private HashMap mParams;
   protected ArrayList mParamsList;

   private HashMap mIterBindings = new HashMap(5);
   protected ArrayList mIterBindingList = new ArrayList(5);

   private HashMap mControls = new HashMap(10);
   protected ArrayList mControlList = new ArrayList(10);

   private DCBindingContainer mParent;
   private ArrayList mRegionsList;

   private HashMap mExecutables;
   private ArrayList mExecutablesList;

   boolean mFindMode = false;
   private LocaleContext mLocaleContext;
   boolean mExecuteOnRollback = true;
   protected ApplicationModule mDataProvider;
   ArrayList mValidationListeners;
   private BindingContext mBindingContext;
   boolean mInited = false;
   int mTrackInputs = 0;
   boolean  mEnableTokenValidation = true;
   
   //Map of dc alias names to parent relative dcAlias or fully qualified dcName.
   private Map mAliases;
   private Map mParamValues;

   private boolean mParentBeingValidated = false;
   transient Object mActionProcessor;
   transient RegionController mRegionController;
   transient ArrayList mRegionListeners;
   transient int mTransientRefreshType = REFRESH_UNKNOWN;

   private PermissionInfo mPermissionInfo = null;

   class RegionContextImpl implements RegionContext
   {
      RegionBinding mRegion;
      int mFlag;
      RegionContextImpl(RegionBinding reg, int flag)
      {
         mRegion = reg; 
         mFlag = flag;
      }

      public RegionBinding getRegionBinding()
      {
         return mRegion;
      }
      
      public int getRefreshFlag()
      {
         return mFlag;
      }

      void internalSetRegion(RegionBinding reg)
      {
         mRegion = reg;
      }
   }

   /**
   * Default constructor.
   */
   public DCBindingContainer()
   {
   }

   /**
    * Returns true if token validation is enabled for this binding container. This
    * flag is used in ADF web apps to verify the state of a binding container for a 
    * the page that is being processed.
    */
   public boolean isTokenValidationEnabled()
   {
      return mEnableTokenValidation;
   }
   
   /**
    * Enables or disables token validation.
    */
   public void setEnableTokenValidation(boolean bSet)
   {
      mEnableTokenValidation = bSet;         
   }
   
   /**
   * Constructor used by DCPanelBinding, which passes in a reference to the JPanel object.
   * *** For internal framework use only ***
   */
   protected DCBindingContainer(Object panel)
   {
      // minimalize the impact of the design time panel binding definition
      if (panel != null)
      {
         setViewComponentInternal(panel);
      }
   }

   void reportException(DCDataControl app, Throwable th)
   {
      if (Diagnostic.isOn())
      {
         Diagnostic.println("DCBindingContainer.reportException :" + ((th != null) ? th.getClass().getName() : "null exception"));
         if (th != null)
         {
           // print the stack trace; otherwise it is hard to debug:
           Diagnostic.printStackTrace(th);
         }
      }

      JboException ex = (th instanceof JboException) ? (JboException) th : new JboException(th);
      //try
      {
         if (app != null)
         {
            app.reportException(this, ex);
         }
         else
         {
            BindingContext ctx = getBindingContext();
            if (ctx != null && ctx.getErrorHandler() != null)
            {
               ctx.getErrorHandler().reportException(this, ex);
            }
            else
            {
               JUMetaObjectManager.reportException(this, ex);
            }
         }
      }
      /*
      finally
      {
         mRaisingException = false;
      }
      */
   }
   /**
   * If DCDataControl is setup, then invoke DCDataControl.reportException
   * to report any exceptions. Otherwise, throw a JboException (wrapping
   * non-JboExceptions if required)
   * <p>
   * This method converts all exceptions to a JboException.
   */
   public void reportException(Throwable th)
   {
      DCDataControl app = null;
      try
      {
         app = getDataControl();
      }
      catch (JboException e)
      {
         //ignore as we're only trying to report an exception.
         oracle.jbo.common.Diagnostic.println("Ignoring during reportException :"+e);
      }
      reportException(app, th);
   }

   
   /**
    * *** For internal framework use only ***
    */
   protected void setBindingContext(BindingContext ctx)
   {
      mBindingContext = ctx;
   }

   /**
    * Returns the bindingContext to which this bindingContainer belongs.
    */
   public BindingContext getBindingContext()
   {
      return mBindingContext;
   }

   /**
   * Sets the DCDataControl instance in this form binding.
   * If this form binding is already registered with a DCDataControl,
   * then it throws an InvalidOperException.
   * @throws InvalidOperException
   */
   public void setDataControl(DCDataControl app)
   {
      if (mDataControl != null && app != mDataControl)
      {
         throw new InvalidOperException(UIMessageBundle.class,
                                        UIMessageBundle.EXC_APP_ALREADY_SET_FOR_FORM_BND,
                                        new Object[] { getName() } );
      }
      
      if (app != mDataControl)
      {
         mDataControl = app;

         if (app != null && mParent == null)
         {
            app.addBindingContainer(this);
            if (mDataProvider != app.getApplicationModule())
            {
               mDataProvider = app.getApplicationModule();
            }
         }
      }
   }


   /**
   * *** For internal framework use only ***
   */
   public final DCBindingContainerDef getDef()
   {
      return mBindingContainerDef;
   }

   
   /**
   * *** For internal framework use only ***
   */
   protected void setDef(DCBindingContainerDef formDef)
   {
      mBindingContainerDef = formDef;
      if (formDef != null)
      {
         mValidationListeners = formDef.mValidators;
      }
      super.setExecutableDef(formDef);
   }

   
   /**
   * *** For internal framework use only ***
   */
   public void initializeFromDef(BindingContext ctx, ApplicationModule am)
   {
      this.setBindingContext(ctx);
      mBindingContainerDef.initializeBindingContainer(this, am);
   }

   
   /**
   * *** For internal framework use only ***
   * Returns the associated JPanel object.
   */
   public final Object getViewComponent()
   {
      return mViewComponent;
   }

   /**
   * *** For internal framework use only ***
   * Sets internal member variable with the given panel instance.
   */
   protected void setViewComponentInternal(Object panel)
   {
      mViewComponent = panel;
   }

   
   /**
   * Return oracle.jbo.ApplicationModule instance which provides the BC4J context to
   * this form binding object if this BindingContainer is working with only one BC4J 
   * DataControl which is for support of classic JClient appliations.
   * <p>
   * To get a BC4J AM in all cases use the IteratorBinding that iterates
   * over a Bc4J collection and get it's DataControl to get to the 
   * corresonding ApplicationModule.
   * 
   * @deprecated since 10.1.2. Use IteratorBinding.getDataControl() to get to the
   * ApplicationModule in case of BC4J datacontrols.
   */
   public final ApplicationModule getApplicationModule()
   {
      if (mDataProvider == null) 
      {
         //initializeApplicationModule();
         mDataProvider = getDataControl().getApplicationModule();
      }
      return mDataProvider;
   }

   
   /**
   * *** For internal framework use only ***
   * Sets the ApplicationModule reference
   */
   public void setApplicationModule(ApplicationModule am)
   {
      mDataProvider = am;
   }

   //Region mgt.

   /**
    * *** For internal framework use only ***
    * <p>
    * Sets the parent container for this nested BindingContainer usage
    */
   void setRegionContainer (DCBindingContainer parent)
   {
      mParent = parent;
   }
   
   /**
    * Returns the parent BindingContainer that includes this
    * instance of BindingContainer as a nested BindingContainer.
    */
   public final DCBindingContainer getRegionContainer()
   {
      return mParent;
   }

   /**
   * Return an ordered set of executableBindings.
   */
   public final List getRegionBindings()
   {
      return (List) ((mRegionsList != null)  ? mRegionsList.clone() : null);
   }

   /**
   * Return an ordered set of executableBindings.
   */
   public final List getExecutableBindings()
   {
      return (List) ((mExecutablesList != null)  ? mExecutablesList.clone() : null);
   }

   public final RegionBinding findRegionBinding(String name)
   {
      return (RegionBinding)findExecutableBinding(name);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public final boolean usesDef(DCBindingContainerDef def)
   {
      if (getExecutableDef() == def) 
      {
         return true;
      }
      if (mRegionsList != null) 
      {
         DCExecutableBinding region;
         DCIExecutableDef regionDef;
         for (int i = 0; i < mRegionsList.size(); i++) 
         {
            region = (DCExecutableBinding)mRegionsList.get(i);
            regionDef = region.getExecutableDef();
            if (regionDef == def) 
            {
               return true;
            }
            if (region instanceof DCBindingContainer) 
            {
               if (((DCBindingContainer)region).usesDef(def))
               {
                  return true;
               }
            }
         }
      }
      return false;
   }
   
   /**
   * Returns the nested BindingContainer usage/instance of the given name.
   * found in nested in this BindingContainer. This method does not recurse
   * into it's nested containers.
   */
   public final Object findExecutableBinding(String name)
   {
      return ((mExecutables != null) ? mExecutables.get(name) : null);
   }

   
   /**
   * Adds the given Nested BindingContainer usage into this bindingContainer.
   * By default name the nested BindingContainer usage is referred to by the
   * instance name of given BindingContainer.
   */
   public final void addExecutableBinding (Object ctr)
   {
      if (ctr instanceof DCIExecutable) 
      {
         addExecutableBinding(((DCIExecutable)ctr).getName(), ctr);
      }
      else
      {
         addExecutableBinding(getDef().adaptExecutableBinding(null, ctr));
      }
   }


   /**
   * Adds this ExecutableBinding into this container with the given name.
   * If the name is null, a system-generated name is used. The generated
   * name is set into the nested ExecutableBinding object.
   * @throws InvalidObjNameException if an invalid name is passed in.
   * @throws NameClashException if given a duplicate name.
   */
   public final void addExecutableBinding(String name, Object execObj)
   {
      DCIExecutable exec = (DCIExecutable)execObj;
      int execType = exec.getExecutableType();

      boolean genIterName = (((name == null) || (name.length() == 0)) && (exec != null));
      if (mExecutables == null) 
      {
         mExecutables      = new HashMap(10);
         mExecutablesList  = new ArrayList();
      }

      while (true)
      {
         if (genIterName)
         {
            name = DCUtil.generateIteratorName(exec);
         }
         else  if (!JboNameUtil.isNameValid(name))
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_FORM_BINDING,
                                              name);
         }

         if (mExecutables.get(name) != null)
         {
            if (!genIterName)
            {
               throw new NameClashException(JUMetaObjectBase.TYP_FORM_BINDING,
                                            name);
            }
         }
         else
         {
            break;
         }
      }

      if (name != null && name.length() != 0) 
      {
         if (exec != null) 
         {
            if (genIterName) 
            {
               exec.setName(name);
            }
         }

         mExecutablesList.add(exec);
         mExecutables.put(name, exec);
         exec.setBindingContainer(this);

         if (execType == EXECUTABLE_REGION) 
         {
            if (exec instanceof DCBindingContainer) 
            {
               DCBindingContainer dcRegion = (DCBindingContainer)exec;
               dcRegion.setRegionContainer(this);                   
               dcRegion.setBindingContext(getBindingContext());
            }

            if (mRegionsList == null) 
            {
               mRegionsList = new ArrayList(5);
            }
            mRegionsList.add(exec);
         }
         else if (execType == EXECUTABLE_ITERATORBINDING)
         {
            mIterBindingList.add(exec);
            mIterBindings.put(name, exec);
         }
      }
   }


   /**
   * If a BindingContainer usage exists with the given name, remove it from the internal
   * members. This method also releases the references to view layer if any that this
    * nested container may have. Cleaning out the references to the data layer is the 
    * responsibility of the caller.
   */
   public final boolean removeExecutableBinding(String name)
   {
      boolean retVal = false;
      if (mExecutables != null) 
      {
         DCIExecutable bnd = (DCIExecutable) mExecutables.get(name);

         if (bnd != null) 
         {
            if (bnd instanceof DCBindingContainer)
            {
               ((DCBindingContainer)bnd).release(DCDataControl.REL_VIEW_REFS);
               if (mRegionsList != null) 
               {
                  mRegionsList.remove(bnd);
               }
            }
            else if (bnd instanceof DCIteratorBinding) 
            {
               mIterBindingList.remove(bnd);
               mIterBindings.remove(name);
            }

            mExecutables.remove(name);
            mExecutablesList.remove(bnd);
            retVal = true;
         }

      }
      return retVal;
   }


   /**
   * *** For internal framework use only ***
   * Clean all nested ExecutableBindings registered with this container.
   */
   protected final void clearExecutableBindings()
   {
      if (mExecutablesList != null) 
      {
         for (int i = 0; i < mExecutablesList.size(); i++) 
         {
            mExecutablesList.remove(mExecutablesList.get(i));
         }
         mExecutablesList.clear();
         mExecutables.clear();
      }
   }



   //IteratorBinding list mgt.
   /**
   * Return the hashmap containing iterator bindings
   */
   public final HashMap getIterBindings()
   {
      return (HashMap)mIterBindings.clone();
   }


   /**
   * Return an ordered set of iterator bindings.
   */
   public final ArrayList getIterBindingList()
   {
      return (ArrayList)mIterBindingList.clone();
   }

   /*
   *
   * Returns a list of all the iterator bindings, including iterators
   * in the nested binding container.
   * 
   * One of the possible usage, is in JUNavigation bar where nvaigation bar,
   * can assoicate itself with iterator of the nested binding container.
   */
   public final ArrayList getAllIterBindingList()
   {
      ArrayList al = (ArrayList)mIterBindingList.clone();
      if (mRegionsList != null) 
      {
         RegionBinding ctr;
         for (int i = 0; i < mRegionsList.size(); i++) 
         {
            ctr = (RegionBinding)mRegionsList.get(i);
            if (ctr instanceof DCBindingContainer) 
            {
               al.addAll(((DCBindingContainer)ctr).getIterBindingList());
            }
         }
      }
      return al;
   }

   
   /**
   * Returns the iterator binding object of the given name.
   */
   public final DCIteratorBinding findIteratorBinding(String name)
   {
      if (name != null && name.indexOf('.') > 0) 
      {
         return (DCIteratorBinding)DCUtil.findSpelObject(this, name, false);
      }
      return (DCIteratorBinding) mIterBindings.get(name);
   }

   
   /**
   * Adds the given iterator binding name with a framework generated name.
   */
   public final void addIteratorBinding(DCIteratorBinding iterBinding)
   {
      addIteratorBinding(null, iterBinding);
   }


   /**
   * Adds this iterator binding with this form with the given name.
    * If the name is null, a system-generated name is used. The generatd
    * name is set into the iteratorBinding object.
   * @throws InvalidObjNameException if an invalid name is passed in.
   * @throws NameClashException if given a duplicate name.
   */
   public final void addIteratorBinding(String name, DCIteratorBinding iterBinding)
   {
      boolean genIterName = ((name == null) || (name.length() == 0));

      while (true)
      {
         if (genIterName)
         {
            name = DCUtil.generateIteratorName(iterBinding);
         }
         else  if (!JboNameUtil.isNameValid(name))
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_ITER_BINDING,
                                              name);
         }

         //see if this name matches any that we already have in this namespace
         if (getChildByName(name) != null)
         //if (mIterBindings.get(name) != null)
         {
            if (!genIterName)
            {
               throw new NameClashException(JUMetaObjectBase.TYP_ITER_BINDING,
                                            name);
            }
         }
         else
         {
            break;
         }
      }

      iterBinding.setName(name);
      
      addExecutableBinding(name, iterBinding);

   }



   /**
   * If an iterator binding exists with the given name, remove it from the internal
   * members.
   */
   public final boolean removeIteratorBinding(String name)
   {
      /*
      boolean retVal = false;
      DCIteratorBinding bnd = (DCIteratorBinding) mIterBindings.get(name);
      
      if (bnd != null)
      {
         retVal = mIterBindingList.remove(bnd);
         mExecutablesList.remove(bnd);
         mIterBindings.remove(name);
         mExecutables.remove(name);
      }
      */

      return removeExecutableBinding(name);
   }


   /**
   * *** For internal framework use only ***
   * Clean all iterator bindings registered with this form.
   */
   protected final void clearIteratorBindings()
   {
      DCIteratorBinding iter;
      for (int i = 0; i < mIterBindingList.size(); i++) 
      {
         iter = (DCIteratorBinding)mIterBindingList.get(i);
         mExecutablesList.remove(iter);
         mExecutables.remove(iter.getName());
      }
      mIterBindingList.clear();
      mIterBindings.clear();
   }

   final void addParameter(DCParameter control, String name)
   {
      if (name == null)
      {
         throw new InvalidObjNameException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                              name);
      }
      
      if (control.getBindingContainer() != this)
      {
         DCBindingContainer ctr =control.getBindingContainer();
         if (ctr != null)
         {
           ctr.removeParameter(control);
           control.setBindingContainer(null);
         }

         control.setName(name);
         //set would have added the control by right name
         control.setBindingContainer(this);
         return;
      }

      if (name != null && !name.equals(control.getName()))
      {
         control.setName(name);
      }
      else //if (name == null)
      {
         addBinding(control, false);
      }
   }

   /**
   * *** For internal framework use only ***
    * Adds a controlbinding object to this container.
    * @throws InvalidObjNameException if control's name is of unsupported format
    * @throws NameClashException if an object exists with this control-binding's name.
   */
   public final void addControlBinding(DCControlBinding control)
   {
      addBinding(control, true);
   }

   private void addBinding(DCControlBinding control, boolean notParam)
   {
      String name = control.getName();

      boolean genIterName = ((name == null) || (name.length() == 0));

      while (true)
      {
         if (genIterName)
         {
            name = DCUtil.generateControlName(control);
         }
         else if (!JboNameUtil.isNameValid(name))
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                              name);
         }

         //see if this name matches any that we already have in this namespace
         if (getChildByName(name) != null)
         {
            if (!genIterName)
            {
               throw new NameClashException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                            name);
            }
            //continue for another name.
         }
         else
         {
            control.internalSetName(name);
            break;
         }
      }


      if (name != null)
      {
         if (notParam) 
         {
            mControls.put(name, control);
            mControlList.add(control);
         }
         else
         {
            if (mParams == null) 
            {
               mParams = new HashMap(4);
               mParamsList = new ArrayList(4);
            }
            mParams.put(name, control);
            mParamsList.add(control);
         }
      }
   }


   /**
   * *** For internal framework use only ***
   */
   public final void addControlBinding(String name, DCControlBinding control)
   {
      if (control.getBindingContainer() != this)
      {
         //if this is the first time this control is being added to a bindingContainer,
         //then set the name once rather than add control with default name (via setBindingContainer)
         //and then adjust it with the right name.
         if (control.getBindingContainer() == null && name != null && !name.equals(control.getName()))
         {
            control.setName(name);
         }
         control.setBindingContainer(this);
      }

      if (name != null && !name.equals(control.getName()))
      {
         control.setName(name);
      }
      else if (name == null)
      {
         addControlBinding(control);
      }
   }

   
   /**
    * Returns a list  containing all control-bindings in this container 
    */
   public final List getControlBindings()
   {
      /*
      ArrayList al = (ArrayList)mControlList.clone();
      if (mRegionsList != null) 
      {
         List list;
         for (int i = 0; i < mRegionsList.size(); i++) 
         {
            list = ((RegionBinding)mRegionsList.get(i)).getControlBindings();
            if (list != null) 
            {
               al.addAll(list);
            }
         }
      }
      return al;
      */
      return getCtrlBindingList();
   }

   /**
    * Returns an array containing all control-bindings in this container.
    */
   public final ArrayList getCtrlBindingList()
   {
      return (ArrayList)mControlList.clone();
   }

   /**
    * Return a list of all Attribute bindings in this RegionBinding.
    */
   public List getAttributeBindings()
   {
      int size = mControlList.size();
      ArrayList al = new ArrayList(size);
      Object obj;
      for (int i = 0; i < size; i++) 
      {
         if ((obj = mControlList.get(i)) instanceof oracle.binding.AttributeBinding) 
         {
            al.add(obj);
         }
      }
      return al;
   }

   /**
    * Return a list of all Action bindings in this RegionBinding.
    */
   public List getOperationBindings()
   {
      int size = mControlList.size();
      ArrayList al = new ArrayList(size);
      Object obj;
      for (int i = 0; i < size; i++) 
      {
         if ((obj = mControlList.get(i)) instanceof oracle.binding.OperationBinding) 
         {
            al.add(obj);
         }
      }
      return al;
   }

   /**
    * Return a list of parameter (DCParameter type) objects that make up 
    * the parameters for this bindingContainer. null is returned if there
    * are no parameters defined for this bindingContainer.
    */
   public final List getParametersList()
   {
      return (List) ((mParamsList != null) ? mParamsList.clone() : null);
   }

   /**
    * Return Parameters map.
    */
   public final Map getParametersMap()
   {
      return (Map) ((mParams != null) ? mParams.clone() : null);
   }

   /**
    * Given the name, find a parameter (DCParameter) type object in this binding
    * container of the same name. Return null if no such name is found.
    */
   public final DCParameter findParameter(String name)
   {
      if (mParams== null) 
      {
         return null;
      }
      if (name != null && name.indexOf ('.') > 0) 
      {
         return (DCParameter)DCUtil.findSpelObject(this, name, false);
      }
      return (DCParameter) mParams.get(name);
   }


   
   /**
   * *** For internal framework use only ***
   */
   public final DCControlBinding getCtrlBinding(int index)
   {
      return (DCControlBinding) mControlList.get(index);
   }


   /**
    * Returns a control binding with the given name. Returns null
    * if name is not found.
   */
   public final DCControlBinding findCtrlBinding(String name)
   {
      if (name != null && name.indexOf ('.') > 0) 
      {
         return (DCControlBinding)DCUtil.findSpelObject(this, name, false);
      }
      return (DCControlBinding) mControls.get(name);
   }

   public final oracle.binding.ControlBinding getControlBinding(String name)
   {
      return (oracle.binding.ControlBinding)findCtrlBinding(name);
   }

   public final oracle.binding.OperationBinding getOperationBinding(String name)
   {
      return (oracle.binding.OperationBinding)findCtrlBinding(name);
   }


   final Object evaluateParameter(String expr, boolean bCtx, boolean retExpr)
   {
      Object retVal = null;
      boolean isExpr = DCUtil.isElExpr(expr);
      if (isExpr)
      {
        retVal = DCUtil.elEvaluate(getBindingContext(), this, expr);
      }
      else 
      {
        retVal = DCUtil.findSpelObject(this, new StringBuffer(expr), false);
      }
      //if (retVal instanceof JUCtrlParameterBinding)
      //retVal = ((JUCtrlParameterBinding)retVal).getAttribute();
      if (retVal instanceof DCParameter)
      {
         DCParameter param = (DCParameter)retVal;
         retVal = null;
         if (param.getBindingContainer() == this) 
         {
            if (mParamValues != null && mParamValues.containsKey(param.getName()) && !param.isFinal())
            {
               //parameter expression has been overridden with a fixed null.
               retVal = mParamValues.get(param.getName());
            }
         }
         if (retVal == null) 
         {
            retVal = param.getValue();
            if (retVal == null && retExpr) 
            {
               retVal = param.getExpression();
            }
         }
      }

      //if asked to seek into bindingContext as well.
      if (retVal == null && bCtx)
      {
         if (!isExpr)
         {
            retVal = DCUtil.findSpelObject(getBindingContext(), new StringBuffer(expr), false);
         }
         // for expr. this is redundant as we've already looked into
         //bindings and bindingContext both in elEvaluate.
      }
      return retVal;
   }

   /**
    * *** For internal framework use only ***
    * Return the Expression String that will be used to evaluate the
    * value of a parameter.
    */
   public final Object evaluateParameter(String expr, boolean bCtx)
   {
      return evaluateParameter(expr, bCtx, false);
   }

   /**
    * *** For internal framework use only ***
    * Set the expression string for a given parameter name. This allows
    * overriding of the parameter expression in a bindingContainer usage.
    */
   public final void setParameterExpression(String name, String elExpr)
   {
      if (mAliases == null) 
      {
         mAliases = new HashMap(5);
      }
      if (Diagnostic.isOn()) 
      {
         if (mAliases.get(name) != null) 
         {
            Diagnostic.println("Overriding existing parameter of name:"+name+" with value expression:"+elExpr);
         }
      }
      mAliases.put(name, elExpr);
   }

   /**
    * *** For internal framework use only ***
    * Allows setting values for this page's parameters. Note that if the usage
    * declaratively defines a parameter 'value' then that takes precedence over
    * the value passed in in this list. So for usages where parameter is passed
    * in from a caller, there should be no 'value' defined in the usage.
    * <p>
    * This method is primarily called on top-level BindingContainers to pass
    * in the page/bindingContainer level parameters.
    */
   public final void setParameterValues(Map paramValueMap)
   {
      if (paramValueMap != null)
      {
         Map paramValues = new HashMap();
         paramValues.putAll(paramValueMap);
         mParamValues = paramValues;
      }
      else
      {
         mParamValues = null;
      }
   }

   public final DCDataControl findDataControl(String alias)
   {
      //this string could be an alias or an expression, so use elEvaluate.
      return (DCDataControl)evaluateParameter(alias, true, true);

      
      //datacontrol always walks up the hierarchy in parents 
      //to fetch a mapped datacontrol or fetch the same named 
      //datacontrol from the parent. The top level parent finally
      //goes to bindingContext to get the datacontrol
      /*
      String mappedName = (mAliases != null)  ? (String)mAliases.get(alias) : alias;
      mappedName = (mappedName != null) ? mappedName : alias;
      
      if (getParentContainer() != null)
      {
         return getParentContainer().findDataControl(mappedName);
      }

      return (DCDataControl)getBindingContext().get(mappedName);
      */
   }

   void setAliasesMap(Map map)
   {
      mAliases = map;
   }

   /**
    * *** For internal framework use only ***
    * Return any alias String value if set for a given bindingContainer parameter.
    */
   public String getParameterAlias(String key)
   {
      return (String)((mAliases != null) ? mAliases.get(key) : null);
   }


   /**
    * *** For internal framework use only ***
    * Returns true if this nested bindingContainer usage has an alias defined
    * for paramter with the given key as it's id/name.
    */
   public boolean aliasExists(String key) 
   {
      return (mAliases != null) ? mAliases.containsKey(key) : false;
   }

   /**
    * *** For internal framework use only ***
    */
   public DCBindingContainer getRootBindingContainer()
   {
      if (getRegionContainer() == null) 
      {
         return this;
      }
      return getRegionContainer().getRootBindingContainer();
   }

   
   /**
    * Matches the control with the View-component(getControl) for
    * each of the control bindings in this container. Returns the matching
    * control binding if found. Otherwise returns null.
    */
   public final DCControlBinding getCtrlBinding(Object control)
   {
      int size = mControlList.size();
      Object bind;
      for (int i = 0; i < size; i++) 
      {
         bind = mControlList.get(i);
         if (bind instanceof DCControlBinding) 
         {
            if (((DCControlBinding)bind).getControl() == control)
            {
               return ((DCControlBinding)bind);
            }
         }
      }
      return null;
   }


   /**
    * *** For internal framework use only ***
    * Remove the parameter object from a binding container
    */
   public final boolean removeParameter(DCParameter control)
   {
      if (mParams != null) 
      {
         String ctrlName = control.getName();

         mParams.remove(ctrlName);

         return mParamsList.remove(control);
      }
      return false;
   }

   
   /**
   * *** For internal framework use only ***
   */
   public final boolean removeControlBinding(DCControlBinding control)
   {
      String ctrlName = control.getName();

      mControls.remove(ctrlName);

      return mControlList.remove(control);
   }


   /**
   * *** For internal framework use only ***
   */
   public final boolean removeControlBinding(String name)
   {
      boolean retVal = false;
      DCControlBinding bnd = (DCControlBinding) mControls.get(name);
      
      if (bnd != null)
      {
         mControls.remove(name);

         retVal = mControlList.remove(bnd);
      }

      return retVal;
   }

   /**
    * *** For internal framework use only ***
    */
   public final boolean removeParameter(String name)
   {
      boolean retVal = false;

      if (mParams != null) 
      {
         DCControlBinding bnd = (DCControlBinding) mParams.get(name);

         if (bnd != null)
         {
            mParams.remove(name);

            retVal = mParamsList.remove(bnd);
         }
      }

      return retVal;
   }


   /**
   * Execute the query behind each iterator binding that is contained in this form binding.
   * Applications could invoke this method to re-execute all the ViewObjects associated with
   * this form.
   */
   public void execute()
   {
      internalRefreshControl(EXECUTE_MODEL, false);
   }

   private void oldExecute()
   {
      DCIteratorBinding iterBnd;

      // JRS 3284980 Suspend row set events handling for all other binding
      // containers.  This assumes that the other binding containers are not
      // active and will refresh themselves once activated.
      //
      // In JClient this may not completely work.  I suppose that a JPanel
      // could contain control bindings/iterator bindings that are in
      // different binding containers.  In this scenario an execute on one
      // binding container may refresh the RSI that is shared between the two
      // iterator bindings in separate containers but the iterator binding/
      // control binding in the binding container on which execute was *not*
      // invoked would not get notified of the refresh.
      //
      // There are a number of potential further fixes.  One is to make the
      // execute service more global and to have it operate on all binding
      // containers.  This would resolve the issue mentinoed above.
      //
      // Another fix would be to share iterator bindings between the containers
      // (i.e. one-to-one between iterator binding and rsi).  This has been
      // discussed for other reasons concerning range sizes.  If we agree
      // to share iterator bindings then this code could go.
      //
      // See guava.batchmode.js01 for regression.
      //
      // JRS Moved to release.  endRequest/release processing should suspend
      // the request BC's IBs event handling.  Next refreshControl will only
      // restore the current BC's IBs event handling.
      
      int size = mIterBindingList.size();
      DCDataControl iterDC;
      int i;
      ArrayList dcs = new ArrayList(4);
      boolean hasBatchDCs = false;
      try
      {
         //1. collect DCs that need sync & suspend active event handling
         for (i = 0; i < size; i++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(i);

            iterBnd.suspendRowSetEventsHandling(true);
            iterDC = iterBnd.getDataControl();

            if (iterDC != null && (iterDC.getApplicationModule() != null || iterDC.syncNeeded()) && !dcs.contains(iterDC))
            {
               //for all Bc4J DCs and all syncNeeded ones.
               hasBatchDCs = (hasBatchDCs) ? true : iterDC.syncNeeded();
               dcs.add(iterDC);
               iterDC.getRootDataControl().getApplicationModule().setExceptionHandler(this);
            }
         }

         RowSetIterator rsi;

         //2. perform execute

         //recalc size as size changes.      
         for (int j = 0; j < mIterBindingList.size(); j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            rsi = iterBnd.getRowSetIterator();
            {
               if (rsi != null)
               {
                  if (hasBatchDCs)
                  {
                     //this check will cause a roundtrip. avoid that.
                     //if (iterBnd.getRowSetIterator().getRangeSize() != iterBnd.mRangeSize)
                     if (iterBnd.mRangeSize != DCIteratorBinding.RANGESIZE_DO_NOT_OVERRIDE)
                     {
                       rsi.setRangeSize(iterBnd.mRangeSize);
                     }
                  }
                  else if (iterBnd.getDataControl().isJClientApp() 
                            && (iterBnd.mRangeSize != DCIteratorBinding.RANGESIZE_DO_NOT_OVERRIDE))
                  {
                     rsi.setRangeSize(iterBnd.mRangeSize);
                  }
               }
               iterBnd.executeQuery();
            }
         }

         //3. sync()

         JboException je = null;
         for (i = 0; i < dcs.size(); i++)
         {
            try
            {
               //
               //if activation occurs, do the extra bit of collecting which RSIs
               //to bring to life. Call getAllRowsInRange() here as the event.
               //
               ((DCDataControl)dcs.get(i)).sync("DCBindingContainer.execute");
            }
            catch (JboException catchEx)
            {
               je = catchEx;
            }
         }

         //refresh the iterators after setting listening to events to true.

         //do we really need this step?
         //-----------------------------
         size = mIterBindingList.size();
         for (int j = 0; j < size; j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            rsi = iterBnd.getRowSetIterator();
            if (rsi != null)
            {
               rsi.reset();
            }
         }
         //-----------------------------

         // JRS bug 3320665.  See verification script guava.batchmode.js02

         if (je != null)
         {
            //after reseting the 
            throw je;
         }
      }
      finally
      {
         //4. activate event handling

         //need two loops as processing of refresh events may lead to dependent
         //iterator execution.
         for (int j = 0; j < mIterBindingList.size(); j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            iterBnd.suspendRowSetEventsHandling(false);
         }


         //5. refresh iterators so that UIs redisplay values.
         //   shouldn't this be done only for JClient/active clients?
         for (int j = 0; j < mIterBindingList.size(); j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            iterBnd.rangeRefreshed(null);
         }
      }
   }
   

   
   /**
   * Excecute the query for each iterator binding, if not already executed.
   * Applications should invoke this method to verify and execute all the ViewObjects
   * associated with this form. This method is used by the generated applications
   * by default.
   */
   public void executeIfNeeded()
   {
      DCIteratorBinding iterBnd;
      DCDataControl dc = getDataControl();
      boolean syncBatch = (dc != null) ? dc.syncNeeded() : false;
      
      int size = mIterBindingList.size();

      

      for (int j = 0; j < size; j++)
      {
         iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
         RowSetIterator rsi = iterBnd.getRowSetIterator();
         if (syncBatch)
         {
            iterBnd.suspendRowSetEventsHandling(true);

            //this check will cause a roundtrip. avoid that.
            //if (iterBnd.getRowSetIterator().getRangeSize() != iterBnd.mRangeSize)
            if (iterBnd.mRangeSize != DCIteratorBinding.RANGESIZE_DO_NOT_OVERRIDE)
            {
               iterBnd.setRangeSizeForRSI(rsi, iterBnd.mRangeSize);
            }
         }
         else if (dc.isJClientApp() 
                   && (iterBnd.mRangeSize != DCIteratorBinding.RANGESIZE_DO_NOT_OVERRIDE))
         {
            iterBnd.setRangeSizeForRSI(rsi, iterBnd.mRangeSize);
         }
         
         iterBnd.executeQueryIfNeeded();
      }

      RowSetIterator rsi;
      if (syncBatch)
      {
         dc.syncIfNeeded("DCBindingContainer.executeIfNeeded");
         for (int j = 0; j < size; j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            rsi = iterBnd.getRowSetIterator();
            if (rsi != null)
            {
               rsi.reset();
            }
            iterBnd.suspendRowSetEventsHandling(false);
         }
         for (int j = 0; j < size; j++)
         {
            iterBnd = (DCIteratorBinding) mIterBindingList.get(j);
            iterBnd.rangeRefreshed(null);
         }
      }
   }

   /**
   * Return an Iterator Binding of the given "voIterBindingName" if one already exists by that name.
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that display just one row's attribute invoke this method to find
   * or create the iterator binding for which they display an attribute data.
   */
   public DCIteratorBinding getIteratorBinding(String        voInstanceName,
                                             String        voIterName, /**temporarily taking nulls for this*/
                                             String        voIterBindingName)
   {
      return getIteratorBinding(voInstanceName, voIterName, voIterBindingName, 1);
   }

   /**
   * Return an Iterator Binding of the given "voIterBindingName", if one already exists by that name,
   * after setting up the iterator binding's range Size to the greater of existing range size and
   * the given range size. If range size is -1, that indicates all rows in the range and hence
   * takes precedence in the above comparison.
   * <p>
   * If not, create an IteratorBinding object that references a default iterator of the ViewObject
   * instance named voInstanceName (and optionally the iterator named voIterName). Return this created
   * iterator binding after adding it to internal lists.
   * <p>
   * Various control bindings that are capable of displaying more than one row of data invoke this
   * method to create their iterator binding with a preferred range size.
   */
   public DCIteratorBinding getIteratorBinding(String       voInstanceName,
                                                 String       voIterName, /**temporarily taking nulls for this*/
                                                 String       voIterBindingName, 
                                                 int          rangeSize)
   {
      DCIteratorBinding bnd = findIteratorBinding(voIterBindingName);

      if (bnd == null) 
      {
         bnd = createIteratorBinding(voInstanceName, voIterName, voIterBindingName, rangeSize);
         addIteratorBinding(voIterBindingName, bnd);
         if (mDataControl != null)
         {
            //for jclient case where datacontrol is not set on the created bindings elsewhere.
            bnd.internalSetDataControl(mDataControl);
         }
      }
      else
      {
         //validate that the rangeSize passed in is greater than 1.
         bnd.resolveRangeSize(rangeSize);
      }
      
      return bnd;
   }

   protected DCIteratorBinding createIteratorBinding(String       voInstanceName,                                      
                                                     String       voIterName, 
                                                     String       voIterBindingName,                                 
                                                     int          rangeSize)
   {
      //impl is in JUFormBinding.
      return null;

   }

   /**
    * Calls setFindMode(boolean mode, boolean applyCriteria) with applyCriteria = true;
   */
   public void setFindMode(boolean mode)
   {
      setFindMode(mode, true);
   }

   /**
   * Sets this form into findMode. All iterator bindings with this form are set to find mode.
    * Passes applyCriteria to IteratorBindings to indicate if they should apply the ViewCritiera
    * stored on the iterator binding onto the model collection.
    * <p>
   * Also, notify each iteratorChanged listener registered with this form of the change
   * in the iterator (due to change in mode so that they update the displays with 
   * the find or data mode's data).
    */
   public void setFindMode(boolean mode, boolean applyCriteria)
   {
      if (mode != mFindMode) 
      {
         mFindMode = mode;
         int type;
         DCIExecutable bnd;
         if (mExecutablesList != null) 
         {
            for (int j = 0; j < mExecutablesList.size(); j++)
            {
               bnd = (DCIExecutable) mExecutablesList.get(j);
               type = bnd.getExecutableType();
               if (type == EXECUTABLE_REGION) 
               {
                  if (bnd instanceof DCBindingContainer) 
                  {
                     ((DCBindingContainer)bnd).setFindMode(mode, applyCriteria);
                  }
               }
               else if (type == EXECUTABLE_ITERATORBINDING)
               {
                  DCIteratorBinding iterBnd = (DCIteratorBinding)bnd;
                  if (iterBnd.isFindModeAllowed())
                  {
                     iterBnd.setFindMode(mode, applyCriteria);
                     notifyIteratorChanged(iterBnd, false); //do not refresh incase of changing back to data mode.
                  }
                  else 
                  {
                     if (iterBnd.getDataControl().isJClientApp())
                     {
                        //simply send out a refresh event for the UI to disable itself.
                        iterBnd.refreshControl();
                     }
                  }
               }
            }
         }
      }
   }

   /**
   * Returns true if this form is in find mode.
   */
   public boolean isFindMode()
   {
      return mFindMode;
   }

   /**
    * Returns "* Find Mode" if this bindingContainer is in find mode.
    * @deprecated since 10.1.3 use isFindMode to determine the find or 
    * data modes for this bindingContainer. 
    */
   public String getEditingMode()
   {
      //FIXME , add to resource bundle
      if(isFindMode())
         return "*Find Mode";
      return ""; // dont return any string for editing mode bug#3061656
   }
   
   /**
   * Helper method to add the given object to the JUApplication's StatusBars.
   */
   public void addStatusBarInterface(DCStatusBarInterface statusBar)
   {
      //should this be registered with all datacontrols referred to in this container?
      if (getDataControl() != null) 
      {
         mDataControl.addStatusBarInterface(statusBar);
      }
   }

   /**
   * Helper method to remove the given object to the JUApplication's StatusBars.
   */
   public void removeStatusBarInterface(DCStatusBarInterface statusBar)
   {
      if (mDataControl != null) 
      {
         mDataControl.removeStatusBarInterface(statusBar);
      }
   }

   /**
   * Helper method to display the given message and params via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(DCIteratorBinding iterBinding, String msgId, Object[] params)
   {
      if (mDataControl != null) 
      {
         mDataControl.displayStatus(iterBinding, msgId, params);
      }
   }

   /**
   * Helper method to display the given message string via the JUApplication's displayStatus method.
   * This method becomes a no-op if this form is not registered with a JUApplication
   */
   public void displayStatus(String msg)
   {
      if (mDataControl != null) 
      {
         mDataControl.displayStatus(msg);
      }
   }



   /**
    * Returns the locale context set into the BC4J application module if this binding-container's
    * datacontrol is a Bc4J data control. Otherwise returns null.
    */
   public LocaleContext getLocaleContext()
   {
      if (getBindingContext() != null) 
      {
         return getBindingContext().getLocaleContext();
      }

      if (mLocaleContext == null) 
      {
         mLocaleContext = (getDataControl() != null) 
                            ? getDataControl().getLocaleContext() 
                            : null;
      }
      return mLocaleContext;
   }

   
   /**
    * Returns true if this form binding executes all the ViewObjects it's associated with after rollback
    * is called on the application via DCCtrlActionBinding's rollback action.
    **/
   public boolean isExecuteOnRollback()
   {
      return mExecuteOnRollback;
   }

   /**
    * Set false if this form binding should not execute all the ViewObjects it's associated with after rollback
    * is called on the application via DCCtrlActionBinding's rollback action. The default is to execute all
    * the ViewObjects on rollback.
    **/
   public void setExecuteOnRollback(boolean flag)
   {
      mExecuteOnRollback = flag;
   }

   /**
    * release all view and datacontrol references from this binding-container
    * and all it's containee iterator bindings and control bindings.
    */
   public void release()
   {
      release(DCDataControl.REL_ALL_REFS);
   }

   /**
    * Applications should release the DataControl which
    * will end up calling this method for all binding 
    * containers in the datacontrol.
    * 
    * @param flags could be one of the enumerations in DCDataControl. See DCDataControl.release()
    **/
   public void release(int flags)
   {
      ArrayList al;
      
      mRegionController = null;
      mActionProcessor = null;
      mExcs = null;


      // JRS Release the control bindings first since they are the clients
      // to the iterator bindings.
      // See bug 3498424 in which the JUCtrlListBinding release does not
      // properly function b/c it's mListIterBinding was released first.
      al = (ArrayList)mControlList.clone();
      for (int i = 0; i < al.size(); i++)
      {
         ((DCControlBinding)al.get(i)).release(flags);
      }
      
      
      if (mExecutables != null) 
      {
        al = (ArrayList)mExecutablesList.clone();
        for (int i = 0; i < al.size(); i++)
        {
           ((DCIExecutable)al.get(i)).release(flags);
        }
      }
     
      if (mIterBindingList.size() > 0) 
      {
         al = (ArrayList)mIterBindingList.clone();
         for (int i = 0; i < al.size(); i++)
         {
            ((DCIteratorBinding)al.get(i)).release(flags);
         }
      }

      if (mParamsList != null && mParamsList.size() > 0) 
      {
         al = (ArrayList)mParamsList.clone();
         for (int i = 0; i < al.size(); i++)
         {
            ((DCParameter)al.get(i)).release(flags);
         }
      }


      if (flags == DCDataControl.REL_ALL_REFS)
      {
         mControls = new HashMap(10);
         mControlList = new ArrayList(10);
         
         mParams = null;
         mParamsList = null;

         mIterBindings = new HashMap(5);
         mIterBindingList = new ArrayList(5);

         mExecutables = null;
         mExecutablesList = null;

         mRegionsList = null;

         mValidationListeners = null;
         mRegionListeners = null;
         mDataProvider = null;


         if (mDataControl != null)
         {
            mDataControl.removeBindingContainer(this);
            mDataControl = null;
         }
      }

      if (((flags & DCDataControl.REL_DATA_REFS) > 0) || (flags & DCDataControl.REL_WEAK_DATA_REFS) > 0)
      {
         mDataProvider = null;
         mFindMode = false; //the next page will turn on findmode based on iterator token.
      }

      //this is the only place where a UI control is set to null in DC bindings.
      //code-gen needs this to be null for applets to restart properly after release.
      if ((flags & DCDataControl.REL_VIEW_REFS) > 0)
      {
         setViewComponentInternal(null);
      }

      //either we remove this bindingContainer (which is uselessnow)
      //from the bindingContext or we do not remove the control/iterator bindings
      //but simply release their referenced objects.
      //For now, release and remove the bindingContainer instance as well.
      //
      // JRS 11/02/2005 Replace the dead BindingContainer with a 
      // DCBindingContainerReference
      if (flags == DCDataControl.REL_ALL_REFS)
      {
         if (getBindingContext() != null)
         {
            BindingContext bctx = getBindingContext();
            if (this == bctx.get(getName()))
            {
               bctx.remove(getName());

               bctx.put(getName(), new DCBindingContainerReference(
                  bctx, getName(), mBindingContainerDef.getFullName()));
            }
         }
      }
      super.release(flags);
   }

   /**
   * *** For internal framework use only ***
   */
   protected void initializeViewComponent(ArrayList controls) {};

   /**
   * *** For internal framework use only ***
   * Used to setup reference to DCDataControl and oracle.jbo.Application objects.
   */
   protected void initializeApplicationModule() {};
   
   /**
   * Invoked by the framework to notify various status bars of which control has gained the focus.
   */
   protected void focusGained(DCIteratorBinding iterBinding, DCControlBinding binding, int attrIndex) {};

   /**
   * Notify each listener of the iteratorChanged event when an iterator changes its data due to execute, 
   * re-execute, or change in display mode (find mode or data mode).
   */
   protected void notifyIteratorChanged(DCIteratorBinding iterBnd, boolean refresh) {};

   /**
    * Invoked when a DCIteratorBinding receives a rangeRefreshed Event from BC4J RowSetIterator
    * @param iter that received the rangeRefreshed event.
    * @param event a description of the new ranges.
    */
   protected void rangeRefreshed(DCIteratorBinding iter, RangeRefreshEvent event) {};

   /**
    * Invoked when a DCIteratorBinding receives a rangeScrolled Event from BC4J RowSetIterator
    * @param iter that received the rangeScrolled event.
    * @param event a description of the new range.
    */
   protected void rangeScrolled(DCIteratorBinding iter, ScrollEvent event) {};

   /**
    * Invoked when a DCIteratorBinding receives a rowInserted Event from BC4J RowSetIterator
    * @param iter that received the rowInserted event.
    * @param event a description of the new Row object.
    */
   protected void rowInserted(DCIteratorBinding iter, InsertEvent event) {};

   /**
    * Invoked when a DCIteratorBinding receives a rowDeleted Event from BC4J RowSetIterator
    * @param iter that received the rowDeleted event.
    * @param event a description of the deleted Row object.
    */
   protected void rowDeleted(DCIteratorBinding iter, DeleteEvent event) {};

   /**
    * Invoked when a DCIteratorBinding receives a rowUpdated Event from BC4J RowSetIterator
    * @param iter that received the rowUpdated event.
    * @param event a description of the modified Row object.
    */
   protected void rowUpdated(DCIteratorBinding iter, UpdateEvent event) {};

   /**
    * Invoked when a DCIteratorBinding receives a navigated Event from BC4J RowSetIterator
    * @param iter that received the navigated event.
    * @param event a description of the new and previous current rows.
    */
   protected void navigated(DCIteratorBinding iter, NavigationEvent event) {};


   /**
   * Invoked before any control binding performs a setAttribute call on a BC4J row.
   * This is used by DCPanelBinding to generate validation events to validate attribute values
   * before they are set.
   */
   public Object callBeforeSetAttribute(DCControlBinding ctrl,
                                     Row row,
                                     AttributeDef ad,
                                     Object value) 
   {
      DCIteratorBinding iter = ctrl.getDCIteratorBinding();
      /*
      if (iter != null) 
      {
         DCDataControl dc = iter.getDataControl();
         if (dc == null)
         {
            //why is this cleaning out the dc.
            setDataControl (dc);
         }
      }
      */

      if (iter != null)
      {
         // more bug 4756026.  Instead of forcing the insert in  the 
         // form token validation let's do it here right before we
         // set the attribute.  guava.region.sv02 caught this issue.
         // see the comment in DCBindingContainerState (search for bug)
         // for more info.
         iter.insertCreatedRow();
      }

      DCBindingContainerValidationEvent ev = new DCBindingContainerValidationEvent(ctrl, this, iter, row, ad.getName(), value);
      beforeSetAttribute(ev);
      

      return ev.getNewValue();
   }

   /**
    * Jclient uses this to indicate if stopEdit completed before
    * datacontrol can proceed with update cycle (commit etc).
    */
   protected boolean isEditingStopped()
   {
      return true;
   }

   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeRowNavigated() method to notify all validation listeners.
   */
   public void callBeforeRowNavigated(DCIteratorBinding iter)
   {
      Row row = iter.getCurrentRow();
      if (row != null) 
      {
         beforeCurrencyChange(new DCBindingContainerValidationEvent(this, iter, row));
      }
   }
   
   /**
   * Forces the current control to stop its editing mode (if used, like in JTable).
   * Calls beforeSaveTransaction() method to notify all validation listeners.
   */
   public void callBeforeSaveTransaction(DCDataControl dc)
   {
      beforeSaveTransaction(new DCBindingContainerValidationEvent(this, dc));
   }

   /**
   * Notifies all DCBindingContainerValidationListeners with the beforeSetAttribute event.
   * This event is raised before a control binding sets the value from a control
   * into the corresponding BC4J row's attribute.
   */
   public void beforeSetAttribute(DCBindingContainerValidationEvent  ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCBindingContainerValidationListener)al.get(i)).beforeSetAttribute(ev);
         }
      }
   }
   
   /**
   * Notifies all JUPanelValidationListeners with the beforeCurrencyChange event.
   * This event is raised before an iterator-binding object moves the current row
   * to another row.
   */
   public void beforeCurrencyChange(DCBindingContainerValidationEvent ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCBindingContainerValidationListener)al.get(i)).beforeCurrencyChange(ev);
         }
      }
   }
   
   /**
   * Notifies all JUPanelValidationListeners with the beforeSaveTransaction event.
   * The JClient framework calls this method before invoking commit() on the BC4J transaction.
   */
   public void beforeSaveTransaction(DCBindingContainerValidationEvent ev)
   {
      if (mValidationListeners != null) 
      {
         ArrayList al = mValidationListeners;
         for (int i = 0; i < al.size(); i++) 
         {
            ((DCBindingContainerValidationListener)al.get(i)).beforeSaveTransaction(ev);
         }
      }
   }
   
   private Object getChildByName(String key)
   {
      Object ret = null;
      if ((ret= mControls.get(key)) != null)
      {
         return ret;
      }
      if (mExecutables != null) 
      {
         if ((ret = mExecutables.get(key)) != null)
         {
            mInternalGet_KeyResolved = true;
            if (ret instanceof DCIExecutableAdapter) 
            {
               //in case of deferred mode, this executable
               //needs to be refreshed.
               ((DCIExecutableAdapter)ret).refreshIfNeeded();
               return ((DCIExecutableAdapter)ret).getAdaptee();
            }
            return ret;
         }
      }
      if (mParams != null) 
      {
         if ((ret= mParams.get(key)) != null)
         {
            mInternalGet_KeyResolved = true;
            return ((DCParameter)ret).getValue();
         }
      }
      
      VariableValueManager varMgr = getVariableManager();
      if (varMgr != null) 
      {
         Variable var = varMgr.lookupVariable(key);
         if (var != null) 
         {
            mInternalGet_KeyResolved = true;
            return varMgr.getVariableValue(var);
         }
      }
      return ret;
   }

   //these are public apis accessible via spel.
   static final String GET_EditingMode = "editingMode"; //NONLS
   static final String GET_ExceptionsList = "exceptionsList"; //NONLS
   static final String GET_StateToken = "statetoken"; //NONLS
   static final String GET_StateTokenId = "statetokenid"; //NONLS
   static final String GET_VariableManager = "variableManager"; //NONLS
   static final String GET_Viewable = "viewable"; //NONLS
   static final String GET_Parameters = "parametersMap"; //NONLS
   static final String GET_Executables = "executableBindings"; //NONLS
   static final String GET_This = "bindings"; //NONLS
   
   /**
    * This method may be overridden by subclasses to implement
    * public spel lookup strings.
    * <p>
    * This method first checks for control binding
    * with the given name and returns a control-binding with the
    * matching name.                 /EmpEdit.do
    * If not, then iterator binding with a matching key/name is
    * returned.
    * If not, then if the following keys are checked:
    * <p>
    * Properties returned vis getter on this control bindings are:
    * <li><code>def</code> - returns getDef()</li>
    * <li><code>name</code> - returns getName()</li>
    * 
   */
   protected Object internalGet(String key)
   {
      key = key.intern();
      Object ret = null;

      ret = getChildByName(key);
      if (ret != null || mInternalGet_KeyResolved)
      {
         //found a child with this name even if it's value is null (for params/variables)
         mInternalGet_KeyResolved = true;
         return ret;
      }
      //now check for getters accessible via EL
      if (key == GET_This)
      {
         mInternalGet_KeyResolved = true;
         return this;
      }
      else if (key == GET_Viewable)
      {
         mInternalGet_KeyResolved = true;
         return new Boolean(isViewable());
      }
      else if (key == GET_Parameters)
      {
         mInternalGet_KeyResolved = true;
         return this.getParametersMap();
      }
      else if (key == GET_Executables)
      {
         mInternalGet_KeyResolved = true;
         return this.getExecutableBindings();
      }
      else if (key == GET_StateToken)
      {
         mInternalGet_KeyResolved = true;
         return getStateToken();
      }
      else if (key == GET_StateTokenId)
      {
         mInternalGet_KeyResolved = true;
         return getStateTokenId();
      }
      else if (key == GET_EditingMode)
      {
         mInternalGet_KeyResolved = true;
         return getEditingMode();
      }
      else if (key == GET_ExceptionsList)
      {
         mInternalGet_KeyResolved = true;
         return getExceptionsList();
      }
      else if (key == GET_VariableManager)
      {
         mInternalGet_KeyResolved = true;
         ensureVariableManager();
         return getVariableManager();
      }
      else if (key == BindingContext.CONTEXT_ID)
      {
         mInternalGet_KeyResolved = true;
         return getBindingContext();
      }
      
      return super.internalGet(key);
   }

   public int hashCode()
   {
     return mName.hashCode() + mIterBindings.hashCode() + mControls.hashCode();
   }

   /**
    * Invokes refreshControl.
    */
   public final void refresh(int refreshFlag)
   {
      internalRefreshControl (refreshFlag, true);
   }

   /**
    * Invokes refreshControl.
    */
   public final void refresh()
   {
      refreshControl();
   }

   /**
    * Refresh the binding container with control data.
    * <p>
    * This method synhronizes the rangeSizes from iteratorBindings onto the
    * collection that they are bound to and then executes (if not already
    * executed) the collection sources to get the collection data by calling
    * iterator binding's refreshControl method. 
    * The order of these calls is implied by the order in which the iterator bindings
    * were added to this bindingContainer (or were represented in xml metadata).
    * <p>
    * Method bound iterator bindings expect the methods be already executed
    * or atleast their parameters(if any) be accessible to the Method Action
    * associated with the iterator binding so that the method can be executed
    * successfully to bind to a returned collection.
    * <p>
    * 
    *
    **/
   public void refreshControl()
   {
      internalRefreshControl(REFRESH_UNKNOWN, true);
   }

   /**
    * *** For internal framework use only ***
    * <p>
    * Subclasses may need to override this as a choke point to ready
    * their component bindings before executing/refreshing the bindingContainer.
    */
   protected void internalRefreshControl (int refreshFlag, boolean executeIfNeeded)
   {

      //this should register datacontrols that are part of this panelBinding into 
      //context so that at the end of refresh, context could call sync on 
      //datacontrols
      setRefreshed(true);
      mTransientRefreshType = refreshFlag;
      int i;
      DCIteratorBinding iter;
      try
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("**** refreshControl() for BindingContainer :"+getName());
         }

         int size = mIterBindingList.size();
         ArrayList dcs = new ArrayList(3);

         //sjv-2004-06-02
         //we could speed this up by adding knowledge that we have
         //multiple datacontrols. However I do not anticipate more than 
         //say 3-4DCs in a page so this doesn't seem like a time-sink for now.

         //build ArrayList of dcs in this page.
         DCDataControl iterDC;
         boolean hasBatchDCs = false;
         for (i = 0; i < size; i++)
         {
            iter = (DCIteratorBinding) mIterBindingList.get(i);

            if (executeIfNeeded) 
            {
               //only in case of refreshControl()
               //release iterator current row state so that it gets rebuilt
               //in updatemodel/prepareForInput.
               iter.releaseCurrentRow();
            }

            iterDC = iter.getDataControl();
            if (iterDC != null)
            {
               LocaleContext localeCtx = iterDC.getLocaleContext();
               if (localeCtx == null || !localeCtx.equals(getLocaleContext()))
               {
                  iterDC.setLocaleContext(getLocaleContext());

                  //so that fetchAttributeProperties is called again on batch DCs.
                  mInited = false;
               }
            }

            if (iterDC != null && (iterDC.getApplicationModule() != null || iterDC.syncNeeded()) && !dcs.contains(iterDC))
            {
               //for all Bc4J DCs and all syncNeeded ones.
               hasBatchDCs = (hasBatchDCs) ? true : iterDC.syncNeeded();
               dcs.add(iterDC);
               iterDC.getRootDataControl().getApplicationModule().setExceptionHandler(this);
            }

            if (refreshFlag == PREPARE_MODEL) 
            {
               iter.setRefreshed(false);
               iter.initForRefresh();
            }
         }

         // JRS bug 4763372 10.1.2 applications may be migrated to use
         // parameters and may pass a REFRESH_UNKNOWN flag to refresh.
         // go ahead and evaluate the parameters every time if REFRESH_UNKOWN.
         // this should not impact 10.1.3 applications that have specified
         // a known refreshFlag.
         if (refreshFlag == PREPARE_MODEL || refreshFlag == REFRESH_UNKNOWN) 
         {
            //run through page parameters and evaluate them once.
            if (mParamsList != null) 
            {
               evaluateParameters();
            }
         }


         if (!mInited)
         {
            mInited = true;
            
            for (i = 0; i < mControlList.size(); i++) 
            {
               ((DCControlBinding)mControlList.get(i)).initResources();
            }

            for (i = 0; i < size; i++)
            {
               iter = (DCIteratorBinding) mIterBindingList.get(i);
               iter.fetchAttributeProperties();
            }
         }

         //run through iterators and call executeIteratorBindingIfNeeded on all of them
         DCIExecutable iterObj;

         if (mRegionListeners != null) 
         {
            RegionContext regCtx = new RegionContextImpl(this, refreshFlag);
            ArrayList al = (ArrayList)mRegionListeners.clone();
            for (int regIdx = 0; regIdx < al.size(); regIdx++) 
            {
               if (((RegionListener)al.get(regIdx)).refreshRegion(regCtx) == false)
               {
                  //bailout as no refresh is needed.
                  if (Diagnostic.isOn()) 
                  {
                     Diagnostic.println("BindingContainer :"+getName()+" not refreshed due to listener:"+((RegionListener)al.get(regIdx)).getName());
                  }
                  continue;
               }
            }
         }

         //boolean needsFetchAttr = (hasBatchDCs) ? !mInited : false;
         
         mInited = true;

         RegionBinding region;
         int execType;
         DCIExecutableDef execDef;
         boolean execute = !executeIfNeeded;
         
         if (mExecutablesList != null) 
         {
            for (i = 0; i < mExecutablesList.size(); i++)
            {
               iterObj = (DCIExecutable) mExecutablesList.get(i);
               //fix this -1 to be proper int.
               execDef = iterObj.getExecutableDef();
               execType = iterObj.getExecutableType();

               if (refreshFlag == PREPARE_MODEL) 
               {
                  iterObj.setRefreshed(false);
               }
               if (/*execute ||*/ execDef == null || execDef.isRefreshable(this, iterObj, refreshFlag)) 
               {
                  if (execType == DCIExecutable.EXECUTABLE_REGION) 
                  {
                     if (execute && iterObj instanceof DCBindingContainer) 
                     {
                        ((DCBindingContainer)iterObj).internalRefreshControl(refreshFlag, false);
                     }
                     else
                     {
                        region = (RegionBinding)iterObj;
                        if (region.getRegionController() == null) 
                        {
                           region.refresh(refreshFlag);
                        }
                        else
                        {
                           region.getRegionController()
                                 .refreshRegion(new RegionContextImpl(region, refreshFlag));
                        }
                     }
                  }
                  else if (execType == EXECUTABLE_ITERATORBINDING)
                  {
                     iter = (DCIteratorBinding) iterObj;

                     //enable events handling as this binding container is being refreshed.
                     iter.suspendRowSetEventsHandling(true);

                     //if (needsFetchAttr) 
                     //{
                     //   iter.fetchAttributeProperties();
                     //}

                     if (!iter.isFindMode())
                     {
                        //set this for every bindingContainer.refreshControl(),
                        //as each page may have it's own setting. 
                        //--- modified --- this logic use the larger of the two range size settings!

                        if (iter.mRangeSize != DCIteratorBinding.RANGESIZE_DO_NOT_OVERRIDE)
                        {
                           //iter.resolveRangeSize(iter.getRowSetIterator().getRangeSize());
                           //force my range size over what's set so that I see only
                           //the number of rows I'm interested in 
                           iter.setRangeSize(iter.mRangeSize);
                        }

                        if (executeIfNeeded) 
                        {
                           //iterator is referred in the subsequent panels, we need to
                           //execute only if not executed. 
                           iter.executeQueryIfNeeded();
                        }
                        else
                        {
                           //iterator is referred in the subsequent panels, we need to
                           //execute only if not executed. 
                           iter.executeQuery();
                        }
                     }
                     // JRS 06/15/2004 The code above has the side effect of initializing
                     // the source RSI before the DC sync below.  The subsequent sync
                     // will match the WS objects with their cli/mt couterparts.
                     // 
                     // The initSourceRSI/sync is also necessary for BC4J find mode IBs
                     // after resetState has been invoked.  Without the initSourceRSI
                     // below the WSVO parent for the IB VC will not be aware of its
                     // buddy VO and an invalid oper exception will be thrown when
                     // setting up find mode immediately after refreshControl.
                     // bug 3443380.
                     else
                     {
                        iter.getViewCriteria();
                        iterObj.setRefreshed(iter.getNavigatableRowIterator() != null);
                     }
                  }
                  else
                  {
                     iterObj.refresh(refreshFlag);
                     iterObj.setRefreshed(true);
                  }
               }
            }
         }
         if (mParent == null) 
         {
            //run through my list of DCs and contained container's DCs. 
            //This should lead to 'one set of syncs' for all Dcs rather
            //than one per nested container.
            fetchAllNestedBatchDCs(dcs);

            for (i = 0; i < dcs.size(); i++)
            {
               //this should be a collective sync call for all DCs in this
               //top level bindingContainer.
               try
               {
                  //
                  //if activation occurs, do the extra bit of collecting which RSIs
                  //to bring to life. Call getAllRowsInRange() here as the event.
                  //
                  ((DCDataControl)dcs.get(i)).syncIfNeeded("DCBindingContainer.refresh");
               }
               catch (JboException je)
               {
                  reportException((DCDataControl)dcs.get(i), je);
                  //bail out now. The bindings should be updated by now
                  //of the MT changes due to eventing.
                  return;
               }
            }
         }
      }
      finally
      {
         //since we need to pass true only in case of "execute"
         //reverse executeIfNeeded as if it was 'execute'.
         executeIfNeeded = !executeIfNeeded;
         if (mParent == null || executeIfNeeded) 
         {
            //if execute then reset the iterators too before
            //calling refresh on them.
            resetSuspendedExecutables(executeIfNeeded, refreshFlag);
            if (mParent == null) // bug 5365941
            {
               refreshExecutables(executeIfNeeded, refreshFlag);
            }   
         }

         mTransientRefreshType = REFRESH_UNKNOWN;
      }
   }

   void resetSuspendedExecutables(boolean reset, int refreshFlag)
   {
      if (mExecutablesList == null) 
      {
         return;
      }
      for (int i = 0; i < mExecutablesList.size(); i++) 
      {
         DCIExecutable iterObj = (DCIExecutable)mExecutablesList.get(i);
         if (iterObj != null) 
         {
            int execType = iterObj.getExecutableType();
            if (execType == EXECUTABLE_REGION) 
            {
               if (iterObj instanceof DCBindingContainer) 
               {
                  ((DCBindingContainer)iterObj).resetSuspendedExecutables(reset, refreshFlag);
               }
            }
            else if (execType == EXECUTABLE_ITERATORBINDING)
            {
               DCIteratorBinding iter = ((DCIteratorBinding)iterObj);
               DCIteratorBindingDef iterDef = iter.getDef();
               if (reset && iter.hasRSI() && (iterDef == null || iterDef.isRefreshable(this, iter, refreshFlag))) 
               {
                  iter.getRowSetIterator().reset();
               }
               iter.suspendRowSetEventsHandling(false);
            }
         }
      }
   }

   void refreshExecutables(boolean refresh, int refreshFlag)
   {
      DCIExecutable iterObj;
      if (mExecutablesList == null) 
      {
         return;
      }
      for (int i = 0; i < mExecutablesList.size(); i++) 
      {
         iterObj = (DCIExecutable)mExecutablesList.get(i);
         int execType = iterObj.getExecutableType();
         if (execType == EXECUTABLE_REGION) 
         {
            if (iterObj instanceof DCBindingContainer) 
            {
               if (/*refresh || */((DCBindingContainer)iterObj).getDef().isRefreshable(this, iterObj, refreshFlag)) 
               {
                  ((DCBindingContainer)iterObj).refreshExecutables(refresh, refreshFlag);
               }
            }
         }
         else if (execType == EXECUTABLE_ITERATORBINDING)
         {
            DCIteratorBinding iter = (DCIteratorBinding)iterObj;
            DCIteratorBindingDef iterDef = iter.getDef();
            if (iter.isRefreshed() 
                || (iterDef == null || iterDef.isRefreshable(this, iter, refreshFlag))) 
            {
               iter.refresh (refreshFlag);
            }
         }
      }
   }

   private void evaluateParameters()
   {
      for (int i = 0; i < mParamsList.size(); i++) 
      {
         ((DCParameter)mParamsList.get(i)).reEvaluateValueEagerly();
      }
   }

   void fetchAllNestedBatchDCs(List dcs)
   {
      if (mExecutablesList == null) 
      {
         return;
      }
      DCIExecutable iterObj;
      DCDataControl iterDC;
      for (int i = 0; i < mExecutablesList.size(); i++)
      {
         iterObj = (DCIExecutable)mExecutablesList.get(i);
         int execType = iterObj.getExecutableType();
         if (execType == EXECUTABLE_REGION) 
         {
            if (iterObj instanceof DCBindingContainer) 
            {
               ((DCBindingContainer)iterObj).fetchAllNestedBatchDCs(dcs);
            }
         }
         else if (execType == EXECUTABLE_ITERATORBINDING)
         {
            iterDC = ((DCIteratorBinding)iterObj).getDataControl();
            if (iterDC != null && (iterDC.getApplicationModule() != null || iterDC.syncNeeded()) && !dcs.contains(iterDC))
            //if (iterDC != null && iterDC.syncNeeded() && !dcs.contains(iterDC))
            {
               dcs.add(iterDC);
            }
         }
      }
   }

   /**
    ** Resets the error state for all control bindings.
    **
    ** @javabean.method name=resetInputState
    **/
   public void resetInputState()
   {
      {
         DCIExecutable iterObj;
         if (mExecutables == null) 
         {
            return;
         }
         for (int i = 0; i < mExecutablesList.size(); i++)
         {
            iterObj = (DCIExecutable)mExecutablesList.get(i);
            if (iterObj != null) 
            {
               int execType = iterObj.getExecutableType();
               if (execType == EXECUTABLE_REGION) 
               {
                  if (iterObj instanceof DCBindingContainer) 
                  {
                     ((DCBindingContainer)iterObj).resetInputState();
                  }
               }
               else if (execType == EXECUTABLE_ITERATORBINDING)
               {
                  if (mExcs != null)
                  {
                     ((DCIteratorBinding)iterObj).resetInputState();
                  }
               }
            }
         }
         mExcs = null;
      }
   }

   /**
   * Returns a list of RegionListeners (returns an empty list if no such listener was registered).
   */
   public final List getRegionListeners()
   {
      ArrayList al = (mRegionListeners != null) ? (ArrayList)mRegionListeners.clone() : new ArrayList(0);
      if (getRegionController() != null) 
      {
         al.add(getRegionController());
      }
      return al;
   }
   
   /**
   * Adds the given listener to this binding container's validation listeners list.
   */
   public final void addRegionListener(RegionListener l)
   {
      if (mRegionListeners == null) 
      {
         mRegionListeners = new ArrayList(4);
      }
      if (!mRegionListeners.contains(l)) 
      {
         mRegionListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this binding container's validation listeners list.
   */
   public final void removeRegionListener(RegionListener l)
   {
      if (mRegionListeners != null) 
      {
         mRegionListeners.remove(l);
      }
   }

   public boolean isViewable()
   {
      if (mRegionListeners != null) 
      {
         boolean notVisible = false;
         RegionContext regCtx = new RegionContextImpl(this, REFRESH_UNKNOWN);
         ArrayList al = (ArrayList)mRegionListeners.clone();
         for (int regIdx = 0; regIdx < al.size(); regIdx++) 
         {
            if (((RegionListener)al.get(regIdx)).isRegionViewable(regCtx) == false)
            {
               notVisible = true;
               break;
            }
         }

         if (notVisible) 
         {
            return false;
         }
      }
      return internalIsViewable();
   }

   private boolean internalIsViewable()
   {
      SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
      if (secContext.isAuthorizationEnabled())
      {
         String target = mBindingContainerDef.getFullName();
         String permClassName = PermissionHelper.getPermissionClassName(PermissionHelper.REGION_PERMISSION);
         if (permClassName == null)
         {
            return true;
         }
        
         Permission p = (Permission)PermissionHelper.createPermissionInstance(permClassName, target, PermissionHelper.VIEW_ACTION);
         return PermissionHelper.hasPermission(secContext, p);
      }
     
      return true;
   }


   /**
   * Returns a list of ValidationListeners (returns an empty list if no such listener was registered).
   */
   public final ArrayList getValidationListeners()
   {
      return (mValidationListeners != null) ? (ArrayList)mValidationListeners.clone() : new ArrayList(0);
   }
   
   /**
   * Adds the given listener to this binding container's validation listeners list.
   */
   public final void addValidationListener(DCBindingContainerValidationListener l)
   {
      if (mValidationListeners == null) 
      {
         mValidationListeners = new ArrayList(4);
      }
      if (!mValidationListeners.contains(l)) 
      {
         mValidationListeners.add(l);
      }
   }
   
   /**
   * Removes the given listener from this binding container's validation listeners list.
   */
   public final void removeValidationListener(DCBindingContainerValidationListener l)
   {
      if (mValidationListeners != null) 
      {
         mValidationListeners.remove(l);
      }
   }

   public final void validate()
   {
      try
      {
         mParentBeingValidated = true;
         
         RegionContextImpl regCtx = new RegionContextImpl(this, REFRESH_UNKNOWN);
         if (mRegionListeners != null) 
         {
            ArrayList al = (ArrayList)mRegionListeners.clone();
            for (int regIdx = 0; regIdx < al.size(); regIdx++) 
            {
               if (((RegionListener)al.get(regIdx)).validateRegion(regCtx) == false)
               {
                  try
                  {
                     //throw to get exception stack.
                     throw (new ValidationException(ADFmMessageBundle.class,
                                                   ADFmMessageBundle.EXC_REGION_LISTENER_VALIDATE,
                                                   new Object[]{
                                                      ((RegionListener)al.get(regIdx)).getName(),
                                                      new Integer(regIdx),
                                                      getName()}));
                  }
                  catch (ValidationException ve)
                  {
                     ve.setSource(this);
                     reportException(ve);
                  }
               }
            }
         }

         RegionBinding region;
         if (mRegionsList != null) 
         {
            for (int i = 0; i < mRegionsList.size(); i++) 
            {
               region = (RegionBinding)mRegionsList.get(i);
               if (region.getRegionController() == null) 
               {
                  region.validate();
               }
               else
               {
                  regCtx.internalSetRegion(region);
                  region.getRegionController().validateRegion(regCtx);
               }
            }
         }
      }
      finally
      {
         mParentBeingValidated = false;
      }
      validateInputValues();
   }

   /**
    * Calls DataControl.validate() for each data control that has a collection
    * to which an iterator binding in this container is bound to.
    */
   public void validateInputValues()
   {
      if ((getRegionContainer() != null) && getRegionContainer().mParentBeingValidated) 
      {
         return;
      }

      if (mTrackInputs > 0)
      {
         mTrackInputs = 0;
         
         ArrayList dcs = new ArrayList(5);
         collectNestedDCsForValidate(dcs);

         for (int i = 0; i < dcs.size(); i++)
         {
            try
            {
               ((DCDataControl)dcs.get(i)).validate();
            }
            catch (Exception e)
            {
               reportException((DCDataControl)dcs.get(i), e);
            }
         }
      }
      else
      {
         DCIteratorBinding iter;
         for (int i = 0; i < mIterBindingList.size(); i++)
         {
            iter = (DCIteratorBinding) mIterBindingList.get(i);
            if (!iter.isFindMode())
            {
               iter.doneInput();
            }
         }
      }
   }

   public PermissionInfo getPermissionInfo()
   {
      if (mPermissionInfo == null)
      {
         mPermissionInfo = new PermissionBinding(mBindingContainerDef.getFullName(), PermissionHelper.REGION_PERMISSION, getBindingContext());
      }
      return mPermissionInfo;
   }

   private void collectNestedDCsForValidate(ArrayList dcs)
   {
      mTrackInputs = 0;
      if (mExecutablesList == null) 
      {
         return;
      }

      DCDataControl iterDC;
      DCIExecutable iterObj;
      DCIteratorBinding iter;
      for (int i = 0; i < mExecutablesList.size(); i++)
      {
         iterObj = (DCIExecutable)mExecutablesList.get(i);
         int execType = iterObj.getExecutableType();
         if (execType == EXECUTABLE_REGION) 
         {
            if (iterObj instanceof DCBindingContainer) 
            {
               ((DCBindingContainer)iterObj).collectNestedDCsForValidate(dcs);
            }
         }
         else if (execType == EXECUTABLE_ITERATORBINDING)
         {
            iter = (DCIteratorBinding)iterObj;
            if (!iter.isFindMode())
            {
               iterDC = iter.getDataControl();
               if (iterDC != null && !dcs.contains(iterDC))
               {
                  dcs.add(iterDC);
               }
            }
            iter.doneInput();
         }
      }
   }

   /**
    * notify binding container that it needs to call validate on the datacontrols.
    */
   void prepareForInput()
   {
      if (getRegionContainer() != null)
      {
         getRegionContainer().prepareForInput();
      }
      else
      {
         mTrackInputs++;
      }
   }

   public void processInputValues(java.util.Map inputValues)
   {
      if (inputValues == null || inputValues.isEmpty())
      {
         return;
      }

      DCIteratorBinding iterBinding;
      ArrayList reservedBindings = null;
      try
      {
         // Iterate through all the values from the form and ony push the
         // the new ones to the model
         final Iterator iter = inputValues.keySet().iterator();
         while(iter.hasNext())
         {
            String propertyName = (String) iter.next();
            AttributeBinding binding = (AttributeBinding )findCtrlBinding(propertyName);

            Object  value = inputValues.get(propertyName);

            if (binding.processNewInputValue(value))
            {
               if (reservedBindings == null)
               {
                  reservedBindings = new ArrayList();
               }          
               iterBinding = ((DCControlBinding)binding).getDCIteratorBinding();
               iterBinding.internalReserveCurrentRow();
               reservedBindings.add(iterBinding);
               binding.setInputValue(value);
            }
         }
      }
      finally
      {
         if (reservedBindings != null)
         {
            for (int i = 0; i < reservedBindings.size(); i++)
            {
               iterBinding = (DCIteratorBinding)reservedBindings.get(i);
               iterBinding.releaseCurrentRow();
            }
         }
      }
   }


   /**
   * @internal *** For internal framework use only *** 
   */
   public String toString()
   {
      return getName();
   }

   /**
    * Matches a control-binding with the exception or one of it's detail exceptions if the
    * exception or one of it's detail excpetions is an AttrValException and the control-binding
    * is bound to that attribute.
    * <p>
    * If the bindingContext is in JClient mode, then this exception is thrown, otherwise
    * the exception is cached at the panelBinding level for the controller to get/access
    * during the page-rendering phase or before invoking the next action.
    *
    * @javabean.method name=processException
    */
   public void processException(JboException ex)
   {
      //first cache this exception if I do not already have it.
      //this will make sure next time this exception is processed
      //due to may a control trying to add it, I'd check
      //for it's existence before adding it again.
      cacheException (ex);
      
      if (ex.getSource() == this)
      {
         return;
      }
      
      Throwable[] jboExs = ex.getExceptions();
      
      if (jboExs != null)
      {
         for (int i = 0; i < jboExs.length; i++)
         {
            if (jboExs[i] instanceof JboException)
            {
               processException((JboException)jboExs[i]);
            }
         }
      }

      if (mExecutablesList != null) 
      {
         DCIExecutable iterObj;
         for (int i = 0; i < mExecutablesList.size(); i++)
         {
            iterObj = (DCIExecutable)mExecutablesList.get(i);
            int execType = iterObj.getExecutableType();
            if (execType == EXECUTABLE_REGION) 
            {
               if (iterObj instanceof DCBindingContainer) 
               {
                  ((DCBindingContainer)iterObj).processException(ex);
               }
            }
            else if (execType == EXECUTABLE_ITERATORBINDING)
            {
               ((DCIteratorBinding)iterObj ).processInputException(ex);
            }
         }
      }

      if (getBindingContext() != null)
      {
         if (getBindingContext().isGenericApp())
         {
            return;
         }
      }
      throw ex;
   }

   /**
    ** Returns a list of exceptions that has been cached on this bindingContainer.
    ** @javabean.property name=exceptionsList
    **/
   public ArrayList getExceptionsList()
   {
      ArrayList al = (ArrayList)DCUtil.getLocalizedExceptionsList(mExcs, getLocaleContext());
      if (mRegionsList != null)
      {
         ArrayList innerList;
         RegionBinding ctr;
         for (int i = 0; i < mRegionsList.size(); i++)
         {
            ctr = (RegionBinding)mRegionsList.get(i);
            if (ctr instanceof DCBindingContainer) 
            {
               innerList = ((DCBindingContainer)ctr).getExceptionsList();
               if (innerList != null && innerList.size() > 0)
               {
                  if (al == null)
                  {
                     al = new ArrayList();
                  }
                  al.addAll(innerList);
               }
            }
         }
      }
      return al;
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void cacheException (JboException ex)
   {
      if (mExcs == null)
      {
         mExcs = new ArrayList(5);
      }
      if (needToAddException(ex))
      {
         if (Diagnostic.isOn()) 
         {
            Diagnostic.println("* * * BindingContainer caching EXCEPTION:"+ex.getClass().getName());
            Throwable th[] = ex.getExceptions();
            if (th != null  && th.length > 0) 
            {
               Diagnostic.printStackTrace(th[0]);
            }
         }
         mExcs.add(ex);
      }
   }

   private boolean needToAddException(JboException ex)
   {
      if (mExcs.contains(ex))
      {
         return false;
      }

      JboException listEx;
      for (int i = 0; i < mExcs.size(); i++)
      {
         
         listEx = ((JboException)mExcs.get(i));
         if (listEx == ex)
         {
            return false;
         }

         if (listEx.containsException(ex))
         {
            return false;
         }
      }
      return true;
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void handleException(Exception ex, boolean lastEntryInPiggyback)
   {
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void handleWarning(JboWarning warn)
   {
      Diagnostic.println("Batch Warning:"+warn.getMessage());
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void finishedProcessingPiggyback(Exception[] exArr)
   {
      if(exArr != null && exArr.length > 0)
      {
         JboException jboEx = null;
         
         for (int i = 0; i < exArr.length; i++)
         {
            if (exArr[i] instanceof JboException)
            {
               jboEx = (JboException) exArr[i];
            }
            else
            {
               jboEx = new JboException(exArr[i]);
            }
            processException(jboEx);
         }
         throw jboEx;
      }
   }

   /**
    **/
   public boolean isErrorHandlerActive()
   {
      if (mDataControl != null)
      {
         return mDataControl.getErrorHandlerActive();
      }
      return true;
   }

   /**
    ** Sets the registered handler for exceptions into active/inactive mode.
    ** During inactive mode the handler is not supposed to 'display' a modal
    ** UI for the exceptions but simply report it on console/log and then 
    ** rethrow the exception.
    **/
   public void setErrorHandlerActive(boolean flag)
   {
      if (mDataControl != null)
      {
         mDataControl.setErrorHandlerActive(flag);
      }
      //not going to BindingContext or Metaobject manager
      //if this case is such that no adf stuff is created
      //we're already in fatal shape. Let multiple
      //errors show through in that case.
   }

   /**
    * Returns an ordered list of ViewObject usages in this panel so that a JboException parameters
    * can be transformed from Entity-layer names and exception parameters to ViewObject names and parameters.
    */
   protected ViewObject[] getOrderedVOUsageList(DCDataControl dc)
   {
      //sjvTBD:add executables here = to correct error strings.
      int size = mIterBindingList.size();
      ArrayList al = new ArrayList(size);
      ViewObject vo;
      DCIteratorBinding iter;
      for (int i = 0; i < size; i++) 
      {
         iter = ((DCIteratorBinding)mIterBindingList.get(i));
         if (iter.getDataControl() != dc)
         {
            continue;
         }
         vo = null;
         if (iter.hasRSI())
         {
            vo = iter.getViewObject();
         }
         else
         {
            oracle.adf.model.binding.DCIteratorBindingDef iterDef = iter.getDef();
            //we could live without this method/accessor check, but lets do this
            //for now to be safe.
            if (iterDef != null 
                && DCDefBase.PNAME_MethodIterator.equals(iterDef.getSubType())
                && DCDefBase.PNAME_AccessorIterator.equals(iterDef.getSubType())) 
            {
               boolean errorHandler = isErrorHandlerActive();
               try
               {
                  setErrorHandlerActive(false);
                  vo = iter.getViewObject();
               }
               catch (oracle.jbo.JboException je)
               {
                  //ignore = we are already in exception mode.
               }
               finally
               {
                  if (errorHandler)
                  {
                     setErrorHandlerActive(true);
                  }
               }
            }
         }
         if (vo != null && !al.contains(vo)) 
         {
            al.add(vo);
         }
      }
      return (ViewObject[])al.toArray(new ViewObject[al.size()]);
   }

   /**
    * Returns the container state token.
    * 
    */
   public String getStateTokenId()
   {
      return getName() + "State__";   //NOTRANS
   }
   
   /**
    * Returns the container state.
    * 
    */
   public String getStateToken()
   {
      return new DCBindingContainerState(this).toString();
   }
   
   /**
    * validates that this container is in the same state as represented by the given string token 
    */
   public void validateToken(String sState) 
   {
      try
      {
         DCBindingContainerState state =  new DCBindingContainerState(this);
         state.validateToken(sState);
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (Exception e)
      {
         throw new JboException(e);
      }
   }

   /**
   * *** For internal framework use only ***
   * Returns the DCApplciation object to which this form binding belongs.
   * This method is primarily for use in classic/direct bound JClient apps.
   */
   public DCDataControl getDataControl()
   {
      if (mDataControl == null && !DCUtil.inDesignTime())
      {
         //no need to go through nested containers as this is 
         //primarily for old jclient (preADF) support
         initializeApplicationModule();
         if (mDataControl == null)
         {
            DCIteratorBinding iter;
            for(int j = 0; j < mIterBindingList.size(); j++)
            {
               iter = ((DCIteratorBinding)mIterBindingList.get(j));
               mDataControl = iter.getDataControl();
               if (mDataControl != null)
               {
                  mDataProvider = mDataControl.getApplicationModule();
                  break;
               }
            }
         }
      }
      return mDataControl;
   }

   /**
   * *** For internal framework use only ***
    */
   protected DCDataControl internalGetDataControl()
   {
      return mDataControl;
   }

   /**
   * *** For internal framework use only ***
    */
   public Object findNamedObject(String expr)
   {
      return DCUtil.findSpelObject(this, expr, false);
   }

   public final int getExecutableType()
   {
      return DCIExecutable.EXECUTABLE_REGION;
   }

   public final String getFullName()
   {
      StringBuffer sBuff = new StringBuffer();

      if (getRegionContainer() != null) 
      {
         sBuff.append(getRegionContainer().getFullName());
      }
      else
      {
         sBuff.append(BindingContext.CONTEXT_ID);
      }

      sBuff.append(DCUtil.SEP_DOT_CHAR).append(getName());
      return sBuff.toString();
   }

   public RegionController getRegionController()
   {
      if (mRegionController == null && getDef() != null)
      {
         String clzName = getDef().getControllerClassName();
         if (clzName != null) 
         {
            mRegionController = (RegionController)JBOClass.newInstance(clzName);
         }
      }
      return mRegionController;
   }

   public Object getActionProcessor()
   {
      if (mActionProcessor == null && getDef() != null) 
      {
         String clzName = getDef().getActionProcessorClassName();
         if (clzName != null) 
         {
            mActionProcessor = JBOClass.newInstance(clzName);
         }
      }
      return mActionProcessor;
   }

   public final boolean hasRefreshParametersChanged()
   {
      return true;
   }

   public DCIExecutableDef getExecutableDef()
   {
      return getDef();
   }

   public final boolean hasVariables()
   {
      return (getVariableManager() != null);
   }
   
   public final VariableValueManager getVariableManager()
   {
      VariableManagerOwner varMgrOwner = getVariableManagerOwner();
      return (varMgrOwner != null) ? varMgrOwner.getVariableManager() : null;
   }

   protected VariableManagerOwner getVariableManagerOwner()
   {
      Object obj;
      for (int i = 0; i < mIterBindingList.size(); i++) 
      {
         obj = mIterBindingList.get(i);
         if (obj.getClass().getName().equals("oracle.jbo.uicli.binding.JUVariableIteratorBinding")) 
         {
            //this variable manager needs to be ensured if it has declared variables.
            return (VariableManagerOwner)obj;
         }
      }
      return null;
   }


   public VariableValueManager ensureVariableManager()
   {
      //implemented by JUFormBinding
      return null;
   }

   public final Class getMessageBundleClass()
   {
      return getDef().getMessageBundleClass();
   }

   public final int getTransientRefreshFlag()
   {
      return mTransientRefreshType;
   }

   private static final String NO_VARIABLE_INDICATOR = "%V%=N"; //nonls
   private static final String VARIABLE_DELIMITER= ";#;"; //nonls
   private static final String VARIABLES_END_DELIMITER= ":#:"; //nonls
   void buildFormToken(StringBuffer buffer)
   {
      //save variable values.
      if (!hasVariables()) 
      {
         buffer.append(NO_VARIABLE_INDICATOR);
      }
      else
      {
         StringBuffer buf = new StringBuffer(VARIABLE_DELIMITER);
         VariableValueManager varMgr = ensureVariableManager();
         Variable[] vars = varMgr.getVariables();
         Object varVal;
         for (int i = 0; i < vars.length; i++) 
         {
            varVal = varMgr.getVariableValueRaw(vars[i], false);
            if (varVal != null) 
            {
               if (varVal instanceof oracle.jbo.domain.NullValue) 
               {
                  buf.append(vars[i].getName()).append('=').append(VARIABLE_DELIMITER);
               }
               else
               {
                  buf.append(vars[i].getName()).append('=').append(varVal).append(VARIABLE_DELIMITER);
               }
               if (Diagnostic.isOn()) 
               {
                  Diagnostic.println("Tokenizing Variable:"+vars[i].getName()+'='+varVal);
               }
            }
         }
         if (buf.length() > 3) 
         {
            buffer.append(buf);
            buffer.append(VARIABLES_END_DELIMITER);
         }
      }
   }

   String processFormToken(String state)
   {
      if (state.startsWith(NO_VARIABLE_INDICATOR)) 
      {
         return state.substring(NO_VARIABLE_INDICATOR.length());
      }

      String retState = state;
      if (state.startsWith(VARIABLE_DELIMITER)) 
      {
         int index = state.indexOf(VARIABLES_END_DELIMITER);
         
         retState = state.substring(index+3);
         state = state.substring(0, index);

         StringTokenizer tokens = new StringTokenizer(state , VARIABLE_DELIMITER, false); //NOTRANS
         VariableValueManager varMgr = ensureVariableManager();
         String sToken = state;
         while(tokens.hasMoreTokens())
         {
            sToken = tokens.nextToken();
            if(sToken == null)
            {
               break;
            }
            int nIndex = sToken.indexOf('=');
            if(nIndex != -1)
            {
               String sIteratorId = sToken.substring(0, nIndex);
               String sKeyValue = sToken.substring(nIndex + 1);
               if (Diagnostic.isOn()) 
               {
                  Diagnostic.println("Restore Variable:"+sIteratorId+'='+sKeyValue);
               }
               varMgr.setVariableValue(sIteratorId, sKeyValue);
            }
         }
      }

      return retState;
   }
}
