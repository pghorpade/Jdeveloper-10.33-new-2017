package oracle.adf.model.binding;

/* $Header: DCVariableResolverImpl.java 15-aug-2005.17:48:03 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    08/15/05 - 
    alai        07/22/05 - 
    jsmiljan    04/15/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/22/05 - Creation
 */

import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.VariableResolver;

import oracle.adf.model.BindingContext;

import oracle.binding.BindingContainer;

import oracle.adf.share.ADFContext;

/**
 *  This class may be used with an {@link oracle.adf.share.el.ADFExpressionEvaluator}
 *  to resolve root variables names against a {@link oracle.adf.model.BindingContext}.
 *  <p>
 *  When constructed with a BindingContainer reference this class will
 *  resolve the {@link oracle.adf.model.BindingContext#RESERVED_BINDINGS}
 *  symbol to the specified BindingContainer instance.
 *  <p>
 *  @version $Header: DCVariableResolverImpl.java 15-aug-2005.17:48:03 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
class DCVariableResolverImpl implements VariableResolver
{   
   private final BindingContext mContext;
   private final BindingContainer mBindingContainer;

   DCVariableResolverImpl(
      BindingContext context, BindingContainer bindingContainer)
   {
      mContext = context;
      mBindingContainer = bindingContainer;
   }

   DCVariableResolverImpl(BindingContext context)
   {
      this(context, null);
   }

   public Object resolveVariable(String name) throws ELException
   {
      Object rtn = null;

      if (mBindingContainer != null
         && BindingContext.RESERVED_BINDINGS.equals(name))
      {
         rtn = mBindingContainer;
      }
      else
      {
         rtn = mContext.get(name);
      }

      // If the binding resolver can't find it then delegate to the 
      // ADFContext variable resolver
      if (rtn == null)
      {
         Object vr = ADFContext.getCurrent().getVariableResolver();
         if (vr instanceof VariableResolver)
         {
             rtn = ((VariableResolver)vr).resolveVariable(name);
         }
      }

      return rtn;
   }
}

