/*
 * @(#)JUPanelValidationEvent.java
 *
 * Copyright 2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.EventObject;
import oracle.adf.model.OperationInfo;

public class DCInvokeMethodEvent extends EventObject
{

   private Object mInstance;
   private Object[] mArgs;
   
   public DCInvokeMethodEvent(DCInvokeMethod source, Object instance, Object[] args)
   {
      super(source);
      mArgs = args;
      mInstance = instance;
   }


   public final OperationInfo getMethodInfo()
   {
      return (DCInvokeMethod)getSource();
   }

   public final Object getInvokeInstance()
   {
      return mInstance;
   }

   public final Object[] getInvokeArgs()
   {
      return mArgs;
   }
}

