package oracle.adf.model.binding;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidParamException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.RepConversion;
import oracle.jbo.uicli.mom.JUMetaObjectBase;

import oracle.adf.model.RegionBinding;
import oracle.adf.model.ADFmMessageBundle;

/**
 * This class can capture the iterator state for a binding container. This state may then be restored in
 * order to set iterator binding currency to when the state was captured.
 */
public class DCBindingContainerState 
{
   private static final String STATE_PREFIX = "BCST:";
   static final String STATE_TOKEN_DELIMITER = ",";
   
   private DCBindingContainer _container;
   
   public DCBindingContainerState(DCBindingContainer container)
   {
      _container = container;
   }
   
   static char FIND_MODE_CHAR = '1';
   static char DATA_MODE_CHAR = '0';
   /**
    * Builds the string buffer containing the encoded iterator id + current row key
    */
   private StringBuffer buildStringBuffer()
   {
      StringBuffer buffer = new StringBuffer(STATE_PREFIX);
      buffer.append('=').append((_container.isFindMode()) ? FIND_MODE_CHAR : DATA_MODE_CHAR);

      //bring this back when we have usecase to carry over variable values
      //across requests.
      _container.buildFormToken(buffer);
      
      /*
      ArrayList list = _container.getAllIterBindingList();
      for(int i = 0 ; i < list.size(); i++)
      {
         DCIteratorBinding iterator = (DCIteratorBinding)list.get(i);
         iterator.buildFormToken(buffer, _container.isTokenValidationEnabled());
      }
      */
      
      List list = _container.getIterBindingList();
      for(int i = 0 ; i < list.size(); i++)
      {
         DCIteratorBinding iterator = (DCIteratorBinding)list.get(i);
         iterator.buildFormToken(buffer, _container.isTokenValidationEnabled());
      }

      list = _container.getRegionBindings();
      if (list != null) 
      {
         String str; 
         for(int i = 0 ; i < list.size(); i++)
         {
            RegionBinding ctr = (RegionBinding)list.get(i);
            if (ctr.isTokenValidationEnabled()) 
            {
               buffer.append(ctr.getName())
                        .append('=')
                        .append(ctr.getStateToken())
                        .append(STATE_TOKEN_DELIMITER);
            }
         }

      }
      return buffer;
   }
   
   byte[] compressBuffer(StringBuffer buffer) throws Exception
   {
      ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
      DeflaterOutputStream out = new DeflaterOutputStream(byteStream);
      
      byte data [] = buffer.toString().getBytes();
      out.write(data);
      out.flush();
      out.close();
      
      byte cdata[] = byteStream.toByteArray();
      return cdata;
   }
   
   String decompressBytes(byte [] bytes) throws Exception
   {
      ByteArrayInputStream byteStream = new ByteArrayInputStream(bytes);
      InflaterInputStream in = new InflaterInputStream(byteStream);
      
      StringBuffer buffer = new StringBuffer();
            
      try
      {
         int c = in.read();
         while(c != -1)
         {
            buffer.append((char)c);
            c = in.read();
         }
      }
      finally
      {
         in.close();
      }
      return buffer.toString();
   }
   
   
   /**
    * Builds a map of all the iterators that need to be restored. 
    */
   private HashMap buildMap(String sState)
   {
      HashMap         map = new HashMap();
      StringTokenizer tokens = new StringTokenizer(sState , STATE_TOKEN_DELIMITER, false); //NOTRANS
      
      while(tokens.hasMoreTokens())
      {
         String sToken = tokens.nextToken();
         if(sToken == null)
            break;
            
         int nIndex = sToken.indexOf('=');
         if(nIndex != -1)
         {
            String sIteratorId = sToken.substring(0, nIndex);
            String sKeyValue = sToken.substring(nIndex + 1);
            
            Object ctrObj = _container.get(sIteratorId);

            if(ctrObj == null)
            {
                throw new InvalidObjNameException(JUMetaObjectBase.TYP_DEF_ITER_BINDING,
                                              sIteratorId);
            }
            map.put(sIteratorId, sKeyValue);
         }
      }
      return map;
   }
   
   /**
    * Restores a single iterator
    */
   private void restoreIterator(HashMap map, DCIteratorBinding iterator) throws Exception
   {
      String            sKeyValue = (String)map.get(iterator.getName());
      
      if(sKeyValue == null)
      {
         //we already processed this iterator
         return;
      }
       
      iterator.setCurrentRowWithKey(sKeyValue);
      if(iterator.getCurrentRow() == null)
      {
         throwRowNotFoundException(iterator , iterator.parseKeyValue(sKeyValue));
      }
      map.remove(iterator.getName());
   }
   
   private void throwRowNotFoundException(DCIteratorBinding iterator , String sKey)
   {
      Object objs[] = new Object[1];
      if (sKey != null && sKey.length() > 0)
      {
         Key key = iterator.createKey(sKey);
         if (key != null)
         {
            objs[0] = key.toString();
         }
         else
         {
            objs[0] = null;
         }
      }
      else
      {
         objs[0] = null;
      }
      throw new JboException(ADFmMessageBundle.class, 
               ADFmMessageBundle.EXC_UNEXPECTED_CURRENT_ROW, objs);      
   }
   
    /**
    * validate a single iterator
    */
   private void validateIterator(HashMap map, DCIteratorBinding iterator, Map newRowMap) throws Exception
   {
      String            sKeyValue = (String)map.get(iterator.getName());
      
      if(sKeyValue == null)
      {
         //we already processed this iterator
         return;
      }
      
      if (iterator.processFormToken (sKeyValue, newRowMap))
      {
         map.remove(iterator.getName());
      }
      else
      {
         throwRowNotFoundException(iterator , iterator.parseKeyValue(sKeyValue));
      }
   }
   
   /**
    * Builds the hierarchy for an accessor iterator. The parent iterators will be first
    * in the array list so that the caller can process them in the correct order.
    */
   private ArrayList buildHierarchy(DCIteratorBinding iterator)
   {
      ArrayList names = new ArrayList();
            
      names.add(iterator);
      
      // add the parent iterators to the beginning of the list
      oracle.jbo.uicli.binding.JUAccessorIteratorDef def = (oracle.jbo.uicli.binding.JUAccessorIteratorDef)iterator.getDef();
      String sMaster = def.getMasterBindingName();
      
      while(sMaster != null)
      {
         DCIteratorBinding masterIter = _container.findIteratorBinding(sMaster);
         
         if(masterIter == null)
         {
            throw new InvalidObjNameException(JUMetaObjectBase.TYP_DEF_ITER_BINDING,
                                        sMaster);
         }
         names.add(0, masterIter);
         
         sMaster = null;
         
         if(masterIter.isAccessorIterator())
         {
            oracle.jbo.uicli.binding.JUAccessorIteratorDef mdef = (oracle.jbo.uicli.binding.JUAccessorIteratorDef)masterIter.getDef();
            sMaster = mdef.getMasterBindingName();
         }
      }
      return names;
   }
   
   /**
    * This is where it all starts. Iterators are restored until the map is empty.
    */
   private void restoreStateFromString(String sState) throws Exception
   {
      if(sState == null || !sState.startsWith(STATE_PREFIX))
      {
         throw new InvalidParamException("restoreStateFromString", "sState", sState); //NOTRANS
      }
      
      sState = sState.substring(STATE_PREFIX.length());
      
      HashMap map = buildMap(sState);
      
      while(!map.isEmpty())
      {
         String            sIteratorId = (String)map.keySet().iterator().next();
         
         Object ctrObj = _container.get(sIteratorId);
         if (ctrObj instanceof DCIteratorBinding) 
         {
            DCIteratorBinding iterator = (DCIteratorBinding)ctrObj;

            if(iterator.isAccessorIterator())
            {
               // build iterator name list
               ArrayList iterators = buildHierarchy(iterator);

               for(int i = 0; i < iterators.size(); i++)
               {
                  restoreIterator(map, (DCIteratorBinding)iterators.get(i));
               }
            }
            else
            {
              restoreIterator(map, iterator);
            }
         }
         else if (ctrObj instanceof DCBindingContainer)
         {
            new DCBindingContainerState((DCBindingContainer)ctrObj).restoreState((String)map.get(sIteratorId));
         }
         else if (Diagnostic.isOn())
         {
            Diagnostic.println("Unable to restore state for :"+sIteratorId);
         }
      }
   }
   
    /**
    * This is where it all starts. Iterators are restored until the map is empty.
    */
   private void validateStateFromString(String sState) throws Exception
   {
      if(sState == null || !sState.startsWith(STATE_PREFIX))
      {
         throw new InvalidParamException("restoreStateFromString", "sState", sState); //NOTRANS
      }
      
      if (sState.length() == STATE_PREFIX.length())
      {
         return;
      }

      boolean setContainerToFind = (sState.charAt(STATE_PREFIX.length() + 1) == FIND_MODE_CHAR);
      sState = sState.substring(STATE_PREFIX.length()+2);
      
      //bring this back when we have usecase to carry over variable values
      //across requests.
      sState = _container.processFormToken(sState);
      
      HashMap map = buildMap(sState);
      
      //pass in this map so that any new rows that need to be
      //inserted is collected per iterator binding and added
      //later to the collections after all validation is done.
      HashMap newRowMap = new HashMap(map.size());
      
      while(!map.isEmpty())
      {
         String            sIteratorId = (String)map.keySet().iterator().next();
         
         Object ctrObj = _container.get(sIteratorId);
         if (ctrObj instanceof DCIteratorBinding) 
         {
            DCIteratorBinding iterator = (DCIteratorBinding)ctrObj;
         
            if(iterator.isAccessorIterator())
            {
               // build iterator name list
               ArrayList iterators = buildHierarchy(iterator);
               
               for(int i = 0; i < iterators.size(); i++)
               {
                  validateIterator(map, (DCIteratorBinding)iterators.get(i), newRowMap);
               }
            }
            else
            {
              validateIterator(map, iterator, newRowMap);
            }
         }
         else if (ctrObj instanceof RegionBinding) 
         {
            ((RegionBinding)ctrObj).validateToken((String)map.get(sIteratorId));
            map.remove(sIteratorId);
         }
      }

      if (newRowMap.size() > 0)
      {
         Iterator iter = newRowMap.keySet().iterator();
         DCIteratorBinding iterBind;
         while (iter.hasNext())
         {
            iterBind = (DCIteratorBinding)iter.next();

            // bug 4756026.  why would we insert the row now and
            // transition the row to STATUS_NEW? this was not the state
            // that the iterator binding was left in.  using cacheCreatedRow
            // here instead to restore the mCreatedRef and cache in the DC.
            //
            // Discovered a regression of this change in guava.region.sv02.
            // The issue is that ADFm assumes that the next request will
            // cause a set on this row so, it assumes that it can just
            // go ahead and insert the row.  However, as you can see from the
            // bug it is not always the case that the next request will
            // cause an attribute set -- thus my change.  However, now we
            // are in a situation where the row will never get inserted and
            // set as current.  Fixed this by adding logic to the 
            // beforeAttributeSet handler in DCBindinContainer.  This new
            // logic will invoke DCIteratorBinding.insertCreatedRow()
            // immediately before the first set is called.
            //iterBind.findAndInsertNewRow((oracle.jbo.Row)newRowMap.get(iterBind));
            iterBind.cacheCreatedRow(iterBind.getRowSetIterator()
               , (oracle.jbo.Row)newRowMap.get(iterBind));
         }
      }
      if (setContainerToFind)
      {
         Diagnostic.println("Setting back to findmode based on validation token");
         _container.setFindMode(true);
      }
   }
   
   public void restoreState(String sState)
   {
      try
      {
         byte [] origBytes = RepConversion.nibbles2bArray(sState.getBytes());
         String sValue = decompressBytes(origBytes);
         
         Diagnostic.println("restoreState:Decompressed BC state:" + sValue);
         
         restoreStateFromString(sValue);
      }
      catch (Exception e)
      {
         Diagnostic.printStackTrace(e);
      }
   }
   
   public void validateToken(String sState) throws Exception
   {
      try
      {
         if (sState == null)
         {
            return;
         }
         byte [] origBytes = RepConversion.nibbles2bArray(sState.getBytes());
         String sValue = decompressBytes(origBytes);
         
         Diagnostic.println("valiateToken:Decompressed BC state:" + sValue);
         
         validateStateFromString(sValue);
      }
      catch (Exception e)
      {
         Diagnostic.printStackTrace(e);
         throw e;
      }
   }
   
   public String toString()
   {
      StringBuffer buffer = buildStringBuffer();
      
      try
      {
         byte data [] = compressBuffer(buffer);
         
         String sRet =  RepConversion.bArray2String(data);
         
         return sRet;
      }
      catch (Exception e)
      {
         Diagnostic.printStackTrace(e);
      }
      
      return null;
   }
}
