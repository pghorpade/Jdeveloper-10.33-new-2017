/*
 * @(#)DCStatusBarInterface.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

/**
 * Implements status messages based on the current focus, current iterator, and current display mode of 
 * a DCPanel. Various JClient control bindings and Panel bindings use this interface to update
 * their status and the classes implementing this interface (typically a StatusBar) can display
 * these status messages. Messages that are MsgId0based could be found in UIMessageBundle class.
 * <p>
 * Applications could implement this interface to manage focus, currency and display status messages
 * in a custom manner and register the implementing class with a DCPanelBinding to get these messages.
 * <p>
 * @see oracle.jbo.uicli.UIMessageBundle
 */
public interface DCStatusBarInterface
{
   /**
   * This event is sent out by a DCCtrlBinding when the associated control comes into focus.
   * @param iterBinding The Iterator that the control-binding is working with.
   * @param controlBinding Identifies which control is coming into focus.
   * @param attrIndex Index of the attribute in the DCCtrlBinding that is current/in focus.
   * The value for this index could be -1 if a composite control that is working with a ViewObject
   * or RowIterator comes in focus (like a JTree/JTable/DCNavigationBar).
   */
   void focusGained(DCIteratorBinding iterBinding, DCControlBinding controlBinding, int attrIndex);
   
   /**
   * This event is sent out by the framework to display a message in oracle.jbo.uicli.UIMessageBundle
   * of the given msgId with the given set of parameters. 
   * @param iterBinding Current IteratorBinding object for the control that sends this message.
   * @param msgId String ID of a message from UIMessageBundle to display.
   * @param params Parameters that the message needs to format an appropriate display.
   */
   void displayStatus(DCIteratorBinding iterBinding, String msgId, Object[] params);

   /**
   * Applications can invoke to display any custom messages in the status bar(s).
   */
   void displayStatus(String msg);

   /**
    * Framework calls this method when it needs to indicate that the connection to BC4J is being released. 
    */
   void release();

}
