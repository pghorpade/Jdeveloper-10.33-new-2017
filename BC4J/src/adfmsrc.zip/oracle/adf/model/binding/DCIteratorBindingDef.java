/*
 * @(#)DCIteratorBindingDef.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.HashMap;

import oracle.adf.model.BindingContext;

import oracle.jbo.ApplicationModule;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;
import oracle.jbo.SortCriteria;
import oracle.jbo.SortCriteriaImpl;

import com.sun.java.util.collections.ArrayList;

abstract public class DCIteratorBindingDef extends DCExecutableBindingDef 
{
   private String mAMName;
   private String mBindsName;
   private String mRSIName;
   private String mDCName;
   private String mDesignTimeClass;
   private boolean mObjectType;
   SortCriteria[] mSortCriterias;
   
   boolean mSortable = true;

   protected int mRangeSize = DCIteratorBinding.RANGESIZE_UNLIMITED; 
   private boolean mIsCacheResults = true;
   
   public static final String PNAME_RangeSize = JUTags.RangeSize;
   public static final String PNAME_TYPE = PNAME_Iterator;
   static final String PNAME_SortOn = JUTags.PNAME_SortOn;
   static final String PNAME_Ascending = JUTags.PNAME_Ascending;

   static final int TOKEN_VALIDATION_ON = 0;
   static final int TOKEN_VALIDATION_OFF = 1;
   int mValCur   = TOKEN_VALIDATION_ON;
   
   public DCIteratorBindingDef()
   {
      setSubType(PNAME_Iterator);
   }

   protected byte getLevel()
   {
      return 0;
   }


   public DCIteratorBindingDef(String name, String amName, String voName, String rsiName, int rangeSize)
   {
      super(name);
      setSubType(PNAME_Iterator);
      mAMName = amName;
      mBindsName = voName;
      mRSIName = rsiName;
      mRangeSize = rangeSize;
   }

   public String getDesignTimeClass()
   {
      return mDesignTimeClass;
   }
        
   public SortCriteria[] getSortCriteria()
   {
       return mSortCriterias;
   }

   public void init(HashMap initValues)
   {
      super.init(initValues);
      
      Object val;

      if ((val = initValues.get(JUTags.PNAME_AMName)) != null)
      {
         mAMName = val.toString();
      }

      if ((val = initValues.get(JUTags.PNAME_VOName)) != null)
      {
         mBindsName = val.toString();
      }

      if ((val = initValues.get(JUTags.PNAME_RSIName)) != null)
      {
         mRSIName = val.toString();
      }
      
      if ((val = initValues.get(PNAME_RangeSize)) != null)
      {
         mRangeSize = convertToInt(val);
      }
      
      if ((val = initValues.get(JUTags.DataControl)) != null)
      {
         mDCName = val.toString();
      }

      if ((val = initValues.get(JUTags.PNAME_Sortable)) != null)
      {
         mSortable = convertToBoolean(val);
      }

      if ((val = initValues.get(JUTags.PNAME_IterTokenValidation)) != null)
      {
         setStateValidationEnabled(convertToBoolean(val));
      }

      if ((val = initValues.get(JUTags.DesignTimeClass)) != null)
      {
         mDesignTimeClass = val.toString();
      }

      if ((val = initValues.get(JUTags.PNAME_CacheResults)) != null)
      {
         mIsCacheResults = convertToBoolean(val);
      }
        
      Boolean obj = (Boolean)initValues.get(JUTags.ObjectType);
      mObjectType = (obj != null) ? obj.booleanValue() : false;
   }
   
   public boolean isObjectType()
   {
      return mObjectType;
   }

   public int getRangeSize()
   {
      return mRangeSize;
   }

   public boolean isSortable()
   {
      return mSortable;
   }

   public boolean isCacheResults()
   {
      return mIsCacheResults;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * 
    */
   public boolean isStateValidationEnabled()
   {
      return mValCur == TOKEN_VALIDATION_ON;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setStateValidationEnabled(boolean enable)
   {
      mValCur = (enable) ? TOKEN_VALIDATION_ON : TOKEN_VALIDATION_OFF;
   }

   public void setBindingContainerDef(DCBindingContainerDef formDef)
   {
      super.setParent(formDef);
   }
   
   public String getAMName()
   {
      return mAMName;
   }

   public String getBindsName()
   {
      return mBindsName;
   }

   public String getRSIName()
   {
      return mRSIName;
   }

   public String getXMLElementTag()
   {
      return PNAME_TYPE;
   }
   
   public String getDataControlName()
   {
      return mDCName;
   }

   public int getExecutableType()
   {
      return EXECUTABLE_ITERATORBINDING;
   }

   boolean isAccessorType()
   {
      return getSubType().equals(PNAME_AccessorIterator);  
   }

   boolean isMethodType()
   {
      return getSubType().equals(PNAME_MethodIterator);  
   }

   abstract public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bindingContainer, ApplicationModule anchorAM);
   abstract public DCIteratorBinding createIterBinding(BindingContext ctx, DCBindingContainer bindingContainer);

   
   protected void retrieveFromXML(DefElement xmlElement, HashMap valueTab)
   {
      super.retrieveFromXML(xmlElement, valueTab);
      
      readXMLString(xmlElement, JUTags.PNAME_AMName, valueTab);
      readXMLString(xmlElement, JUTags.PNAME_VOName, valueTab);
      readXMLString(xmlElement, JUTags.PNAME_RSIName, valueTab);
      readXMLInt(xmlElement, PNAME_RangeSize, valueTab);
      readXMLString(xmlElement, JUTags.DesignTimeClass, valueTab);
      readXMLString(xmlElement, JUTags.DataControl, valueTab);
      readXMLBoolean(xmlElement, JUTags.ObjectType, valueTab);
      readXMLBoolean(xmlElement, JUTags.PNAME_Sortable, valueTab);
      readXMLBoolean(xmlElement, JUTags.PNAME_IterTokenValidation, valueTab);
      readXMLBoolean(xmlElement, JUTags.PNAME_CacheResults, valueTab);
   }

   public void loadChildrenFromXML(DefElement xmlElement)
   {
      super.loadChildrenFromXML(xmlElement);

      com.sun.java.util.collections.ArrayList sortCol = 
            xmlElement.getChildrenList(JUTags.PNAME_SortCriteriaCollection);

      if (sortCol.size() > 0)
      {
         DefElement sortcolDefXML = (DefElement) sortCol.get(0);
         com.sun.java.util.collections.ArrayList sortEntries
                 = sortcolDefXML.getChildrenList(JUTags.PNAME_SortCriteria);

         mSortCriterias = new SortCriteria[sortEntries.size()];
         if (sortEntries.size() > 0)
         {
            SortCriteria sortBy;
            String ascStr;
            boolean asc;
            for (int i=0; i < sortEntries.size(); i++) 
            {
               asc = true;
               DefElement sortByElem = (DefElement) sortEntries.get(i);
               ascStr = sortByElem.readString(PNAME_Ascending);
               if (ascStr != null) 
               {
                  asc = Boolean.valueOf(ascStr).booleanValue(); 
               }
               mSortCriterias[i] = new SortCriteriaImpl(
                            sortByElem.readString(PNAME_SortOn), 
                            !asc);
            }
         }

      }
   }

   public Object createExecutableBinding(BindingContext ctx, DCBindingContainer bc)
   {
      DCIteratorBinding iter = createIterBinding(ctx, bc, null);
      iter.setDef(this);
      iter.setRefreshOption(getRefreshOption());
      iter.setRefreshExpression(getRefreshExpression());

      return iter;
   }

   protected String getPermissionTargetName()
   {
      String bindsName = getBindsName();

      if (bindsName == null || mDCName == null) 
      {
         return null;
      }

      StringBuffer strBuf = new StringBuffer();
      strBuf.append(mDCName).append('.');;

      if (bindsName.equals("root")) //NOTRANS
      {
         strBuf.append(mDCName);
      }
      else 
      {
	 if (bindsName.endsWith(".result")) //NOTRANS
	 {
	     strBuf.append(bindsName.substring(0, bindsName.lastIndexOf('.')));
	 }
	 else
	 {
	     strBuf.append(bindsName);
	 }
      
      }
      return strBuf.toString();
   }

   protected String getPermissionClassName()
   {
      return PermissionHelper.getPermissionClassName(PermissionHelper.ROWSET_PERMISSION);
   }
}
