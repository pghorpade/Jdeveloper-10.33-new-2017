/*
 * @(#)DCInvokeMethodDef.java
 *
 * Copyright 2003-2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.model.binding;
import java.beans.MethodDescriptor;

import java.lang.reflect.InvocationTargetException;

import java.util.ArrayList;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.generic.BeanUtils;
import oracle.adf.model.generic.RowImpl;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.Exportable;
import oracle.jbo.InvalidObjAccessException;
import oracle.jbo.InvalidObjNameException;
import oracle.jbo.InvalidOperException;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.Diagnostic;


/**
 * Implements metadata and logic to invoke a custom action binding method.
 * <p>
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class DCInvokeMethodDef implements Cloneable, oracle.adf.model.OperationInfo
{
   String instanceName;
   String methodName;
   String returnName;
   DCMethodParameterDef[] args = new DCMethodParameterDef[0]; // must be initialized
   MethodDescriptor method;
   String mCachedParamsName;
   String    instanceClassName;
   //String    returnType;
   DCBindingContainer mBC;
   boolean   mIsViewObjectMethod;
   boolean   mIsLocalObjectReference;
   
   /**
    * <b>Internal:</b> <em>Applications should not use this constructor.</em>
    */
   public DCInvokeMethodDef(String instName, 
                            String mthName, 
                            String[] types, 
                            String[] vals, 
                            String[] options, 
                            String retName, 
                            String sInstClassName, 
                            /*String sReturnType,*/
                            Boolean bIsViewObjectMethod,
                            Boolean   bIsLocalObjectReference)
   {
      instanceName = instName;
      methodName   = mthName;
      args = new DCMethodParameterDef[types.length];
      int optionVal;
      for (int i = 0; i < types.length; i++)
      {
         args[i] = new DCMethodParameterDef((new Integer(i)).toString(),
                                            types[i],
                                            vals[i], 
                                            (options != null) ? Integer.valueOf(options[i]).intValue() : DCMethodParameterDef.DEFAULT);
      }

      returnName   = retName;
      instanceClassName    = sInstClassName;
      //returnType   = sReturnType;
      mIsViewObjectMethod = (bIsViewObjectMethod != null) ? bIsViewObjectMethod.booleanValue() : false;
      mIsLocalObjectReference = (bIsLocalObjectReference != null) ? bIsLocalObjectReference.booleanValue() : false;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this constructor.</em>
    */
   public DCInvokeMethodDef(String instName, 
                            String mthName, 
                            DCMethodParameterDef[] params,
                            String retName, 
                            String sInstClassName, 
                            /*String sReturnType,*/
                            Boolean bIsViewObjectMethod,
                            Boolean   bIsLocalObjectReference)
   {
      instanceName = instName;
      methodName   = mthName;
      args = params;
      returnName   = retName;
      instanceClassName    = sInstClassName;
      mIsViewObjectMethod = (bIsViewObjectMethod != null) ? bIsViewObjectMethod.booleanValue() : false;
      mIsLocalObjectReference = (bIsLocalObjectReference != null) ? bIsLocalObjectReference.booleanValue() : false;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setIsViewObjectMethod(boolean bSet)
   {
      mIsViewObjectMethod = bSet;   
   }
   
   
   public boolean getIsLocalObjectReference()
   {
      return mIsLocalObjectReference;
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean getIsViewObjectMethod()
   {
      return mIsViewObjectMethod;   
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setArguments(DCMethodParameterDef[] props)
   {
      args = props;
   }

   public void setBindingContainer(DCBindingContainer bc)
   {
      mBC = bc;
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setArgumentTypes(String[] types)
   {
      throw new UnsupportedOperationException("DCInvokeMethodDef.setArgumentTypes");
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setArgumentValues(String[] vals)
   {
      throw new UnsupportedOperationException("DCInvokeMethodDef.setArgumentTypes");
   }

   public Object callMethod (DCDataControl dc, ArrayList params)
   {
      if (dc == null)
      {
         if (mBC != null)
         {
            dc = mBC.getDataControl();
         }
         if (dc == null)
         {
            throw new UnsupportedOperationException("DCInvokeMethodDef.null datacontrol");
         }
      }
      Object retVal = dc.invokeMethod(this, params);
      BindingContext ctx = dc.getBindingContext();
      if ((returnName != null) && (ctx != null))
      {
         // should use expression engine here.
         DCUtil.putValueInPath(ctx, returnName, retVal);
      }
      return retVal;
   }

   static Object resolveAsExpression(Object bindingContext, Object rootObj, String expression)
   {
      if (!(expression.startsWith(DCUtil.EL_start) && expression.endsWith(DCUtil.EL_end))) 
      {
         //convert by adding elexpression syntax
         expression = (new StringBuffer()
                      .append(DCUtil.EL_start)
                      .append(expression)
                      .append(DCUtil.EL_end))
                      .toString();
      }
      return DCUtil.elEvaluate(bindingContext, rootObj, expression);
   }

   
   Object invokeMethod (DCDataControl dc, ArrayList params)
   {
      BindingContext ctx = dc.getBindingContext();
      if (ctx == null)
      {
         throw new InvalidObjAccessException("BindingContext", null); //NONLS
      }

      if (instanceName == null)
      {
         throw new InvalidObjNameException("instanceName", instanceName);  //NONLS
      }

      Object instance;

      if (!this.getIsViewObjectMethod())
      {
         //TODO:if it's a new expression, then we need to store that it's a static
         //value and hence not call resolveAsExpression.
         instance = (mIsLocalObjectReference && mBC != null) 
                        ? resolveAsExpression(ctx, mBC, instanceName)
                        : resolveAsExpression(ctx, ctx, instanceName);

         if (instance instanceof oracle.adf.model.generic.RowImpl)
         {
            instance = ((RowImpl)instance).getDataProvider();
         }
      }
      else
      {
         instance = dc.getApplicationModule().findViewObject(instanceName);
      }

      int i;
      int argsize = (args != null) ? args.length : 0;

      try
      {
         if (method == null && !(instance instanceof Exportable))
         {
            Class[] argClasses = new Class[argsize];
            for (i = 0; i < argsize; i++)
            {
               argClasses[i] = args[i].getType();
            }
            java.lang.reflect.Method mth = JboNameUtil.findMethod( //instance.getClass(), 
                                                                     (instanceClassName != null) ? JBOClass.forName(instanceClassName) : instance.getClass(),
                                                                     methodName,     
                                                                     argClasses,
                                                                     null);
            if (mth == null)
            {
               throw new InvalidOperException(CSMessageBundle.class,
                                              CSMessageBundle.EXC_INVALID_METHOD_CALL,
                                              new Object[] { instanceName+"."+methodName+"()" });
            }

            method = new MethodDescriptor(mth);
         }

         Object[] objs = new Object[argsize];

         if (params != null)
         {
            if (params.size() != argsize)
            {
               throw new JboException("");
            }
            for (i = 0; i < argsize; i++)
            {
               objs[i] = DCMethodParameterDef.resolveParameterValue(args[i], ctx, null, params.get(i)); 
            }
         }
         else
         {
            for (i = 0; i < argsize; i++)
            {
               objs[i] = DCMethodParameterDef.resolveParameterValue(args[i], ctx, null, null);
            }
         }

         Object retVal;
         if(instance instanceof Exportable)
         {
            retVal = ((Exportable)instance).invokeExportedMethod(methodName,
                                                                 getArgTypes(),
                                                                 objs);
         }
         else
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("DCInvokeMethodDef:Invoking "+instanceName+"."+methodName+"()");
            }
            retVal = method.getMethod().invoke(instance, objs);
         }

         return retVal;
      }
      catch (JboException je)
      {
         throw je;
      }
      catch (InvocationTargetException e)
      {
         Throwable t = e.getCause();
         if ( t == null )
         {
           t = e;
         }
         throw new JboException( t );
      }
      catch (Throwable e)
      {
         throw new JboException(e);
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getInstanceName()
   {
      return instanceName;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getOperationName()
   {
      return methodName;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getMethodName()
   {
      return methodName;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getReturnName()
   {
      return returnName;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getCachedParamsName()
   {
      if (mCachedParamsName == null) 
      {
         if (returnName != null && (returnName.indexOf(".methodResults.") > 0) && returnName.endsWith("_result"))
         {
            mCachedParamsName = (new StringBuffer(returnName).append("~cp")).toString();
         }
      }
      //return a cache name from the metadata.
      return mCachedParamsName;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final void setCachedParamsName(String name)
   {
      mCachedParamsName = name;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final OperationParameter[] getParameters()
   {
      return (OperationParameter[])args;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String[] getArgTypes()
   {
      if (args != null)
      {
         String[] ret = new String[args.length];
         for (int i = 0; i < args.length; i++)
         {
            ret[i] = args[i].getTypeName();
         }
         return ret;
      }
      return new String[0];
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String[] getArgVals()
   {
      if (args != null)
      {
         String[] ret = new String[args.length];
         for (int i = 0; i < args.length; i++)
         {
            ret[i] = (String)args[i].getValue();
         }
         return ret;
      }
      return new String[0];
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public final String getClassName()
   {
      return instanceClassName;
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
  /* public String getReturnType()
   {
      return returnType;
   }
   */

   public Object clone()
   {
      try
      {
         return super.clone();
      }
      catch (CloneNotSupportedException e)
      {
      }

      return null;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public DCInvokeMethod createMethodInstance(DCBindingContainer ctr, OperationBinding action)
   {
      return new DCInvokeMethod(this, ctr, action);
   }
}
