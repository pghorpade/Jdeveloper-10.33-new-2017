package oracle.adf.model.binding;

public interface DCCachingErrorHandler extends DCErrorHandler
{
   /**
   * @internal *** For internal framework use only *** 
   */
   public boolean isThrowFlag();
  
   /**
   * @internal *** For internal framework use only *** 
   */
   public void setThrowFlag(boolean flag);
}