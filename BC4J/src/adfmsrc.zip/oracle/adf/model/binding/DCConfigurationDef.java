package oracle.adf.model.binding;

import java.util.ArrayList;
import java.util.HashMap;

import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.ElementDefElement;
import oracle.jbo.uicli.mom.JUTags;

import org.w3c.dom.NodeList;

public class DCConfigurationDef extends DCDefBase 
{
   public DCConfigurationDef()
   {
   }
   
   private ArrayList mSessionDefs = new ArrayList();
   private HashMap   mSessionDefsMap = new HashMap(15);

   public DCConfigurationDef(String name)
   {
      setName(name);
   }
   
   protected com.sun.java.util.collections.ArrayList getContainerDefNames(boolean recursive)
   {
      return new com.sun.java.util.collections.ArrayList(1);
   }

   /**
    * Name this object.
    * @param name  the name to be given to this object.
    **/

   public void setName(String name)
   {
      // sim 4/19/01 -- setName is declared here to be public
      super.setName(name);
   }

    
   public ArrayList getSessionDefNames()
   {
      int count = mSessionDefs.size();
      ArrayList retAl = new ArrayList(count);
      for (int i = 0; i < count; i++)
      {
         retAl.add(((DCDataControlDef)mSessionDefs.get(i)).getName());
      }
      return retAl;
   }

   
   static public DCDefBase createAndLoadFromXML(DefElement xmlElement)
   {
      DCConfigurationDef defObj = new DCConfigurationDef();
      
      if (defObj != null)
      {
         
         defObj.loadFromXML(xmlElement);
      }

      return defObj;
   }

   protected void loadFromXMLFile(DefElement xmlElement) 
   {  
      // load the child nodes
      
   }


   private void loadSessions(DefElement xmlElement)
   {
      DebugDiagnostic.println("Loading JUSessions for DataControl '" + getFullName() + "'."); //NONLS

      com.sun.java.util.collections.ArrayList list =
         xmlElement.getChildrenList();

      int length = list.size();
      if (length > 0)
      {
         DCDataControlDef eInfo = null;
         String myFullName = getFullName();
         for ( int i=0; i < length; i++ )
         {
            DefElement elem = (DefElement)list.get(i);

            if(elem.getNodeName().equals(JUTags.Contents))
               break;

            eInfo = (DCDataControlDef)DCDataControlDef.createAndLoadFromXML(elem, myFullName);
            
            if(eInfo == null)
            {
               DebugDiagnostic.println("Failed to load DataControlDef '" + elem.getNodeName() + "'."); //NONLS
            }
            mSessionDefs.add(eInfo);
            mSessionDefsMap.put(eInfo.getName(), eInfo);

            DebugDiagnostic.println("Successfully loaded DataControlDefImpl '" + eInfo.getFullName() + "'."); //NONLS
         }
      }
   }

   
   public DCDataControlDef findSession(String name)
   {
      return (DCDataControlDef)mSessionDefsMap.get(name);
   }

   
   public void removeSession(String name)
   {
      Object obj = mSessionDefsMap.get(name);
      if (obj != null) 
      {
         mSessionDefs.remove(obj);
         mSessionDefsMap.remove(name);
      }
   }

   /**
    * Returns a piece of static info for the type of object this is invoked
    * upon.  Examples are PreparedStatements for insert, update, delete,
    * and String containing a base the select statement for retrieving
    * instances of this type through the SQLInputStream
    * @return returns the Statement required to store in Persitent Storage.
    *         Incase of XML, it just returns the String. In the case of SQL
    *         a JDBC PreparedStatement is returned.
    **/
   public String getXMLElementTag()
   {
      return JUTags.DataControlConfigs;
   }

   protected void loadChildrenFromXML(DefElement xmlElement)
   {
      loadSessions(xmlElement);
   }
}
