/*
 * @(#)DCParameter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.Map;

import oracle.jbo.uicli.UIMessageBundle;

/**
 * @javabean.class name=DCParameter
*/
public class DCParameter extends DCControlBinding
{

   Object mValue;
   String mExpression;
   boolean mEvaluated;

   /**
   * *** For internal framework use only ***
   */
   protected DCParameter()
   {
   }

   public DCParameter(Object value)
   {
      if (value instanceof String) 
      {
         mExpression = (String)value;
      }
      else
      {
         mValue = value;
      }
   }

   public DCParameter(String expression)
   {
      super();
      mExpression = expression;
   }

   protected void initResources()
   {
      mValue = null;
   }

   /**
    * invoked by BindingContainer to evaluate all the page parameters
    * once.
    */
   void reEvaluateValue()
   {
      mValue = null;
      evaluateValue();
   }

   void evaluateValue()
   {
      if (mValue == null) 
      {
         mEvaluated = true;
         mValue = internalEvaluateExpresion();
      }
   }

   void reEvaluateValueEagerly()
   {
      DCParameterDef def = (DCParameterDef)getBaseParameterDef();
      if (def != null) 
      {
         if (!def.isLazy())
         {
            reEvaluateValue();
         }
      }
      else
      {
         reEvaluateValue();
      }
   }

   public Object getValue()
   {
      return (mValue != null || mEvaluated) ? mValue : internalEvaluateExpresion();
   }

   public String getExpression()
   {
      return mExpression;
   }

   public void setExpression(String expression)
   {
      DCParameterDef def = (DCParameterDef)getBaseParameterDef();
      if (def != null) 
      {
         if (def.isReadOnly() || def.isFinal()) 
         {
            try
            {
               throw new oracle.jbo.InvalidParamException(UIMessageBundle.class, 
                                                          UIMessageBundle.EXC_FINAL_PARAMETER,
                                                          new Object[]{getName()});
            }
            catch (Exception e)
            {
               reportException(e);
            }
         }
      }
      if (expression != mExpression && !mExpression.equals(expression)) 
      {
         mExpression = expression;
         mValue = null;
         mEvaluated = false;
      }
   }


   DCIBaseParameterDef getBaseParameterDef()
   {
      return (DCIBaseParameterDef)getDef();
   }


   public static final String ATTR_VALUE = "value";
   protected boolean mInternalGet_KeyResolved = false;
   /**
    * Subclasses should override this to handle a specific key.
    * If they do find the key valid, they should also set the
    * mInternalGet_KeyResolved to  'true' so that bean-introspection
    * is not done for valid null-value returns from the internalGet() call.
    * <p>
    * Properties returned vis getter on this parameter are:
    * <li><code>value</code> - returns getValue()</li>
    */
   protected Object internalGet(String key)
   {
      key = key.intern();

      //we could implement a better scheme here but to start with 
      //go with if/then/else.
      if (key == ATTR_VALUE)
      {
         mInternalGet_KeyResolved = true;
         return getValue();
      }
      return super.internalGet(key);
   }

   Object internalEvaluateExpresion()
   {
      DCIBaseParameterDef def = getBaseParameterDef();
      DCBindingContainer ctr = getBindingContainer();
      
      //if this value is final, then go the BindingContext to get the value.
      //if this value is required, then go to parent and return the value.
      //if this value is optional, go to parent first, then go to bindingcontext.
      Object value = null;
      String expression = mExpression;
      if (!def.isFinal()) 
      {                            
         DCParameter aliasParam = null;
         if (ctr.aliasExists(getName()) && ctr.getRegionContainer() != null)
         {
            value = ctr.getRegionContainer().evaluateParameter(ctr.getParameterAlias(getName()), false);
         }
         if (def.isMandatory()) 
         {
            if (value == null) 
            {
               try
               {
                  throw new oracle.jbo.InvalidParamException(UIMessageBundle.class, 
                                                             UIMessageBundle.EXC_MANDATORY_PARAMETER,
                                                             new Object[]{getName()});
               }
               catch(Exception ex)
               {
                  reportException(ex);
               }
            }
            return value;
         }
         if (expression == null && def != null) 
         {
            expression = ((DCParameterDef)def).getExpression();
         }
      }
      else
      {
         expression = (def != null) ? ((DCParameterDef)def).getExpression() : expression;
      }

      if (value == null)
      {
         value = ctr.evaluateParameter(expression, true);
      }
      return value;
   }

   /**
    * noop
    */
   public void refreshControl()
   {
   }

   /**
    * noop
    */
   protected void resetInputState()
   {
   }

   /**
    * noop
    */
   public void addControlToPanel(Object x, Object y, Object z)
   {
   }

   public String toString()
   {
      //this should be InputValue and not AttributeValue as incase of form, 
      //if there are errors, this needs to display the error-value and not attribute value
      Object value = getValue();
      return (value != null) ? value.toString() : "";
   }

   boolean isFinal()
   {
      if (getDef() != null) 
      {
         return getBaseParameterDef().isFinal();
      }
      return false;
   }

   /**
   * @internal *** For internal framework use only *** 
    * Override to add to Parameters
   */
   public void setBindingContainer(DCBindingContainer formBnd)
   {
      if (formBnd != mBindingContainer)
      {
         if (mBindingContainer != null)
         {
            mBindingContainer.removeParameter(this);
         }
      }
      mBindingContainer = formBnd;

      if (formBnd != null)
      {
         formBnd.addParameter(this, getName());
      }
   }

   /**
   * @internal *** For internal framework use only *** 
   */
   public void setName(String name)
   {
      if (mName == null && name == null)
      {
         return;
      }
      
      if (mName != null)
      {
         if (mName.equals(name))
         {
            return;
         }

         if (mBindingContainer != null)
         {
            mBindingContainer.removeParameter(this);
         }
      }

      mName = name;
      
      if (mBindingContainer != null)
      {
         mBindingContainer.addParameter(this, name);
      }
   }

   protected void release(int flags)
   {
      mEvaluated = false;
      mValue = null;
      super.release(flags);
   }
}

