package oracle.adf.model.binding;

import oracle.jbo.JboException;
import oracle.jbo.SessionContext;

import oracle.jbo.common.JboAbstractMap;
import oracle.jbo.common.JBOClass;

import oracle.adf.model.BindingContext;

import oracle.adf.model.DataControlFactory;

import java.util.Map;
import java.util.HashMap;

/**
 ** @javabean.class name=DCDataControlReference
 ** 
 **/
public class DCDataControlReference extends JboAbstractMap implements Cloneable, DCDataControlManagement
{
   private final DCDataControlDef mDef; 
   private String mName;
   private Map mUserParams = null;

   static String USER_PARAMS_KEY = "adf_dc_user_params_key";

   private HashMap mRequestContext = null;

   public DCDataControlReference(DCDataControlDef def)
   {
      this(def, def.getName());
   }

   public DCDataControlReference(DCDataControlDef def, String name)
   {
      mDef = def;
      mName = name;
   }

   public void setUserParams(Map userParams)
   {
      put(USER_PARAMS_KEY, userParams);
   }

   public DCDataControl getDataControl(BindingContext ctx)
   {
      DataControlFactory factory;
      try
      {
         Class factoryClass = JBOClass.forName(mDef.getFactoryClass());
         factory = (DataControlFactory)factoryClass.newInstance();
      }
      catch(Exception e)
      {
         throw new JboException(e);
      }

      // JRS this is a backwards compatibility step.  The generic
      // DataControlFactoryImpl used to perform this mapping such
      // that the bean class will be faulted back the definition class
      // if null.  I am performing this mapping at RT only in order
      // to maintain the DT integrity (i.e. I don't want the DT to start
      // faulting the bean class as the definition class when writing the
      // DC def).

      //moved this implict beanclass name derivation to mDef.getBeanClass
      //this avoids using a synchronized map in mDef.

      //if (mDef.getBeanClass() == null)
      //{
      //   mDef.setBeanClass(mDef.getDefinitionClass());
      //}

      Map userParams = (Map)get(USER_PARAMS_KEY); 
      DCDataControl dc = (DCDataControl)factory.createSession(
         ctx, mName, userParams, mDef);

      dc.setDef(mDef);

      // store the user params on the dc in case we transition back to 
      // DCDataControlRefernce.
      if (userParams != null)
      {
         dc.put(USER_PARAMS_KEY, userParams);
      }


      SessionContext sessionCtx = ctx.getSessionContext();

      if (sessionCtx != null)
      {
         dc.setSessionContext(sessionCtx);
      }

      // fire the deferred beginRequest notication on the new datacontrol
      if (mRequestContext != null)
      {
         dc.beginRequest(mRequestContext);
         mRequestContext = null;
      }

      return dc;
   }

   public String getName()
   {
      return mName;
   }

   public Object clone() throws CloneNotSupportedException
   {
      return super.clone();
   }

   // From DCDataControlManagement
   public void beginRequest(HashMap requestCtx)
   {
      // queue the beginRequest event in the event that
      // this data control is used later in the request
      mRequestContext = requestCtx;
   }

   public void endRequest(HashMap requestCtx)
   {
      // clear any queued beginRequest events.  this
      // dc was not used in this request.
      mRequestContext = null;
   }

   public void release(int flags)
   {
      // nothing to release.
   }

   public void release()
   {
      // nothing to release.
   }

   public boolean resetState()
   {
      return false;
   }

   protected void internalPut(String key, Object value)
   {
      if (USER_PARAMS_KEY.equals(key))
      {
         mUserParams = (Map)value;
      }
      else
      {
         super.internalPut(key, value);
      }
   }
   
   protected Object internalGet(String key)
   {
      if (USER_PARAMS_KEY.equals(key))
      {
         return mUserParams;
      }
      else
      {
         return super.internalGet(key);
      }
   }
}
