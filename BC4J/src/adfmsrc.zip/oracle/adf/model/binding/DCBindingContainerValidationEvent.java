/*
 * @(#)DCBindingContainerValidationEvent.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.Transaction;

/**
 * Implements EventObject that is passed to the DCBindingContainerValidationListeners
 * in the various event methods. This class provides access to the current iterator binding,
 * panel binding, current row, attribute being edited, and its new value, etc as the
 * case may be for a particular event method.
 */
public class DCBindingContainerValidationEvent extends java.util.EventObject
{
   DCDataControl mDC;
   DCBindingContainer mPanelBinding;
   DCIteratorBinding mIter;
   Row         mRow;
   String      mAttrName;
   Object      mNewValue;
   Object      mModifiedNewValue;
   boolean     mModified = false;

   public DCBindingContainerValidationEvent(DCControlBinding source,
                                 DCBindingContainer panel,
                                 DCIteratorBinding iterBinding,
                                 Row         row,
                                 String      attrName,
                                 Object      value)
   {
      super(source);
      mPanelBinding = panel;
      mDC = (iterBinding != null) ? iterBinding.getDataControl() : null;
      mIter = iterBinding;
      mRow  = row;
      mAttrName = attrName;
      mNewValue = value;
   }

   public DCBindingContainerValidationEvent(DCBindingContainer source,
                                 DCIteratorBinding iterBinding,
                                 Row         row)
   {
      super(source);
      mDC = (iterBinding != null) ? iterBinding.getDataControl() : null;
      mPanelBinding = source;
      mIter = iterBinding;
      mRow  = row;
   }

   public DCBindingContainerValidationEvent(DCBindingContainer source, DCDataControl dc)
   {
      super(dc);
      mPanelBinding = source;
      mDC = dc;
   }

   public DCBindingContainerValidationEvent(DCBindingContainerValidationEvent ev)
   {
      super(ev.getSource());
      mPanelBinding = ev.mPanelBinding;
      mIter = ev.mIter;
      mRow = ev.mRow;
      mAttrName = ev.mAttrName;
      mNewValue = ev.mNewValue;
      mDC = ev.mDC;
   }

   public final DCIteratorBinding getIteratorBinding()
   {
      return mIter;
   }

   public final RowIterator getRowIterator()
   {
      return (mIter != null) ? mIter.getNavigatableRowIterator() : null;
   }

   public final Row getRow()
   {
      return mRow;
   }

   public final String getAttributeName()
   {
      return mAttrName;
   }

   /**
    * Returns the 'new' attribute value as was sent into this event from the setAttributeInRow call
    * If setNewValue is not called on this event, this value will be used to call setAttribute on the
    * row.
    */
   public final Object getValue()
   {
      return mNewValue;
   }

   /**
    * Modified the new value that should be set for this attribute on the data row.
    */
   public final void setNewValue(Object val)
   {
      mModified = true;
      mModifiedNewValue = val;
   }

   /**
    * If there's a modified new value set in this event return that otherwise return 
    * the new value. This value will be used to update the row data using setAttribute method.
    */
   public final Object getNewValue()
   {
      return (mModified) ? mModifiedNewValue : mNewValue;
   }

   public final Transaction getTransaction()
   {
      Transaction txn = null;
      DCDataControl dc = getDataControl();
      if (dc != null)
      {
         ApplicationModule am = dc.getApplicationModule();
         txn = (am != null) ? am.getTransaction() : null;
      }
      return txn;
   }

   public final DCBindingContainer getBindingContainer()
   {
      return mPanelBinding;
   }

   public final DCDataControl getDataControl()
   {
      if (mDC == null)
      {
         if (mIter != null) 
         {
            mDC = mIter.getDataControl();
         }
         else if (mPanelBinding != null)
         {
            mDC = mPanelBinding.getDataControl();
         }
      }
      return mDC;
   }

   public final boolean isFindMode()
   {
      return mPanelBinding.isFindMode();
   }
}
