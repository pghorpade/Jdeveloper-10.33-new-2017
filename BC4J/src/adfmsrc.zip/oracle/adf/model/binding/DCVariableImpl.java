package oracle.adf.model.binding;

import oracle.jbo.Variable;      
import oracle.jbo.VariableManager;      
import oracle.jbo.VariableManagerOwner;      
import oracle.jbo.VariableValueManager;

import oracle.jbo.common.JBOClass;
import oracle.jbo.common.VariableImpl;      
import oracle.jbo.common.VariableValueManagerImpl;      

import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.uicli.mom.JUTags;

/**
 * @javabean.class name=DCVariableImpl
*/
public class DCVariableImpl extends VariableImpl implements java.io.Serializable
{

   transient String  mExpr;
   transient boolean mExprBasedDefaultValue = true;
   transient boolean mDefaultValue = true;

   transient boolean mSourceToResolve = true;
   transient String mSourceName;
   transient String mDCName;
   transient Variable mSource;

   transient boolean mSourceNameInit = false;

   public DCVariableImpl()
   {
   }

   protected VariableImpl createClone()
   {
      return new DCVariableImpl();
   }

   public Object clone()
   {
      DCVariableImpl var = (DCVariableImpl)super.clone();
      var.mDCName = mDCName;
      var.mSourceName = mSourceName;
      var.mSourceNameInit = true;
      return var;
   }

   private Variable resolveSourceVariable()
   {
      if (mSourceToResolve && mSourceNameInit) 
      {
         mSourceToResolve = false; //do not attempt this again.
         if (mSource == null && mDCName != null) 
         {
            VariableManager manager = getVariableManager();
            DCBindingContainer ctr = (manager instanceof DCVariableValueManagerImpl) 
                                   ? ((DCVariableValueManagerImpl)manager).getBindingContainer()
                                   : null;
            if (ctr != null) 
            {
               DCDataControl dc = ctr.getBindingContext().findDataControl(mDCName);
               mSource = dc.findVariable(mSourceName);
            }
         }
      }
      return mSource;
   }

   /**
    * Returns the default value of the attribute.
    * <p>
    * The default value for an attribute is expressed in terms
    * of the Java type system, rather than the storage type system.
    * @return the default value for the attribute, or <tt>null</tt> if none.
    */
   public Object getDefaultValue()
   {
      //evaluateExpression here.
      //this same value is returned for the variable
      //on getVaraibleValue as well.
      VariableManager varMgr = getVariableManager();

      DCBindingContainer ctr = (varMgr instanceof DCVariableValueManagerImpl) 
                             ? ((DCVariableValueManagerImpl)varMgr).getBindingContainer()
                             : null;
      if (ctr != null && mExprBasedDefaultValue) 
      {
         //resolve expression and return that value.
         Object defVal = super.getDefaultValue();
         if (resolveSourceVariable() != null && defVal == null) 
         {
            defVal = mSource.getDefaultValue();
         }
         if (defVal instanceof String) 
         {
            String defStr = (String)defVal;
            if (DCUtil.isElExpr(defStr)) 
            {
               mExpr = defStr;
               return ctr.evaluateParameter(defStr, true);
            }
         }
         return defVal;
      }
      return super.getDefaultValue();
   }


   public void setDefaultValue(Object val)
   {
      if (val != null && mExpr != null) 
      {
         //this value programmatically overrides expression.
         mExprBasedDefaultValue = false;
      }

      super.setDefaultValue(val);
   }


   public int getIndex()
   {
      DCVariableValueManagerImpl varMgr = (DCVariableValueManagerImpl)getVariableManager();
      java.util.List list = varMgr.variableList();
      return list.indexOf(this);
   }

   public void initFromXML(DefElement xmlElement, boolean bDesignTime)
   {
      super.initFromXML(xmlElement, bDesignTime);
      mSourceName = xmlElement.readString(JUTags.PNAME_Binds);
      mDCName = xmlElement.readString(JUTags.DataControl);
      mSourceNameInit = true;
   }


   protected String resolveResourceProperty(String property, oracle.jbo.LocaleContext locale)
   {
      String thisvar = super.resolveResourceProperty(property, locale);
      if (resolveSourceVariable() != null && thisvar == null) 
      {
         thisvar = mSource.getUIHelper().getHintValue(locale, property);
      }
      return thisvar;
   }

   public String getVariableKind()
   {
      String thisvar = super.getVariableKind();
      if (thisvar == null && resolveSourceVariable() != null) 
      {
         thisvar = mSource.getVariableKind();
      }
      return thisvar;
   }

   public byte getUpdateableFlag()
   {
      byte thisvar = super.getUpdateableFlag();
      if (resolveSourceVariable() != null && thisvar == Variable.UPDATEABLE) 
      {
         thisvar = mSource.getUpdateableFlag();
      }
      return thisvar;
   }

   public boolean isMandatory()
   {
      boolean thisvar = super.isMandatory();
      if (resolveSourceVariable() != null && !thisvar) 
      {
         thisvar = mSource.isMandatory();
      }
      return thisvar;
   }

   public int getPrecision()
   {
      int thisvar = super.getPrecision();
      if (resolveSourceVariable() != null && thisvar == 0) 
      {
         thisvar = mSource.getPrecision();
      }
      return thisvar;
   }

   public int getScale()
   {
      int thisvar = super.getScale();
      if (resolveSourceVariable() != null && thisvar == oracle.jbo.rules.JboPrecisionScaleValidator.DEFAULT_SCALE) 
      {
         thisvar = mSource.getScale();
      }
      return thisvar;
   }

   public Class getJavaType()
   {
      if (resolveSourceVariable() != null) 
      {
         return mSource.getJavaType();
      }
      return super.getJavaType();
   }

}


