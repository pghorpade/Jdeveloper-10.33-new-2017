/*
 * @(#)DCMethodParameter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.adf.model.binding;

import java.util.Map;

import oracle.jbo.uicli.UIMessageBundle;
import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationParameter;

/**
 * *** For internal framework use only ***
 * @javabean.class name=DCMethodParameter
*/
public class DCMethodParameter extends DCParameter 
             implements OperationParameter
{
   DCMethodParameterDef mDef;
   DCBindingContainer   mBC;

   /**
   * *** For internal framework use only ***
   */
   protected DCMethodParameter(DCMethodParameterDef def, DCBindingContainer bc)
   {
      super(def.getValue());
      mDef = def;
      mBC = bc;
      setName(def.getName());
   }

   public String getTypeName()
   {
      return mDef.getTypeName();
   }

   public Class getType()
   {
      return mDef.getType();
   }

   DCIBaseParameterDef getBaseParameterDef()
   {
      return (DCIBaseParameterDef)mDef;
   }

   Object internalEvaluateExpresion()
   {
      return resolveParameterValue(mBC.getBindingContext(), null); 
   }

   Object resolveParameterValue(BindingContext ctx, Object paramValue)
   {
      return DCMethodParameterDef.resolveParameterValue(mDef, ctx, mBC, paramValue);
   }
}

