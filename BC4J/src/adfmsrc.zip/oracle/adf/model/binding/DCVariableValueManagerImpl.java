package oracle.adf.model.binding;

import oracle.jbo.Variable;      
import oracle.jbo.VariableManager;      
import oracle.jbo.VariableManagerOwner;      
import oracle.jbo.VariableValueManager;

import oracle.jbo.common.JBOClass;
import oracle.jbo.common.VariableImpl;      
import oracle.jbo.common.VariableValueManagerImpl;      

import java.util.List;


public class DCVariableValueManagerImpl extends VariableValueManagerImpl implements java.io.Serializable
{
   /**
    * constructor only for serialization usages.
    */
   DCVariableValueManagerImpl()
   {
      this(null, null, null);
   }

   DCBindingContainer mBindingContainer;

   public DCVariableValueManagerImpl(VariableManagerOwner owner, VariableValueManager defVarMgr, DCBindingContainer bc)
   {
      super(owner, (defVarMgr != null) ? new VariableValueManager[]{defVarMgr} : new VariableValueManager[0]);
      mBindingContainer = bc;
   }

   protected VariableImpl internalCreateVariableInstance()
   {
      return new DCVariableImpl();
   }

   protected DCBindingContainer getBindingContainer()
   {
      return mBindingContainer;
   }

   protected List variableList()
   {
      return super.variableList();
   }

}

