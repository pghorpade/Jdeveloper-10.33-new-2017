package oracle.adf.model.binding;

import java.security.Permission;
import java.security.Principal;
import java.lang.reflect.Constructor;

import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.ADFContext;

class PermissionMap
{
   int mId;
   String mPermissionClass;


   PermissionMap(int id, String str)
   {
      mId = id;
      mPermissionClass = str;
   }
}

public class PermissionHelper 
{
   public static final int ATTRIBUTE_PERMISSION = 0;
   public static final int ROWSET_PERMISSION    = 1;
   public static final int REGION_PERMISSION    = 2;
   public static final int METHOD_PERMISSION    = 3;

   // Temporary stuff for AttributePermission actions
   public static final String UPDATE_ACTION = "Update";
   public static final String READ_ACTION = "Read";
   public static final String WRITE_ACTION = "Write";

   // Temporary stuff for RowSetPermission actions
   public static final String CREATE_ACTION = "Create";
   public static final String DELETE_ACTION = "Delete";
   public static final String EDIT_ACTION = "Edit";
   public static final String VIEW_ACTION = "View";

   // Temporary stuff for MethodPermission actions
   public static final String INVOKE_ACTION = "Invoke";

   private static final String ADF_PERMISSION_CLASS = "oracle.adf.share.security.authorization.ADFPermission";

   public static final int NOT_CHECKED = -1;
   public static final int NO_PERMISSION = 0;
   public static final int HAS_PERMISSION = 1;

   private static final int AUTHORIZATION_NOT_INITIALIZED = -1;
   private static final int AUTHORIZATION_NOT_ENABLED = 0;
   private static final int AUTHORIZATION_ENABLED = 1;

   private static int mAuthorizationFlag = AUTHORIZATION_NOT_INITIALIZED;


   static final PermissionMap [] mPermissionMap =
   {
      new PermissionMap(ATTRIBUTE_PERMISSION, "oracle.adf.share.security.authorization.AttributePermission"),
      new PermissionMap(ROWSET_PERMISSION   , "oracle.adf.share.security.authorization.RowSetPermission"),
      new PermissionMap(REGION_PERMISSION   , "oracle.adf.share.security.authorization.RegionPermission"),
      new PermissionMap(METHOD_PERMISSION   , "oracle.adf.share.security.authorization.MethodPermission"),
   }  ;

   static public Object createPermissionInstance(String permClassName, String target, String actions)
   {
       Permission p = null;

       try
       {
         Class cls = Class.forName(permClassName);
         Class strClass = Class.forName("java.lang.String");
         Class[] params = new Class[]{strClass, strClass};
         Constructor ctr = cls.getConstructor(params);
         // NOTE: assume 2-string ctr
         p = (Permission)ctr.newInstance(new Object[]{ target, actions });
       }
       catch (Exception e)
       {
         e.printStackTrace(System.err);
         throw new IllegalStateException(e.getMessage());
       }
       return p;
   }


   static public boolean hasPermission(SecurityContext secCtx, String target, String actions)
   {
       if (!secCtx.isAuthorizationEnabled())
       {
          return true;
       }

       Permission p = (Permission) createPermissionInstance(ADF_PERMISSION_CLASS, target, actions);
       return hasPermission(secCtx, p);
   }


   static public boolean hasPermission(SecurityContext secCtx, Permission permission)
   {
       if (!isAuthorizationEnabled())
       {
          return true;
       }
       return secCtx.hasPermission(permission);
   }

   static public String getPermissionClassName(int id)
   {
       if (id < mPermissionMap.length)
       {
          return mPermissionMap[id].mPermissionClass;
       }
       return null;
   }

   static public String getReadAction(String permClass)
   {
      for (int i = 0; i < mPermissionMap.length; i++)
      {
         if (mPermissionMap[i].mPermissionClass.equals(permClass))
         {
            if (i == REGION_PERMISSION)
            {
               return VIEW_ACTION; 
            }
         }
 
      }
      return READ_ACTION;
   }

   static public final boolean isAuthorizationEnabled()
   {
     if (mAuthorizationFlag == AUTHORIZATION_NOT_INITIALIZED)
     {
	 SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
	 if (secCtx != null) {
	     mAuthorizationFlag = secCtx.isAuthorizationEnabled() ? AUTHORIZATION_ENABLED : AUTHORIZATION_NOT_ENABLED;
	 }

     }
     return (mAuthorizationFlag == AUTHORIZATION_ENABLED) ? true : false;
   }

}

