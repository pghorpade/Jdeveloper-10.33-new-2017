package oracle.adf.model;

import java.io.Serializable;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import oracle.adf.share.ADFContext;
import oracle.adf.share.Environment;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCBindingContainerReference;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.binding.DCDataControlManagement;
import oracle.adf.model.binding.DCDataControlReference;
import oracle.adf.model.binding.DCErrorHandler;

import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.SessionContext;
import oracle.jbo.common.DefLocaleContext;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.StringManager;
import oracle.jbo.mom.DefinitionObject;
import oracle.jbo.uicli.mom.JUApplicationDefImpl;

public class BindingContext implements Serializable, Map
{
   static final long serialVersionUID = 3114329020915398600L;

   public static final String RESERVED_BINDINGS = "bindings";
   public static final String CONTEXT_HELPER = "_dc_hlp_";
   public static final String BINDINGS_HELPER = "_bc_hlp_";
   public static final String CONTEXT_ID = "data";
   public static final String DEFAULT_DATA_CONTROL = "_default_datacontrol_";
   public static final String LOCALE_CONTEXT = "_locale_context_";
   public static final String ERROR_HANDLER = "_error_handler_";
   public static final String MAP_RESOLVER = "_map_resolver_";

   public static final String HTTP_REQUEST = "_http_request_";
   public static final String HTTP_RESPONSE = "_http_response_";
   public static final String INPUT_VALUE_HANDLERS = "_InputValueHandlers_";

   public static final String APPLICATION_DEF = "_def_";
   public static final String IS_INITIALIZED = "_is_initialized_";

   static public byte CLIENT_TYPE_ABSTRACT = 0;
   static public byte CLIENT_TYPE_JCLIENT  = 1;
   private byte mClient = CLIENT_TYPE_ABSTRACT;
   private HashMap mPersistentStates = null;

   // JRS 3149548 BindingContext cannot extend HashMap to store its
   // transient state because it must be serializable.  Encapsulate
   // the map instead.  This should still work with SPEL since
   // BindingContext implements Map.
   private transient HashMap mDefaultMap;

   // JRS The *Array objects represent immutable lists.
   // They are used to perform fast DC and BC iteration.
   private transient HashMap mDCMap;
   private transient Object[] mDCArray;
   private transient HashMap mBCMap;
   private transient Object[] mBCArray;
   private transient JUApplicationDefImpl mDef;

   private transient SessionContext mSessionContext = null;

   public BindingContext(int size)
   {
     initialize(size);
   }

   public BindingContext()
   {
     this(10);
   }

   public DefinitionObject getDef()
   {
     if (mDef == null)
     {
        initDef();
     }

     return mDef;
   }

   private void initialize(int size)
   {
      if (mDefaultMap == null)
      {
         mDefaultMap = new HashMap(size);
      }

      if (mDCMap == null)
      {
         mDCMap = new HashMap(size);
      }

      if (mBCMap == null)
      {
         mBCMap = new HashMap(size);
      }
   }

   public void setLocaleContext(LocaleContext lCtx)
   {
     put(LOCALE_CONTEXT, lCtx);
     /*
     Object obj;
     Iterator iter = dataControlsIterator();
     while (iter.hasNext())
     {
        obj = iter.next();
        if (obj instanceof DCDataControl)
        {
           ((DCDataControl)obj).setLocaleContext(lCtx);
        }
     }
     */
   }

   public LocaleContext getLocaleContext()
   {
     LocaleContext localeCtx = (LocaleContext)get(LOCALE_CONTEXT);

     if (localeCtx == null)
     {
        //set a default locale context if none set thus far.
       localeCtx = new DefLocaleContext(StringManager.getDefaultLocale());
       setLocaleContext(localeCtx);
     }

     return localeCtx;
   }

   public void setErrorHandler(DCErrorHandler errHandlerObj)
   {
     put(ERROR_HANDLER, errHandlerObj);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public void setClientAppType(byte clientType)
   {
     mClient = clientType;
     if (clientType == CLIENT_TYPE_JCLIENT)
     {
        oracle.jbo.uicli.mom.JUMetaObjectManager.getJUMom().setJClientDefFactory(null);
     }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public boolean isJClientApp()
   {
    return (mClient == CLIENT_TYPE_JCLIENT);
   }

   public boolean isGenericApp()
   {
    return (mClient == CLIENT_TYPE_ABSTRACT);
   }

   public final DCErrorHandler getErrorHandler()
   {
     return (DCErrorHandler)get(ERROR_HANDLER);
   }

   public final oracle.binding.BindingContainer setCurrentBindingsEntry(oracle.binding.BindingContainer bindings)
   {
      oracle.binding.BindingContainer existingBC = (oracle.binding.BindingContainer)mDefaultMap.get(RESERVED_BINDINGS);
      if (bindings != null)
      {
         mDefaultMap.put(RESERVED_BINDINGS, bindings);
      }
      else
      {
         mDefaultMap.remove(RESERVED_BINDINGS);
      }
      return existingBC;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    * Only for use in JClient internally to get to JUApplication.
    */
   public DCDataControl getDefaultDataControl()
   {
      Object dc = (DCDataControl)get(DEFAULT_DATA_CONTROL);
      if (dc == null)
      {
         Object[] dcArray = dataControlsArray();
         for (int i=0; i < dcArray.length; i++)
         {
            dc = dcArray[i];
            if (dc instanceof DCDataControlReference)
            {
               // this get will replace the ref with the DC.
               dc = get(((DCDataControlReference)dc).getName());
            }


            if (dc instanceof DCDataControl)
            {
               //got a DC now use that as default.
               break;
            }
         }
      }
      return (DCDataControl)dc;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public void initializeSessionContext(SessionContext currentSession)
   {
      mSessionContext = currentSession;
   }


   /**
    * <b>Internal:</b> <em>Applications should not use this class.</em>
    */
   public void setSessionContext(SessionContext currentSession)
   {
      mSessionContext = currentSession;

      Object[] dcArray = dataControlsArray();
      for (int i=0; i < dcArray.length; i++)
      {
         if (dcArray[i] instanceof DCDataControl)
         {
            ((DCDataControl)dcArray[i]).setSessionContext(currentSession);
         }
      }
   }

   public SessionContext getSessionContext()
   {
     return mSessionContext;
     /*
     DCDataControl dc = getDefaultDataControl();
     if(dc != null)
     {
        return dc.getSessionContext();
     }
     return null;
     */
   }

   /**
    * Release the datacontrols first and then all the contained
    * binding containers.
    */
   public void release()
   {

      // use valuesIterator() here.  If the BindingContext is not synchronized
      // then release WILL result in a concurrency exception.
      Object[] dcArray = dataControlsArray();
      for (int i=0; i< dcArray.length; i++)
      {
         ((DCDataControlManagement)dcArray[i]).release();
      }

      Object[] bcArray = bindingContainersArray();
      for (int i=0; i < bcArray.length; i++)
      {
         if (bcArray[i] instanceof DCBindingContainer)
         {
            ((DCBindingContainer)bcArray[i]).release();
         }
      }
   }

    /**
     * Does not save the map that this context extends.
     * Only saves out the context/application type and persistent IDs.
     */
    private void writeObject(java.io.ObjectOutputStream s)
        throws java.io.IOException
    {
       s.writeByte(mClient); //client type
       s.writeObject(mPersistentStates); //map of dcnames and their ids.
    }

    /**
     * Reconstitute the <tt>ArrayList</tt> instance from a stream (that is,
     * deserialize it).
     */
    private void readObject(java.io.ObjectInputStream s)
        throws java.io.IOException, ClassNotFoundException
    {
       initialize(10);
       mClient = s.readByte();
       mPersistentStates = (HashMap)s.readObject();
    }

    public DCDataControl findDataControl(String name)
    {
       return (DCDataControl)get(name);
    }

    public DCBindingContainer findBindingContainer(String name)
    {
       return (DCBindingContainer)get(name);
    }

    /**
     * @return A persistent state for the specified name.  If a persistent
     * state is not found for the name then return null.
     * <p>
     * @deprecated since 10.1.3.  Applications should use the StateManager instead.  See
     * {@link oracle.adf.share.statemanager.StateManager}
     */
    public Serializable findPersistentState(String name)
    {
       Serializable psState = null;
       if (mPersistentStates != null)
       {
          psState = (Serializable)mPersistentStates.get(name);
       }
       return psState;
    }


    /**
     * <b>Internal:</b> <em>Applications should not use this class.</em>
     * <p>
     * @deprecated since 10.1.3.  Applications should use the StateManager instead.  See
     * {@link oracle.adf.share.statemanager.StateManager}
     */
    public void addPersistentState(String name, Serializable psState)
    {
       if (mPersistentStates == null)
       {
          mPersistentStates = new HashMap(5);
       }

       mPersistentStates.put(name, psState);
    }

    /**
     * <b>Internal:</b> <em>Applications should not use this class.</em>
     * <p>
     * @deprecated since 10.1.3.  Applications should use the StateManager instead.  See
     * {@link oracle.adf.share.statemanager.StateManager}
     */
    public void removePersistentState(String name)
    {
       if (mPersistentStates != null)
       {
          mPersistentStates.remove(name);
       }
    }

    /**
     * Returns a thread safe values iterator.
     */
    public Iterator valuesIterator()
    {
       HashMap copy = (HashMap)mDefaultMap.clone();
       return copy.values().iterator();
    }

    public Iterator dataControlsIterator()
    {
       HashMap copy = (HashMap)mDCMap.clone();
       return copy.values().iterator();
    }

    public Iterator bindingContainersIterator()
    {
       HashMap copy = (HashMap)mBCMap.clone();
       return copy.values().iterator();
    }

    private Object[] dataControlsArray()
    {
       if (mDCArray == null)
       {
          mDCArray = mDCMap.values().toArray();
       }
       return mDCArray;
    }

    private Object[] bindingContainersArray()
    {
       if (mBCArray == null)
       {
          mBCArray = mBCMap.values().toArray();
       }
       return mBCArray;
    }

    /**
     * Returns a thread safe keys iterator.
     */
    public Iterator keysIterator()
    {
       HashMap copy = (HashMap)mDefaultMap.clone();
       return copy.keySet().iterator();
    }

   public int size()
   {
      return mDefaultMap.size();
   }

   public boolean isEmpty()
   {
      return mDefaultMap.isEmpty();
   }

   public boolean containsKey(Object key)
   {
      return mDefaultMap.containsKey(key);
   }

   public boolean containsValue(Object value)
   {
      return mDefaultMap.containsValue(value);
   }

   public Object get(Object key)
   {
      if (CONTEXT_ID.equals(key))
      {
         return this;
      }

      if (HTTP_REQUEST.equals(key))
      {
         return ADFContext.getCurrent().getEnvironment().getRequest();
      }

      Object rtn = mDCMap.get(key);
      if (rtn == null)
      {
         rtn = mBCMap.get(key);
      }
      else
      {
         if (rtn instanceof DCDataControlReference)
         {
            // remove the reference in order to prevent re-entrancy.
            Object ref = remove(key);
            try
            {
               rtn = ((DCDataControlReference)rtn).getDataControl(this);
               put(key, rtn);
               ref = null;
            }
            finally
            {
               // but replace the reference if getDataControl failed (bug4330928)
               if( ref != null )
                  put(key, ref);
            }
         }

         return rtn;
      }

      if (rtn == null)
      {
         rtn = mDefaultMap.get(key);
      }
      else
      {
         if (rtn instanceof DCBindingContainerReference)
         {
            Object ref = remove(key);
            try
            {
               rtn = ((DCBindingContainerReference)rtn).getBindingContainer();
               put(key, rtn);
               ref = null;
            }
            finally
            {
               if( ref != null )
                  put(key, ref);
            }
         }

         return rtn;
      }

      return rtn;
   }

   public Object put(Object key, Object value)
   {
      if (value instanceof DCDataControl
         || value instanceof DCDataControlReference)
      {
         mDCMap.put(key, value);
         mDCArray = null;
         if (value instanceof DCDataControl)
         {
            DCDataControl dc = ((DCDataControl)value);
            if (dc.getBindingContext() != this)
            {
               dc.setBindingContext(this);
            }
         }
      }
      else if (value instanceof DCBindingContainer
         || value instanceof DCBindingContainerReference)
      {
         mBCMap.put(key, value);
         mBCArray = null;
      }

      // JRS DefaultMap still references all values.
      return mDefaultMap.put(key, value);
   }

   public Object remove(Object key)
   {
      mBCMap.remove(key);
      mBCArray = null;
      mDCMap.remove(key);
      mDCArray = null;
      return mDefaultMap.remove(key);
   }

   public void putAll(Map t)
   {
      // need to invoke this.put in order to ensure that
      // the objects are added to the correct collections.
      Iterator keys = t.keySet().iterator();
      Object key = keys.next();
      while(key != null)
      {
         put(key, t.get(key));
         key = keys.next();
      }
   }

   public void clear()
   {
      mDCMap.clear();
      mDCArray = null;
      mBCMap.clear();
      mBCArray = null;
      mDefaultMap.clear();
   }

   public Set keySet()
   {
      return mDefaultMap.keySet();
   }

   public Collection values()
   {
      return mDefaultMap.values();
   }

   public Set entrySet()
   {
      return mDefaultMap.entrySet();
   }

   public Object getBindingInputHandler(String type)
   {
      Map map = (Map)get(INPUT_VALUE_HANDLERS);
      if (map != null)
      {
         Object obj = map.get(type);
         if (obj instanceof String)
         {
            try
            {
               Class clz = JBOClass.forName((String)obj);
               obj = JBOClass.newInstance(clz);
               map.put(type, obj);
            }
            catch (ClassNotFoundException e)
            {
               throw new JboException(e);
            }
         }
         return obj;
      }
      return null;
   }

   public void setBindingInputHandlers(Map map)
   {
      Map hmap = (Map)get(INPUT_VALUE_HANDLERS);
      if (hmap == null)
      {
         hmap = new HashMap();
         put(INPUT_VALUE_HANDLERS, hmap);
      }
      hmap.putAll(map);
   }

   void initDef()
   {
      if (mDef == null && mDefaultMap != null && mDefaultMap.containsKey(APPLICATION_DEF))
      {
         mDef = (JUApplicationDefImpl)mDefaultMap.get(APPLICATION_DEF);
      }
   }

   /**
    * Given the view path, find a mapping entry in this BindingContext's
    * pageMap definition and return a bindingContainer whose usage name
    * maps the value of the mapped entry. Returns null if no matching
    * entry found.
    */
   public DCBindingContainer findBindingContainerByPath(String path)
   {
      if (mDef == null)
      {
         initDef();
      }
      if (mDef != null)
      {
         String bcId;
         if ((bcId = mDef.findBindingContainerIdByPath(path, this)) != null)
         {
            return findBindingContainer(bcId);
         }
      }
      return null;
   }

   /**
    * Given the view path, find a mapping entry in this BindingContext's
    * pageMap definition and return the mapped value which should be
    * a bindingContainer ID that can be used to lookup a bindingContainer
    * instance in this BindingContext. Returns null if no matching entry
    * found.
    */
   public String findBindingContainerIdByPath(String path)
   {
      if (mDef == null)
      {
         initDef();
      }
      return (mDef != null) ? mDef.findBindingContainerIdByPath(path, this) : null;
   }

   void beginRequest(ADFContext adfContext, HashMap requestCtx)
   {
      Environment adfEnv = adfContext.getEnvironment();
      setLocaleContext(new DefLocaleContext(adfEnv.getRequestLocale()));

      Object[] dcArray = dataControlsArray();
      for (int i=0; i < dcArray.length; i++)
      {
         if (dcArray[i] instanceof DCDataControl)
         {
            ((DCDataControl)dcArray[i]).setSessionContext(mSessionContext);
         }
      }

      Object[] bcArray = bindingContainersArray();
      for (int i=0; i < bcArray.length; i++)
      {
         if (bcArray[i] instanceof DCBindingContainer)
         {
            ((DCBindingContainer)bcArray[i]).resetInputState();
         }
      }

      dcArray = dataControlsArray();
      for (int i=0; i < dcArray.length; i++)
      {
         if (dcArray[i] instanceof DCDataControlManagement)
         {
            ((DCDataControlManagement)dcArray[i]).beginRequest(requestCtx);
         }
      }
   }

   void endRequest(ADFContext adfContext, HashMap requestCtx)
   {      
      Object[] dcArray = dataControlsArray();
      for (int i=0; i < dcArray.length; i++)
      {
         if (dcArray[i] instanceof DCDataControlManagement)
         {
            ((DCDataControlManagement)dcArray[i]).endRequest(requestCtx);
         }
      }
   }
}


