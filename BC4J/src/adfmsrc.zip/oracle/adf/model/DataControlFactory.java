package oracle.adf.model;

import org.w3c.dom.Node;
import java.util.Map;

import oracle.adf.model.binding.DCDataControlDef;

/*
 * Creates session instances from the xml node
 */
public interface DataControlFactory 
{
   public static String APP_PARAM_ENV_INFO          = "_envInfo_Provider";

   /**
    * @deprecated the HttpSession will no longer be passed as an application
    * parameter from the ADFBindingFilter.  DataControls that must
    * access the HttpSession should use:
    * <p>
    * <code>((HttpServletRequest)ADFContext.getCurrent().getEnvironment().getRequest()).getSession(true)</code>
    * <p>
    * or:
    * <p>
    * <code>ADFContext.getCurrent().getSessionScope().get(String)</code>
    * <p>
    * instead.
    */
   public static String APP_PARAM_HTTP_SESSION      = "_http_Session";
   public static String APP_PARAM_POOL_PROPERTIES   = "_pool_Properties";
   public static String APP_PARAMS_BINDING_CONTEXT  = "_binding_Context";
   public static String APP_PARAM_REQUEST_CONTEXT   = "_request_context";

   /**
    * @deprecated  use APP_PARAM_REQUEST_CONTEXT instead.
    */
   public static String APP_PARAM_COOKIE_PROPERTIES = APP_PARAM_REQUEST_CONTEXT;
   /**
    * The DataControl developer should implement createSession to return an
    * instance of {@link oracle.adf.model.DataControl}.  For example, the
    * JavaBean DataControl implements {@link oracle.adf.model.generic.DataControlFactoryImpl}
    * to return an instance of {@link oracle.adf.model.generic.DCGenericDataControl}.
    * <p>
    * The data binding framework will typically invoke this method once, at 
    * the beginning of a new application session.  The DataControl factory 
    * implementation to use is determined by the DataControl definition.
    * <p>
    * @param ctx The BindingContext for which the DataControl is being created
    * @param node The DOM node of the DataControl definition that is being created
    * @param applicationParams Additional application createSession context
    * <p>
    * The framework may pass additional context in the applicationParams Map.
    * For example, in the case of a HttpSession, the framework will add the
    * current HttpSession to the applicationParams Map.
    */
   public DataControl createSession(BindingContext ctx, Node node, Map applicationParams);

   /**
    * The DataControl developer should implement createSession to return an
    * instance of {@link oracle.adf.model.DataControl}.  For example, the
    * JavaBean DataControl implements {@link oracle.adf.model.generic.DataControlFactoryImpl}
    * to return an instance of {@link oracle.adf.model.generic.DCGenericDataControl}.
    * <p>
    * The data binding framework will typically invoke this method once, at 
    * the beginning of a new application session.  The DataControl factory 
    * implementation to use is determined by the DataControl definition.
    * <p>
    * @param ctx The BindingContext for which the DataControl is being created
    * @param sName The DataControl name as specified in the DataControl definition

    * @param applicationParams Additional application createSession context
    * @param cpxMetaData A Map containing name/value pairs of the properties
    *   defined in the DataControl definition
    * <p>
    * The framework may pass additional context in the applicationParams Map.
    * For example, in the case of a HttpSession, the framework will add the
    * current HttpSession to the applicationParams Map.
    */
   public DataControl createSession(BindingContext ctx, String sName, Map applicationParams, Map cpxMetaData);
}
