/* Copyright (c) 2001, 2004, Oracle. All rights reserved.  */

package oracle.adf.mds.jbo;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import javax.naming.Binding;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import oracle.cabo.ui.AttributeKey;

import oracle.jbo.mom.xml.XMLContextImpl;

import oracle.adf.mds.MDSContext;

import oracle.adfinternal.mds.jbo.JBODefManagerHelper;

/**
** JBO Definitions Manager.  This class supports loading BC4J substitutions from
** the MDS repository.  If a JPX file exists, any substitutions from the file
** will take precedence over repository data.
*/
/*
** <!--------------------------------------------------------------------------
** MODIFIED    (MM/DD/YY)
** edelaube     12/03/04  -  Fix location of helper class 
** cbarrow      11/05/03  -  Move most logic to MDS VOB (JBODefManagerHelper)
** cbarrow      11/04/03  -  Fix NPE: initialize SITE_ONLY_CUST_CONTEXT!
** cbarrow      11/03/03  -  Accomodate some MDS changes (BasePath).
** sudsrini     08/20/03  -  Stop using DOC_PATH_ATTR 
** cbarrow      08/12/03  -  Accomodate RTMDS refactorying.
** sudsrini     07/03/03  -  Change JRADContext to MDSContext
** kaalvare     04/21/03  -  Modify replace syntax
** kaalvare     04/15/03  - #(2767164) Creation - to support BC4J substitutions
** --------------------------------------------------------------------------->
*/
public class JBODefManager extends XMLContextImpl
{

    //-------------------------------------------------------------------------
    // Public methods
    //-------------------------------------------------------------------------

    /**
    **  Constructor.
    **  @param  env    Environment properties
    */
    public JBODefManager(Hashtable env)
    {
        super(env);
        mJBODefManagerHelper = new JBODefManagerHelper(env);
    }


    /**
    **  List all name class pairs for a given name, using a naming enumeration.
    **  @param  name  Name of the BC4J object
    **  @return NamingEnumeration - enumeration of name class pairs
    */
    public NamingEnumeration list(String name) throws NamingException
    {
        // First check whether a substitution exists in the JPX file
        NamingEnumeration enum = super.listBindings(name);
        if (enum.hasMoreElements())
        {
            return enum;
        }
        // No substitution exists in the JPX file. Look in the MDS repository.
        NamingEnumeration enumMDS = mJBODefManagerHelper.list(name);
        if ( enumMDS != null )
        {
            return enumMDS;
        }
        return enum;
     }


    /**
    **   List all bindings for a given name.
    **   @param   name   Name of the BC4J object
    **   @return NamingEnumeration - enumeration of bindings
    */
    public NamingEnumeration listBindings(String name) throws NamingException
    {
        // First check whether a substitution exists in the JPX file
        NamingEnumeration enum = super.listBindings(name);
        if (enum.hasMoreElements())
        {
            return enum;
        }
        // No substitution exists in the JPX file. Look in the MDS repository.
        NamingEnumeration enumMDS = mJBODefManagerHelper.listBindings(name);
        if ( enumMDS != null )
        {
            return enumMDS;
        }
        return enum;
    }


    //-------------------------------------------------------------------------
    // Public static methods
    //-------------------------------------------------------------------------


    /**
    **  Sets the MDS Context
    **  @param  context  MDS Context instance
    */
    public static void setMDSContext(MDSContext context)
    {
        JBODefManagerHelper.setMDSContext(context);
    }


    //-------------------------------------------------------------------------
    // Private static variables
    //-------------------------------------------------------------------------

    private JBODefManagerHelper     mJBODefManagerHelper;
}
