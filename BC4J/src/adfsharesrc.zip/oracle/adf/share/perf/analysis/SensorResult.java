package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

import java.text.DecimalFormat;

/**
 * Base class for sensor result
 */
abstract class SensorResult
{
  int mThreadId = 0;
  long mTimeStamp = 0;
  long mElapseTime = 0;
  int mNameIndex = 0;
  String mValue = null;// the last value
  int mHit = 0;
  
  // the gap between this sensor and previous one.
  // the previous one is parent if this sensor is the first child.
  // it should be zero if this sensor is the root in sensor tree.
  long mGap = 0;

  static DecimalFormat sDblFmt = new DecimalFormat("#,##0.00");
  static DecimalFormat sIntFmt = new DecimalFormat("###,##0");
    
  /**
   * Print out the timer result to the PrintStream
   * 
   * @param out the PrintStream where the results go
   * @param printGap flag to indicates whether to print gap attribute. 
   * <p>For sensor type of analysis, gap is meaningless.
   * @param spaces the space string preceding on each print line for indentation
   */
  abstract void print(PrintStream out, boolean printGap, String spaces);
  
  /**
   * Set sensor value, this is generic implementation. TimerResult needs to do
   * more for elapse time specific handling
   * 
   * @param value the new value
   */
  void setValue(String value)
  {
    mHit++;
    mValue = value;
  }
  
  /**
   * Get sensor value
   * @return the sensor value
   */
  String getValue()
  {
    return mValue;
  }
  
  /**
   * Set gap between this object and previous object
   * @param prev the previous sensor
   * @param isChild true if current sensor result is the child of prev
   *        <p>false if current sensor result is the next of prev
   */
  void setGap(SensorResult prev, boolean isChild)
  {
    mGap = mTimeStamp - prev.mTimeStamp;
    if (!isChild)
      mGap -= prev.mElapseTime;
  }
  
  /**
   * Aggregate the result to current object
   * @param result the sensor to be aggregated
   */
  void aggregate(SensorResult result)
  {
    mTimeStamp += result.mTimeStamp;
    setValue(result.mValue);
  }
  
  /**
   * Prepend spaces to fir the specified size
   * @param str the original string
   * @param bufSize the size to be fit
   * @return new string with prepend spaces for the size specified
   */
  static String prependSpace(String str, int bufSize)
  {
    int size = str.length();
    if (bufSize <= size)
      return str;
    StringBuffer buf = new StringBuffer(size);
    for (int i = 0; i < bufSize - size; i++)
      buf.append('_');
    buf.replace(bufSize - size, bufSize, str);
    return buf.toString();
  }
}

