package oracle.adf.share.perf.analysis;

import java.io.PrintStream;
import java.util.StringTokenizer;
import java.util.Vector;

import oracle.adf.share.perf.ADFPerfConstants;

/**
 * This analyzer analyses the performance log files based on sensor names
 */
class SensorAnalyzer extends Analyzer
{
  // a list of index sensor results
  private Vector mSensorResults = new Vector();
  
  /**
   * Add sensor index, name and type to the analyzer
   * 
   * @param index the sensor index
   * @param name the sensor name
   * @param type the sensor type
   */
  void addSensor(int index, String name, String type)
  {
    if (index+1 > mSensorResults.size())
      mSensorResults.setSize(index + 1);
    super.addSensor(index, name, type);
  }

  /**
   * Analyse the performance logging line entry
   * <p> regular line format is: <ecid> [<sensorIndex> <timeStamp> <value>]*
   * 
   * @param line regular data line
   */
  void analyseLine(String line)
  {    
    StringTokenizer st = new StringTokenizer(line, 
                                ADFPerfConstants.LOG_SEPARATOR + 
                                ADFPerfConstants.SENSOR_SEPARATOR_LEFT);
    st.nextToken();// skip ecid
    while (st.hasMoreTokens())
    {
      int index = Integer.parseInt(st.nextToken(
        ADFPerfConstants.LOG_SEPARATOR + 
        ADFPerfConstants.SENSOR_SEPARATOR_LEFT + 
        ADFPerfConstants.SENSOR_SEPARATOR_RIGHT));
      st.nextToken();// skip threadId
      st.nextToken();// skip timeStamp
      // search for ']' and ski the leading space
      String value = st.nextToken(ADFPerfConstants.SENSOR_SEPARATOR_RIGHT).substring(1);
    
    
      SensorResult result = (SensorResult)mSensorResults.get(index);
      if (sSensorTypes.get(index).equals(ADFPerfConstants.TIMER))
      {
        if (result == null)
        {
          result = new TimerResult(index);
          mSensorResults.set(index, result);
        }
      }
      else 
      {
        if (sTimerOnly) // ignore all other types of sensors
          continue;
          
        if (sSensorTypes.get(index).equals(ADFPerfConstants.COUNTER))
        {
          if (result == null)
          {
            result = new CounterResult(index);
            mSensorResults.set(index, result);
          }
        }
        else if (sSensorTypes.get(index).equals(ADFPerfConstants.STATE))
        {
          if (result == null)
          {
            result = new StateResult(index);
            mSensorResults.set(index, result);
          }
        }
      }
      
      if (result != null)
        result.setValue(value);
    }

    return;
  }
  
  /**
   * print performance logging statistic result
   */
  void print()
  {
    int size = mSensorResults.size();
    
    for (int i = 0; i < size; i++)
    {
      SensorResult result = (SensorResult)mSensorResults.get(i);
      if (result != null)
        result.print(sOut, false, "");
    }
  }
}
