package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

/**
 * The tree of sensors based on calling sequence and duration. Each request
 * have a corresponding sensor tree. Each request could use multiple threads.
 */
class SensorTree
{
  // Following TreeSet stores sensor tree root based on threadId, each 
  // threadId has its own sensor tree
  private TreeSet mThreads = new TreeSet(new ThreadComparator());
  private String mUrl = null;
  private TreeNode mUrlThread = null;
  private final static int INDENTATION_SPACES = 2;
  private static int sXmlIdCount = 0;
  private int mMinThreadCount = Integer.MAX_VALUE;
  private int mMaxThreadCount = Integer.MIN_VALUE;  
  private long mTotalThreadCount = 0;
  private long mRequestCount = 0;
  
  SensorTree(int minThreadCount, int maxThreadCount, long totalThreadCount,
             long requestCount)
  {
    mMinThreadCount = minThreadCount;
    mMaxThreadCount = maxThreadCount;
    mTotalThreadCount = totalThreadCount;
    mRequestCount = requestCount;
  }
  
  /**
   * Add a thread of sensor tree to the SensorTree. 
   */
  void addThread(TreeNode root, boolean isUrlThread)
  {     
    if (isUrlThread)
    {
      if (mUrlThread == null)
        mUrlThread = root;
      else
      {
        // there is already one thread which is marked as potential main thread
        // if the new thread also contains url state,use hit number to determine
        // which one as main. The more hits means more chance to be a main 
        // thread
        if (mUrlThread.mResult.mHit < root.mResult.mHit)
        {
          // new one has higher hits, use it as main thread
          mThreads.add(mUrlThread);
          mUrlThread = root;
        }
        else
          mThreads.add(root);
      }        
    }
    else
      mThreads.add(root);
  }
  
  /**
   * Insert sensor result to a thread tree
   * @param threadRoot the old root of thread tree to add into
   * @param result the sensor result object to be added
   * @return new root of the thread tree
   */
  TreeNode insertToThread(TreeNode threadRoot, SensorResult result)
  {
    int nameIdx = result.mNameIndex;
    
    // populate mURL
    if (mUrl == null)
      if (((String)(Analyzer.sSensorTypes.get(nameIdx))).equalsIgnoreCase("s"))
        if (((String)(Analyzer.sSensorNames.get(nameIdx))).endsWith("/url"))
          mUrl = result.getValue();

    if (!((String)(Analyzer.sSensorTypes.get(nameIdx))).equalsIgnoreCase("t") &&
        Analyzer.sTimerOnly)
      return threadRoot; // discard this SensorResult

    return add(new TreeNode(result), threadRoot);
  }
  
  /**
   * Add the new node into the tree starting from the root
   * <p>Please note this method assumes the newNode has same threadId with all
   * other nodes in the tree start from the root.
   * 
   * @param newNode the new tree node that contains new result
   * @param root the root of the tree
   * @return new tree root
   */
  private TreeNode add(TreeNode newNode, TreeNode root)
  {
    if (root == null)
      return newNode;
    
    if (newNode.mResult.mTimeStamp < root.mResult.mTimeStamp)
    {
      // New sensor starts before the root.
      
      // The sensor added later should include all sensors added earlier and
      // that has same ending timestamp. So we use the condition of '>=' here
      if (newNode.mResult.mTimeStamp + newNode.mResult.mElapseTime >=
          root.mResult.mTimeStamp + root.mResult.mElapseTime)
      {  
        // Enclose root and possible its following nodes under newNode
        enclose(newNode, root);
      }
      else
      { 
        // The new sensor is in front of root, insert before root
        newNode.mParent = root.mParent;
        if (newNode.mParent != null)
        {
          newNode.mParent.mChild = newNode;
          root.mParent = null;
        }
        
        newNode.mNext = root;
        newNode.mPrev = root.mPrev;
        if (newNode.mPrev != null)
        {
          newNode.mPrev.mNext = newNode;
          newNode.mResult.setGap(newNode.mPrev.mResult, false);
        }
        root.mPrev = newNode;        
        root.mResult.setGap(newNode.mResult, false);
      }       
      return newNode;       
    }
    else 
    {
      // newNode.mResult.mTimeStamp >= root.mResult.mTimeStamp
      // new sensor starts same or after root
      if (newNode.mResult.mTimeStamp >= 
          root.mResult.mTimeStamp + root.mResult.mElapseTime)
      {
        // add the new node from root.mNext
        newNode = add(newNode, root.mNext);
        newNode.mPrev = root;
        root.mNext = newNode;
        newNode.mResult.setGap(root.mResult, false);
        return root;
      }
      else
      {
        // newNode starts at same as root or inside root
        if (newNode.mResult.mTimeStamp + newNode.mResult.mElapseTime <= 
            root.mResult.mTimeStamp + root.mResult.mElapseTime)
        {
          if ((newNode.mResult.mTimeStamp == root.mResult.mTimeStamp) &&
              (newNode.mResult.mTimeStamp + newNode.mResult.mElapseTime ==
               root.mResult.mTimeStamp + root.mResult.mElapseTime))
          {
            // newNode starts and lasts same as root, newNode should be
            // parent of root as newNode is added later.
            
            // Note mElapseTime can't be zero here, otherwise, it should
            // have already been covered above in the condition of 
            // if (newNode.mResult.mTimeStamp >= 
            //     root.mResult.mTimeStamp + root.mResult.mElapseTime)
            // because both have same mTimeStamp.
            enclose(newNode, root);
            return newNode;
          }
          else
          {
            // newNode is completely inside root
            newNode = add(newNode, root.mChild);
            root.mChild = newNode;
            newNode.mParent = root;
            newNode.mResult.setGap(root.mResult, true);
            return root;
          }
        }
        else
        {
          // newNode ends beyond root end point
          if (newNode.mResult.mTimeStamp == root.mResult.mTimeStamp)
          {
            // newNode starts at the same time as root, but ends beyond root.
            // in this case newNode should be parent of root
            enclose(newNode, root);
            return newNode;
          }
          else
          {
            // newNode starts inside root and newNode ends after root
            // This normally only happen for different thread
            System.out.println(
              "Warning: two sensors with the same ecid and threadid" +
              " should not have following situation:");
            System.out.println( 
               " threadId=" + root.mResult.mThreadId +
               " rootNameIndex=" + root.mResult.mNameIndex + 
               " timeStamp=" + root.mResult.mTimeStamp +
               " elapseTime=" + root.mResult.mElapseTime + 
               " newNodeNameIndex=" + newNode.mResult.mNameIndex +
               " timeStamp=" + newNode.mResult.mTimeStamp +
               " elapseTime=" + newNode.mResult.mElapseTime);
               
            // still try to insert after root, but it could be problematic!!!
            
            // link newNode forward to root.mNext
            newNode.mNext = root.mNext;
            if (newNode.mNext != null)
            {
              newNode.mNext.mPrev = newNode;
              newNode.mNext.mResult.setGap(newNode.mResult, false);
            }
            
            // link newNode backward to root
            newNode.mPrev = root;
            root.mNext = newNode;
            newNode.mResult.setGap(root.mResult, false);
            return root;
          }
        }
      }
    }
  }
  
  /**
   * Enclose root and possible its following nodes under newNode
   * 
   * @param newNode
   * @param root
   */
  private void enclose(TreeNode newNode, TreeNode root)
  {
    // newNode covers root (at least one sensor)
    // now to find if newNode covers more sensors following the root
    TreeNode node = root;
    while (node.mNext != null)
    {
      if (newNode.mResult.mTimeStamp + newNode.mResult.mElapseTime >=
          node.mNext.mResult.mTimeStamp + node.mNext.mResult.mElapseTime)
        node = node.mNext;
      else 
        break;
    }
    
    // newNode covers from root to node, so make newNode the parent of
    // nodes from root to node.
    newNode.mParent = root.mParent;
    if (newNode.mParent != null)
      newNode.mParent.mChild = newNode;
    newNode.mChild = root;
    root.mParent = newNode;
    root.mResult.setGap(newNode.mResult, true);
    
    // link to remaining nodes after node.
    newNode.mNext = node.mNext;
    if (newNode.mNext != null)
    {
      newNode.mNext.mPrev = newNode;
      newNode.mNext.mResult.setGap(newNode.mResult, false);
    }
    node.mNext = null;
    
    // link to prior nodes before newNode
    newNode.mPrev = root.mPrev;
    if (newNode.mPrev != null)
    {
      newNode.mPrev.mNext = newNode;
      newNode.mResult.setGap(newNode.mPrev.mResult, false);
    }
    root.mPrev = null;
  }
  
  /**
   * Get URL for the current sensors tree which is based on same ecid.
   * 
   * @return the url for the request
   */
  String getURL()
  {
    return mUrl;
  }
  
  /**
   * Set gaps for each thread relative to the earliest sensor in one thread.
   * Normally, that thread is the main thread
   */
  void setThreadGap()
  {
    // find out the earlist timestamp of root sensor in all threads
    Iterator itr = mThreads.iterator();
    long earliestTS = mUrlThread.mResult.mTimeStamp;
    while (itr.hasNext())
    {
      TreeNode root = (TreeNode)itr.next();
      if (root.mResult.mTimeStamp < earliestTS)
        earliestTS = root.mResult.mTimeStamp;
    }
    
    // use this timestamp to set gap for each root sensor's gap
    itr = mThreads.iterator();
    while (itr.hasNext())
    {
      TreeNode root = (TreeNode)itr.next();
      root.mResult.mGap = root.mResult.mTimeStamp - earliestTS;
    }
  }
  
  /**
   * Get summary information for the tree
   * @return String representation of the avg, min, max elapse time for the tree
   */
  String getSummary()
  {
    if (mUrlThread == null)
    {
      System.out.println("Error: don't have thread that contains url sensor.");
      return "";
    }

    // use the main thread which contains url sensor for average request time
    String summary = "";
    if (mUrlThread != null)
    {
      double avg = mUrlThread.getDuration();
      summary = "request.avg=" + SensorResult.sDblFmt.format(avg);
    }
    
    if (mThreads.size() > 0)
    {
      if (mUrlThread != null)
        summary += " | ";
        
      summary += "thread.avg=" + 
        SensorResult.sDblFmt.format((double)mTotalThreadCount/mRequestCount);
      if (mMaxThreadCount != mMinThreadCount)
        summary += " | thread.max=" + mMaxThreadCount + 
                   " | thread.min=" + mMinThreadCount;
    }
    return summary;
  }
  
  /**
   * Print current SensorTree
   * 
   * @param out print stream where to print current tree
   */
  void print(PrintStream out)
  {
    // print main thread
    int depth = 1;
    if (Analyzer.sFormatXml)
      depth = 4;
    TreeNode root = mUrlThread;
    int threadSize = mThreads.size();
    if (threadSize > 0)
    {
      if (Analyzer.sFormatXml)
      {
        double gap = (double)root.mResult.mGap/root.mResult.mHit;
        double du = root.getDuration() - gap;
        out.println("      <branch id=\"thread" + (sXmlIdCount++) + "\">");
        out.println("        <branchText>" +
          "(gap=" + 
          SensorResult.prependSpace(SensorResult.sDblFmt.format(gap), 8) +
          " | avg=" + 
          SensorResult.prependSpace(SensorResult.sDblFmt.format(du), 8) + 
          ") Main Thread: </branchText>");
        depth += 4;
      }
      else
      {
        out.println("Main Thread: ");
        depth += 1;
      }
    }
   
    print(out, root, depth);
   
    if ((threadSize > 0) && Analyzer.sFormatXml)
      out.println("      </branch>");            
    
    // loop through all threads
    Iterator itr = mThreads.iterator();
    int threadCount = 1;
    while (itr.hasNext())
    {
      depth = 1;
      if (Analyzer.sFormatXml)
        depth = 4;
      root = (TreeNode)itr.next();
      if (threadSize > 0)
      {
        if (Analyzer.sFormatXml)
        {
          double gap = (double)root.mResult.mGap/root.mResult.mHit;
          double du = root.getDuration() - gap;
          out.println("      <branch id=\"thread" + (sXmlIdCount++) + "\">");
          out.println("        <branchText>" + 
            "(gap=" + 
            SensorResult.prependSpace(SensorResult.sDblFmt.format(gap), 8) +
            " | avg=" + 
            SensorResult.prependSpace(SensorResult.sDblFmt.format(du), 8) + 
            ") Thread pattern: " + threadCount + "</branchText>");
          depth += 4;
        }
        else
        {
          out.println("Thread pattern: " + threadCount);
          depth += 1;
        }
        threadCount++;
      }
      // else don't print thread number  
      
      print(out, root, depth);
      
      if ((threadSize > 0) && Analyzer.sFormatXml)
        out.println("      </branch>");        
    }    
  }
  
  /**
   * Print each node in the tree
   * 
   * @param out output stream
   * @param root the root of the tree
   * @param depth the level of current subtree
   */
  void print(PrintStream out, TreeNode root, int depth)
  {
    // print indentation based on the tree depth
    byte[] spaces = new byte[INDENTATION_SPACES * (depth-1)];
    
    for (int i = 0; i < spaces.length; i++)
      spaces[i] = ' ';
    String indent = new String(spaces);
  
    if (Analyzer.sFormatXml)
    {
      if (root.mChild != null)
      {
        out.println(indent + "<branch id=\"id" + (sXmlIdCount++) + "\">");
        out.println(indent + "  <branchText>");
      }
      else
      {
        out.println(indent + "<leaf>");
        out.println(indent + "  <leafText>");
      }
    }

    root.mResult.print(out, true, indent);

    if (Analyzer.sFormatXml)
    {
      if (root.mChild != null)
        out.println(indent + "  </branchText>");
      else
        out.println(indent + "  </leafText>");
    }
    
    if (root.mChild != null)
      print(out, root.mChild, depth+1);
      
    if (Analyzer.sFormatXml)
    {
      if (root.mChild != null)
        out.println(indent + "</branch>");
      else
        out.println(indent + "</leaf>");
    }

    if (root.mNext != null)
      print(out, root.mNext, depth);
  } 
  
  class ThreadComparator implements Comparator
  {
    public int compare(Object o1, Object o2)
    {
      TreeNode t1 = (TreeNode)o1;
      TreeNode t2 = (TreeNode)o2;
      if (t1.mResult.mHit < t2.mResult.mHit)
        return 1;
      else if (t1.mResult.mHit == t2.mResult.mHit)
        return 1; // set only contain unique object, so if two hits are same, 
                  // we treat them as first one is less than second one.
      else
        return -1;      
    }
  }
}
