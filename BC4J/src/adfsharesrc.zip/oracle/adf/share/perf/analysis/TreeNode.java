package oracle.adf.share.perf.analysis;

/**
 * Tree node class
 */
class TreeNode
{
  SensorResult mResult = null;
  
  TreeNode mChild = null; // points to the sensors inside this one
  TreeNode mParent = null;// points to the enclosure sensor 
  
  // for sensors in the same thread and one after another
  TreeNode mNext = null;
  TreeNode mPrev = null;
  
  TreeNode(SensorResult result)
  {
    mResult = result;
  }

  double getDuration()
  {
    double duration = 0;
    TreeNode node = this;
    while (node != null)
    {
      duration += (double)(node.mResult.mGap + node.mResult.mElapseTime)/
                           node.mResult.mHit;
      node = node.mNext;
    }
    return duration;
  }

}

