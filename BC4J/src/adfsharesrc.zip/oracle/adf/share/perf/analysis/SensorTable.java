package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The table of sensors based on calling sequence and duration. Each request
 * have a corresponding sensor table. Each request could use multiple threads.
 */
class SensorTable 
{
  // mThreads is a hash map of threads, and each thread is SensorThread
  private LinkedHashMap mThreads = new LinkedHashMap();
  private String mEcid = null;
  private String mUrl = null;

  private int mMinThreadCount = Integer.MAX_VALUE;
  private int mMaxThreadCount = Integer.MIN_VALUE;  
  private long mTotalThreadCount = 0;
  private long mRequestCount = 0;
  private int mThreadIdCounter = 5000;
  private final static int INDENTATION_SPACES = 2;
  private final static double IGNORE_THREAD_RATIO = 
                                Analyzer.sAllPattern? 0: 0.05;
  
  /**
   * Construct the tree based on ecid
   * 
   * @param ecid request ecid
   */
  SensorTable(String ecid)
  {
    mEcid = ecid;
  }
  
  /**
   * Add a result to the sensor tree. 
   * <p>At beginning, to simplify the processing, we add the result based on
   * threadId so that the sensors with same threadId will be in its own tree
   * 
   * @param result sensor result
   */
  void add(SensorResult result)
  {
    int nameIdx = result.mNameIndex;
    boolean setUrlThread = false;
    
    // populate mUrl
    if (((String)(Analyzer.sSensorTypes.get(nameIdx))).equalsIgnoreCase("s"))
      if (((String)(Analyzer.sSensorNames.get(nameIdx))).endsWith("/url"))
      {
        mUrl = result.getValue();
        setUrlThread = true;
      }
        
    // add to the sensor table
    Integer key = new Integer(result.mThreadId);
    SensorThread thread = (SensorThread)mThreads.get(key);
    if (thread == null)
    {
      thread = new SensorThread(); // create a new one if this is a new thread
      mThreads.put(key, thread);
    }
    if (setUrlThread)
      thread.setHaveUrl();
      
    if (((String)(Analyzer.sSensorTypes.get(nameIdx))).equalsIgnoreCase("t") ||
        !Analyzer.sTimerOnly)
      thread.add(result);   
  }

  /**
   * Get URL for the current sensors table which is based on same ecid.
   * 
   * @return the url for the request
   */
  String getURL()
  {
    return mUrl;
  }
  
  /**
   * reBaseTimeStamp based on the earliest thread
   */
  void reBaseTimeStamp()
  {
    // find out the earliest timestamp of all threads
    Iterator itr = mThreads.entrySet().iterator();
    long earliestTS = Long.MAX_VALUE;
    while (itr.hasNext())
    {     
      SensorThread thread = (SensorThread)((Map.Entry)itr.next()).getValue();
      if (thread.getEarliestTimeStamp() < earliestTS)
        earliestTS = thread.getEarliestTimeStamp();
    }
    
    // use this earliest time stamp to rebase all sensors in all threads.
    itr = mThreads.entrySet().iterator();
    while (itr.hasNext())
    {
      SensorThread thread = (SensorThread)((Map.Entry)itr.next()).getValue();
      thread.reBaseTimeStamp(earliestTS);
    }    
  }
  
  /**
   * print the sensor table
   * @param out the output stream to print
   */
  void print(PrintStream out)
  {
    // loop through all threads
    Iterator itr = mThreads.entrySet().iterator();
    int threadCount = 1;
    int threadSize = mThreads.size();
    while (itr.hasNext())
    {
      int depth = 1;
      Map.Entry entry = (Map.Entry)itr.next();
      SensorThread thread = (SensorThread)entry.getValue();
      if (threadSize > 1)
      {
        out.println("Thread " + threadCount + ": [id=" + entry.getKey() + "]");
        depth += 1;
        threadCount++;
      }
      // else don't print thread number  
      
      thread.print(out, depth);
    }        
  }
  
  /**
   * Aggregate the sensors in table to current SensorTable 
   * @param table
   */
  void aggregate(SensorTable table)
  {
    if (mTotalThreadCount == 0) 
    {
      // initialization, this SensorTable never aggregated with others
      mTotalThreadCount = mThreads.size();
      mMaxThreadCount = mThreads.size();
      mMinThreadCount = mThreads.size();
      mRequestCount = 1;
    }
    
    if (table.mThreads.size() > mMaxThreadCount)
      mMaxThreadCount = table.mThreads.size();
    if (table.mThreads.size() < mMinThreadCount)
      mMinThreadCount = table.mThreads.size();      
    mTotalThreadCount += table.mThreads.size();
    mRequestCount++;
    
    Iterator srcItr = table.mThreads.entrySet().iterator();
    while (srcItr.hasNext())
    {
      boolean matchThread = false;
      Map.Entry entry = (Map.Entry)srcItr.next();
      SensorThread srcThread = (SensorThread)entry.getValue();
      SensorThread tgtThread = null;
      Iterator tgtItr = mThreads.entrySet().iterator();
      while (!matchThread && tgtItr.hasNext())
      {
        entry = (Map.Entry)tgtItr.next();
        tgtThread = (SensorThread)entry.getValue();
        matchThread = tgtThread.match(srcThread);
      }
      if (matchThread)
        tgtThread.aggregate(srcThread);
      else if (mRequestCount * IGNORE_THREAD_RATIO < 100)
      {
        // does not match and we still collect all patterns, 
        // append the src thread to target mThreads
        mThreads.put(new Integer(mThreadIdCounter++), srcThread);
      }
      // else does not match and this will be too rare pattern to be used
    }
  }
  
  /**
   * Convert from SensorTable to SensorTree
   * <p>To be more readable, we ignore these SensorTables that only have less
   * than 5% (IGNORE_THREAD_RATIO) of pattern.
   * 
   * @return converted SensorTree
   */
  SensorTree convertToTree()
  {
    if (mTotalThreadCount == 0) 
    {
      // initialization, this SensorTable never aggregated with others
      mTotalThreadCount = mThreads.size();
      mMaxThreadCount = mThreads.size();
      mMinThreadCount = mThreads.size();
      mRequestCount = 1;
    }

    SensorTree tree = new SensorTree(mMinThreadCount, mMaxThreadCount,
                                     mTotalThreadCount, mRequestCount);

    // loop through all threads
    int threadCount = 0;
    Iterator itr = mThreads.entrySet().iterator();
    while (itr.hasNext())
    {
      threadCount++;
      Map.Entry entry = (Map.Entry)itr.next();
      SensorThread thread = (SensorThread)entry.getValue();
      SensorResult root = (SensorResult)thread.getSensors().get(0);
      if (root.mHit < IGNORE_THREAD_RATIO * mRequestCount)
        continue;
        
      // iterate through all sensors in one thread
      TreeNode threadTree = null;
      ArrayList sensors = thread.getSensors(); 
      Iterator sItr = sensors.iterator();
      while (sItr.hasNext())
      {
        SensorResult result = (SensorResult)sItr.next();
        result.mThreadId = threadCount;
        threadTree = tree.insertToThread(threadTree, result);
      }
      
      if (threadTree != null)
        tree.addThread(threadTree, thread.hasUrl());
    }
    return tree;
  }
  
  /**
   * Collection of sensors in a thread
   */
  private class SensorThread
  {
    private long mEarliestTS = Long.MAX_VALUE; // track ealiest time
    private ArrayList mSensors = new ArrayList(); // a array of sensors
    private boolean mHasUrl = false;
    
    ArrayList getSensors()
    {
      return mSensors;
    }
    
    /**
     * Set flag to mark this thread has url, which means it is the candidate
     * as main thread
     */
    void setHaveUrl()
    {
      mHasUrl = true;
    }
    
    /**
     * Get the flag to indicate whether this thread contains url.
     * @return whether contains url 
     */
    boolean hasUrl()
    {
      return mHasUrl;
    }
    
    /**
     * Add a sensor result to the thread
     * @param result
     */
    void add(SensorResult result)
    {
      mSensors.add(result);
      // set earliest time stamp
      if (mEarliestTS > result.mTimeStamp)
        mEarliestTS = result.mTimeStamp;
    }
    
    /**
     * Get earliest time stamp of all sensors in the thread
     * @return
     */
    long getEarliestTimeStamp()
    {
      return mEarliestTS;
    }
    
    /**
     * Reset all sensors' timestamp based on the startTime
     * @param startTime
     */
    void reBaseTimeStamp(long startTime)
    {
      Iterator iter = mSensors.iterator();
      while (iter.hasNext())
      {
        SensorResult result = (SensorResult)iter.next();
        result.mTimeStamp -= startTime;
      }
    }
    
    /**
     * Print SensorTable for debugging purpose
     * @param out output stream to print
     * @param depth the depth of indentation for print format
     */
    void print(PrintStream out, int depth)
    {
      // print indentation based on the tree depth
      byte[] spaces = new byte[INDENTATION_SPACES * (depth-1)];
      
      for (int i = 0; i < spaces.length; i++)
        spaces[i] = ' ';
      String indent = new String(spaces);

      Iterator iter = mSensors.iterator();
      while (iter.hasNext())
      {
        SensorResult result = (SensorResult)iter.next();
        result.print(out, false, indent);
      }
    }
    
    /**
     * Check if current thread match with the passing thread
     * @param thread the thread to compare with current one
     * @return true if matches, false if does not match
     */
    boolean match(SensorThread thread)
    {
      // first check the size, which should filter out many thread quickly
      boolean match = (mSensors.size() == thread.mSensors.size());
      if (!match) return false;
      
      // when the sizes are same, there is better chance two threads have
      // same pattern, check sensors are in the same order
      int size = mSensors.size();
      for (int i = 0; i < size; i++)
      {
        SensorResult result1 = (SensorResult)mSensors.get(i);
        SensorResult result2 = (SensorResult)thread.mSensors.get(i);
        match = (result1.mNameIndex == result2.mNameIndex);
        if (!match)
          return false;
      }

      return true;
    }
    
    /**
     * Aggregate the sensors in thread with sensors in current SensorThread
     * <p> This method should be called only after match() is true
     * @param thread source thread to be aggregated
     */
    void aggregate(SensorThread thread)
    {
      int size = mSensors.size();
      for (int i = 0; i < size; i++)
      {
        SensorResult result1 = (SensorResult)mSensors.get(i);
        SensorResult result2 = (SensorResult)thread.mSensors.get(i);
        result1.aggregate(result2);
      }      
    }
  }
}
