package oracle.adf.share.perf.analysis;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

import oracle.adf.share.perf.ADFPerfConstants;

/**
 * This analyzer analyses the performance log files based on requests
 */
class RequestAnalyzer extends Analyzer
{  
  // max number of requests in the mRequests hashtable. 
  private static final int MAX_NUM_REQUESTS = 1000;
  private static int sIdCount = 0;
  
  // mRequests stores all requests
  // key is ecid, value is SensorTree for that ecid
  private LinkedHashMap mRequests = new LinkedHashMap();
  // the master aggregated sensor tables
  // key is url, and value could be Integer counter if the url has been
  // hit less than sExcludeCount, or be master SensorTable for the url
  // if the url has been hit more than sExcludeCount
  private Hashtable mMasterSensorTables = new Hashtable();
  
  /**
   * Analyse the performance logging line entry
   * <p> regular line format is: <ecid> [<sensorIndex> <timeStamp> <value>]*
   * 
   * @param line regular data line
   */
  void analyseLine(String line)
  {    
    StringTokenizer st = new StringTokenizer(line, 
      ADFPerfConstants.LOG_SEPARATOR + 
      ADFPerfConstants.SENSOR_SEPARATOR_LEFT);
    String ecid = removeSeqNum(st.nextToken());
    SensorTable table = (SensorTable)mRequests.get(ecid);
    if (table == null)
    {
      table = new SensorTable(ecid);
      mRequests.put(ecid, table);
    }
      
    while (st.hasMoreTokens())
    {
      int index = Integer.parseInt(st.nextToken(
        ADFPerfConstants.LOG_SEPARATOR + 
        ADFPerfConstants.SENSOR_SEPARATOR_LEFT + 
        ADFPerfConstants.SENSOR_SEPARATOR_RIGHT));
      int threadId = Integer.parseInt(st.nextToken());
      long timeStamp = Long.parseLong(st.nextToken());
      // search for ']' and ski the leading space
      String value = st.nextToken(ADFPerfConstants.SENSOR_SEPARATOR_RIGHT).substring(1);
      SensorResult result = null;
    
      if (sSensorTypes.get(index).equals(ADFPerfConstants.TIMER))
        result = new TimerResult(index);
      else if (sSensorTypes.get(index).equals(ADFPerfConstants.COUNTER))
        result = new CounterResult(index);
      else if (sSensorTypes.get(index).equals(ADFPerfConstants.STATE))
        result = new StateResult(index);
      if (result != null)
      {
        result.mThreadId = threadId;
        result.mTimeStamp = timeStamp;
        result.setValue(value);
        table.add(result);
      }
    }
    
    if (mRequests.size() >= MAX_NUM_REQUESTS)
    {
      // Too many requests in the mRequests hashmap, aggregate some of them
      // before adding more.
      // This is to avoid out of memory
      Iterator keys = mRequests.keySet().iterator();
      int count = 0;

      // reduce the mRequest size
      while (keys.hasNext() && (count < MAX_NUM_REQUESTS/2))
      {
        count++;
        addToMasterTable(keys);
      }
    }
    return;
  }
  
  /**
   * Add the SensorTable to the master table
   * @param keys interator that points to current processing key entry
   */
  private void addToMasterTable(Iterator keys)
  {
    Object key = keys.next();
    SensorTable curTable = (SensorTable)mRequests.get(key);
    String url = curTable.getURL();
    
    // ignore those lines without url, this would happen if the some of log
    // entries are still in the buffer and has not been flushed.
    if (url == null) return; 
    
    curTable.reBaseTimeStamp();
    if (sDebug)
    {
      sOut.println("DEBUG: ecid=" + key + " url=" + url);
      sOut.println("=====================================================");
      curTable.print(sOut);
    }
    Object value = mMasterSensorTables.get(url);

    if (value == null) // the first time hiting a new url
    {
      if (sExcludeCount > 0)
      {
        // discard this curTree
        mMasterSensorTables.put(url, new Integer(1));
        if (sDebug)
          sOut.println("Excluded it from aggregation.");
      }
      else
      {
        mMasterSensorTables.put(url, curTable);
      }
    } 
    else // has value for the url
    {
      if (value instanceof Integer)
      {
        int curCount = ((Integer)value).intValue();
        curCount++;
        if (sExcludeCount < curCount)
        {
          mMasterSensorTables.put(url, curTable);
        }
        else
        {
          // discard this curTree
          mMasterSensorTables.put(url, new Integer(curCount));
          if (sDebug)
            sOut.println("Excluded it from aggregation.");
        }
      } 
      else
      {
        // instanceof SensorTree
        SensorTable masterTable = (SensorTable)value;
        masterTable.aggregate(curTable);
        if (sDebug)
        {
          sOut.println("DEBUG: after aggregate");
          sOut.println("=====================================================");
          masterTable.print(sOut);
        }
      }
    }
    keys.remove();
  }

  /**
   * print performance logging statistic result
   */
  void print()
  {    
    // firstly, merge requests based on URL and get aggregated numbers
    Iterator keys = mRequests.keySet().iterator();
    while (keys.hasNext())
      addToMasterTable(keys);
      
    // secondly, create SensorTree based on SensorTable
    Hashtable masterTreeTables = convertToTreeTables(mMasterSensorTables);
    
    // thirdly, print aggregated trees based on url
    if (sFormatXml)
    {
      sOut.println("<?xml version=\"1.0\" ?>");
      sOut.println("<?xml-stylesheet type=\"text/xsl\" href=\"xmlTree.xsl\"?>");
      sOut.println("<!DOCTYPE tree SYSTEM 'tree.dtd'>");
      sOut.println("<tree>");
    }
    else
    {
      sOut.println("===================SUMMARY REPORT====================");
      sOut.println();
    }
    keys = masterTreeTables.keySet().iterator();
    while (keys.hasNext())
    {
      String url = (String)keys.next();
      Object tree = masterTreeTables.get(url);
      if (!(tree instanceof SensorTree))
        continue;
      SensorTree masterTree = (SensorTree)tree;
      masterTree.setThreadGap();
      if (sFormatXml)
      {
        sOut.println("  <branch id=\"url" + (sIdCount++) + "\">");
        sOut.println("    <branchText>(" + masterTree.getSummary() + 
                    ") " + htmlEncode(url) + "</branchText>");
      }
      else
      {
        sOut.println("[" + masterTree.getSummary() + "] " + url);
        sOut.println("=====================================================");
      }
      
      masterTree.print(sOut);
      
      if (sFormatXml)
        sOut.println("  </branch>");
      else
      {
        sOut.println("=====================================================");
        sOut.println();
      }
    }
    if (sFormatXml)
      sOut.println("</tree>");
  }
  
  /**
   * Convert to SensorTrees from SensorTables. 
   * 
   * @param sensorTables hashtable of SensorTable for each url
   * @return a hashtable of SensorTrees converted from SensorTables
   */
  private static Hashtable convertToTreeTables(Hashtable sensorTables)
  {
    Hashtable treeTables = new Hashtable();
    
    Iterator keys = sensorTables.keySet().iterator();
    while (keys.hasNext())
    {
      String url = (String)keys.next();
      Object obj = sensorTables.get(url);
      if (!(obj instanceof SensorTable))
        continue;
        
      SensorTable table = (SensorTable)obj;
      SensorTree tree = table.convertToTree();
      treeTables.put(url, tree);      
    }
    
    return treeTables;
  }
  
  /**
   * Remove sequence number from ecid. Sequence number is separated by ','
   * @param ecid
   * @return the ecid without sequence number
   */
  private String removeSeqNum(String ecid)
  {
    int idx = ecid.lastIndexOf(',');
    if (idx != -1)
      ecid = ecid.substring(0, idx);
    return ecid;
  }
}
