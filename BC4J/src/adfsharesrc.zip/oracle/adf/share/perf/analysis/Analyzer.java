package oracle.adf.share.perf.analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import java.net.URL;

import java.util.StringTokenizer;
import java.util.Vector;

import oracle.adf.share.perf.ADFPerfConstants;

/**
 * Analyzer - Analysis tool for adf perf logging
 */
public class Analyzer 
{
  // analysis types:
  // sensor type: aggregate based to sensor name, regardless ecid. This is
  // only useful in normal java application where no concept of request.
  // request type: aggregate based on request (or ecid). This is more useful
  // for web request
  private static final String SENSOR = "sensor";
  private static final String REQUEST = "request";
  
  private static final String FILE_SEPARATOR = 
    System.getProperty("file.separator");
  private static final int PROGRESS_UPDATE_GAP = 100;

  // a list of indexed sensor types
  protected static Vector sSensorTypes = new Vector();
  // a list of indexed sensor names
  protected static Vector sSensorNames = new Vector();
  // exclude number of sensors or requests from aggregating statistics
  protected static int sExcludeCount = 0;
  // output stream
  protected static PrintStream sOut = null;
  // Analysis types
  protected static final int TYPE_SENSOR = 1;
  protected static final int TYPE_REQUEST = 2;
  protected static int sAnalysisType = TYPE_SENSOR;
  
  // aggregate timers or all types of sensors
  private static final String AGGTYPE_ALL = "all";
  protected static boolean sTimerOnly = true;
  
  // output format related constants and variables
  private static final String FORMAT_XML = "xml";
  protected static boolean sFormatXml = false;
  protected static boolean sAllPattern = false;
  protected static boolean sDebug = false;
  
  /**
   * Main entry point for the analysis tool
   * @param args arguments have following format:
   * -t sensor|request 
   * -x &lsaquo;exclude_warmup_counter&rsaquo;
   * -a all|timers
   * &lsaquo;perflog_path&rsaquo; &lsaquo;output_file_name&rsaquo;
   */
  public static void main(String[] args)
  {
    if ((args == null) || (args.length < 2))
    {
      System.out.println("Usage: java -cp <classpath> " +
        "oracle.adf.share.perf.analysis.Analyser " +
        "[-t sensor|request] [-x <exclude_warmup_counter>] [-a all|timer] " + 
        "[-f text|xml] [-p] [-d] <perflog_path> <output_file_name>");
      System.out.println("Option -t: choose processing type:");
      System.out.println("    sensor - aggregate the performance statistics based on sensor name");
      System.out.println("    request - aggregate the performance statistics based on request");
      System.out.println("    default is 'sensor'");
      System.out.println("Option -x: exclude specified number of warmup encounters to sensors");
      System.out.println("    default is to exclude nothing");
      System.out.println("Option -a: aggregate what type of sensors:");
      System.out.println("    all - aggregate all types of sensors");
      System.out.println("    timers - aggregate timers only");
      System.out.println("    default is to aggregate timers only");
      System.out.println("Option -f: format of the output file (applicable for request type only):");
      System.out.println("    text - pure text format");
      System.out.println("    xml - xml format which can be transformed to tree control html document");
      System.out.println("    default is to use text");
      System.out.println("Option -p: aggregate and report all thread patterns");
      System.out.println("    default is to aggregate and report only top 95% thread patterns and ignore rare (<5%) thread patterns");
      System.out.println("Option -d: debug analysis processing (applicable for request type and text format only)");
      System.out.print("For example: to analyze the performance log file ");
      System.out.print("in /tmp/log directory based on requests, ");
      System.out.print("and exclude the first 5 requests from statistics. ");
      System.out.println("Send result report to result.txt in current working directory.");
      System.out.println(">java oracle.adf.share.perf.analysis.Analyser -t request -x 5 /tmp/log result.txt");
      return;
    }
    
    try
    {
      String type = SENSOR;
      int argc = 0;
      String arg = args[argc++];
      while (true)
      {
        if (arg.equalsIgnoreCase("-t"))
        {
          type = args[argc++];
          arg = args[argc++];
        }
        else if (arg.equalsIgnoreCase("-x")) 
        {
          sExcludeCount = Integer.parseInt(args[argc++]);
          arg = args[argc++];
        }
        else if (arg.equalsIgnoreCase("-a")) 
        {
          String agg = args[argc++];
          if (agg.equalsIgnoreCase(AGGTYPE_ALL))
            sTimerOnly = false;
          arg = args[argc++];
        }
        else if (arg.equalsIgnoreCase("-f")) 
        {
          String agg = args[argc++];
          if (agg.equalsIgnoreCase(FORMAT_XML))
            sFormatXml = true;
          arg = args[argc++];
        }
        else if (arg.equalsIgnoreCase("-p")) 
        {
          sAllPattern = true;
          arg = args[argc++];
        }
        else if (arg.equalsIgnoreCase("-d")) 
        {
          sDebug = true;
          arg = args[argc++];
        }
        else
          break;
      }
      String path = arg + FILE_SEPARATOR;
      String outFile = args[argc++];
      
      // xml format only applies to request type analysis
      if (!type.equalsIgnoreCase(REQUEST))
        sFormatXml = false;
        
      // force text format and request type analysis
      if (sDebug)
      {
        sFormatXml = false;
        type = REQUEST;
      }
        
      if (sFormatXml)
      {
        // change the extension to .xml
        int ext = outFile.lastIndexOf('.');
        if (ext != -1)
          outFile = outFile.substring(0, ext) + ".xml";
        else
          outFile += ".xml";
          
        // copy a bunch of supporting files from resources 
        // to the same place as output file
        File file = new File(outFile);
        String parent = file.getParent();
        String files[] = {"closed.gif", "doc.gif", "open.gif", "tree.dtd",
                          "xmlTree.css", "xmlTree.js", "xmlTree.xsl"};
        try
        {
          byte[] buf = new byte[1024];
          for (int i = 0; i < files.length; i++)
          {
            URL url = Analyzer.class.getResource("resources/" + files[i]);
            InputStream in = url.openStream();
            OutputStream out = new FileOutputStream(new File(parent, files[i]));
            
            // Transfer bytes from in to out
            int len;
            while ((len = in.read(buf)) > 0)
              out.write(buf, 0, len);
            in.close();
            out.close();            
          }
        }
        catch (Exception e)
        {
          e.printStackTrace(System.out);
          System.exit(-1);
        }
      }                    
       
      sOut = new PrintStream(new FileOutputStream(outFile));
      Analyzer analyzer = getAnalyzer(type);
      analyzer.analyse(path);
      analyzer.print();
    }
    catch (Exception e)
    {
        e.printStackTrace(System.out);
    }
    return;
  }
  
  /**
   * Get corresponsing analyzer based on the type of analysis
   * 
   * @param type the type of analysis
   */
  private static Analyzer getAnalyzer(String type)
  {
    if (type.equalsIgnoreCase(SENSOR))
    {
      sAnalysisType = TYPE_SENSOR;
      return new SensorAnalyzer();
    }
    else if (type.equalsIgnoreCase(REQUEST))
    {
      sAnalysisType = TYPE_REQUEST;
      return new RequestAnalyzer();
    }
    else
    {
      sAnalysisType = TYPE_SENSOR;
      return new Analyzer();
    }
  }
  
  /**
   * Analyze the performance log file
   * 
   * @param perfFilePath performance log file path
   */
  void analyse(String perfFilePath)
  {
    String fn = perfFilePath + ADFPerfConstants.PERFLOG_FILE_PREFIX + 
                ADFPerfConstants.PERFLOG_FILE_SUFFIX;
    process(fn);
    for (int i = getNumberOfLogFile(perfFilePath); i >= 0; i--)
    {
      fn = perfFilePath + ADFPerfConstants.PERFLOG_FILE_PREFIX + i + 
           ADFPerfConstants.PERFLOG_FILE_SUFFIX;
      process(fn);
    }    
  }
  
  /**
   * Process perf log file
   * @param fn perf log file name
   */
  void process(String fn)
  {
    System.out.println("Processing " + fn + "...");
    try
    {
      BufferedReader br = new BufferedReader(new FileReader(fn));
      
      String line;
      int lineCount = 0;
      System.out.print("  Processing line# 1");
      while ((line = br.readLine()) != null)
      {
        lineCount++;
        if (lineCount % PROGRESS_UPDATE_GAP == 0)
          System.out.print(" " + lineCount);
          
        // the perf logging line has following three formats:
        // # comments
        // I <index> <sensorName> <sensorType>
        // <ecid> [<index> <startTimeStamp> <value>]*
        if (line.startsWith(ADFPerfConstants.COMMENT_PREFIX))
          continue; // skip the comment
        else if (line.startsWith(ADFPerfConstants.INDEX_PREFIX))
        {
          StringTokenizer st = new StringTokenizer(line);
          st.nextToken(); // skip "I "
          int index = Integer.parseInt(st.nextToken());
          String name = st.nextToken();
          String type = st.nextToken();
          addSensor(index, name, type);
        }
        else if (line.startsWith(ADFPerfConstants.DATETIME_PREFIX))
          continue; // skip the date time stamp
        else
          analyseLine(line);
      }
      
      System.out.println("");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }    
  }
  
  /**
   * Analyse the performance logging line entry
   * <p> regular line format is: <ecid> [<sensorIndex> <timeStamp> <value>]*
   * 
   * @param line regular data line
   */
  void analyseLine(String line)
  {    
     // noop for generic analyzer, leave to subclass to implement
  }
  
  /**
   * Add a sensor based on index
   * @param index the index for the sensor
   * @param name the name of the sensor
   * @param type the type of the sensor
   */
  void addSensor(int index, String name, String type)
  {
    if (index+1 > sSensorNames.size())
      sSensorNames.setSize(index + 1);
    if (index+1 > sSensorTypes.size())
      sSensorTypes.setSize(index + 1);

    sSensorNames.set(index, name);
    sSensorTypes.set(index, type);
  }  

  /**
   * print performance logging statistic result
   */
  void print()
  {
    // noop for generic analyzer, leave to subclass to implement
  }
  
  /**
   * Get number of performance log file
   * 
   * @param perfFilePath performance log file path
   * @return the number of performance log file
   */
  private int getNumberOfLogFile(String perfFilePath)
  {
    int count = 0;
    while (true)
    {
      String fn = perfFilePath + ADFPerfConstants.PERFLOG_FILE_PREFIX + count + 
                  ADFPerfConstants.PERFLOG_FILE_SUFFIX;
      File f = new File(fn);
      if (!f.exists())
        break;
      count++;
    }
    count--;
    return count;
  }
  
  /**
   * Encode any text string to be html compatible
   * 
   * @param str input string
   * @return encoded string
   */
  static String htmlEncode(String str)
  {
    if (str == null)
      return null;
    str = str.replaceAll("&", "&amp;");
    str = str.replaceAll("<", "&lt;");
    str = str.replaceAll(">", "&gt;");
    return str;
  }
}
