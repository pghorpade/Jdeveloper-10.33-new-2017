package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

/**
 * Timer sensor result
 */
class TimerResult extends SensorResult
{
  int mMax = Integer.MIN_VALUE;
  int mMin = Integer.MAX_VALUE;
  
  /**
   * Constructor with name index
   * 
   * @param nameIndex the index to sSensorNames
   */
  TimerResult(int nameIndex)
  {
    mNameIndex = nameIndex;
  }
  
  /**
   * Set a value (elapse time) to the timer result
   * 
   * @param value elapsed time
   */
  void setValue(String value)
  {
    mHit++;
    mValue = value;
    int intValue = Integer.parseInt(value);
    mElapseTime += intValue;
    if (intValue > mMax)
      mMax = intValue;
    if (intValue < mMin)
      mMin = intValue;
  }
  
  /**
   * Print out the timer result to the PrintStream
   * 
   * @param out the PrintStream where the results go
   * @param printGap flag to indicates whether to print gap attribute. 
   * <p>For sensor type of analysis, gap is meaningless.
   * @param spaces the space string preceding on each print line for indentation
   */
  void print(PrintStream out, boolean printGap, String spaces)
  {
    String fullName = (String)Analyzer.sSensorNames.get(mNameIndex);
    
    if (Analyzer.sFormatXml)
    {
      int sep = fullName.lastIndexOf('/');
      String name = fullName.substring(sep + 1);
      String group = fullName.substring(0, sep);
      out.print("Timer: (");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |");
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | avg=" + 
                prependSpace(sDblFmt.format((double)mElapseTime/mHit), 6));
      out.print(" | min=" + prependSpace(sDblFmt.format(mMin), 6));
      out.print(" | max=" + prependSpace(sIntFmt.format(mMax), 6));
      out.print(" )");
      out.println(" " + name + " [" + group + "]");
    }
    else
    {
      out.println(spaces + "Timer:" + fullName + " [id=" + mNameIndex + "]");
      out.print(spaces + "(");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |");
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | avg=" + 
                prependSpace(sDblFmt.format((double)mElapseTime/mHit), 6));
      out.print(" | min=" + prependSpace(sDblFmt.format(mMin), 6));
      out.print(" | max=" + prependSpace(sIntFmt.format(mMax), 6));
      if (Analyzer.sDebug)
        out.print(" | ts=" + prependSpace(sIntFmt.format(mTimeStamp), 6));
      out.println(" )");
      out.println("");
    }
  }
}
