package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

/**
 * Counter sensor result
 */
class CounterResult extends SensorResult
{
  /**
   * Constructor with name index
   * 
   * @param nameIndex the index to sSensorNames
   */
  CounterResult(int nameIndex)
  {
    mNameIndex = nameIndex;
  }

  /**
   * Print out the counter result to the PrintStream
   * 
   * @param out the PrintStream where the results go
   * @param printGap flag to indicates whether to print gap attribute. 
   * <p>For sensor type of analysis, gap is meaningless.
   * @param spaces the space string preceding on each print line for indentation
   */
  void print(PrintStream out, boolean printGap, String spaces)
  {
    String fullName = (String)Analyzer.sSensorNames.get(mNameIndex);
    
    if (Analyzer.sFormatXml)
    {
      int sep = fullName.lastIndexOf('/');
      String name = fullName.substring(sep + 1);
      String group = fullName.substring(0, sep);
      out.print("Count: (");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |");
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | cnt=" + mValue);
      out.print(" )");
      out.println(" " +  name + " [" + group + "]");        
    }
    else
    {
      out.println(spaces + "Counter:" + fullName + " [id=" + mNameIndex + "]");
      out.print(spaces + "(");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |");
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | cnt=" + mValue);
      if (Analyzer.sDebug)
        out.print(" | ts=" + prependSpace(sIntFmt.format(mTimeStamp), 6));
      out.println(" )");
      out.println("");
    }
  }
}
