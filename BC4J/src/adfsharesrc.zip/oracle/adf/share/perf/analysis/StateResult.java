package oracle.adf.share.perf.analysis;

import java.io.PrintStream;

/**
 * State sensor result
 */
class StateResult extends SensorResult
{
  /**
   * Constructor with name index
   * 
   * @param nameIndex the index to sSensorNames
   */
  StateResult(int nameIndex)
  {
    mNameIndex = nameIndex;
  }
  
  /**
   * Print out the state result to the PrintStream
   * 
   * @param out the PrintStream where the results go
   * @param printGap flag to indicates whether to print gap attribute. 
   * <p>For sensor type of analysis, gap is meaningless.
   * @param spaces the space string preceding on each print line for indentation
   */
  void print(PrintStream out, boolean printGap, String spaces)
  {
    String fullName = (String)Analyzer.sSensorNames.get(mNameIndex);
    
    // For request analysis type, the excluded request won't put into the 
    // Sensor Result, so mHitCount is the count already excluding the unwanted
    // hits. 
    // For sensor analysis type, mHitCount includes unwanted hits, but mSum and
    // mAvg does not include unwanted hits, so we need to deduct 
    // Analyzer.sExcludeCount from mHitCount    
    if (Analyzer.sFormatXml)
    {
      int sep = fullName.lastIndexOf('/');
      String name = fullName.substring(sep + 1);
      String group = fullName.substring(0, sep);
      out.print("State: (");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |");
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | state=" + Analyzer.htmlEncode(mValue));
      out.print(" )");
      out.println(" " + name + " [" + group + "]");         
    }
    else
    {
      out.println(spaces + "State:" + fullName + " [id=" + mNameIndex + "]");
      out.print(spaces + "(");
      if (printGap)
        out.print(" gap=" + 
                  prependSpace(sDblFmt.format((double)mGap/mHit), 6) + " |"); 
      out.print(" hit=" + prependSpace(sIntFmt.format(mHit), 6));
      out.print(" | state=" + mValue);
      if (Analyzer.sDebug)
        out.print(" | ts=" + prependSpace(sIntFmt.format(mTimeStamp), 6));
      out.println(" )");
      out.println("");
    }
  }
}
