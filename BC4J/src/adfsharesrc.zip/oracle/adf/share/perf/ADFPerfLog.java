package oracle.adf.share.perf;

import java.text.DateFormat;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.dms.instrument.ExecutionContext;

/**
 * ADF performance logging class. The only public method in this class is to
 * flush out the performance logging content in the buffer when the application 
 * is running in the normal j2se environment where is no request boundary.
 */
public class ADFPerfLog 
{
  // perf logger level
  private static Level sLevel = null;
  // perf logger object
  private static Logger sLog = null;
  private static Logger sIdxLog = null;
  // perf logging buffer size
  private static int sBufSize = 100;
  // max perf logging sensor per line
  private static final int MAXSENSORS_PER_LINE = 12;
  
  private static final String LINE_SEPARATOR = System.getProperty("line.separator");

  // This buffer is used to store all PerfLogRecords in processing.  
  // The key is the ECID, all sensors with same ECID are in a linked list as 
  // value, but the number of sensors in the linked list should not exceed 
  // LOGRECORDS_PER_LINE
  private static LinkedHashMap sLogRecordBuffer = 
    new LinkedHashMap(sBufSize, (float)0.75, true);
    
  // This buffer is used by application to store PerfLogLine from 
  // sLogRecordBuffer, and DumpPerfLogthread to consume (send to logger)
  private static LinkedList sDumpBuffer = new LinkedList();
  
  // The thread for dumping perf log line
  private static Thread sThread = null;
  
  // adf performance logger name
  private static final String ADFNAME = "oracle.adf.perf"; //NO TRANS
  private static final String ADFNAME_IDX = "oracle.adf.perfIdx"; // NO TRANS
  
  /**
   * Get ADFPerfLog logger level
   * 
   * @return ADFPerfLog logger level
   */
  public static Level getLevel()
  {
    if (sLevel == null)
    {
      // this system property is set in PerfHandlerFactory to indicate
      // the handler has been initiated or not.
      sLog = Logger.getLogger(ADFNAME);
      if (System.getProperty(ADFPerfConstants.JVM_PROP_PERF_HANDLER) != null)
      {
        if (sLog == null)
          sLevel = Level.OFF;// no logger - level is default to off
        else
        {
          Logger log = sLog;
          while ((sLevel = log.getLevel()) == null)
          {
            log = log.getParent();
            if (log == null) 
            {
              sLevel = Level.SEVERE; // with logger - level is default to SEVERE
              break;
            }
          }
          
          if (sLevel != null)
          {
            String bufSize = System.getProperty(ADFPerfConstants.JVM_PROP_BUFSIZE);
            if (bufSize != null)
              sBufSize = Integer.parseInt(bufSize);
          }
          Handler[] handlers = sLog.getHandlers();
          
          // Set the performance logging formatter here for future use...
          // Currently performance logging does not use this formatter,
          // it formats the message in various place. We should move the 
          // logic to the PerfFormatter when we add new features in the future.
          Formatter formatter = new PerfFormatter();
          for (int i = 0; i < handlers.length; i++)
            handlers[i].setFormatter(formatter);
            
          createIdxLogger(sLevel, formatter);
            
          // output a few line of heads
          sIdxLog.log(sLevel, PerfFormatter.LOG_LINE_FORMAT);
          
          DateFormat format = DateFormat.getDateTimeInstance(DateFormat.FULL, 
                                                             DateFormat.LONG);
          sIdxLog.log(sLevel, ADFPerfConstants.DATETIME_PREFIX + 
                              format.format(new Date(PerfFormatter.STARTTIME)) +
                              " (" + PerfFormatter.STARTTIME + ")" +
                              LINE_SEPARATOR);
        }
      }
      else
        // perf logging FileHandler never initialized, it means perf logging is
        // off
        sLevel = Level.OFF;
    }
    
    return sLevel;
  }
  
  /**
   * Create companion index logger for header and index information. 
   * <p>The main performance log files are rotated and will eventually be 
   * overridden when log content grows over the limit. The companion index 
   * logger keep the critical index information in separate file and should
   * never be overridden.
   * @param level the same level as main performance logger
   * @param formatter the formatter to be used by index logger
   */
  static private void createIdxLogger(Level level, Formatter formatter)
  {
    // use same level as sLog
    sIdxLog = Logger.getLogger(ADFNAME_IDX);
    sIdxLog.setLevel(level);
    sIdxLog.setUseParentHandlers(false);
    String path = System.getProperty(ADFPerfConstants.JVM_PROP_PERF_PATH);
    FileHandler handler = null;
    try
    {
      handler = new FileHandler(path + 
                                ADFPerfConstants.FILE_SEPARATOR +
                                ADFPerfConstants.PERFLOG_FILE_PREFIX + 
                                ADFPerfConstants.PERFLOG_FILE_SUFFIX, 
                                false);
      handler.setFormatter(formatter);
      
      Handler[] handlers = sIdxLog.getHandlers();
      for (int i = 0; i < handlers.length; i++)
        sIdxLog.removeHandler(handlers[i]);      
      sIdxLog.addHandler(handler);
    }
    catch (Exception e)
    {
      // fall back to use main performance logger
      sIdxLog = sLog;
    }    
  }
  
  /**
   * Get perf logger object
   * 
   * @return perf logger object
   */
  static Logger getLogger()
  {
    return sLog;
  }
  
  /**
   * Get performance index logger object
   * 
   * @return perf index logger object
   */
  static Logger getIdxLogger()
  {
    return sIdxLog;
  }
  
  /**
   * Add log record to perf logging buffer. If the buffer is full, send to 
   * logger object
   * 
   * @param record PerfLogRecord
   * @param ecid Execution id
   */
  static void addLogRecord(PerfLogRecord record, String ecid)
  {
    LinkedList recordList = null;
    
    if (ecid == null)
      ecid = getECID();

    if (ecid == null)
      return;
      
    ecid = removeSeqNum(ecid);
    
    synchronized (sLogRecordBuffer)
    {
      recordList = (LinkedList)sLogRecordBuffer.get(ecid);
      if (recordList == null)
      {
        // no map entry exists for the current ecid, create one
        recordList = new LinkedList();
        sLogRecordBuffer.put(ecid, recordList);
      }
        
      recordList.add(record);
              
      // when the log records exceeds LOGRECORDS_PER_LINE in the map entry
      // remove that map entry
      if (recordList.size() >= MAXSENSORS_PER_LINE)
        recordList = (LinkedList)sLogRecordBuffer.remove(ecid);
      else
      {
        recordList = null;
      
        if (sLogRecordBuffer.size() > sBufSize)
        {
          // when the buffer size exceeds limit, find the least used ecid 
          Iterator iter = sLogRecordBuffer.keySet().iterator();
          if (iter.hasNext())
          {
            ecid = (String)iter.next();
            recordList = (LinkedList)sLogRecordBuffer.remove(ecid);
          }
        }
      }
      
      if (recordList != null)
        printList(ecid, recordList); // print that map entry
    }
  }
  
  /**
   * Flush the map entry identified by current ecid from internal perf logging 
   * buffer 
   */
  public static void flushLog()
  {
    LinkedList recordList = null;

    String ecid = getECID();
    
    if (ecid == null)
      return;

    ecid = removeSeqNum(ecid);
    
    synchronized (sLogRecordBuffer)
    {
      recordList = (LinkedList)sLogRecordBuffer.remove(ecid);
      
      if (recordList != null)
        printList(ecid, recordList);
    }
  }
  
  /**
   * Print log record list identified by ecid and recordList
   * 
   * @param ecid ECID for sensor log records
   * @param recordList sensor log record list
   */
  private static void printList(String ecid, LinkedList recordList)
  {
    if ((recordList == null) || (recordList.size() == 0))
      return;
      
    PerfLogLine line = new PerfLogLine(ecid, recordList);
    synchronized (sDumpBuffer)
    {
      // start up the dump thread if it has not
      if (sThread == null)
      {
        DumpPerfLogThread dt = new DumpPerfLogThread(sDumpBuffer);
        sThread = new Thread(dt, DumpPerfLogThread.class.getName());
        sThread.setPriority(Thread.MIN_PRIORITY);
        sThread.setDaemon(true);
        sThread.start();     
      }
      
      sDumpBuffer.add(line);// append to the tail of the list
      sDumpBuffer.notify();
    }
  }
    
  /**
   * Remove sequence number from ecid. Sequence number is separated by ','
   * @param ecid
   * @return the ecid without sequence number
   */
  static private String removeSeqNum(String ecid)
  {
    int idx = ecid.lastIndexOf(',');
    if (idx != -1)
      ecid = ecid.substring(0, idx);
    return ecid;
  }
    /**
   * Get ECID for current thread
   * 
   * @return the ecid string
   */
  public static String getECID()
  {
    String ecid = null;
    try
    {
      ExecutionContext execCtx = ExecutionContext.get();
      ecid = execCtx.getECIDasString();
      if (ecid == null)
      {
        // calling setECID(null) will initialize the context with a new ECID
        execCtx.setECID(null);
        ecid = execCtx.getECIDasString();
      }
    }
    catch (NoClassDefFoundError e)
    {
      // ignore this exception, it would happen when dms does not exist in 
      // class path
    }
    return ecid;
  }

  /**
   * Set ECID for current thread
   * 
   * @param ecid the ecid string. Normally it can be retrieved from getECID
   * from another thread which already has ecid set
   */
  public static void setECID(String ecid)
  {
    try
    {
      ExecutionContext execCtx = ExecutionContext.get();
      execCtx.setECID(ExecutionContext.parseECID(ecid));
    }
    catch (NoClassDefFoundError e)
    {
      // ignore this exception, it would happen when dms does not exist in 
      // class path
    }
  }
}
