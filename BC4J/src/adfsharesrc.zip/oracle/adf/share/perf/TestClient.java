package oracle.adf.share.perf;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.logging.ConsoleFormatter;
import oracle.adf.share.perf.StateTracker;

public class TestClient 
{
  public TestClient()
  {
  }
  
  public static void testLogFileHandler()
  {
    String ADFNAME = "oracle.adf.perf";

    Logger log = Logger.getLogger(ADFNAME);
    //StreamHandler sh = new StreamHandler(System.out, new ConsoleFormatter());
    
    FileHandler sh = null;
    try
    {
      sh = new FileHandler("d:/temp/perf/log%g.log",1000, 5, true);
    }
    catch(Exception e)
    {
      e.printStackTrace();
      return;
    }

    sh.setLevel(ADFLogger.TRACE);
    sh.setFormatter(new ConsoleFormatter());
    log.addHandler(sh);
    log.setLevel(ADFLogger.TRACE);
    log.setUseParentHandlers(false);


    for(int i=0;i < 1000; i ++)
    {
      log.log(Level.INFO, "test" + i);    
    }
  }
  
  
  public static void main(String[] args)
  {
    // testLogFileHandler();

    long s = 10l;
    
    for(int i = 0; i < 100; i ++)
    {
      Timer t = null;
      Counter c = null;
      StateTracker state = null;
      try 
      {
        t = Timer.createTimer(Level.INFO, "oracle.adf.demo","TestTimer-1", "Timer One");
        c = Counter.createCounter(Level.INFO, "oracle.adf.demo","TestCounter-1","counter");
        
        state = StateTracker.createStateTracker(Level.INFO, "oracle.adf.demo","TestState",StateTracker.INTEGER , "ms", "state tracker");
        // c.occurred();
        t.start();
        state.increment(1);
        Thread.sleep(s);  
        t.stop();
      } catch (Exception ex) 
      {
        ex.printStackTrace();
      } finally 
      {
        t.cleanup();
      }
    }
    
    
  }
}

class TestThread implements Runnable
{
  public TestThread()
  {
    
  }
  
  public void run()
  {
    long s = 10l;
    
    for(int i = 0; i < 10; i ++)
    {
    Timer t=null;
    try 
    {
      t = Timer.createTimer(Level.INFO, "oracle.adf.demo","TestTimer-2", "Timer 2");
       t.start();
      Thread.sleep(s);  
    } catch (Exception ex) 
    {
      ex.printStackTrace();
    } finally 
    {
      t.stop();
    }
    }
    
  }
}