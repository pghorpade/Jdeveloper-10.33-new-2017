package oracle.adf.share.perf;

import java.io.File;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.List;

import oracle.core.ojdl.logging.HandlerFactory;
import oracle.core.ojdl.logging.HandlerFactoryException;

/**
 * Factory class for performance logging handler
 */
public class PerfHandlerFactory implements HandlerFactory
{
  private static final String FILE_SEPARATOR = System.getProperty("file.separator");
  // the properties defined in the log config file
  private Properties mProperties;
  // the property name map from lower case to the one used in log config file
  private HashMap mNameMap;
  // a list of valid properties the handler support
  private static final List sProperties =
    Arrays.asList(new String[] 
    {
      ADFPerfConstants.PATH.toLowerCase(),
      ADFPerfConstants.MAXFILESIZE.toLowerCase(),
      ADFPerfConstants.MAXLOGSIZE.toLowerCase(),
      ADFPerfConstants.LEVEL.toLowerCase(),
      ADFPerfConstants.BUFFERSIZE.toLowerCase()
    });                                                      

  /**
   * Create log handler based on configuration properties
   * 
   * @param properties hanlder configuration properties
   * @return the handler object
   * @throws HandlerFactoryException
   */
  public Handler create(Properties properties)
    throws HandlerFactoryException
  {
    // verify that the property names are valid 
    // and create a map of property lowercase value to actual name
    mProperties = properties;
    mNameMap = new HashMap(properties.size());
    for (Enumeration en = properties.propertyNames(); en.hasMoreElements();) 
    {
      String name = (String)en.nextElement();
      String lname = name.toLowerCase();

      if (!sProperties.contains(lname)) 
        throw new HandlerFactoryException("Invalid property name: " + name);

      mNameMap.put(lname, name);
    }

    // get the value and validate each property

    String path = getProperty(ADFPerfConstants.PATH);
    if (path == null) 
      throw new HandlerFactoryException("Required property 'path' not found.");
    System.setProperty(ADFPerfConstants.JVM_PROP_PERF_PATH, path);

    long fileSize = getLongProperty(ADFPerfConstants.MAXFILESIZE);
    if (fileSize <= 0) 
      throw new HandlerFactoryException("Invalid maxFileSize value: " + 
        getProperty(ADFPerfConstants.MAXFILESIZE));

    long logSize = getLongProperty(ADFPerfConstants.MAXLOGSIZE);
    if (logSize <= 0) 
      throw new HandlerFactoryException("Invalid maxLogSize value: " +
        getProperty(ADFPerfConstants.MAXLOGSIZE));

    if (logSize < fileSize)
      throw new HandlerFactoryException(
        "Invalid configuration: " + ADFPerfConstants.MAXLOGSIZE +
        " cannot be less than " + ADFPerfConstants.MAXFILESIZE);

    String bufSize = getProperty(ADFPerfConstants.BUFFERSIZE);
    if (bufSize != null)
      System.setProperty(ADFPerfConstants.JVM_PROP_BUFSIZE, bufSize);

    // create and configure the handler
    Handler handler = null;
    try
    {
      int count = (int)(logSize / fileSize);      
      createLogDir(path);    
      handler = new FileHandler(path + 
                                FILE_SEPARATOR +
                                ADFPerfConstants.PERFLOG_FILE_PREFIX + "%g" + 
                                ADFPerfConstants.PERFLOG_FILE_SUFFIX, 
                                (int)fileSize, count, false);
      System.setProperty(ADFPerfConstants.JVM_PROP_PERF_HANDLER, "yes");
    } 
    catch (Exception e) 
    {
      throw new HandlerFactoryException(
        "Failed to create ADF Performance Handler", e);
    }

    return handler;
  }
  
  /**
   * Create directory for log files
   * 
   * @param name directory path
   * @throws Exception
   */
  private static void createLogDir(String name) throws Exception 
  {
    File bsDir = new File(name);

    try 
    {
      if (bsDir.exists()) 
      {
        if (!bsDir.isDirectory()) 
          throw new Exception(name + " is not a directory");
      } 
      else 
      {
        if (!bsDir.mkdirs())
          throw new Exception("cannot create directory " + name);
      }
      if (!bsDir.canWrite()) 
        throw new Exception("cannot write to directory " + name);
    } 
    catch (SecurityException e) 
    {
      throw new Exception("access to log directory " + name + " is denied");
    }
    
    // remove all perf log files from previous run
    int count = 0;
    while (true)
    {
      String fn = name + FILE_SEPARATOR + ADFPerfConstants.PERFLOG_FILE_PREFIX + 
                  count + ADFPerfConstants.PERFLOG_FILE_SUFFIX;
      File f = new File(fn);
      if (!f.exists())
        break;
      f.delete();
      count++;
    }
  }

  /**
   * Get property value of long type
   * 
   * @param name property name, which is case insensitive
   * @return property value of long type
   * @throws HandlerFactoryException
   */
  private long getLongProperty(String name)
      throws HandlerFactoryException
  {
    String value = getProperty(name);
    if (value == null) 
      return Long.MAX_VALUE;
    
    try 
    {
      return Long.parseLong(value);
    }
    catch (Exception e) 
    {
      throw new HandlerFactoryException("Invalid value for property "
                                        + mNameMap.get(name) + ": " + value);
    }
  }

  /**
   * Get property value of string type
   * 
   * @param name property name, which is case insensitive
   * @return property value
   */
  private String getProperty(String name) 
  {
    String pname = (String)mNameMap.get(name.toLowerCase());
    if (pname != null) 
      return mProperties.getProperty(pname);
    else 
      return null;
  }
}
