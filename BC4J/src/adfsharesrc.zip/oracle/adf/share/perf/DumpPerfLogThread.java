package oracle.adf.share.perf;

import java.util.LinkedList;

import oracle.adf.share.logging.ADFLogger;

class DumpPerfLogThread implements Runnable
{
  // diagnostic logger 
  private static ADFLogger sDiagLogger = 
    ADFLogger.createADFLogger(DumpPerfLogThread.class);
    
  // FIFO PerfLogLine buffer
  private LinkedList mBuffer;
  
  DumpPerfLogThread(LinkedList buffer)
  {
    mBuffer = buffer;
  }
  
  /**
   * Run dump performance logging content thread
   */
  public void run()
  {
    while (true)
    {
      try
      {
        PerfLogLine line = null;
        synchronized (mBuffer)
        {
          if (mBuffer.size() != 0)
            line = (PerfLogLine)mBuffer.removeFirst();
          else
            mBuffer.wait();
        }
        if (line != null)
          ADFPerfLog.getLogger().log(line);
      }
      catch (Exception e)
      {
        sDiagLogger.throwing(DumpPerfLogThread.class.getName(), "run", e);
      }
    }
  }
}
