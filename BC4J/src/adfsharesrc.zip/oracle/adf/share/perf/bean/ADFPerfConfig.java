package oracle.adf.share.perf.bean;
import oracle.adf.share.config.ADFConfigImpl;
import oracle.adf.share.perf.ADFPerfConstants;
import oracle.adf.share.perf.bean.ADFPerfConfigMBean;

public class ADFPerfConfig implements ADFPerfConfigMBean
{
  private String path;
  private long MaxFileSize;
  private long MaxLogSize;
  private String Level;
  private int BufferSize;
  
  private ADFConfigImpl ac = null;

  public ADFPerfConfig(ADFConfigImpl ac)
  {
    this.ac = ac;
  }

  public String getPath()
  {
    path = ac.getPerfConfig(ADFPerfConstants.PATH);
    return path;
  }

  public void setPath(String path)
  {
    this.path = path;
    ac.setPerfConfig(ADFPerfConstants.PATH,path);
  }

  public long getMaxFileSize()
  {
    MaxFileSize = Long.parseLong(ac.getPerfConfig(ADFPerfConstants.MAXFILESIZE));
    return MaxFileSize;
  }

  public void setMaxFileSize(long MaxFileSize)
  {
    this.MaxFileSize = MaxFileSize;
    ac.setPerfConfig(ADFPerfConstants.MAXFILESIZE,String.valueOf(MaxFileSize));
  }

  public long getMaxLogSize()
  {
    MaxLogSize = Long.parseLong(ac.getPerfConfig(ADFPerfConstants.MAXLOGSIZE));
    return MaxLogSize;
  }

  public void setMaxLogSize(long MaxLogSize)
  {
    this.MaxLogSize = MaxLogSize;
    ac.setPerfConfig(ADFPerfConstants.MAXLOGSIZE,String.valueOf(MaxLogSize));
  }

  public String getLevel()
  {
    Level = ac.getPerfConfig(ADFPerfConstants.LEVEL);
    return Level;
  }

  public void setLevel(String Level)
  {
    this.Level = Level;
    ac.setPerfConfig(ADFPerfConstants.LEVEL, Level);
  }

  public int getBufferSize()
  {
    BufferSize = Integer.parseInt(ac.getPerfConfig(ADFPerfConstants.BUFFERSIZE));
    return BufferSize;
  }

  public void setBufferSize(int BufferSize)
  {
    this.BufferSize = BufferSize;
    ac.setPerfConfig(ADFPerfConstants.BUFFERSIZE, String.valueOf(BufferSize));
  }
}