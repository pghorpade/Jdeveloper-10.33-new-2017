
package oracle.adf.share.perf.bean;

import javax.management.*;
import javax.management.modelmbean.*;
import oracle.adf.share.config.ADFConfigImpl;

// Referenced classes of package oracle.adf.share.perf.bean:
//            ADFPerfConfig

public class ModelBeanDescriptor
{
  private String dClassName = "oracle.adf.share.perf.bean.ADFPerfConfig";

  private String dDescription = "ADF Performance Config Management Bean.";

  private ModelMBeanAttributeInfo dAttributes[] = new ModelMBeanAttributeInfo[5];
  private ModelMBeanConstructorInfo dConstructors[] = new ModelMBeanConstructorInfo[1];
  private ModelMBeanOperationInfo dOperations[] = new ModelMBeanOperationInfo[10];
  private ModelMBeanNotificationInfo dNotifications[] = new ModelMBeanNotificationInfo[1];

  private Descriptor mmbDesc = null;
  private ModelMBeanInfo dMBeanInfo = null;

  private ADFConfigImpl ac = null;
  private MBeanServer server = MBeanServerFactory.createMBeanServer();

  public ModelBeanDescriptor(ADFConfigImpl ac)
  {
    this.ac = ac;
  }

  public boolean register()
  {
    String name = "name=adfperfconfig";
    boolean ret = false;
    name = server.getDefaultDomain() + ":" + name;
    try
    {
      ObjectName obj = new ObjectName(name);
      boolean flag = register(obj, name);
      return flag;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    boolean flag1 = false;
    return flag1;
  }

  public boolean register(ObjectName mbeanObjectName, String mbeanName)
  {
    String mbeanClassName = "javax.management.modelmbean.RequiredModelMBean";
    buildDynamicMBeanInfo(mbeanObjectName, mbeanName);
    try
    {
      RequiredModelMBean modelmbean = new RequiredModelMBean(dMBeanInfo);
      modelmbean.setManagedResource(new ADFPerfConfig(ac), "objectReference");
      server.registerMBean(modelmbean, mbeanObjectName);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      boolean flag = false;
      return flag;
    }
    return true;
  }

  private ModelMBeanAttributeInfo buildMbeanAttrInfo (
      String name,
      String desc,
      String type
      )
    {
      String getMethodName = "get";
      String setMethodName = "set";
      
      if ((name != null) && (name.length() > 1))
      {
        String vName = name.toUpperCase().substring(0,1) + name.subSequence(1,name.length());
        getMethodName += vName;
        setMethodName += vName;
        
      }
      else return null;
      
      Descriptor stateDesc = new DescriptorSupport();
      stateDesc.setField("name", name);
      stateDesc.setField("descriptorType", "attribute");
      // stateDesc.setField("displayName", "MyState");
      stateDesc.setField("getMethod", getMethodName);
      stateDesc.setField("setMethod", setMethodName);
      stateDesc.setField("currencyTimeLimit", "20");
      ModelMBeanAttributeInfo ret = new ModelMBeanAttributeInfo(
              name, 
              type, 
              desc, 
              true, 
              true, 
              false, 
              stateDesc);
      return ret;
  }
   
  private ModelMBeanOperationInfo buildMbeanGetOperInfo(
    String name,
    String desc,
    String type
  )
  {
    Descriptor getStateDesc = new DescriptorSupport(new String[] {"name="+name,
                                                        "descriptorType=operation",
                                                        "role=operation"} );

    return new ModelMBeanOperationInfo(name,
                                                   desc,
                                                   null ,
                                                   type,
                                                   MBeanOperationInfo.ACTION,
                                                   getStateDesc);

  }
  
  private ModelMBeanOperationInfo buildMbeanSetOperInfo(
    String name,
    String desc,
    String type
    )
  {
      Descriptor setStateDesc = new DescriptorSupport(new String[] {
                                                        "name=" + name,
                                                        "descriptorType=operation",
                                                        "role=operation"});

      MBeanParameterInfo[] setStateParms = new MBeanParameterInfo[] { (new MBeanParameterInfo("newValue",
                                                                                              type,
                                                                                              "new value") )} ;

      return new ModelMBeanOperationInfo(name,
                                                   desc,
                                                   setStateParms,
                                                   type, //"void"
                                                   MBeanOperationInfo.ACTION,
                                                   setStateDesc);

  }
  private void buildDynamicMBeanInfo(ObjectName inMbeanObjectName, String inMbeanName)
  {
    try
    {
      mmbDesc = new DescriptorSupport(new String[] {("name="+inMbeanObjectName),
                                        "descriptorType=mbean",
                                        ("displayName="+inMbeanName),
                                        //"log=T",
                                        //"logfile=jmxmain.log",
                                        "currencyTimeLimit=5"});

        
      dAttributes[0] = buildMbeanAttrInfo("path","ADF Performance Log Path", "java.lang.String");
      dAttributes[1] = buildMbeanAttrInfo("maxFileSize","ADF Performance Log Max File Size", "long");
      dAttributes[2] = buildMbeanAttrInfo("maxLogSize","ADF Performance Log Max Log Size", "long");
      dAttributes[3] = buildMbeanAttrInfo("bufferSize","ADF Performance Log Internal Buffer Size", "int");
      dAttributes[4] = buildMbeanAttrInfo("level","ADF Performance Log Level", "java.lang.String");
      
      dOperations[0] = buildMbeanGetOperInfo("getPath","get ADF Performance Log Path", "java.lang.String");
      dOperations[1] = buildMbeanSetOperInfo("setPath","set ADF Performance Log Path", "java.lang.String");

      dOperations[2] = buildMbeanGetOperInfo("getMaxFileSize","Get ADF Performance Log Max File Size", "long");
      dOperations[3] = buildMbeanSetOperInfo("setMaxFileSize","set ADF Performance Log Max File Size", "long");
      
      dOperations[4] = buildMbeanGetOperInfo("getMaxLogSize","get ADF Performance Log Max Log Size", "long");
      dOperations[5] = buildMbeanSetOperInfo("setMaxLogSize","set ADF Performance Log Max Log Size", "long");
      
      dOperations[6] = buildMbeanGetOperInfo("getBufferSize","get ADF Performance Log Internal Buffer Size", "int");
      dOperations[7] = buildMbeanSetOperInfo("setBufferSize","set ADF Performance Log Internal Buffer Size", "int");

      dOperations[8] = buildMbeanGetOperInfo("getLevel","get ADF Performance Log Level", "java.lang.String");
      dOperations[9] = buildMbeanSetOperInfo("setLevel","set ADF Performance Log Level", "java.lang.String");
      
      dMBeanInfo = new ModelMBeanInfoSupport(dClassName, 
                                             dDescription, 
                                             dAttributes, 
                                             null,
                                             dOperations, 
                                             null);
      dMBeanInfo.setMBeanDescriptor(mmbDesc);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

}
