package oracle.adf.share.perf.bean;

public interface ADFPerfConfigMBean 
{
  public String getPath();
  public void setPath(String path);
  public long getMaxFileSize();
  public void setMaxFileSize(long MaxFileSize);
  public long getMaxLogSize();
  public void setMaxLogSize(long MaxLogSize);
  public String getLevel();
  public void setLevel(String Level);
  public int getBufferSize();
  public void setBufferSize(int BufferSize);
}