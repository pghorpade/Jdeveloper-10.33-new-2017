/*
 * @(#)StateTracker.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.perf;

import java.util.logging.Level;

import oracle.dms.instrument.Noun;
import oracle.dms.instrument.Sensor;
import oracle.dms.instrument.State;

/**
 * This class is a wrapper of DMS State sensor. It encapsulates sensor 
 * group name(Noun) and sensor name. 
 * <p>
 * @version 10.1.3, 02/15/05
 * @since 10.1.3
 */
 public class StateTracker extends ADFPerfSensor
{
  public static final byte DOUBLE = State.DOUBLE;
  public static final byte INTEGER = State.INTEGER;
  public static final byte LONG = State.LONG;
  public static final byte OBJECT = State.OBJECT;
    
  // Type
  private byte mType;
  
  // Unit
  private String mUnit;
  
  // DMS State
  private State mState = null;

  /**
   * Create a StateTracker object identified by the sensorFullName.
   * <p>
   * Internally, this method creates a DMS State sensor.
   * <p>
   * The DMS State sensor has following metrics: 
   * value, count, minValue, maxValue.
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param sensorFullName   the sensor full name, which is a container of
   *  related sensors that cover certain aspect of a feature. 
   * @param valueType        the type of data to be maintained in this State, 
   *  which must be one of DOUBLE, LONG, INTEGER, or OBJECT
   * @param unit             the unit of the value. For example, if the state 
   *  is "60 M", then the value is "60", and the unit should be "M".
   * @param state DMS state sensor
   */
  private StateTracker(
    Level  level,
    String sensorFullName,
    byte   valueType,
    String unit,
    State state
  )
  {
    super(level, sensorFullName);
    mType = valueType;
    mUnit = unit;    
    mState = state;
  }

  /**
   * Add increasedAmount to the value of the state.
   * 
   * @param increasedAmount the new value to add to the current value of the
   * State.
   */
  public void increment(double increasedAmount)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;
      
    mState.increment(increasedAmount);
    if (mEnablePerfLog)
      log(Double.toString(increasedAmount));
  }

  /**
   * Add increasedAmount to the value of the state.
   * 
   * @param increasedAmount the new value to add to the current value of the
   * State.
   */
  public void increment(int increasedAmount)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.increment(increasedAmount);
    if (mEnablePerfLog)
      log(Integer.toString(increasedAmount));
  }

  /**
   * Add increasedAmount to the value of the state.
   * 
   * @param increasedAmount the new value to add to the current value of the
   * State.
   */
  public void increment(long increasedAmount)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.increment(increasedAmount);
    if (mEnablePerfLog)
      log(Long.toString(increasedAmount));
  }
  
  /**
   * Update the value of the State.
   * 
   * @param newValue the new value for the State.
   */
  public void update(double newValue)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.update(newValue);
    if (mEnablePerfLog)
      log(Double.toString(newValue));
  }
  
  /**
   * Update the value of the State.
   * 
   * @param newValue the new value for the State.
   */
  public void update(int newValue)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.update(newValue);
    if (mEnablePerfLog)
      log(Integer.toString(newValue));
  }

  /**
   * Update the value of the State.
   * 
   * @param newValue the new value for the State.
   */
  public void update(long newValue)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.update(newValue);
    if (mEnablePerfLog)
      log(Long.toString(newValue));
  }

  /**
   * Update the value of the State.
   * 
   * @param newValue the new value for the State.
   */
  public void update(Object newValue)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mState.update(newValue);
    if (mEnablePerfLog)
      log(newValue.toString());
  }

  /**
   * Create a Counter object identified by the groupName and the name.
   * <p>
   * Developers should then call Counter's increment(), update() methods
   * to track the state object. 
   * <p>
   * Internally, this method creates a DMS Event sensor. 
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   *                         The component_id is also used as StateTracker type
   * @param name             the stateTracker name.
   * @param valueType        the type of data to be maintained in this State, 
   *                         which must be one of DOUBLE, LONG, INTEGER, or OBJECT.
   * @param unit             the label for the units of the value.
   * @param desc             the description for this StateTracker.
   * 
   * @return StateTracker    the new StateTracker object
   */
  public static StateTracker createStateTracker(
    Level  level,
    String groupName,
    String name,
    byte   valueType,
    String unit,
    String desc
  )
  {
    String nounType = PerfUtil.getNounType(groupName);
    return createStateTracker(level, groupName, name, nounType, valueType, unit, 
                              desc);    
  }

  /**
   * Create a Counter object identified by the groupName and the name.
   * <p>
   * Developers should then call Counter's increment(), update() methods
   * to track the state object. 
   * <p>
   * Internally, this method creates a DMS Event sensor. 
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   * @param name             the stateTracker name.
   * @param type             the stateTracker type which collects all sensors
   *                         with same type and display them together in a table 
   *                         in AggreSpy
   * @param valueType        the type of data to be maintained in this State, 
   *                         which must be one of DOUBLE, LONG, INTEGER, or OBJECT.
   * @param unit             the label for the units of the value.
   * @param desc             the description for this StateTracker.
   * 
   * @return StateTracker    the new StateTracker object
   */
  public static StateTracker createStateTracker(
    Level  level,
    String groupName,
    String name,
    String type,
    byte   valueType,
    String unit,
    String desc
  )
  {
    groupName = PerfUtil.standardizeGroupName(groupName);
    name = PerfUtil.standardizeSensorName(name);

    String fullName = groupName + 
                      ADFPerfConstants.NAME_SEPARATOR + 
                      name + ADFPerfConstants.LOG_SEPARATOR + 
                      ADFPerfConstants.STATE;

    ADFPerfSensor state = PerfUtil.getSensor(fullName);
    
    if ((state != null) && (state instanceof StateTracker))
    {
      // already created
      return (StateTracker)state;
    }
    else
    {
      // first time hit this sensor
      State st = null;
      
      if ((ADFPerfLog.getLevel().intValue() <= level.intValue()) || 
          (PerfUtil.getDMSSensorLevel().intValue() <= level.intValue()))
      {      
        // create DMS sensor if the level is lower
        Noun parentNoun = Noun.create(groupName);
        parentNoun.setType(type);
        st = State.create(parentNoun, name, valueType, unit, desc);
        st.deriveMetric(Sensor.all);
      }
      StateTracker tr = new StateTracker(level, fullName, valueType, unit, st);
      tr = (StateTracker)PerfUtil.putSensor(fullName, tr);
      return tr;
    }
  }

  /**
   * Send sensor's metrics to performance logs.
   */
  private void log(String value)
  {
    if ((mUnit != null) && (mUnit.length() != 0))
      value = value + mUnit;
    log(System.currentTimeMillis(), value, null);
  }
}

