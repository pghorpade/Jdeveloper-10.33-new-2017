/* $Header: TimerToken.java 22-mar-2006.17:37:07 shalin Exp $ */

/* Copyright (c) 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    This class define the timer token object to be used by timer.startWithToken,
    timer.stopWithToken, and Timer.cleanupWithToken.

   NOTES
    Developer should not create nor access the content in the Token object. It
    should be treated as opaque object used by Timer.

   MODIFIED    (MM/DD/YY)
    shalin      03/20/06 - Creation
 */

package oracle.adf.share.perf;

import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * This class defines the object type return from Timer.startWithToken(), and
 * used by Timer.endWithToken() or cleanupWithToken()
 * <p>
 * Developer should not create nor access the content in the Token object. It
 * should be treated as opaque object used by Timer.
 *
 *  @version $Header: TimerToken.java 22-mar-2006.17:37:07 shalin Exp $
 *  @author  shalin
 *  @since   10.1.3
 */

public class TimerToken
{
  boolean mStarted = false;
  long    mDMSToken = 0;
  String  mEcid = null;
    
  /**
   * Constructor for TimerToken
   * @param started indicate if the Timer has started or not
   * @param dmsToken store the dms token for phase event
   * @param isSameThread flag to indicate if the start and stop call will
   * be in same thread. If they are in different thread, then we use the
   * thread id and ecid of the starting thread. 
   */
  TimerToken(boolean started, long dmsToken, boolean isSameThread)
  {
    mStarted = started;
    mDMSToken = dmsToken;
    if (!isSameThread)
    {
      mEcid = ADFPerfLog.getECID();
    }
  }
}
