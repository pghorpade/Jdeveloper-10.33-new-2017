package oracle.adf.share.perf;

import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * Performance logging reocrd
 */
class PerfLogRecord extends LogRecord
{
  // performance sensor index, each distinct sensor has its unique index number
  private int mIndex = 0;
  
  /**
   * Constructor of performance logging record
   * 
   * @param level - the level of the record
   * @param value - the value of the record
   */
  PerfLogRecord(Level level, String value)
  {
    super(level, value);
  }
  
  /**
   * Set the index of the sensor to the record
   * 
   * @param index the index of the sensor
   */
  void setIndex(int index)
  {
    mIndex = index;
  }
  
  /**
   * Get the index number for the sensor
   * 
   * @return the sensor index number
   */
  int getIndex()
  {
    return mIndex;
  }
}
