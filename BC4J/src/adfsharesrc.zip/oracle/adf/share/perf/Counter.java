/*
 * @(#)Counter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.perf;

import java.util.logging.Level;
import oracle.dms.instrument.Event;
import oracle.dms.instrument.Noun;
import oracle.dms.instrument.Sensor;

/**
 * This class is a wrapper of DMS Event sensor. It encapsulates sensor 
 * group name(Noun) and sensor name. It also introduces the incresed method
 * instead of occured().
 * 
 * <p>
 * @version 10.1.3, 02/15/05
 * @since 10.1.3
 */
 
 /**
 * This class is a wrapper of DMS Event sensor.
 * <p>
 */
public class Counter extends ADFPerfSensor
{
  // DMS Event
  private Event mEvent;
  

  /**
   * Internal Constructor, user should not use it directly.
   * 
  /**
   * Create a Counter object identified by the sensorGroupName and the sensorName.
   * <p>
   * Developers should then call occurred() to track system event.
   * <p>
   * Internally, this method creates a DMS Event sensor. 
   * <p>
   * A DMS Event sensor has following metrics: count
   * <p>
   * 
   * @param sensorFullName  the sensor full name, which is a container of
   *  related sensors that cover certain aspect of a feature.
   * @param event DMS event sensor
   * @param level one of the message level identifiers, e.g. SEVERE
   */
  private Counter(
    Level  level,
    String sensorFullName,
    Event  event
  )
  {
    super(level, sensorFullName);
    mEvent = event;
  }

  /**
   * Increase the counter to indicate an event occurred.
   * <p>
   */
  public void increase()
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    mEvent.occurred();
    Object value = mEvent.getValue(mEvent.count);
    if (mEnablePerfLog)
      log(System.currentTimeMillis(), value.toString(), null);
  }
  
  /**
   * Clean up the counter value
   * <p>
   */
  public void reset()
  {
    mEvent.reset();
  }
  

  /**
   * Create a Counter object identified by the sensorGroupName and the sensorName.
   * <p>
   * Developers should then call Counter's increase(), reset() methods
   * to track the counter object. 
   * <p>
   * Internally, this method creates a DMS Event sensor. 
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   *                         The component_id is also used as Counter type
   * @param name             the counter name.  
   * @param desc             the description for this Counter.
   * 
   * @return Counter           the new Counter
   */
  public static Counter createCounter(
    Level  level,
    String groupName,
    String name,
    String desc
  )
  {
    String nounType = PerfUtil.getNounType(groupName);
    return createCounter(level, groupName, name, nounType, desc);
  }
  
  
  /**
   * Create a Counter object identified by the sensorGroupName and the sensorName.
   * <p>
   * Developers should then call Counter's increase(), reset() methods
   * to track the counter object. 
   * <p>
   * Internally, this method creates a DMS Event sensor. 
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   * @param name             the counter name.  
   * @param type             the Counter type which collects all sensors
   *                         with same type and display them together in a table 
   *                         in AggreSpy
   * @param desc             the description for this Counter.
   * 
   * @return Counter         the new Counter
   */
  public static Counter createCounter(
    Level  level,
    String groupName,
    String name,
    String type,
    String desc
  )
  {
    groupName = PerfUtil.standardizeGroupName(groupName);
    name = PerfUtil.standardizeSensorName(name); 

    String fullName = groupName + 
                      ADFPerfConstants.NAME_SEPARATOR + 
                      name + ADFPerfConstants.LOG_SEPARATOR + 
                      ADFPerfConstants.COUNTER;

    ADFPerfSensor counter = PerfUtil.getSensor(fullName);
    if ((counter != null) && (counter instanceof Counter))
    {
      // already created
      return (Counter)counter;
    }
    else
    {    
      // first time hit this sensor
      Event et = null;
      
        if ((ADFPerfLog.getLevel().intValue() <= level.intValue()) || 
            (PerfUtil.getDMSSensorLevel().intValue() <= level.intValue())) 
      {
        // create DMS sensor if the level is lower
        Noun parentNoun = Noun.create(groupName);
        parentNoun.setType(type);
        et = Event.create(parentNoun, name, desc);  
        et.deriveMetric(Sensor.all);
      }
      Counter tr = new Counter(level, fullName, et);
      tr = (Counter)PerfUtil.putSensor(name, tr);
      return tr;
    }
  }
}
