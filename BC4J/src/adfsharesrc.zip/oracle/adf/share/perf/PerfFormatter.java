package oracle.adf.share.perf;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * Performance logging formatter 
 */
class PerfFormatter extends Formatter 
{
  private static final String LINE_SEPARATOR = System.getProperty("line.separator");

  static final long STARTTIME = System.currentTimeMillis();
  
  static final String LOG_LINE_FORMAT = 
    ADFPerfConstants.COMMENT_PREFIX + "Time stamp line format: " +
    ADFPerfConstants.DATETIME_PREFIX + "long format of date time (timestamp)" + 
    LINE_SEPARATOR + 
    ADFPerfConstants.COMMENT_PREFIX + "Sensor index line format: " + 
    ADFPerfConstants.INDEX_PREFIX + "<sensorIndex> <sensorFullName> <type>" + 
    LINE_SEPARATOR + 
    ADFPerfConstants.COMMENT_PREFIX + "Performance entry line format: " +
    "<ecid> [<sensorIndex> <threadId> <timeStamp> <value>]*" + 
    LINE_SEPARATOR + 
    ADFPerfConstants.COMMENT_PREFIX + "where <type> can be: " + 
    "t - timer, s - state, c - counter" + 
    LINE_SEPARATOR;
    
  /**
   * Format the given LogRecord.
   * @param record the log record to be formatted.
   * @return a formatted log record
   */
  public String formatMessage(LogRecord record) 
  {
    if (!(record instanceof PerfLogLine))
      return super.formatMessage(record);
    
    PerfLogLine line = (PerfLogLine)record;
    
    LinkedList recordList = line.getRecordList();    
    if (recordList != null)
    { 
      StringBuffer sb = new StringBuffer();

      sb.append(line.getMessage());// append ecid
      
      Iterator iter = recordList.iterator();
      while (iter.hasNext())
      {
        sb.append(ADFPerfConstants.LOG_SEPARATOR);
        sb.append(ADFPerfConstants.SENSOR_SEPARATOR_LEFT);// [
        PerfLogRecord plRecord = (PerfLogRecord)iter.next();
        sb.append(plRecord.getIndex());// sensor index
        sb.append(ADFPerfConstants.LOG_SEPARATOR);
        sb.append(plRecord.getThreadID());// Thread id
        sb.append(ADFPerfConstants.LOG_SEPARATOR);
        sb.append(plRecord.getMillis() - STARTTIME);// sensor time stamp
        sb.append(ADFPerfConstants.LOG_SEPARATOR);
        sb.append(plRecord.getMessage());// sensor value
        sb.append(ADFPerfConstants.SENSOR_SEPARATOR_RIGHT);// ]
      }
      sb.append(LINE_SEPARATOR);
      return sb.toString();
    }
    return null;
  }
  
  /**
   * Format the given log record and return the formatted string. 
   * The resulting formatted String will normally include a localized and 
   * formated version of the LogRecord's message field. 
   * 
   * @param record log record
   * @return formatted message string
   */
  public String format(LogRecord record)
  {
    return formatMessage(record);
  }
}