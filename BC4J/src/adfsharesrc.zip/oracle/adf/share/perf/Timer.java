/*
 * @(#)Timer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.perf;

import java.util.logging.Level;

import oracle.dms.instrument.Noun;
import oracle.dms.instrument.PhaseEvent;
import oracle.dms.instrument.Sensor;

/**
 * This class is a wrapper of DMS PhaseEvent sensor. It encapsulates sensor 
 * group name(Noun) and sensor name. It also contains a pair of functions to
 * start()/stop() the timer, and a cleanup() function to abort the timer in the
 * case of an exception so that we only count those PhaseEvents that are 
 * successfully stopped. 
 * <p>
 * @version 10.1.3, 02/15/05
 * @since 10.1.3
 */
 
public class Timer extends ADFPerfSensor
{
  // PhaseEvent 
  private PhaseEvent mPEvent = null;
  
  // for composite timer, the provider supply children timers
  private TimerProvider mProvider = null;
  
  // use ThreadLocal to store the current token value for each thread
  private ThreadLocal mToken = new ThreadLocal() 
  {
    protected synchronized Object initialValue() {
      return new TimerToken(false, 0, true);
    }    
  };
       

  /**
   * Internal implementation, user should not call this constructor.
   * 
   * @param level           the sensor level
   * @param sensorFullName  the sensor full name, including the noun path
   * @param pe              phase event object crated for the timer
   */
  private Timer(
    Level  level,
    String sensorFullName,
    PhaseEvent pe
  )
  {
    super(level, sensorFullName);
    mPEvent = pe;
  }

  /**
   * Create a Timer object identified by the groupName, the name, and the 
   * description.
   * <p>
   * Developers should then call Timer's start(), stop() and cleanup() functions 
   * to track the time. Please note start()/stop() funtions should always be 
   * put in a try or catch block, and the cleanup() function should always be 
   * called in a finally block to make sure the Timer object is aborted cleanly
   * in case stop() is not called.
   * <p>
   * Internally, this method creates a DMS PhaseEvent sensor. 
   * <p>
   * A DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   *                         The component_id is also used as timer type
   * @param name             the timer name
   * @param desc             the description for this timer.
   * 
   * @return Timer           the new Timer
   */
  public static Timer createTimer(
    Level  level,
    String groupName,
    String name,
    String desc
  )
  {
    String nounType = PerfUtil.getNounType(groupName);
    return createTimer(level, groupName, name, nounType, desc);
  }
  
  /**
   * Create a composite timer object identified by the groupName, the name, 
   * the description, and a timer provider.
   * <p>
   * Developers should then call Timer's start(), stop(returnValue) and 
   * cleanup() functions to track the time. Please note 
   * start()/stop(returnValue) funtions should always be 
   * put in a try or catch block, and the cleanup() function should always be 
   * called in a finally block to make sure the Timer object is aborted cleanly
   * in case stop(returnValue) is not called.
   * <p>
   * Internally, this method creates one or more DMS PhaseEvent sensors 
   * depending on the implementation of TimerProvider. 
   * <p>
   * A DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   *                         The component_id is also used as timer type
   * @param name             the timer name
   * @param desc             the description for this timer.
   * @param provider         the timer provider implements TimerProvider
   * 
   * @return Timer           the new composite Timer
   */
  public static Timer createTimer(
    Level  level,
    String groupName,
    String name,
    String desc,
    TimerProvider provider
  )
  {
    String nounType = PerfUtil.getNounType(groupName);
    return createTimer(level, groupName, name, nounType, desc, provider);
  }  
  
  /**
   * Create a Timer object identified by the groupName, the name, the type,
   * and the description.
   * <p>
   * Developers should then call Timer's start(), stop() and cleanup() functions 
   * to track the time. Please note start()/stop() funtions should always be 
   * put in a try or catch block, and the cleanup() function should always be 
   * called in a finally block to make sure the Timer object is aborted cleanly
   * in case stop() is not called.
   * <p>
   * Internally, this method creates a DMS PhaseEvent sensor. 
   * <p>
   * A DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   * @param name             the timer name 
   * @param type             the timer type which collects all sensors
   *                         with same type and display them together in a table 
   *                         in AggreSpy
   * @param desc             the description for this timer.
   * 
   * @return Timer           the new Timer
   */
  public static Timer createTimer(
    Level  level,
    String groupName,
    String name,
    String type,
    String desc
  )
  {
    groupName = PerfUtil.standardizeGroupName(groupName);
    name = PerfUtil.standardizeSensorName(name);

    String fullName = groupName + 
                      ADFPerfConstants.NAME_SEPARATOR + 
                      name + 
                      ADFPerfConstants.LOG_SEPARATOR + 
                      ADFPerfConstants.TIMER;
                      
    ADFPerfSensor timer = PerfUtil.getSensor(fullName);
    
    if ((timer != null) && (timer instanceof Timer))
    {
      // already created
      return (Timer)timer;
    }
    else
    {
      // first time hit this sensor
      PhaseEvent pet = null;

      if ((ADFPerfLog.getLevel().intValue() <= level.intValue()) || 
          (PerfUtil.getDMSSensorLevel().intValue() <= level.intValue()))
      {      
        // create DMS sensor if the level is lower
        Noun parentNoun = Noun.create(groupName);
        if (type != null) // null type means a hidden timer
          parentNoun.setType(type);
        pet = PhaseEvent.create(parentNoun, name, desc);
        pet.deriveMetric(Sensor.all);
      }
      Timer tr = new Timer(level, fullName, pet);
      tr = (Timer)PerfUtil.putSensor(fullName, tr);
      return tr;
    }
  }

  /**
   * Create a summerized Timer object identified by the groupName, the name, 
   * the type, the description, and a bunch of sub timers provided by the provider.
   * <p>
   * Developers should then call Timer's start(), stop(returnValue) and 
   * cleanup() functions to track the time. Please note 
   * start()/stop(returnValue) funtions should always be 
   * put in a try or catch block, and the cleanup() function should always be 
   * called in a finally block to make sure the Timer object is aborted cleanly
   * in case stop(returnValue) is not called.
   * <p>
   * Internally, this method creates one or more DMS PhaseEvent sensors 
   * depending on the implementation of TimerProvider. 
   * <p>
   * A DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param level            one of the message level identifiers, e.g. SEVERE
   * @param groupName        the group name, which has the format of
   *                         /oracle/component_id/module/subModule/...
   * @param name             the timer name 
   * @param type             the timer type which collects all sensors
   *                         with same type and display them together in a table 
   *                         in AggreSpy
   * @param desc             the description for this timer.
   * @param provider         the timer provider implements TimerProvider
   * 
   * @return Timer           the new Timer
   */
  public static Timer createTimer(
    Level  level,
    String groupName,
    String name,
    String type,
    String desc,
    TimerProvider provider
  )
  {
    if (provider != null)
    {
      provider.createTimers(level, groupName, name, type, desc);
      if (!provider.isParentLoggable())
        type = null; // use null type to hide the timer
    }
    
    Timer timer = createTimer(level, groupName, name, type, desc);
      
    timer.mProvider = provider;
    return timer;
  }

  /**
   * Start the timer.
   * <p>
   * After a timer is started, developers should call stop() function to stop 
   * the timer. start()/stop() funtions should be put in a try block, and the 
   * cleanup() function should be called in a finally block.
   * <p>
   * Internally, this method starts the DMS PhaseEvent sensor. 
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   */
  public void start()
  {  
    if (!mEnablePerfLog && !mEnableDms)
      return;
      
    TimerToken token = (TimerToken)mToken.get();
    if (!token.mStarted)
    { 
      token.mDMSToken = mPEvent.start();
      token.mStarted = true;
    }
  }
  
  /**
   * Start the timer using Token. Normally this method is only used when the
   * timer starts and stops in different thread. Otherwise, the simpler version
   * of start()/stop() should be used.
   * <p>
   * After a timer is started, developer should call stopWithToken(token) and
   * cleanupWithToekn(token) function to stop and cleanup the timer. 
   * <p>
   * Internally, this method starts the DMS PhaseEvent sensor. 
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * 
   * @return token of the timer
   */
  public TimerToken startWithToken()
  {  
    if (!mEnablePerfLog && !mEnableDms)
      return null;
    
    return new TimerToken(true, mPEvent.start(), false);  
  }  
  
  /**
   * Stop the timer.
   * <p>
   * Developer should call start() function to start the timer. 
   * start()/stop() functions should be put in a try block, and the 
   * cleanup() function should be called in a finally block.
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor.
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   */
  public void stop()
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;
     
    TimerToken token = (TimerToken)mToken.get();
    if (token.mStarted) 
    {  
      long elapsedTime = mPEvent.stop2(token.mDMSToken) - token.mDMSToken;
      if (mEnablePerfLog)
        log(token.mDMSToken, Long.toString(elapsedTime), token.mEcid);
      token.mStarted = false;
    }
  }
  
  /**
   * Stop the timer using token.
   * <p>
   * Developer should call startWithToken() function to start the timer, 
   * and then call this method to stop the timer
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor.
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param token the TimerToken returned from startWithToken()
   */
  public void stopWithToken(TimerToken token)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;
      
    if (token.mStarted)
    {
      long elapsedTime = mPEvent.stop2(token.mDMSToken) - token.mDMSToken;
      if (mEnablePerfLog)
        log(token.mDMSToken, Long.toString(elapsedTime), token.mEcid);
      token.mStarted = false;
    }
  }  
  
  /**
   * Stop the timer with specified returnValue
   * <p>
   * Developer should call start() function to start the timer with 
   * TimerProvider, and stop(returnValue) to stop the timer. The returnValue
   * decides which children timers to be updated.
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor for the parent 
   * sensor, and then update each children's PhaseEvent based on the result 
   * from TimerProvider.getTimers().
   * <p>
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param returnValue the return code from a piece of code being monitored.
   */
  public void stop(int returnValue)
  {
    stopComposite(null, returnValue, null);
  }
  
  /**
   * Stop the timer using token with specified returnValue
   * <p>
   * Developer should call startWithToken() function to start the timer with 
   * TimerProvider, and stopWithToken(token, returnValue) to stop the timer. 
   * The returnValue decides which children timers to be updated.
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor for the parent 
   * sensor, and then update each children's PhaseEvent based on the result 
   * from TimerProvider.getTimers().
   * <p>
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param token the TimerToken returned from startWithToken()
   * @param returnValue the return code from a piece of code being monitored.
   */
  public void stopWithToken(TimerToken token, int returnValue)
  {
    stopComposite(token, returnValue, null);
  }  
  
  /**
   * Stop the timer with specified returnValue
   * <p>
   * Developer should call start() function to start the timer with 
   * TimerProvider, and stop(returnValue) to stop the timer. The returnValue
   * decides which children timers to be updated.
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor for the parent 
   * sensor, and then update each children's PhaseEvent based on the result 
   * from TimerProvider.getTimers().
   * <p>
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param returnValue the return code from a piece of code being monitored.
   */
  public void stop(Object returnValue)
  {
    stopComposite(null, 0, returnValue);
  }

  /**
   * Stop the timer using token with specified returnValue
   * <p>
   * Developer should call startWithToken() function to start the timer with 
   * TimerProvider, and stopWithToken(token, returnValue) to stop the timer. 
   * The returnValue decides which children timers to be updated.
   * <p>
   * Internally, this method stops the DMS PhaseEvent sensor for the parent 
   * sensor, and then update each children's PhaseEvent based on the result 
   * from TimerProvider.getTimers().
   * <p>
   * The DMS PhaseEvent sensor has following metrics:
   * active, avg, completed, maxActive, maxTime, minTime and time.
   * <p>
   * @param token the TimerToken returned from startWithToken()
   * @param returnValue the return code from a piece of code being monitored.
   */
  public void stopWithToken(TimerToken token, Object returnValue)
  {
    stopComposite(token, 0, returnValue);
  }
  
  /**
   * Combine both stop(int) and stop(Object) for better maintenance of the code
   * 
   * @param token, the timer token if it is started using startWithToken()
   * @param returnInt int type of return code
   * @param returnObj generic Object type of return code
   */
  private void stopComposite(TimerToken token, int returnInt, Object returnObj)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;
     
    if (token == null)
      token = (TimerToken)mToken.get();
    if (token.mStarted) 
    {  
      // stop the parent timer (phaseEvent) first
      long endTime = mPEvent.stop2(token.mDMSToken);
      long elapsedTime = endTime - token.mDMSToken;
      
      if (mProvider != null)
      {
        // this is a composite timer with several children timers 
        Timer[] timers;
        if (returnObj != null)
          timers = mProvider.getTimers(returnObj);
        else
          timers = mProvider.getTimers(returnInt);
        if (timers != null)
        {
          for (int i = 0; i < timers.length; i++)
          {
            PhaseEvent pe = timers[i].mPEvent;
            if (pe != null)
            {
              // start at the timestamp same as parent
              pe.start(token.mDMSToken); 
              // stop at the timestamp same as parent
              pe.stop(token.mDMSToken, endTime); 
              // log child timer
              if (mEnablePerfLog)
                timers[i].log(token.mDMSToken, 
                              Long.toString(elapsedTime),
                              token.mEcid); 
            }
          }
        }
      }

      if (mEnablePerfLog)
        if (((mProvider != null) && (mProvider.isParentLoggable())) ||
            (mProvider == null)) 
          log(token.mDMSToken, Long.toString(elapsedTime), token.mEcid);
      
      token.mStarted = false;
    }    
  }

  /**
   * Cleanup the timer.
   * <p>
   * This function should be called within a finally block. It either stops
   * the timer if everything goes fine, or aborts the timer if an exception
   * occurred.
   * <p>
   */
  public void cleanup()
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    TimerToken token = (TimerToken)mToken.get();
    if (token.mStarted)
    {
      mPEvent.abort(token.mDMSToken);    
      token.mStarted = false;
    }
  }
  
  
  /**
   * Cleanup the timer using token.
   * <p>
   * This function should be called within a finally block. It either stops
   * the timer if everything goes fine, or aborts the timer if an exception
   * occurred.
   * <p>
   * @param token the TimerToken returned from startWithToken()
   */
  public void cleanupWithToken(TimerToken token)
  {
    if (!mEnablePerfLog && !mEnableDms)
      return;

    if (token.mStarted)
    {
      mPEvent.abort(token.mDMSToken);    
      token.mStarted = false;
    }
  }
}
