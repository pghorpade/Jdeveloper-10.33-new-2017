/*
 * @(#)PerfUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.perf;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Enumeration;

import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;

import oracle.dms.instrument.DMSConsole;

/**
 * Internal Perfomance Log Utility
 */
public class PerfUtil 
{
  // a list of sensors used in the application.
  private static Hashtable sSensor   = new Hashtable();
  
  /**
   * Put the ADFPerfSensor into hashtable
   * 
   * @param name Sensor name
   * @param sensor the ADFPerfSensor object
   * @return the sensor that was put into the hashtable
   */
  static ADFPerfSensor putSensor(String name, ADFPerfSensor sensor)
  {
    synchronized (sSensor)
    {
      // make sure the sensor has not been put there yet.
      ADFPerfSensor s = (ADFPerfSensor)sSensor.get(name);
      if (s == null)
      {
        sSensor.put(name, sensor);
        s = sensor;
      }
      return s;
    }
  }

  /**
   * Get the cached sensor
   * 
   * @param name sensor name
   * 
   * @return sensor obejct, null if no cached sensor found.
   */
  static ADFPerfSensor getSensor(String name)
  {
    return (ADFPerfSensor)sSensor.get(name);
  }

  /**
   * Get noun type from group name which is in the format of
   * /oracle/component_id/noun1/noun2/.../nounN
   * 
   * @param groupName
   * @return noun type which comes from the second field of the groupName
   */
  static String getNounType(String groupName)
  {
    String type = null;
    StringTokenizer st = new StringTokenizer(groupName, "/");
    if (st.hasMoreTokens())
    {
      st.nextToken(); // skip first token which is 'oracle' or the company name
      if (st.hasMoreTokens())
        type = st.nextToken();          
    }
    return type.toUpperCase();
  }
  
  
  /**
   * Get DMS sensor weight, and map it to java logging level
   * 
   * @return converted java logging level for current global DMS sensor weight
   */
  static Level getDMSSensorLevel()
  {
    try
    {
      int weight = DMSConsole.getSensorWeight();
      switch (weight)
      {
        case DMSConsole.NONE:
          return Level.OFF;
        case DMSConsole.NORMAL:
          return Level.INFO;
        case DMSConsole.HEAVY:
          return Level.FINE;
        case DMSConsole.ALL:
          return Level.FINEST;
      }
      return Level.OFF;
    }
    catch (NoClassDefFoundError e)
    {
      // DMS jar is not accessible, turn off any DMS sensor
      return Level.OFF;
    }
  }

  /**
   * Get url for the http servlet request
   * <p>If the request is get, append query string
   * <p>If the request is post, append post parameter except state
   * <p>distinguish the request type by prepend "get" or "post"
   */
  public static String getUrl(HttpServletRequest request)
  {
    StringBuffer reqUrl = new StringBuffer(request.getRequestURI());
    String method = request.getMethod();
    if (method.equalsIgnoreCase("GET"))
    {
      String queryString = request.getQueryString();
      if (queryString != null)
      {
        reqUrl.append("?");
        reqUrl.append(queryString);
      }
    }
    else if (method.equalsIgnoreCase("POST"))
    {
      Enumeration pNames = request.getParameterNames();
      reqUrl.append("?");

      while (pNames.hasMoreElements()) 
      {
        String name = (String)pNames.nextElement();
        if (!name.equalsIgnoreCase("oracle.adf.faces.STATE_TOKEN"))
        {
          // except the faces state value, we capture other parameters in
          // the post form as part of url
          reqUrl.append(name);
          reqUrl.append("=");
          String[] values = request.getParameterValues(name);
          for (int i = 0;  i < values.length; i++)
          {
            if (i > 0)
               reqUrl.append("|");
            reqUrl.append(values[i]);
          }
          reqUrl.append("&");
        }
      }
      reqUrl.deleteCharAt(reqUrl.length()-1); // remove the unused '?' or '&'
    }
    /* else method.equalsIgnoreCase("PUT") */
    reqUrl.insert(0, method + ":");
    return reqUrl.toString();
  }
  
  /**
   * Standardize groupName
   * <p>Check and prepend beginning slash; replace spaces with '_'
   * 
   * @param groupName original group name
   * @return standardized group name
   */
  static String standardizeGroupName(String groupName)
  {
    // make sure groupName starts with '/'
    if (groupName != null)
    { 
      if ((groupName.length() >= 1) && 
          (groupName.charAt(0) != ADFPerfConstants.NAME_SEPARATOR))
        groupName = ADFPerfConstants.NAME_SEPARATOR + groupName;
      groupName =  groupName.replace(' ', '_'); 
      int len = groupName.length();
      if ((len > 0) && 
          (groupName.charAt(len-1) == ADFPerfConstants.NAME_SEPARATOR))
        groupName = groupName.substring(0, len-1);
    }
    return groupName;
  }
  
  /**
   * Standardize sensor name
   * <p>lowercase for the fist character; replace all spaces with '_'
   * @param name original sensor name
   * @return standardized sensor name
   */
  static String standardizeSensorName(String name)
  {
    // sensor name has naming convention of lowercase for the first character
    if ((name != null) && (name.length() >= 1))
    {
      name = name.substring(0, 1).toLowerCase() + name.substring(1);
      name = name.replace(' ', '_');
    }
    return name;
  }
}
