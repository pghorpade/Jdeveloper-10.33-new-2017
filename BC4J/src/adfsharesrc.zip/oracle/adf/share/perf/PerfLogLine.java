package oracle.adf.share.perf;

import java.util.LinkedList;
import java.util.logging.LogRecord;

/**
 * Performance logging line, which is a LogRecord for log formatter:
 * PerfFormatter
 */
class PerfLogLine extends LogRecord
{
  // a linked list for all performance log records (PerfLogRecord) that have 
  // same ecid
  private LinkedList mRecordList = null;
  
  /**
   * Constructor
   * 
   * @param ecid the ecid for all log records (PerfLogRecord) in the recordList
   * @param recordList a list of log records (PerfLogRecord) with same specified 
   * ecid
   */
  PerfLogLine(String ecid, LinkedList recordList)
  {
    super(ADFPerfLog.getLevel(), ecid);
    mRecordList = recordList;
  }
  
  /**
   * Get log records list
   * 
   * @return a list of log records of type PerfLogRecord
   */
  LinkedList getRecordList()
  {
    return mRecordList;
  }
}
