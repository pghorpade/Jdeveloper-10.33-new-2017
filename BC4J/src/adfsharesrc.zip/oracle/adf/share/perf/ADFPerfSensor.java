package oracle.adf.share.perf;

import java.util.logging.Level;

/**
 * Base class for all ADF Performance sensors: Timer, Counter, stateTracker
 */
protected class ADFPerfSensor
{
  // sensor index count
  private static int sIndex = 0;

  // sensor full name, including nouns and sensor name
  protected String mSensorFullName;
    
  // Logging Level
  protected Level mLevel = null;
    
  // Sensor index number
  protected int mIndex = 0;
  
  // depending on perf logger level and oracle.dms.sensors jvm property
  // following two flags show if the perf logging or dms should be enabled for
  // this sensor
  protected boolean mEnablePerfLog = false;
  protected boolean mEnableDms = false;
  
  // flag to indicate whether the timer logged
  private boolean mIsTimerLogged = false;

  private static final String LINE_SEPARATOR = System.getProperty("line.separator");
  
  protected ADFPerfSensor(Level level, String sensorFullName)
  {
    mLevel = level;
    mSensorFullName = sensorFullName;
    mIndex = getIndex();
    mEnablePerfLog = ADFPerfLog.getLevel().intValue() <= level.intValue();
    mEnableDms = PerfUtil.getDMSSensorLevel().intValue() <= level.intValue();
  }
  
  /**
   * Send sensor's metrics to performance logs.
   * @param timeStamp time stamp for the sensor. It is start time for timer
   * @param value sensor value. 
   * <p>Timer - elapsed time</p>
   * <p>Counter - count</p>
   * <p>StateTracker - state</p>
   * @param ecid the ecid of the sensor
   */
  protected void log(long timeStamp, String value, String ecid)
  {
    logIndex();
    PerfLogRecord record = new PerfLogRecord(mLevel, value);
    record.setMillis(timeStamp);
    record.setIndex(mIndex);
    ADFPerfLog.addLogRecord(record, ecid);
  } 
  
  /**
   * Check if the sensor is active
   * @return true - yes, false - no
   */
  public boolean isActive()
  {
    return (mEnablePerfLog || mEnableDms);
  }

  /**
   * Log sensor index line if the sensor index and name has not been logged
   * <P>
   * The sensor index line has the format of 
   * <p>
   * I <index> <timerFullName>\n
   */
  private synchronized void logIndex()
  {
    if (!mIsTimerLogged)
    {
      // construct index line:
      StringBuffer sb = new StringBuffer();
      sb.append(ADFPerfConstants.INDEX_PREFIX);
      sb.append(mIndex);
      sb.append(ADFPerfConstants.LOG_SEPARATOR);
      sb.append(mSensorFullName);
      sb.append(LINE_SEPARATOR);
      ADFPerfLog.getIdxLogger().log(mLevel, sb.toString());
      mIsTimerLogged = true;
    }
  }
  
  /**
   * Get unique index for each distinct sensor 
   * 
   * @return index number
   */
  private synchronized static int getIndex()
  {
    return ++sIndex;
  }
}
