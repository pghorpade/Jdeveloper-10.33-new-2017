package oracle.adf.share.perf;

import java.util.logging.Level;

/**
 * This interface gives the implementer control over which timers to be updated
 * for a return value from a piece of code being monitored.
 * <p> 
 * For example, if you want to measure how much time spent on making
 * http request, and you want to separate the measurement based on the http
 * return code, you can do following:
 * <code>
 * Timer t= Timer.createTimer(Level.INFO, 
 *                            "oracle.adf.mycomp", 
 *                            "mySensor", 
 *                            "my sensor to be measured",
 *                            new MyTimerProvider());
 * try
 * {
 *   t.start();
 *   int returnCode = makeHttpRequest(URL);
 *   t.stop(returnCode);
 * }
 * finally
 * {
 *   t.cleanup();
 * }
 * </code>
 * <p>
 * Class MyTimerProvider implements TimerProvider interface, and the key methods
 * to be implemented are createTimers and getTimers. In the above example, you 
 * could have following code:
 * <code>
 * void createTimers(Level level, String groupName, String name, String type,
 *                   String desc)
 * {
 *   // timer for http response code >= 200 but < 300
 *   Timer m2xx = Timer.createTimer(level, groupName, name + "_2xx", type, 
 *                                desc + " for 200 series http response code");
 *   // timer for http response code >= 300 but < 400
 *   Timer m3xx = Timer.createTimer(level, groupName, name + "_3xx", type,
 *                                desc + " for 300 series http response code");
 *   // timer for http response code >= 400 but < 500
 *   Timer m4xx = Timer.createTimer(level, groupName, name + "_4xx", type,
 *                                desc + " for 400 series http response code");
 *   // timer for http response code >= 500 but < 600
 *   Timer m5xx = Timer.createTimer(level, groupName, name + "_5xx", type,
 *                                desc + " for 500 series http response code");
 *   // timer for http response code >= 500 but < 600
 *   Timer mOther = Timer.createTimer(level, groupName, name + "_other", type,
 *                                desc + " for other error http response code");
 *   // timer for http successful response
 *   Timer mSucc = Timer.createTimer(level, groupName, name + "_succ", type,
 *                                desc + " for successful http response");
 *   // timer for http failed response
 *   Timer mFail = Timer.createTimer(level, groupName, name + "_fail", type,
 *                                desc + " for failed http response");
 * }
 *                                
 * Timer[] getTimers(int returnValue)
 * {
 *   Timer[] timers = new Timer[2];
 *   
 *   if ((returnValue >= 200) && (returnValue < 300))
 *   {
 *     timers[0] = m2xx;
 *     timers[1] = mSucc;
 *   }
 *   else if ((returnValue >= 300) && (returnValue < 400))
 *   {
 *     timers[0] = m3xx;
 *     timers[1] = mSucc;
 *   }
 *   else if ((returnValue >= 400) && (returnValue < 500))
 *   {
 *     timers[0] = m4xx;
 *     timers[1] = mFail;
 *   }
 *   else if ((returnValue >= 500) && (returnValue < 600))
 *   {
 *     timers[0] = m5xx;
 *     timers[1] = mFail;
 *   }
 *   else 
 *   {
 *     timers[0] = mOther;
 *     timers[1] = mFail;
 *   }
 *   return timers;
 * }
 * </code>
 */

public interface TimerProvider
{
  /**
   * Create children timers based on the parent timer level, groupName, name,
   * type, and desc
   * <p>
   * By convention, the children timer level should be same as or lower than
   * parent timer; the children timer groupName should be same as parent timer;
   * the children timer name should be derived from parent timer; the children
   * timer type should be same as parent timer; and the children timer 
   * description should be based on the parent timer, and then add its own 
   * information.
   * <p>
   * The children timers can be instanciated up front in this method, or 
   * instanciated later on demand (when the timer is used).
   * 
   * @param level parent timer level
   * @param groupName parent timer groupName
   * @param name parent timer name
   * @param type parent timer type
   * @param desc parent timer desc
   */
  public void createTimers(Level level, String groupName, String name, 
                           String type, String desc);
  
  /**
   * Get a list of children timers based on the returnValue int value. These 
   * timers metrics will be updated by parent timer.
   * 
   * @param returnValue
   * @return a list of children timers to be updated based on the returnValue
   */
  public Timer[] getTimers(int returnValue);
  
  /**
   * Get a list of children timers based on an Object type returnValue value. 
   * These timers metrics will be updated by parent timer.
   * 
   * @param returnValue
   * @return a list of children timers to be updated based on the returnValue
   */
  public Timer[] getTimers(Object returnValue);
  
  /**
   * To indicate if the parent timer to be loggable or not (which means it is 
   * just a place holder). 
   * 
   * @return true - the parent timer will be created using the group name, name, 
   *         type, desc, level, and send to performance logging
   *         <p>
   *         false - the parent timer will be created as hidden timer, and its
   *         metrics won't be sent to performance logging. Internally we create 
   *         a hidden phase event without type. The only purpose is to get 
   *         timestamp from the dms phase event
   */
  public boolean isParentLoggable();
}
