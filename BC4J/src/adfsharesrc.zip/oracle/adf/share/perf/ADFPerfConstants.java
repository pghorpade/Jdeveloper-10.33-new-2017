package oracle.adf.share.perf;

/**
 * This class define a set of constants used by various classes
 */
public class ADFPerfConstants 
{
  public static final String TIMER = "t";
  public static final String COUNTER = "c";
  public static final String STATE = "s";
  
  public static final char DASH = '-'; 
  public static final String COMMENT_PREFIX = "# ";
  public static final String INDEX_PREFIX = "I ";
  public static final String DATETIME_PREFIX = "T ";
  public static final String LOG_SEPARATOR = " "; 
  public static final String SENSOR_SEPARATOR_LEFT = "[";
  public static final String SENSOR_SEPARATOR_RIGHT = "]";

  static final char NAME_SEPARATOR = '/';
  
  public static final String PATH = "path";
  public static final String LEVEL = "level";
  public static final String MAXFILESIZE = "maxFileSize";
  public static final String MAXLOGSIZE = "maxLogSize";
  public static final String BUFFERSIZE = "bufferSize";
  
  // jvm properties set by PerfHandlerFactory and consumed by ADFPerfLog
  static final String JVM_PROP_PERF_HANDLER = "oracle.adf.share.perf.handler";
  static final String JVM_PROP_BUFSIZE = "oracle.adf.share.perf.bufSize";
  static final String JVM_PROP_PERF_PATH = "oracle.adf.share.perf.path";

  public static final String PERFLOG_FILE_PREFIX = "adfperf";
  public static final String PERFLOG_FILE_SUFFIX = ".log";
  public static final String FILE_SEPARATOR = System.getProperty("file.separator");
}
