package oracle.adf.share.statemanager;

import java.util.Map;
import java.util.Hashtable;

import javax.naming.InitialContext;
import java.util.Collection;
import java.util.Set;

import oracle.adf.share.ADFScope;
import oracle.adf.share.ADFContext;
import oracle.adf.share.ADFScopeListener;

/* $Header: StateManagerScopeAdapter.java 12-dec-2005.16:59:55 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    12/12/05 - XbranchMerge jsmiljan_fix_kava_121205 from main 
    jsmiljan    08/16/05 - 
    jsmiljan    03/17/05 - 
    jsmiljan    02/08/05 - 
    jsmiljan    02/01/05 - jsmiljan_statemanager_012505
    jsmiljan    01/26/05 - Creation
 */
/**
 * The state manager specification defines a StateManagerScopeAdapter
 * to make adapt the StateManager to a simple Map interface.
 * <p>
 * The StateManagerScopeAdapter is instantiated with an ADF scope and an optional
 * JNDI environment Hashtable.  The JNDI environment Hashtable may be used to
 * initialize and configure the StateManager.  See the {@link oracle.adf.share.statemanager.DefaultInitialContextFactory}.
 * <p>
 * The StateManagerScopeAdapter works by defining a UUID for the specified scope.
 * The adapter will store this id in the specified scope for later use by other adapters.
 *
 *  @version $Header: StateManagerScopeAdapter.java 12-dec-2005.16:59:55 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class StateManagerScopeAdapter implements Map
{
   public static final String STATE_MANAGER_SCOPE_ID_KEY = "adf.statemanager.uuid_key";
   public  static final String ENV_STATE_MANAGER_POLICY_KEY = "adf.statemanager.policy_key"; 

   private final StateManager mStateManager;
   private final String mScopeName;
   private final Object mScopeUUID;
   private final Policy mPolicy;

   public StateManagerScopeAdapter(String scopeName, Hashtable env)
   {
      mScopeName = scopeName;
      
      if (env == null)
      {
         env = new Hashtable(4);
      }

      if (env.get(InitialContext.INITIAL_CONTEXT_FACTORY) == null)
      {
         env.put(InitialContext.INITIAL_CONTEXT_FACTORY
            , DefaultInitialContextFactory.class.getName());
      }

      try
      {
         mStateManager = (StateManager)(new InitialContext(env).lookup(
            DefaultContext.STATE_MANAGER_JNDI_NAME));
      }
      catch (javax.naming.NamingException n)
      {
         throw new RuntimeException(n);
      }

      Map scope = ADFContext.getCurrent().getScope(mScopeName);

      Object scopeUUID = scope.get(STATE_MANAGER_SCOPE_ID_KEY);
      if (scopeUUID == null)
      {
         scopeUUID = generateStateManagerId(scope);
         scope.put(STATE_MANAGER_SCOPE_ID_KEY, scopeUUID);

         if (scope instanceof ADFScope)
         {
            ((ADFScope)scope).addScopeListener(new ADFScopeListenerImpl());
         }
      }
      mScopeUUID = scopeUUID;
      mPolicy = (Policy)env.get(ENV_STATE_MANAGER_POLICY_KEY);
   }

   protected Object generateStateManagerId(Map scope)
   {
      return UUID.generateUUID();
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public int size()
   {
      methodNotSupported();
      
      return 0;
   }

   public void clear()
   {
      mStateManager.clearStates(mScopeUUID);
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public boolean isEmpty()
   {
      methodNotSupported();
      
      return false;
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public boolean containsKey(Object p0)
   {
      methodNotSupported();
      
      return false;
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public boolean containsValue(Object p0)
   {
      methodNotSupported();
      
      return false;
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public Collection values()
   {
      methodNotSupported();
      
      return null;
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public void putAll(Map p0)
   {
      methodNotSupported();
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public Set entrySet()
   {
      methodNotSupported();
      
      return null;
   }

   /**
    * Method is not supported by the StateManager.
    * <p>
    * Invoking this method on the StateManagerScopeAdapter will result in
    * a RuntimeException.
    */
   public Set keySet()
   {
      methodNotSupported();
      
      return null;
   }

   public Object get(Object key)
   {
      return mStateManager.getState(mScopeUUID, key);
   }

   public Object remove(Object key)
   {
      return mStateManager.removeState(mScopeUUID, key);
   }

   public Object put(Object key, Object state)
   {
      if (mPolicy != null)
      {
         return mStateManager.putState(mScopeUUID, key, state, mPolicy);
      }
      else
      {
         return mStateManager.putState(mScopeUUID, key, state);
      }
   }

   protected String getScopeName()
   {
      return mScopeName;
   }
   
   private void methodNotSupported()
   {
      throw new UnsupportedOperationException();
   }

   class ADFScopeListenerImpl implements ADFScopeListener
   {
      public void scopeInvalidated(String scopeName)
      {
         Map stateManager = ADFContext.getCurrent().getStateManager(scopeName, null);
         stateManager.clear();
      }
   }
}
