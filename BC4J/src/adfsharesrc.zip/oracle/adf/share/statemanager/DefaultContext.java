package oracle.adf.share.statemanager;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.Context;
import javax.naming.NameParser;
import java.util.Hashtable;
import oracle.adf.share.statemanager.StateManager;

import oracle.adf.share.ADFContext;

import java.util.WeakHashMap;

/**
 * A default initial JNDI context for the StateManager.
 * <p>
 * This context maintains a singleton instance of the StateManager for the current
 * J2EE application.  The singleton instance may be created/resolved by performing
 * a <tt>lookup({@link #STATE_MANAGER_JNDI_NAME}</tt> from this context.  Please
 * note that all lookups from this context will resolve to the singleton
 * StateManager -- the lookup name is ignored by the context.  Once
 * the StateManager instance has been created it may not be destroyed for the
 * current application.
 * <p>
 * The application developer may specify the <tt>ENV_STATE_MANAGER_CLASS_NAME</tt>
 * environment parameter to specify the StateManager implementation that should
 * be created by the default StateManager context.  For example,
 * <p>
 * <tt>
 * Hashtable env = new Hashtable(4);
 * env.put(InitialContext.INITIAL_CONTEXT_FACTORY, "oracle.adf.share.statemanager.DefaultInitialContextFactory");
 * env.put(DefaultContext.ENV_STATE_MANAGER_CLASS_NAME, "oracle.adf.share.statemanager.javacache.StateManagerImpl");
 * InitialContext ctx = new InitialContext(env);
 * StateManager sm = ctx.lookup(null);
 * </tt>
 * <p>
 * will result in a singleton instance of the javacache implementation of the
 * StateManager.  If an ENV_STATE_MANAGER_CLASS_NAME is not specified then
 * the default StateManager context will create an instance of the javacache
 * implementation of the StateManager.
 * <p>
 * The default context will invoke {@link oracle.adf.share.statemanager.StateManager#init(Hashtable)}
 * with the context environment after instantiating the specified StateManager
 * instance.  Please see the specific StateManager implementation documentation
 * for information about the environment parameters that are supported by that
 * implementation.
 */
public class DefaultContext implements Context 
{
   public static final String ENV_STATE_MANAGER_CLASS_NAME = "oracle.adf.share.statemanager.class_name";
   public static final String STATE_MANAGER_JNDI_NAME = "__state_manager__";

   private final Hashtable mEnvironment;
   
   private static WeakHashMap mStateManagerMap = new WeakHashMap(4);
   
   public DefaultContext(Hashtable environment)
   {
      mEnvironment = environment;
   }

   public Object lookup(Name name) throws NamingException
   {
      return getStateManager();
   }

   public Object lookup(String name) throws NamingException
   {
      return getStateManager();
   }
   
   private StateManager getStateManager()
   {
      StateManager mgr = null;
      synchronized(mStateManagerMap)
      {
         ClassLoader cl = Thread.currentThread().getContextClassLoader();
         StateManagerHolder holder = (StateManagerHolder)mStateManagerMap.get(cl);

         if (holder == null)
         {
            holder = new StateManagerHolder();

            mStateManagerMap.put(cl, holder);
         }

         mgr = holder.getStateManager();
         if (mgr == null)
         {
            String className = (String)mEnvironment.get(ENV_STATE_MANAGER_CLASS_NAME);

            if (className == null)
            {
               try
               {
                  className = System.getProperty(ENV_STATE_MANAGER_CLASS_NAME);
               }
               catch (Exception e)
               {
                  // could not read the system property.  oh well.
               }
            }

            if (className == null)
            {
               ADFContext adfCtx = ADFContext.getCurrent();
               if (adfCtx.getContextType() == ADFContext.TYPE_HTTP
                  && adfCtx.hasSession())
               {
                  className = (oracle.adf.share.http.HttpSessionStateManagerImpl.class).getName();
               }
               else
               {
                  className = (oracle.adf.share.statemanager.j2ee.StateManagerImpl.class).getName();
               }
            }
            
            try
            {
               Class managerClass = Class.forName(className, true, cl);
               mgr = (StateManager)managerClass.newInstance();
            }
            catch (Exception e)
            {
               throw new RuntimeException(e);
            }

            holder.setStateManager(mgr);
            mgr.init(mEnvironment);
         }
      }
      
      return mgr;
   }

   public void bind(Name name, Object obj) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void bind(String name, Object obj) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void rebind(Name name, Object obj) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void rebind(String name, Object obj) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void unbind(Name name) throws NamingException
   {
      unbind(name.toString());
   }

   public void unbind(String name) throws NamingException
   {
      ClassLoader cl = Thread.currentThread().getContextClassLoader();
      synchronized(mStateManagerMap)
      {
         mStateManagerMap.remove(cl);
      }
   }

   public void rename(Name oldName, Name newName) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void rename(String oldName, String newName) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NamingEnumeration list(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NamingEnumeration list(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NamingEnumeration listBindings(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void destroySubcontext(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public void destroySubcontext(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Context createSubcontext(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Context createSubcontext(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Object lookupLink(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Object lookupLink(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NameParser getNameParser(Name name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public NameParser getNameParser(String name) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Name composeName(Name name, Name prefix) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public String composeName(String name, String prefix) throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   public Object addToEnvironment(String propName, Object propVal) throws NamingException
   {
      return mEnvironment.put(propName, propVal);
   }

   public Object removeFromEnvironment(String propName) throws NamingException
   {
      return mEnvironment.remove(propName);
   }

   public Hashtable getEnvironment() throws NamingException
   {
      return mEnvironment;
   }

   public void close() throws NamingException
   {
   }

   public String getNameInNamespace() throws NamingException
   {
      throw new UnsupportedOperationException();
   }

   private class StateManagerHolder
   {
      private StateManager mPortletStateManager = null;
      private StateManager mDefaultStateManager = null;

      private StateManager getStateManager()
      {
         ADFContext adfCtx = ADFContext.getCurrent();
         if (adfCtx.getContextType() == ADFContext.TYPE_PORTLET)
         {
            return mPortletStateManager;
         }
         else
         {
            return mDefaultStateManager;
         }

      }

      private void setStateManager(StateManager mgr)
      {
         ADFContext adfCtx = ADFContext.getCurrent();
         if (adfCtx.getContextType() == ADFContext.TYPE_PORTLET)
         {
            mPortletStateManager = mgr;
         }
         else
         {
            mDefaultStateManager = mgr;
         }
      }
   }
}   
