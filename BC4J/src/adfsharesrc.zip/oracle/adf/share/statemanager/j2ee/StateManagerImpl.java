package oracle.adf.share.statemanager.j2ee;

import java.util.HashMap;

import java.security.AccessController;

import oracle.adf.share.statemanager.StateManager;
import oracle.adf.share.statemanager.Policy;

import java.util.Hashtable;

/**
 * A HashMap based implementation of the StateManager.
 * <p>
 * The HashMap based implementation does not implement persistentce or
 * distribution services.  This may be used as a low cost StateManager
 * implementation for those applications that do not require the QoS
 * that is implemented by some of the other StateManager implementations.
 */
public class StateManagerImpl implements StateManager
{
   private static HashMap mContextMaps = new HashMap();

   public StateManagerImpl()
   {
   }
   
   public void init(Hashtable env)
   {
   }
   
   public Object getState(Object context, Object id)
   {
      synchronized(mContextMaps)
      {
         HashMap contextMap = (HashMap)mContextMaps.get(context);
         if (contextMap != null)
         {
            return contextMap.get(id); 
         }

         return null;
      }
   }

   public Object putState(Object context, Object id, Object state)
   {
      return putState(context, id, state, null);
   }

   public Object putState(Object context, Object id, Object state, Policy policy)
   {
      synchronized(mContextMaps)
      {
         HashMap contextMap = (HashMap)mContextMaps.get(context);
         if (contextMap == null)
         {
            contextMap = new HashMap(4);
            mContextMaps.put(context, contextMap);
         }

         return contextMap.put(id, state);
      }
   }

   public Object removeState(Object context, Object id)
   {
      synchronized(mContextMaps)
      {
         HashMap contextMap = (HashMap)mContextMaps.get(context);
         if (contextMap != null)
         {
            return mContextMaps.remove(id);
         }
         
         return null;
      }
   }

   public void clearStates(Object context)
   {
      synchronized(mContextMaps)
      {
         mContextMaps.remove(context);
      }
   }
}

