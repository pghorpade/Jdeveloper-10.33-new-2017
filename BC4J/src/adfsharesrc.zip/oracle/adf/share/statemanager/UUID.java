package oracle.adf.share.statemanager;

import java.security.SecureRandom;

import java.io.Serializable;

public class UUID implements Serializable
{
   static final long serialVersionUID = 9008807960891297392L;

   private static volatile SecureRandom mGenerator = null;
   
   private final long mMSB;
   private final long mLSB;
     
   private transient String mStringValue;
  
  // encapsulates logic for a simple type 4 UUID.  Do not use downcast
  // to this interface it may be replaced with the 1.5 UUID support.
   private UUID()
   {
      if (mGenerator == null)
      {
        mGenerator = new SecureRandom();
      }
      
      byte[] randomBytes = new byte[16];
      mGenerator.nextBytes(randomBytes);
      
      // format the random bytes as necessary
      //
      // set the two most significant bits (bits six and seven) of the
      // clock_seq_hi_and_reserved to zero and one respectively
      randomBytes[8] &= 0xbf; // turns off bit 6
      randomBytes[8] |= 0x80; // turn on bit 7 (only)
      
      // set the four most significant bits (12 -15) of the time_hi_and_version
      // field to the four bit version number from section 4.13
      randomBytes[6] &= 0x0f;
      randomBytes[6] |= 0x40;
      
      long msb = 0;
      for (int i=0; i < 8; i++)
      {
         msb = (msb << 8) | (randomBytes[i] & 0xff);
      }
      
      long lsb = 0;
      for (int i=8; i < 16; i++)
      {
         lsb = (lsb << 8) | (randomBytes[i] & 0xff);
      }
      
      mMSB = msb;
      mLSB = lsb;
   }
  
   private UUID(long msb, long lsb)
   {
      mMSB = msb;
      mLSB = lsb;
   }

   public String toString()
   {
      if (mStringValue == null)
      {
         StringBuffer sb = new StringBuffer(132);
         sb.append(digits(mMSB >> 32, 8));
         sb.append('-');
         sb.append(digits(mMSB >> 16, 4));
         sb.append('-');
         sb.append(digits(mMSB, 4));
         sb.append('-');
         sb.append(digits(mLSB >> 48, 4));
         sb.append('-');
         sb.append(digits(mLSB, 12));
         mStringValue = sb.toString();
      }
     
      return mStringValue;
   }
   
   private static String digits(long val, int digits)
   {
      // turn on the next most significant bit so that the zeros are padded out
      long hi = 1L << (digits * 4);
      
      // make sure that we don't return the character that we turned on.
      return Long.toHexString(hi | (val & (hi - 1))).substring(1);
   }
   

   public boolean equals(Object uuid)
   {
      if ((uuid instanceof UUID)
         && ((UUID)uuid).mMSB == mMSB && ((UUID)uuid).mLSB == mLSB)
      {
         return true;
      }
      else
      {
         return false;
      }
   }
   
   public int hashCode()
   {
      // just grab the least significant bits of mLSB for now.
      return (int)mLSB >> 32;
   }

   public static Object generateUUID()
   {
      return new UUID();
   }

   public static Object generateUUID(String uuidString)
   {
      long msb = 0;
      msb = Long.parseLong(uuidString.substring(0, 8), 16) << 32;
      msb = msb | (Long.parseLong(uuidString.substring(9, 13), 16) << 16);
      msb = msb | Long.parseLong(uuidString.substring(14, 18), 16);
      
      long lsb = 0;
      lsb = Long.parseLong(uuidString.substring(19, 23), 16) << 48;
      lsb = (lsb | Long.parseLong(uuidString.substring(24, 36), 16));
   
      return new UUID(msb, lsb);
   }
}
