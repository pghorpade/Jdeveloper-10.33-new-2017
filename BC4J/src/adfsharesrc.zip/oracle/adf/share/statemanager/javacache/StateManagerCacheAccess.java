package oracle.adf.share.statemanager.javacache;

import oracle.ias.cache.Attributes;
import oracle.ias.cache.CacheAccess;
import oracle.ias.cache.CacheException;
import oracle.ias.cache.InvalidArgumentException;

import oracle.adf.share.statemanager.Policy;
import oracle.adf.share.statemanager.DefaultPolicyImpl;


class StateManagerCacheAccess
{
   private static String STATE_MANAGER_CACHE_REGION = "__state_manager_cache_region__";

   private final String mScopeName;
   private final Object mObjId;
   
   private final CacheAccess mCacheAccess;
   
   private final Policy mPolicy;
   
   StateManagerCacheAccess(String scopeName, Object objId)
   {
      this(scopeName, objId, null);
   }
   
   StateManagerCacheAccess(String scopeName, Object objId, Policy policy)
   {
      mScopeName = scopeName;
      mObjId = objId;
      
      mCacheAccess = getCacheAccess(scopeName);
      
      if (policy == null)
      {
         // if a policy is not specified then inherit the policy of the scope.
         try
         {
            policy = new AttributePolicyImpl(mCacheAccess.getAttributes());
         }
         catch (CacheException e)
         {
            e.printStackTrace();
            
            // is this ever thrown?
            policy = new DefaultPolicyImpl();
         }
      }
      mPolicy = policy;
   }
   
   Object get()
   {
      try
      {
         if (mCacheAccess.isPresent(mObjId))
         {
            return mCacheAccess.get(mObjId);
         }
         return null;
      }
      catch (CacheException e)
      {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }
   
   Object put(Object obj)
   {
      Attributes attrs = new Attributes();

      // always allow the objects to be spooled by the caching service.
      long flags = Attributes.SPOOL;

      // mark persistent objects as distributable for now.  this will guarantee
      // that the objects will end up in the global machine cache instead of the
      // local process cache.
      //
      // implement the persistent manager later.
      if (mPolicy.isDistributable() || mPolicy.isPersistent())
      {
         flags |= Attributes.DISTRIBUTE;         
      }
      
      attrs.setFlags(flags);
      
      long timeToLive = mPolicy.getTimeToLive();
      if (timeToLive > 0)
      {
         try
         {
            attrs.setTimeToLive(timeToLive);
         }
         catch (InvalidArgumentException e)
         {
            e.printStackTrace();
            throw new RuntimeException(e);
            // can't be thrown
         }
      }
      
      try
      {
         if (!mCacheAccess.isPresent(mObjId))
         {
            // should this use put or use the loader mechanism?  the loader
            // mechanism should provide for better synch.
            mCacheAccess.get(mObjId, new StateManagerCacheLoaderHolder(obj, attrs));
         }
         else
         {
            // replacement does not currently reset the attributes.
            mCacheAccess.replace(mObjId, obj);
         }

         if (mPolicy.isDistributable() || mPolicy.isPersistent())
         {
            mCacheAccess.save(mObjId);
         }
         return obj;
      }
      catch (CacheException e)
      {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   Object remove()
   {
      try
      {
         if (mObjId != null)
         {
            Object obj = null;
            if (mCacheAccess.isPresent(mObjId))
            {
               obj = mCacheAccess.get(mObjId);
               mCacheAccess.destroy(mObjId);
            }
            return obj;
         }
         else
         {
            mCacheAccess.destroy();
            return null;
         }
      }
      catch (CacheException e)
      {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   void destroy()
   {
      try
      {
         if (mCacheAccess != null)
         {
            mCacheAccess.close();
         }
      }
      catch (Exception e)
      {
      }
   }
   
   private CacheAccess getCacheAccess(Object context)
   {
      if (mCacheAccess != null)
      {
        return mCacheAccess;
      }
      
      CacheAccess subRegion;

      Attributes attrs = new Attributes();
      attrs.setLoader(new StateManagerCacheLoader());
      
      // this will prevent cache invalidation.
      attrs.setFlags(Attributes.ORIGINAL);
      
      String subRegionName = context.toString();
      subRegionName = new StringBuffer(STATE_MANAGER_CACHE_REGION)
        .append('/')
        .append(subRegionName)
        .toString();

      try
      {
         subRegion = CacheAccess.getAccess(subRegionName, attrs, true);
      }
      catch (CacheException e)
      {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
  
      return subRegion;
   }
}
