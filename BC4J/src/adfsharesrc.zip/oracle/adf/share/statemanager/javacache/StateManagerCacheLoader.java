package oracle.adf.share.statemanager.javacache;

import oracle.ias.cache.CacheException;
import oracle.ias.cache.CacheLoader;

class StateManagerCacheLoader extends CacheLoader
{
   public StateManagerCacheLoader()
   {
   }
   
   public Object load(Object handle, Object args)
   {
      try
      {
         setAttributes(handle, ((StateManagerCacheLoaderHolder)args).attributes);
      }
      catch (CacheException e)
      {
         // should not ever happen
         e.printStackTrace();
      }
      return ((StateManagerCacheLoaderHolder)args).cacheObject;
   }
}
