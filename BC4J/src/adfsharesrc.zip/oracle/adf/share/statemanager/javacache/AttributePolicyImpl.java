package oracle.adf.share.statemanager.javacache;

import oracle.adf.share.statemanager.DefaultPolicyImpl;

import oracle.ias.cache.Attributes;
import oracle.adf.share.statemanager.Policy;

public class AttributePolicyImpl implements Policy
{
   private final Attributes mAttributes;
   
   public AttributePolicyImpl(Attributes attributes)
   {
      mAttributes = attributes;
   }

   public boolean isPersistent()
   {
      return (mAttributes.getFlags() & Attributes.SPOOL) > 0;
   }

   public boolean isDistributable()
   {
      return (mAttributes.getFlags() & Attributes.DISTRIBUTE) > 0;
   }

   public long getTimeToLive()
   {
      return mAttributes.getTimeToLive();
   }
}