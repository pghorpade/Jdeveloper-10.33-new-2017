package oracle.adf.share.statemanager.javacache;

import oracle.ias.cache.Attributes;

public class StateManagerCacheLoaderHolder 
{
   final Object cacheObject;
   final Attributes attributes;
   
   StateManagerCacheLoaderHolder(Object cacheObject, Attributes attributes)
   {
      this.cacheObject = cacheObject;
      this.attributes = attributes;
   }
}