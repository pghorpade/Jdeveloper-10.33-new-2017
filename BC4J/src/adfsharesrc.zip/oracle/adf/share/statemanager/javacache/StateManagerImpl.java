package oracle.adf.share.statemanager.javacache;

import java.security.AccessController;
import oracle.adf.share.statemanager.StateManager;
import oracle.adf.share.statemanager.Policy;

import oracle.ias.cache.Cache;
import oracle.ias.cache.CacheAttributes;
import oracle.ias.cache.CacheException;
import oracle.ias.cache.CacheLogger;

import java.util.Hashtable;

import java.io.File;

import sun.security.action.GetPropertyAction;

/**
 * A javacache based implementation of the StateManager.
 * <p>
 * Since the javacache is a shared JVM-level resource there are some restrictions
 * that must be followed when using the javacache StateManager:
 * <p>
 * The javacache StateManager depends upon the distributed cache features of
 * the javacache to persist and distribute state.  If the javacache is
 * configured externally for use elsewhere in the application it should be
 * configured with the distribution option enabled and a disk path declared.
 * <p>
 * The javacache StateManager will create the {@link oracle.adf.share.statemanager.javacache.StateManagerCacheAccess#STATE_MANAGER_CACHE_REGION}
 * region for the managed states.  The StateManager will create subregions
 * within that region for each managed scope.
 * <p>
 * An application developer may specify the <tt>ENV_CACHE_ATTRIBUTES</tt>
 * environment parameter when acquiring the StateManager default context to
 * initialize and configure the Cache.  The parameter value should be a
 * {@link oracle.ias.cache.CacheAttributes} instance.  If the Cache has already
 * been initialized (Cache.isReady) then the specified CacheAttributes will be
 * ignored.  If no CacheAttributes are specified and the Cache has not already 
 * been initialized then the StateManager implementation will configure and
 * initialize the Cache with the distribution option enabled and with the
 * disk path equal to the temporary system path (<tt>System.getProperty("java.io.tmpdir")</tt>).
 */
public class StateManagerImpl implements StateManager
{
   public static final String ENV_CACHE_ATTRIBUTES =
      "oracle.adf.share.statemanager.javacache.cache_attributes";
   
   public StateManagerImpl()
   {
   }
   
   public void init(Hashtable env)
   {
      if (!Cache.isReady())
      {
         try
         {
            CacheAttributes cAttrs = (CacheAttributes)env.get(ENV_CACHE_ATTRIBUTES);
            if (cAttrs == null)
            {
               cAttrs = new CacheAttributes();
               cAttrs.setDistribute(true);
   
               GetPropertyAction a = new GetPropertyAction("java.io.tmpdir");
               String tmpdir = ((String) AccessController.doPrivileged(a));
               cAttrs.setDiskPath(tmpdir);

               cAttrs.setLogFileName(
                  new StringBuffer(tmpdir).append(File.separatorChar)
                     .append("javacache.log").toString());
            }
            
            Cache.init(cAttrs);
         }
         catch(CacheException e)
         {
            System.out.println("WARNING:  Could not init the StateManager cache");
            e.printStackTrace();
         }
      }
   }
   
   public Object getState(Object context, Object id)
   {
      StateManagerCacheAccess req = null;
      try
      {
         req = new StateManagerCacheAccess(context.toString(), id);
         return req.get();
      }
      finally
      {
         if (req != null) 
         {
            req.destroy();
         }
      }
   }

   public Object putState(Object context, Object id, Object state)
   {
      return putState(context, id, state, null);
   }

   public Object putState(Object context, Object id, Object state, Policy policy)
   {
      StateManagerCacheAccess req = null;
      try
      {
         req = new StateManagerCacheAccess(context.toString(), id, policy);
         return req.put(state);
      }
      finally
      {
         if (req != null) 
         {
            req.destroy();
         }
      }
   }

   public Object removeState(Object context, Object id)
   {
      StateManagerCacheAccess req = null;
      try
      {
         req = new StateManagerCacheAccess(context.toString(), id);
         return req.remove();
      }
      finally
      {
         if (req != null) 
         {
            req.destroy();
         }
      }
   }

   public void clearStates(Object context)
   {
      StateManagerCacheAccess req = null;
      try
      {
         req = new StateManagerCacheAccess(context.toString(), null);
         req.remove();
      }
      finally
      {
         if (req != null) 
         {
            req.destroy();
         }
      }
   }
}

