package oracle.adf.share.statemanager;

import java.util.Hashtable;

/**
 * The base StateManager interface.  The state manager is designed to
 * manage state that describes "the circumstance or condition of a being
 * or thing at any given time" [<i>Webster's Revised Unabridged Dictionary</i>].
 * <p>
 * ADF/J2EE state is generally implemented  as a property of an
 * object.  The state property of an object is distinct from other
 * properties of an object in that it is usually transient and not
 * independently searchable.
 * <p>
 * ADF components will use the common state manager to load and store
 * states during the lifetime of an application.  This inteface defines
 * operations similar to those found in the Map interface to get, put, 
 * and remove states.
 * <p>
 * Some ADF components may require that state is durable.  Durable states
 * are those that may survive abnormal events like system crash.  The
 * common state manager will support durable states by using a
 * persistence service to read/write state to secondary storage.
 * <p>
 * Some ADF components may also requires that state is distributable.
 * Distributable state is defined as being available on all nodes in
 * a distributed system.  The common state manager will support
 * distributable states by using a distribution service to share states
 * across nodes.
 * <p>
 * To access states, the common state manager requires that each state is
 * uniquely identified by a state id and an ADF context.
 * <p>
 * The state id is to be defined by the ADF component.  State ids must be
 * unique for a context.  Ids of persistent or distributable object must
 * also be Serializable and consistent.  Consistency requires that an
 * identifier for a state is equal across processes.
 * <p>
 * The state context is to be defined as an ADF context.  Examples may
 * include BindingContext or session.
 * <p>
 * A default singleton state manager instance will be managed by the ADF
 * framework.  Most ADF components will access the state manager from
 * a context {@link oracle.adf.share.statemanager.DefaultContext}.
 */
public interface StateManager
{
   /**
   * Invoked by the {@link oracle.adf.share.statemanager.DefaultContext}
   * when the StateManager is instantiated.  Custom implementations may use the
   * environment to perform custom initialization of the StateManager
   * implementation.
   * <p>
   * @param env the default context environment
   */
   public void init(Hashtable env);
   
   /**
    * Returns the specified state.  If the state does not exist
    * returns null.
    * <p>
    * @param context the ADF context of the required state
    * @param id the state id
    * @return the specified state
    */
   public Object getState(Object context, Object id);

   /**
    * Registers a state.
    * <p>
    * @param context the ADF context of the state
    * @param id the state id
    * @param state the state
    * @return the registered state
    */
   public Object putState(Object context, Object id, Object state);

   /**
    * Registers a state with a management policy.  Management policies
    * may be defined to customize how a state will be managed.  The
    * StateManager defines default management policies for most contexts.
    * If a management policy is specified then that policy will override
    * the default policy.
    * <p>
    * @param context the ADF context of the state
    * @param id the state id
    * @param state the state
    * @param policy the management policy.
    * @return the registered state
    */
   public Object putState(Object context, Object id, Object state, Policy policy);

   /**
    * Removes the specified state.  If the state does not exist
    * returns null.
    * <p>
    * @param context the ADF context of the required state
    * @param id the state id
    * @return the specified state
    */
   public Object removeState(Object context, Object id);

   /**
    * Removes all states for the specified conext.
    * <p>
    * @param context an ADF context
    */
   public void clearStates(Object context);
} 
