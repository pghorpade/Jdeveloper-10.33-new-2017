package oracle.adf.share.statemanager;

public class DefaultPolicyImpl implements Policy 
{
   private final boolean mIsPersistent;
   private final boolean mIsDistributable;
   private final long mTimeToLive;
   
   public DefaultPolicyImpl(boolean isPersistent, boolean isDistributable, long timeToLive)
   {
      mIsPersistent = isPersistent;
      mIsDistributable = isDistributable;
      mTimeToLive = timeToLive;
   }
   
   public DefaultPolicyImpl()
   {
      this(false /* isPersistent */, false /* isDistributable */, -1);
   }

   public boolean isPersistent()
   {
      return mIsPersistent;
   }

   public boolean isDistributable()
   {
      return mIsDistributable;
   }

   public long getTimeToLive()
   {
      return mTimeToLive;
   }
}