package oracle.adf.share.statemanager;

import javax.naming.Context;
import java.util.Hashtable;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;

/**
 * A simple InitialContextFactory that may be used to acquire an initial
 * DefaultContext for the StateManager.  This DefaultInitialContextFactory may
 * be specified when acquiring a new JNDI initial context for looking up a
 * StateManager instance:
 * <p><tt>
 * Hashtable env = new Hashtable(4);
 * env.put(InitialContext.INITIAL_CONTEXT_FACTORY, "oracle.adf.share.statemanager.DefaultInitialContextFactory");
 * InitialContext ctx = new InitialContext(env);
 * </tt>
 * <p>
 * Please see {@link oracle.adf.share.DefaultContext} for more information
 * about using the default StateManager initial context.
 */
public class DefaultInitialContextFactory implements InitialContextFactory 
{
   public DefaultInitialContextFactory()
   {
   }

   public Context getInitialContext(Hashtable environment) throws NamingException
   {
      return new DefaultContext(environment);
   }
}
