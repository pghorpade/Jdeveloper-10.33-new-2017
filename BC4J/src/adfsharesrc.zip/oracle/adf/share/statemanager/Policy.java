package oracle.adf.share.statemanager;

/**
 * Defines a state management policy.  The state manager requires 
 * a state management policy for each state.  The policy determines 
 * how the state will be managed.
 * <p>
 * The state manager supports the following policies:
 * <p>
 * <b>Persistent</b>
 * <p>
 * Specifies that a state may be persisted.
 * <p>
 * <b>Distributable</b>
 * <p>
 * Specifies that a state may be distributed.
 * <p>
 * <b>Time To Live</b>
 * <p>
 * Specifies the time that a state may live.
 * <p>
 * A default policy will be defined for each of the ADF contexts.  When the
 * default policy is not appropriate the user may specify an overide policy
 * when registering state with the state manager.
 */
public interface Policy
{
   /**
    * @return a boolean indicating that the state may be persisted
    */
   public boolean isPersistent();

   /**
    * @return a boolean indicating that the state may be distributed
    */
   public boolean isDistributable();

   /**
    * @return a long indicating the time that the state may live in ms
    */
   public long getTimeToLive();
}
