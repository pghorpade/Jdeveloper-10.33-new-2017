package oracle.adf.share.config;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Hashtable;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import oracle.adf.share.security.ADFSecurityConfig;
import oracle.adf.share.jndi.AdfJndiConfig;

import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.security.JAASInitialContextFactory;

import oracle.adf.share.ADFConfig;
import oracle.adf.share.jndi.ProviderProperties;

/**
 *  ADFConfig fallback implementation. Used when we don't have a 
 *  persistent adf configuration available. ADF configuration
 *  is persisted in adf-config.xml. 
 *  This class extends from ADFConfigImpl, because for cases where the
 *  adf-config.xml file does not exist at the .ear level but exists at the 
 *  .war level, we still need one ADFConfigImpl object for reference.
 *  The methods in the FallbackImpl are only to facilitate must have default 
 *  configurations for applications.
 *  
 *  @see ADFConfig
 *  @see ADFConfigFactory
 *  @see ADFConfigImpl
 */
public class FallbackConfigImpl extends ADFConfigImpl
{

   private static final String CONNECTIONS_XML = "/META-INF/connections.xml";

   private String applicationName;
   private Object mdsInstanceFactory = null;


   public Object getMDSInstance()
   {
      try
      {
        //namespace string from  oracle.adf.share.config.ADFMDSConfig
         Map mdsMap = getConfigObject("http://xmlns.oracle.com/adf/mds/config");
         if (mdsMap!= null)
            mdsInstanceFactory = mdsMap.get("MDSInstance");
         if(mdsInstanceFactory == null)
         {
            Class cls = Class.forName("oracle.adf.share.config.ADFMDSConfig", 
                                       true, 
                                       Thread.currentThread().getContextClassLoader());
            Object obj = cls.newInstance();

            Method m = obj.getClass().getDeclaredMethod("getDefaultMDSInstance", 
                                                           new Class[]{String.class});
            mdsInstanceFactory =  m.invoke(obj, new Object[] {applicationName});            
          }
          return mdsInstanceFactory;
         
      }
      catch(Exception ex)
      {
         throw new RuntimeException(ex);
      }
      
   }


   public Context getConnectionsContext() throws NamingException
   {
       Map connMap = getConfigObject(AdfJndiConfig.namespaceURI);
       if (connMap == null) {
           return getDefaultConnectionsContext();   
       }
       return new InitialContext(new Hashtable(connMap));
   }

   static Context getDefaultConnectionsContext() throws NamingException
   {      
      Hashtable env = new Hashtable(3);
      env.put(Context.INITIAL_CONTEXT_FACTORY, 
              "oracle.adf.share.jndi.InitialContextFactoryImpl");
      env.put(Context.PROVIDER_URL, CONNECTIONS_XML);
      env.put(ProviderProperties.DOCUMENT_STORE, 
              "oracle.adf.share.jndi.ResourceBackingStore");

      return new InitialContext(env);
   }

   public Context getSecurityContext() throws NamingException
   {
          Map secMap = getConfigObject(ADFSecurityConfig.namespaceURI);
          if ( secMap == null) {
              return FallbackConfigImpl.getDefaultSecurityContext();   
          }  
          
          JAASInitialContextFactory factory = new JAASInitialContextFactory();
          return factory.getInitialContext(new Hashtable(secMap));   
   }

   static Context getDefaultSecurityContext() throws NamingException
   {
      Hashtable env = new Hashtable(4);
      env.put(Context.INITIAL_CONTEXT_FACTORY, "oracle.adf.share.security.JAASInitialContextFactory");

      String auth = System.getProperty(SecurityEnv.PROP_AUTHORIZATION_ENFORCE);
      env.put(SecurityEnv.PROP_AUTHORIZATION_ENFORCE, 
                  (auth == null || auth.length() == 0) ? SecurityEnv.AUTHORIZATION_ENFORCE_DEFAULT: auth);

      String jaznConfig = System.getProperty(SecurityEnv.PROP_JAZN_CONFIG);
      if (jaznConfig != null && jaznConfig.length() > 0)
      {
         env.put(SecurityEnv.PROP_JAZN_CONFIG, jaznConfig);
      }
   
     env.put(SecurityEnv.PROP_CREDENTIAL_STORE_PROVIDER, SecurityEnv.CREDENTIAL_STORE_PROVIDER_DEFAULT);
     JAASInitialContextFactory factory = new JAASInitialContextFactory();
     return factory.getInitialContext(env);   
   }

}
