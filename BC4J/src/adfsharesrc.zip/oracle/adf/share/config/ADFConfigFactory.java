package oracle.adf.share.config;

import java.util.Map;
import java.util.WeakHashMap;
import java.io.InputStream;

import oracle.adf.share.ADFConfig;
import oracle.adf.share.logging.ADFLogger;


public class ADFConfigFactory
{

   private final static ADFLogger mLogger = ADFLogger.createADFLogger(ADFConfigImpl.class.getName());
   private static Map applications = new WeakHashMap(4);

   static public ADFConfig findOrCreateADFConfig()
   {
      ClassLoader cl = Thread.currentThread().getContextClassLoader();
      return findOrCreateADFConfig(cl,  ADFConfigImpl.ADFCONFIG_FILENAME);
   }




   static public ADFConfig findOrCreateADFConfig(Object context, String resourceName)
   {

      // TODO: Fix synchronization to use dcl 
      // if neessary -dm 3/31/2005
      synchronized(applications)
      {

         ClassLoader cl = Thread.currentThread().getContextClassLoader();
         ADFConfig app = (ADFConfig)applications.get(cl);
         if (app == null)
         {
            InputStream is = cl.getResourceAsStream(resourceName);

            if (is != null)
            {
                mLogger.info( ADFConfigFactory.class.getName() + " Reading "+ resourceName);
               app = new ADFConfigImpl(is, resourceName);
            }
            else
            {
                mLogger.info( ADFConfigFactory.class.getName() + " No " + resourceName+ " found");
               app = new FallbackConfigImpl();
            }
            applications.put(context, app);
         }
         else if (cl != context && app instanceof ADFConfigImpl)
         {
            // has context information is not at the default .ear level.
            Object ctxApp  = applications.get(context);
            if (ctxApp == null) // not already been here
            {
               InputStream is = cl.getResourceAsStream(resourceName);
               if (is != null)
               {
                  ADFConfigImpl adfConfigImpl = (ADFConfigImpl)app;
                   // read the war level config file as well.
                  adfConfigImpl.readConfig(is, resourceName);
               }
               applications.put(context, app); 
            }

         }
         return app;
      }

   }

}



