package oracle.adf.share.config;

import java.io.File;

import java.net.URL;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

import oracle.adf.share.ADFConfig;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


import oracle.mds.core.MDSConstants;
import oracle.mds.core.MDSInstance;


import oracle.mds.config.CustConfig;
import oracle.mds.config.CustClassListMapping;
import oracle.mds.config.MDSConfig;
import oracle.mds.config.MDSConfigurationException;
import oracle.mds.config.PConfig;
import oracle.mds.config.TypeConfig;

import oracle.mds.cust.CustomizationClass;
import oracle.mds.cust.CustClassList;

import oracle.mds.exception.MDSException;

import oracle.mds.persistence.MetadataStore;
import oracle.mds.persistence.stores.file.FileMetadataStore;
import oracle.mds.persistence.stores.file.ClassPathMetadataStore;


import oracle.adf.share.security.identitymanagement.RoleManager;

import oracle.adf.share.logging.ADFLogger;

/* $Header: ADFMDSConfig.java 07-aug-2006.23:01:59 nvarma Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    This class will create the MDSInstance based on the configuration information
    present in the adf-config.xml file.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    nvarma      07/28/06 - 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
    nvarma      08/15/05 - nvarma_adfconfig_support_multiple_level
    nvarma      08/08/05 - Creation
 */

/**
 *  @version $Header: ADFMDSConfig.java 07-aug-2006.23:01:59 nvarma Exp $
 *  @author  nvarma  
 *  @since   10.1.3
 */

public class ADFMDSConfig implements ADFConfigCallback
{

   private static final String providerPaths[] =  {
                     "oracle/adf/dt/schema/main.xsd",
                     "oracle/jbo/dt/schema/jbo_03_01.xsd",
                     "oracle/portlet/container/Generic.xsd",
                     "oracle/portlet/container/Web.xsd",
                     "oracle/portlet/container/WSRP.xsd",
                     "oracle/adfinternal/rc/xml/catalogDefinition.xsd"
                 };

   private MDSInstance defaultInstance = null;
   private boolean mdsInited = false;

   private final static ADFLogger mLogger = ADFLogger.createADFLogger("oracle.adf.share.config");

   //The adf-config.xml file should use this namspace for the adf-mds-config element.
   public final static String namespaceURI="http://xmlns.oracle.com/adf/mds/config";

   /**
   * 
   * @param el The dom element currently being parsed.
   * @param storedResult The cached parsed results thus far for the registered 
   * namespace
   * @param currentCtx the current context available at the time of parsing. 
   * This can store useful information like the file identifier, ServletContext. 
   * This can also be used to store information that may need to be added in 
   * future.
   * @return component returns the Map, which will be cached for that component 
   * and this will be the new storedResult
   */
   public java.util.Map parseADFConfiguration(Element el,
                                              Map storedResult, 
                                              ADFConfigParsingContext currentCtx)
   {
      if (storedResult != null)
         return storedResult; // should not happen, if it does just reuse the results
                              // from the first parsing.
      MDSInstance mdsInstance = null;
      try
      {

         NodeList nl1 = el.getElementsByTagName("mds-config");
          String resourceBeingRead = currentCtx.getConfigFilename();
          if (resourceBeingRead.equalsIgnoreCase(ADFConfig.ADFCONFIG_META_FILENAME)){
             ClassLoader cl = Thread.currentThread().getContextClassLoader();
             URL url = cl.getResource(resourceBeingRead);
             if (url != null && url.getPath() != null) {
                 File relativePath = new File(url.getPath()).getParentFile();
                 mLogger.fine("Found MDS Relative path reference in META-INF/adf-config.xml");
             
                 mdsInstance =  MDSInstance.getOrCreateInstance((String)currentCtx.getApplicationName(),
                                                             new MDSConfig((Element)nl1.item(0), relativePath));
                 }   else {
                 
                    mdsInstance =  MDSInstance.getOrCreateInstance((String)currentCtx.getApplicationName(),
                                                                new MDSConfig((Element)nl1.item(0)));
                 }                                                        
              
          }   else {
          
             mdsInstance =  MDSInstance.getOrCreateInstance((String)currentCtx.getApplicationName(),
                                                         new MDSConfig((Element)nl1.item(0)));
          }                                                        
      }
      catch (MDSConfigurationException ex)
      {
          mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName() +
          "  MDSConfigurationException encountered in parseADFConfiguration"+ "\n" , ex);
         throw new RuntimeException(ex);
      }
      catch (MDSException ex)
      {
          mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName() +
               "MDSException encountered in parseADFConfiguration"+ "\n" , ex);
         throw new RuntimeException(ex);
      }
      HashMap map = new HashMap(2);
      map.put("MDSInstance", mdsInstance);
      return map;      
   }


   MDSInstance getDefaultMDSInstance(String applicationName)
   {
      // Don't retry in case of exceptions
      if(defaultInstance == null && !mdsInited)
      {
         try
         {
            TypeConfig tConfig = null;
            if(useSchemas())
            {
               URL[] urls = getProviderURLs();

               if(urls != null && urls.length > 0)
               {
                  tConfig = new TypeConfig(urls);
               }
            }

            MetadataStore store;
            String fileStorePath = getMDSFileStorePath();
            if(fileStorePath != null && fileStorePath.length() > 0)
            {
               store = new FileMetadataStore(fileStorePath);
            }
            else
            {
               store = new ClassPathMetadataStore();
            }

            PConfig pConfig = new PConfig(store);

            MDSConfig mdsConfig = new MDSConfig(tConfig, pConfig, 
                                                getCustConfig());

            defaultInstance =  MDSInstance.getOrCreateInstance(applicationName,
                                                           mdsConfig);

         }
         catch(MDSConfigurationException ex)
         {
            throw new RuntimeException(ex);
         }
         catch(MDSException ex)
         {
            throw new RuntimeException(ex);
         }
         finally
         {
            mdsInited = true;
         }

      }
       mLogger.fine("Created the defautl MDS Instance");
      return defaultInstance;

   }

   private URL[] getProviderURLs()
   {
      ArrayList urls = new ArrayList();

      ClassLoader loader = Thread.currentThread().getContextClassLoader();
      for(int i = 0 ; i < providerPaths.length; i++)
      {
         URL url = loader.getResource(providerPaths[i]);
         if(url != null)
         {
            urls.add(url);
         }
      }

      return (URL[])urls.toArray(new URL[0]);
   }

   private String getMDSFileStorePath()
   {
      return System.getProperty("mds.store.filesystem.path");
   }

   private boolean useSchemas()
   {
      return Boolean.getBoolean("oracle.adf.mds.useschema");
   }

   private CustConfig getCustConfig()
   {

     ArrayList custClassList = new ArrayList();
     custClassList.add(new UserCC());
     try
     {
        RoleManager roleMgr = new RoleManager("oracle.adf.share.security.providers.jazn.JAZNIdentityManagementProvider");
        CustomizationClass roleCC = new SecurityRoleCC("role", roleMgr);
        custClassList.add(roleCC);

     }
     catch(Throwable t)
     {
        mLogger.fine(t);
        mLogger.warning("Unable to create role customization class..Ignored");
     }

     try
     {
        CustomizationClass[]  custClasses = (CustomizationClass[])custClassList.toArray(new CustomizationClass[0]);

        CustClassListMapping mapping = new CustClassListMapping("/", null, null,
                                                                new CustClassList(custClasses));
        return new CustConfig(new CustClassListMapping[] {mapping});
     }
     catch(Throwable t)
     {
        mLogger.fine(t);
        mLogger.warning("Error creating customization config..Ignored");
     }
     return null;
   }


}
