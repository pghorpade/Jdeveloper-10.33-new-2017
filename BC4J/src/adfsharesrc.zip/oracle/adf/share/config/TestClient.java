package oracle.adf.share.config;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.List;
import org.w3c.dom.Element;

//import oracle.adf.share.ADFConfig;

public class TestClient 
{
  public TestClient()
  {
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args)
  {
    FileInputStream is = null;
    
    try 
    {
      is = new FileInputStream(args[0]);  
    } catch (Exception ex) 
    {
      ex.printStackTrace();
    } finally 
    {
    }
    
  //  ADFConfigImpl ac = new ADFConfigImpl(is);
    
//    //ac.readConfig(is);
//    
//    Properties pc = ac.getCommonConfiguration();
//    
//    
//    List hr = ac.getConfigObjects("MDS");
//    for(int i = 0; i < hr.size(); i++)
//    {
//      Element aco = (Element) hr.get(i);
//      System.out.println(aco.toString());
//    }
//    
//    Element eco = ac.getConfigObject("MDS", "mds1");
//    
//    System.out.println(eco.toString());
  }
}
