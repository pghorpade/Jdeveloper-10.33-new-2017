/* $Header: ADFConfigParsingContext.java 07-aug-2006.22:58:01 nvarma Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    nvarma      08/18/05 - 
    nvarma      08/15/05 - nvarma_adfconfig_support_multiple_level
    nvarma      08/05/05 - Creation
 */

/**
 *  @version $Header: ADFConfigParsingContext.java 07-aug-2006.22:58:01 nvarma Exp $
 *  @author  nvarma  
 *  @since   10.1.3
 */
 
package oracle.adf.share.config;

import oracle.adf.share.logging.ADFLogger;
import java.util.HashMap;


public class ADFConfigParsingContext  {
  private static final String CONTEXT = "_context"; 
  private static final String APPNAME = "_appname"; 
  private static final String FILENAME = "_filename";
 
  private HashMap mDefaultMap = new HashMap(10);
  private static ADFLogger logger = null;

  public ADFConfigParsingContext(String applicationName, Object ctx) 
  {
     this(applicationName, ctx, "");
  }


  public ADFConfigParsingContext(String applicationName, Object ctx, String resource) 
  {
    mDefaultMap.put(APPNAME, applicationName);
    mDefaultMap.put(CONTEXT, ctx);
    mDefaultMap.put(FILENAME, resource);
  }

  /**
   * Will return subclassed ADFLogger that will use log additional information 
   * relative to the node currently being parsed, and the adf-config.xml file.
   */
  public ADFLogger getLogger(){
    if (logger == null)
    {
    // singleton.
      logger = ADFLogger.createADFLogger("oracle.adf.share.config.ADFConfig");
    }
    return logger;    
  }

  /**
   * Return the context under which the file adf-config.xml is being read. 
   * Will return null for .ear(application) level adf-config.xml file
   * Will return  the ServletContext for a web based context.
   * @return the Context
   */
  public Object getContext(){
    return mDefaultMap.get(CONTEXT);
  }
  
  /**
   * Get the application name associated with this parsing context.
   * @return the application name.
   */
  public String getApplicationName(){
    return (String)mDefaultMap.get(APPNAME);
  }
  
   /**
   * Get the config file associated with this parsing context.
   * This would return META-INF/adf-config.xml or WEB-INF/adf-config.xml
   * depending on which config file was being read.
   *
   * @return the config file name.
   */
  public String getConfigFilename() {
    return (String)mDefaultMap.get(FILENAME);
  }
 
}

