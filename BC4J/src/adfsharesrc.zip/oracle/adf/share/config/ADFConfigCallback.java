/*
 * @(#)ADFConfig.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.config;

import org.w3c.dom.Element;
import java.util.Map;
import oracle.adf.share.config.ADFConfigParsingContext;

/**
 * ADFConfigCallback interface is used for all callbacks class which wants to
 * get the notification events from the adf configuration.
 */
public interface ADFConfigCallback 
{
  /**
  * 
  * @param domFragment The dom element currently being parsed.
  * @param storedResult The cached parsed results thus far for the registered 
  * namespace
  * @param currentCtx the current context available at the time of parsing. 
  * This can store useful information like the file identifier, ServletContext. 
  * This can also be used to store information that may need to be added in 
  * future.
  * @return component returns the Map, which will be cached for that component 
  * and this will be the new storedResult
  */
  public java.util.Map parseADFConfiguration(Element domFragment,
                                            Map storedResult, 
                                            ADFConfigParsingContext currentCtx);

 
}