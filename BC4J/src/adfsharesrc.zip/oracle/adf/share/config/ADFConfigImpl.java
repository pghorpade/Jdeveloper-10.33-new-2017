/*
 * @(#)ADFConfigImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.config;

import java.io.InputStream;
import java.io.IOException;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.net.URL;
import java.lang.reflect.Method;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XMLParseException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import oracle.adf.share.ADFConfig;
import oracle.adf.share.ADFContext;
import oracle.adf.share.jndi.AdfJndiConfig;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.ADFSecurityConfig;

import oracle.adf.share.security.JAASInitialContextFactory;

/**
 * This is a implementation class of ADF configuration object. The Application 
 * Configuration object will manage and store the Application wide configuration 
 * information for diifferent components of an ADF application.  
 * <p>
 * ADF configuration object is initilzed with ADF context object.
 * <p>
 * The adf configuration file looks like
  <body>&lt;?xml version=&quot;1.0&quot; encoding=&quot;windows-1252&quot; ?&gt;
  <pre>&lt;schema xmlns=&quot;http://www.w3.org/2001/XMLSchema&quot;</pre>
  <pre>&nbsp; xmlns:adf=&rdquo;
    <a href="http://xmlns.oracle.com/adf/config">http://xmlns.oracle.com/adf/config</a>&rdquo;
  </pre>
  <pre>&nbsp; targetNamespace=&quot;http://xmlns.oracle.com/adf/jndi/config&quot;</pre>
  <pre>&nbsp; xmlns:jndiC=&quot;http://xmlns.oracle.com/adf/jndi/config&quot;</pre>
  <pre>&nbsp; elementFormDefault=&quot;qualified&quot;&gt;</pre>
  <pre>&nbsp; &lt;complexType name=&quot;PropertyType&quot;&gt;</pre>
  <pre>&nbsp; &lt;attribute name=&quot;name&quot; type=&quot;string&quot;/&gt;</pre>
  <pre>&nbsp; &lt;attribute name=&quot;value&quot; type=&quot;string&quot; /&gt;</pre>
  <pre> &lt;/complexType&gt;</pre>
  <pre> &lt;complexType name=&quot;ADFJndiConfigType&quot;&gt;</pre>
  <pre>&nbsp; &lt;sequence&gt;</pre>
  <pre>&nbsp;&nbsp; &lt;element name=&quot;contextEnv&quot; type=&quot;jndiC:PropertyType&quot; 
minOccurs=&quot;0&quot;&nbsp; maxOccurs=&quot;unbounded&quot;/&gt;</pre>
  <pre>&nbsp; &lt;/sequence&gt;</pre>
  <pre>&nbsp;&nbsp;&lt;attribute name=&quot;initialContextFactoryClass&quot;</pre>
  <pre>&nbsp; default=&quot;oracle.adf.share.jndi.InitialContextFactoryImpl&quot;/&gt;</pre>
  <pre>&nbsp; &lt;attribute name=&quot;backingStoreClass&quot;</pre>
  <pre>&nbsp; default=&quot;oracle.adf.share.jndi.ResourceBackingStore&quot;/&gt;</pre>
  <pre>&nbsp; &lt;attribute name=&quot;backingStoreURL&quot; default=&quot;META-INF/connections.xml&quot;/&gt;</pre>
  <pre> &lt;/complexType&gt;</pre>
  <pre> </pre>
  <pre>&nbsp;&lt;element name=&quot;adf-jndi-config&quot; type=&quot;jndiC:ADFJndiConfigType&quot;</pre>
  <pre>&nbsp; substitutionGroup=&quot;adf:adf-config-child&quot;/&gt;</pre>
   <pre>&lt;/schema&gt;</pre>

  </body>
 *
 * @version 10.1.3, 02/05/05
 * @since 10.1.3
 */
public class ADFConfigImpl implements ADFConfig 
{
   final static String ADFCONFIG_FILENAME = "META-INF/adf-config.xml";
   final static String CALLBACK_FILE = "META-INF/services/adf-config.properties";
   public final static String ADF_CONFIG_CHILD = "adf-config-child";
   private Hashtable storedResults = new Hashtable(10);

   public static final String nameSpaceURI = "http://xmlns.oracle.com/adf/config";
   private final static ADFLogger mLogger = ADFLogger.createADFLogger(ADFConfigImpl.class.getName());

   private static Map callbackMap = new HashMap(10);
   private String mApplicationName;
   private static int appCounter = 0;


   ADFConfigImpl()
   {
      init();
   }

   ADFConfigImpl(InputStream is, String resource)
   {
      init();
      readConfig(is, resource);
   }

   public Object getId()
   {
      return this;
   }

   /**
    * Initilization function, which will load the adf config xml file, process
    * the configuration object.
    */
   public void init()
   {
      generateApplicationName();

   }


//  private void loadCallbackListeners() 

   static {
      try
      {
         ClassLoader cl = Thread.currentThread().getContextClassLoader();
         // NOTE: using getlisteners() here.
         final Enumeration listeners = cl.getResources(CALLBACK_FILE);

         if (listeners != null)
         {
            // Merge all mappings in 'listeners':

            while (listeners.hasMoreElements ())
            {
               final URL url = (URL) listeners.nextElement ();
               final Properties mapping;

               InputStream urlIn = null;
               try
               {
                  urlIn = url.openStream ();

                  mapping = new Properties ();
                  mapping.load (urlIn); // Load in .properties format.
                  callbackMap.putAll(mapping);
               }
               catch (IOException ioe)
               {
                  // Ignore this resource and go to the next one.
                  continue;
               }
               finally
               {
                  if (urlIn != null)
                     try
                     {
                        urlIn.close ();
                     }
                     catch (Exception ignore)
                     {
                        ignore.toString();
                     }
               }
            }
         }
      }
      catch (Exception ignore)
      {
      }

   }



   /**
    * read the adf-config.xml from meta-inf, and parse it into dom object
    * 
    * @param is InputStream of adf-config.xml
    */
   public void readConfig(InputStream is, String resource)
   {

      try
      {
         if (is == null)
         {
            throw new IllegalArgumentException();
         }

         DOMParser dp  = new DOMParser();
         dp.setPreserveWhitespace(true);
         dp.parse(is);
         XMLElement root = (XMLElement) dp.getDocument().getDocumentElement();
         if (root != null)
         {
            Set namespaceSet = callbackMap.keySet();
            if (namespaceSet == null || namespaceSet.isEmpty())
               return; //no one needs config information
            NodeList nl = root.getChildNodes();
            Object ctx = null;
            try 
            {
              ctx = ADFContext.getCurrent().getEnvironment().getContext();
            }catch( Exception ignore ) 
            {
              // null or unsupported exception, both possible at app level.
            }
            for (int i = 0 ; nl!=null && i < nl.getLength() ; i++)
            {
               Node app = nl.item(i);
               String ns = app.getNamespaceURI();
               if (namespaceSet.contains(ns))
               {
                  // notify the registered calllbacks for this element.      
                  Map mapResult = getResultFromComponent(app,
                     (Map)storedResults.get(ns), ctx, resource);
                  if (mapResult != null)
                     storedResults.put(ns, mapResult);
               }
            }
//        }
         }
      }
      catch (XMLParseException pe)
      {
          StringBuffer mesg = new StringBuffer(pe.getMessage());
          mesg.append(" Error at Col number: "+pe.getColumnNumber());
          mesg.append ("Line number : "+pe.getLineNumber());        
           
            mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName()+  "  " +
               mesg );
         throw new RuntimeException(pe);
      }
      catch (Exception e)
      {
          String mesg = e.getMessage();
          if (mesg == null)
              mesg = "";
            mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName()+  "  " +
              mesg, e);
         throw new RuntimeException(e);
      }
      // Bug 5722822, closing the inputStream to remove reference
      // to the adf-config.xml file so that it undeploys successfully.
      finally
      {
        try
        {
          is.close();
        }
        catch (Exception e)
        {
          String mesg = e.getMessage();
          if (mesg == null)
              mesg = "";
            mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName()+  "  " +
              mesg, e);
          throw new RuntimeException(e);
        }
     }

   }

   private Map getResultFromComponent(Node el, Map storedResult, Object ctx, String resource)
   {
      String cbClassName = (String)callbackMap.get(el.getNamespaceURI());
      final Class cls;
      final Object handler;
      final Method method;
      Map map= null;
      try
      {
         cls = Class.forName(cbClassName, true, 
                         Thread.currentThread().getContextClassLoader());
         handler = cls.newInstance ();
         method = cls.getMethod("parseADFConfiguration", new Class[]{Element.class, 
                                   Map.class, ADFConfigParsingContext.class});
         ADFConfigParsingContext adfParsingCtx = new ADFConfigParsingContext(
          mApplicationName, ctx, resource);//TODO put correct context here

         map = (Map)method.invoke(handler, new Object[] {el, storedResult, 
                                     adfParsingCtx});

      }
      catch (ClassNotFoundException e)
      {
          mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName()+ "  " +
          e.getMessage(), e.getCause());
      }
      catch (Exception e)
      {
          mLogger.log(ADFLogger.INTERNAL_ERROR, getClass().getName()+ "  " +
            e.getMessage(), e.getCause());
      }
      return map;
   }


   /**
    * get the configuration object information stored for the provided namespace
    * 
    * @return java.util.Map storedResults for this namespace.
    * @param namespace namespace for which configObject is to be returned
    */
   public Map getConfigObject(String namespace)
   {
      return(Map)storedResults.get(namespace);
   }


   public Object getMDSInstance()
   {
      Map mMDSContext = (Map)storedResults.get(ADFMDSConfig.namespaceURI);
      if (mMDSContext == null)
      {
         throw new RuntimeException("Unable to find MDS configuration");
      }
      return mMDSContext.get("MDSInstance");
   }



   public Context getConnectionsContext() throws NamingException
   {
      Hashtable mContextEnv = (Hashtable)storedResults.get(AdfJndiConfig.namespaceURI);
      if (mContextEnv == null) {
           return FallbackConfigImpl.getDefaultConnectionsContext();
      }
      return new InitialContext(mContextEnv);
   }

   synchronized private void generateApplicationName()
   {
      appCounter++;
      mApplicationName = "ADFApplication" + appCounter;
   }

   public Context getSecurityContext() throws NamingException
   {
          Hashtable mSecurityContextEnv = (Hashtable)storedResults.get(ADFSecurityConfig.namespaceURI);
          if (mSecurityContextEnv == null)
          {
              return FallbackConfigImpl.getDefaultSecurityContext();    
          }
          JAASInitialContextFactory factory = new JAASInitialContextFactory();
          return factory.getInitialContext(mSecurityContextEnv);   
       
   }
}
