/* $Header: SecurityRoleCC.java 16-may-2005.17:05:21 cbarrow Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    cbarrow     05/16/05 - Move to new MDS core API 
    dmutreja    05/09/05 - dmutreja_add_security_role_based_customization_9may05
    dmutreja    05/09/05 - Creation
 */

/**
 *  @version $Header: SecurityRoleCC.java 16-may-2005.17:05:21 cbarrow Exp $
 *  @author  dmutreja
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.config;

import java.util.ArrayList;
import java.util.Iterator;

import java.security.Principal;

import oracle.mds.core.MetadataObject;
import oracle.mds.core.RestrictedSession;
import oracle.mds.cust.CacheHint;
import oracle.mds.cust.CustomizationClass;

import oracle.adf.share.security.identitymanagement.RoleManager;
import oracle.adf.share.security.identitymanagement.Role;

import oracle.adf.share.ADFContext;


public class SecurityRoleCC extends CustomizationClass
{
   private final String DEFAULT_LAYER_NAME = "role";
   private String mLayerName = DEFAULT_LAYER_NAME;
   private RoleManager mRoleMgr;

   private static final String roleProviderClassName = "oracle.adf.share.security.providers.jazn.JAZNIdentityManagementProvider";


   public SecurityRoleCC()
   {
   }

   public SecurityRoleCC(String layerName, RoleManager roleMgr)
   {
      mRoleMgr = roleMgr;
      mLayerName = layerName;
   }

   public CacheHint getCacheHint()
   {
     return CacheHint.USER;
   }

   public String getName()
   {
     return mLayerName;
   }

   private RoleManager getRoleManager()
   {
      if(mRoleMgr == null)
      {
         mRoleMgr = new RoleManager(roleProviderClassName);
      }
      return mRoleMgr;
   }

   public String[] getValue(RestrictedSession sess,
                            MetadataObject    mo)
   {
      String custNames[] = null;
      Principal p = ADFContext.getCurrent().getSecurityContext().getUserPrincipal();
      if(p != null)
      {
         ArrayList customizations = new ArrayList();
         Iterator iter = getRoleManager().getRoleList(-1, null).iterator();
         while(iter.hasNext())
         {
            Role role = (Role)iter.next();
            Principal members[] = role.getMembers();
            for(int i = 0 ; i < members.length ; i++)
            {
               if(members[i].equals(p))
               {
                  customizations.add(role.getName());
                  break;
               }
            }
         }
         if(customizations.size() > 0)
         {
            custNames = (String[])customizations.toArray(new String[0]);
         }
      }
      return custNames;
   }

}
