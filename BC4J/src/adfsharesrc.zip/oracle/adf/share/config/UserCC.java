package oracle.adf.share.config;

import java.util.ArrayList;
import java.util.Iterator;

import java.security.Principal;

import oracle.mds.core.RestrictedSession;
import oracle.mds.core.MetadataObject;
import oracle.mds.cust.CacheHint;
import oracle.mds.cust.CustomizationClass;

import oracle.adf.share.security.identitymanagement.RoleManager;
import oracle.adf.share.security.identitymanagement.Role;

import oracle.adf.share.ADFContext;


public class UserCC extends CustomizationClass
{
   private static final String DEFAULT_LAYER_NAME = "user";
   private String mLayerName = DEFAULT_LAYER_NAME;
   
   public UserCC()
   {
   }

   public UserCC(String layerName)
   {
      mLayerName = layerName;
   }

   public CacheHint getCacheHint()
   {
     return CacheHint.USER;
   }

   public String getName()
   {
     return mLayerName;
   }

   public String[] getValue(RestrictedSession sess, MetadataObject mo)
   {
      Principal p = ADFContext.getCurrent().getSecurityContext().getUserPrincipal();
      if(p != null)
      {
         return new String[] {p.getName() };
      }
      return null;
   }

}
