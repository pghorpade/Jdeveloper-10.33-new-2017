package oracle.adf.share;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Hashtable;

import oracle.adf.share.config.ADFConfigFactory;
import oracle.adf.share.config.FallbackConfigImpl;

import javax.naming.Context;
import javax.naming.NamingException;



// import oracle.adf.model.BindingContext;
import javax.servlet.jsp.el.VariableResolver;

import oracle.adf.share.security.JAASInitialContextFactory;
import oracle.adf.share.security.SecurityContext;

import oracle.adf.share.statemanager.StateManagerScopeAdapter;

import oracle.adf.share.el.ADFContextVariableResolverImpl;
import oracle.adf.share.el.ADFExpressionEvaluator;
import oracle.adf.share.el.OracleExpressionEvaluatorImpl;


import oracle.mds.core.MDSInstance;
import oracle.mds.core.MDSSession;
import oracle.mds.config.CustClassListMapping;
import oracle.mds.config.CustConfig;


/**
 *  The execution context for an ADF application 
 */
public abstract class ADFContext
{
  public static final int TYPE_GENERIC = 0x01;
  public static final int TYPE_HTTP = 0x02;
  public static final int TYPE_PORTLET = 0x03;

   private final static String MDS_SESSION_CUSTOMIZER = "oracle.adf.share.MdsSessionCustomizer";
   public static String SESSION_SCOPE = "sessionScope";
   public static String REQUEST_SCOPE = "requestScope";
   public static String APPLICATION_SCOPE = "applicationScope";

   private SecurityContext securityContext;
   private Object mdsSession = null;

   private transient Map scopeMap = new HashMap(3);

   private transient ADFExpressionEvaluator mExpressionEvaluator
      = new OracleExpressionEvaluatorImpl();

   private transient VariableResolver mVariableResolver = null;

   private static ThreadLocal contextStore = new InheritableThreadLocal();

   /** Uncomment if classloader is not thread safe. Doubt it. 
      -dm 4/5/2005 
   private static ThreadLocal initialized = new ThreadLocal();
   private static Object storeLock = new Object();
   */

   abstract protected Environment loadEnvironment();

   /**
    * Add a scope to the ADFContext.  
    * <p>
    * Scopes may be used by ADF applications to store application state.  For example,
    * the following code could be used to store an application state in the
    * sessionScope:
    * <p>
    * <tt>
    * Map sessionScope = ADFContext.getCurrent().getSessionScope().put(&lt;stateId&gt;, &lt;state&gt;);
    * </tt>
    * <p>
    * ADF supports three standard scopes:  applicationScope, sessionScope, and
    * requestScope.  The lifecycles of these scopes are defined in the ADFScopes
    * documentation and may depend upon the ADFContext's environment.  For example,
    * the lifecycle of the sessionScope may be different in a servlet container than
    * it would be in an EJB container or in a java application.
    * <p>
    * This method may be used by applications that wish to define custom scopes.  If an
    * application has defined a custom scope then it is the application's responsibility
    * to manage the lifecycle of that custom scope.
    * <p>
    * Please note that a custom scope's lifecycle cannot exceed that of the ADFContext
    * itself -- once the ADFContext goes out of scope then all custom scopes will also
    * go out of scope.  Applications that require a custom scope with a lifecycle greater
    * than the ADFContext's must manage those custom scopes elsewhere and associate them
    * with each ADFContext object as it comes into scope.
    * <p>
    * For example, in a servlet container the ADFContext has request
    * level scope -- once request processing ends the ADFContext object will go out
    * of scope.  However, the sessionScope must have a scope that spans multiple requests.
    * ADF solves this issue by associating the session scope to the ADFContext each
    * time the ADFContext is created.
    * 
    * @param name the name of the scope.  Scope names should implement the pattern
    *    <scopeType>Scope.  The session, request, and application scope types are
    *    reserved for use by ADF and should not be used by applications.
    *
    * @param scope the scope implementation.  All scope implementations must implement
    *   the <tt>java.util.Map</tt> interface.
    */
   public void putScope(String name, Map scope)
   {
      scopeMap.put(name, scope);
   }


   /**
    * Retrieve a scope from the ADFContext.
    * <p>
    * See {@link #putScope(String,Map)} for more information about scopes.
    * 
    * @param name the scope name.
    * @return the scope implementation.  null if the scope is not found.
    */
   public Map getScope(String name)
   {
      Map scope = (Map)scopeMap.get(name); 
      if (scope == null)
      {
         scope = createScope(name);
         scopeMap.put(name, scope);
      }
      return scope;
   }

   /**
    * May be implemented by custom ADFContext classes to create a scope for
    * the specfied name.
    * <p>
    * {@link #getScope(String)} will invoke this method if the specified
    * scope has not already been associated with the current ADFContext.  The
    * new scope will be associated with the context until removed or until
    * the context is destroyed.
    */
   public Map createScope(String name)
   {
      // create a HashMap backed scope by default
      return new HashMapScopeAdapter(name, new HashMap(4));
   }

   /**
    * Remove a scope from the ADFContext.
    * <p>
    * See {@link #putScope(String,Map)} for more information about scopes.
    * 
    * @param name the scope name.
    * @return the scope implementation.  null if the scope is not found.
    */
   public Map removeScope(String name)
   {
      return (Map)scopeMap.remove(name); 
   }

   /**
    * Returns the names of all the scopes that are supported by the current ADFContext.
    * <p>
    * See {@link #putScope(String,Map)} for more information about scopes.
    *
    * returns a set of scope names.
    */
   public Set getScopeNames()
   {
      return scopeMap.keySet();
   }

   /**
    * A convenience method for the standard applicationScope.  This method name uses
    * JavaBean naming patterns so that it may be used by JavaBean toolsets.
    * <p>
    * Equivalent to invoking <tt>getScope(APPLICATION_SCOPE)</tt>.
    *
    * @return the standard application scope.
    */
   public Map getApplicationScope()
   {
      return getScope(APPLICATION_SCOPE);
   }

   /**
    * A convenience method for the standard sessionScope.  This method name uses
    * JavaBean naming patterns so that it may be used by JavaBean toolsets.
    * <p>
    * Equivalent to invoking <tt>getScope(SESSION_SCOPE)</tt>.
    *
    * @return the standard session scope.
    */
   public Map getSessionScope()
   {
      return getScope(SESSION_SCOPE);
   }

   /**
    * A convenience method for the standard requestScope.  This method name uses
    * JavaBean naming patterns so that it may be used by JavaBean toolsets.
    * <p>
    * Equivalent to invoking <tt>getScope(REQUEST_SCOPE)</tt>.
    *
    * @return the standard request scope.
    */
   public Map getRequestScope()
   {
      return getScope(REQUEST_SCOPE);
   }


  /**
   *  Gets the ADF configuration Object used by current 
   *  thread.
   * 
   *  @deprecated Use getADFConfig() instead.
   *  
   */
   public ADFConfig getApplication()
   {
     return getADFConfig();
   }

   /**
   *  Gets the ADF configuration Object used by current 
   *  thread.
   */
   public ADFConfig getADFConfig()
   {
      // Do not cache the application.
      // Some servers use the same thread 
      // for initing multiple applications. 
      // Bug4552744 -dm 8/26/2005
      return ADFConfigFactory.findOrCreateADFConfig();
   }

  /**
   *  Gets the security context for the current thread
   */
   public SecurityContext getSecurityContext()
   {
      if(securityContext == null)
      {
         try 
         {
            securityContext = (SecurityContext) getADFConfig().getSecurityContext();
            setSecurityContext(securityContext);
         }
         catch (NamingException ne)
         {
            //throws exception
            ne.printStackTrace();
         }
      }
      return securityContext;
   }

   /**
    *  Convenience for accessing the adf jndi context, for managing
    *  adf connection definitions. 
    */
    public Context getConnectionsContext() throws NamingException
    {
       return getADFConfig().getConnectionsContext();
    }

   /**
    * Gets the ADF context for the current thread
    */
   public static ADFContext getCurrent()
   {
      ADFContext ctx = (ADFContext)getContextStore().get();   
      if(ctx == null)
      {
         ctx = new DefaultContext();
         ctx.setAsCurrent();
      }
      return ctx;
   }


       /**
        * Gets the Application Name. This will be over ridden by subclasses that
        * can return a meaningful application name such as in the case of a 
        * deployed application.
        */
       public String getApplicationName(){
              return null;
       }

   /**
    * Sets up this context as the current context. 
    * This is required for multi-threaded environment
    * such as an application server, where a thread pool 
    * is used. Should be called to associate this 
    * context to the thread retrieved
    * from the pool. 
    */
   public void setAsCurrent()
   {
      getContextStore().set(this);
   }

   /**
    * Disassociates this context from the current thread. 
    */
   public void removeAsCurrent()
   {
      getContextStore().set(null);
   }

   protected void setSecurityContext(SecurityContext ctx)
   {
      securityContext = ctx;
   }

   protected SecurityContext loadSecurityContext()
   {
      JAASInitialContextFactory factory = new JAASInitialContextFactory();
      SecurityContext secCtx = null;
      try 
      {
         secCtx = (SecurityContext) factory.getInitialContext(null);   
         setSecurityContext(secCtx);
      }
      catch (NamingException ne)
      {
         //throws exception
         ne.printStackTrace();
      }
     
      return secCtx;
   }


  /**
   *  Gets the security context for the current thread
   */
   public Context getConfigSecurityContext() throws NamingException
   {
      return getADFConfig().getSecurityContext();
   }

   final public Environment getEnvironment()
   {
      return loadEnvironment();
   }

   public boolean hasEnvironment()
   {
      return false;
   }

   /**
    * Returns a variable resolver for this context.
    * <p>
    * The VariableResolver will be used whenever evaluating expressions
    * that will be evaluated by the ADFContext expression evaluator.
    */
   public VariableResolver getVariableResolver()
   {
      if (mVariableResolver == null)
      {
         mVariableResolver = new ADFContextVariableResolverImpl();
      }
      return mVariableResolver;
   }

   public void setVariableResolver(VariableResolver variableResolver)
   {
      if (variableResolver != null)
      {
         mVariableResolver = variableResolver;
      }
   }

   public ADFExpressionEvaluator getExpressionEvaluator()
   {
      return mExpressionEvaluator;
   }

   public void setExpressionEvaluator(ADFExpressionEvaluator expressionEvaluator)
   {
      if (expressionEvaluator != null)
      {
         mExpressionEvaluator = expressionEvaluator;
      }
   }

   /**
    * Returns a StateManagerScopeAdapter for the specified scope.
    */
   public Map getStateManager(String scopeName, Hashtable env)
   {
      return new StateManagerScopeAdapter(scopeName, env);
   }

   /**
    * Returns a type for the context instance.  Current types include:
    *    <li>TYPE_GENERIC</li>
    *    <li>TYPE_HTTP</li>
    *    <li>TYPE_PORTLET</li>
    * the type may be checked to implement logic specific to a platform.
    */
   public abstract int getContextType();

   /**
    * Returns true if the ADFContext is running in an http container.
    * <p>
    * Applications may use this to determine if it is okay to reference
    * Http classes.
    */
   public boolean isHttpContext()
   {
      return false;
   }

   /**
    * Checks the environment to see if this ADFContext references a
    * native session.  The implementation should not create an
    * session if one has not already been created.
    */
   public boolean hasSession()
   {
      return false;
   }

   public Object getMDSInstanceAsObject()
   {
      return getADFConfig().getMDSInstance();
   }

   /**
    *  Get the MDS session associated with this context. 
    *  If no MDS sesion exists, then a new MDS session will be created and 
    *  associated with this context.
    *  
    */
   public Object getMDSSessionAsObject()
   {
      if(mdsSession == null)
      {
         mdsSession = createMDSSession();
      }
      return mdsSession;
   }

   /**
    *  Determine if there is a MDS session associated with this
    *  context
    *  @return True if a mds session was created for this context, 
    *          otherwise false
    *  @see  #getMDSSessionAsObject() getMDSSessionAsObject
    */
   public boolean hasMDSSession()
   {
      return mdsSession != null;
   }


   /**
    *  Sets the customizer to be used for creating the MDS session 
    *  for this context. The customer instance is stored in the session 
    *  scope. Clients who wish to dynamically override the base customization 
    *  (as specified in adf-config) can set the customizer 
    *  before asking for mds session.
    *   
    *  @param MDSSessionCustomizer The customizer instance. 
    *                              If null removes any previously set customizer
    *  
    */
   public void setMDSSessionCustomizer(MDSSessionCustomizer customizer)
   {
      if(customizer != null)
      {
         getSessionScope().put(MDS_SESSION_CUSTOMIZER, customizer);
      }
      else
      {
         getSessionScope().remove(MDS_SESSION_CUSTOMIZER);
      }

   }

  /**
   *  Gets the customizer used for creating the MDS session 
   *  for this context. 
   */
   public MDSSessionCustomizer getMDSSessionCustomizer(MDSSessionCustomizer customizer)
   {
      return (MDSSessionCustomizer)getSessionScope().get(MDS_SESSION_CUSTOMIZER);
   }

   protected Object createMDSSession()
   {

      CustConfig custConfig = null;
      try
      {
         MDSSessionCustomizer customizer = (MDSSessionCustomizer)getSessionScope().get(MDS_SESSION_CUSTOMIZER);
         if(customizer != null)
         {
            List mappings = customizer.getCustomizationMappings();
            if(mappings != null)
            {
               CustClassListMapping[] listMappings = (CustClassListMapping[])mappings.toArray(new CustClassListMapping[0]);
               custConfig = new CustConfig(listMappings);
            }
         }
         return ((MDSInstance)getMDSInstanceAsObject()).createSession(null, 
                                                                      null, 
                                                                      custConfig, 
                                                                      null);

      }
      catch(Exception ex)
      {
         throw new RuntimeException(ex);
      }
   }

   private static ThreadLocal getContextStore()
   {
      /** Uncomment if classloader is not thread safe. Doubt it. 
         -dm 4/5/2005 
      if(initialized.get() == null) 
      {
        synchronized(storeLock)
        {
          if (contextStore == null) 
          {
             contextStore = new ThreadLocal();
          }
          initialized.set(Boolean.TRUE);
        }
      }
      */
      return contextStore;

   }


   /**
    * Retrieve the BindingContext.
    */
//   abstract public BindingContext getBindingContext();
}


class DefaultContext extends ADFContext
{
   protected Environment loadEnvironment()
   {
      // Environment only valid for WEB apps
      throw new UnsupportedOperationException();
   }

      public int getContextType()
      {
         return TYPE_GENERIC;
      }

/*
   public BindingContext getBindingContext()
   {
      // BindingContext only valid for WEB apps
      throw new UnsupportedOperationException();
   }
   */
}



