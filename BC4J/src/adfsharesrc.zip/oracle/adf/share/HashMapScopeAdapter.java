package oracle.adf.share;

import java.util.Map;
import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;

import oracle.adf.share.ADFScope;
import oracle.adf.share.ADFScopeHelper;
import oracle.adf.share.ADFScopeListener;

/* $Header: HashMapScopeAdapter.java 17-aug-2005.16:00:55 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    08/17/05 - 
    jsmiljan    02/09/05 - jsmiljan_scope_020805_1
    jsmiljan    02/08/05 - 
    jsmiljan    02/01/05 - jsmiljan_statemanager_012505
    jsmiljan    01/26/05 - Creation
 */

/**
 *  @version $Header: HashMapScopeAdapter.java 17-aug-2005.16:00:55 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HashMapScopeAdapter implements ADFScope 
{
   private HashMap mAdaptee;
   private final ADFScopeHelper mHelper;
   private final String mScopeName;

   public HashMapScopeAdapter(String scopeName, HashMap adaptee)
   {
      mScopeName = scopeName;

      mAdaptee = adaptee;
      mHelper = new ADFScopeHelper();
   }

   public int size()
   {
      return mAdaptee.size();
   }

   public void clear()
   {
      mAdaptee.clear();
   }

   public boolean isEmpty()
   {
      return mAdaptee.isEmpty();
   }

   public boolean containsKey(Object key)
   {
      return mAdaptee.containsKey(key);
   }

   public boolean containsValue(Object value)
   {
      return mAdaptee.containsValue(value);
   }

   public Collection values()
   {
      return mAdaptee.values();
   }

   public void putAll(Map map)
   {
      mAdaptee.putAll(map);
   }

   public Set entrySet()
   {
      return mAdaptee.entrySet();
   }

   public Set keySet()
   {
      return mAdaptee.keySet();
   }

   public Object get(Object key)
   {
      return mAdaptee.get(key);
   }

   public Object remove(Object key)
   {
      return mAdaptee.remove(key);
   }

   public Object put(Object key, Object value)
   {
      return mAdaptee.put(key, value);
   }

   public void invalidate()
   {
      mHelper.fireScopeInvalidated(mScopeName);

      mAdaptee = null;
   }

   public void addScopeListener(ADFScopeListener listener)
   {
      mHelper.addScopeListener(listener);
   }

   public void removeScopeListener(ADFScopeListener listener)
   {
      mHelper.removeScopeListener(listener);
   }
}
