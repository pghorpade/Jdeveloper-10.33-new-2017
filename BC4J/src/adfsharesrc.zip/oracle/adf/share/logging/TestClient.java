// This is a temporary test program . This is in the process of being cleaned up, updated
// and moved out of this to Testsrc dir. This is not part of the build

package oracle.adf.share.logging;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestClient 
{
  public TestClient()
  {
  }
  public static void test1()
  {
    Logger jlog1 = Logger.getLogger("oracle.wireless.logging");
    Logger jlog2 = Logger.getLogger("oracle.wireless");


    ADFLogger a1 = ADFLogger.createADFLogger("oracle.wireless.logging");
    ADFLogger a2 = ADFLogger.createADFLogger("oracle.wireless");
    
    a1.log(ADFLogger.ERROR, "ADFLogger == oracle.wireless.logging");
    a2.log(ADFLogger.ERROR, "ADFLogger == oracle.wireless");

    jlog1.log(Level.SEVERE, "JAVALogger == oracle.wireless.logging");
    jlog2.log(Level.SEVERE, "JAVALogger == oracle.wireless");
  }
  
  public static void test2()
  {
    ADFLogger logger2 = ADFLogger.createADFLogger("oracle.new.adf");  
    logger2.log(Level.INFO, "Level = test2.logger2");
        
    System.out.println("Position 1");
    java.util.logging.Logger jlogger = Logger.getLogger("oracle.adf.demo");
    System.out.println("Position 2");
    java.util.logging.Logger jlogger2 = Logger.getLogger("oracle.adf");
    System.out.println("Position 3");
    ADFLogger logger = ADFLogger.createADFLogger("oracle.adf.demo");
    System.out.println("Position 4");
    //ADFLogger logger2 = ADFLogger.createADFLogger("oracle.adf");  
    //logger2.log(Level.INFO, "Level = test2.logger2");
    System.out.println("Position 5");
        
    int number = 1;
    System.out.println("Position 6");
       for(int i = 0; i < number; i++)
        {
          /*
          logger.log(ADFLogger.WARNING,"Message 1 = " + i);
          logger.log(ADFLogger.NOTIFICATION,"Notification Test");
          logger.log(ADFLogger.ERROR,"Error Test");
          logger2.info("Convenience Info");
          logger2.fine("Conveninece Fine");
          System.out.println("Position 7");
          logger2.log(ADFLogger.TRACE,"ADFLogger Trace");
          logger2.log(Level.FINE,"Level Fine");
          logger2.log(Level.CONFIG,"Level Config");
          */
          
    logger2.log(Level.INFO, "Level = test2.logger2");
          
          
    //logger2.log(ADFLogger.FINE,"ADFLogger Fine");
    //jlogger.log(Level.SEVERE, "Java Loggger Message 1 = " + i);
        }
        
    System.out.println("Position 8");
  }
  public static void main(String[] args)
  {
    //ADFLogger.setConfiguration(args[0]);
    TestClient.test1();
    TestClient.test2();
  }
}