/*
 * @(#)ADFConsoleHandler.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share.logging;
import java.io.PrintStream;
import java.util.logging.ErrorManager;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;

public class ADFConsoleHandler extends StreamHandler
{
  private PrintStream output;
  
  public ADFConsoleHandler(PrintStream out, Formatter formatter)
  {
    super(out,formatter);
    output = out;  
  }
  
    /**
     * Format and publish a <tt>LogRecord</tt>.
     * <p>
     * The <tt>StreamHandler</tt> first checks if there is an <tt>OutputStream</tt>
     * and if the given <tt>LogRecord</tt> has at least the required log level.
     * If not it silently returns.  If so, it calls any associated
     * <tt>Filter</tt> to check if the record should be published.  If so,
     * it calls its <tt>Formatter</tt> to format the record and then writes 
     * the result to the current output stream.
     * <p>
     * If this is the first <tt>LogRecord</tt> to be written to a given
     * <tt>OutputStream</tt>, the <tt>Formatter</tt>'s "head" string is 
     * written to the stream before the <tt>LogRecord</tt> is written.
     *
     * @param  record  description of the log event
     */
    public synchronized void publish(LogRecord record) 
    {
      if (!isLoggable(record))  return;
      String msg;
      try 
      {
        msg = getFormatter().format(record);
      } 
      catch (Exception ex) 
      {
        // We don't want to throw an exception here, but we
        // report the exception to any registered ErrorManager.
        reportError(null, ex, ErrorManager.FORMAT_FAILURE);
        return;
      }

	    output.print(msg);
    }


    /**
     * Check if this <tt>Handler</tt> would actually log a given <tt>LogRecord</tt>.
     * <p>
     * This method checks if the <tt>LogRecord</tt> has an appropriate level and 
     * whether it satisfies any <tt>Filter</tt>.  It will also return false if
     * no output stream has been assigned yet.
     * <p>
     * @param record  a <tt>LogRecord</tt>
     * @return true if the <tt>LogRecord</tt> would be logged.
     *
     */
    public boolean isLoggable(LogRecord record) 
    {
      if (output == null) return false;
    	return super.isLoggable(record);
    }

    /**
     * Flush any buffered messages.
     */
    public synchronized void flush() 
    {
    }

    private synchronized void flushAndClose() throws SecurityException 
    {
	    output = null;
    }

    /**
     * Close the current output stream.
     * <p>
     * The <tt>Formatter</tt>'s "tail" string is written to the stream before it
     * is closed.  In addition, if the <tt>Formatter</tt>'s "head" string has not
     * yet been written to the stream, it will be written before the
     * "tail" string.
     *
     * @exception  SecurityException  if a security manager exists and if
     *             the caller does not have LoggingPermission("control").
     * @exception  SecurityException  if a security manager exists and if
     *             the caller does not have LoggingPermission("control").
     */
    public synchronized void close() throws SecurityException 
    {
      flushAndClose();
    }
  
}