package oracle.adf.share.jndi;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.security.credentialstore.CredentialProvisioner;
import oracle.adf.share.security.credentialstore.CredentialStore;
import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.identitymanagement.UserManager;

import java.security.Principal;

public class CredentialStoreHelper
{

   private static CredentialStoreHelper singleton = null;
   private static ThreadLocal initialized = new ThreadLocal();
   private static Object syncLock = new Object();

   private UserManager  userMgr ; 
   private CredentialProvisioner csp ;
   private CredentialStore cs;

   static public CredentialStoreHelper getInstance() throws Exception
   {
      if(initialized.get() == null) 
      {
        synchronized(syncLock)
        {
          if (singleton == null) 
          {
             singleton = new CredentialStoreHelper();
          }
          initialized.set(Boolean.TRUE);
        }
      }
      return singleton;
   }


   public CredentialStoreHelper() throws Exception
   {
      userMgr = new UserManager("oracle.adf.share.security.providers.jazn.JAZNIdentityManagementProvider");
      csp = new CredentialProvisioner("oracle.adf.share.security.providers.jazn.JAZNCredentialStore");;
      cs = new CredentialStore("oracle.adf.share.security.providers.jazn.JAZNCredentialStore");
   }


   public void removeCredential(String principalName, String credKey) throws Exception
   {
      Principal principal = userMgr.getPrincipal(principalName);
      csp.removeCredential(credKey, principal);  
   }
   public void storeCredential(String principalName, String credKey, Credential cred) throws Exception
   {
      Principal principal = userMgr.getPrincipal(principalName);
      csp.storeCredential(cred, credKey, principal);
   }

   public Credential fetchCredential(String principalName, 
                                     String credKey) throws Exception
   {
      // Need to talk to Yvonne. Can we authenticate this 
      // principle using the credentials supplied in the
      // context and pass it to credential store 
      // instead of setting it on the ADF context
      // -dm 3/4/2005

      SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
      Principal principal = null;
      
      try
      {
         if(secCtx.getEnvironment().get(SecurityContext.SECURITY_PRINCIPAL) == null)
         {
            principal = userMgr.getPrincipal(principalName);
            secCtx.addToEnvironment(SecurityContext.SECURITY_PRINCIPAL, principal);
         }
         return cs.fetchCredential(credKey);

      }
      finally
      {
         if(principal != null)
         {
            secCtx.removeFromEnvironment(SecurityContext.SECURITY_PRINCIPAL);
         }
      }
   }




}
