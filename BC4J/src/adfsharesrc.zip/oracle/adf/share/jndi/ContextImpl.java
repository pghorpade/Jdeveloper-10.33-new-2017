package oracle.adf.share.jndi;

import java.io.IOException;
import java.lang.reflect.Method;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.NoSuchElementException;
import java.io.Writer;

import javax.naming.Binding;
import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameClassPair;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;

import javax.naming.spi.ObjectFactory;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

import oracle.adf.share.jndi.xml.AnyXmlType;
import oracle.adf.share.jndi.xml.PropertyType;
import oracle.adf.share.jndi.xml.RefAddrType;
import oracle.adf.share.jndi.xml.RefAddressListType;
import oracle.adf.share.jndi.xml.ReferenceFactoryType;
import oracle.adf.share.jndi.xml.ReferenceListType;
import oracle.adf.share.jndi.xml.ReferenceType;
import oracle.adf.share.jndi.xml.References;
import oracle.adf.share.jndi.xml.StringRefAddrType;
import oracle.adf.share.jndi.xml.XmlRefAddrType;
import oracle.adf.share.jndi.xml.SecureRefAddrType;

import oracle.adf.share.security.credentialstore.Credential;


public class ContextImpl implements AdfJndiContext, 
                                    ProviderProperties
                                             
{
   private Hashtable mEnv = null;
   private transient DocumentBackingStore mStore = null;
   private transient JAXBContext mJaxbContext;
   private transient Marshaller mMarshaller;
   private transient Unmarshaller mUnmarshaller;
   private transient Hashtable mBindings;
   private transient Object mRefStoreLock = new Object();
   private transient ReferenceStoreHelper mRefStore = new ReferenceStoreHelper();



   ContextImpl(Hashtable env) throws NamingException
   {
      mEnv = env;
      init();
   }

   public Object lookup(Name name) throws NamingException
   {
      return findObject(name);
   }

   public Object lookup(String name) throws NamingException
   {
      return lookup(NameParserImpl.getInstance().parse(name));
   }

   public void bind(Name name, Object obj) throws NamingException
   {
      if (exists(name))
      {
         throw new NameAlreadyBoundException(name.toString());
      }
      bindObject(name, obj);
   }

   public void bind(String name, Object obj) throws NamingException
   {
      bind(NameParserImpl.getInstance().parse(name), obj);
   }

   public void rebind(Name name, Object obj) throws NamingException
   {
      removeObject(name);
      bindObject(name, obj);
   }

   public void rebind(String name, Object obj) throws NamingException
   {
      rebind(NameParserImpl.getInstance().parse(name), obj);
   }

   public void unbind(Name name) throws NamingException
   {
      removeObject(name);
   }

   public void unbind(String name) throws NamingException
   {
      unbind(NameParserImpl.getInstance().parse(name));
   }

   public void rename(Name oldName, Name newName) throws NamingException
   {
   }

   public void rename(String oldName, String newName) throws NamingException
   {
      rename(NameParserImpl.getInstance().parse(oldName), 
             NameParserImpl.getInstance().parse(newName));
   }

   public NamingEnumeration list(Name name) throws NamingException
   {
      if(!name.isEmpty())
      {
          throw new OperationNotSupportedException();
      }
      return new NameClassEnumerator(this);
   }

   public NamingEnumeration list(String name) throws NamingException
   {
      return list(NameParserImpl.getInstance().parse(name));
   }

   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      if(!name.isEmpty())
      {
          throw new OperationNotSupportedException();
      }
      return new BindingsEnumerator(this);
   }

   public NamingEnumeration listBindings(String name) throws NamingException
   {
      return listBindings(NameParserImpl.getInstance().parse(name));
   }

   public void destroySubcontext(Name name) throws NamingException
   {
      throw new OperationNotSupportedException();
   }

   public void destroySubcontext(String name) throws NamingException
   {
      destroySubcontext(NameParserImpl.getInstance().parse(name));
   }

   public Context createSubcontext(Name name) throws NamingException
   {
      throw new OperationNotSupportedException();
   }

   public Context createSubcontext(String name) throws NamingException
   {
      return createSubcontext(NameParserImpl.getInstance().parse(name));
   }

   public Object lookupLink(Name name) throws NamingException
   {
      throw new OperationNotSupportedException();
   }

   public Object lookupLink(String name) throws NamingException
   {
      return lookupLink(NameParserImpl.getInstance().parse(name));
   }

   public NameParser getNameParser(Name name) throws NamingException
   {
      return NameParserImpl.getInstance();
   }

   public NameParser getNameParser(String name) throws NamingException
   {
      return getNameParser(NameParserImpl.getInstance().parse(name));
   }

   public Name composeName(Name name, Name prefix) throws NamingException
   {
      return null;
   }

   public String composeName(String name, String prefix) throws NamingException
   {
      return composeName(NameParserImpl.getInstance().parse(name), 
                         NameParserImpl.getInstance().parse(prefix)).toString();
   }

   public Object addToEnvironment(String propName, Object propVal) throws NamingException
   {
      return mEnv.put(propName, propVal);
   }

   public Object removeFromEnvironment(String propName) throws NamingException
   {
      return mEnv.remove(propName);
   }

   public Hashtable getEnvironment() throws NamingException
   {
      return(Hashtable)mEnv.clone();
   }

   public void close() throws NamingException
   {    
      saveDocument(getDocumentUrl());
   }

   public String getNameInNamespace() throws NamingException
   {
      return null;
   }

   private void init() throws NamingException
   {
      String url = getDocumentUrl();
      try
      {
         if(cacheEnabled())
         {
            mBindings  = new Hashtable(12);
         }
         mJaxbContext = JAXBContext.newInstance("oracle.adf.share.jndi.xml");
         mStore = createDocumentBackingStore();
         mStore.initialize(mEnv, url);
         load();
      }
      catch (Exception ex)
      {
         throwNamingException(ex);   
      }
   }

   protected DocumentBackingStore createDocumentBackingStore() throws NamingException
   {
      // Find the backing store implementation
      // from the provider properties file
      String storeClassName = (String)mEnv.get(DOCUMENT_STORE);
      if(storeClassName != null && storeClassName.length() > 0)
      {
         try
         {
            Class cls = Class.forName(storeClassName,  true,  
                                      Thread.currentThread().getContextClassLoader());

            if(!DocumentBackingStore.class.isAssignableFrom(cls))
            {
               throw new NamingException(storeClassName + " doesn't implement " + 
                                         DocumentBackingStore.class.getName());
            }

            return (DocumentBackingStore) cls.newInstance();
         }
         catch(InstantiationException ex)
         {
            throwNamingException(ex);
         }
         catch(IllegalAccessException ex)
         {
            throwNamingException(ex);
         }
         catch(ClassNotFoundException ex)
         {
            throwNamingException(ex);
         }
      }
      return new FileSystemBackingStore();
   }

   private void throwNamingException(Exception ex) throws NamingException
   {
      NamingException nex;
      if (ex instanceof NamingException)
      {
         nex = (NamingException) ex;
      }
      else
      {
         nex = new NamingException();
         nex.setRootCause(ex);
      }
      throw nex;
   }

   private String getDocumentUrl() throws NamingException 
   {
      String url = (String)mEnv.get(Context.PROVIDER_URL);

      if (url == null)
         throw new NamingException("Missing provider url");

      return url;
   }

   private  String getMyComponents(Name name) throws NamingException 
   {
      if (name instanceof CompositeName)
      {
         if (name.size() > 1)
         {
            throw new InvalidNameException(name.toString() +
                                           " has more components than namespace can handle");

         }
         return name.get(0);
      }
      else
      {
         return name.toString();
      }
   }

   private Marshaller getMarshaller() throws NamingException
   {
      if (mMarshaller == null)
      {
         try
         {
            mMarshaller = mJaxbContext.createMarshaller();   
            mMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
         }
         catch (JAXBException ex)
         {
            throwNamingException(ex);
         }
      }
      return mMarshaller;
   }

   private Unmarshaller getUnmarshaller() throws NamingException
   {
      if (mUnmarshaller == null)
      {
         try
         {
            mUnmarshaller = mJaxbContext.createUnmarshaller();   
         }
         catch (JAXBException ex)
         {
            throwNamingException(ex);
         }
      }
      return mUnmarshaller;
   }



   Object findObject(Name name) throws NamingException
   {
      String id = getMyComponents(name);
      Object bound = null;

      // Search locally
      if(cacheEnabled())
      {
         bound = mBindings.get(id);
         if (bound != null)
            return bound;
      }
      synchronized (mRefStoreLock) {
          try
          {
            bound = mRefStore.getObjectForReference(id);
          }
          catch(Exception e)
          {
            throwNamingException(e);
          }
      }
      if (bound == null)
      {
         NameNotFoundException nnfe = new NameNotFoundException();
         nnfe.setRemainingName(name);
         throw nnfe;
      }

      if(cacheEnabled())
      {
         mBindings.put(id,  bound);
      }
      return bound;
   }

   private void bindObject(Name name, Object obj) throws NamingException
   {

      if(mStore.isReadOnly())
      {
         throw new NamingException("ReadOnly BackingStore.");  
      }
      Reference reference = null;
      if (obj instanceof Reference)
      {
         reference = (Reference) obj;
      }
      else if (obj instanceof Referenceable)
      {
         reference = ((Referenceable)obj).getReference();
      }
      else
      {
         throw new OperationNotSupportedException("Can only bind Referenceable and Reference");
      }
      String id = getMyComponents(name);

       synchronized (mRefStoreLock) {
          // add the reference to the ReferenceStore
          mRefStore.addReference(id, reference);
       }
    }

   private void removeObject(Name name) throws NamingException
   {
      if(mStore.isReadOnly())
      {
         throw new NamingException("ReadOnly BackingStore.");  
      }
      String id = getMyComponents(name);

      // Remove from cache
      if(cacheEnabled())
      {
         mBindings.remove(id);
      }

       synchronized (mRefStoreLock) {
      // Remove from document
          mRefStore.removeReference(id);
       }
   }

   private boolean exists(Name name) throws NamingException
   {
      String id = getMyComponents(name);

      // Search locally
      if(cacheEnabled())
      {
         Object bound = mBindings.get(id);
         if (bound != null)
         {
            return true;
         }
      }

      return mRefStore.exists(id);

   }

   /*   
    private Document getDocument() throws Exception
    {
       if(mDocument == null)
       {
          mDocument = mStore.readDocument(getDocumentUrl());
       }
       return mDocument;
    }
    */

   private void load() throws NamingException
   {
      try
      {
         if(mStore.documentExists(getDocumentUrl()))
         {
            Document doc = mStore.readDocument(getDocumentUrl());
            References references = (References)getUnmarshaller().unmarshal(doc);
            mRefStore.init(references, this, mEnv);
         }
         else
         {
            mRefStore.init(null, this, mEnv);
         }
      }
      catch (Exception ex)
      {
         throwNamingException(ex);
      }

   }

   private void saveDocument(String url) throws NamingException
   {
      if(!mStore.isReadOnly())
      {
         References references = mRefStore.getReferences();
         if (references != null)
         {
            try
            {
               mRefStore.saveCredentials();
               Document doc = mStore.createDocument(url);
               //writer = mStore.getDocumentWriter(url);
               getMarshaller().marshal(references, doc);
               mStore.writeDocument(doc, url);
               mStore.closeDocument(url);
            }
            catch (Exception ex)
            {
               throwNamingException(ex);
            }
            /*
            finally
            {
               if (writer != null)
               {
                  try
                  {
                     writer.flush();
                     writer.close();
                  }
                  catch (IOException ioex)
                  {
                  }
               }
            }
            */
         }

      }
   }

   public void reload() throws NamingException
   {
      load();
   }

   public void save() throws NamingException
   {
      saveDocument(getDocumentUrl());
   }

   public void saveAs(String url) throws NamingException
   {
      saveDocument(url);
   }

   ReferenceStoreHelper getReferenceStoreHelper()
   {
      return mRefStore;
   }

   private boolean cacheEnabled()
   {
      return false;
   }

}
