package oracle.adf.share.jndi;

import javax.naming.RefAddr;

/**
 * Class reperesenting a secure reference address. 
 * The address content comprise of a property name and a value 
 * which are actually stored in the credential store. 
 * Instances of SecurerefAddr are always added as type "secure" in the reference. 
 */
public class SecureRefAddr extends RefAddr
{
  private String mProp;
  private String mValue;

  public SecureRefAddr(String propName, String propValue)
  {
     super(propName);
     mProp = propName;
     mValue = propValue;
  }
  
  /**
   * Returns the address value. Same as getValue()
   */
  public Object getContent()
  {
    return mValue;
  }

  public String getName()
  {
     return mProp;
  }

  public String getValue()
  {
     return mValue;
  }

}