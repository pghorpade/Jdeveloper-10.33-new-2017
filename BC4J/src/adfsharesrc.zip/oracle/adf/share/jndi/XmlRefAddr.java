package oracle.adf.share.jndi;

import javax.naming.RefAddr;
import org.w3c.dom.DocumentFragment;

public class XmlRefAddr extends RefAddr
{
   private DocumentFragment mFragment;

   public XmlRefAddr(String addrType, DocumentFragment doc)
   {
      super(addrType);
      mFragment = doc;
   }

   public Object getContent() 
   {
      return getDocumentFragment();
   }

   public DocumentFragment getDocumentFragment()
   {
      return mFragment;
   }
}
