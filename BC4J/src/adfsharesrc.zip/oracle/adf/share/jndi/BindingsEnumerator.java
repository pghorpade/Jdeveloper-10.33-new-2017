package oracle.adf.share.jndi;

import javax.naming.Binding;
import javax.naming.CompoundName;
import javax.naming.NamingException;

import oracle.adf.share.jndi.xml.ReferenceType;

class BindingsEnumerator extends NameClassEnumerator
{
   BindingsEnumerator(ContextImpl ctx)
   {
      super(ctx);
   }

   public Object next() throws NamingException 
   {
      ReferenceType refType = nextRefType();
      if(refType != null)
      {
         return new Binding(refType.getName(), 
                            refType.getClassName(),
                            getOwningContext().findObject(NameParserImpl.getInstance().parse(refType.getName())),
                            true);
      }
      return null;
   }

}
