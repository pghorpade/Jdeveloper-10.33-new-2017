package oracle.adf.share.jndi;

import java.util.Hashtable;
import java.io.*;
import java.net.URL;

import javax.naming.Context;

import org.w3c.dom.Document;


import oracle.xml.parser.v2.*;


public class ResourceBackingStore extends DocumentBackingStore 
{
   private String mResourcePath;

   public ResourceBackingStore()
   {
   }

   public void initialize(Hashtable contextEnv, String url) throws Exception
   {
      super.initialize(contextEnv, url);
      Object o = contextEnv.get(Context.PROVIDER_URL);
      if(o instanceof String)
      {
         mResourcePath = (String) o;
      }
   }

   public ResourceBackingStore(String resourcePath)
   {
      mResourcePath = resourcePath;
   }

   public Document readDocument(String url) throws Exception 
   {
         InputStream is = getDocumentStream();
         if(is == null)
         {
            throw new Exception("Unable to find resource " + mResourcePath);
         }
         try
         {
            DOMParser parser = new DOMParser();
            BufferedInputStream in
            = new BufferedInputStream(is);
            parser.parse(in);
            Document doc = parser.getDocument();
            return doc;
         }
         finally
         {
            is.close();
         }
   }

   public boolean documentExists(String url) throws Exception
   {
     ClassLoader cl = Thread.currentThread().getContextClassLoader();
     URL resource = cl.getResource(mResourcePath);
     if (resource == null)
        return false;
     return true;
   }

   public Document createDocument(String url) throws Exception 
   {
      throw new UnsupportedOperationException("ReadOnly");
   }

   public void writeDocument(Document doc, String url) throws Exception 
   {
      throw new UnsupportedOperationException("ReadOnly");
   }

   public boolean isReadOnly()
   {
      return true;
   }

   private InputStream getDocumentStream()
   {
      ClassLoader cl = Thread.currentThread().getContextClassLoader();
      InputStream is = cl.getResourceAsStream(mResourcePath);
      if(is == null && mResourcePath.startsWith("/"))
      {
         is = cl.getResourceAsStream(mResourcePath.substring(1));
      }
      return is;
   }

}

