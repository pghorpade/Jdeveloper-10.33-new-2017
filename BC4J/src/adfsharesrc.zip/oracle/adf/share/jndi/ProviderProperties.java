package oracle.adf.share.jndi;

public interface ProviderProperties
{
   public final static String DOCUMENT_STORE = "oracle.adf.share.jndi.documentstore";
}
