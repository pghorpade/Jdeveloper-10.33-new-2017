package oracle.adf.share.jndi;

import java.util.Iterator;
import java.util.NoSuchElementException;

import javax.naming.NameClassPair;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;

import oracle.adf.share.jndi.xml.ReferenceListType;
import oracle.adf.share.jndi.xml.References;
import oracle.adf.share.jndi.xml.ReferenceType;


class NameClassEnumerator implements NamingEnumeration
{

   protected Iterator mRefIterator;
   protected ContextImpl mCtx;

   NameClassEnumerator(ContextImpl ctx)
   {
      mCtx = ctx;
   }

   public boolean hasMoreElements()
   {
      try
      {
         return hasMore();
      }
      catch (NamingException ex)
      {
         return false;
      }
   }

   public boolean hasMore() throws NamingException 
   {
      ensureIterator();
      return mRefIterator.hasNext();
   }

   public Object next() throws NamingException 
   {
      ReferenceType refType = nextRefType();
      if(refType != null)
      {
         return new NameClassPair(refType.getName(), refType.getClassName());
      }
      return null;
   }

   public Object nextElement()
   {
      try
      {
         return next();
      }
      catch (NamingException e)
      {
         throw new NoSuchElementException(e.toString());
      }
   }

   public void close()
   {
      mRefIterator = null;
   }

   void ensureIterator()
   {
      if(mRefIterator == null)
      {
         References references = mCtx.getReferenceStoreHelper().getReferences();
         mRefIterator = references.getReference().iterator();
      }
   }

   ReferenceType nextRefType()
   {
      ensureIterator();
      return (ReferenceType) mRefIterator.next();
   }

   ContextImpl getOwningContext()
   {
      return mCtx;
   }
}

