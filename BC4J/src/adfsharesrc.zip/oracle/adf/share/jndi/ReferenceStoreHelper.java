/* $Header: ReferenceStoreHelper.java 08-dec-2006.14:36:25 nvarma Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    nvarma      12/08/06 - 
    ychua       11/07/06 - 
    shihuang    10/26/06 - 
    nvarma      05/12/06 - Backport nvarma_conn_sync_references5189366 from 
                           main 
    dmutreja    05/31/05 - 
    cbroadbe    05/19/05 - cbroadbe_reuse_ca_schema_in_rc
    cbroadbe    04/20/05 - Creation
*/
package oracle.adf.share.jndi;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;
import javax.naming.StringRefAddr;

import oracle.adf.share.jndi.xml.AnyXmlType;
import oracle.adf.share.jndi.xml.PropertyType;
import oracle.adf.share.jndi.xml.RefAddressListType;
import oracle.adf.share.jndi.xml.RefAddrType;
import oracle.adf.share.jndi.xml.ReferenceFactoryType;
import oracle.adf.share.jndi.xml.References;
import oracle.adf.share.jndi.xml.ReferenceType;
import oracle.adf.share.jndi.xml.SecureRefAddrType;
import oracle.adf.share.jndi.xml.StringRefAddrType;
import oracle.adf.share.jndi.xml.XmlRefAddrType;
import oracle.adf.share.security.credentialstore.Credential;

import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

/**
 *  ReferenceStoreHelper is a helper class that manages the conversion of 
 *  JNDI Reference objects to/from their persistent representation. This 
 *  includes the persistence of SecureRefAddr objects using the Credential Store.
 *  
 *  All APIs operate on JNDI Reference objects so the client does not need to
 *  know anything about the serialized form of the References or how to convert
 *  JNDI Reference objects to or from the JAXB/Credential Store representation
 *  
 *  @version $Header: ReferenceStoreHelper.java 08-dec-2006.14:36:25 nvarma Exp $
 *  @since   10.1.3
 */
public class ReferenceStoreHelper
{
   private oracle.adf.share.jndi.xml.ObjectFactory 
                   mJaxbFactory = new oracle.adf.share.jndi.xml.ObjectFactory();

   private References mReferences = null;
   private Context mCtx = null;
   private Hashtable mEnv = null;
   private Map mNewCredentials; 
   private Map mDeletedCredentials;
//   private static Object syncLock = new Object();
   private CredentialStoreHelper storage = null;

   /**
    * Initialize the ReferenceStoreHelper.
    * 
    * @param refs JAXB ReferenceListType object that will be used to marshal/
    *             unmarshal the References
    * @param ctx Context this ReferenceStoreHelper is associated with.
    * @param env Environment hashtable containing the security credentials that
    *            should be used to access the Credential Store
    */
   public void init(References refs, Context ctx, Hashtable env)
   {
      mReferences = refs;
      mCtx = ctx;
      mEnv = env;
   }

   /**
    * Get the References object that is being maintained by this 
    * ReferenceStoreHelper instance.
    * 
    * @return the References object that is being maintained by this 
    *         ReferenceStoreHelper instance.
    */
   public References getReferences()
   {
      return mReferences;
   }


   /**
    * Return the Reference for the specified ID.
    * 
    * @param id ID of the JNDI Reference to be returned
    * @return the JNDI Reference identified by id or null one could not be found
    * @throws NamingException if an exception occurs locating the specified
    *         JAXB ReferenceType or converting the JAXB ReferenceType into a 
    *         JNDI Reference
    */
   public Reference findReference(String id) throws NamingException
   {
      ReferenceType refType = findReferenceType(id);
      if (refType == null)
      {
         return null;
      }
      Reference ref = null;
      try
      {
         ref = createReference(refType);
      }
      catch (Exception e)
      {
         throwNamingException(e);
      }
      return ref;
   }


   /**
    * Returns true if a Reference with the specified ID exists in the reference
    * store
    * 
    * @param id ID of the reference
    * @return true if a Reference with the specified ID exists in the reference
    *         store. Otherwise false.
    * @throws NamingException if an exception occurs determining if the reference
    *         exists or not. 
    */
   public boolean exists(String id) throws NamingException
   {
      ReferenceType refType = findReferenceType(id);
      return refType != null;
   }


   /**
    * Get the Object identified by "id".
    * 
    * This method finds the Reference for the specified ID and converts it back 
    * into its original object form.
    * 
    * @param id ID of the object to be returned
    * @return The Object described by the specified Reference
    * @throws Exception if an exception occurs locating the Reference or 
    *         re-creating the object described by the Reference
    */
   public Object getObjectForReference(String id) throws Exception
   {
      ReferenceType refType = findReferenceType(id);
      if (refType == null)
      {
         return null;
      }

      // create the Reference
      Reference reference = createReference(refType);

      // Create the Factory
      ObjectFactory fac = getJndiObjectFactory(refType.getFactory());

      // Invoke Factory for the real object
      return fac.getObjectInstance(reference, new CompositeName(id), mCtx, mEnv);
   }

   /**
    * Return a Map containing a javax.naming.Reference object for each 
    * corresponding JAXB ReferenceType. 
    * 
    * @return a Map containing a JNDI Reference for each corresponding JAXB
    *         ReferenceType
    * @throws NamingException if an exception occurs populating the Map. 
    */
   public Map getReferencesMap() throws NamingException
   {
      Map refMap = new HashMap(10);

      if (mReferences == null)
      {
         return refMap;
      }

      try
      {
         List refList = mReferences.getReference();
         Iterator iter = refList.iterator();
         while (iter.hasNext())
         {
            ReferenceType refType = (ReferenceType)iter.next();
            String id = refType.getName();
            Reference ref = createReference(refType);
            refMap.put(id, ref);
         }
      }
      catch (Exception ex)
      {
         throwNamingException(ex);
      }
      return refMap;
   }

   /**
    * Add a new javax.naming.Reference to the reference store.
    * 
    * @param id ID of the Reference
    * @param ref the Reference to be added
    * @throws NamingException if an exception occurs adding the Reference
    */
   public void addReference(String id, Reference ref) throws NamingException
   {
      ReferenceType refType = findReferenceType(id);
      if (refType == null)
      {
         refType = createReferenceType(id, ref);
         addReferenceType(refType);
      }
      else
      {
         throw new NamingException("Name already in use");
      }
   }


   /**
    * Remove a Reference from the reference store.
    * 
    * @param id ID of the Reference to be removed
    * @throws NamingException if an exception occurs removing the Reference
    */
   public void removeReference(String id) throws NamingException
   {
      removeReferenceType(id);
   }


   /**
    * Write the accummulated changes to the Credential Store.
    * 
    * This method should be called when the ReferenceListType used by this
    * helper is persisted. When called, it writes to the Credential Store any 
    * new credentials associated with References that have been added and 
    * deletes from the Credential Store any credentials associated
    * with References that have been deleted
    * 
    * @throws Exception if an exception occurs writing the accummulated changes
    *                   to the Credential Store
    */
   public void saveCredentials() throws Exception
   {
      // don't do anything if there aren't any changes to credentials
      if (mNewCredentials == null && mDeletedCredentials == null) 
      {
          return;    
      }
//      storage = CredentialStoreHelper.getInstance();
      if (storage == null)
         storage = new CredentialStoreHelper();
      String principal = (String)mEnv.get(Context.SECURITY_PRINCIPAL);
      if(mNewCredentials != null)
      {
         Iterator iter = mNewCredentials.entrySet().iterator();
         while (iter.hasNext())
         {
            Map.Entry entry = (Map.Entry)iter.next();
            storage.storeCredential(principal, 
                                    (String)entry.getKey(), 
                                    (Credential)entry.getValue());
         }

         mNewCredentials.clear();
      }
      if(mDeletedCredentials != null)
      {
         Iterator iter = mDeletedCredentials.keySet().iterator();
         while (iter.hasNext())
         {
            storage.removeCredential(principal, (String)iter.next());
         }
         mDeletedCredentials.clear();
      }
   }

   /**
    * Release any resources being held by the ReferenceStoreHelper instance. 
    * 
    * All pending changes are discarded when this method is called. 
    */
   public void destroy()
   {
      mNewCredentials.clear();
      mDeletedCredentials.clear();

      mJaxbFactory = null;
      mReferences = null;
      mEnv = null;
      mNewCredentials = null;
      mDeletedCredentials = null;
   }


   private ReferenceType findReferenceType(String id) throws NamingException
   {
      if (mReferences == null)
      {
         return null;
      }

      try
      {
         List refList = mReferences.getReference();
         Iterator iter = refList.iterator();
         while (iter.hasNext())
         {
            ReferenceType ref = (ReferenceType)iter.next();
            if (ref.getName().equals(id))
            {
               return ref;
            }
         }
      }
      catch (Exception ex)
      {
         throwNamingException(ex);
      }
      return null;
   }


   private Reference createReference(ReferenceType ref) throws Exception
   {
      Reference reference = new Reference (ref.getClassName(), 
                                           ref.getFactory().getClassName(), null);

      RefAddressListType addrList = ref.getRefAddresses();
      Iterator rIter = addrList.getStringRefAddrOrXmlRefAddrOrSecureRefAddr().iterator();
      while (rIter.hasNext())
      {
         RefAddrType refAddr = (RefAddrType) rIter.next();
         if (refAddr instanceof XmlRefAddrType)
         {
            AnyXmlType anyType = ((XmlRefAddrType)refAddr).getContents();
            Iterator i =  anyType.getAny().iterator();
            while (i.hasNext())
            {
               Node node = (Node)i.next();
               XmlRefAddr xmlRefAddr = new XmlRefAddr(refAddr.getAddrType(),
                                                      createDocumentFragment(node));
               reference.add(xmlRefAddr);
            }
         }
         else if (refAddr instanceof StringRefAddrType )
         {
            reference.add(new StringRefAddr(refAddr.getAddrType(), 
                                            ((StringRefAddrType)refAddr).getContents()));  
         }
      }

      if (ref.getCredentialStoreKey() != null)
      {
         Credential cred = loadCredentials(ref.getCredentialStoreKey());
         Iterator iter = cred.getPropertyNames().iterator();
         while (iter.hasNext())
         {
            String pname = (String)iter.next();
            String value = cred.getProperty(pname);
            reference.add(new SecureRefAddr(pname, value));
         }
      }
      return reference;
   }

   private void addReferenceType(ReferenceType refType) throws NamingException
   {
      if (mReferences == null)
      {
         mReferences = mJaxbFactory.createReferences();
      }

      try
      {
         List refList = mReferences.getReference();
         refList.add(refType);
      }
      catch (Exception ex)
      {
         throwNamingException(ex);
      }
   }

   private void removeReferenceType(String id) throws NamingException
   {
      if (mReferences == null)
      {
         return;
      }

      try
      {
         ReferenceType ref = findReferenceType(id);
         if (ref != null)
         {
            if (ref.getCredentialStoreKey() != null)
            {
               removeCredential(ref.getName());
            }
            mReferences.getReference().remove(ref);
         }
      }
      catch (Exception e)
      {
         throwNamingException(e);
      }
   }

   private ReferenceType createReferenceType(String id, Reference ref)
   {
      Credential credential = new Credential();

      ReferenceType aRef = mJaxbFactory.createReferenceListTypeReference();;

      aRef.setName(id);
      aRef.setClassName(ref.getClassName());

      ReferenceFactoryType refFact = mJaxbFactory.createReferenceFactoryType();
      refFact.setClassName(ref.getFactoryClassName());
      aRef.setFactory(refFact);

      RefAddressListType addrList = mJaxbFactory.createRefAddressListType();

      for (int i = 0 ; i < ref.size(); i++)
      {
         RefAddr refAddr = ref.get(i);   
         if (refAddr instanceof StringRefAddr)
         {
            StringRefAddrType strRefAddrType  = mJaxbFactory.createRefAddressListTypeStringRefAddr();
            strRefAddrType.setContents((String)((StringRefAddr)refAddr).getContent());
            strRefAddrType.setAddrType(((StringRefAddr)refAddr).getType());
            addrList.getStringRefAddrOrXmlRefAddrOrSecureRefAddr().add(strRefAddrType);
         }
         else if (refAddr instanceof XmlRefAddr)
         {
            XmlRefAddrType xmlRef = mJaxbFactory.createRefAddressListTypeXmlRefAddr();
            xmlRef.setAddrType(refAddr.getType());
            AnyXmlType anyXml = mJaxbFactory.createAnyXmlType();
            anyXml.getAny().add(refAddr.getContent());
            xmlRef.setContents(anyXml);
            addrList.getStringRefAddrOrXmlRefAddrOrSecureRefAddr().add(xmlRef);
         }
         else if (refAddr instanceof SecureRefAddr)
         {
            SecureRefAddr secref = (SecureRefAddr) refAddr;
            credential.put(secref.getName(),  secref.getValue());

            SecureRefAddrType secRefType = mJaxbFactory.createRefAddressListTypeSecureRefAddr();
            secRefType.setAddrType(refAddr.getType());
            addrList.getStringRefAddrOrXmlRefAddrOrSecureRefAddr().add(secRefType);
         }

      }

      if (credential.size() > 0 )
      {
         aRef.setCredentialStoreKey(addCredential(id, credential));
      }

      aRef.setRefAddresses(addrList);
      return aRef;
   }


   private ObjectFactory getJndiObjectFactory(ReferenceFactoryType facType) throws Exception
   {
      String factoryClassName = facType.getClassName();
      Class factoryClass = Class.forName(factoryClassName, true,  
                                         Thread.currentThread().getContextClassLoader());
      Object factory = factoryClass.newInstance();
      Properties props = null;
      Iterator iter = facType.getProperty().iterator();
      while (iter.hasNext())
      {
         if (props == null)
         {
            props = new Properties();
         }
         PropertyType prop = (PropertyType)iter.next();
         props.setProperty(prop.getName(), prop.getValue());
      }

      if (props != null)
      {
         try
         {
            Method m = factory.getClass().getMethod("setProperties", 
                                                    new Class[] {Properties.class});
            m.invoke(factory, new Object[]{props});

         }
         catch (NoSuchMethodException ex)
         {
            // Ignore
         }
      }
      return(ObjectFactory)factory;
   }

   private String addCredential(String id, Credential cred)
   {
      //String key = id.replace('/',  '_');
      if(mNewCredentials == null)
      {
         mNewCredentials = new HashMap(10);
      }
      mNewCredentials.put(id, cred);
      if(mDeletedCredentials != null)
      {
         mDeletedCredentials.remove(id);
      }
      return id;
   }

   private void removeCredential(String id)
   {
      Object credential = null;
      if(mNewCredentials != null)
      {
         credential = mNewCredentials.remove(id);
      }
      if(credential == null)
      {
         if(mDeletedCredentials == null)
         {
            mDeletedCredentials = new HashMap(10);
         }
         mDeletedCredentials.put(id, credential);
      }
   }

   private Credential loadCredentials(String credKey) throws Exception
   {
       if (storage == null)
         storage = new CredentialStoreHelper();
      String principal = (String)mEnv.get(Context.SECURITY_PRINCIPAL);
      return storage.fetchCredential(principal, credKey);
   }

   private DocumentFragment createDocumentFragment(Node node) throws DOMException
   {
//     synchronized(syncLock) 
//      {
         DocumentFragment doc = node.getOwnerDocument().createDocumentFragment();   
         doc.appendChild(node.cloneNode(true));
         return doc;
//      }
   }

   private void throwNamingException(Exception ex) throws NamingException
   {
      NamingException ne = new NamingException();
      ne.setRootCause(ex);
      throw ne;
   }

}
