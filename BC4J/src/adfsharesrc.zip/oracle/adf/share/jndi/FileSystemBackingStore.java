package oracle.adf.share.jndi;

import java.util.Hashtable;

import org.w3c.dom.Document;

import java.io.*;
import java.net.URL;
import java.net.URI;

import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;

import oracle.xml.parser.v2.*;


public class FileSystemBackingStore extends DocumentBackingStore 
{
//   private Map writerMap = new HashMap();
   
    public void initialize(Hashtable contextEnv, String url) throws Exception
    {
       super.initialize(contextEnv, url);
    }

   public Document readDocument(String url) throws Exception
   {
      File file = getFile(url); 
      if(file.exists())
      {
      BufferedInputStream in = null;
      FileInputStream fis = null;
      try {
          DOMParser parser = new DOMParser();
          fis = new FileInputStream(file); 
          in
          = new BufferedInputStream(fis);
          parser.parse(in);
          return parser.getDocument();
        }finally 
        {
          if (fis !=null) 
            fis.close();
          if (in != null)
            in.close();
          }
      }
      return null;
    
   }
   public void writeDocument(Document doc, String url) throws Exception
   {
     ((XMLDocument)doc).setEncoding("UTF-8");

     BufferedOutputStream bos = null;
     OutputStream out = null;
     try
     {
       out = new FileOutputStream(getFile(url));
       bos = new BufferedOutputStream( out );
       ((XMLDocument)doc).print(bos, "UTF-8");       
     }
     finally
     {
       if ( bos != null ) try { bos.close(); } catch ( Exception e ) { e.printStackTrace(); }
       else if ( out != null ) try { out.close(); } catch ( Exception e ) { e.printStackTrace(); }
     }

             
   }
   
//   public Writer getDocumentWriter(String url) throws Exception
//   {
//     Writer writer
//        = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(getFile(url)), "UTF-8"));
//      writerMap.put(url, writer);
//      return writer;
//   }

//   public boolean  closeDocument(String url) {
//       boolean retval = true;
//       Writer writer = null;
//       try
//       {
//           writer = (Writer)writerMap.get(url); 
//           writer.flush();
//           writer.close();
//       }
//       catch (Exception ex)
//       {
//          retval = false;
//       }
//
//       return retval;
//   }
   
   public boolean isReadOnly()
   {
      return false;
   }

   public Document createDocument(String url) throws Exception
   {
       return new XMLDocument();
   }

   public boolean documentExists(String url) throws Exception
   {
      return getFile(url).exists();
   }

   private File getFile(String url) throws Exception
   {
      if(url.startsWith("file:"))
      {
        return new File(new URI(url));
      }
      else
      {
        return new File(url);
      }
   }
}
