package oracle.adf.share.jndi;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;



public class InitialContextFactoryImpl implements InitialContextFactory
{
   public Context getInitialContext(Hashtable env) throws NamingException
   {
      return new ContextImpl(env);
   }
}
