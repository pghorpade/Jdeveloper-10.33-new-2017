package oracle.adf.share.jndi;

import javax.naming.Context;
import javax.naming.NamingException;


public interface AdfJndiContext extends Context
{
   public void reload() throws NamingException;
   public void saveAs(String url) throws NamingException;
   public void save() throws NamingException;
}
