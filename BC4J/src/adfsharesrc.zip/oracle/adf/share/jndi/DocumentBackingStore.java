package oracle.adf.share.jndi;

import java.io.Writer;
import java.util.Hashtable;
import org.w3c.dom.Document;

public abstract class DocumentBackingStore
{
   public DocumentBackingStore()
   {

   }
   public void initialize(Hashtable contextEnv, String url) throws Exception
   {

   }
   abstract public boolean documentExists(String url) throws Exception;
   abstract public Document readDocument(String url) throws Exception;
   abstract public Document createDocument(String url) throws Exception;
   abstract public void writeDocument(Document doc, String url) throws Exception;
   /** 
    * This method should be overwritten by Writable backing store, so that they
    * close and flush the resources used. The default method is a no-op.
    */
   public boolean  closeDocument(String url) {
       return true; 
   }
   
   abstract public boolean isReadOnly();
   
}
