package oracle.adf.share.jndi;

import java.util.Properties;

import javax.naming.CompoundName;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingException;

class NameParserImpl implements NameParser
{
   final private Properties mNameProps = new Properties();
   final private static NameParserImpl mInstance = new NameParserImpl();

   private NameParserImpl()
   {
      mNameProps.put("jndi.syntax.direction", "flat"); 
      mNameProps.put("jndi.syntax.separator ", "/"); 
   }

   static NameParserImpl getInstance()
   {
      return mInstance;
   }


   public Name parse(String name) throws NamingException
   {
      return createCompoundName(name);
   }

   CompoundName createCompoundName(String name) throws NamingException
   {
      return new CompoundName(name, mNameProps);   
   }
}
