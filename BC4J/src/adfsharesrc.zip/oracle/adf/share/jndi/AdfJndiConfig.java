package oracle.adf.share.jndi;

import java.util.Map;
import org.w3c.dom.Element;
import javax.naming.Context;
import oracle.adf.share.config.ADFConfigCallback;
import oracle.adf.share.config.ADFConfigParsingContext;
import org.w3c.dom.NodeList;
import java.util.Hashtable;

/* $Header: AdfJndiConfig.java 26-nov-2006.18:01:43 nvarma Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    This class provides the JNDI Context environment for ADF. It implements the
    ADFConfigCallback interface

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    nvarma      11/06/06 - 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051024 from 
                           main 
    nvarma      09/20/05 - 
    nvarma      08/15/05 - nvarma_adfconfig_support_multiple_level
    nvarma      08/08/05 - Creation
 */


/**
 *  @version $Header: AdfJndiConfig.java 26-nov-2006.18:01:43 nvarma Exp $
 *  @author  nvarma  
 *  @since   10.1.3
 */

public class AdfJndiConfig implements ADFConfigCallback 
{
  public final static String namespaceURI="http://xmlns.oracle.com/adf/jndi/config";
  
  public AdfJndiConfig()
  {
    
  }
  
  /**
  * 
  * @param el The dom element currently being parsed.
  * @param storedResult The cached parsed results thus far for the registered 
  * namespace
  * @param currentCtx the current context available at the time of parsing. 
  * This can store useful information like the file identifier, ServletContext. 
  * This can also be used to store information that may need to be added in 
  * future.
  * @return component returns the Map, which will be cached for that component 
  * and this will be the new storedResult
  */
  public java.util.Map parseADFConfiguration(Element el,
                                            Map storedResult, 
                                            ADFConfigParsingContext currentCtx)
  {
    
    if (storedResult != null)
      return storedResult; // should not happen, if it does just reuse the results
                           // from the first parsing.
                            
    NodeList nl = el.getElementsByTagNameNS(namespaceURI, "ConnectionsJndiContext");
    if(nl.getLength() <= 0)
    {
     return null;
    }
    Map mContextEnv = new Hashtable(4);
    Element elem = (Element)nl.item(0);

    String facClass = elem.getAttribute("initialContextFactoryClass");
    String backingStoreClass = elem.getAttribute("backingStoreClass");
    String backingStoreURL = elem.getAttribute("backingStoreURL");

    NodeList nl1 = elem.getElementsByTagNameNS(namespaceURI, "contextEnv");
    if(nl1.getLength() > 0)
    {
        Element elem1 = (Element)nl1.item(0);
        mContextEnv.put(elem1.getAttribute( "name"), 
                       elem1.getAttribute("value"));
    }

    mContextEnv.put(Context.INITIAL_CONTEXT_FACTORY,  facClass);
    mContextEnv.put(ProviderProperties.DOCUMENT_STORE, backingStoreClass); 
    mContextEnv.put(Context.PROVIDER_URL, backingStoreURL);
    return mContextEnv;
                               
  }
  
}
