package oracle.adf.share.el;


/* $Header: ADFContextVariableResolverImpl.java 14-sep-2005.08:31:24 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/14/05 - 
    jsmiljan    08/15/05 - 
    jsmiljan    08/12/05 - 
    jsmiljan    07/19/05 - 
    jsmiljan    07/13/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/22/05 - Creation
 */

import oracle.adf.share.ADFContext;

import javax.servlet.jsp.el.VariableResolver;
import javax.servlet.jsp.el.ELException;

/**
 *  A variable resolver that may be used against the ADFContext.  This 
 *  variable resolver may be used when other variable resolvers like the
 *  FacesContext variable resolver and the PageContext variable resolver are
 *  not available.
 *  <p>
 *  This variable resolver should not be seen as a replacement for the
 *  JSP/JSF variable resolvers.  Those variable resolvers should be used
 *  whenever they are available in the container.
 *  <p>
 *  The ADFContextVariableResolverImpl does define an extended implicit
 * object set for ADF.  The following ADF implicit objects are supported:
 * <p>
 * <tt>securityContext</tt> -- Resolves to the current {@link oracle.adf.share.security.SecurityContext}.
 *    Equivalent to invoking:
 *       <tt> ADFContext.getCurrent().getSecurityContext()</tt>
 *    
 * <p>
 * If you wish to use the ADF variable resolver with one of the JSP or
 * JSF variable resolvers then you may pass the JSP/JSF variable resolver
 * instantiate one of the resolvers that decorate this resolver.
 *
 *  @version $Header: ADFContextVariableResolverImpl.java 14-sep-2005.08:31:24 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class ADFContextVariableResolverImpl implements VariableResolver
{

   public ADFContextVariableResolverImpl()
   {
   }

   public Object resolveVariable(String name) throws ELException
   {
      return resolveVariable(null, name);
   }

   public Object resolveVariable(Object ctx, String name)
   {
      ADFContext adfContext = ADFContext.getCurrent();

      // ADF EXTENSIONS
      if ("securityContext".equals(name))
      {
         return adfContext.getSecurityContext();
      }

      return null;
   }


}
