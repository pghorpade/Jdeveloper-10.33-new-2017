package oracle.adf.share.el;

/* $Header: OracleExpressionEvaluatorImpl.java 10-nov-2005.10:06:09 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    11/10/05 - XbranchMerge jsmiljan_fix_kava_103105 from main 
    jsmiljan    09/28/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/17/05 - Creation
 */

import oracle.jsp.el.OracleExpression;
import oracle.jsp.el.OracleExpressionEvaluator;

import javax.servlet.jsp.el.VariableResolver;
import javax.servlet.jsp.el.ELException;

import oracle.adf.share.ADFContext;

/**
 *  @version $Header: OracleExpressionEvaluatorImpl.java 10-nov-2005.10:06:09 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class OracleExpressionEvaluatorImpl implements ADFExpressionEvaluator 
{
   private OracleExpressionEvaluator mEvaluator;

   public Object evaluate(String expression)
   {
      return evaluate(expression, getVariableResolver());
   }

   public Object evaluate(String expression, VariableResolver variableResolver)
   {
      return evaluateInternal(expression, variableResolver);
   }

   public void setValue(String expression, Object value)
   {
      setValue(expression, value, getVariableResolver());
   }

   public void setValue(String expression, Object value, VariableResolver variableResolver)
   {
      throw new UnsupportedOperationException();
   }

   public VariableResolver getVariableResolver()
   {
      return ADFContext.getCurrent().getVariableResolver();
   }

   private Object evaluateInternal(String expression, VariableResolver variableResolver)
   {
      if (mEvaluator == null) 
      {
         init();
      }

      try
      {
         OracleExpression expr = (OracleExpression)
            mEvaluator.parseExpression(expression, Object.class, null);

         return expr.evaluate(variableResolver);
      }
      catch(ELException e)
      {
         throw new RuntimeException(e);
      }
   }

   private synchronized void init()
   {
      if (mEvaluator == null) 
      {
         mEvaluator = new OracleExpressionEvaluator();
      }
   }
}
