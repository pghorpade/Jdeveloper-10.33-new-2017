package oracle.adf.share.el;

import oracle.adf.share.ADFContext;
import java.util.Map;
import java.util.HashMap;

import javax.servlet.jsp.el.VariableResolver;

public interface ADFExpressionEvaluator
{
   /**
    * Evaluates the specified value expression against the evaluator's default variable
    * resolver.
    * <p>
    * invokeMethod(String, Object[]) should be used if the expression
    * is a method expression.
    */
   public Object evaluate(String expression);

   /**
    * Evaluates the specified value expression against the specified variable resolver.
    * <p>
    * invokeMethod(String, Class[], Object[]) should be used if the expression
    * is a method expression.
    */
   public Object evaluate(String expression, VariableResolver variableResolver);

   /**
    * Sets the value of the specified expression.  The expression resolve to a JavaBean
    * property.
    */
   public void setValue(String expression, Object value);

   /**
    * Sets the value of the specified expression.  The expression resolve to a JavaBean
    * property.
    */
   public void setValue(String expression, Object value, VariableResolver variableResolver);

   /**
    * Get the default variable resolver to be used while resolving expressions with
    * this evaluator.
    */
   public VariableResolver getVariableResolver();
}
