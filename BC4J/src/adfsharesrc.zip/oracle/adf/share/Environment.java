package oracle.adf.share;

import java.util.Locale;

import java.io.IOException;

import java.util.Map;

// This is the Faces javadoc
/**
 * <p>Managed an anonymous environment consisting of a request, a response and
 * a context.</p>
 *
 * <p>This class allows the Faces API to be unaware of the nature of its
 * containing application environment.  In particular, this class allows
 * JavaServer Faces based appications to run in either a Servlet or a Portlet
 * environment.</p>
 *
 * <p>In the method descriptions below, paragraphs starting with
 * <em>Servlet:</em> and <em>Portlet:</em> denote behavior that is
 * specific to that particular environment.</p>
 */
public abstract class Environment
{
  // This is the Faces javadoc
  /**
   * <p>Return the environment-specific object instance for the current
   * request.</p>
   *
   * <p><em>Servlet:</em>  This must be the current request's
   * <code>javax.servlet.http.HttpServletRequest</code> instance.</p>
   *
   * <p><em>Portlet:</em>  This must be the current request's
   * <code>javax.portlet.PortletRequest</code> instance, which
   * will be either an <code>ActionRequest</code> or a
   * <code>RenderRequest</code> depending upon when this method
   * is called.</p>
   */
   abstract public Object getRequest();

  // This is the Faces javadoc
  /**
   * <p>Return the environment-specific object instance for the current
   * response.</p>
   *
   * <p><em>Servlet:</em>  This is the current request's
   * <code>javax.servlet.http.HttpServletResponse</code> instance.</p>
   *
   * <p><em>Portlet:</em>  This is the current request's
   * <code>javax.portlet.PortletResponse</code> instance, which
   * will be either an <code>ActionResponse</code> or a
   * <code>RenderResponse</code> depending upon when this method
   * is called.</p>
   */
   abstract public Object getResponse();

  // This is the Faces javadoc
  /**
   * <p>Return the application environment object instance for the current
   * appication.</p>
   *
   * <p><em>Servlet:</em>  This must be the current application's
   * <code>javax.servlet.ServletContext</code> instance.</p>
   *
   * <p><em>Portlet:</em>  This must be the current application's
   * <code>javax.portlet.PortletContext</code> instance.</p>
   */
   abstract public Object getContext();

    // faces javadoc
    /**
     * <p>Return the preferred <code>Locale</code> in which the client
     * will accept content.</p>
     *
     * <p><em>Servlet:</em> This must be the value returned by the
     * <code>javax.servlet.ServletRequest</code> method
     * <code>getLocale()</code>.</p>
     *
     * <p><em>Portlet:</em> This must be the value returned by the
     * <code>javax.portlet.PortletRequest</code> method
     * <code>getLocale()</code>.</p>
     */
   abstract public Locale getRequestLocale();

   // faces javadoc
    /**
     * <p>Return the servlet path information (if any) included in the
     * request URI; otherwise, return <code>null</code>.</p>
     *
     * <p><em>Servlet:</em> This must be the value returned by the
     * <code>javax.servlet.http.HttpServletRequest</code> method
     * <code>getServletPath()</code>.</p>
     *
     * <p><em>Portlet:</em> This must be <code>null</code>.</p>
     */
   abstract public String getRequestServletPath();

   // faces javadoc
    /**
     * <p>Return the extra path information (if any) included in the
     * request URI; otherwise, return <code>null</code>.</p>
     *
     * <p><em>Servlet:</em> This must be the value returned by the
     * <code>javax.servlet.http.HttpServletRequest</code> method
     * <code>getPathInfo()</code>.</p>
     *
     * <p><em>Portlet:</em> This must be <code>null</code>.</p>
     */
   abstract public String getRequestPathInfo();

   // faces javadoc
    /**
     * <p>Return the input URL, after performing any rewriting needed to
     * ensure that it will correctly identify an addressable resource in the
     * current application.<p>
     *
     * <p><em>Servlet:</em> This must be the value returned by the
     * <code>javax.servlet.http.HttpServletResponse</code> method
     * <code>encodeURL(url)</code>.</p>
     *
     * <p><em>Portlet:</em> This must be the value returned by the
     * <code>javax.portlet.PortletResponse</code> method
     * <code>encodeURL(url)</code>.</p>
     *
     * @param url The input URL to be encoded
     *
     * @exception NullPointerException if <code>url</code>
     *  is <code>null</code>
     */
   abstract public String encodeResourceURL(String url);

   // faces javadoc
   /**
     * <p>Redirect a request to the specified URL, and cause the
     * <code>responseComplete()</code> method to be called on the
     * {@link FacesContext} instance for the current request.</p>
     *
     * <p><em>Servlet:</em> This must be accomplished by calling the
     * <code>javax.servlet.http.HttpServletResponse</code> method
     * <code>sendRedirect()</code>.</p>
     *
     * <p><em>Portlet:</em> This must be accomplished by calling the
     * <code>javax.portlet.ActionResponse</code> method
     * <code>sendRedirect()</code>.</p>
     *
     * @param url Absolute URL to which the client should be redirected
     *
     * @exception IllegalArgumentException if the specified url is relative
     * @exception IllegalStateException if, in a portlet environment,
     *  the current response object is a <code>RenderResponse</code>
     *  instead of an <code>ActionResponse</code>
     * @exception IllegalStateException if, in a servlet environment,
     *  the current response has already been committed
     * @exception IOException if an input/output error occurs
     */
   abstract public void redirect(String url) throws IOException;

   // faces javadoc
   /**
    * <p>Dispatch a request to the specified resource to create output
    * for this response.</p>
    *
    * <p><em>Servlet:</em> This must be accomplished by calling the
    * <code>javax.servlet.ServletContext</code> method
    * <code>getRequestDispatcher(path)</code>, and calling the
    * <code>forward()</code> method on the resulting object.</p>
    *
    * <p><em>Portlet:</em> This must be accomplished by calling the
    * <code>javax.portlet.PortletContext</code> method
    * <code>getRequestDispatcher()</code>, and calling the
    * <code>include()</code> method on the resulting object.</p>
    *
    * @param path Context relative path to the specified resource,
    *  which must start with a slash ("/") character
    *
    * @exception FacesException thrown if a <code>ServletException</code>
    *  or <code>PortletException</code> occurs
    * @exception IllegalArgumentException if no request dispatcher
    *  can be created for the specified path
    * @exception IllegalStateException if this method is called in a portlet
    *  environment, and the current request is an <code>ActionRequest</code>
    *  instead of a <code>RenderRequest</code>
    * @exception IOException if an input/output error occurs
    * @exception NullPointerException if <code>path</code>
    *  is <code>null</code>
    */
   abstract public void dispatch(String path)
      throws IOException;

   // faces javadoc
   /**
     * <p>Return the portion of the request URI that identifies the web
     * application context for this request.</p>
     *
     * <p><em>Servlet:</em> This must be the value returned by the
     * <code>javax.servlet.http.HttpServletRequest</code> method
     * <code>getContextPath()</code>.</p>
     *
     * <p><em>Portlet:</em> This must be the value returned by the
     * <code>javax.portlet.PortletRequest</code> method
     * <code>getContextPath()</code>.</p>
     */
   abstract public String getRequestContextPath();

   abstract public String getRequestURI();

   abstract public String getRequestCharacterEncoding();

   abstract public void setRequestCharacterEncoding(String encoding) throws IOException;
   
   abstract public Map getRequestParameterMap();
}
