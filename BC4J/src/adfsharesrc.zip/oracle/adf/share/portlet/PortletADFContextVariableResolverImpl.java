package oracle.adf.share.portlet;


/* $Header: PortletADFContextVariableResolverImpl.java 19-jun-2006.15:00:43 jsmiljan Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/13/05 - 
    jsmiljan    08/12/05 - jsmiljan_bug-3688418
    jsmiljan    07/19/05 - 
    jsmiljan    07/13/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/22/05 - Creation
 */
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.PortletContext;
import javax.portlet.PortletSession;

import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Set;
import java.util.Collection;

import oracle.adf.share.ADFContext;

import oracle.adf.share.el.ADFContextVariableResolverImpl;

import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.VariableResolver;

/**
 *  A variable resolver that may be used against the ADFContext.  This 
 *  variable resolver may be used when other variable resolvers like the
 *  FacesContext variable resolver and the PageContext variable resolver are
 *  not available.
 *  <p>
 *  This variable resolver should not be seen as a replacement for the
 *  JSP/JSF variable resolvers.  Those variable resolvers should be used
 *  whenever they are available in the container.
 *  <p>
 *  This variable resolver attempts to support many of the implicit objects
 *  that are defined for both the JSP variable resolver and the Faces
 *  resolver.  The following standard implicit objects are supported:
 *  <p>
 *  <tt>requestScope</tt>
 *  <tt>sessionScope</tt>
 *  <tt>applicationScope</tt>
 *  <tt>param</tt>
 *  <tt>paramValues</tt>
 *  <tt>header</tt>
 *  <tt>initParam</tt>
 *  <tt>cookie</tt>
 *  <p>
 *  Please see the JSP/JSF specifications for more information about
 *  each of these implicit objects.
 *  <p>
 *  The PortletADFContextVariableResolverImpl does define an extended implicit
 * object set for ADF.  The following ADF implicit objects are supported:
 * <p>
 * <tt>securityContext</tt> -- Resolves to the current {@link oracle.adf.share.security.SecurityContext}.
 *    Equivalent to invoking:
 *       <tt> ADFContext.getCurrent().getSecurityContext()</tt>
 *    
 * <p>
 * If you wish to use the ADF variable resolver with one of the JSP or
 * JSF variable resolvers then you may pass the JSP/JSF variable resolver
 * to the PortletADFContextVariableResovler constructor.  This will cause the
 * JSP/JSF variable resolver to be decorated by the ADF variable resolver.
 * You may then pass the ADF variable resolver to the JSP/JSF expression
 * evaluator.
 *
 *  @version $Header: PortletADFContextVariableResolverImpl.java 19-jun-2006.15:00:43 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class PortletADFContextVariableResolverImpl implements VariableResolver
{
   static final String PORTLET_REQUEST_SCOPE = "__portlet_request_scope__";
   static final String PORTLET_SESSION_SCOPE = "__portlet_session_scope__";
   static final String PORTLET_APPLICATION_SCOPE = "__portlet_application_scope__";
   static final String PORTLET_PARAM_MAP = "__portlet_param_map__";
   static final String PORTLET_PARAM_VALUES_MAP = "__portlet_param_values_map__";
   static final String PORTLET_HEADER_MAP = "__portlet_header_map__";
   static final String PORTLET_HEADER_VALUES_MAP = "__portlet_header_values_map__";
   static final String PORTLET_INIT_PARAM_MAP = "__portlet_init_param_map__";
   static final String PORTLET_COOKIE_MAP = "__portlet_cookie_map__";

   private final Hashtable mMapCache = new Hashtable(10);

   private final VariableResolver mParentResolver;

   private boolean mResolveImplicit = true;

   public PortletADFContextVariableResolverImpl(VariableResolver parentResolver)
   {
      if (parentResolver == null)
         parentResolver = new ADFContextVariableResolverImpl();

      mParentResolver = parentResolver;
   }

   public Object resolveVariable(String name) throws ELException
   {
      ADFContext adfContext = ADFContext.getCurrent();

      if (isResolveImplicit())
      {
         // STANDARD IMPLICIT OBJECTS
         // Check for implicit objects
         if ("pageScope".equals (name))
         {
            throw new UnsupportedOperationException("pageScope");
         }
         else if ("requestScope".equals (name))
         {
            return getPortletRequestScope(
               (PortletRequest)adfContext.getEnvironment().getRequest());
         }
         else if ("sessionScope".equals (name))
         {
            return getPortletSessionScope(
               ((PortletRequest)adfContext.getEnvironment().getRequest())
                  .getPortletSession(true));
         }
         else if ("applicationScope".equals (name))
         {
            return getPortletApplicationScope(
               (PortletContext)adfContext.getEnvironment().getContext());
         }
         else if ("param".equals (name))
         {
            return getPortletParamMap((
               PortletRequest)adfContext.getEnvironment().getRequest());
         }
         else if ("paramValues".equals (name))
         {
            return getPortletParamValuesMap(
               (PortletRequest)adfContext.getEnvironment().getRequest());
         }
         else if ("header".equals (name))
         {
//            Object request = adfContext.getEnvironment().getRequest();
//            if (request instanceof PortletRequest)
//            {
//               return getPortletHeaderMap((PortletRequest)request);
//            }

            throw new UnsupportedOperationException("header");
         }
         else if ("initParam".equals (name))
         {
            return getPortletInitParamMap(
               (PortletContext)adfContext.getEnvironment().getContext());
         }
         else if ("cookie".equals (name))
         {
//            Object request = adfContext.getEnvironment().getRequest();
//            if (request instanceof PortletRequest)
//            {
//               return getPortletCookieMap((PortletRequest)request);
//            }

            throw new UnsupportedOperationException("cookie");
         }
      }

      Object rtn = mParentResolver.resolveVariable(name);
      if (rtn != null) return rtn;

      // now start the check in the default scopes, request, session
      // and application.
      if (isResolveImplicit())
      {
         PortletRequest request = 
            (PortletRequest)adfContext.getEnvironment().getRequest();

         rtn = request.getAttribute(name);
         if (rtn != null) return rtn;

         PortletSession session = request.getPortletSession(false);
         rtn = session != null ? session.getAttribute(name) : null;
         if (rtn != null) return rtn;

         rtn = ((PortletContext)adfContext.getEnvironment().getContext())
            .getAttribute(name);
         if (rtn != null) return rtn;
      }

      return null;
   }

   public void setResolveImplicit(boolean resolveImplicit)
   {
      mResolveImplicit = resolveImplicit;
   }

   /**
    * When false the resolver will not attempt implicit object
    * resolution.
    */
   public boolean isResolveImplicit()
   {
      return mResolveImplicit;
   }
   private Object getPortletRequestScope(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_REQUEST_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_REQUEST_SCOPE, map);
      }
      return map;
   }

   private Object getPortletSessionScope(final PortletSession session)
   {
      Map map = (Map)mMapCache.get(PORTLET_SESSION_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return session.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_SESSION_SCOPE, map);
      }
      return map;
   }

   private Object getPortletApplicationScope(final PortletContext context)
   {
      Map map = (Map)mMapCache.get(PORTLET_APPLICATION_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return context.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_APPLICATION_SCOPE, map);
      }
      return map;
   }

   private Object getPortletParamMap(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_PARAM_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getParameter((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_PARAM_MAP, map);
      }
      return map;
   }

   private Object getPortletParamValuesMap(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_PARAM_VALUES_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getParameterValues((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_PARAM_VALUES_MAP, map);
      }
      return map;
   }

   private Object getPortletHeaderMap(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_HEADER_MAP);
//      if (map == null)
//      {
//         map = new ImplicitObjectMapAdapter()
//         {
//            public Object get(Object key)
//            {
//               if (key instanceof String)
//               {
//                  return request.getHeader((String)key);
//               }
//               return null;
//            }
//         };
//         mMapCache.put(PORTLET_HEADER_MAP, map);
//      }
      return map;
   }
/*
   private Object getPortletHeaderValuesMap(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_HEADER_VALUES_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getAttribute((String)key);
               }
               return null;
            }
         }
         mMapCache.put(PORTLET_HEADER_VALUES_MAP, map);
      }
      return map;
   }
*/

   private Object getPortletInitParamMap(final PortletContext context)
   {
      Map map = (Map)mMapCache.get(PORTLET_INIT_PARAM_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return context.getInitParameter((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_INIT_PARAM_MAP, map);
      }
      return map;
   }

   private Object getPortletCookieMap(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_COOKIE_MAP);
//      if (map == null)
//      {
//         Cookie[] cookies = request.getCookies();
//         map = new HashMap(cookies.length);
//         for (int i=0; i < cookies.length; i++)
//         {
//            map.put(cookies[i].getName(), cookies[i]);
//         }
//         mMapCache.put(PORTLET_COOKIE_MAP, map);
//      };
      return map;
   }


   abstract class ImplicitObjectMapAdapter implements Map
   {
      public int size()
      {
         return -1;
      }

      public boolean isEmpty()
      {
         return false;
      }

      public boolean containsKey(Object key)
      {
         return get(key) != null;
      }

      public boolean containsValue(Object value)
      {
         return false;
      }

      abstract public Object get(Object key);

      public Object put(Object key, Object value)
      {
         return null;
      }

      public Object remove(Object key)
      {
         return null;
      }

      public void putAll(Map t)
      {
      }

      public void clear()
      {
      }

      public Set keySet()
      {
         return null;
      }

      public Collection values()
      {
         return null;
      }

      public Set entrySet()
      {
         return null;
      }
   }
}
