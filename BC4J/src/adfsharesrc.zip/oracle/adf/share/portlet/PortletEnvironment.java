package oracle.adf.share.portlet;

import java.io.IOException;

import java.util.Locale;

import java.util.Map;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.PortletContext;

import oracle.adf.share.Environment;

public class PortletEnvironment extends Environment
{
   private final PortletContext mPortletContext;
   private final PortletRequest mRequest;
   private final PortletResponse mResponse;
   
   public PortletEnvironment(PortletContext portletContext,
                             PortletRequest request,
                             PortletResponse response)
   {
      mPortletContext = portletContext;
      mRequest = request;
      mResponse = response;
   }
           
   public Object getRequest()
   {
      return mRequest;
   }
   
   public Object getResponse()
   {
      return mResponse;
   }

   public Object getContext()
   {
      return mPortletContext;
   }

   public Locale getRequestLocale()
   {
      return mRequest.getLocale();
   }

   public String getRequestServletPath()
   {
      return null;
   }

   public String getRequestPathInfo()
   {
      return null;
   }

   public String encodeResourceURL(String url)
   {
      return mResponse.encodeURL(url);
   }

   public void redirect(String url)
      throws IOException
   {
      throw new RuntimeException("Operation not supported");
   }

   public String getRequestContextPath()
   {
      return mRequest.getContextPath();
   }

   public String getRequestURI()
   {
      throw new RuntimeException("Operation not supported");
   }

   public String getRequestCharacterEncoding()
   {
      return null;
   }

   public void setRequestCharacterEncoding(String encoding) throws IOException
   {
   }
   
   // We may need to return an immutable map like Faces does. For now
   // it returns the real thing.
   public Map getRequestParameterMap()
   {
      return mRequest.getParameterMap();
   }
   
   public void dispatch(String requestURI)
      throws IOException
   {
      throw new RuntimeException("Operation not supported");
      /*
      RequestDispatcher rd = mRequest.getRequestDispatcher(requestURI);

      if (rd == null)
      {
         mResponse.sendError(
             HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
             "No request dispatcher for " + requestURI);
         return;
      }

      try
      {
         rd.forward(mRequest, mResponse);
      }
      catch (IOException ioe)
      {
         throw ioe;
      }
      */
   }
}
