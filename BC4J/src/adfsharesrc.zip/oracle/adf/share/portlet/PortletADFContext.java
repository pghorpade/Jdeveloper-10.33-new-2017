package oracle.adf.share.portlet;

import java.security.Principal;

import java.util.Map;
import java.util.Hashtable;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Collection;
import java.util.Enumeration;

import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.IOException;
import java.io.Externalizable;

import javax.naming.Context;

import javax.portlet.PortletContext;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.PortletSession;

import javax.servlet.jsp.el.VariableResolver;

import oracle.adf.share.ADFContext;
import oracle.adf.share.ADFConfig;
import oracle.adf.share.ADFScope;
import oracle.adf.share.ADFScopeHelper;
import oracle.adf.share.ADFScopeListener;
import oracle.adf.share.Environment;

import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.config.ADFConfigFactory;

import java.lang.reflect.Method;

import java.util.Iterator;

public class PortletADFContext extends ADFContext
{
   private Environment env;
   private ADFConfig application;

   private static final String PORTLET_CONTEXT_APPLICATION_SCOPE_KEY =
   "__adf_application_scope__";

   private static final String HTTP_SESSION_SCOPE_KEY = "__adf_session_scope__";

   PortletADFContext()
   {
   }

   PortletADFContext(SecurityContext securityContext,
                     Environment env)
   {
      this();

      setSecurityContext(securityContext);
      setEnvironment(env);
   }

   /**
    *  Gets the ADF configuration Object used by current 
    *  thread.
    */
   public ADFConfig getADFConfig()
   {
      Environment env = getEnvironment();
      if (application == null)
      {
         if (env!= null && env.getContext()!= null )
         {
            application = ADFConfigFactory.findOrCreateADFConfig(
               env.getContext()
               , ADFConfig.ADFCONFIG_WAR_FILENAME);
         }
         else
         {
            application = ADFConfigFactory.findOrCreateADFConfig();         
         }
      }
      return application;
   }

   public Map createScope(String name)
   {
      Map scope = null;
      if (SESSION_SCOPE.equals(name))
      {
         PortletRequest request = getPortletRequest();
         if (request != null)
         {
            PortletSession session = getPortletRequest().getPortletSession(true);
            scope = (Map)session.getAttribute(HTTP_SESSION_SCOPE_KEY);

            if (scope == null
                || !scope.containsKey(PortletSessionScopeAdapter.VALID))
            {
               synchronized(session)
               {
                  // DCL
                  scope = (Map)session.getAttribute(HTTP_SESSION_SCOPE_KEY);

                  if (scope == null
                      || !scope.containsKey(PortletSessionScopeAdapter.VALID))
                  {
                     scope = new PortletSessionScopeAdapter(
                        SESSION_SCOPE, session);

                     session.setAttribute(HTTP_SESSION_SCOPE_KEY, scope);
                  }
               }
            }
         }
         else
         {
            super.createScope(name);
         }
      }
      else
      {
         scope = super.createScope(name);
      }

      return scope;
   }

   protected PortletRequest getPortletRequest()
   {
      return(PortletRequest) env.getRequest();
   }

   protected PortletResponse getPortletResponse()
   {
      return(PortletResponse) env.getResponse();
   }

   protected void setSecurityContext(SecurityContext ctx)
   {
      super.setSecurityContext(ctx);
      setUserPrincipal();
   }

   private void setUserPrincipal()
   {
      Principal p = getUserPrincipal();
      if (p != null)
      {
         try
         {
            SecurityContext secCtx = getSecurityContext();
            secCtx.addToEnvironment(Context.SECURITY_PRINCIPAL, p);
         }
         catch (Exception e)
         {
            e.printStackTrace();
         }
      }
   }

   protected Principal getUserPrincipal()
   {
      return getPortletRequest().getUserPrincipal();
   }

   protected void setEnvironment(Environment env)
   {
      this.env = env;
   }

   protected Environment loadEnvironment()
   {
      return env;
   }

   public boolean hasSession()
   {
      Object request = getEnvironment().getRequest();
      if (request instanceof PortletRequest)
      {
         return ((PortletRequest)request).getPortletSession(false) != null;
      }

      return super.hasSession();
   }

   public int getContextType()
   {
      return TYPE_PORTLET;
   }

   public boolean isHttpContext()
   {
      return false;
   }

   public static void initThreadContext(PortletContext portletContext,
                                        PortletRequest request,
                                        PortletResponse response)
   {
      PortletADFContext threadCtx = new PortletADFContext();
      threadCtx.initialize(portletContext, request, response);
   }

   protected void initialize(PortletContext portletContext
      , PortletRequest request
      , PortletResponse response)
   {
       ADFContext oldContext = ADFContext.getCurrent();
      // This should be initialized only once per request. Use a refCount on 
      // the request to ensure this.
      
      setEnvironment(
         new PortletEnvironment(portletContext, request, response));

      setAsCurrent(); 
      getSecurityContext();

      setVariableResolver(new PortletADFContextVariableResolverImpl(
         oldContext.getVariableResolver()));

      setExpressionEvaluator(oldContext.getExpressionEvaluator());

      if (portletContext != null)
      {
         Map scope = (Map)portletContext.getAttribute(
            PORTLET_CONTEXT_APPLICATION_SCOPE_KEY);

         if (scope == null)
         {
            synchronized(portletContext)
            {
               scope = (Map)portletContext.getAttribute(
                  PORTLET_CONTEXT_APPLICATION_SCOPE_KEY);

               if (scope == null)
               {
                  scope = new PortletContextScopeAdapter(ADFContext.APPLICATION_SCOPE, 
                                                         portletContext);
                  portletContext.setAttribute(
                     PORTLET_CONTEXT_APPLICATION_SCOPE_KEY, scope);
               }
            }
         }
         putScope(ADFContext.APPLICATION_SCOPE, scope);
      }

      // bind the session scope lazily.  declare the name for now.
      putScope(ADFContext.SESSION_SCOPE, null);
      if (request != null)
      {
         PortletRequestScopeAdapter reqAdapter = new 
            PortletRequestScopeAdapter(ADFContext.REQUEST_SCOPE, request);

         putScope(ADFContext.REQUEST_SCOPE, reqAdapter);
      }

   }

   public static void resetThreadContext()
   {
      ADFContext threadCtx = ADFContext.getCurrent();
      ADFScope requestScope = (ADFScope)threadCtx.getRequestScope();
      
      
      if (requestScope != null)
      {
         requestScope.invalidate();

         // JRS Shouldn't the scope do this?  Not implementing for right
         // now because it is too risky
         threadCtx.removeScope(ADFContext.REQUEST_SCOPE);
      }

      threadCtx.removeAsCurrent();
   }

   public boolean hasEnvironment()
   {
      return true;
   }


   class PortletContextScopeAdapter implements ADFScope
   {
      private PortletContext mAdaptee;
      private final ADFScopeHelper mHelper;

      private final String mScopeName;

      public PortletContextScopeAdapter(String scopeName, PortletContext adaptee)
      {
         mScopeName = scopeName;

         mAdaptee = adaptee;
         mHelper = new ADFScopeHelper();
      }

      public int size()
      {
         int size = 0;
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            size++;
         }
         
         return size;
      }

      public void clear()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            mAdaptee.removeAttribute((String)attrNames.nextElement());
         }
      }

      public boolean isEmpty()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            return false;
         }
         return true;
      }

      public boolean containsKey(Object key)
      {
         if (key == null)
         {
            return false;
         }
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (key.equals(attrNames.nextElement()))
            {
               return true;
            }
         }
         
         return false;

      }

      public boolean containsValue(Object value)
      {
         if (value == null)
         {
            return false;
         }
         
         // linear search.  optimize later if this is used heavily.
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (value.equals(mAdaptee.getAttribute((String)attrNames.nextElement())))
            {
               return true;
            }
         }
         
         return false;
      }

      public Collection values()
      {
         ArrayList values = new ArrayList();

         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            values.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }

         return values;
      }

      public void putAll(Map map)
      {
         Iterator keys = map.keySet().iterator();
         while (keys.hasNext())
         {
            Object key = keys.next();
            mAdaptee.setAttribute(key.toString(), map.get(key));
         }
      }

      public Set entrySet()
      {
         HashSet entrySet = new HashSet();
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            entrySet.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }
         
         return entrySet;
      }

      public Set keySet()
      {
         Set keySet = new HashSet();
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            keySet.add(attrNames.nextElement());
         }
         return keySet;
      }

      public Object get(Object key)
      {
         if (key == null) return null;
         
         return mAdaptee.getAttribute(key.toString());
      }

      public Object remove(Object key)
      {
         if (key == null) return null;
         
         Object rtn = get(key);
         mAdaptee.removeAttribute(key.toString());
         
         return rtn;
      }

      public Object put(Object key, Object value)
      {
         if (key == null || value == null) return null;
         
         Object rtn = get(key);
         mAdaptee.setAttribute(key.toString(), value);
         
         return rtn;
      }

      public void invalidate()
      {
         mHelper.fireScopeInvalidated(mScopeName);
         mAdaptee = null;
      }

      public void addScopeListener(ADFScopeListener listener)
      {
         mHelper.addScopeListener(listener);
      }

      public void removeScopeListener(ADFScopeListener listener)
      {
         mHelper.removeScopeListener(listener);
      }
   }

   class PortletRequestScopeAdapter implements ADFScope 
   {
      private PortletRequest mAdaptee;
      private final ADFScopeHelper mHelper;

      private final String mScopeName;

      public PortletRequestScopeAdapter(String scopeName, PortletRequest adaptee)
      {
         mScopeName = scopeName;

         mAdaptee = adaptee;
         mHelper = new ADFScopeHelper();
      }

      public int size()
      {
         int size = 0;
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            size++;
         }
         
         return size;
      }

      public void clear()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            mAdaptee.removeAttribute((String)attrNames.nextElement());
         }
      }

      public boolean isEmpty()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            return false;
         }
         return true;
      }

      public boolean containsKey(Object key)
      {
         if (key == null)
         {
            return false;
         }
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (key.equals(attrNames.nextElement()))
            {
               return true;
            }
         }
         
         return false;

      }

      public boolean containsValue(Object value)
      {
         if (value == null)
         {
            return false;
         }
         
         // linear search.  optimize later if this is used heavily.
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (value.equals(mAdaptee.getAttribute((String)attrNames.nextElement())))
            {
               return true;
            }
         }
         
         return false;
      }

      public Collection values()
      {
         ArrayList values = new ArrayList();

         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            values.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }

         return values;
      }

      public void putAll(Map map)
      {
         Iterator keys = map.keySet().iterator();
         while (keys.hasNext())
         {
            Object key = keys.next();
            mAdaptee.setAttribute(key.toString(), map.get(key));
         }
      }

      public Set entrySet()
      {
         HashSet entrySet = new HashSet();
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            entrySet.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }
         
         return entrySet;
      }

      public Set keySet()
      {
         Set keySet = new HashSet();
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            keySet.add(attrNames.nextElement());
         }
         return keySet;
      }

      public Object get(Object key)
      {
         if (key == null) return null;
         
         return mAdaptee.getAttribute(key.toString());
      }

      public Object remove(Object key)
      {
         if (key == null) return null;
         
         Object rtn = get(key);
         mAdaptee.removeAttribute(key.toString());
         
         return rtn;
      }

      public Object put(Object key, Object value)
      {
         if (key == null || value == null) return null;
         
         Object rtn = get(key);
         mAdaptee.setAttribute(key.toString(), value);
         
         return rtn;
      }

      public void invalidate()
      {
         mHelper.fireScopeInvalidated(mScopeName);

         mAdaptee = null;
      }

      public void addScopeListener(ADFScopeListener listener)
      {
         mHelper.addScopeListener(listener);
      }

      public void removeScopeListener(ADFScopeListener listener)
      {
         mHelper.removeScopeListener(listener);
      }
   }

   class PortletSessionScopeAdapter implements ADFScope, Externalizable
   {
      private transient PortletSession mAdaptee;
      private transient ADFScopeHelper mHelper;

      public static final String VALID = "__valid__";

      private final String mScopeName;

      static final long serialVersionUID = -414166398739154544L;

      public PortletSessionScopeAdapter()
      {
         // must maintain the public no-arg constructor to support the
         // Externalizable interface.
         mScopeName = null;
      }

      public PortletSessionScopeAdapter(String scopeName)
      {
         mScopeName = scopeName;

         mAdaptee = null;
         mHelper = null;
      }

      public PortletSessionScopeAdapter(String scopeName, PortletSession adaptee)
      {
         mScopeName = scopeName;

         mAdaptee = adaptee;
         mHelper = new ADFScopeHelper();
      }

      public int size()
      {
         int size = 0;
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            size++;
         }
         
         return size;
      }

      public void clear()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            mAdaptee.removeAttribute((String)attrNames.nextElement());
         }
      }

      public boolean isEmpty()
      {
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            return false;
         }
         return true;
      }

      public boolean containsKey(Object key)
      {
         if (key == null)
         {
            return false;
         }

         if (VALID.equals(key))
         {
            return (mAdaptee != null);
         }
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (key.equals(attrNames.nextElement()))
            {
               return true;
            }
         }
         
         return false;

      }

      public boolean containsValue(Object value)
      {
         if (value == null)
         {
            return false;
         }
         
         // linear search.  optimize later if this is used heavily.
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            if (value.equals(mAdaptee.getAttribute((String)attrNames.nextElement())))
            {
               return true;
            }
         }
         
         return false;
      }

      public Collection values()
      {
         ArrayList values = new ArrayList();

         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            values.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }

         return values;
      }

      public void putAll(Map map)
      {
         Iterator keys = map.keySet().iterator();
         while (keys.hasNext())
         {
            Object key = keys.next();
            mAdaptee.setAttribute(key.toString(), map.get(key));
         }
      }

      public Set entrySet()
      {
         HashSet entrySet = new HashSet();
         
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            entrySet.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
         }
         
         return entrySet;
      }

      public Set keySet()
      {
         Set keySet = new HashSet();
         Enumeration attrNames = mAdaptee.getAttributeNames();
         while (attrNames.hasMoreElements())
         {
            keySet.add(attrNames.nextElement());
         }
         return keySet;
      }

      public Object get(Object key)
      {
         if (key == null) return null;
         
         return mAdaptee.getAttribute(key.toString());
      }

      public Object remove(Object key)
      {
         if (key == null) return null;
         
         Object rtn = get(key);
         mAdaptee.removeAttribute(key.toString());
         
         return rtn;
      }

      public Object put(Object key, Object value)
      {
         if (key == null || value == null) return null;
         
         Object rtn = get(key);
         mAdaptee.setAttribute(key.toString(), value);
         
         return rtn;
      }

      public void invalidate()
      {
         mHelper.fireScopeInvalidated(mScopeName);
         mAdaptee = null;
      }

      public void addScopeListener(ADFScopeListener listener)
      {
         mHelper.addScopeListener(listener);
      }

      public void removeScopeListener(ADFScopeListener listener)
      {
         mHelper.removeScopeListener(listener);
      }


      public void writeExternal(ObjectOutput out) throws IOException
      {
         // no-op.  don't write anything for this object.  it will be
         // re-created properly whenever we create a new
         // HttpSessionScopeAdapter.
      }

      public void readExternal(ObjectInput in)
         throws IOException, ClassNotFoundException
      {
      }
   }
}
