package oracle.adf.share.security;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.ArrayList;

import javax.naming.Binding;
import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NameClassPair;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NamingException;
import javax.naming.NameNotFoundException;
import javax.naming.OperationNotSupportedException;

import java.security.AccessController;
import java.security.Permission;
import java.security.Principal;
import javax.security.auth.Subject;
	   
import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class SecurityContextImpl implements SecurityContext
{
   private static final int ENV_SIZE = 10;
   protected Hashtable mEnv = new Hashtable(ENV_SIZE);
   protected Hashtable mNames = new Hashtable();

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public SecurityContextImpl()
   {
      this(null);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public SecurityContextImpl(Hashtable env)
   {
      if (env != null)
      {
         mEnv = (Hashtable)env.clone();
      }
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Principal getUserPrincipal()
   {
      return (Principal)mEnv.get(Context.SECURITY_PRINCIPAL);
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public String getUserName()
   {
      Principal p = getUserPrincipal();
      return (p != null) ? p.getName() : null;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean isAuthorizationEnabled()
   {
      return false;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean hasPermission(Permission permission)
   {
      return false;
   }

   public NamingEnumeration list(String name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      if (name.equals(""))
      {
         return new NameList(mNames.keySet().iterator(), true);
      }
      
      return new NameList(name, true);
   }

   public NamingEnumeration list(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      return list(name.toString());
   }

   public NamingEnumeration listBindings(String name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      if (name.equals(""))
      {
         return new NameList(mNames.keySet().iterator(), false);
      }

      return new NameList(name, false);
   }

   public NamingEnumeration listBindings(Name name) throws NamingException
   {
      return listBindings(name.toString());
   }

   public void rename(String oldName, String newName) throws NamingException
   {
      if ((oldName == null) || (oldName.equals("")) ||
          (newName == null) || (newName.equals("")))
      {
         throw new InvalidNameException("Empty name.");
      }

      Object obj = null;

      if ((obj = mNames.get(oldName)) == null)
      {
         throw new NameNotFoundException(oldName + " not bound.");
      }

      if (mNames.get(newName) != null)
      {
         throw new NameAlreadyBoundException(newName + " already bound.");
      }

      mNames.remove(oldName);
      mNames.put(newName, obj);
   }


   public void rename(Name oldName, Name newName) throws NamingException
   {
      if ((oldName == null) || (newName == null))
      {
         throw new InvalidNameException("Empty name.");
      }

      rename(oldName.toString(), newName.toString());
   }


   public void bind(String name, Object obj) throws NamingException
   {
      if ((name == null) || (name.equals("")))
      {
         throw new InvalidNameException("Empty name.");
      }

      if (mNames.get(name) != null)
      {
         throw new NameAlreadyBoundException(name + " already bound.");
      }

      mNames.put(name, obj);
   }


   public void bind(Name name, Object obj) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      bind(name.toString(), obj);
   }


   public void rebind(String name, Object obj) throws NamingException
   {
      if ((name == null) || (name.equals("")))
      {
         throw new InvalidNameException("Empty name.");
      }

      mNames.put(name, obj);
   }


   public void rebind(Name name, Object obj) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      rebind(name.toString(), obj);
   }


   public void destroySubcontext(String name) throws NamingException
   {
      unbind(name);
   }


   public void destroySubcontext(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      destroySubcontext(name.toString());
   }


   public void unbind(String name) throws NamingException
   {
      if ((name == null) || (name.equals("")))
      {
         throw new InvalidNameException("Empty name.");
      }

      mNames.remove(name);
   }


   public void unbind(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      unbind(name.toString());
   }

   public Context createSubcontext(String name) throws NamingException
   {
      throw new OperationNotSupportedException("Subcontext not supported.");
   }


   public Context createSubcontext(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      return createSubcontext(name.toString());
   }


   public Object lookup(String name) throws NamingException
   {
      return  mNames.get(name);
   }
   
   
   public Object lookup(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      return lookup(name.toString());
   }


   public Object lookupLink(String name) throws NamingException
   {
      return lookup(name);
   }


   public Object lookupLink(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      return lookupLink(name.toString());
   }


   public NameParser getNameParser(String name) throws NamingException
   {
      throw new OperationNotSupportedException("getNameParser not supported.");
   }


   public NameParser getNameParser(Name name) throws NamingException
   {
      if (name == null)
      {
         throw new InvalidNameException("Empty name.");
      }

      return getNameParser(name.toString());
   }

   public Name composeName(Name name, Name prefix) throws NamingException
   {
      Name result = (Name)prefix.clone();
      result.addAll(name);
      return result;
   }


   public String composeName(String name, String prefix) throws NamingException
   {
      Name result = composeName(new CompositeName(name),
                                new CompositeName(prefix));
      return result.toString();
   }


  public Object addToEnvironment(String propName, Object propVal)
     throws NamingException
  {
     if ((propName == null) || (propName.equals("")))
     {
        throw new InvalidNameException("Empty name.");
     }

     if (propName == Context.SECURITY_PRINCIPAL && propVal != null)
     {
        setPrincipal(propVal);
        return propVal; 
     }
     return (propVal != null) ? mEnv.put(propName, propVal) : null;
  }


  public Object removeFromEnvironment(String propName) throws NamingException
  {
     if ((propName == null) || (propName.equals("")))
     {
        throw new InvalidNameException("Empty name.");
     }

     if (mEnv == null)
     {
        return null;
     }

     if (propName == Context.SECURITY_PRINCIPAL)
     {
	mEnv.remove(SecurityEnv.JAAS_SUBJECT);
	mEnv.remove(SecurityEnv.SECURITY_AUTHENTICATED);
     }

     return mEnv.remove(propName);
  }


  public Hashtable getEnvironment() throws NamingException
  {
     if (mEnv == null)
     {
        // TODO: Throw better exception
        throw new NamingException("Null Environment");
     }

     return mEnv;
  }

  
  public void close() throws NamingException
  {
     mEnv = null;
  }
   
   public String getNameInNamespace()
      throws NamingException
   {
      return null;
   }

   class NameList implements NamingEnumeration
   {
      Iterator names;
      boolean     isNameClassPair;

      NameList(String name, boolean ncpair)
      {
         ArrayList vec = new ArrayList(1);

         if (mNames.get(name) != null)
         {
            vec.add(name);
         }
         
         names = vec.iterator();
         isNameClassPair = ncpair;
      }

      
      NameList(Iterator namesEnum, boolean ncpair)
      {
         names = namesEnum;
         isNameClassPair = ncpair;
      }


      public boolean hasMoreElements()
      {
         return names.hasNext();
      }


      public boolean hasMore() throws NamingException
      {
         return hasMoreElements();
      }


      public Object nextElement()
      {
         String name = (String) names.next();

         if (isNameClassPair)
         {
            return new NameClassPair(name, mNames.get(name).getClass().getName());
         }

         return new Binding(name, mNames.get(name));
      }


      public Object next() throws NamingException
      {
         return nextElement();
      }


      public void close()
         throws NamingException
      {
         names = null;
      }
   }

   void setPrincipal(Object principal)
   {
       java.security.Permission p = new RuntimePermission("setPrincipal");
       SecurityManager sm = System.getSecurityManager();
       if (sm != null)
       {
          sm.checkPermission(p);
       }
       mEnv.put(SecurityEnv.SECURITY_AUTHENTICATED, SecurityEnv.SECURITY_CHECKED);
       mEnv.put(Context.SECURITY_PRINCIPAL, principal);
   }

   public boolean isAuthenticated()
   {
       return mEnv.get(Context.SECURITY_PRINCIPAL) != null ? true : false;
   }

   public boolean isUserInRole(String roleName)
   {
       if (ADFContext.getCurrent().isHttpContext())
       {
	  Object req = ADFContext.getCurrent().getEnvironment().getRequest();
	  if (req != null) {
	      return ((javax.servlet.http.HttpServletRequest) req).isUserInRole(roleName);
	  }
       }
             
       Subject s = getSubject();
       if (s != null) 
       {
           Iterator principalIterator = s.getPrincipals().iterator();
           while (principalIterator.hasNext())
           {
              Principal p = (Principal)principalIterator.next();
              String principalName = p.getName();
          
              int ix = principalName.indexOf("/");
              if ((ix > 0 && roleName.regionMatches(0, principalName, ix + 1, roleName.length())) ||
                   roleName.equals(principalName))
              {
                 return true;
              }
           }
       }
      
       return false;
   }      

   public Subject getSubject()
   {
       Subject s = (Subject) mEnv.get(SecurityEnv.JAAS_SUBJECT);
       if (s == null)
       {
          s = Subject.getSubject(AccessController.getContext());
       }
       return s;
   }

   public boolean isAnyoneEnabled()
   {
      Object value = mEnv.get(SecurityEnv.PROP_ANYONE_ENABLED);
      return (value != null ? (value.equals("true") ? true : false) : true);
   }

}

