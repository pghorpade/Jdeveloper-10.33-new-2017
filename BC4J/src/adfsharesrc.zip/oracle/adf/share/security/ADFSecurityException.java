/* Copyright (c) 2004, 2005, Oracle. All rights reserved.  */

package oracle.adf.share.security;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.Throwable;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.MissingResourceException;

public class ADFSecurityException extends Exception
{
   private Throwable m_Cause;  //cause exception
   private String m_ErrorMsgKey;  //msg key for lookup in resourcebundle
   private Object[] m_MsgArgs;  // msg args to construct message using messageformat
   private ResourceBundle mResourceBundle;

   private static String s_DefaultMsgKey = "default";
   private static ResourceBundle sDefaultResourceBundle;

   static
   {
      try
      {
          ADFSecurityException.init("oracle.adf.share.security.resource.ADFSecurityMessages");

       }
      catch( MissingResourceException ex )
      {
          System.out.println("Missing resource bundle ADFSecurityResources file");
      }
   }

   /**
   ** Initialize the <code>ADFSecurityException</code> with the base name of the
   ** resource bundle, a fully qualified class name.
   **
   ** @param baseName base name of the resource bundle, a fully qualified
   **                 class name.
   ** @throws MissingResourceException if no resource bundle for the
   **                                  specified base name can be found.
   */
   public static void init(String baseName) throws MissingResourceException
   {
      sDefaultResourceBundle = ResourceBundle.getBundle(baseName);
   }


   /**
   ** Construct <code>ADFSecurityException</code> with default error
   ** message lookup key.
   */
   public ADFSecurityException()
   {
      this(ADFSecurityException.s_DefaultMsgKey);
   }


   /**
   ** Construct <code>ADFSecurityException</code> with the given error
   ** message lookup key.
   **
   ** @param msgKey the error message lookup key
   */
   public ADFSecurityException(String msgKey)
   {
      this(null, msgKey, null);
   }


   /**
   ** Constructs the <code>ADFSecurityException</code> with the given error
   ** message lookup key and message substitution arguments that are
   ** used for message formatting.
   **
   ** @param msgKey  the error message lookup key
   ** @param msgArgs Object array for the message formatting
   */
   public ADFSecurityException(String msgKey, Object[] msgArgs)
   {
      this(null, msgKey, msgArgs);
   }


   /**
   ** Constructs the <code>ADFSecurityException</code> with the given error
   ** message lookup key and the look up resource bundle. This resource
   ** bundle will override default resource bundle for lookup.
   **
   ** @param      msgKey         the error message lookup key
   ** @param      resourceBundle The resource bundle
   */
   public ADFSecurityException(String msgKey, ResourceBundle resourceBundle)
   {
      this(null, msgKey, resourceBundle, null);
   }


   /**
   ** Construct the <code>ADFSecurityException</code> with default error
   ** message lookup key and with the given <code>Throwable</code>cause.
   **
   ** @param cause parent exception that caused this one.
   */
   public ADFSecurityException(Throwable cause)
   {
       this(cause, ADFSecurityException.s_DefaultMsgKey, null);
   }


   /**
   ** Construct <code>ADFSecurityException</code> with the given
   ** <code>Throwable</code> cause, error message lookup key and
   ** message substitution arguments that are used for message formatting.
   ** Convenience constructor so that obj array need not be created in common
   ** cases.
   **
   ** @param      cause  parent exception that caused it
   ** @param      msgKey the error message lookup key
   ** @param      obj1   substitution argument used to create the object array,
   **                    which is used for message formatting.
   ** @param      obj2   substitution argument used to create the object array,
   **                    which is used for message formatting.
   ** @param      obj3   substitution argument used to create the object array,
   **                    which is used for message formatting.
   */
   public ADFSecurityException(Throwable   cause,
                       String      msgKey,
                       Object      obj1,
                       Object      obj2,
                       Object      obj3)
   {
      this(cause, msgKey, new Object[] {obj1, obj2, obj3});
   }


   /**
   ** Construct <code>ADFSecurityException</code> with the given
   ** <code>Throwable</code> cause, error message lookup key, overriding
   ** resource bundle and message substitution arguments that are used
   ** for message formatting. Convenience constructor so that obj array
   ** need not be created in common cases.
   **
   ** @param      cause          parent exception that caused it
   ** @param      msgKey         the error message lookup key
   ** @param      resourceBundle the resource bundle
   ** @param      obj1           substitution argument used to create the
   **                            object array, which is used for message
   **                            formatting.
   ** @param      obj2           substitution argument used to create the
   **                            object array, which is used for message
   **                            formatting.
   ** @param      obj3           substitution argument used to create
   **                            the object array, which is used for message
   **                            formatting.
   */
   public ADFSecurityException(Throwable       cause,
                       String          msgKey,
                       ResourceBundle  resourceBundle,
                       Object          obj1,
                       Object          obj2,
                       Object          obj3)
   {
      this(cause, msgKey, resourceBundle, new Object[] {obj1, obj2, obj3});
   }


   /**
   ** Constructs the <code>ADFSecurityException</code> with the given error
   ** <code>Throwable</code> cause, message lookup key and message
   ** substitution arguments that are used for message formatting.
   **
   ** @param cause   parent exception that caused it
   ** @param msgKey  the error message lookup key
   ** @param msgArgs Object array for the messageFormatting
   */
   public ADFSecurityException(Throwable cause, String msgKey, Object[] msgArgs)
   {
      this(cause, msgKey, null, msgArgs);
   }


   /**
   ** Constructs the <code>ADFSecurityException</code> with the given error
   ** <code>Throwable</code> cause, message lookup key, overriding
   ** resource bundle and message substitution arguments
   ** that are used for message formatting.
   **
   ** @param      cause          parent exception that caused it
   ** @param      msgKey         the error message lookup key
   ** @param      resourceBundle The resource bundle
   ** @param      msgArgs        Object array for the messageFormatting
   */
   public ADFSecurityException(Throwable cause,
                       String         msgKey,
                       ResourceBundle resourceBundle,
                       Object[]       msgArgs)
   {
      super();
      m_Cause = cause;
      m_ErrorMsgKey = msgKey;
      mResourceBundle = resourceBundle;
      m_MsgArgs = msgArgs;
   }


   /**
   ** Returns the error message key.
   **
   ** @return String - error message key.
   */
   public String getErrorMsgKey()
   {
      return m_ErrorMsgKey;
   }


   /**
   ** Returns the error message determined by the following rules
   ** <ol>
   ** <li>
   ** If the "message key" is default and there no "cause" exception,
   ** returns the default message corresponding to the "default message key".
   ** <br />
   ** ex: new ADFSecurityException()
   ** </li>
   ** <li>
   ** If the "message key" is default and there is a "cause" exception,
   ** returns ONLY the message from the cause exception.
   ** ex: new ADFSecurityException(causeEx)
   ** <br />
   ** </li>
   ** <li>
   ** If "message key" is non-default and there is no "cause" exception,
   ** returns the message corresponding to the "message key".
   ** <br />
   ** ex: new ADFSecurityException(null, "&lt;MSG_KEY&gt;")
   ** </li>
   ** <li>
   ** If "message key" is non-default and there is a "cause" exception,
   ** returns the message corresponding to the "message key" and the message
   ** from the cause exception.
   ** <br />
   ** ex: new ADFSecurityException(causeEx, "&lt;MSG_KEY&gt;")
   ** </li>
   ** </ol>
   **
   ** @return String - the error message.
   */
   public String getErrorMessage()
   {
      // Returns the local error message of this ADFSecurityException. Returns "" if
      // there is no error message key defined for this ADFSecurityException
      String msg = getLocalErrorMessage();

      // Include the message from the cause too.
      if (m_Cause != null)
      {
          msg = msg.concat("    \n");
          if (m_Cause instanceof ADFSecurityException)
          {
              String mdsMsg = ((ADFSecurityException)m_Cause).getErrorMessage();
              if (mdsMsg != null)
              {
                  msg = msg.concat(mdsMsg);
              }
          }
          else
          {
              // Cause is a general Java exception
              String exMsg = m_Cause.getMessage();
              if (exMsg != null)
              {
                  msg = msg.concat(exMsg);
              }
          }
      }
      return msg;
   }


   /**
    * Get the local message for this ADFSecurityException. Unlike the getErrorMessage()
    * method,
    * 1. this method does not return the error message of the cause exception.
    * 2. it also does not recursively return the error messages of the
    *    chained exception.
    *
    * @return The local message for this ADFSecurityException. "" if there is no
    *         error message key defined for this ADFSecurityException
    */
   public String getLocalErrorMessage()
   {
      String msg = "";

      // Ignore the defaultMessage if there is a cause exception
      if (m_ErrorMsgKey.equals(s_DefaultMsgKey))
      {
          if (m_Cause == null)
          {
              msg = getResourceBundle().getString(m_ErrorMsgKey);
          }
      }
      else
      {
          msg = getResourceBundle().getString(m_ErrorMsgKey);
          if (m_MsgArgs != null)
          {
              MessageFormat format = new MessageFormat(msg);
              msg = format.format(m_MsgArgs);
          }
      }

      return msg;
   }


   /**
   ** Prints the error message in the System's default output
   ** <code>PrintStream</code> returned by <code>System.out</code>.
   */
   public void printErrorMessage()
   {
       System.out.println(getErrorMessage());
   }


   /** {@inheritDoc} */
   public void printStackTrace()
   {
      printStackTrace(System.err);
   }


   /** {@inheritDoc} */
   public void printStackTrace(PrintStream stream)
   {
      stream.println();
      stream.println(" Exception: ");
      super.printStackTrace(stream);
      if (m_Cause != null)
      {
          stream.println("Cause: ");
          m_Cause.printStackTrace(stream);
      }
      stream.println();
   }


   /** {@inheritDoc} */
   public void printStackTrace(PrintWriter writer)
   {
      writer.println();
      writer.println("Exception: ");
      super.printStackTrace(writer);
      if (m_Cause != null)
      {
          writer.println("Cause: ");
          m_Cause.printStackTrace(writer);
      }
      writer.println();
      writer.flush();
   }


   /** {@inheritDoc} */
   public Throwable getCause()
   {
      return m_Cause;
   }


   /** {@inheritDoc} */
   public String getLocalizedMessage()
   {
      return getErrorMessage();
   }


   private ResourceBundle getResourceBundle()
   {
      if (mResourceBundle != null)
      {
          return mResourceBundle;
      }
      else
      {
          return sDefaultResourceBundle;
      }
   }
}