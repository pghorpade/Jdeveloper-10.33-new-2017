package oracle.adf.share.security.identitymanagement;

/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 *
 * This interface defines getter and setter methods for constructing a
 * "canonical" user profile.  
 */
public interface UserProfileCapable 
{

   /*
   * Canonical Set of User Attributes
   */
  public static final String FIRST_NAME = "givenName";
  public static final String LAST_NAME = "sn";
  public static final String MIDDLE_NAME = "orclMiddleName";
  public static final String NAME_SUFFIX = "generationQualifier";
  public static final String DISPLAY_NAME = "displayName";
  public static final String DATE_OF_BIRTH = "orclDateOfBirth";
  public static final String USER_ID = "uid";
  public static final String USER_NAME = "username";
  public static final String PASSWORD = "userPassword";
  public static final String DEPARTMENT = "departmentNumber";
  public static final String ORGANIZATION = "o";
  public static final String ORGANIZATIONAL_UNIT = "ou";
  public static final String TITLE = "title";
  public static final String HOME_ADDRESS = "homePostalAddress";
  public static final String HOME_PHONE = "homePhone";
  public static final String BUSINESS_STREET = "street";
  public static final String BUSINESS_CITY = "l";
  public static final String BUSINESS_STATE = "st";
  public static final String BUSINESS_POSTAL_CODE = "postalCode";
  public static final String BUSINESS_COUNTRY = "c";
  public static final String BUSINESS_POSTAL_ADDR = "PostalAddress";
  public static final String BUSINESS_PO_BOX = "postOfficeBox";
  public static final String BUSINESS_PHONE = "telephoneNumber";
  public static final String BUSINESS_FAX = "facsimileTelephoneNumber";
  public static final String BUSINESS_MOBILE = "mobile";
  public static final String BUSINESS_PAGER = "pager";
  public static final String BUSINESS_EMAIL = "mail";
  public static final String DESCRIPTION = "description";
  public static final String INITIALS = "initials";
  public static final String MAIDEN_NAME = "orclMaidenName";
  public static final String EMPLOYEE_NUMBER = "employeeNumber";
  public static final String EMPLOYEE_TYPE = "employeeType";
  public static final String MANAGER = "manager";
  public static final String NAME = "cn";
  public static final String JPEG_PHOTO = "jpegPhoto";
  public static final String DATE_OF_HIRE = "orclHireDate";
  public static final String DEFAULT_GROUP = "orclDefaultProfileGroup";
  public static final String TIME_ZONE = "orclTimeZone";
  public static final String UI_ACCESS_MODE = "orclUIAccessibilityMode";
  public static final String WIRELESS_ACCT_NUMBER = "orclWirelessAccountNumber";
  public static final String PREFERRED_LANGUAGE = "preferredLanguage";

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getGivenName();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setGivenName(String givenName);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getSn();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setSn(String sn);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclMiddleName();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclMiddleName(String orclMiddleName);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getGenerationQualifier();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setGenerationQualifier(String generationQualifier);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDisplayName();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDisplayName(String displayName);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclDateOfBirth();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclDateOfBirth(String orclDateOfBirth);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getUid();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setUid(String uid);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDepartmentNumber();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDepartmentNumber(String departmentNumber);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getO();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setO(String o);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOu();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOu(String ou);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getTitle();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setTitle(String title);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getHomePostalAddress();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setHomePostalAddress(String homePostalAddress);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getHomePhone();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setHomePhone(String homePhone);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getStreet();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setStreet(String street);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getL();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setL(String l);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getSt();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setSt(String st);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostalCode();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostalCode(String postalCode);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getC();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setC(String c);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostalAddress();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostalAddress(String postalAddress);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostOfficeBox();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostOfficeBox(String postOfficeBox);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getTelephoneNumber();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setTelephoneNumber(String telephoneNumber);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getFacsimileTelephoneNumber();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setFacsimileTelephoneNumber(String facsimileTelephoneNumber);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getMobile();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setMobile(String mobile);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPager();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPager(String pager);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getMail();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setMail(String mail);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDescription();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDescription(String description);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getInitials();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setInitials(String initials);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclMaidenName();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclMaidenName(String orclMaidenName);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getEmployeeNumber();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setEmployeeNumber(String employeeNumber);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getManager();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setManager(String manager);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getCn();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setCn(String cn);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getJpegPhoto();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setJpegPhoto(String jpegPhoto);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclHireDate();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclHireDate(String orclHireDate);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclDefaultProfileGroup();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclDefaultProfileGroup(String orclDefaultProfileGroup);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclTimeZone();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclTimeZone(String orclTimeZone);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclUIAccessibilityMode();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclUIAccessibilityMode(String orclUIAccessibilityMode);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclWirelessAccountNumber();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclWirelessAccountNumber(String orclWirelessAccountNumber);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPreferredLanguage();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPreferredLanguage(String preferredLanguage);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getUsername();
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setUsername(String username);
}