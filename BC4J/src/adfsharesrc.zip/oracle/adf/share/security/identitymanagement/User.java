package oracle.adf.share.security.identitymanagement;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * This class represents the most basic user representation.
 * It is expected that this class will be subclassed by IdentityManagement
 * providers with more robust implementations of a user representation.
 */
public class User 
{
   private String username;
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public User()
   {
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public User(String name)
   {
     this();
     this.setUsername(name);    
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public String getUsername()
   {
     return username;
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setUsername(String name)
   {
     this.username = name;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean equals(java.lang.Object obj)
   {
     if (!(obj instanceof User))
        return false;
     return (username != null) ? username.equals(((User) obj).getUsername()) : false;
   }
}