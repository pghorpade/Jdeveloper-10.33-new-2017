package oracle.adf.share.security.identitymanagement;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Properties;
import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.identitymanagement.spi.IdentityManagement;
import java.lang.UnsupportedOperationException;
import java.lang.reflect.*;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class UserManager 
{
  private final static String PROVIDER_CLASS_PROPERTY = "providerClass";
  private IdentityManagement identityManagementProvider = null;
  
  /*
   * This method uses the reflection API to instantiate the specified
   * classname.
   */
  private static Object createObject(String className)
  {
     Object object = null;
     try 
     {
        Class classDefinition = Class.forName(className);
        object = classDefinition.newInstance();
     }
     catch (Exception e)
     {
        throw e;
     }
    return object;
 }

  /*
   * Setter method for the identityManagementProvider.
   */
  private void setidentityManagementProvider(IdentityManagement provider)
  {
    identityManagementProvider = provider;
  }
  
  private void checkProviderConfiguration() throws SecurityException
  {
    if (identityManagementProvider == null) 
      throw new UnsupportedOperationException("Provider not installed.");
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Constructor of the UserManager class.
   * <p>
   * This constructor reads the <code>test.properties</code> file for the 
   * <code>providerClass</code> property, which should be a class name of a 
   * class that implements the <code>IdentityManagement</code> interface.
   * <p>
   * The class that is specified is then set up as the IdentityManagement provider
   * for this API.
   */
  public UserManager()
  {
    // read the configured provider
    Properties properties = new Properties();
    try
    {
      properties.load(new FileInputStream("test.properties"));
    } catch (IOException e)
    {
      System.out.println(e.getMessage());
    }
    String providerClassName = properties.getProperty(PROVIDER_CLASS_PROPERTY);
    if (providerClassName != null)
    {
      IdentityManagement provider = (IdentityManagement)createObject(providerClassName);
      this.setidentityManagementProvider(provider);
    }
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Constructor for UserManager that takes in a provider class name.
   * 
   * @param providerClassName
   */
  public UserManager(java.lang.String providerClassName)
  {
    if (providerClassName != null)
    {
      IdentityManagement provider = (IdentityManagement)createObject(providerClassName);
      this.setidentityManagementProvider(provider);
    }
  }
  
 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  */
  public Principal addUser(User userProfile, Credential cred)
  {
    return identityManagementProvider.addUser(userProfile, cred);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public User createUser()
  {
    return identityManagementProvider.createUser();
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public Principal getPrincipal(String username)
  {
     return ((username == null || username.length() == 0) ? null :identityManagementProvider.getUserPrincipal(username));
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public User getUser(Principal principal)
  {
     return (principal == null ? null : identityManagementProvider.getUser(principal));
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void modifyUser(Principal principal, User user)
  {
     if (principal != null && user != null)
     { 
        identityManagementProvider.modifyUser(principal, user);
     }
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void deleteUser(Principal principal)
  {
     if (principal != null)
     {
        identityManagementProvider.deleteUser(principal);
     }
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public boolean isAddUserSupported()
  {
    return false;
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public boolean isModifyUserSupported()
  {
    return false;
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public boolean isDeleteUserSupported()
  {
    return false;
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public ArrayList getUserList(int sizeLimit, AttributeFilter[] filter)
  {
    return identityManagementProvider.getUserList(sizeLimit, filter);
  }

  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public ArrayList getUserList(int sizeLimit, AttributeFilter[] filter, Principal roleRef)
  {
    return identityManagementProvider.getUserList(sizeLimit, filter, roleRef);
  }
  
}