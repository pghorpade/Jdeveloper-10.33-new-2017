package oracle.adf.share.security.identitymanagement;
import java.security.Principal;
import java.util.Set;
import java.util.ArrayList;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class Role
{
   private String _name;
   private ArrayList _members = new ArrayList();
  
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Role()
   {
     
   }
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Role(String name)
   {
      _name = name;
   }
  
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public String getName()
   {
      return _name;
   }
  
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void setName(String name)
   {
      _name = name;
   }
  
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void addMember(Principal member)
   {
       _members.add(member);
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void removeMember(Principal member)
   {
      int ix = _members.indexOf(member);
      if (ix != -1)
      {
         _members.remove(ix);
      }
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Principal[] getMembers()
   {
      return (Principal[]) _members.toArray(new Principal[_members.size()]);
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean hasMember(Principal member)
   {
      for (int i = 0; i < _members.size(); i++)
      {
         if (((Principal)_members.get(i)).getName().equals(member.getName()))
         {
            return true;
         }
      }
      return false;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public boolean equals(java.lang.Object obj)
   {
     if (!(obj instanceof Role))
        return false;
     return (_name != null) ? _name.equals(((Role) obj).getName()) : false;
   }
}