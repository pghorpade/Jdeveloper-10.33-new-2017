package oracle.adf.share.security.identitymanagement;

import java.security.Principal;
import java.util.ArrayList;

import oracle.adf.share.security.identitymanagement.spi.IdentityManagement;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class RoleManager 
{
   private IdentityManagement identityManagementProvider = null;

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public RoleManager()
   {
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public RoleManager(String providerClassName)
   {
     if (providerClassName != null)
     {
       IdentityManagement provider = (IdentityManagement)createObject(providerClassName);
       this.setidentityManagementProvider(provider);
     }
   }
 
   /*
    * Setter method for the identityManagementProvider.
    */
   private void setidentityManagementProvider(IdentityManagement provider)
   {
     identityManagementProvider = provider;
   }
 
   /*
    * This method uses the reflection API to instantiate the specified
    * classname.
    */
    private static Object createObject(String className) 
    {
       Object object = null;
       try 
       {
          Class classDefinition = Class.forName(className);
          object = classDefinition.newInstance();
       }
       catch (Exception e)
       {
          throw e;
       }
       return object;
   }
 
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public Role createRole()
   {
     return identityManagementProvider.createRole();
 
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Principal addRole(Role role)
   {
     return null;
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void modifyRole(Principal roleRef, Role roleDef)
   {
     
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void deleteRole(Principal roleRef)
   {
     
   }
   
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Role getRole(Principal roleRef)
   {
     return identityManagementProvider.getRole(roleRef);
 
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public Principal getPrincipal(String roleName)
   {
     return identityManagementProvider.getRolePrincipal(roleName);
   }
 
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void deleteFromRole(Principal roleRef, Principal member)
   {
     
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public void addToRole(Principal roleRef, Principal member)
   {
     
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public ArrayList getRoleList(int sizeLimit, AttributeFilter[] filter)
   {
      return identityManagementProvider.getRoleList(sizeLimit, filter);
   }
}
