package oracle.adf.share.security.identitymanagement;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 *
 * This Class provides the ability to set an attribute filter for use in
 * doing a user or group list query.  The <code>setAttribute</code> method
 * lets you specify the name of an attribute on which to apply a filter.
 * The <code>setValue</code> method is used to set the value pattern to filter
 * with. <p>
 * For example, to search for users with names starting with 'P', the 
 * filter could be setup as:
 * <p>
 * <code>
 * AttributeFilter f = new AttributeFilter(UserProfileCapable.USER_NAME, "P*");
 * </code>
 * <p>
 */
public class AttributeFilter 
{
  private String attribute = null;
  private String value = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public AttributeFilter()
  {
    
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public AttributeFilter(String attribute)
  {
    this();
    this.setAttribute(attribute);
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public AttributeFilter(String attribute, String valuePattern)
  {
    this();
    this.setAttribute(attribute);
    this.setValue(valuePattern);
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getAttribute()
  {
    return attribute;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setAttribute(String attribute)
  {
    this.attribute = attribute;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getValue()
  {
    return value;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setValue(String valuePattern)
  {
    this.value = valuePattern;
  }
}
