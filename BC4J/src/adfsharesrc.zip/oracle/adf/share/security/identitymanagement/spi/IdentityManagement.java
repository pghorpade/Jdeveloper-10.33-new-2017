package oracle.adf.share.security.identitymanagement.spi;
import java.security.Principal;
import java.util.ArrayList;
import oracle.adf.share.security.identitymanagement.AttributeFilter;
import oracle.adf.share.security.identitymanagement.Role;
import oracle.adf.share.security.identitymanagement.User;
import oracle.adf.share.security.credentialstore.Credential;

/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 * This <code>interface</code> specifies the contract that a provider of an
 * Identity Management adapter should implement.
 * 
 */
public interface IdentityManagement 
{
 
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method should return a User object or subclass of it that is able to
   * represent a user as expected by the identity management system 
   * implemented by this provider.
   * <p>
   * The subclass is encouraged to implement the UserProfileCapable 
   * interface, which defines the contract for a user profile for a 
   * standard Oracle Identity Management user entry.
   * <p>
   * 
   * @return a representation of a user with standard getter and setter
   * methods for the supported attributes.
   */
  User createUser();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method instructs the provider to create a user in the implemented
   * identity management system with the attributes specified in the user
   * object.  The credential is provided in a separate parameter so that
   * it is not defined in the User object, which is provided freely to
   * the application.  The credential is only specified during user
   * creation and is not available thereafter.
   * 
   * @param user
   * @param credential
   * @return a Principal assigned to the new user.  This principal must be
   * consistent with the user Principal that would be added to the Subject
   * if this user were to authenticate against this repository.
   */
  Principal addUser(User user, Credential credential);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method obtains a User object from the provider for the 
   * user corresponding to the specified principal.
   * 
   * @param principal
   * @return a User object that contains the user's profile attributes from the 
   * identity management system.
   */
  User getUser(Principal principal);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method instructs the provider to update the user entry referenced
   * by the specified user principal in the identity management system.
   * 
   * @param principal A user principal that corresponds to what the associated
   * authenticator for the identity management system would associate with the 
   * Subject when the user authenticates.  This provides the unique identifier
   * for the user in the identity management system.
   * @param user A User object or subclass of it that provides the complete
   * set of attributes that should be committed to the identity management 
   * system.
   */
  void modifyUser(Principal principal, User user);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method deletes the specified user entry referenced by the 
   * user principal.
   * 
   * @param principal A user principal that corresponds to what the associated
   * authenticator for the identity management system would associate with the 
   * Subject when the user authenticates.  This provides the unique identifier
   * for the user in the identity management system.
   */
  void deleteUser(Principal principal);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method get the user principal for the given username. 
   * @param username The username of the user as used to log on to the system.
   * @return A user principal that corresponds to what the associated
   * authenticator for the identity management system would associate with the 
   * Subject when the user authenticates.  This provides the unique identifier
   * for the user in the identity management system.
   */
  Principal getUserPrincipal(String username);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a hint to the calling application as to whether or not
   * the provider supports the addUser method.
   * 
   * @return true indicates that addUser is supported by the provider
   */
  boolean isAddUserSupported();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a hint to the calling application as to whether or
   * not the provider supports the modifyUser method.
   * 
   * @return true indicates that modifyUser is supported by the provider
   */
  boolean isModifyUserSupported();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a hint to the calling application as to whether or
   * not the provider supports the deleteUser method.
   * 
   * @return true indicates that deleteUser is supported by the provider
   */
  boolean isDeleteUserSupported();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a list of users from the
   * underlying repository, based on the specified attribute filters.
   * 
   * @param sizeLimit The limit of the number of entries that should be 
   * retrieved into the collection.
   * @param filter An array of AttributeFilter to specify the search
   * criteria for the list.  The attributes specified should be supported
   * by the underlying provider in the user object.
   * @return An array of user objects.
   */
  ArrayList getUserList(int sizeLimit, AttributeFilter[] filter);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a user list of users in a specified role.
   * 
   * @param sizeLimit
   * @param filter
   * @param roleRef
   * @return An array of user objects.
   */
  ArrayList getUserList(int sizeLimit, AttributeFilter[] filter, Principal roleRef);
  
  /*
   * Role APIs
   */
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method should return a Role object or subclass that 
   * the caller can use to build up a Role definition to submit
   * to the UserManager for adding to the identity management
   * system.
   * @return a Role object or subclass 
   */
  Role createRole();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method should add the specified Role to the identity
   * management system and return a Principal that can subsequently
   * be used to reference the Role.
   * @param roleDef
   * @return A Principal corresponding to the Role that was
   * added to the identity management system.
   */
  Principal addRole(Role roleDef);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method takes a Principal that references a Role in the
   * identity management system, and a Role object, and modifies
   * the definition of the Role in the identity management system
   * in accordance with the definition of the Role specified in the 
   * argument.
   * @param roleRef
   * @param roleDef
   */
  void modifyRole(Principal roleRef, Role roleDef);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method deletes the role referenced by the specified Principal
   * in the identity management system.
   * @param roleRef
   */
  void deleteRole(Principal roleRef);
 
 /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method returns a Role object corresponding to the Principal 
   * specified as an argument.
   * @param roleRef
   * @return a Role object corresponding to the specified Principal
   */
  Role getRole(Principal roleRef);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method returns a Principal corresponding to the specified Role name.
   * @param roleName
   * @return Principal for specified role name
   */
  Principal getRolePrincipal(String roleName);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method adds the specified member Principal to the Role referenced
   * by the specified role Principal.
   * @param roleRef
   * @param member
   */
  void addToRole(Principal roleRef, Principal member);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method deletes the member specified by the corresponding Principal, 
   * from the Role represented by the roleRef Principal, from the identity
   * management system.
   * @param roleRef
   * @param member
   */
  void deleteFromRole(Principal roleRef, Principal member);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method provides a list of roles from the
   * underlying repository, based on the specified attribute filters.
   * 
   * @param sizeLimit The limit of the number of entries that should be 
   * retrieved into the collection.
   * @param filter An array of AttributeFilter to specify the search
   * criteria for the list.  The attributes specified should be supported
   * by the underlying provider in the role object.
   * @return An array of role objects.
   */
  ArrayList getRoleList(int sizeLimit, AttributeFilter[] filter);
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method indicates whether or not the addRole method is supported
   * by the underlying provider.  This may be used by the application
   * to tailor the user interface accordingly.
   * @return true if the addRole method is supported by the provider
   */
  boolean isAddRoleSupported();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method indicates whether or not the modifyRole method is supported
   * by the underlying provider.  This may be used by the application
   * to tailor the user interface accordingly.
   * @return true if the modifyRole method is supported by the provider
   */
  boolean isModifyRoleSupported();
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * This method indicates whether or not the deleteRole method is supported
   * by the underlying provider.  This may be used by the application
   * to tailor the user interface accordingly.
   * @return true if the deleteRole method is supported by the provider
   */
  boolean isDeleteRoleSupported();
  
}
