package oracle.adf.share.security.identitymanagement;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class OIMUserProfile extends User implements UserProfileCapable
{
  private String givenName = null;
  private String sn = null;
  private String orclMiddleName = null;
  private String generationQualifier = null;
  private String displayName = null;
  private String orclDateOfBirth = null;
  private String uid = null;
  private String departmentNumber = null;
  private String o = null;
  private String ou = null;
  private String title = null;
  private String homePostalAddress = null;
  private String homePhone = null;
  private String street = null;
  private String l = null;
  private String st = null;
  private String postalCode = null;
  private String c = null;
  private String postalAddress = null;
  private String postOfficeBox = null;
  private String telephoneNumber = null;
  private String facsimileTelephoneNumber = null;
  private String mobile = null;
  private String pager = null;
  private String mail = null;
  private String description = null;
  private String initials = null;
  private String orclMaidenName = null;
  private String employeeNumber = null;
  private String manager = null;
  private String cn = null;
  private String jpegPhoto = null;
  private String orclHireDate = null;
  private String orclDefaultProfileGroup = null;
  private String orclTimeZone = null;
  private String orclUIAccessibilityMode = null;
  private String orclWirelessAccountNumber = null;
  private String preferredLanguage = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public OIMUserProfile()
  {
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public OIMUserProfile(String username)
  {
    this();
    super.setUsername(username);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getGivenName()
  {
    return givenName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setGivenName(String givenName)
  {
    this.givenName = givenName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getSn()
  {
    return sn;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setSn(String sn)
  {
    this.sn = sn;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclMiddleName()
  {
    return orclMiddleName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclMiddleName(String orclMiddleName)
  {
    this.orclMiddleName = orclMiddleName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getGenerationQualifier()
  {
    return generationQualifier;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setGenerationQualifier(String generationQualifier)
  {
    this.generationQualifier = generationQualifier;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDisplayName()
  {
    return displayName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDisplayName(String displayName)
  {
    this.displayName = displayName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclDateOfBirth()
  {
    return orclDateOfBirth;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclDateOfBirth(String orclDateOfBirth)
  {
    this.orclDateOfBirth = orclDateOfBirth;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getUid()
  {
    return uid;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setUid(String uid)
  {
    this.uid = uid;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDepartmentNumber()
  {
    return departmentNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDepartmentNumber(String departmentNumber)
  {
    this.departmentNumber = departmentNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getO()
  {
    return o;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setO(String o)
  {
    this.o = o;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOu()
  {
    return ou;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOu(String ou)
  {
    this.ou = ou;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getTitle()
  {
    return title;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setTitle(String title)
  {
    this.title = title;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getHomePostalAddress()
  {
    return homePostalAddress;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setHomePostalAddress(String homePostalAddress)
  {
    this.homePostalAddress = homePostalAddress;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getHomePhone()
  {
    return homePhone;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setHomePhone(String homePhone)
  {
    this.homePhone = homePhone;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getStreet()
  {
    return street;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setStreet(String street)
  {
    this.street = street;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getL()
  {
    return l;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setL(String l)
  {
    this.l = l;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getSt()
  {
    return st;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setSt(String st)
  {
    this.st = st;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostalCode()
  {
    return postalCode;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostalCode(String postalCode)
  {
    this.postalCode = postalCode;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getC()
  {
    return c;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setC(String c)
  {
    this.c = c;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostalAddress()
  {
    return postalAddress;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostalAddress(String postalAddress)
  {
    this.postalAddress = postalAddress;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPostOfficeBox()
  {
    return postOfficeBox;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPostOfficeBox(String postOfficeBox)
  {
    this.postOfficeBox = postOfficeBox;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getTelephoneNumber()
  {
    return telephoneNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setTelephoneNumber(String telephoneNumber)
  {
    this.telephoneNumber = telephoneNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getFacsimileTelephoneNumber()
  {
    return facsimileTelephoneNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setFacsimileTelephoneNumber(String facsimileTelephoneNumber)
  {
    this.facsimileTelephoneNumber = facsimileTelephoneNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getMobile()
  {
    return mobile;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setMobile(String mobile)
  {
    this.mobile = mobile;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPager()
  {
    return pager;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPager(String pager)
  {
    this.pager = pager;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getMail()
  {
    return mail;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setMail(String mail)
  {
    this.mail = mail;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setDescription(String description)
  {
    this.description = description;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getInitials()
  {
    return initials;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setInitials(String initials)
  {
    this.initials = initials;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclMaidenName()
  {
    return orclMaidenName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclMaidenName(String orclMaidenName)
  {
    this.orclMaidenName = orclMaidenName;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getEmployeeNumber()
  {
    return employeeNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setEmployeeNumber(String employeeNumber)
  {
    this.employeeNumber = employeeNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getManager()
  {
    return manager;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setManager(String manager)
  {
    this.manager = manager;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getCn()
  {
    return cn;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setCn(String cn)
  {
    this.cn = cn;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getJpegPhoto()
  {
    return jpegPhoto;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setJpegPhoto(String jpegPhoto)
  {
    this.jpegPhoto = jpegPhoto;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclHireDate()
  {
    return orclHireDate;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclHireDate(String orclHireDate)
  {
    this.orclHireDate = orclHireDate;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclDefaultProfileGroup()
  {
    return orclDefaultProfileGroup;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclDefaultProfileGroup(String orclDefaultProfileGroup)
  {
    this.orclDefaultProfileGroup = orclDefaultProfileGroup;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclTimeZone()
  {
    return orclTimeZone;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclTimeZone(String orclTimeZone)
  {
    this.orclTimeZone = orclTimeZone;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclUIAccessibilityMode()
  {
    return orclUIAccessibilityMode;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclUIAccessibilityMode(String orclUIAccessibilityMode)
  {
    this.orclUIAccessibilityMode = orclUIAccessibilityMode;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getOrclWirelessAccountNumber()
  {
    return orclWirelessAccountNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setOrclWirelessAccountNumber(String orclWirelessAccountNumber)
  {
    this.orclWirelessAccountNumber = orclWirelessAccountNumber;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public String getPreferredLanguage()
  {
    return preferredLanguage;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
  public void setPreferredLanguage(String preferredLanguage)
  {
    this.preferredLanguage = preferredLanguage;
  }

}