/* $Header: SecurityContext.java 21-mar-2006.10:59:22 ychua Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       04/25/05 - 
    ychua       03/17/05 - 
    ychua       03/14/05 - 
    ychua       03/08/05 - 
    ychua       02/13/05 - 
    ychua       12/08/04 - 
    dmutreja    11/18/04 - 
    ychua       11/16/04 - Creation
 */

/**
 *  @version $Header: SecurityContext.java 21-mar-2006.10:59:22 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.security;

import java.security.Principal;
import java.security.Permission;
import javax.security.auth.Subject;
import javax.naming.Context;

public interface SecurityContext extends Context
{
  /**
   * Retrieves the principal of this SecurityContext.  It is the current authenticated user 
   * principal obtained from the <code>HttpServletRequest.getUserPrincipal()</code>
   * @return the user principal
   */
  public Principal getUserPrincipal();
   
  /**
   * Retrieves the name of principal of this SecurityContext.  
   * @return the name of the user principal
   */
  public String getUserName();
   
  /**
   * True if the principal in this SecurityContext has the permission
   * @param permission the permission to be checked
   * @return <code>true</code> if the principal has the specified permission.
   */
  public boolean hasPermission(Permission permission);

  /**
   * True if authorization check is enable
   * @return <code>true</code> if authorization check should be performed.
   */
  public boolean isAuthorizationEnabled();

  /**
   * True if authenticated
   * @return <code>true</code> if there is an authenticated user.
   */
  public boolean isAuthenticated();

  /**
   * True if user is in the specified role
   * @return <code>true</code> if current user in the role.
   */
  public boolean isUserInRole(String roleName);

  /**
   * Retrieves the subject in the SecurityContext or AccessController context.
   * @return the current Subject
   */
  public Subject getSubject();

  /**
   * <b>Internal:</b> <em>Applications should not use this class.</em>
   * True if anyone role is enable
   * @return <code>true</code> if authorization check should be performed.
   */
  public boolean isAnyoneEnabled();
}

