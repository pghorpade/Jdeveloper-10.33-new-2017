package oracle.adf.share.security.credentialstore.spi;

import oracle.adf.share.security.credentialstore.Credential;

import java.security.Principal;

import java.io.Serializable;

/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 * An interface for managing credentials for user or role principals. 
 */

public interface CredentialProvisioning
{
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential for the specified credential key and principal.
   * @param cred  the credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeCredential(Credential cred, String credKey, Principal principal);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential for the specified credential key and principal.
   * @param cred  the serializable credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeSerializableCredential(Serializable cred, String credKey, Principal principal);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the credential specified by the credential key.
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void removeCredential(String credKey, Principal principal);
}

 


