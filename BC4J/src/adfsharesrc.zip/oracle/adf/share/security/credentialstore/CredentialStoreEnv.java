package oracle.adf.share.security.credentialstore;

import java.util.Enumeration;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Configuration properties for credential store providers.  These properties are used in the 
 * credential store configuartion file. 
 */
class CredentialStoreEnv 
{
  /**
   * Provider type property
   */
   public static String PROVIDER_TYPE = "provider.type";
   
  /**
   * Provider class name property
   */
   public static String PROVIDER_CLASS = "provider.class";

  /**
   * Credential store configuration file property
   */
   public static String CREDENTIAL_STORE_CONFIG = "oracle.adf.share.security.credentialstore.config";
   
  /**
   * Credential type property
   */
   public static String CREDENTIAL_TYPE = "credential-type";
   
  /**
   * Credential types property
   */
   public static String CREDENTIAL_TYPES = "credential-types";

  /**
   * Default provider property
   */
   public static String PROVIDER_TYPE_DEFAULT = "provider.default";
}

 


