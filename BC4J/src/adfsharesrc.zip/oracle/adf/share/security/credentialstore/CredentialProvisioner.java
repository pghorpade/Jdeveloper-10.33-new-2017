package oracle.adf.share.security.credentialstore;

import oracle.adf.share.security.credentialstore.spi.CredentialProvisioning;

import java.security.Principal;

import java.io.Serializable;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * CredentialProvisioner provides management of user/role principals credentials. 
 */

public class CredentialProvisioner
{
//   CredentialStoreContext _credentialStoreCtx = CredentialStoreContext.getInstance();
   CredentialStoreContext _credentialStoreCtx = null;
   CredentialProvisioning _provisioning = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructor for a credential provisioner.
   * It provide access to a credential provisioning object from an internal context.
   */
   public CredentialProvisioner()
   {
      _credentialStoreCtx = new CredentialStoreContext();
      _provisioning = _credentialStoreCtx.getDefaultCredentialProvisioner();
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructor for a credential provisioner of a specific provider class.
   * @param providerClassName
   */
   public CredentialProvisioner(String providerClassName)
   {
       _credentialStoreCtx = new CredentialStoreContext();
      _provisioning = _credentialStoreCtx.getCredentialProvisioner(providerClassName);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential for the specified credential key and principal.
   * @param cred  the credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeCredential(Credential cred, String credKey, Principal principal)
   {
      _provisioning.storeCredential(cred, credKey, principal);
   }


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential for the specified credential key and principal.
   * @param cred  the serializable credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeSerializableCredential(Serializable cred, String credKey, Principal principal)
   {
      _provisioning.storeSerializableCredential(cred, credKey, principal);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the credential specified by the credential key.
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void removeCredential(String credKey, Principal principal)
   {
       _provisioning.removeCredential(credKey, principal);
   }
}

 


