package oracle.adf.share.security.credentialstore;

import java.util.Properties;

import oracle.xml.parser.v2.DOMParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XMLDocument;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Enumeration;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Loads the CredentialStore configuration file which may contains multiple credential stores and their properties
 */
class CredentialStoreConfig
{
   private Hashtable _providers = new Hashtable();
   private static String _configFilePath;
   private static URL _configFileURL;
   private static XMLDocument xmlDoc = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * 
   * Create an instance of credentialstore config object with the configuration file specified.
   * @param configPath the configuration file path
   */
   public CredentialStoreConfig(String configPath)
   {
      _configFilePath = configPath;
   }

   private static synchronized URL getConfigFileURL()
   {
       try
       {
          if (_configFileURL != null)
          {
             return _configFileURL;
          }
          else
          {
             String s = getConfigFilePath();
             if (s != null)
             {
                File file = new File(s);
                _configFileURL = file.toURL();
                return _configFileURL;
             } 
          }
       }
       catch (Exception ex)
       {
           ex.printStackTrace();
       }
       return null;
   }


   private static synchronized String getConfigFilePath()
   {
       if (_configFilePath == null || _configFilePath.length() == 0)
       {
          _configFilePath = getConfigFileFromSystemProperty();
       }
       return  _configFilePath;
   }

   void loadFromXML()
   {
      DOMParser xmlParser = new DOMParser();
      XMLElement elem = null;

      try
      {
         Reader reader = createReader(getConfigFileURL());
         if (reader == null)
         {
            return;
         }
         xmlParser.parse(reader);
         xmlDoc = xmlParser.getDocument();
         elem = (XMLElement)xmlDoc.getDocument().getDocumentElement();
         NodeList nl = xmlDoc.getElementsByTagName("providers");
         if (nl != null)
         {
             Node n = nl.item(0); 
             if (n.getNodeName().equals("providers") && n.hasChildNodes())
             {
                loadProviderProperties(n.getChildNodes()); 
             }
         }
         //showProviders();
         //getProviders();
      }
      catch (IOException ex)
      {
         ex.printStackTrace();
      }        
      catch (org.xml.sax.SAXException e)
      {

      }        
   }

   protected Reader createReader(URL url) throws IOException
   {
      InputStream inputStream = null;
      InputStreamReader isr = null;
      if (url == null)
      {
           return null;
      }
      try
      {
         inputStream = url.openStream();
         isr = new InputStreamReader(inputStream);
      }
      finally
      {
         if ( isr == null && inputStream != null )
         {
            try { inputStream.close(); } catch ( Exception ex ) {}
         }
      }
      return isr;
   }

   private static String getConfigFileFromSystemProperty()
   {
      String cfg = null;

      try 
      {
         cfg = System.getProperty(CredentialStoreEnv.CREDENTIAL_STORE_CONFIG);
      }
      catch (Exception e)
      {
      }
      return cfg;
   }

   void loadProviderProperties(NodeList nl)
   {
      for ( int i=0; i < nl.getLength(); i++)
      {
         Node parent = nl.item(i); 
 
         System.out.println(" Parent:   " +  parent.getNodeName());
         if ( parent.hasChildNodes() )
         {
            NodeList children = parent.getChildNodes();
            //ProviderProperties pp = new ProviderProperties(parent);
            ProviderProperties pp = new ProviderProperties();
            pp.loadProperties(parent);

//            String providerType = pp.getProperties().getProperty(CredentialStoreEnv.PROVIDER_TYPE);
            String providerType = pp.getProperty(CredentialStoreEnv.PROVIDER_TYPE);
            if (providerType != null)
            {
               //System.out.println("ProviderType: " + providerType);
               _providers.put(providerType, pp);
            }
         }
      }
    }

    void showProviders()
    {
        Enumeration e = _providers.keys();
        while (e.hasMoreElements())
        {
           Object key = e.nextElement();
           ProviderProperties pp = (ProviderProperties) _providers.get(key);
//           showProperties(pp.getProperties());
           showProperties(pp);
           ArrayList csTypes = pp.getCredentialTypeProperties();
           for (int i = 0; i < csTypes.size(); i++)
           {
               showProperties((Properties) csTypes.get(i));
           }
        }
    }

    void showProperties(Properties props)
    {
        Enumeration enum = props.propertyNames();
        while (enum.hasMoreElements())
        {
           String pName = (String) enum.nextElement();
           System.out.println(pName + " = " + props.getProperty(pName));
        }
    }

    private Hashtable getProviders()
    {
        return _providers;
    }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * 
   * Gets the properties of the specified provider type.
   * @param providerType the name of the provider type.
   * @return the properties
   */
    public Properties getProperties(String providerType)
    {
       ProviderProperties pp = (ProviderProperties) _providers.get(providerType);
       return pp;
    }

   public ProviderProperties getProviderProperties()
   {
      return (ProviderProperties) _providers.get(getProviderTypes().get(0));
   }

  
  //<b>Internal:</b> <em>Applications should not use this method.</em>
  //Gets the properties of the specified provider type.
  //@param providerType the name of the provider type.
  //@return the properties
  //public ProviderProperties getProviderProperties(String providerType)
  //{
  //   return (ProviderProperties) _providers.get(providerType);
  //}

  
   // Gets a list of provider types.
   // @return the list of provider types
   //
    ArrayList getProviderTypes()
    {
        Enumeration e = _providers.keys();
        ArrayList list = new ArrayList();

        while (e.hasMoreElements())
        {
           Object o = e.nextElement();
           System.out.println(" Provider = " + o);
           list.add(o);
        }
        return list;
    }

    ArrayList getCredentialTypeProperties(String providerType)
    {
        ProviderProperties pp = (ProviderProperties) _providers.get(providerType);
        return pp.getCredentialTypeProperties();
    }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * 
   * Gets the class name of the specified provider type.
   * @param providerType the name provider type
   * @return the class name of the provider type
   */
   public String getProviderClassName(String providerType)
   {
      ProviderProperties pp = (ProviderProperties)getProviders().get(providerType);
      return pp.getClassName();
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public ProviderProperties getProviderProperties(String className)
   {
      Enumeration e = _providers.keys();
      while (e.hasMoreElements())
      {
         Object key = e.nextElement();
         ProviderProperties pp = (ProviderProperties) _providers.get(key);
         if (pp.getClassName().equals(className))
         {
            return pp;
         }
      }
      return null;
   }
}



 


