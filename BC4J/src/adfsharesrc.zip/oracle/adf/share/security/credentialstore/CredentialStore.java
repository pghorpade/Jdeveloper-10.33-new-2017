package oracle.adf.share.security.credentialstore;

import java.util.Enumeration;
import java.util.Properties;
import java.util.ArrayList;

import java.io.Serializable;

import oracle.adf.share.security.credentialstore.spi.CredentialStorage;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * CredentialStore is the runtime interface to a credential storage for the current user.  It delegates fetching, storing
 * and removing of credentials to the underlying storage.  
 */

public class CredentialStore 
{
   CredentialStoreContext _credentialStoreCtx = null;
//   CredentialStoreContext _credentialStoreCtx = CredentialStoreContext.getInstance();
   CredentialStorage _storage = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructor for a credential store.
   * It get an instance of credential store from an internal context that loads a configuration file containing
   * properties of credential storage provider.
   */
   public CredentialStore()
   {
     _credentialStoreCtx = new CredentialStoreContext();
      _storage = _credentialStoreCtx.getDefaultCredentialStoreProvider();
   }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructor for a credential store of a specific provider class.
   * @param providerClassName
   */
   public CredentialStore(String providerClassName)
   {
       _credentialStoreCtx = new CredentialStoreContext();
      _storage = _credentialStoreCtx.getCredentialStorage(providerClassName);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Adds or replace the credential in the store for the given credential key.
   * @param cred  the credential value
   * @param credKey  the credential key
   */
   public void storeCredential(Credential cred, String credKey)
   {
      _storage.storeCredential(cred, credKey);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Adds or replace a session credential for the given credential key.
   * @param cred  the credential value
   * @param credKey  the credential key
   */
   public void storeSessionCredential(Credential cred, String credKey)
   {
      CredentialStoreContext.storeSessionCredential(cred, credKey);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the session credential for the specifier credential key.
   * @param credKey  the credential key.
   * @return  a valid credential, or <code>null</code> if not found
   */
   public Credential fetchSessionCredential(String credKey)
   {
      return CredentialStoreContext.fetchSessionCredential(credKey);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the credential for the specified credential key.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Credential fetchCredential(String credKey)
   {
      return _storage.fetchCredential(credKey);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredential(String credKey)
   {
      return _storage.fetchSerializableCredential(credKey);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key for the current user.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredentialForCurrentUser(String credKey)
   {
      return _storage.fetchSerializableCredentialForCurrentUser(credKey);
   }


//  /**
//   * Returns a list of credentials 
//   * @return a list of valid credentials
//   */
//   public ArrayList fetchCredentials()
//   {
//      return _storage.fetchCredentials();
//   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the credential specified by the credential key.
   * @param credKey  the credential key
   */
   public void removeCredential(String credKey)
   {
      _storage.removeCredential(credKey);
   }
}

 


