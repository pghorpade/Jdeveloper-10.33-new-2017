package oracle.adf.share.security.credentialstore;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
 

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * This class implements map and use a hashtable to store and retrieve property values.
 */
public class Credential implements Map 
{
   Hashtable mProperties = new Hashtable();
   
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Sole constructor
   */
   public Credential()
   {
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns properties in a <code>Hashtable</code>.
   * @return a hashtable of properties
   */
   public Hashtable getProperties()
   {
      return mProperties;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the property specify by the name of the property.
   * @param propName the property name
   * @return the property value, or <code>null</code> if not found
   */
   public String getProperty(String propName)
   {
      Object value = mProperties.get(propName);
      return ((value == null) ? null : value.toString());
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Sets the property value for the specify property name
   * @param propName  the property name
   * @param value the property value
   */
   public void setProperty(String propName, String value)
   {
      mProperties.put(propName, value);
   }
    
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the property names
   * @return a collection of property names
   */
   public Set getPropertyNames()
   {
      return mProperties.keySet();
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Maps the specified key to the specified value in this hashtable. Neither the key nor the value can be null. 
   * The value can be retrieved by calling the get method with a key that is equal to the original key. 
   * @param value the value.
   * @param key the hashtable key
   * @return the previous value of the specified key in this hashtable, or null if it did not have one. 
   * @throws <code>NullPoinerException</code> if the key is null
   */
   public Object put(Object key, Object value) 
   {
      Object oldValue = mProperties.get(key);
      mProperties.put(key, value);
      return oldValue;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the value to which the specified key is mapped in this hashtable. 
   * @param key a key in the hashtable
   * @return the value to which the key is mapped in this hashtable; null if the key is not mapped to any value in this hashtable. 
   * @throws <code>NullPoinerException</code> if the key is null
   */
   public Object get(Object key)
   {
      return mProperties.get(key);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the key (and its corresponding value) from this hashtable
   * @param key the key that needs to be removed. 
   * @return the value to which the key had been mapped in this hashtable, or null if the key did not have a mapping
   * @throws <code>NullPoinerException</code> if the key is null
   */
  public Object remove(Object key)
  {
      Object value = mProperties.get(key);
      mProperties.remove(key);
      return value;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns a Set view of the keys contained in this Hashtable. The Set is backed by the Hashtable, so changes to the Hashtable are reflected in the Set, and vice-versa. The Set supports element removal (which removes the corresponding entry from the Hashtable), but not element addition. 
   * @return a set view of the keys contained in this map
   */
  public Set keySet()
  {
      return mProperties.keySet();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns a Set view of the entries contained in this Hashtable. Each element in this collection is a Map.Entry. The Set is backed by the Hashtable, so changes to the Hashtable are reflected in the Set, and vice-versa. The Set supports element removal (which removes the corresponding entry from the Hashtable), but not element addition. 
   * @return a set view of the mappings contained in this map
   */
  public Set entrySet()
  {
      return mProperties.entrySet();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Copies all of the mappings from the specified Map to this Hashtable These mappings will replace any mappings that this Hashtable had for any of the keys currently in the specified Map. 
   * @param map Mappings to be stored in this map. 
   * @throws <code>NullPoinerException</code> if the key is null
   */
  public void putAll(Map map)
  {
      mProperties.putAll(map);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns a collection view of the values contained in this map. The collection is backed by the map, so changes to the map are reflected in the collection, and vice-versa. If the map is modified while an iteration over the collection is in progress, the results of the iteration are undefined. The collection supports element removal, which removes the corresponding mapping from the map, via the Iterator.remove, Collection.remove, removeAll, retainAll and clear operations. It does not support the add or addAll operations. 
   * @return a collection view of the values contained in this map.
   */
  public Collection values()
  {
      return mProperties.values();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns true if this map maps one or more keys to the specified value. More formally, returns true if and only if this map contains at least one mapping to a value v such that (value==null ? v==null : value.equals(v)). This operation will probably require time linear in the map size for most implementations of the Map interface
   * @return true if this map maps one or more keys to the specified value
   * @param value value whose presence in this map is to be tested. 
   */
  public boolean containsValue(Object value)
  {
      return mProperties.containsValue(value);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns true if this map contains a mapping for the specified key. More formally, returns true if and only if this map contains at a mapping for a key k such that (key==null ? k==null : key.equals(k)). (There can be at most one such mapping.) 
   * @return <code>true</code> if this map contains a mapping for the specified key. 
   * @param key key whose presence in this map is to be tested. 
   * @throws <code>NullPoinerException</code> if the key is null
   */
  public boolean containsKey(Object key)
  {
      return mProperties.containsKey(key);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns true if this map contains no key-value mappings.
   * @return <code>true</code> if this map contains no key-value mappings.
   */
  public boolean isEmpty()
  {
      return mProperties.isEmpty();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the hash code value for this map. The hash code of a map is defined to be the sum of the hashCodes of each entry in the map's entrySet view.
   * @return the hash code value for this map
   */
  public int hashCode()
  {
      return mProperties.hashCode();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the number of key-value mappings in this map. If the map contains more than Integer.MAX_VALUE elements, returns Integer.MAX_VALUE. 
   * @return the number of key-value mappings in this map
   */
  public int size()
  {
      return mProperties.size();
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Clears this hashtable so that it contains no keys
   */
  public void clear()
  {
      mProperties.clear();
  }
}


 



 


