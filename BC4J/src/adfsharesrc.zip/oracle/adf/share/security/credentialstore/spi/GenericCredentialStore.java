package oracle.adf.share.security.credentialstore.spi;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.credentialstore.CredentialStore;
import oracle.adf.share.security.ADFSecurityRuntimeException;
import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.security.resource.ADFSecurityMessageBundle;


import java.util.ArrayList;
import java.util.Hashtable;

import java.io.Serializable;
import javax.naming.Context;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * This class provides a skeletal implementation of the CredentialStorage interface, to minimize the 
 * effort required to implement this interface.
 */
public abstract class GenericCredentialStore implements CredentialStorage 
{
   private static String _applicationUser = null;
   private boolean isApplicationUserSupported = true;
   private Context _secCtx = null;

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Initializes the credentialstore from the properties.
   * @param props the properties to initialize with
   */
   public abstract void initialize(Hashtable props);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential using the specify credential key.
   * @param cred  the crdential to be stored
   * @param credKey  the credential key
   */
   public abstract void storeCredential(Credential cred, String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Retrieves the credential for the specified credential key.
   * @param credKey  the credential key
   * @return the credential, or <code>null</code> if not found
   */
   public abstract Credential fetchCredential(String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public abstract Serializable fetchSerializableCredential(String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key for current user.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredentialForCurrentUser(String credKey)
   {
      throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_CRDENTIAL_OPERATION));
   }


//  /**
//   * Retrieves a list of credentials
//   * @return a list of credentials 
//   */
//   public abstract ArrayList fetchCredentials();


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the credential specified credential idebtifier.
   * @param credKey  the credential key
   */
   public abstract void removeCredential(String credKey);

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public String getApplicationUserName()
   {
      if (_applicationUser == null && isApplicationUserSupported)
      {
         try
         {
            _applicationUser = System.getProperty(SecurityEnv.PROP_CREDENTIAL_STORE_DEFAULT_USER);
            if (_applicationUser == null)
            {
               String configUser = getConfigCredentialStoreUser();
               _applicationUser = (configUser != null && configUser.length() > 0) ?
                                   configUser : SecurityEnv.CREDENTIAL_STORE_USER_DEFAULT;
            }
         }
         catch (Exception e)
         {
         }
      }
      return _applicationUser;
   }

   String getConfigCredentialStoreUser()
   {
      String configUser = null;

      try
      {
         configUser = (String)getSecurityContext().getEnvironment().get(SecurityEnv.PROP_CREDENTIAL_STORE_DEFAULT_USER);
      }
      catch (Exception e)
      {

      }
      return configUser;
   }

   Context getSecurityContext()
   {
      if (_secCtx == null)
      {
         try
         {
            _secCtx= ADFContext.getCurrent().getSecurityContext();
         }
         catch(Exception e)
         {
         }
      }
      return _secCtx;
   }
}

 


