package oracle.adf.share.security.credentialstore;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Hashtable;
import java.util.Vector;

import oracle.adf.share.security.credentialstore.spi.CredentialStorage;
import oracle.adf.share.security.credentialstore.spi.CredentialProvisioning;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.security.SecurityEnv;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * This class provide the starting point for getting CredentialStore related
 * objects and a centralized place for managing CredentialStore properties.
 */
class CredentialStoreContext 
{
   private static CredentialStoreContext _singleton;
   private final static Object   __LOCK__ = new Object();
   private static Hashtable _sessionCredentials = new Hashtable();
   private Vector mProviders = new Vector();
   
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Instantiates a CredentialStore context.
   * @return an instance of the CredentialStoreContext
   */
   public static CredentialStoreContext getInstance()
   {
     synchronized (__LOCK__)
     {
       if (null == _singleton)
       {
         _singleton = new CredentialStoreContext();
         return _singleton;
       }
     }
     return _singleton;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Initialize with the given properties
   * @param props the properties to initialize
   */
   public void initialize(java.util.Properties props)
   {
   }


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the default credential store.
   * @return the default credential store
   */
   public CredentialStorage getDefaultCredentialStoreProvider()
   {
      SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
      String  credStore = null;
      try
      {
         credStore = (String)secCtx.getEnvironment().get(SecurityEnv.PROP_CREDENTIAL_STORE_PROVIDER);
      }
      catch (Exception e)
      {

      }

      if (credStore == null)        
      {
         credStore = SecurityEnv.CREDENTIAL_STORE_PROVIDER_DEFAULT;
      }
      return getCredentialStorage(credStore);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the default credential provisioner.
   * @return the default credential provisioner
   */
   public CredentialProvisioning getDefaultCredentialProvisioner()
   {
      return (CredentialProvisioning) getDefaultCredentialStoreProvider();
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the credential provisioner specified by the provider class name.
   * @param providerClassName  the class name of the provider 
   * @return the credential provisioner
   */
   public CredentialProvisioning getCredentialProvisioner(String providerClassName)
   {
      return (CredentialProvisioning)getCredentialStorage(providerClassName);
   }   
   
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the credential store provider for the specified provider type.
   * @param providerClassName  the class name of the provider
   * @return the credential store
   */
   public CredentialStorage getCredentialStoreProvider(String providerClassName)
   {
       return getCredentialStorage(providerClassName);
   }


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Gets the credential store provider for the specified provider type.
   * @param providerClassName  the class name of the provider 
   * @return the credential store
   */
   public CredentialStorage getCredentialStorage(String providerClassName)
   {
       CredentialStorage instance = null;

       for ( int i = 0; i < mProviders.size(); i++)
       {
	   Object o = mProviders.get(i);
	   if (o.getClass().getName().equals(providerClassName))
           {
	       return (CredentialStorage) o;
	   }
       }
       try
       {
          Class cls = Class.forName(providerClassName);
          instance = (CredentialStorage) cls.newInstance();
          mProviders.add(instance);
       }
       catch (Exception ex)
       {
          throw ex;
       }
       return instance;
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Stores the session credential. The credential is available only for the duration of 
   * the session.
   * @param cred  the credential to be stored
   * @param credKey  the key of the credential
   */
   public static void storeSessionCredential(Credential cred, String credKey)
   {
      _sessionCredentials.put(credKey, cred);
   }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Fetch the session credential of the specified credential key.
   * @param credKey  the credential key
   * @return the credential for the given key, or <code>null</code> if not found
   */
   public static Credential fetchSessionCredential(String credKey)
   {
      return (Credential) _sessionCredentials.get(credKey);
   }

}

 
 


