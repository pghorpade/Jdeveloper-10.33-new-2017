package oracle.adf.share.security.credentialstore;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import oracle.xml.parser.v2.XMLElement;
import oracle.xml.parser.v2.XMLDocument;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Properties;

/**
 * This class is used internally to load credentialstore provider properties and credential types 
 * from the credential store configuration file.
 */
class ProviderProperties extends Properties
{
   private String _providerType = null;
   private ArrayList _credentialTypes = null;
   boolean _lazyLoad = false;

   void  loadProperties(Node parent)
   {
      _credentialTypes = new ArrayList();

      NodeList children = parent.getChildNodes();
      for ( int j=0; j < children.getLength(); j++)
      {
         Node nn = children.item(j);

         String nodeName = nn.getNodeName();
         System.out.println("   " + nn.getNodeName() );
         if (nn.getNodeName().equals(CredentialStoreEnv.CREDENTIAL_TYPES))
         {
            if (!_lazyLoad)
            {
               _credentialTypes = getCredentialTypes(nn.getChildNodes());   
            }
            else
            {
               _credentialTypes.add(nn);
            }
         }
         else
         {
            Node child = nn.getFirstChild();
            if (child != null)
            {
               System.out.println("   " + child.getNodeName() + ", " + child.getNodeValue());
               if (child.getNodeValue() != null)
               {
                  super.setProperty(getKeyName(parent, nn), child.getNodeValue());
               }
            }
            else 
            {
               NamedNodeMap attrs = nn.getAttributes();
               if (attrs != null)
               {
                  getExtendedProperties(attrs);
               }
            }
  
         }
      }
    }

    String getKeyName(Node parent, Node child)
    {
       return parent.getNodeName() + "."  + child.getNodeName();
    }

    ArrayList getCredentialTypes(NodeList nl)
    {
       ArrayList credentialTypes = new ArrayList();

       for ( int i=0; i < nl.getLength(); i++)
       {
          Node parent = nl.item(i); 
          Properties p = new Properties();

          if ( parent.hasChildNodes() )
          {
             NodeList children = parent.getChildNodes();

             for ( int j=0; j < children.getLength(); j++)
             {
                Node nn = children.item(j);
                String nodeName = nn.getNodeName();
                System.out.println("   " + nn.getNodeName() );

                Node child = nn.getFirstChild();
                if (child != null)
                {
                   System.out.println("   " + child.getNodeName() + ", " + child.getNodeValue());
                   if (child.getNodeValue() != null)
                   {
                       p.setProperty(getKeyName(parent, nn), child.getNodeValue());
                   }
                }
             }
             credentialTypes.add(p);
          }
       }
       return credentialTypes;
   }

   void  getExtendedProperties(NamedNodeMap attrs)
   {
      String name = null;
      String value = null;

      for (int k = 0; k < attrs.getLength(); k++)
      {
         Node a = attrs.item(k);
         System.out.println("  **  " + a.getNodeName() + ", " + a.getNodeValue());
         if (a.getNodeName().equals("name"))
         {
            name = a.getNodeValue();
         }
         else if (a.getNodeName().equals("value"))
         {
            value = a.getNodeValue();
         }
     }

      if (name != null && value != null)
      {
         super.put(name, value);
      }
   }

    void showProviderProperties()
    {
       showProperties();
       ArrayList csTypes = getCredentialTypeProperties();
       for (int i = 0; i < csTypes.size(); i++)
       {
           showProperties((Properties) csTypes.get(i));
       }
           
    }

    void showProperties(Properties props)
    {
        Enumeration enum = props.propertyNames();
        while (enum.hasMoreElements())
        {
           String pName = (String) enum.nextElement();
           System.out.println(pName + " = " + props.getProperty(pName));
        }
    }

    void showProperties()
    {
        Enumeration enum = super.propertyNames();
        while (enum.hasMoreElements())
        {
           String pName = (String) enum.nextElement();
           System.out.println(pName + " = " + super.getProperty(pName));
        }
    }

    public String getProviderType()
    {
        return _providerType;
    }

    public ArrayList getCredentialTypes()
    {
        ArrayList list = getCredentialTypeProperties();
        ArrayList types = new ArrayList();
        for (int i = 0; i < list.size(); i++)
        {
           Properties p = (Properties) list.get(i);
           types.add(p.getProperty(CredentialStoreEnv.CREDENTIAL_TYPE + ".name"));
        }
        return types;
    }

    public ArrayList getCredentialTypeProperties()
    {
       if (_credentialTypes != null && _credentialTypes.size() > 0)
       {
           Object o = _credentialTypes.get(0);
           if (o instanceof Node)
           {
              _credentialTypes = getCredentialTypes(((Node)o).getChildNodes());   
           }
       }
       return _credentialTypes;
    }

    public String getClassName()
    {
       return super.getProperty(CredentialStoreEnv.PROVIDER_CLASS);
    }
}



 


