package oracle.adf.share.security.credentialstore.spi;

import oracle.adf.share.security.credentialstore.Credential;

import java.util.ArrayList;
import java.util.Hashtable;

import java.io.Serializable;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * The credential store service provider interface.
 */
public interface CredentialStorage
{

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Initializes the credentialstore from the properties.
   * @param props the properties to initialize with
   */
   public void initialize(Hashtable props);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Store the credential using the specify credential key.
   * @param cred  the crdential to be stored
   * @param credKey  the credential key
   */
   public void storeCredential(Credential cred, String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Retrieves the credential for the specified credential key.
   * @param credKey  the credential key
   * @return the credential, or <code>null</code> if not found
   */
   public Credential fetchCredential(String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredential(String credKey);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Returns the serializable credential for the specified credential key for current user.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredentialForCurrentUser(String credKey);

 // /**
 //  * Retrieves a list of credentials 
 //  * @return a list of credentials 
 //  */
 //  public ArrayList fetchCredentials();

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Removes the credential specified credential idebtifier.
   * @param credKey  the credential key
   */
   public void removeCredential(String credKey);

 }

 


