/* $Header: ADFSecurityMessageBundle.java 14-nov-2006.19:40:43 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       10/05/05 - Creation
 */

/**
 *  @version $Header: ADFSecurityMessageBundle.java 14-nov-2006.19:40:43 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.security.resource;

import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Locale;

public final class ADFSecurityMessageBundle 
{
   private static final String ADF_SECURITY_BUNDLE = "oracle.adf.share.security.resource.ADFSecurityMessages";

   public static final String  EXC_INVALID_USER = "80100";
   public static final String  EXC_CREDENTIAL_STORE_INIT= "80101"; 
   public static final String  EXC_STORE_CREDENTIAL= "80102"; 
   public static final String  EXC_FETCH_CREDENTIAL= "80103"; 
   public static final String  EXC_FETCH_ALL_CREDENTIAL= "80104"; 
   public static final String  EXC_DELETE_CREDENTIAL= "80105"; 
   public static final String  EXC_CREDENTIAL_NOT_FOUND= "80106"; 
   public static final String  EXC_INVALID_SERIALIZABLE_CREDENTIAL= "80107"; 
   public static final String  EXC_UNSUPPORTED_CRDENTIAL_OPERATION= "80108"; 
   public static final String  EXC_UNSUPPORTED_SECURITY_CONFIG= "80109"; 
   public static final String  EXC_INVALID_CREDENTIAL_REALM = "80110"; 
   public static final String  EXC_INVALID_LOGOUT_PARAM = "80111"; 
   public static final String  EXC_INVALID_LOGIN_PARAM = "80112"; 
   public static final String  EXC_NO_AUTHENTICATED_USER = "80113"; 

   public static String format(String msg, Object[] values)
   {
      if (values != null)
      {
         return MessageFormat.format(msg, values);
      }

      return msg;
   }

   public static String getString(String key, Object[] values)
   {
       String msg = getString(key);
       return format(msg, values);
   }

   public static String getString(String key)
   {
      try
      {
         ResourceBundle b =  ResourceBundle.getBundle(ADF_SECURITY_BUNDLE,
                                                     Locale.getDefault());                      
         return b.getString(key);
      }
      catch (Exception e)
      {
      }
      return "";
  }
}

