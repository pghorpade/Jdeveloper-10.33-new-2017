/* Copyright (c) 2001, 2005, Oracle. All rights reserved.  */

package oracle.adf.share.security;

import java.util.ResourceBundle;

/**
** ADF Security runtime exception.
**/

public class CredentialNotFoundException extends ADFSecurityRuntimeException
{

   /**
   ** Constructs a CredentialNotFoundException with the specified detail message.
   ** @param msg  String detailed message
   */
   public CredentialNotFoundException(String msg)
   {
      super(msg);
   }

}
