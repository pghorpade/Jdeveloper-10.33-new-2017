/* $Header: ADFSecurityUtil.java 29-sep-2006.20:35:29 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       08/02/05 - Creation
 */

/**
 *  @version $Header: ADFSecurityUtil.java 29-sep-2006.20:35:29 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.security;

import java.util.logging.Level;
import java.util.Iterator;

import oracle.adf.share.logging.ADFLogger;

import javax.security.auth.Subject;
import java.security.Principal;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class ADFSecurityUtil
{
   private static ADFLogger _adfSecLogger = null;

   public static ADFLogger getADFLogger()
   {
     if (_adfSecLogger == null)
     {
        _adfSecLogger = ADFLogger.createADFLogger("oracle.adf.share.security");  //NO NLS
     }
     return _adfSecLogger;
   }

   public static boolean hasAnyoneRole(Subject subject)
   {
      if (subject != null)
      {
	 Iterator principalIterator = subject.getPrincipals().iterator();
	 while (principalIterator.hasNext())
	 {
	    Principal p = (Principal)principalIterator.next();
	    if (p.getName().equals(SecurityEnv.ADF_ANYONE_ROLE))
	    {
		return true;
	    }
	 }
      }

      return false;
   }

}

