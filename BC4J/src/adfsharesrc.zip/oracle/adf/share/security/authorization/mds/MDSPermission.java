package oracle.adf.share.security.authorization.mds;

import java.security.Permission;
import java.util.Vector;
import java.util.StringTokenizer;
import java.lang.reflect.Constructor;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * A class that represent permission for access to MDS resources.
 */
public class MDSPermission
   extends Permission
{
  public static final String METADATA_PERMISSION_READ = "Read";

  public static final String METADATA_PERMISSION_EDIT = "Edit";

  public static final String METADATA_PERMISSION_CUSTOMIZE = "Customize";

  public static final String METADATA_PERMISSION_CREATE = "Create";

  public static final String[] METADATA_PERMISSIONS = { METADATA_PERMISSION_READ, METADATA_PERMISSION_EDIT, METADATA_PERMISSION_CUSTOMIZE, METADATA_PERMISSION_CREATE };

  private String _actions = null;

  private Vector _actionsVector = null;

  private Permission _permission = null;

  /**
   * Constructs a permission with the specified name
   * @param name 
   */
  public MDSPermission(String name)
  {
    super(name);
    init(name);
  }

  /**
   * Constructs a permission with the specified name and actions
   * @param actions actions of the permission object being created
   * @param name name of the permission object being created
   */
  public MDSPermission(String name, String actions)
  {
    super(name);
    _actions = actions;
    Vector v = parseActions(actions);
    sort(v);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructs a permission from the specified permission object
   * @param p 
   */
  public MDSPermission(Permission p)
  {
    super(encode(p));
    if (p instanceof MDSPermission)
    {
      throw new IllegalArgumentException();
    }
    _permission = p;
  }

  /**
   * Initialize this instance.
   * @param name the encoded permission string
   */
  private void init(String name)
  {
    _permission = decode(name);
  }

  Permission decode(String name)
  {
    if (name == null)
    {
      throw new IllegalArgumentException();
    }
    StringTokenizer st = new StringTokenizer(name, "$");    //NOTRANS
    String pclass = st.nextToken();
    if (pclass.equals(MDSPermission.class.getName()))
    {
      System.out.println("**WARNING**: recursive MDSPermission");
      throw new IllegalArgumentException();
    }
    String pname = st.nextToken();
    String pactions = null;
    if (st.hasMoreElements())
    {
      pactions = st.nextToken();
    }
    Permission p = null;
    try
    {
      Class cls = Class.forName(pclass);
      Class[] params = new Class[2];
      params[0] = pname.getClass();
      params[1] = pname.getClass();
      Constructor ctr = cls.getConstructor(params);
      // NOTE: assume 2-string ctr
      p = (Permission)ctr.newInstance(new Object[]{ pname, pactions });
      if (p instanceof MDSPermission)
      {
        System.out.println("**WARNING**: recursive AdminPermission");
        throw new IllegalArgumentException();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace(System.err);
      throw new IllegalStateException(e.getMessage());
    }
    return p;
  }

  /**
   * @return actions
   */
  public java.lang.String getActions()
  {
    return _actions == null? "": _actions;
  }

  public int hashCode()
  {
    return this.getName().hashCode();
  }

  public boolean equals(Object obj)
  {
    if (!(obj instanceof MDSPermission))
      return false;
    MDSPermission that = (MDSPermission)obj;
    System.out.println("equals: " + that.getName());
    if (!this.getName().equalsIgnoreCase(that.getName()))
      return false;
    return that.getEmbeddedPermission().equals(getEmbeddedPermission());
  }

  public boolean implies(Permission permission)
  {
    if (!(permission instanceof MDSPermission))
    {
      return false;
    }
    boolean isImplies = false;
    MDSPermission p = (MDSPermission)permission;
    System.out.println("MDSPermission.implies( " + p.getName() + ", " + p.getActions() + ")");
    return true;
  }

  public String toString()
  {
    String s = new String("(MDSPermission ");
    s += getName//NOTRANS
    () + " " + _actions + ")";
    return s;
  }

  private Vector parseActions(String actions)
  {
    int begin = 0;
    int end = actions.indexOf(",", begin);
    String action;
    Vector actionsV = new Vector();
    if (end == -1)
    {
      actionsV.addElement//only 1 action
      (actions.toLowerCase());
      return actionsV;
    }
    while (end != -1)
    {
      action = actions.substring(begin, end);
      actionsV.addElement(action.toLowerCase());
      begin = end + 1;
      end = actions.indexOf(",", end + 1);
    }
    actionsV.addElement//get the last one
    (actions.substring(begin).toLowerCase());
    return actionsV;
  }

  private void sort(Vector actionsV)
  {
    if (actionsV.contains(PagePermission.PAGE_PERMISSION_VIEW))
    {
      actionsV.remove(PagePermission.PAGE_PERMISSION_VIEW);
      actionsV.add(METADATA_PERMISSION_READ);
    }
    _actionsVector = new //sort the actions
    Vector();
    for (int i = 0; i < actionsV.size(); i++)
    {
      String s = (String)actionsV.elementAt(i);
      for (int j = i + 1; j < actionsV.size(); j++)
      {
        if (s.compareTo(actionsV.elementAt(j)) > 0)
          s = (String)actionsV.set(j, s);
      }
      _actionsVector.add(i, s);
    }
    _actions = "";
    for (int i = 0; i < _actionsVector.size(); i++)
    {
      if (i > 0 && i < _actionsVector.size())
        _actions += ",";
      _actions += (String)_actionsVector.elementAt(i);
    }
  }

  /**
   * Encodes the specified permission into a canonical string
   * format.
   * 
   * @param p the permission to be encoded
   * @return the encoded string
   */
  private static String encode(Permission p)
  {
    if (p == null)
    {
      throw new IllegalArgumentException();
    }
    if (p.getClass() == MDSPermission.class)
    {
      throw new IllegalArgumentException();
    }
    StringBuffer sb = new // TO-DO: err msg
    StringBuffer();
    sb.append(p.getClass().getName());
    sb.append("$").append(p.getName());
    if (p.getActions() != null)
      sb.append("$").append(p.getActions());
    return sb.toString();
  }

  Permission getEmbeddedPermission()
  {
    return _permission;
  }

      
}


