package oracle.adf.share.security.authorization;

import java.io.IOException;
import java.io.Writer;
import java.util.*;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 *  Describes a permission target eg. "doAs" in java.security.AuthPermission
 */
public final class PermissionTargetDescriptor
{
    /** The display name */
    private String _name;
    /** The permission class */
    private String _value;

   /** 
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Constructs a PermissionTargetDescriptor
    * @param name the name of the action
    * @param value the value of the action.
    */
    public PermissionTargetDescriptor(String name, String value)
    {
      _name = name;
      _value = value;
    }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Accessor for name.
    * @return String the name of the target, used in the Permission.
    */
    public String getName()
    {
        return _name;
    }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * Accessor for value.
    * @return String the value of the target, used for display.
    */
    public String getValue()
    {
        return _value;
    }
}
