package oracle.adf.share.security.authorization;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Principal;
import oracle.adf.share.security.authorization.spi.PolicyInspection;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Provides management API to Java security policy.
 * Deals with the assignment of permissions or privileges to Principals
 * (which can be user or role Principals or any valid Principal).
 * 
 * <p>
 * The policy inspector delegates the requests to the concrete implementation of the
 * {@link oracle.adf.share.security.authorization.spi.PolicyInspection} service
 * provider interface. The following class relationship shows how the PolicyInspector
 * delegates to a concrete service provider that is based on an XML file based policy.
 * <pre>
 *    PolicyInspector ----> PolicyInspection (spi)
 *                               ^
 *                               |
 *                               |
 *                       XMLFilePolicyInspector (service provider example)
 * 
 * </pre>
 * 
 * <p>
 * <h3>Granting/Revoking Policies</h3>
 * 
 * In order for a grant/revocation to succeed, the grantor/revoker
 * (represented by the current Subject) must have the relevant permissions
 * granted to him/her.
 * 
 * This API also defines methods that change the persistent state of the
 * policy store (e.g. grant/revoke methods).
 */
public final class PolicyInspector
{

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Default constructor that creates the default PolicyInspection provider.
  * Reads the configuration to determine the default PolicyInspection
  * provider class
  */
 public PolicyInspector()
 {
   //TODO
 }
 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Constructs policy inspector and instantionates the provider class
  * based on the supplied classname.
  * @param providerClassname the PolicyInspection provider class to
  * instantiate.
  */
 public PolicyInspector(Class providerClassname)
 {
    try
    {
       _policyInspection = (PolicyInspection) providerClassname.newInstance();
    }
    catch (Exception ex)
    {
       ex.printStackTrace();
    }
 }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * @param provider a PolicyInspection instance.
  */
  public PolicyInspector(PolicyInspection inspection)
  {
    _policyInspection = inspection;
  }
  
  
 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Adds a Policy statement to the security Policy.
  * @param policyStatement the {@link PolicyStatement} to be added to the Policy.
  */
  public void addPolicyStatement(PolicyStatement policyStatement)
  {
    _policyInspection.addPolicyStatement(policyStatement);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Adds a Policy statement to the security Policy.
  * @param policyStatement the {@link PolicyStatement} to be added to the Policy.
  */
  public void removePolicyStatement(PolicyStatement policyStatement)
  {
    _policyInspection.removePolicyStatement(policyStatement);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Retrieves the list of explicit policy entries for the specified Principal.
  * @param principal the Principal for whom the Policy entries are to be retrieved.
  * @param permissionClasses the Permission classes to restrict the return resultset with.
  * @return PolicyStatement[] the {@link PolicyStatement}s given to the specified Principal.
 */
  public PolicyStatement[] getPolicyStatements(Principal principal, Class[] permissionClasses)
  {
    return _policyInspection.getPolicyStatements(principal, permissionClasses);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Retrieves the list of explicit policy entries for the specified resource id.
  * @param resourceId the target resource for which the policy statements are to be retrieved.
  * @param permissionClass the permission class of the  policy statement.
  * @return PolicyStatement[] the {@link PolicyStatement}s given to the specified Principal.
 */
  public PolicyStatement[] getPolicyStatements(String resourceId, Class permissionClass)
  {
    return _policyInspection.getPolicyStatements(resourceId, permissionClass);
  }


  /* Permission class descriptor management methods */

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Returns all the managed permission class descriptors.
  * @return PermissionClassDescriptor[] an array containing all the managed permission class descriptors.
 */
  public PermissionClassDescriptor[] getPermissionClassDescriptors()
  {
    return _policyInspection.getPermissionClassDescriptors();
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Retrieves the list of explicit policy entries for the specified resource id.
  * @param permClassDescriptor the permission class descriptor for the permission.
  * @return boolean true if this collection changed as a result of the call.
 */
  public boolean addPermissionClassDescriptor(PermissionClassDescriptor permClassDescriptor)
  {
    return _policyInspection.addPermissionClassDescriptor(permClassDescriptor);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Unregisters an existing permission class from the system.
  * @param permClass the class of the permission.
  * return boolean true if this list contained the specified element.
 */
  public boolean removePermissionClassDescriptor(Class permClass)
  {
    return _policyInspection.removePermissionClassDescriptor(permClass);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Returns specified permission class descriptor.
  * @param permClass the permission class.
  * @return PermissionClassDescriptor the {@link PermissionClassDescriptor} assocaiated with this permission class.
 */
  public PermissionClassDescriptor getPermissionClassDescriptor(Class permClass)
  {
    return _policyInspection.getPermissionClassDescriptor(permClass);
  }

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Refresh the policy provider 
  * @param save save changes
  */
  public void refresh(boolean save)
  {
     _policyInspection.refresh(save);
  }


  /** Peer delegate */
  private PolicyInspection _policyInspection;
}

