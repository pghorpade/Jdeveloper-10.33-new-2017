/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

package oracle.adf.share.security.authorization;

import java.security.Permission;
import java.util.Vector;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 * This class represents operation privilege on a datacontrol
 */
public class ADFPermission
   extends Permission
{
  protected String _actions = null;

  protected Vector _actionsVector = null;

  protected Pattern mPattern = null;
  private static transient String anyThing = ".*";   //Greedy Qualitifier

  /**
   * Constructs a permission with the specified name and actions
   * @param actions actions of the permission object being created
   * @param name name of the permission object being created
   */
  public ADFPermission(String name, String actions)
  {
    super(name);
    if (actions == null)
    {
      String err = "Invalid parameter: actions cannot be null";
      throw new IllegalArgumentException(err);
    }

    sort(parseActions(actions));
  }

  public java.lang.String getActions()
  {
    return _actions;
  }

  public boolean equals(Object obj)
  {
    if (!(obj instanceof ADFPermission))
      return false;
    ADFPermission p = (ADFPermission)obj;
    System.out.println("equals: " + p.getName());
    if (!this.getName().equalsIgnoreCase(p.getName()))
      return false;
    return _actions.equals(p.getActions());
  }

  public boolean implies(Permission permission)
  {
    if (!(permission instanceof ADFPermission))
    {
      return false;
    }

    boolean isImplies = false;
    ADFPermission p = (ADFPermission)permission;
   
    if (!getName().equals("*"))
    {
       isImplies = getName().equalsIgnoreCase(p.getName());
       if (!isImplies)
       {
          isImplies = isPatternMatch(p.getName());
       }
    }
    else 
    {
       isImplies = true;
    }
  
    if (isImplies == false)
    {
       return false;
    }

    //check if p's actions are a subset of this actions
    Vector v = parseActions(permission.getActions());
    for (int i = 0; i < v.size(); i++)
    {
      if (!_actionsVector.contains(v.elementAt(i)))
      {
         return false;
      }
    }
    return true;
  }

  public int hashCode()
  {
     return toString().hashCode();
  }

  public String toString()
  {
     String s = new String("(ADFPermission "); //NOTRANS
     s += getName() + "/" + _actions;
     return s;
  }

  public static Vector parseActions(String actions)
  {
    int begin = 0;
    int end = actions.indexOf(",", begin);
    String action;
    Vector actionsV = new Vector();
    if (end == -1)
    {
      //only 1 action
      actionsV.addElement(actions.toLowerCase());
      return actionsV;
    }
    while (end != -1)
    {
      action = actions.substring(begin, end);
      actionsV.addElement(action.toLowerCase());
      begin = end + 1;
      end = actions.indexOf(",", end + 1);
    }
    //get the last one
    actionsV.addElement(actions.substring(begin).toLowerCase());
    return actionsV;
  }

  protected void sort(Vector actionsV)
  {
    //sort the actions
    _actionsVector = new Vector();
    for (int i = 0; i < actionsV.size(); i++)
    {
      String s = (String)actionsV.elementAt(i);
      for (int j = i + 1; j < actionsV.size(); j++)
      {
        if (s.compareTo(actionsV.elementAt(j)) > 0)
          s = (String)actionsV.set(j, s);
      }
      _actionsVector.add(i, s);
    }
    _actions = "";
    for (int i = 0; i < _actionsVector.size(); i++)
    {
      if (i > 0 && i < _actionsVector.size())
        _actions += ",";
      _actions += (String)_actionsVector.elementAt(i);
    }
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static PermissionActionDescriptor[] getPermissionActionDescriptors()
   {
       return null;
   }                

   protected boolean isPatternMatch(String sMatch)
   {
      if (mPattern == null)
      {
	 if (sMatch.equals("*"))
         {
	    mPattern = Pattern.compile(".*");
         }
	 else
         {
	    mPattern = Pattern.compile(getName());
         }
      }
      Matcher matcher = mPattern.matcher(sMatch);
      return matcher.matches();
   }
}


