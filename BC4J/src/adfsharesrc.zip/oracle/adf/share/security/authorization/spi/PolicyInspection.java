package oracle.adf.share.security.authorization.spi;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Principal;
import oracle.adf.share.security.authorization.PolicyStatement;
import oracle.adf.share.security.authorization.PermissionClassDescriptor;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Service Provider Interface for Security Policy Inspection.
 * Service providers must implement this interface and register with the
 * policy inspector.
*/
public interface PolicyInspection
{
/**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Adds a Policy statement to the security Policy.
  * @param policyStatement the {@link PolicyStatement} to be added to the Policy.
  */
  public void addPolicyStatement(PolicyStatement policyStatement);

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Removes a Policy statement from the security Policy.
  * @param policyStatement the {@link PolicyStatement} to be added to the Policy.
  */
  public void removePolicyStatement(PolicyStatement policyStatement);

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Retrieves the list of explicit policy entries for the specified Principal.
  * @param principal the Principal for whom the Policy entries are to be retrieved.
  * @param permissionClasses the Permission classes to restrict the return resultset with.
  * @return PolicyStatement[] the {@link PolicyStatement}s given to the specified Principal.
  */
  public PolicyStatement[] getPolicyStatements(Principal principal, Class[] permissionClasses);

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Retrieves the list of explicit policy entries for the specified resource id.
  * @param resourceId the target resource for which the policy statements are to be retrieved.
  * @param permissionClass the permission class of the  policy statement.
  * @return PolicyStatement[] the {@link PolicyStatement}s given to the specified Principal.
  */
  public PolicyStatement[] getPolicyStatements(String resourceId, Class permissionClass);


 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Returns all the managed permission class descriptors.
  * @return PermissionClassDescriptor[] an array containing all the managed permission class descriptors.
  */
  public PermissionClassDescriptor[] getPermissionClassDescriptors();

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Adds a definition for a new Permission class.
  * @param permClassDescriptor the permission class descriptor for the permission.
  * @return boolean true if this collection changed as a result of the call.
  */
  public boolean addPermissionClassDescriptor(PermissionClassDescriptor permClassDescriptor);

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Unregisters an existing Permission class from the system.
  * @param permClass the class of the permission.
  * return boolean true if this list contained the specified element.
  */
  public boolean removePermissionClassDescriptor(Class permClass);

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Returns specified permission class descriptor.
  * @param permClass the permission class.
  * @return PermissionClassDescriptor the {@link PermissionClassDescriptor} assocaiated with this permission class.
  */
  public PermissionClassDescriptor getPermissionClassDescriptor(Class permClass);


 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * Refresh policy provider.  
  * @param save save changes
  */
  public void refresh(boolean save);
}
