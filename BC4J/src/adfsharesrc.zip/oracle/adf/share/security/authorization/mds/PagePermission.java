/* Copyright (c) 2004, 2005, Oracle. All rights reserved.  */

package oracle.adf.share.security.authorization.mds;

import java.security.Permission;
import java.util.Vector;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * This class represents access to a page
 */
public class PagePermission
   extends Permission
{
  public static final String PAGE_PERMISSION_VIEW = "View";

  public static final String PAGE_PERMISSION_PERSONALIZE = "Personalize";

  public static final String PAGE_PERMISSION_CUSTOMIZE = "Customize";

  public static final String PAGE_PERMISSION_CREATE = "Create";

  public static final String PAGE_PERMISSION_CLONE = "Clone";

  public static final String PAGE_PERMISSION_GRANT = "Grant";

  public static final String[] PAGE_PERMISSIONS = { PAGE_PERMISSION_VIEW, PAGE_PERMISSION_PERSONALIZE, PAGE_PERMISSION_CUSTOMIZE, PAGE_PERMISSION_CREATE, PAGE_PERMISSION_CLONE, PAGE_PERMISSION_GRANT };

  private String _actions = null;

  private Vector _actionsVector = null;

  /**
   * Constructs a permission with the specified name and actions
   * @param actions actions of the permission object being created
   * @param name name of the permission object being created
   */
  public PagePermission(String name, String actions)
  {
    super(name);
    if (actions == null)
    {
      String err = "Invalid parameter: actions cannot be null";
      throw new IllegalArgumentException(err);
    }
    Vector v = parseActions(actions);
    sort(v);
  }

  public java.lang.String getActions()
  {
    return _actions;
  }

  public boolean equals(Object obj)
  {
    if (!(obj instanceof PagePermission))
      return false;
    PagePermission p = (PagePermission)obj;
    System.out.println("equals: " + p.getName());
    if (!this.getName().equalsIgnoreCase(p.getName()))
      return false;
    return _actions.equals(p.getActions());
  }

  public boolean implies(Permission permission)
  {
    if (!(permission instanceof PagePermission))
    {
      return false;
    }
    boolean isImplies = false;
    PagePermission p = (PagePermission)permission;
    System.out.println("PagePermission.implies( " + p.getName() + ", " + p.getActions() + ")");
    if (!getName().equals("*"))
    {
      isImplies = getName().equalsIgnoreCase(p.getName());
    }
    else 
    {
      isImplies = true;
    }
    if (isImplies == false)
    {
      System.out.println("Permission name different");
      return false;
    }
    //check if p's actions are a subset of this actions
    Vector v = parseActions(permission.getActions());
    for (int i = 0; i < v.size(); i++)
    {
      if (!_actionsVector.contains(v.elementAt(i)))
      {
        System.out.println("Compared to permission " + p.toString());
        return false;
      }
    }
    return true;
  }

  public int hashCode()
  {
    return _actions.hashCode();
  }

  public String toString()
  {
    String s = new String("(PagePermission ");
    //NOTRANS
    s += getName() + " " + _actions + ")";
    return s;
  }

  private Vector parseActions(String actions)
  {
    int begin = 0;
    int end = actions.indexOf(",", begin);
    String action;
    Vector actionsV = new Vector();
    if (end == -1)
    {
      //only 1 action
      actionsV.addElement(actions.toLowerCase());
      return actionsV;
    }
    while (end != -1)
    {
      action = actions.substring(begin, end);
      actionsV.addElement(action.toLowerCase());
      begin = end + 1;
      end = actions.indexOf(",", end + 1);
    }
    //get the last one
    actionsV.addElement(actions.substring(begin).toLowerCase());
    return actionsV;
  }

  private void sort(Vector actionsV)
  {
    //sort the actions
    _actionsVector = new Vector();
    for (int i = 0; i < actionsV.size(); i++)
    {
      String s = (String)actionsV.elementAt(i);
      for (int j = i + 1; j < actionsV.size(); j++)
      {
        if (s.compareTo(actionsV.elementAt(j)) > 0)
          s = (String)actionsV.set(j, s);
      }
      _actionsVector.add(i, s);
    }
    _actions = "";
    for (int i = 0; i < _actionsVector.size(); i++)
    {
      if (i > 0 && i < _actionsVector.size())
        _actions += ",";
      _actions += (String)_actionsVector.elementAt(i);
    }
  }

}


