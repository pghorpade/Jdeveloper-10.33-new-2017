package oracle.adf.share.security.authorization;
import java.security.Permission;
import java.security.Principal;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Represents an explicit grant in a security Policy.
 * The following is an example of a Policy statement in
 * jdk's default Policy file.
 * <pre>
 *    grant Principal com.foo.UserPrincipal "fred"
 *    {
 *       permission java.io.FilePermission   "file:D:/sample/foo.txt", "read,write";
 *       permission com.foo.CustomPermission "mySpreadSheet", "open,close";
 *     };
 * </pre>
 * The above PolicyStatement represents granting of two permission
 * to a Principal "fred"
 */
public class PolicyStatement
{
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructs a PolicyStatement for a given Principal and permission.
   * @param grantee the {@link Principal} associated with this PolicyStatement.
   * @param permission the {@link Permission} associated with this PolicyStatement.
   */
  public PolicyStatement(Principal grantee, Permission permission)
  {
    this._grantee = grantee;
    this._permission = permission;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Accessor for the Principal associated with this PolicyStatement
   * @return Principal the grantee associated with this PolicyStatement.
   */
  public Principal getPrincipal()
  {
    return _grantee;
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Accessor for the Permissions assocated with this grantee
   * @return Permission the permission associated with this PolicyStatement.
   */
  public Permission getPermission()
  {
    return _permission;
  }

  private Permission _permission;
  private Principal _grantee;
}
