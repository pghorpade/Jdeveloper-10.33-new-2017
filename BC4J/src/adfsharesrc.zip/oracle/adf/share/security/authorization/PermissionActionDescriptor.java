package oracle.adf.share.security.authorization;

import java.io.IOException;
import java.io.Writer;
import java.util.*;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 *  Describes a permission action e.g., "read", "write" actions
 *  for the java.io.FilePermission.
 */
public final class PermissionActionDescriptor
{
    /** The name of the action, used in the Permission */
    private String _name;
    /** The display value of the action, for presentation to the user */
    private String _value;

    /** 
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Constructs a PermissionActionDescriptor
     * @param name the name of the action used within the Permission
     * @param value the name of the action to display on a user interface
     */
    public PermissionActionDescriptor(String name, String value)
    {
      _name = name;
      _value = value;
    }
    
    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for name.
     * @return String the name of the action.
     */
    public String getName()
    {
        return _name;
    }

    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for value.
     * @return String the value of the action to use for display.
     */
    public String getValue()
    {
        return _value;
    }
}
