/* $Header: DataControlPermission.java 22-nov-2005.10:26:10 ychua Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       04/04/05 - 
    ychua       03/17/05 - Creation
 */

/**
 *  @version $Header: DataControlPermission.java 22-nov-2005.10:26:10 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.security.authorization;

import java.util.Vector;
import java.security.Permission;
import oracle.adf.share.security.authorization.ADFPermission;

/**
 * This class represents operation privilege on a datacontrol
 */
public class DataControlPermission extends ADFPermission
{
   public static final String GRANT_ACTION = "Grant";
   public static final String CREATE_ACTION = "Create";
   public static final String EDIT_ACTION = "Edit";
   public static final String VIEW_ACTION = "View";
 
   static final PermissionActionDescriptor[] mActionDescriptors =
   {
      new  PermissionActionDescriptor("GRANT", GRANT_ACTION ),
      new  PermissionActionDescriptor("CREATE",CREATE_ACTION),
      new  PermissionActionDescriptor("EDIT",  EDIT_ACTION),
      new  PermissionActionDescriptor("VIEW",  VIEW_ACTION),
   };
   /**
    * Constructs a permission with the specified name and actions
    * @param actions actions of the permission object being created
    * @param name name of the permission object being created
    */
   public DataControlPermission(String name, String actions)
   {
     super(name, actions);
   }
 
   public boolean equals(Object obj)
   {
     if (!(obj instanceof DataControlPermission))
       return false;
     DataControlPermission p = (DataControlPermission)obj;
     System.out.println("equals: " + p.getName());
     if (!this.getName().equalsIgnoreCase(p.getName()))
       return false;
     return _actions.equals(p.getActions());
   }
 
   public boolean implies(Permission permission)
   {
     if (!(permission instanceof DataControlPermission))
     {
       return false;
     }
     boolean isImplies = false;
     DataControlPermission p = (DataControlPermission)permission;
     System.out.println("DataControlPermission.implies( " + p.getName() + ", " + p.getActions() + ")");
     if (!getName().equals("*"))
     {
        isImplies = getName().equalsIgnoreCase(p.getName());
     }
     else 
     {
        isImplies = true;
     }
   
     if (isImplies == false)
     {
        System.out.println("Permission name different");
        return false;
     }
 
     //check if p's actions are a subset of this actions
     Vector v = parseActions(permission.getActions());
     for (int i = 0; i < v.size(); i++)
     {
       if (!_actionsVector.contains(v.elementAt(i)))
       {
         System.out.println("Compared to permission " + p.toString());
         return false;
       }
     }
     return true;
   }
 
   public int hashCode()
   {
      return toString().hashCode();
   }
 
   public String toString()
   {
      String s = new String("(DataControlPermission "); //NOTRANS
      s += getName() + "/" + _actions;
      return s;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public static PermissionActionDescriptor[] getPermissionActionDescriptors()
   {
       return mActionDescriptors;
   }                
}

