package oracle.adf.share.security.authorization;

import java.io.IOException;
import java.io.Writer;
import java.util.*;
import java.security.Permission;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Describes a security {@link Permission} class.
 * A descriptor i.e the metadata for a permission is composed of a display name,
 * the Class that this permission points to, an array of possible actions
 * and array of possible targets.
  */
public final class PermissionClassDescriptor
{
   /** Constructs a PermissionClassDescriptor
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * @param displayName the display displayName
    * @param permissionClass the Permission Class
    * @param actionDescriptors a collection of action descriptors
    */
    public PermissionClassDescriptor(String displayName, Class permissionClass, 
                                      PermissionActionDescriptor[] actionDescriptors,
                                      PermissionTargetDescriptor[] targetDescriptors)
    {
      _displayName = displayName;
      _permissionClass = permissionClass;
      _actionDescriptors = actionDescriptors;
      _targetDescriptors  = targetDescriptors;
    }
    
    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for displayName.
     * @return String the displayName of the action.
     */
    public String getDisplayName()
    {
        return _displayName;
    }

    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for the permission class.
     * @return Class the permission class
     */
    public Class getPermissionClass()
    {
        return _permissionClass;
    }

    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for the permission action descriptors.
     * @return PermissionActionDescriptor the permission action descriptors.
     */
    public PermissionActionDescriptor[] getPermissionActionDescriptors()
    {
        return _actionDescriptors;
    }

    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * Accessor for the permission target descriptors.
     * @return PermissionActionDescriptor the permission target descriptors.
     */
    public PermissionTargetDescriptor[] getPermissionTargetDescriptors()
    {
        return _targetDescriptors;
    }

    /** The display displayName */
    private String _displayName;
    /** The permission class */
    private Class _permissionClass;
    /** Collection of action descriptors */
    private PermissionActionDescriptor[] _actionDescriptors;
    private PermissionTargetDescriptor[] _targetDescriptors;
}
