package oracle.adf.share.security.authorization;

import java.security.CodeSource;
import java.security.Principal;
/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * Represents a grantee in a policy statement. For example
 * in the following grant in the default jdk policy, 
 * the Grantee represents a combination of the Principal and
 * the codebase:
 * <pre>
 *    grant codebase "file:D:/sample/-" 
 *          Principal com.foo.UserPrincipal "fred"
 *    {
 *       permission java.io.FilePermission   "file:D:/sample/foo.txt", "read,write";   
 *     };
 * </pre>
 * Either codebase and/or Grantee can be null in which case the Grantee
 * will represent a global entity.
 * */
 
public class Grantee 
{
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Default constructor.
   * Refers to a global grantee, ie. applicable
   * to all codesources and Principals.
   * 
   */
  public Grantee()
  {
    this(null, null);
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructs a grantee that refers to a specific
   * user (Principal) but applicable for all codesources.
   * @param principal the {@link Principal} to be associated with this grantee.
   */
  public Grantee(Principal principal)
  {
    this(principal, null);
  }
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Constructs a grantee that refers to a specific codesource and Principal.
   * @param principal the {@link Principal} to be associated with this grantee.
   * @param codesource the {@link CodeSource} to be associated with this grantee.
   */
  public Grantee(Principal principal, CodeSource codesource)
  {
    this._principal = principal;
    this._cs = codesource;
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Modifier for the user associated with this grantee.
   * @param principal the {@link Principal} to be associated with this grantee.
   */
  protected void setPrincipal(Principal principal)
  {
      _principal = principal;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Modifier for the codesource associated with this grantee.
   * @param codesource the {@link CodeSource} to be associated with this grantee.
   */
  protected void setCodeSource(CodeSource codesource)
  {
      _cs = codesource;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Accessor for the Principal associated with this grantee.
   * @return principal the {@link Principal} associated with this grantee.
   */
  public Principal getPrincipal()
  {
      return _principal;
  }
  
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Accessor for the codesource associated with this grantee.
   * @return CodeSource the {@link CodeSource} associated with this grantee.
   */
  public CodeSource getCodeSource()
  {
      return _cs;
  }

 
  private boolean matches(Grantee grantee)
  {
      if(getCodeSource() != null)
      {
          if(grantee.getCodeSource() == null)
          {
              return false;
          }
          if(!getCodeSource().equals(grantee.getCodeSource()))
          {
              return false;
          }
      } else
      if(grantee.getCodeSource() != null)
      {
          return false;
      }

      if(_principal != null)
      {
          if(grantee.getPrincipal() == null)
          {
              return false;
          }
          if (_principal.equals(grantee.getPrincipal()) )
          {
              return false;
          }

      } else if(grantee.getPrincipal() != null)
      {
          return false;
      }
      return true;
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * Compares two grantees.
   */
  public boolean equals(Object obj)
  {
      if(obj instanceof Grantee)
      {
          Grantee grantee = (Grantee)obj;
          return matches(grantee);
      } else
      {
          return false;
      }
  }
  private Principal _principal;
  private CodeSource _cs;
}
