/* $Header: AttributePermission.java 27-mar-2006.11:58:12 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       06/07/05 - 
    ychua       05/04/05 - 
    ychua       04/13/05 - 
    ychua       04/04/05 - 
    ychua       03/17/05 - Creation
 */

/**
 *  @version $Header: AttributePermission.java 27-mar-2006.11:58:12 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.security.authorization;

import java.util.Vector;
import java.security.Permission;
import oracle.adf.share.security.authorization.ADFPermission;

/**
 * This class represents operation privilege on a attribute
 */
public class AttributePermission extends ADFPermission
{
   public static final String READ_ACTION = "Read";
   public static final String UPDATE_ACTION = "Update";
          
   static final PermissionActionDescriptor[] mActionDescriptors =
   {
      new  PermissionActionDescriptor("READ", READ_ACTION),
      new  PermissionActionDescriptor("UPDATE", UPDATE_ACTION),
   };
   /**
    * Constructs a permission with the specified name and actions
    * @param actions actions of the permission object being created
    * @param name name of the permission object being created
    */
   public AttributePermission(String name, String actions)
   {
     super(name, actions);
   }
 
   public boolean equals(Object obj)
   {
     if (!(obj instanceof AttributePermission))
       return false;
     AttributePermission p = (AttributePermission)obj;
     if (!this.getName().equalsIgnoreCase(p.getName()))
       return false;
     return _actions.equals(p.getActions());
   }
 
   public boolean implies(Permission permission)
   {
     if (!(permission instanceof AttributePermission))
     {
       return false;
     }

     AttributePermission p = (AttributePermission)permission;
     boolean isImplies = super.implies(p);
     if (isImplies == false)
     {
        return false;
     }
 
     //check if p's actions are a subset of this actions
     Vector v = parseActions(permission.getActions());
     for (int i = 0; i < v.size(); i++)
     {
       if (!_actionsVector.contains(v.elementAt(i)))
       {
          return false;
       }
     }
     return true;
   }
 
   public int hashCode()
   {
      return toString().hashCode();
   }
 
   public String toString()
   {
      String s = new String("(AttributePermission "); //NOTRANS
      s += getName() + "/" + _actions;
      return s;
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
   public static PermissionActionDescriptor[] getPermissionActionDescriptors()
   {
       return mActionDescriptors;
   }                
}


