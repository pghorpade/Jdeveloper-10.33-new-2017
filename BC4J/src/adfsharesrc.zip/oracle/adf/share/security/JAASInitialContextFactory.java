package oracle.adf.share.security;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.spi.InitialContextFactory;
import java.net.URL;
import java.net.URLClassLoader;


/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 */
public class JAASInitialContextFactory implements InitialContextFactory 
{
   static final String JAZN_LOGINMODULE = "oracle.security.jazn.realm.RealmLoginModule";
   static final String JAZN_JAR = "jazn.jar";
   static final String JAZN_XML = "config/jazn.xml";
   static final String ADFS_JAZN_JAR = "adfs-jazn.jar";

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public Context getInitialContext(Hashtable env) throws NamingException
   {
      Context ctx = null;
      String contextName = (env != null) ? (String)env.get(SecurityEnv.PROP_JAAS_CONTEXT_FACTORY) : null;
      
      if ( contextName == null )
      {
         if (useJAZN())
         {
            contextName = SecurityEnv.JAAS_CONTEXT_JAZN;
         }
         else
         {
            contextName = SecurityEnv.JAAS_CONTEXT_DEFAULT;
         }
      }

      try
      {
         Class cls = Class.forName(contextName);
         ctx = (Context)cls.getConstructor(new Class[]{Hashtable.class}).newInstance(new Object[]{env});
      }
      catch (Exception e)
      {
         if (!contextName.equals(SecurityEnv.JAAS_CONTEXT_DEFAULT))
         {
            try
            {
               Class cls = Class.forName(SecurityEnv.JAAS_CONTEXT_DEFAULT);
               ctx = (Context)cls.getConstructor(new Class[]{Hashtable.class}).newInstance(new Object[]{env});
            }
            catch (Exception e2)
            {
               NamingException ne = new NamingException(e2.getMessage());
               ne.setRootCause(e2);
               throw ne;
            }
         }
      }
     return ctx;
   }

   boolean useJAZN()
   {
      try
      {
         Class cls = Class.forName(JAZN_LOGINMODULE);
         ClassLoader cl = cls.getClassLoader();
         if (cl instanceof URLClassLoader)
         {
            URL[] urls = ((URLClassLoader)cl).getURLs();
            for (int i=0; i < urls.length; i++)
            {
               String str = urls[i].getFile();
               str = java.net.URLDecoder.decode(str);

               if (str.endsWith(JAZN_JAR) && !str.endsWith(ADFS_JAZN_JAR) )
               {
                  return true;
               }
            }
         }
         else
         {
            if (cl.loadClass(JAZN_LOGINMODULE) != null)
               return true;
            else
               return false;
         }
      }
      catch (Exception e)
      {
      }
      return false;
   }
}
