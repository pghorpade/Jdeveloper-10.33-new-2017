/* Copyright (c) 2001, 2005, Oracle. All rights reserved.  */

package oracle.adf.share.security;

import java.util.ResourceBundle;

/**
** ADF Security runtime exception.
**/

public class ADFSecurityRuntimeException extends RuntimeException
{
   private ADFSecurityException mADFSecurityException = null;

   /**
   ** Constructs a ADFSecurityRuntimeException with the specified detail message.
   ** @param msg  String detailed message
   */
   public ADFSecurityRuntimeException(String msg)
   {
      super(msg);
   }


   /**
   ** Constructor
   **
   ** @param      cause        parent exception that caused this one
   */
   public ADFSecurityRuntimeException(Throwable cause)
   {
      super(cause);
      mADFSecurityException = new ADFSecurityException(cause);
   }


   /**
   ** Constructor
   **
   ** @param      msgKey        the error message lookup key
   ** @param      msgArgs       Object array for the messageFormatting or null
   */
   public ADFSecurityRuntimeException(String msgKey, Object[] msgArgs)
   {
      this(null, msgKey, null, msgArgs);
   }
   
   
   /**
   ** Constructor
   **
   ** @param      cause         parent exception that caused it or null
   ** @param      msgKey        the error message lookup key
   ** @param      msgArgs       Object array for the messageFormatting or null
   */
   public ADFSecurityRuntimeException(Throwable cause, String msgKey, Object[] msgArgs)
   {
      this(cause, msgKey, null, msgArgs);
   }
   
   
   /**
   ** Constructor
   **
   ** @param  cause           Parent exception that caused it
   ** @param  msgKey          The error message lookup key
   ** @param  resourceBundle  The resource bundle or null to use the default
   ** @param  msgArgs         Object array for the messageFormatting or null
   */
   public ADFSecurityRuntimeException(Throwable      cause, 
                              String         msgKey,
                              ResourceBundle resourceBundle,
                              Object[]       msgArgs)
   {
      super(cause);
      mADFSecurityException = 
               new ADFSecurityException(cause, msgKey, resourceBundle, msgArgs);
   }


   public String getLocalizedMessage()
   {
      if ( mADFSecurityException != null )
      {
          return mADFSecurityException.getLocalizedMessage();
      }
      else
      {
          return super.getLocalizedMessage();
      }
   }
}
