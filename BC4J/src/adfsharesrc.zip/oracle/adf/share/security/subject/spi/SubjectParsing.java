package oracle.adf.share.security.subject.spi;
import java.security.Principal;
import java.util.Set;
import javax.security.auth.Subject;

/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 *
 * Finder for Principal from a Subject.
 */
public interface SubjectParsing
{
  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Gets the user Principal associated with a Subject.
   * A Subject typically contains multiple Principals.
   * This method provides access to the
   * Principal that is the "User" principal or the primary principal.
   * @param subject the Subject that needs to be inspected
   * @return Principal the found user Principal
   */
  public Principal getUserPrincipal(Subject subject);

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Gets the Role Principals associated with a Subject.
   * A Subject typically contains multiple Principals.
   * This method provides access to the
   * Principal that is the "Role" principal or the secondary principals.
   * @param subject the Subject that needs to be inspected
   * @return Set the found role Principals
   */
  public Set getRolePrincipals(Subject subject);
}
