package oracle.adf.share.security.subject.serviceproviders.adf;
import java.security.Principal;
import java.util.Set;
import javax.security.auth.Subject;
import java.security.AccessControlContext;
import java.security.AccessController;
import oracle.adf.share.security.authentication.spi.UserPrincipal;
import oracle.adf.share.security.authentication.spi.RolePrincipal;
import com.evermind.security.Group;
import com.evermind.security.MemoryUser;
import oracle.security.jazn.realm.RealmUser;
import oracle.security.jazn.realm.RealmRole;
import java.util.logging.Logger;
import java.util.logging.Level;

import oracle.adf.share.security.subject.spi.SubjectParsing;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 *
 * Finder for Principal from a Subject.
 * BI Specific implementation of the pluggable SubjectParsing.
 */
public class ADFSubjectParsing implements SubjectParsing
{
  /**
   * {@inheritDoc}
   */
  public Principal getUserPrincipal(Subject subject)
  {
    if( subject != null )
    {
      Set principals = subject.getPrincipals();
      //if the subject has no principals, return null;
      if( principals == null || principals.size() <= 0 )
      {
        return null;
      }
      //If there is only one principal, then return that principal as the user principal
      else if(principals.size() == 1 )
      {
        return (Principal)(principals.toArray()[0]);
      }
      else //principals.size() > 1
      {
        //first check if there is "UserPrincipal"
        Set userPrincipals = subject.getPrincipals(UserPrincipal.class);
        //cannot have more than one user principals
        if( userPrincipals.size() > 1 )
        {
          _logger.warning("A Subject cannot contain more than one user Principals");
          throw new IllegalStateException("A Subject cannot contain more than one user Principals");
        }
        //if there is only one user principal, return that
        else if (userPrincipals.size() == 1 )
        {
           Principal p = (Principal)(userPrincipals.toArray()[0]);
           return p;
        }
        //if no user principals found, check if an SSO or JAZN principal exists
        else //(userPrincipals.size() < 1 )
        {
          //check for JAZN Principals
          Set jaznUserPrincipals = subject.getPrincipals(RealmUser.class);
          if(jaznUserPrincipals.size() == 1 )
          {
            return (Principal)(jaznUserPrincipals.toArray()[0]);
          }
          //check for SSO Principals
          Set ssoUserPrincipals = subject.getPrincipals(MemoryUser.class);
          if(ssoUserPrincipals.size() == 1 )
          {
            return (Principal)(ssoUserPrincipals.toArray()[0]);
          }
          _logger.warning("No known user principal found in the Subject");
          throw new IllegalStateException("No known user principal found in the Subject");
        }
      }
    }
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public Set getRolePrincipals(Subject subject)
  {
    //first check if there is "RolePrincipal"
    Set rolePrincipals = subject.getPrincipals(RolePrincipal.class);
    //cannot have more than one user principals
    if( rolePrincipals.size() > 0 )
    {
      return rolePrincipals;
    }
    //now check jazn principals
    Set jaznRolePrincipals = subject.getPrincipals(RealmRole.class);
    if(jaznRolePrincipals.size() == 1 )
    {
      return jaznRolePrincipals;
    }
    //now check sso principals
    Set ssoRolePrincipals = subject.getPrincipals(Group.class);
    if(ssoRolePrincipals.size() == 1 )
    {
      return ssoRolePrincipals;
    }

    //none of the known Role Principals found... return null
    return null;
  }
  /**the static logger reference */
  private static Logger _logger = Logger.getLogger(ADFSubjectParsing.class.getName());
}
