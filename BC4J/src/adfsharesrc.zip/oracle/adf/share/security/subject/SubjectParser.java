package oracle.adf.share.security.subject;
import java.security.Principal;
import java.util.Set;
import javax.security.auth.Subject;
import oracle.adf.share.security.subject.spi.SubjectParsing;
import oracle.adf.share.security.subject.serviceproviders.adf.ADFSubjectParsing;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 *
 * Provides utility methods for a user's Subject.
 * Access methods for getting a user's User and Role Principals.
 * Uses the pluggable SubjectParsing to get the principals.
 */
public final class SubjectParser
{

 /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  */
  public static SubjectParser getInstance()
  {
     return _singleton;
  }


  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Gets the user Principal associated with a Subject.
   * A Subject typically contains multiple Principals.
   * This utility method provides access to the
   * Principal that is the "User" principal or the primary principal.
   * It uses a pluggable SubjectParsing to determine
   * which of all the Principals is the real one
   * @param subject the Subject that needs to be inspected
   * @return Principal the found user Principal
   */
  public final Principal getUserPrincipal(Subject subject)
  {
    return _subjectParsing.getUserPrincipal(subject);
  }

  /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   *
   * Gets the Role Principals associated with a Subject.
   * A Subject typically contains multiple Principals.
   * This method provides access to the
   * Principal that is the "Role" principal or the secondary principals.
   * @param subject the Subject that needs to be inspected
   * @return Set the found role Principals
   */
  public final Set getRolePrincipals(Subject subject)
  {
    return _subjectParsing.getRolePrincipals(subject);
  }



  private SubjectParsing _subjectParsing = new oracle.adf.share.security.subject.serviceproviders.adf.ADFSubjectParsing();

  private static SubjectParser _singleton = new SubjectParser();

}
