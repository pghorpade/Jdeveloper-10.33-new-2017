package oracle.adf.share.security.authentication;

import java.security.Principal;

public class ADFUserPrincipal implements Principal {
    protected String _name;
    String _canonicalName; 
    
    public ADFUserPrincipal() {
    
       this("anonymous");
    }
    public ADFUserPrincipal(String name) {
    
       this._name = name;
       _canonicalName = (getClass().getName() + _name).toLowerCase();

    }
     /**
      * Returns a string representation of this principal.
      * @return a string representation of this principal.
      */
     public String toString()
     {
       return "[ADFUserPrincipal]: "+ _name;
     }


     /**
      * Returns the name of this principal.
      * @return the name of this principal.
      */
     public String getName()
     {
       return _name;
     }

    /**
     * Compares this principal to the specified object.
     * @param another principal to compare with.
     *
     * @return true if the principal passed in is the same as that
     * encapsulated by this principal, and false otherwise.
     */
     public boolean equals(Object another)
     {
       if( another != null && another instanceof ADFUserPrincipal )
       {
         ADFUserPrincipal anotherUserPrincipal = (ADFUserPrincipal)another;
         return this._name.equals(anotherUserPrincipal._name);
       }
       return false;
     }

     public int hashCode()
     {
        return _canonicalName.hashCode();
     }
}
