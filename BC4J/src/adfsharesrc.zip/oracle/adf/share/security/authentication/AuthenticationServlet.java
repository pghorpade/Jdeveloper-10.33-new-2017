/* $Header: AuthenticationServlet.java 14-nov-2006.13:39:38 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       10/11/06 - 
    cbroadbe    09/15/06 - 
    ychua       04/26/05 - 
    ychua       04/13/05 - second try 
    ychua       04/13/05 - Creation
 */

/**
 *  @version $Header: AuthenticationServlet.java 14-nov-2006.13:39:38 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.security.authentication;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;

import javax.naming.Context;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Enumeration;
import java.util.Hashtable;

import oracle.adf.model.servlet.ADFBindingFilter;
import oracle.adf.share.security.ADFSecurityUtil;
import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.resource.ADFSecurityMessages;
import oracle.adf.share.security.resource.ADFSecurityMessageBundle;

import java.lang.reflect.Method;

/**
*  Authenticates the user by calling WebAuthenticator
*
*/
public class AuthenticationServlet extends HttpServlet 
{
   private static ADFLogger _adfSecLogger = ADFSecurityUtil.getADFLogger();
   private static final String PARAM_KEY_SUCCESS_URL = "success_url"; //url to goto after successful login
   private static final String PARAM_KEY_END_URL = "end_url"; //url to goto after logout end
   private static final String PARAM_KEY_LOGIN = "login";
   private static final String PARAM_KEY_LOGOUT = "logout";
   public  static final String ATTR_KEY_SUCCESS_URL = PARAM_KEY_SUCCESS_URL;

   static final String JSSOUTIL_CLASS = "oracle.security.jazn.sso.util.JSSOUtil"; //NO NLS

   static final int SSO_AUTH       = 0;
   static final int JSSO_AUTH      = 1;
   static final int COREIDSSO_AUTH = 2;

   static String[]  mAuthMethods = {"SSO", "CUSTOM_AUTH", "COREIDSSO"};

   String successUrl = null;
   String endUrl = null;

   public void init(ServletConfig config)
       throws ServletException
   {
       super.init(config);
       successUrl = config.getInitParameter(PARAM_KEY_SUCCESS_URL);
       endUrl = config.getInitParameter(PARAM_KEY_END_URL);

       // Load the ConnectionCredentialMgr MBean and invoke its register method
       // dynamically. This is necessary because the MBean class will not be 
       // included in AS 10.1.3.1
       try
       {
         // load the MBean Class
         final String mbeanClassName = "oracle.adfinternal.extapp.credential.mbean.ConnectionCredentialMgr";
         final ClassLoader ldr = Thread.currentThread().getContextClassLoader();
         final Class mbeanClass = Class.forName(mbeanClassName, true, ldr);
         
         // get the MBean's registerMBean method
         final String registerMethodName = "registerMBean";
         final Method register = mbeanClass.getMethod(registerMethodName, null);
         
         // invoke the method - registerMBean is a static method so no target object
         // is required
         register.invoke(null, null);
       }
       catch(Throwable t)
       {
         // The MBean could not be loaded or the registration method could not be invoked.
         // Swallow the exception and continue so execution of the app is not affected.         
       }
   }

   public void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException
   {
      processRequest(request, response);
   }
 
   public void doPost(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException
   {
      processRequest(request, response);
   }
 
 
   private void processRequest(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException
   {
      _adfSecLogger.log(Level.INFO, "AuthenticationServlet processRequest...");
      Hashtable paramTab = collectParms(request);
      HttpSession session = request.getSession(false);

      if (paramTab.containsKey(PARAM_KEY_LOGOUT))
      {
         String[] values = (String[]) paramTab.get(PARAM_KEY_LOGOUT);
         if (values.length > 0 && (values[0].equals("true") || values[0].equals(PARAM_KEY_LOGOUT)))
	 {
            doLogout(paramTab, response, request);  
	 }
         else
	 {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
               ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_LOGOUT_PARAM));
         }
      }
      else 
      {
         Principal contextPrincipal = request.getUserPrincipal();

         if (paramTab.containsKey(PARAM_KEY_LOGIN))
	 {
            String[] values = (String[]) paramTab.get(PARAM_KEY_LOGIN);
            if (values.length > 0 && values[0].equals("true") )
	    {
               if (contextPrincipal == null )
               {
	          _adfSecLogger.log(Level.WARNING, "No authentication user" );
	          response.sendError(HttpServletResponse.SC_UNAUTHORIZED, 
	             ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_NO_AUTHENTICATED_USER));
	       }
            }
            else
            {
               response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                  ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_LOGIN_PARAM));
            }
	 }
	 _adfSecLogger.log(Level.INFO, "User principal " + contextPrincipal.getName());
	   
	 String url = null;
	   
	 if (paramTab.containsKey(PARAM_KEY_SUCCESS_URL))
	 {
	    String[] vals = (String[]) paramTab.get(PARAM_KEY_SUCCESS_URL);
	    url = getEncodeRedirectURL(request, response, vals[0]);
	 }
	 
	 if (url == null) 
	 {
	    if (session != null && (successUrl == null || successUrl.length() == 0))
	    {
	       url = (String)session.getAttribute(ATTR_KEY_SUCCESS_URL);   
	       session.removeAttribute(PARAM_KEY_SUCCESS_URL);   
	    }
	    else
	    {
	       url = getEncodeRedirectURL(request, response, successUrl);
	    }
	 }
	 if (url == null)
	 {
	    return;
	 }
	 _adfSecLogger.log(Level.INFO, "Success url " + url);
    
	 // Mark in the session that the bindingContainer will need to be invalidated.
	 if (session != null)
	 {
	    session.setAttribute(ADFBindingFilter.SESSION_INVALIDATE_BINDINGCONTAINER_DEF, "true");
	 }
    
	 try
	 {
	    SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
	    secCtx.getEnvironment().remove(SecurityEnv.JAAS_PERMISSION_CHECK);
	    secCtx.addToEnvironment(Context.SECURITY_PRINCIPAL, contextPrincipal);
	 }
	 catch (Exception e)
	 {
	    _adfSecLogger.log(Level.FINE, "Error setting security context environment " + e.getMessage());
         }

         response.sendRedirect(url);   
      }
   }

   public Hashtable collectParms(HttpServletRequest req)
   {
      Hashtable parmTab = new Hashtable();
      Enumeration enumParam = req.getParameterNames();
   
      while (enumParam.hasMoreElements())
      {
         String nam = (String) enumParam.nextElement();
         String vals[] = req.getParameterValues(nam);
         parmTab.put(nam, vals);
      }
   
      return parmTab;
   }

   void doLogout(Hashtable paramTab, HttpServletResponse res, HttpServletRequest req) throws IOException 
   {
      String[] vals = (String[]) paramTab.get(PARAM_KEY_END_URL);
      String url = null;
      HttpSession session = req.getSession(false);

      if ((vals == null || vals.length == 0) && endUrl != null)
      {
         url = getEncodeRedirectURL(req, res, endUrl);
      }
      else
      {
         url = getEncodeRedirectURL(req, res, vals[0]);
      }

      SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
      try 
      {
         secCtx.getEnvironment().remove(SecurityEnv.JAAS_PERMISSION_CHECK);
         secCtx.getEnvironment().remove(SecurityEnv.JAAS_SUBJECT);
         secCtx.getEnvironment().remove(Context.SECURITY_PRINCIPAL);
      }
      catch (Exception e)
      {
      }

      boolean bLogout = false;
      int ssoType = getSSOType(req);
      if (ssoType == JSSO_AUTH  || ssoType == COREIDSSO_AUTH)
      {
         bLogout = doJSSOLogout(res, url);
      }
      else if (ssoType == SSO_AUTH)
      {
	 bLogout = doSSOLogout(res, url);
      }

      if (session != null)
      {
         session.setAttribute(ADFBindingFilter.SESSION_INVALIDATE_BINDINGCONTAINER_DEF, "true");
         req.getSession().invalidate();
      }
 
      session = req.getSession(false);
      if (session != null)
      {
         // Explicit remove of session attributes
         for (Enumeration e = session.getAttributeNames() ; e.hasMoreElements() ;) 
         {
	    String attr = (String)e.nextElement();
           _adfSecLogger.log(Level.INFO, "---- remove session attribute: " + attr);
            session.removeAttribute(attr);
	 }
      }

      if (!bLogout)
      {
         if (url != null)
         {
            res.sendRedirect(url);
         }
         else
         {
            res.setContentType( "text/html" );
            ServletOutputStream out = res.getOutputStream();
            out.println( "<html>" );
            out.println( "<head><title>ADF Security</title></head>" );
            out.println( "<body>" );
            out.println( "<h1>You have been logout</h1>" );
            out.println( "</body>" );
            out.println( "</html>" );
         }
      }
   }

   int getSSOType(HttpServletRequest request)
   {
      String authType = request.getAuthType();
      if (authType != null)
      {
         for (int i = 0; i < mAuthMethods.length; i++)
         {
            if (authType.equals(mAuthMethods[i])) 
            {
                return i;
            }
         }
      }
      return -1;
   }


   boolean doJSSOLogout(HttpServletResponse res, String endUrl)
   {
      boolean logout = false;
       try
       {
          Class cls = Class.forName(JSSOUTIL_CLASS);
          if (cls != null)
          {
             Class [] args = new Class[] {HttpServletResponse.class, String.class};
             Method mth = cls.getMethod("logout", args);  //NO NLS
             if (mth != null)
             {
                mth.invoke(null, new Object[]{res, endUrl});
                _adfSecLogger.log(Level.INFO, "DONE JSSO Logout");
                logout = true;
             }
          }
       }
       catch (Exception e)
       {
          _adfSecLogger.log(Level.FINE, "Error on JSSO Logout ");
       }
       return logout;
   }

   boolean doSSOLogout(HttpServletResponse res, String endUrl)
   {
      try
      {
         res.setHeader("Osso-Return-Url", endUrl);
         res.sendError(470, "Oracle SSO" );
         return true;
      }
      catch (Exception e)
      {
         _adfSecLogger.log(Level.FINE, "Error on SSO Logout ");
      }
      return false;
   }

   String getEncodeRedirectURL(HttpServletRequest request, HttpServletResponse response, String destination)
   {
      StringBuffer buf = new StringBuffer(request.getContextPath());

      if (!destination.startsWith("/"))
      {
         buf.append("/");
      }
      buf.append(destination);  
      return response.encodeRedirectURL(buf.toString());
   }

}

