/* $Header: AuthenticationFilter.java 21-apr-2006.08:41:00 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       08/25/05 - 
    ychua       04/26/05 - Creation
 */

/**
 *  @version $Header: AuthenticationFilter.java 21-apr-2006.08:41:00 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.security.authentication;
import java.io.IOException;


import java.security.Principal;
import java.security.PrivilegedExceptionAction;

import java.util.Set;

import javax.security.auth.Subject;
 
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
import java.security.AccessControlContext;
import java.security.AccessController;

import java.util.Iterator;

import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.security.ADFSecurityUtil;
import oracle.adf.share.ADFContext;

/**
*  This filter is responsible for intercepting all HTTP requests
*  to an application's web component.
*  Has the following two functions:
*  <ul>
*    <li> to propagate the Subject if it exists in the session state.
*  </ul>  
*/
public class AuthenticationFilter implements Filter
{  
   /** A reference to the Filter configuration */
   private FilterConfig _filterConfig;

   private static final String PARAM_KEY_SERVLET_NAME = "auth_servlet";
   private String DEFAULT_SERVLET_NAME = "adfAuthentication"; 
   private String _authServletName  = null;

   /**
    * Called when the filter is instantiated.
    * Security configuration.
    * Loads the name of the Web application from the 
    * Filter configuration (in web.xml file).
    * @param filterConfig the filter configuration.
    * @throws ServletException if the initialization fails.
    */
   public void init(FilterConfig filterConfig) throws ServletException {
      _filterConfig = filterConfig;
      _authServletName = _filterConfig.getInitParameter(PARAM_KEY_SERVLET_NAME);
      if (_authServletName == null)
      {
         _authServletName = DEFAULT_SERVLET_NAME;
      }
   }


  /**
   * Custom implementation of the doFilter method.
   * @param req the incoming ServletRequest
   * @param res the outgoing ServletResponse
   * @param chain the FilterChain to which this filter is associated with.
   * @throws ServletException generic servlet exception
   * @throws IOException generic IO exception if there is an error in reading/writing
   *                     to the streams.
   */
  public void doFilter(final ServletRequest req,
                       final ServletResponse res,
                       final FilterChain chain)
      throws IOException, ServletException
 {
 
    // make sure we are dealing with HTTP
    if (req instanceof HttpServletRequest) 
    {
       final HttpServletRequest request = (HttpServletRequest) req;
       final HttpServletResponse response = (HttpServletResponse) res;
 
       handleAuthentication(request, response, chain);
    }
  }

  /**
   */
  private void handleAuthentication(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain)
                                            throws ServletException, IOException
  {
     HttpSession session = request.getSession();
 
     //check if any JAZN or SSO Principal is associated with the request
     Principal contextPrincipal = request.getUserPrincipal();
     
     //if a Principal not found, invoke AuthenticationServlet
     if ( contextPrincipal == null )
     { 
	SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
        if (secCtx.isAnyoneEnabled())
        {
           addADFRoleToSubject();
        }

	boolean bAuthReq = false;
	try
	{
           String authReq = (String) secCtx.getEnvironment().get(SecurityEnv.JAAS_PERMISSION_CHECK);
           if (authReq != null && authReq.equals("true"))
           {
	       bAuthReq = true;
	   }
	   if (!bAuthReq)
	   {
	      bAuthReq = secCtx.isAuthorizationEnabled();
	      if (!bAuthReq)
	      {
                 authReq = (String) secCtx.getEnvironment().get(SecurityEnv.PROP_AUTHENTICATION_REQUIRE);
                 if (authReq != null && authReq.equals("false"))
                 {
                    bAuthReq = false;
	         }
		 else
		 {
		    bAuthReq = true;
		 }
	      }
	   }
	}
	catch (Exception e)
	{
	}

	if (bAuthReq)
        {
           String path = _authServletName;
           boolean redirect = true;
           if (redirect)
           {
              session.setAttribute(AuthenticationServlet.ATTR_KEY_SUCCESS_URL, request.getRequestURI());
              //response.sendRedirect(response.encodeRedirectURL(path));
              String url = response.encodeRedirectURL(request.getContextPath() + "/" + path);   
              response.sendRedirect(url);   
           }
        }
     }
     chain.doFilter(request, response);
  }
  

  /**
   * Default implementation
   */
  public void destroy()
  {
        //default implementation
  }

  public void addADFRoleToSubject()
  {
     AccessControlContext context = AccessController.getContext();
     Subject subject = Subject.getSubject(context);
     if (subject != null && !ADFSecurityUtil.hasAnyoneRole(subject))
     {
        Principal anonymous = new ADFUserPrincipal(SecurityEnv.ADF_ANONYMOUS_USER);
        subject.getPrincipals().add(anonymous);
        Principal anyone = new ADFRolePrincipal(SecurityEnv.ADF_ANYONE_ROLE);
        ((ADFRolePrincipal)anyone).addUserGrantee(anonymous);
        subject.getPrincipals().add(anyone);
     }
  }

 }


