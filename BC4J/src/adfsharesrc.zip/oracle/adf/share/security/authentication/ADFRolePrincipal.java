package oracle.adf.share.security.authentication;

import java.security.Principal;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class ADFRolePrincipal extends ADFUserPrincipal {
    ArrayList _userGrantees = new ArrayList();
   
    public ADFRolePrincipal(String name) {
        super(name);
    }
    
    public boolean addUserGrantee(Principal user) {
        synchronized(_userGrantees) {
                    return _userGrantees.add(user);
               }
    }
    public boolean removeUserGrantee(Principal user) {
        synchronized(_userGrantees) {
                    return _userGrantees.remove(user);
               }
    }  
    public List getUserGrantees() {
        return _userGrantees;
    }
    public boolean equals(Object another)
    {
       if (another != null && _name.equals(((Principal)another).getName()) )
       {
	   return true;
       }
       return false;
    }
    /*
    public boolean equals(Object another)
    {
       if( another != null && another instanceof ADFRolePrincipal )
       {
          ADFRolePrincipal anotherRolePrincipal = (ADFRolePrincipal)another;
          if (this._name.equals(anotherRolePrincipal._name))
	  {
	     List otherGrantees = anotherRolePrincipal.getUserGrantees();
	     if (_userGrantees.size() != otherGrantees.size())
	     {
	        return false;
	     }
	     Iterator otherIter = otherGrantees.iterator();
	     while (otherIter.hasNext())
	     {
	        Principal otherPrincipal = (Principal)otherIter.next();
	        if (_userGrantees.contains(otherPrincipal))
	        {
	            continue;
	        }
	        else 
	        {
	            return false;
	        }
	     }
	  }
	  return true;
       }
       return false;
    }
 */
}
