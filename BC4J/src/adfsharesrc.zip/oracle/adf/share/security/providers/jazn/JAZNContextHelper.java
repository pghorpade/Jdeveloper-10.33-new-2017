package oracle.adf.share.security.providers.jazn;

import java.lang.Thread;
import java.net.URL;
import java.net.URLClassLoader;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;

import java.util.Set;
import java.security.Principal;
import javax.security.auth.Subject;
import javax.security.auth.Policy;

import java.security.Permission;
import java.security.PermissionCollection;

import oracle.security.jazn.JAZNConfig;
import oracle.security.jazn.JAZNException;
import oracle.security.jazn.realm.Realm;
import oracle.security.jazn.realm.RealmRole;
import oracle.security.jazn.realm.RealmManager;
import oracle.security.jazn.realm.RoleManager;
import oracle.security.jazn.policy.PermissionClassManager;
import oracle.security.jazn.util.JAZNSecurityManager;
import oracle.security.jazn.policy.Grantee;
import oracle.security.jazn.policy.JAZNPolicy;
import oracle.security.jazn.action.GetSystemPropertyAction;
import oracle.security.jazn.action.SetSystemPropertyAction;
import oracle.security.jazn.action.GetJAZNConfigPropertyAction;
import oracle.security.jazn.util.Env;

import java.security.AccessController;
import java.security.ProtectionDomain;

import java.lang.reflect.Method;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.ADFSecurityUtil;
import oracle.adf.share.security.ADFSecurityRuntimeException;
import oracle.adf.share.security.resource.ADFSecurityMessageBundle;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityEnv;


public class JAZNContextHelper 
{
   private static JAZNContextHelper _singleton;
   private final static Object   __LOCK__ = new Object();
   private static ADFLogger _adfSecLogger = ADFSecurityUtil.getADFLogger();

   private static JAZNConfig _config;
   private static RealmManager _realmMgr;
   private static PermissionClassManager _permClsMgr;
   private static JAZNPolicyProvider _policyMgr = null;
   private static JAZNIdentityManagementProvider _identityMgr = null;
   private static JAZNCredentialStore _credentialStore = null;

   static final String JAZN_CONFIG = "oracle.security.jazn.config";        //NO NLS 
   static final String OC4J_JAR = "oc4j.jar";                              //NO NLS 
   static final String JAZN_JAR = "jazn.jar";                              //NO NLS 
   static final String JAZN_XML = "jazn.xml";                              //NO NLS 
   static final String ADFS_JAZN_JAR = "adfs-jazn.jar";                    //NO NLS 
   static final String APPLICATION_JAZNCONFIG = "/META-INF/jazn.xml";         //NO NLS 
   static final String APPLICATION_CONFIG = "/META-INF/orion-application.xml";//NO NLS 
   static final String OC4JCONFIG_CLASS = "oracle.jdeveloper.xml.oc4j.Oc4jConfigAdmin"; //NO NLS

   private static String _configStr = null;
   private static String _embeddedConfigPath = null;
   private static ProtectionDomain _thisPD = null;  
   private static boolean _setJAZNProps = false;
   private static boolean _jClient = false;
   private static boolean _dualUpdate = false;
   private static boolean _useHomeConfig = false;
   private static boolean _refreshConfig = true;

   final static String EMBEDDED_CONFIG_FILENAME = "/system-application.xml";  //NO NLS 
   private static final String FILE_SEPARATOR = System.getProperty("file.separator");

   public JAZNContextHelper()
   {
   }

   public static JAZNContextHelper getInstance()
   {
      return JAZNContextHelper.getInstance(null);
   }

   public static JAZNContextHelper getInstance(Hashtable env)
   {
     // Synchronize on __LOCK__ to ensure that we don't end up creating
     // two singletons.
     synchronized (__LOCK__)
     {
       if (null == _singleton)
       {
         JAZNContextHelper cm = new JAZNContextHelper();
//         String jaznPath = cm.findJAZNConfig();
//         setLoginConfig(jaznPath);
         cm.refresh(env);
         if (_config != null)
         {
            _singleton = cm;
            return cm;
         }
         return null;
       }
       refreshJAZNContext();
     }
     return _singleton;
   }

   public void initialize(Hashtable env)
   {
      refresh(env);
   }

   public JAZNPolicyProvider getPolicyProvider()
   {
      if (_policyMgr == null)
      {
         _policyMgr = new JAZNPolicyProvider(this);
      }
      return _policyMgr;
   }

   public void setIdentityManagementProvider(JAZNIdentityManagementProvider mgr)
   {
      _identityMgr = mgr;
   }

   public JAZNIdentityManagementProvider getIdentityManagementProvider()
   {
      if (_identityMgr == null)
      {
         _identityMgr = new JAZNIdentityManagementProvider(this);
      }
      return _identityMgr;
   }

   public void setCredentialStore(JAZNCredentialStore cs)
   {
      _credentialStore = cs;
   }

   static void setLoginConfig(String configStr)
   {
      _configStr = configStr;
   }

   static void setLoginConfigSystemProperty()
   {
      if (_configStr != null)
      {
         return;
      }

      _adfSecLogger.log(Level.FINE, "Setting JAZN Config property ...");

      try
      {
         _configStr = System.getProperty("oracle.security.jazn.config");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }

   public void refresh(Hashtable env)
   {
      refreshJAZNContext();
      setLoginConfigSystemProperty();

      if (_configStr != null)
      {
         try
         {
        
            _config = new JAZNConfig(_configStr);
         }
         catch(Exception ex)
         {
         } 
      }

      if (_config == null)
      {
        try
        {
           // _config = JAZNConfig.getJAZNConfig();
           _config = JAZNConfig.getOC4JInstanceConfig();
        }
        catch(java.lang.NoClassDefFoundError ex)
        {
            
           throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_SECURITY_CONFIG));
        } 
      }
       
      if (_config.getProviderType().equals(Env.PROVIDER_TYPE_LDAP))
      {
          setSystemProperties();
      }

      try
      {
         _realmMgr = _config.getRealmManager();
         if (_realmMgr == null)
         {
            _adfSecLogger.log(Level.INFO, "RealmManager not found!");
         }
      }
      catch(Exception exception)
      {
          exception.printStackTrace();
      } 

      try
      {
         java.security.Security.setProperty("auth.policy.provider", "oracle.security.jazn.spi.PolicyProvider"); //NO NLS
      }
      catch(Exception ee)
      {
        ee.printStackTrace();
      }
   }  

   public JAZNConfig getJAZNConfig()
   {
      return _config;
   }

   public JAZNConfig getEmbeddedJAZNConfig()
   {
      return getEmbeddedConfig();
   }

   static void validateJAZNConfig()
   {
      if (_config == null)
      {
          throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_SECURITY_CONFIG));
      }
   }

   public String getDefaultRealmName()
   {
       validateJAZNConfig();
       return _config.getDefaultRealm();
   }

   public static PermissionClassManager getPermissionClassManager()
   {
      if (_permClsMgr == null)
      {
         _permClsMgr = _config.getPermissionClassManager();
      }
      return _permClsMgr;
   }

   public static RealmManager getRealmManager()
   {
       validateJAZNConfig();
       return _config.getRealmManager();
   }

   public Realm getDefaultRealm()
   {
      validateJAZNConfig();
      Realm realm = null;
      try
      {
         realm = _realmMgr.getRealm(getDefaultRealmName());
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return realm;
   }                
                        
  RealmRole getRealmRole(String roleName)
  {
     return getRealmRole(roleName, _config);
  }

  RealmRole getRealmRole(String roleName, JAZNConfig config)
  {
     RealmRole realmRole = null;
     try
     {
        Realm realm = config.getRealmManager().getRealm(config.getDefaultRealm());
        RoleManager roleMgr = realm.getRoleManager();
        realmRole = roleMgr.getRole(roleName);
        if (realmRole == null)
        {
           //_adfSecLogger.log(Level.INFO, "Invalid role " + roleName);
        }
     }
     catch(JAZNException e)
     {
        e.printStackTrace();
     }
     return realmRole;
  }

  void persistJAZNData()
  {
     persistJAZNData(null);
  }

  void persistJAZNData(JAZNConfig config)
  {
      try
      {
         if (_useHomeConfig)
         {
            _config.getJAZNProvider().persist();
         }

         if (config != null && config != _config)
         {
            config.getJAZNProvider().persist();
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
   }

   public ADFLogger getADFSecurityLogger()
   {
      return _adfSecLogger;
   }
/*
   void getJAZNConfig(Properties props)
   {
      _config = new JAZNConfig(props);
      try
      {
         _realmMgr = _config.getRealmManager();
         if (_realmMgr == null)
         {
            _adfSecLogger.log(Level.INFO, "RealmManager not found!");
         }
      }
      catch(Exception exception)
      {
          exception.printStackTrace();
      } 
   }
*/
  String findJAZNConfig()
  {
     String resourceName = APPLICATION_CONFIG;

     ClassLoader cl = Thread.currentThread().getContextClassLoader();
     URL url = cl.getResource(resourceName);
     if (url == null)
     {
        resourceName = APPLICATION_JAZNCONFIG;
        url = cl.getResource(resourceName);
     }   
     if (url != null)
     {
        String path = url.getPath();
        int ix = path.indexOf("!/");
        if (ix > 0)
        {
           StringBuffer buf = new StringBuffer();
           buf.append(path.substring(0, ix - 1));
           buf.append(resourceName);
           path = buf.toString();
        }
        _adfSecLogger.log(Level.FINE, "JAZN Config path ..." + path);
        return path;
     }
     return null;
   }

   static void refreshJAZNContext()
   {
      _jClient = false;
      _refreshConfig = true;
   }

   static void setSystemProperties()
   {
      if (_setJAZNProps)
      {
         return;
      }
      if(getSystemJAZNProperty(Env.LDAP_CACHE_POLICY_ENABLE,null) == null)
          _setSystemProperty(Env.LDAP_CACHE_POLICY_ENABLE, "false");
      if(getSystemJAZNProperty(Env.LDAP_CACHE_REALM_ENABLE,null) == null)
          _setSystemProperty(Env.LDAP_CACHE_REALM_ENABLE, "false");
      if(getSystemJAZNProperty(Env.LDAP_CACHE_SESSION_ENABLE,null) == null)
          _setSystemProperty(Env.LDAP_CACHE_SESSION_ENABLE, "false");
        String s = getSystemJAZNProperty(Env.LDAP_CACHE_POLICY_ENABLE,null);

      _setJAZNProps = true;
   }

   static String getSystemJAZNProperty(String name, String defaultValue)
   {
      String value = getSystemProperty(name,null);
      if(value == null)
      {
          value = getJAZNProperty(name, defaultValue);
      }
      return value;
   }
   private static String getSystemProperty(String name, String defaultValue)
   {
      return (String)AccessController.doPrivileged(new GetSystemPropertyAction(name, defaultValue));
   }
   
   private static String _setSystemProperty(String name, String value)
   {
      return (String)AccessController.doPrivileged(new SetSystemPropertyAction(name, value));
   }
   
   private static String getJAZNProperty(String name, String defaultValue)
   {
      return (String)AccessController.doPrivileged(
              new GetJAZNConfigPropertyAction(JAZNConfig.getJAZNConfig(),
                                              name, 
                                              defaultValue));
   }

   private String getEmbeddedConfigPath()
   {
      if (_refreshConfig || (!_jClient && _embeddedConfigPath == null))
      {
         try
         {
            Hashtable env = ADFContext.getCurrent().getSecurityContext().getEnvironment();
            String path = (String) env.get(SecurityEnv.PROP_EMBEDDED_CONFIG_PATH);
            if (path != null)
            {
               if (path.length() == 0)
               {
                  _jClient = true;
                  _embeddedConfigPath = null;
               }
            }  
            else if (_embeddedConfigPath == null)
            {
               path = findEmbeddedConfigPath();
            }

            if (path != null && !_jClient) 
            {
               StringBuffer sbuf = new StringBuffer(path);
               sbuf.append(FILE_SEPARATOR);
               sbuf.append(JAZN_XML);
               _embeddedConfigPath = sbuf.toString();
               _adfSecLogger.log(Level.FINE, "Setting Embedded JAZN Config property ..." + _embeddedConfigPath);
            }

            String dual = System.getProperty(SecurityEnv.PROP_DUAL_AUTH);
            if (dual != null && dual.equals("true"))    //NO NLS
            {
               _dualUpdate = true;
            }

            _refreshConfig = false;
        }
        catch (Exception e)
        {
        }
      }
      return _embeddedConfigPath;
   }

   private String findEmbeddedConfigPath()
   {
      if (_embeddedConfigPath != null)
      {
         return _embeddedConfigPath;
      }

      try
      {
         Class cls = Class.forName(OC4JCONFIG_CLASS);
         if (cls != null)
         {
            Method mth = cls.getMethod("getEmbeddedOc4jConfigDir", new Class[0]);  //NO NLS
            if (mth != null)
            {
               _embeddedConfigPath = ((java.io.File)mth.invoke(null, new Object[0])).getAbsolutePath();  
            }
         }
      }
      catch (Exception e)
      {
      }
      return _embeddedConfigPath;
   }

   private JAZNConfig getEmbeddedConfig()
   {
      JAZNConfig embeddedConfig = null;
 
      if (_config.getProviderType().equals(Env.PROVIDER_TYPE_LDAP))
      {
         return null;
      }

      getEmbeddedConfigPath();

      if (_embeddedConfigPath != null)
      {
         try
         {
            embeddedConfig = new JAZNConfig(_embeddedConfigPath);
           _adfSecLogger.log(Level.FINE, "JAZN embedded onfig path ..." + _embeddedConfigPath);
         }
         catch(Exception ex)
         {
         } 
      }

      if (_embeddedConfigPath == null || _dualUpdate) 
      {
         _useHomeConfig = true;
      }

      return embeddedConfig;
   }

   public static String getRealmName(String name, JAZNConfig config)
   {
      int ix = name.indexOf("/");
      if (ix > 0)
      {
         return name.substring(0, ix);
      }
      return config.getDefaultRealm();
   }

   public boolean isDualUpdate()
   {
      return _dualUpdate;
   }
}      

