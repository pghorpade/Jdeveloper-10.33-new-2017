/* $Header: RADCredentialStore.java 19-feb-2006.18:39:45 ychua Exp $ */
/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       08/23/05 - 
    ychua       03/24/05 - Retry beginmerge mar 24 2005 
    ychua       03/24/05 - Creation
 */

/**
 *  @version $Header: RADCredentialStore.java 19-feb-2006.18:39:45 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.security.providers.rad;

import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.credentialstore.CredentialStore;
import oracle.adf.share.security.credentialstore.spi.GenericCredentialStore;
import oracle.adf.share.security.credentialstore.spi.CredentialProvisioning;
import oracle.adf.share.security.SecurityEnv;

import oracle.ldap.util.jndi.ConnectionUtil;
import oracle.ldap.util.Property;
import oracle.ldap.util.PropertySet;
import oracle.ldap.util.PropertySetCollection;
import oracle.ldap.util.ModPropertySet;
import oracle.ldap.util.User;
import oracle.ldap.util.Util;
import oracle.ldap.util.LDIF;
import oracle.ldap.util.UtilException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import java.security.Principal;

import java.io.Serializable;

import oracle.adf.share.security.ADFSecurityRuntimeException;
import oracle.adf.share.security.CredentialNotFoundException;
import oracle.adf.share.security.resource.ADFSecurityMessageBundle;

/**
 * Implementation of CredentialStore for Resource Access Descriptor.
 */
public class RADCredentialStore extends GenericCredentialStore implements CredentialProvisioning
{
  /**
   * OracleDB credential resource type name.
   */
   public static String CREDENTIAL_TYPE_ORACLEDB = "OracleDB";
  /**
   * UserProperties credential resource type name.
   */
   public static String CREDENTIAL_TYPE_USER = "UserProperties";
   
   private InitialDirContext dirContext = null;
   private static String PROP_LOCATION = "location";
   private static String PROP_LDAP_USER = "ldap.user";
   private static String PROP_LDAP_PASSWORD = "ldap.password";
   private static String PROP_LDAP_COMMON_NAME = "cn";
   private static String PROP_LDAP_DOMAIN_CONTROL = "dc";
   private static String PROP_LDAP_ORGANIZATIONAL_UNIT = "ou";
   private static String PROP_LDAP_ORGANIZATION = "o";
   private final static String INIT_CTX = "com.sun.jndi.ldap.LdapCtxFactory";
 
   private String host;   
   private String location;   
   private String ldap_cn;
   private String ldap_user;
   private String ldap_password;
   private User _ldapUser = null;  
   private String[] _extProperties= {
              OracleDBCredential.USERID_ATTRIBUTE,
              OracleDBCredential.PASSWORD_ATTRIBUTE,
              OracleDBCredential.RESOURCE_NAME,
              OracleDBCredential.RESOURCETYPE_NAME, 
              OracleDBCredential.FLEX_ATTRIBUTE1,
              OracleDBCredential.FLEX_ATTRIBUTE2,
              OracleDBCredential.FLEX_ATTRIBUTE3 }; 

   private void setInitialContext() throws NamingException
   {
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, INIT_CTX);
      env.put(Context.PROVIDER_URL, host);
      env.put(Context.SECURITY_PRINCIPAL, ldap_cn);
      env.put(Context.SECURITY_CREDENTIALS, ldap_password);
      dirContext = new InitialDirContext(env);
   }
   
  /**
   * Initialize the credential store with the specified properties.
   * @param props the properties to initialize with
   */
   public void initialize(Hashtable props)
   {
      // Create an LDAP connection
      location = (String) props.get(SecurityEnv.PROP_CREDENTIAL_STORE_LOCATION);
      host = "ldap://" + location;
      String port = "";
      int i = location.indexOf(":");
      if (i > 0)
      {
         port = location.substring(i + 1);
         location = location.substring(0, i);
      }

      ldap_cn = PROP_LDAP_COMMON_NAME + "=" + (String) props.get(PROP_LDAP_COMMON_NAME);
      ldap_user = (String)props.get(PROP_LDAP_USER);
      ldap_password = (String)props.get(PROP_LDAP_PASSWORD);

      System.out.println("location = " + location);
      System.out.println("port = " + port);
      System.out.println(" cn = " + ldap_cn);
      System.out.println(" pwd = " + ldap_password);

      try
      {
         setInitialContext();
      }
      catch (javax.naming.NamingException e)
      {
        e.printStackTrace();
        throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_STORE_INIT));
      }

      // Create a User object representing the end-user
     
      try
      {
         String dn = PROP_LDAP_DOMAIN_CONTROL + "=" + location + "," + PROP_LDAP_DOMAIN_CONTROL + "=com"; 
         _ldapUser = new User(dirContext, Util.IDTYPE_SIMPLE, ldap_user,Util.IDTYPE_DN, dn, true);
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_STORE_INIT));
      }
   }

  /**
   * Stores the credential object using the sepcified credential key.  The credential is stored as
   * a property set in Resource Access Descriptor (cn) under Extended Properties (cn) in Oracle Internet Directory
   * @param cred    the Credential to store
   * @param credKey  the credential key
   */
   public void storeCredential(Credential cred, String credKey)
   {
      storeCredentialForUser(cred, credKey, _ldapUser);
   }

   void storeCredentialForUser(Credential cred, String credKey, User user)
   {
      Credential _cred = fetchCredentialForUser(credKey, user);
      try
      {
         ModPropertySet mps = new ModPropertySet();
         Set names = cred.getPropertyNames();
         Iterator iter = names.iterator();
         while (iter.hasNext())
         {
            String key = (String) iter.next();
            String value = ((Credential) cred).getProperty(key);
            mps.addProperty(LDIF.ATTRIBUTE_CHANGE_TYPE_ADD, key, value);
            //System.out.println("## RAD key = " + key +", value = " + value);
         }

         if (cred.getProperty(OracleDBCredential.RESOURCETYPE_NAME) == null)
         {
            mps.addProperty(getAttributeChangeType(_cred, OracleDBCredential.RESOURCETYPE_NAME), OracleDBCredential.RESOURCETYPE_NAME, CREDENTIAL_TYPE_USER);
         }

         if (cred.getProperty(OracleDBCredential.RESOURCE_NAME) == null)
         {
            mps.addProperty(getAttributeChangeType(_cred, OracleDBCredential.RESOURCE_NAME), OracleDBCredential.RESOURCE_NAME, credKey);
         }

         if (_cred == null)
         {
            user.createExtendedProperties(dirContext, User.EXTPROPTYPE_RESOURCE_ACCESS_DESCRIPTOR, mps);
         }
         else
         {
            user.setExtendedProperties(dirContext, User.EXTPROPTYPE_RESOURCE_ACCESS_DESCRIPTOR, OracleDBCredential.RESOURCE_NAME+"="+credKey, mps);
         }
     }
     catch(Exception ex)
     {
        ex.printStackTrace();
        throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_STORE_CREDENTIAL, new Object[]{credKey}));
     }
   }

  /**
   * Store the credential for the specified credential key and principal.
   * @param cred  the serializable credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeSerializableCredential(Serializable cred, String credKey, Principal principal)
   {
      throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_CRDENTIAL_OPERATION));
   }


  /**
   * Retrieves the credential of the specified credential key.
   * @param credKey  credential key.
   * @return the credential for the specified credential key
   */
   public Credential fetchCredential(String credKey)
   {
      Credential credential = fetchCredentialForUser(credKey, _ldapUser);
      if (credential == null)
      {
         String appUser = getApplicationUserName();
         if (appUser != null)
         {
            try
            {
               User user = getLDAPUser(appUser);
               credential = fetchCredentialForUser(credKey, user);
            }
            catch(ADFSecurityRuntimeException ex)
            {
            }
         }
      }
      if (credential == null)
      {
         throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }

      return credential;
   }

   Credential fetchCredentialForUser(String credKey, User user)
   {
      String resourceName = credKey != null ? credKey : null;
      
      try
      {
         PropertySetCollection psc = user.getExtendedProperties(dirContext, User.EXTPROPTYPE_RESOURCE_ACCESS_DESCRIPTOR, _extProperties, OracleDBCredential.RESOURCE_NAME+"="+credKey);
     
         for (int i = 0; i < psc.size(); i++) 
         {
            return credentialProperties(psc.getPropertySet(i));
         }
      }
      catch (UtilException ue)
      {
         ue.printStackTrace();
      }

      return null;
   }

  /**
   * Returns the serializable credential for the specified credential key.
   * @param credKey  the credential key
   * @return a valid credential, or <code>null</code> if not found
   */
   public Serializable fetchSerializableCredential(String credKey)
   {
      throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_CRDENTIAL_OPERATION));
   }


  /**
   * Retrieves a list of credential objects 
   * @return an array list of credential objects
   */
   //public ArrayList fetchCredentials()
   ArrayList fetchCredentials()
   {
      ArrayList list = new ArrayList();

      try
      {
         PropertySetCollection psc = _ldapUser.getExtendedProperties(dirContext, User.EXTPROPTYPE_RESOURCE_ACCESS_DESCRIPTOR, _extProperties, OracleDBCredential.RESOURCETYPE_NAME+"=*");
         
         for (int i = 0; i < psc.size(); i++) 
         {
            list.add(credentialProperties(psc.getPropertySet(i)));
         }
      }
      catch (UtilException ue)
      {
         ue.printStackTrace();
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_FETCH_ALL_CREDENTIAL));

      }

      return list;
   }

  /**
   * Removes the credential sepcified by the credential key.
   * @param credKey
   */
   public void removeCredential(String credKey)
   {
      removeCredentialForUser(credKey, _ldapUser);
   }

   void removeCredentialForUser(String credKey, User user)
   {
      String resourceName = credKey;
      try
      {
         PropertySetCollection psc = user.getExtendedProperties(dirContext, User.EXTPROPTYPE_RESOURCE_ACCESS_DESCRIPTOR, _extProperties, OracleDBCredential.RESOURCE_NAME+"="+credKey);
         for (int i = 0; i < psc.size(); i++) 
         {
           Util.ldapDelete(dirContext, psc.getPropertySet(i).getDN());
         }
      }
      catch (UtilException ue)
      {
         ue.printStackTrace();
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_DELETE_CREDENTIAL, new Object[]{credKey}));
      }

   }

  /**
   * Store the credential for the specified credential key and principal.
   * @param cred  the credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeCredential(Credential cred, String credKey, Principal principal)
   {

      User user = getLDAPUser(principal.getName());
      if (user != null)
      {
         storeCredentialForUser(cred, credKey, user);
      }
      else
      {
        // TODO throw invalid user exception
      }
   }

  /**
   * Removes the credential specified by the credential key.
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void removeCredential(String credKey, Principal principal)
   {
      User user = getLDAPUser(principal.getName());
      if (user != null)
      {
         removeCredentialForUser(credKey, user);
      }
      else
      {
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_USER));
      }
   }

   User getLDAPUser(String principalName)
   {
      if (principalName == null || principalName.length() == 0)
      {
         return null;
      }

      try
      {
         String dn = PROP_LDAP_DOMAIN_CONTROL + "=" + location + "," + PROP_LDAP_DOMAIN_CONTROL + "=com"; 
         return new User(dirContext, Util.IDTYPE_SIMPLE, principalName, Util.IDTYPE_DN, dn, true);
      }
      catch(Exception ex)
      {
         throw new ADFSecurityRuntimeException(ex);
      }
   }


   Credential credentialProperties(PropertySet ps)
   {
      OracleDBCredential c = new OracleDBCredential();
      String[] attrs = ps.getAttributeNames();
      //System.out.println("DN: "+ ps.getDN() + ", size: " + ps.size());
      for (int j = 0; j < attrs.length; j++) 
      {
         String s = attrs[j];    
         Property p = ps.getProperty(s);
         String propName  = p.getName();
         for (int k = 0; k < p.size(); k++) 
         {
            //System.out.println(s + " Property Name: "+ propName + ",  Value: " + p.getValue(k));
            c.put(propName,(String) p.getValue(k));
         }
      }
      return c;
   }
   
   int getAttributeChangeType(Credential cred, String attr)
   {
      if (cred != null && cred.getProperty(attr) != null)
      {
         return LDIF.ATTRIBUTE_CHANGE_TYPE_REPLACE;
      }
       return LDIF.ATTRIBUTE_CHANGE_TYPE_ADD;
   }
}


