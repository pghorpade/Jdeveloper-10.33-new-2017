package oracle.adf.share.security.providers.jazn;

import oracle.security.jazn.JAZNConfig;
import oracle.security.jazn.realm.Realm;
import oracle.security.jazn.realm.RealmRole;
import oracle.security.jazn.realm.RealmPrincipal;
import oracle.security.jazn.realm.RealmUser;
import oracle.security.jazn.realm.RoleManager;
import oracle.security.jazn.realm.RealmManager;
import oracle.security.jazn.spi.xml.XMLPrincipal;
import oracle.security.jazn.policy.Grantee;
import oracle.security.jazn.JAZNException;
import oracle.security.jazn.JAZNRuntimeException;
//import oracle.security.jazn.util.Env;

import java.util.Set;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.logging.Level;

import javax.security.auth.Subject;
import java.security.Principal;


import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.identitymanagement.AttributeFilter;
import oracle.adf.share.security.identitymanagement.Role;
import oracle.adf.share.security.identitymanagement.User;
import oracle.adf.share.security.identitymanagement.spi.IdentityManagement;
import oracle.adf.share.security.authentication.ADFRolePrincipal;
import oracle.adf.share.security.authentication.ADFUserPrincipal;

public class JAZNIdentityManagementProvider implements IdentityManagement
{
   public static String PASSWORD_ATTRIBUTE = "orclpasswordattribute";

   private JAZNContextHelper _contextHelper;
   private JAZNConfig _config;
   private RealmManager _realmMgr;
//   private boolean isRealmPolicySupported = true;
   private boolean _isSimpleName = true;
   private static boolean _addADFRole = false;
   private static Principal _adfRolePrincipal = null;

   public JAZNIdentityManagementProvider()
   {
      this(JAZNContextHelper.getInstance());
      JAZNContextHelper.getInstance().setIdentityManagementProvider(this);
   }

   public JAZNIdentityManagementProvider(JAZNContextHelper jaznCtx)
   {
       _contextHelper = jaznCtx;
       init();
   }

   public void init()
   {
      _config = _contextHelper.getEmbeddedJAZNConfig();
      if (_config == null) {
          _config = _contextHelper.getJAZNConfig();
          _addADFRole = false;
      }
      else
      {
         if (ADFContext.getCurrent().getSecurityContext().isAnyoneEnabled())
            _addADFRole = true;
      }

      _realmMgr = _config.getRealmManager();

      ArrayList realms = getRealms();
      if (realms.size() > 1)
      {
         try
         {
            String s = System.getProperty(SecurityEnv.PROP_JAZN_SIMPLE_NAME);
            if (s != null && s.equals("false"))              
            {
               _isSimpleName = false;
            }
         }
         catch (Exception e)
         {
         }
      }
   }

   Realm getJAZNRealm(String realmName)
   {
      Realm realm = null;
      try
      {
        realm = _realmMgr.getRealm(realmName);
      }
      catch (JAZNException je)
      {
      }
      return realm;
   }

   public ArrayList getRealms()
   {
      ArrayList list = new ArrayList();

      Set realms = null;
      try
      {
         realms =  _realmMgr.getRealms();
      }
      catch (JAZNException je)
      {
      }

      if (realms != null)
      {
         Iterator i = realms.iterator();
         while (i.hasNext())
         {
            Realm realm = (Realm)i.next();
            list.add(realm.getName());
         }
      }
      return list;
   }

  public RealmUser getRealmUser(Realm realm, String username)
  {
     if (realm == null)
     {
        return null;
     }
     RealmUser realmUser = null;
     try
     {
        realmUser = realm.getUserManager().getUser(username);
     }
     catch (JAZNException e)
     {
        e.printStackTrace();
     }
     return realmUser;
  }

  public User createUser()
  {
     return new User();
  }

  public Principal addUser(User user, Credential credential)
  {
     String realmName = _config.getDefaultRealm();
     RealmUser realmUser = null;
     try
     {
        Realm realm = _realmMgr.getRealm(realmName);
        realmUser = realm.getUserManager().createUser(user.getUsername(), credential.getProperty(PASSWORD_ATTRIBUTE)); 
     }
     catch(JAZNException e)
     {
        e.printStackTrace();
     }
     return (Principal)realmUser;
  }

  public User getUser(Principal principal)
  {
     String name = principal.getName();
     if (!_isSimpleName) 
     {
        if (principal instanceof RealmPrincipal)
        {
           name = getFullName(name, ((RealmPrincipal)principal).getRealm().getName());
        }
        else if (principal instanceof XMLPrincipal)
        {
           name = getFullName(name, ((XMLPrincipal)principal).getPrincipalRealmName());
        }
     }
     return new User(name);
  }

  public void modifyUser(Principal principal, User user)
  {
  }

  public void deleteUser(Principal principal)
  {

  }

  public Principal getUserPrincipal(String username)
  {
     RealmUser realmUser = null;
     int sep = username.indexOf('/');

     String realmName = null;
     if (sep == -1)
     {
        realmName = _config.getDefaultRealm();
     }
     else
     {
        realmName = username.substring(0, sep);
     }

     Realm realm = getJAZNRealm(realmName);
     if (realm != null) 
     {
        realmUser = getRealmUser(realm, username);
     }
 
     return (Principal) realmUser;
  }

  public boolean isAddUserSupported()
  {
     return true;
  }

  public boolean isModifyUserSupported()
  {
     return true;
  }

  public boolean isDeleteUserSupported()
  {
     return true;
  }

  public ArrayList getUserList(int sizeLimit, AttributeFilter[] filter)
  {
     Set users = null;
     ArrayList userList = new ArrayList();

     //TODO: Assume default realms for now
     String realmName = _config.getDefaultRealm();
     try
     {
        Realm realm = _realmMgr.getRealm(realmName);
        users = realm.getUserManager().getUsers();
     }
     catch (JAZNException e)
     {
        e.printStackTrace();
     }

     if (users != null)
     {
        Iterator i = users.iterator();
        while (i.hasNext())
        {
           RealmUser realmuser = (RealmUser)i.next();
           userList.add(new User(realmuser.getName()));
        }
     }
     return userList;
  }
 
  public ArrayList getUserList(int sizeLimit, AttributeFilter[] filter, Principal roleRef)
  {
     return null;
  }
 
  public Role createRole()
  {
     return null;
  }

  public Principal addRole(Role roleDef)
  {
     return null;
  }

  public void modifyRole(Principal roleRef, Role roleDef)
  {
  }

  public void deleteRole(Principal roleRef)
  {
  }

  public Role getRole(Principal roleRef)
  {
     Principal p = getRolePrincipal(roleRef.getName()); 
     if (p == null)
        return null;

     Role role = null;

     if (p instanceof RealmRole) 
     {
        role = newRole((RealmRole) p);
        initRoleMembers(role, (RealmRole) p);
     }
     else if (p instanceof ADFRolePrincipal)
     {
        role = new Role(p.getName());
     }
     return role;
  }

  public Principal getRolePrincipal(String roleName)
  {
      RealmRole realmRole = _contextHelper.getRealmRole(roleName);
      String realmName = _contextHelper.getRealmName(roleName, _config);
      Principal p = null;
      try
      {
         Realm realm = _realmMgr.getRealm(realmName);
         RoleManager roleMgr = realm.getRoleManager();
         p = (Principal) roleMgr.getRole(roleName);
      }
      catch (Exception e)
      {
      }

      if (p == null && roleName.equals(SecurityEnv.ADF_ANYONE_ROLE))
      {
         p = (Principal) getADFRolePrincipal();
      }
      return p;
  }

  public void addToRole(Principal roleRef, Principal member)
  {
  }

  public void deleteFromRole(Principal roleRef, Principal member)
  {
  }

  public ArrayList getRoleList(int sizeLimit, AttributeFilter[] filter)
  {
     //TODO sizeLimit, and attribute filter
     ArrayList roleList = new ArrayList();
     try
     {
        Set realms = _realmMgr.getRealms();
        Iterator i = realms.iterator();
        while (i.hasNext())
        {
            Realm realm = (Realm)i.next();
            RoleManager roleMgr = realm.getRoleManager();
            try 
            {
               Set roles = roleMgr.getRoles();
               Iterator j = roles.iterator();
               while (j.hasNext())
               {
                   RealmRole realmRole = (RealmRole)j.next();
                   Role role = newRole(realmRole);
                   initRoleMembers(role, realmRole);
                   /*
                   RealmRole realmRole = _contextHelper.getRealmRole(_role.getName());
                   Set principals = roleMgr.getGrantees(realmRole, true);//direc grant for now
                   Iterator k = principals.iterator();
                   while (k.hasNext())
                   {
                      _role.addMember((Principal)k.next());
                   }
                   */
                   roleList.add(role);
               }
            }
            catch (JAZNRuntimeException re)
            {
               _contextHelper.getADFSecurityLogger().log(Level.FINE, "Role unavailable for reaml " + realm.getName());
            }
        }

        if (filter.length == 0)
        {
           Role role = getADFRole();
           if (role != null) 
           {
              roleList.add(role); 
           }
        }
     }
     catch (JAZNException e)
     {
        e.printStackTrace();
     }

     return roleList;
  }

  public boolean isAddRoleSupported()
  {
     return true;
  }

  public boolean isModifyRoleSupported()
  {
     return true;
  }

  public boolean isDeleteRoleSupported()
  {
     return true;
  }

  void initRoleMembers(Role role, RealmRole realmRole)
  {
      Realm realm = realmRole.getRealm();
      try
      {
         RoleManager roleMgr = realm.getRoleManager();
         Set principals = roleMgr.getGrantees(realmRole, true);
         Iterator k = principals.iterator();
         while (k.hasNext())
         {
            role.addMember((Principal)k.next());
         }
      }
      catch (JAZNException je)
      {
      }
  }

  Role newRole(RealmRole realmRole)
  {
     String name = realmRole.getName();
     if (!_isSimpleName)
     {
        name = getFullName(realmRole.getName(), ((RealmPrincipal)realmRole).getRealm().getName());
     }
     Role role = new Role(name);
     return role;
  }


  String getFullName(String name, String realmName)
  {
     StringBuffer sbuf = new StringBuffer();
     if (name.indexOf('/') == -1)
     {
        sbuf.append(realmName).append("/");  
     }
     sbuf.append(name);
     return sbuf.toString();
  }

  Role getADFRole()
  {
     Role role = null;

     if (_addADFRole)
     {
        Principal anyone = getADFRolePrincipal();
        role = new Role(anyone.getName());
        Iterator iter = ((ADFRolePrincipal)anyone).getUserGrantees().iterator();
        while (iter.hasNext())
        {
           role.addMember((Principal) iter.next());
        }
     }
     return role;
  }

  static Principal getADFRolePrincipal()
  {
     if (_addADFRole && _adfRolePrincipal == null)
     {
        Principal anonymous = new ADFUserPrincipal(SecurityEnv.ADF_ANONYMOUS_USER);
        Principal anyone = new ADFRolePrincipal(SecurityEnv.ADF_ANYONE_ROLE);
        ((ADFRolePrincipal)anyone).addUserGrantee(anonymous);
        _adfRolePrincipal = anyone;
     }
     return _adfRolePrincipal;
  }

}



