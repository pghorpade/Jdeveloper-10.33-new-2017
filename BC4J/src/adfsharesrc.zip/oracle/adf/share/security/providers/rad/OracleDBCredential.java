/* $Header: OracleDBCredential.java 24-mar-2005.12:17:21 ychua Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       03/24/05 - Retry beginmerge mar 24 2005 
    ychua       03/24/05 - Creation
 */

/**
 *  @version $Header: OracleDBCredential.java 24-mar-2005.12:17:21 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.security.providers.rad;

import java.util.Properties;
import oracle.adf.share.security.credentialstore.Credential;
 

/**
 * OracleDBCredential represents data in an entry in the Resource Access Descriptor (cn) in the 
 * Extended Properties (cn) of Oracle Internet Directory.
 */
public class OracleDBCredential extends Credential 
{
   public static String USERID_ATTRIBUTE = "orcluseridattribute";
   public static String PASSWORD_ATTRIBUTE = "orclpasswordattribute";
   public static String RESOURCE_NAME = "orclresourcename";
   public static String RESOURCETYPE_NAME = "orclresourcetypename";
   public static String FLEX_ATTRIBUTE1 = "orclflexattribute1";
   public static String FLEX_ATTRIBUTE2 = "orclflexattribute2";
   public static String FLEX_ATTRIBUTE3 = "orclflexattribute3";

  /**
   * Gets the value of the UserId key.
   * @return the value of the UserId key
   */
   public String getUserId()
   {
      return getProperty(USERID_ATTRIBUTE);
   }

  /**
   * Sets the value for UserId key.
   * @param userId
   */
   public void setUserId(String userId)
   {
      setProperty(USERID_ATTRIBUTE, userId);
   }

  /**
   * Gets the value for Password key.
   * @return the value of Password key
   */
   public String getPassword()
   {
      return getProperty(PASSWORD_ATTRIBUTE);
   }

  /**
   * Sets the value for Password key.
   * @param password  the value of Password
   */
   public void setPassword(String password)
   {
      setProperty(PASSWORD_ATTRIBUTE, password);
   }

  /**
   * Gets the value of ResourceName key.
   * @return the value of ResourceName key
   */
   public String getResourceName()
   {
      return getProperty(RESOURCE_NAME);
   }

  /**
   * Sets the value of ResourceName key
   * @param resourceName  the value of ResourceName
   */
   public void setResourceName(String resourceName)
   {
      setProperty(RESOURCE_NAME, resourceName);
   }

  /**
   * Gets the value of ResourceTypeName key.
   * @return the value of ResourceTypeName key
   */
   public String getResourceTypeName()
   {
      return getProperty(RESOURCETYPE_NAME);
   }

  /**
   * Sets the value of ResourceTypeName key.
   * @param resourceTypeName  the value of ResourceTypeName
   */
   public void setResourceTypeName(String resourceTypeName)
   {
      setProperty(RESOURCETYPE_NAME, resourceTypeName);
   }

  /**
   * Gets the FlexAttribute1 value.
   * @return the value of FlexAttribute1
   */
   public String getFlexAttribute1()
   {
      return getProperty(FLEX_ATTRIBUTE1);
   }

  /**
   * Sets the value of the FlexAttribute1
   * @param flexAttr
   */
   public void setFlexAttribute1(String flexAttr)
   {
      setProperty(FLEX_ATTRIBUTE1, flexAttr);
   }

  /**
   * Gets the FlexAttribute2 value.
   * @return the value of FlexAttribute2
   */
   public String getFlexAttribute2()
   {
      return getProperty(FLEX_ATTRIBUTE2);
   }

  /**
   * Sets the value of the FlexAttribute2
   * @param flexAttr
   */
   public void setFlexAttribute2(String flexAttr)
   {
      setProperty(FLEX_ATTRIBUTE2, flexAttr);
   }

  /**
   * Gets the FlexAttribute3 value.
   * @return the value of FlexAttribute3
   */
   public String getFlexAttribute3()
   {
      return getProperty(FLEX_ATTRIBUTE3);
   }

  /**
   * Sets the value of the FlexAttribute3
   * @param flexAttr
   */
   public void setFlexAttribute3(String flexAttr)
   {
      setProperty(FLEX_ATTRIBUTE3, flexAttr);
   }

  /**
   * Gets the value for the specified key.
   * @param key the key
   * @return the value for the key
   */
   public Object get(Object key)
   {
      if (key.equals("userId"))
      {
         return getUserId();
      }
      else if (key.equals("password"))
      {
         return getPassword();
      }
      else if (key.equals("resourceName"))
      {
         return getResourceName();
      }
      else if (key.equals("resourceTypeName"))
      {
         return getResourceTypeName();
      }
      else if (key.equals("flexAttribute1"))
      {
         return getFlexAttribute1();
      }
      else if (key.equals("flexAttribute2"))
      {
         return getFlexAttribute2();
      }
      else if (key.equals("flexAttribute3"))
      {
         return getFlexAttribute3();
      }
      return super.get(key);
   }


  /**
   * Maps the specified key to the specified value
   * @param key the key
   * @param value the value
   * @return 
   */
   public Object put(Object key, Object value)
   {
      Object oldValue = super.get(key);

      if (key.equals("userId"))
      {
         setUserId((String)value);
      }
      else if (key.equals("password"))
      {
         setPassword((String)value);
      }
      else if (key.equals("resourceName"))
      {
         setResourceName((String)value);
      }
      else if (key.equals("resourceTypeName"))
      {
         setResourceTypeName((String)value);
      }
      else if (key.equals("flexAttribute1"))
      {
         setFlexAttribute1((String)value);
      }
      else if (key.equals("flexAttribute2"))
      {
         setFlexAttribute2((String)value);
      }
      else if (key.equals("flexAttribute3"))
      {
         setFlexAttribute3((String)value);
      }
      else
      {
         super.put(key, value);
      }
      return oldValue;
   }
}

