package oracle.adf.share.security.providers.jazn;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.naming.Binding;
import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NameClassPair;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NamingException;
import javax.naming.NameNotFoundException;
import javax.naming.OperationNotSupportedException;
import javax.security.auth.Subject;

import java.security.Permission;
import java.security.Principal;
import java.security.AccessController;
import java.security.AccessControlContext;
  
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.ADFSecurityUtil;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.security.SecurityContextImpl;
import oracle.adf.share.security.SecurityEnv;

import oracle.security.jazn.action.GetJAZNConfigPropertyAction;
import oracle.security.jazn.util.JAZNSecurityManager;
import oracle.security.jazn.JAZNPermission;
import oracle.adf.share.security.authentication.ADFRolePrincipal;
import oracle.adf.share.security.authentication.ADFUserPrincipal;

import oracle.security.jazn.util.Env;

public class JAZNSecurityContext extends SecurityContextImpl implements SecurityContext
{
   private static JAZNContextHelper _ctx;
   private JAZNSecurityManager _jaznSM;
   private ADFLogger _adfSecLogger;

   public JAZNSecurityContext()
   {
      this(null);
   }

   public JAZNSecurityContext(Hashtable env)
   {
      super(env);
      _ctx = JAZNContextHelper.getInstance(env);
      _adfSecLogger = _ctx.getADFSecurityLogger();
      checkEnableAnyoneRole();
   }

   public Object addToEnvironment(String propName, Object propVal)
      throws NamingException
   {
      if ((propName == null) || (propName.equals("")))
      {
	 throw new InvalidNameException("Empty name.");
      }

      if (propName == Context.SECURITY_PRINCIPAL && propVal != null)
      {
	 setPrincipal(propVal);
	 return propVal; 
      }

      return (propVal != null) ? mEnv.put(propName, propVal) : null;
   }


   public Principal getUserPrincipal()
   {
      Principal p = (Principal)mEnv.get(Context.SECURITY_PRINCIPAL);
      if (p != null)
	  return p;

      p = (Principal)mEnv.get(SecurityEnv.ADF_ANONYMOUS_USER);
      if (p != null)
          return p;

      Subject subject = getSubject();
      if (subject != null && isAnyoneEnabled() && !ADFSecurityUtil.hasAnyoneRole(subject))
      {
         addADFRoleToSubject();
      }

      if (subject != null && subject.getPrincipals() != null)
      {
         Iterator principalIterator = subject.getPrincipals().iterator();
         while (principalIterator.hasNext())
         {
            p = (Principal)principalIterator.next();
            if (p.getName().equals(SecurityEnv.ADF_ANONYMOUS_USER))
            {
               mEnv.put(SecurityEnv.ADF_ANONYMOUS_USER, p);
               break;
            }
         }
      }

      return p;
   }
 
   public String getUserName()
   {
      Principal p = getUserPrincipal();
      return (p != null) ? p.getName() : null;
   }

   public boolean isAuthorizationEnabled()
   {
      Object value = mEnv.get(SecurityEnv.SECURITY_AUTHORIZATION_ENFORCE);
      return (value != null ? (value.equals(SecurityEnv.SECURITY_CHECKED) ? true : false) : false);
   }


   public boolean hasPermission(Permission permission)
   {
      boolean bOk = true;
      Principal principal = getUserPrincipal();
      AccessControlContext context = AccessController.getContext();
      Subject subject = Subject.getSubject(context);
      if (subject == null)
      {
         _adfSecLogger.log(Level.FINE, "no subject base permission");
         JAZNPolicyProvider policyProvider = _ctx.getPolicyProvider();
         bOk = policyProvider.hasPermission(permission, principal);
      }
      else
      {
         showPrincipals();
         _adfSecLogger.log(Level.FINE, "-- AccessController.checkPermission " 
             + permission.getName() + ", " + permission.getActions());

         try
         {
            AccessController.checkPermission(permission);
         }
         catch (Exception ex)
         {
            bOk = false;
            if (isAnyoneEnabled() && !ADFSecurityUtil.hasAnyoneRole(subject))
            {
	       addADFRoleToSubject();
               try
               {
	          AccessController.checkPermission(permission);
	          bOk = true;
	       }
               catch (Exception ex2)
               {
               }
	    }
	 }
     }
      /*
      SecurityManager sm = System.getSecurityManager();
      if (sm != null)
      {

         try
         {
            sm.checkPermission(permission);
         }
         catch (SecurityException e)
         {
            return false;
         }
         return true;
      }
      else 
      {      
          JAZNPolicyProvider policyProvider = _ctx.getPolicyProvider();
          return policyProvider.hasPermission(permission, principal);
      }
      */

     if (!bOk)
     {
        _adfSecLogger.log(Level.FINE, "checkPermission no permission: " + permission.getName() + ", " + permission.getActions());
        mEnv.put(SecurityEnv.JAAS_PERMISSION_CHECK, "true");   
     }
     return bOk;
   }

   synchronized void setPrincipal(Object principal)
   {
       if (principal == null)
       {
          return;
       }

       mEnv.put(SecurityEnv.SECURITY_AUTHENTICATED, SecurityEnv.SECURITY_CHECKED);
       mEnv.put(Context.SECURITY_PRINCIPAL, principal);

       //For testing only
       try
       {
          String enforce = System.getProperty(SecurityEnv.SECURITY_AUTHORIZATION_ENFORCE);
          if (enforce != null)
          {
             mEnv.put(SecurityEnv.SECURITY_AUTHORIZATION_ENFORCE, enforce);
          }
       }
       catch (Exception e)
       {
          e.printStackTrace();
       }
   }

   public void refresh(boolean bSave)
   {
      if (bSave)
      {
         _ctx.persistJAZNData();
      }
      _ctx.refresh(new Hashtable());
   }

   void addADFRoleToSubject()
   {
      AccessControlContext context = AccessController.getContext();
      Subject subject = Subject.getSubject(context);
      if (subject != null)
      {
	 Principal anonymous = new ADFUserPrincipal(SecurityEnv.ADF_ANONYMOUS_USER);
	 subject.getPrincipals().add(anonymous);
	 Principal anyone = new ADFRolePrincipal(SecurityEnv.ADF_ANYONE_ROLE);
	 ((ADFRolePrincipal)anyone).addUserGrantee(anonymous);
	 subject.getPrincipals().add(anyone);
      }
   }

   void checkEnableAnyoneRole()
   {
     String value = null;
     try
     {
	value = System.getProperty(SecurityEnv.PROP_ANYONE_ENABLED);
     }
     catch (Exception e)
     {
     }

     if (value != null && value.equals("false"))
     {
	mEnv.put(SecurityEnv.PROP_ANYONE_ENABLED, "false");
     }
     else
     {
	mEnv.put(SecurityEnv.PROP_ANYONE_ENABLED, "true");
     }
   }

   void showPrincipals()
   {
      if (_adfSecLogger == null || _adfSecLogger.getLevel() == null)
         return;

      if (_adfSecLogger.getLevel().intValue() > Level.FINE.intValue())
         return;

      Subject subject = getSubject();
      
      if (subject != null && subject.getPrincipals() != null)
      {
         _adfSecLogger.log(Level.FINE, "---- principals in subject");

         Iterator principalIterator = subject.getPrincipals().iterator();
         while (principalIterator.hasNext())
         {
            Principal p = (Principal)principalIterator.next();
            _adfSecLogger.log(Level.FINE, "\t---- " + p.getName());

         }
      }
      else 
      {
         _adfSecLogger.log(Level.FINE, "---- no subject, principals ");
      }
   }
}      

