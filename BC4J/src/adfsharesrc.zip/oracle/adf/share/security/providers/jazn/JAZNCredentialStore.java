package oracle.adf.share.security.providers.jazn;

import oracle.adf.share.security.credentialstore.Credential;
import oracle.adf.share.security.credentialstore.CredentialStore;
import oracle.adf.share.security.credentialstore.spi.GenericCredentialStore;
import oracle.adf.share.security.credentialstore.spi.CredentialProvisioning;
import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.security.SecurityEnv;

import oracle.security.jazn.JAZNConfig;
import oracle.security.jazn.JAZNException;
import oracle.security.jazn.realm.Realm;
import oracle.security.jazn.realm.RealmUser;
import oracle.security.jazn.spi.xml.XMLRealmUser;
import oracle.security.jazn.realm.UserManager;
import oracle.security.jazn.realm.RealmManager;
import oracle.security.jazn.util.Env;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.io.Serializable;
import java.net.URL;

import java.security.Principal;

import oracle.adf.share.security.CredentialNotFoundException;
import oracle.adf.share.security.ADFSecurityRuntimeException;
import oracle.adf.share.security.resource.ADFSecurityMessages;
import oracle.adf.share.security.resource.ADFSecurityMessageBundle;
import oracle.adf.share.common.SerializableObject;

import java.security.AccessController;
import java.security.AccessControlContext;
import javax.security.auth.Subject;
import java.security.CodeSource;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;

import java.util.logging.Level;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.ADFSecurityUtil;


/**
 * Implementation of CredentialStore for Resource Access Descriptor.
 */
public class JAZNCredentialStore extends GenericCredentialStore implements CredentialProvisioning
{
   private JAZNContextHelper _contextHelper = null;
   private JAZNConfig _config = null;
   private JAZNConfig _embeddedConfig = null;
   private RealmManager _realmMgr = null;
   private Realm _defaultRealm = null;
   private String _default_realm = null;
                  
   static final String USERID = "name";
   static final String CREDENTIALS = "credentials";
   static String MAP_CREDENTIAL_SEPARATOR = "#";
   boolean createDefaultUser = true;

   static int counter = 0;
   int count = 0;

   private static ADFLogger _adfSecLogger = ADFSecurityUtil.getADFLogger();

   public JAZNCredentialStore()
   {
       Hashtable env = null;
       try 
       {
          env = ADFContext.getCurrent().getSecurityContext().getEnvironment();
       }
       catch (Exception e)
       {
       }

       initialize(env);
   }
   /*
   public JAZNCredentialStore()
   {
      this(JAZNContextHelper.getInstance());
      JAZNContextHelper.getInstance().setCredentialStore(this);
   }

   public JAZNCredentialStore(JAZNContextHelper jaznCtx)
   {
       _contextHelper = jaznCtx;
       _config = _contextHelper.getJAZNConfig();
       _embeddedConfig = _contextHelper.getEmbeddedJAZNConfig();
   }
   */
   public void initialize(Hashtable env)
   {
      count = counter++;
      _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore initialize, thread name: " + Thread.currentThread().getName() + " Count=" + count);

      if (env != null)
      {
	 String default_realm = (String) env.get(SecurityEnv.PROP_CREDENTIAL_STORE_DEFAULT_REALM);
         if (default_realm == null) {
          default_realm = (String) env.get(Env.PROP_DEFAULT_REALM);
	 }
         if (default_realm == null) {
            default_realm = SecurityEnv.JAZN_REALM_DEFAULT;
         }

         String location = (String) env.get(SecurityEnv.PROP_CREDENTIAL_STORE_LOCATION);
         if (location != null) {
         
            String locationPath = getJAZNLocationPath(location);
            _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore locationPath = " + locationPath);

            Properties props = new Properties();
            props.setProperty(Env.PROP_LOCATION, locationPath);
            props.setProperty(Env.PROVIDER_TYPE, Env.PROVIDER_TYPE_XML);
            props.setProperty(Env.PROP_DEFAULT_REALM, default_realm );
            _config = new JAZNConfig(props);
         }

         if (_config == null)
         {
            _contextHelper = JAZNContextHelper.getInstance();
            _config = _contextHelper.getJAZNConfig();
            _embeddedConfig = _contextHelper.getEmbeddedJAZNConfig();
            _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore NO locationPath! Use default " + _config.getLocationPath());
         }

         try
         {
            _realmMgr = _config.getRealmManager();
            _defaultRealm = _realmMgr.getRealm(default_realm);
         }
         catch(Exception exception)
         {
            exception.printStackTrace();
            throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_STORE_INIT));
         } 

	 if (_defaultRealm == null)
         {
            String realmName = _config.getDefaultRealm();
	    if (realmName.equals(default_realm))
	    {
               _adfSecLogger.log(Level.FINE, "-- JAZNConfig default realm " + realmName);
	    }
            throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_CREDENTIAL_REALM, new Object[]{default_realm}));
	 } 
      }
      _default_realm = _config.getDefaultRealm();
   }

   String getCredential(XMLRealmUser user) throws java.security.PrivilegedActionException
   {
       final XMLRealmUser xmlUser = user;
       _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore getCredentials realmUser " + user.getName());

       String cred = "";
       AccessControlContext context = AccessController.getContext();
       Subject subject = Subject.getSubject(context);
       try 
       {
	  if (subject != null)
	  {
	     cred = (String)Subject.doAs(subject, new java.security.PrivilegedExceptionAction()
	     { 
	        public Object run() throws Exception
	        { 
	           byte[] credBytes = xmlUser.getClrCredentials();
                   if (credBytes != null)
	              return new String(credBytes);
	           else
	              return "";
	        } 
	     }); 
	  } 
	  else
	  {
             byte[] credBytes = xmlUser.getClrCredentials();        
             if (credBytes != null)
                cred = new String(credBytes);
	  }
       }
       catch (Exception e)
       {
          throw e;
       }
       
       return cred;
   }

  /**
   * Stores the credential object using the sepcified credential key.  The credential is stored as
   * a property set in Resource Access Descriptor (cn) under Extended Properties (cn) in Oracle Internet Directory
   * @param cred    the credential to store.
   * @param credKey the credential key.
   */
   public void storeCredential(Credential cred, String credKey)
   {
      storeCredential(cred, credKey, getUserPrincipal());
   }

   void storeCredentialForUser(Credential cred, String credKey, Principal principal, JAZNConfig jaznconfig)
   {
      _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore storeCredentials for user jazn path " + _config.getLocationPath());

      RealmUser user = findRealmUser(credKey, principal, jaznconfig);          
      if (user == null)
      {
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_USER));
      }
       _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore storeCredentials for user " + user.getName());

      /*
      byte[] credBytes = ((XMLRealmUser)user).getClrCredentials();
      String oldCred = credBytes == null ? "" : new String(credBytes);
      */
      try
      {
         String oldCred = getCredential((XMLRealmUser)user);
	 if (oldCred != null && oldCred.length() > 0 && 
	      !isCredentialType(oldCred))
	 {
	    throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_STORE_CREDENTIAL, new Object[]{credKey}));
	 }
         String newCred = credentialToMapProperties(cred, credKey);
         ((XMLRealmUser)user).setCredentials(oldCred, newCred);
         jaznconfig.getJAZNProvider().persist();
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_STORE_CREDENTIAL, new Object[]{credKey}));
      }
   }

  /**
   * Retrieves the credential of the specified credential key.
   * @param credKey  credential key.
   * @return the credential for the specified credential key
   */
   public Credential fetchCredential(String credKey)
   {
       _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore fetchCredentials..");

      String userName = getMapUserName(getUserPrincipalName(), credKey);
      RealmUser realmUser = getRealmUser(userName);
      Credential credential = null;
      if (realmUser != null)
      {
         credential = fetchCredentialForUser(credKey, realmUser);
      }

      if (credential == null)
      {
         String appUser = getApplicationUserName();
         if (appUser != null)
         {
            _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore fetchCredentials appUser " + appUser);
            userName = getMapUserName(appUser, credKey);
            realmUser = getRealmUser(userName);
            credential = fetchCredentialForUser(credKey, realmUser);
         }
      }
      
      if (credential == null)
      {
         _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore fetchCredentials NO Credentials!");

         throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }
      return credential;
   }

   Credential fetchCredentialForUser(String credKey, RealmUser realmUser)
   {
       _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore fetchCredentials for user jazn path " + _config.getLocationPath());

      if (!isXMLRealmUser(realmUser))
      {
         //throw unsupported exception
        return null;
      }
      _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore fetchCredentials for user " + realmUser.getName());
               
//      byte[] credBytes = ((XMLRealmUser)realmUser).getClrCredentials();
      try
      {
	  String cred = getCredential((XMLRealmUser)realmUser);
	  return mapPropertiesToCredential(cred);
      }
      catch (Exception e)
      {
	  throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }
   }

  /**
   * Retrieves a list of credential objects 
   * @return an array list of credential objects
   */
   //public ArrayList fetchCredentials()
   ArrayList fetchCredentials()
   {
      ArrayList list = new ArrayList();
      return list;
   }

  /**
   * Removes the credential sepcified by the credential key.
   * @param credKey
   */
   public void removeCredential(String credKey)
   {
      String userName = getMapUserName(getUserPrincipalName(), credKey);
      RealmUser realmUser = getRealmUser(userName);
      removeCredentialForUser(credKey, realmUser, _config);
      if (_embeddedConfig != null)
      {
         realmUser = getRealmUser(userName, _embeddedConfig);
         if (realmUser != null)
         {
            removeCredentialForUser(credKey, realmUser, _embeddedConfig);
         }
      }
   }

   void removeCredentialForUser(String credKey, RealmUser user, JAZNConfig jaznconfig)
   {
      if (user != null)
      {
          try
          {
             UserManager usrMgr = user.getRealm().getUserManager();
             usrMgr.dropUser(user.getFullName());
             jaznconfig.getJAZNProvider().persist();
          }
          catch(Exception ex)
          {
             ex.printStackTrace();
             throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_DELETE_CREDENTIAL, new Object[]{credKey}));
          }
       }
   }

  /**
   * Store the credential for the specified credential key and principal.
   * @param cred  the credential 
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void storeCredential(Credential cred, String credKey, Principal principal)
   {
/*
      String userName = getMapUserName(principal.getName(), credKey);
      RealmUser realmUser = getRealmUser(userName);
      if (realmUser == null)
      {
         UserManager usrMgr = getUserManager(principal.getName());
         try
         {
             realmUser = usrMgr.createUser(userName);
             realmUser.setDeactivated(false);
         }
         catch(Exception ex)
         {
           ex.printStackTrace();
         }
      }
      if (!isXMLRealmUser(realmUser))
      {
         //throw invalid user exception
//        return;
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_USER));
      }
*/
      if (principal == null)
      {
         principal = getUserPrincipal();
      }
       _adfSecLogger.log(Level.FINE, "-- JAZNCredentialStore storeCredentials...");

      storeCredentialForUser(cred, credKey, principal, _config);
      if (_embeddedConfig != null)
      {
         storeCredentialForUser(cred, credKey, principal, _embeddedConfig);
      }
   }

   public void storeSerializableCredential(Serializable serCred, String credKey, Principal principal)
   {                                      
      SerializableObject serObject = null;
      if (!(serCred instanceof SerializableObject))
      {
         serObject = new SerializableObject(serCred);
      }
      else
      {
         serObject = (SerializableObject) serCred;
      }

      if (principal == null)
      {
         principal = getUserPrincipal();
      }
      storeSerializableCredentialForUser(serObject, credKey, principal, _config);
      if (_embeddedConfig != null)
      {
        storeSerializableCredentialForUser(serObject, credKey, principal, _embeddedConfig);
      }
   }

   void storeSerializableCredentialForUser(SerializableObject serObject, String credKey, Principal principal, JAZNConfig jaznconfig)
   {
      RealmUser realmUser = findRealmUser(credKey, principal, jaznconfig);          
      if (realmUser == null)
      {
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_USER));
      }

//      byte[] credBytes = ((XMLRealmUser) realmUser).getClrCredentials();
//      String oldCred = credBytes == null ? "" : new String(credBytes);

      try
      {
	 String oldCred = getCredential((XMLRealmUser) realmUser);
	 if (oldCred != null && oldCred.length() > 0 && 
	      isCredentialType(oldCred))
	 {
	    throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_STORE_CREDENTIAL, new Object[]{credKey}));
	 }

         String newCred = serObject.streamToString();
         ((XMLRealmUser) realmUser).setCredentials(oldCred, newCred);
         jaznconfig.getJAZNProvider().persist();
      }
      catch(Exception ex)
      {
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_STORE_CREDENTIAL, new Object[]{credKey}));
      }
   }

   Serializable fetchSerializableCredentialForUser(String credKey, RealmUser realmUser)
   {
      if (!isXMLRealmUser(realmUser))
      {
         //throw unsupported exception
         return null;
      }
      
//      byte[] credBytes = ((XMLRealmUser)realmUser).getClrCredentials();
//      SerializableObject _serObject = (SerializableObject) SerializableObject.streamStringToObject(new String(credBytes));
      SerializableObject _serObject = null;
      try
      {
         String cred = getCredential((XMLRealmUser)realmUser);
         _serObject = (SerializableObject) SerializableObject.streamStringToObject(cred);
      }
      catch (Exception ex)
      {
	  throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }

      if (_serObject != null)
      {
         Serializable serCred = _serObject.getSerializableObject();
         return serCred;
      }
      return null;
   }

   public Serializable fetchSerializableCredentialForCurrentUser(String credKey)
   {
      Principal p = null;
      SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
      if (secCtx != null)
      {
         p = secCtx.getUserPrincipal();
      }

      Serializable serCred = null;
      if (p != null)
      {
         String userName = getMapUserName(p.getName(), credKey);
         RealmUser realmUser = getRealmUser(userName);
         if (realmUser != null)
         {
            serCred = fetchSerializableCredentialForUser(credKey, realmUser);
         }
      }
      if (serCred == null)
      {
         throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }
      return serCred;
   }

   public Serializable fetchSerializableCredential(String credKey)
   {
      String userName = getMapUserName(getUserPrincipalName(), credKey);
      RealmUser realmUser = getRealmUser(userName);
      Serializable serCred = null;
      if (realmUser != null)
      {
         serCred = fetchSerializableCredentialForUser(credKey, realmUser);
      }
      if (serCred == null)
      {
         String appUser = getApplicationUserName();
         if (appUser != null)
         {
            userName = getMapUserName(appUser, credKey);
            realmUser = getRealmUser(userName);
            serCred = fetchSerializableCredentialForUser(credKey, realmUser);
         }
      }
      
      if (serCred == null)
      {
         throw new CredentialNotFoundException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_NOT_FOUND, new Object[]{credKey}));
      }
      return serCred;
   }

  /**
   * Removes the credential specified by the credential key.
   * @param credKey  the credential key
   * @param principal  the user or role principal
   */
   public void removeCredential(String credKey, Principal principal)
   {
      if (principal == null)
      {
         principal = getUserPrincipal();
      }
      String userName = getMapUserName(principal.getName(), credKey);
      RealmUser realmUser = getRealmUser(userName, _config);
      if (realmUser != null)
      {
         removeCredentialForUser(credKey, realmUser, _config);
      }
      else
      {
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_DELETE_CREDENTIAL, new Object[]{credKey}));
      }

      if (_embeddedConfig != null)
      {
         realmUser = getRealmUser(userName, _embeddedConfig);
         if (realmUser != null)
         {
            removeCredentialForUser(credKey, realmUser, _embeddedConfig);
         }
      }
   }


   String getRealmName(String name)
   {
      int ix = name.indexOf("/");
      if (ix > 0)
      {
         return name.substring(0, ix);
      }
      return "";
   }

   RealmUser getRealmUser(String userName)
   {
      return getRealmUser(userName, _config);
   }

   RealmUser getRealmUser(String userName, JAZNConfig jaznconfig)
   {
      UserManager userMgr = getUserManager(userName, jaznconfig);
      if (userMgr != null)
      {
	 try
	 {
	    return userMgr.getUser(userName);
	 }
	 catch (JAZNException je)
	 {
	    je.printStackTrace();
	 }
      }
      return null;
   }

   boolean isXMLRealmUser(RealmUser user)
   {
      return (user instanceof XMLRealmUser) ? true : false;
   }

   UserManager getUserManager(String userName)
   {
      return getUserManager(userName, _config);
   }
   
   UserManager getUserManager(String userName, JAZNConfig jaznconfig)
   {
      _adfSecLogger.log(Level.FINE, "  ---- getUserManager REFRESH");
      _config.getJAZNProvider().refresh();

      String realmName = (userName != null && userName.length() > 0) ? getRealmName(userName) : "";
      Realm realm = null;
      UserManager userMgr = null;
      try
      {
         if (realmName.length() == 0)
         {
	    realm = jaznconfig.getRealmManager().getRealm(jaznconfig.getDefaultRealm());
	    if (realm != null)
            {
	       userMgr = realm.getUserManager();
            }
         }

         if (realmName.length() != 0)
         {
            realm = jaznconfig.getRealmManager().getRealm(realmName);
         }
         userMgr = (realm == null ? null : realm.getUserManager());
      }
      catch (JAZNException je)
      {
         je.printStackTrace();
      }

      return userMgr;
   }

   Principal getUserPrincipal()
   {
      Principal p = null;
      SecurityContext secCtx = ADFContext.getCurrent().getSecurityContext();
      if (secCtx != null)
      {
         p = secCtx.getUserPrincipal();
         if (p == null)
         {
            p = getDefaultUser();          
         }
      }
      return p;
   }

   String getUserPrincipalName()
   {
      String userName = "";
      Principal p = getUserPrincipal();

      if (p != null)
      {
         userName = p.getName();
      }
      
      return userName;
   }

   String getMapUserName(String principalName, String credKey)
   {
      StringBuffer buf = new StringBuffer();

      if (credKey.indexOf("/") >= 0)
      {
         String realmName = getRealmName(principalName);
         if (realmName == null || realmName.length() == 0)
            realmName = getDefaultRealmName();
        buf.append(realmName);
        buf.append("/");
      }
      buf.append(principalName);
      buf.append(MAP_CREDENTIAL_SEPARATOR);
      buf.append(credKey);
      return buf.toString();
   }

   String getUserNameFromMap(String name)
   {
      int ix = name.indexOf(MAP_CREDENTIAL_SEPARATOR);
      if (ix > 0)
      {
         return name.substring(0, ix);
      }
      return "";
   }

   String getCredentialKeyFromMap(String name)
   {
      String credKey = "";
      int ix = name.indexOf(MAP_CREDENTIAL_SEPARATOR);
      if (ix > 0)
      {
         credKey = name.substring(ix+1);
      }
      
      return credKey;
   }
 
   Credential mapPropertiesToCredential(String mapCred)
   {
      SerializableObject aObj = (SerializableObject) SerializableObject.streamStringToObject(mapCred);
      Serializable object = aObj.getSerializableObject();
      if (object instanceof Hashtable)
      {
         Hashtable hTable = (Hashtable) object;
         Credential c = new Credential();
         Iterator iter = hTable.keySet().iterator();
         while (iter.hasNext())
         {
            String name = (String)iter.next();
            c.put(name, hTable.get(name));
            _adfSecLogger.log(Level.FINE, "  ---- Credentials name=" + name +", value=" + hTable.get(name));
         }
         return c;
      }
      return null;
   }

   String credentialToMapProperties(Credential cred, String credKey)
   {
      //dumpCredentials(cred);
      Hashtable props = cred.getProperties();
      SerializableObject serObject = new SerializableObject((Serializable)props);
      return serObject.streamToString();
   }

   RealmUser findRealmUser(String credKey, Principal principal, JAZNConfig jaznconfig)
   {
      String userName = getMapUserName(principal.getName(), credKey);
      RealmUser realmUser = getRealmUser(userName, jaznconfig);
      if (realmUser == null)
      {
         UserManager usrMgr = getUserManager(principal.getName(), jaznconfig);
	 if (usrMgr != null)
         {
	    try
	    {
		realmUser = usrMgr.createUser(userName);
		realmUser.setDeactivated(false);
	    }
	    catch(Exception ex)
	    {
	      ex.printStackTrace();
	    }
	 }
      }
      if (!isXMLRealmUser(realmUser))
      {
         //throw invalid user exception
//        return;
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_INVALID_USER));
      }
      return realmUser;
   }

   void validateJAZNConfig()
   {
      if (_config == null)
      {
          throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_UNSUPPORTED_SECURITY_CONFIG));
      }
   }

   
   public String getDefaultRealmName()
   {
      Realm realm = getDefaultRealm();
      if (realm != null) 
      {
         return realm.getName();
      }
      return null;
   }
   

   public Realm getDefaultRealm()
   {
      validateJAZNConfig();
      try
      {
         _realmMgr = _config.getRealmManager();
         _defaultRealm = _realmMgr.getRealm(_default_realm);
      }
      catch (Exception exception)
      {
         exception.printStackTrace();
         throw new ADFSecurityRuntimeException(ADFSecurityMessageBundle.getString(ADFSecurityMessageBundle.EXC_CREDENTIAL_STORE_INIT));
      } 
      return _defaultRealm;
   }                

   Principal getDefaultUser()
   {
      RealmUser realmUser = null;
      Realm   realm = getDefaultRealm();
      if (createDefaultUser && 
          _config.getProviderType().equalsIgnoreCase("XML"))
      {
         //realmUser = getRealmUser(SecurityEnv.CREDENTIAL_STORE_USER_DEFAULT);
         realmUser = getRealmUser(getApplicationUserName());
         if (realmUser == null && realm != null)
         {
            try
            {
               UserManager usrMgr = realm.getUserManager();
               realmUser = usrMgr.createUser(SecurityEnv.CREDENTIAL_STORE_USER_DEFAULT);
            }
            catch(Exception ex)
            {
               ex.printStackTrace();
            }
         }
	 if (realmUser != null)
         {
            realmUser.setDeactivated(false);
	 }
      }
      return (Principal)realmUser;
   }

   Realm getJAZNRealm(String realmName, JAZNConfig jaznConfig)
   {
      Realm realm = null;
      try
      {
         RealmManager realmMgr = jaznConfig.getRealmManager();
         if (realmMgr != null)
         {
            realm = realmMgr.getRealm(realmName);
         }
      }
      catch (JAZNException je)
      {
      }
      return realm;
   }

   String getJAZNLocationPath(String location)
   {
      URL url = null;
      boolean bRelativePath = false;
      final  String ADFCONFIG_FILENAME = "META-INF/adf-config.xml";

      if (location.startsWith("."))
      {
         bRelativePath = true; 
         // relative path from /META-INF/adf-config.xml
         ClassLoader cl = Thread.currentThread().getContextClassLoader();
         
         try
         {
            String resourceName = ADFCONFIG_FILENAME;
            url = cl.getResource(resourceName);
         }
         catch (Exception e)
         {
         }
      }
      String fileName = location;

      if (url != null)
      {
         fileName = url.getFile();
      }

      String path = null;
      try 
      {
         java.io.File file = new java.io.File(fileName);
         path = file.getAbsolutePath();

         if (bRelativePath)
         {
             java.io.File parentFile = file.getParentFile();
             String parentPath = (parentFile != null) ? parentFile.getAbsolutePath() : "/" ;

             StringBuffer sbuf = new StringBuffer(parentPath); 
             sbuf.append("/");
             sbuf.append(location);
             path = sbuf.toString();
         }
      }
      catch (Exception e)
      {

      }

      return path;
    }

   static boolean isCredentialType(String cred)
   {
      SerializableObject _serObject = null;
      try
      {
	 _serObject = (SerializableObject) SerializableObject.streamStringToObject(cred);
      }
      catch (Exception ex)
      {
	  ex.printStackTrace();
      }
      if (_serObject != null)
      {
	  Serializable object = _serObject.getSerializableObject();
	  if (object instanceof Hashtable)
	  {
	     return true;
	  }
      }
      return false;
   }

   void dumpCredentials(Credential cred)
   {
      Iterator iter = cred.keySet().iterator();
     
      while (iter.hasNext())
      {
         String name = (String)iter.next();
         _adfSecLogger.log(Level.FINEST, "  ----  storeCredentials name=" + name +", value=" + cred.get(name));
      }
   }
}

 


