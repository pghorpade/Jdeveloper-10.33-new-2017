package oracle.adf.share.security.providers.jazn;

import oracle.security.jazn.JAZNConfig;
import oracle.security.jazn.realm.Realm;
import oracle.security.jazn.realm.RealmPrincipal;
import oracle.security.jazn.realm.RealmRole;
import oracle.security.jazn.realm.RealmUser;
import oracle.security.jazn.realm.RoleManager;
import oracle.security.jazn.realm.RealmManager;
import oracle.security.jazn.spi.xml.XMLRealmManager;
import oracle.security.jazn.spi.xml.XMLRoleManager;
import oracle.security.jazn.spi.xml.XMLPrincipal;
import oracle.security.jazn.policy.GlobalPolicy;
import oracle.security.jazn.policy.Grantee;
import oracle.security.jazn.policy.JAZNPolicy;
import oracle.security.jazn.policy.RealmPolicy;
import oracle.security.jazn.policy.PermissionClassDesc;
import oracle.security.jazn.policy.PermissionClassManager;
import oracle.security.jazn.util.Env;
import oracle.security.jazn.util.ItemDesc;
import oracle.security.jazn.util.NVPair;
import oracle.security.jazn.JAZNException;

import javax.security.auth.Policy;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.lang.reflect.Constructor;

import java.security.Principal;
import javax.security.auth.Subject;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.ProtectionDomain;
import java.security.CodeSource;
import java.security.Provider;

import java.util.Properties;

import oracle.adf.share.security.authorization.PermissionClassDescriptor;
import oracle.adf.share.security.authorization.PermissionActionDescriptor;
import oracle.adf.share.security.authorization.PermissionTargetDescriptor;
import oracle.adf.share.security.authorization.PolicyStatement;
import oracle.adf.share.security.authorization.ADFPermission;
import oracle.adf.share.security.authorization.spi.PolicyInspection;
import oracle.adf.share.security.identitymanagement.Role;
import oracle.adf.share.security.SecurityEnv;
import oracle.adf.share.security.authentication.ADFRolePrincipal;
import oracle.adf.share.security.authentication.ADFUserPrincipal;

import oracle.adf.share.ADFContext;

import oracle.security.jazn.realm.InitRealmInfo;

public class JAZNPolicyProvider implements PolicyInspection
{
   private JAZNContextHelper _contextHelper;
   private boolean isRealmPolicySupported = true;
//   private static boolean bAddPermission = false; // LDAP does not support addPermission
   private static boolean _bAddPermission = false; // LDAP does not support addPermission
   private static ProtectionDomain _thisPD = null;  
   private static CodeSource _thisCS = null;        

   static char NAME_ACTION_SEPARATOR = '$';
   static String PAGE_PERMISSION_CLASS = "oracle.adf.share.security.authorization.mds.PagePermission";
   static String MDS_PERMISSION_CLASS = "oracle.adf.share.security.authorization.mds.MDSPermission";

   private JAZNConfig _primaryConfig = null;
   private JAZNConfig _config = null;
   private JAZNConfig _localConfig = null;
   private static Grantee _anyoneGrantee = null;

   public JAZNPolicyProvider()
   {
      this(JAZNContextHelper.getInstance());
   }

   public JAZNPolicyProvider(JAZNContextHelper jaznCtx)
   {
       _contextHelper = jaznCtx;
       init();
   }

   public void init()
   {
      _config = _contextHelper.getJAZNConfig();
      _primaryConfig = _contextHelper.getEmbeddedJAZNConfig();
      if (_primaryConfig == null)
      {
         _primaryConfig = _config;
      }
      _thisPD = getClass().getProtectionDomain();
      _thisCS = _thisPD.getCodeSource();
      if (!_primaryConfig.getProviderType().equals(Env.PROVIDER_TYPE_LDAP))
      {
         isRealmPolicySupported = false;
      }
   }

   public void setLocalConfigPath(String path)
   {
      try
      {
         if (!_primaryConfig.getProviderType().equals(Env.PROVIDER_TYPE_LDAP))
         {
            Properties props = new Properties();
             
            props.setProperty(Env.PROP_DEFAULT_REALM, "jazn.com"); // NORES
            props.setProperty(Env.PROVIDER_TYPE, Env.PROVIDER_TYPE_XML);
            props.setProperty(Env.PROP_LOCATION, path);
            _localConfig = new JAZNConfig(props);

            Realm dflt = getJAZNRealm(_localConfig.getDefaultRealm(), _localConfig);
            
            if (dflt == null)
            {
               // API demands creating admin user/role, so just drop right after.
               dflt = ((XMLRealmManager) _localConfig.getRealmManager()).createRealm(_localConfig.getDefaultRealm(), "oc4jadmin", "welcome", "oc4j-administrators"); // NORES
              
               ((XMLRoleManager) dflt.getRoleManager()).dropRole("oc4j-administrators", true); // NORES
               dflt.getUserManager().dropUser("oc4jadmin"); // NORES
            }
         }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
   }
      
   public void refresh(boolean bSave)
   {
      if (bSave)
      {
         _contextHelper.persistJAZNData(_primaryConfig);
         if (_localConfig != null)
         {
            _contextHelper.persistJAZNData(_localConfig);
         }
      }
   }


   Realm getJAZNRealm(String realmName, JAZNConfig jaznConfig)
   {
      Realm realm = null;
      try
      {
         RealmManager realmMgr = jaznConfig.getRealmManager();
         if (realmMgr != null)
         {
            realm = realmMgr.getRealm(realmName);
         }
      }
      catch (JAZNException je)
      {
      }
      return realm;
   }


   public JAZNPolicy getGlobalPolicy()
   {
      return getGlobalPolicy(_primaryConfig);
   }

   private JAZNPolicy getGlobalPolicy(JAZNConfig jaznConfig)
   {
      JAZNPolicy jaznpolicy = null;
      try
      {
        jaznpolicy = jaznConfig.getPolicyManager().getGlobalPolicy();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return jaznpolicy;
   }

   public JAZNPolicy getRealmPolicy(Realm realm)
   {
      return getRealmPolicy(realm, _primaryConfig); 
   }

   public JAZNPolicy getRealmPolicy(Realm realm, JAZNConfig jaznConfig)
   {
      JAZNPolicy jaznpolicy = null;
      if (!isRealmPolicySupported)
      {
         return null;
      }
      try
      {
         jaznpolicy = jaznConfig.getPolicyManager().getRealmPolicy(realm);
      }
      catch (Exception e)
      {
         isRealmPolicySupported = false;
//         e.printStackTrace();
      }
      return jaznpolicy;
   }



  public void addPolicyStatement(PolicyStatement policyStatement)
  {
     Permission perm = policyStatement.getPermission();
     if (_bAddPermission)
     {
        addPerm(perm.getName() /* dispalyName */,
                perm.getClass().getName(),
                new String[] {perm.getActions()} /*action desc */,
                perm.getName(), "ADF");

     }

     Realm realm = null;
     Principal principal = policyStatement.getPrincipal();

     PolicyStatement[] stmts = getPolicyStatements(principal, new Class[] {policyStatement.getPermission().getClass()});
     for (int i = 0; i < stmts.length; i++)
     {
        Permission permission = stmts[i].getPermission();
        if (permission.getName().equalsIgnoreCase(policyStatement.getPermission().getName()) &&
            permission.getActions().equalsIgnoreCase(policyStatement.getPermission().getActions()))
        {
           return;
        }
     }

     if (principal instanceof RealmPrincipal)
     {
        realm = ((RealmPrincipal)principal).getRealm();
     }
     else if (principal instanceof XMLPrincipal)
     {
        String realmName = ((XMLPrincipal)principal).getPrincipalRealmName();
        realm = getJAZNRealm(realmName, _primaryConfig);
     }

     if (realm == null)
     {
	 realm = getJAZNRealm(_primaryConfig.getDefaultRealm(), _primaryConfig);
     }
     grantPermission(principal, realm, perm.getClass().getName(),
                     new String[] {perm.getName(), perm.getActions()}, _primaryConfig);

     if (_config != _primaryConfig && _contextHelper.isDualUpdate())
     {
        realm = getJAZNRealm(realm.getName(), _config);
	RealmRole realmRole = _contextHelper.getRealmRole(principal.getName(), _config);
	if (realm != null && realmRole != null)
        {
           grantPermission(principal, realm, perm.getClass().getName(),
                     new String[] {perm.getName(), perm.getActions()}, _config);
        }
     }
     
     if (_localConfig != null)
     {
        try
        {
           Realm existing = getJAZNRealm(realm.getName(), _localConfig);
           if (existing == null)
           {
              // API demands creating admin user/role, so just drop right after.
              existing = ((XMLRealmManager) _localConfig.getRealmManager()).createRealm(realm.getFullName(), "oc4jadmin", "welcome", "oc4j-administrators"); // NORES
              ((XMLRoleManager) existing.getRoleManager()).dropRole("oc4j-administrators", true); // NORES
              existing.getUserManager().dropUser("oc4jadmin"); // NORES
           }
           RealmRole realmRole = _contextHelper.getRealmRole(principal.getName(), _localConfig);
           Principal role = null;
           if (realmRole != null)
           {
              role = realmRole;
           }
           else if (principal.getName().equals(SecurityEnv.ADF_ANYONE_ROLE))
           {
              role = JAZNIdentityManagementProvider.getADFRolePrincipal();
           }
           else
           {
              role = existing.getRoleManager().createRole(principal.getName());
           }
           if (existing != null && role != null)
           {
              grantPermission(role, existing, perm.getClass().getName(),
                       new String[] {perm.getName(), perm.getActions()}, _localConfig);
           }
        }
        catch (Exception e)
        {
           e.printStackTrace();
        }
     }
/*   
     if (policyStatement.getPermission().getClass().getName().equals(PAGE_PERMISSION_CLASS))
     {
        try 
        {
          Class cls = Class.forName(MDS_PERMISSION_CLASS);
          Class clsParam = Class.forName("java.security.Permission"); //NOTRANS
          Class[] params = new Class[]{clsParam};
          Constructor ctr = cls.getConstructor(params); 
          Permission p = (Permission)ctr.newInstance(new Object[] {perm});
          grantPermission(principal.getName(), realm, p.getClass().getName(),
                    new String[] {getGrantName(p)});
        }
        catch (Exception e)
        {
           e.printStackTrace(System.err);
           throw new IllegalStateException(e.getMessage());
        }
      }
*/
     
//     _contextHelper.persistJAZNData();
  }

  public void removePolicyStatement(PolicyStatement policyStatement)
  {
     Principal principal = policyStatement.getPrincipal();
     PolicyStatement[] stmts = getPolicyStatements(principal, new Class[] {policyStatement.getPermission().getClass()});
     for (int i = 0; i < stmts.length; i++)
     {
        Permission permission = stmts[i].getPermission();
        if (permission.getName().equalsIgnoreCase(policyStatement.getPermission().getName()))
        {
           revokePerm(principal, permission, _primaryConfig);
	   Realm realm = null;
	   if (principal instanceof RealmPrincipal)
	   {
	      realm = ((RealmPrincipal)principal).getRealm();
	   }
	   else if (principal instanceof XMLPrincipal)
	   {
	      String realmName = ((XMLPrincipal)principal).getPrincipalRealmName();
	      realm = getJAZNRealm(realmName, _primaryConfig);
	   }

           if (_config != _primaryConfig && _contextHelper.isDualUpdate())
           {
	     realm = getJAZNRealm(realm.getName(), _config);
	     RealmRole realmRole = _contextHelper.getRealmRole(principal.getName(), _config);
	     if (realm != null && realmRole != null)
	     {
                revokePerm(policyStatement.getPrincipal(), policyStatement.getPermission(), _config);
             }
	   }
           
           if (_localConfig != null)
           {
              RealmRole realmRole = _contextHelper.getRealmRole(principal.getName(), _localConfig);
              Principal role = null;
              if (realmRole != null)
              {
                 realm = realmRole.getRealm();
                 role = realmRole;
              }
              else if (realmRole == null && principal.getName().equals(SecurityEnv.ADF_ANYONE_ROLE))
              {
                 role = JAZNIdentityManagementProvider.getADFRolePrincipal();
                 realm = getJAZNRealm(_primaryConfig.getDefaultRealm(), _primaryConfig);
              }
              if (realm != null && role != null)
              {
                 revokePerm(role, policyStatement.getPermission(), _localConfig);
              }
           }
        }
     }
//     _contextHelper.persistJAZNData();
  }

  public PolicyStatement[] getPolicyStatements(Principal principal, Class[] permissionClasses)
  {
     RealmRole realmRole = _contextHelper.getRealmRole(principal.getName(), _primaryConfig);
     Principal role = null;
     Realm  realm = null;
     if (realmRole != null)
     {
	realm = realmRole.getRealm();
	role = realmRole;
     }
     else if (realmRole == null && principal.getName().equals(SecurityEnv.ADF_ANYONE_ROLE))
     {
	role = JAZNIdentityManagementProvider.getADFRolePrincipal();
        realm = getJAZNRealm(_primaryConfig.getDefaultRealm(), _primaryConfig);
     }
//     ArrayList permissions = retrieveGrantedPermissions(realmRole, permissionClasses);
     ArrayList permissions = retrieveGrantedPermissions(realm, role, permissionClasses);
     PolicyStatement[] policyStatements = new PolicyStatement[permissions.size()];
     for (int i = 0; i < permissions.size(); i++)
     {
        Permission perm = (Permission) permissions.get(i);    
        policyStatements[i] = new PolicyStatement(principal, perm);
     }
     
     return policyStatements;
  }

  public PolicyStatement[] getPolicyStatements(String resourceId, Class permissionClass)
  {
     ArrayList stmts = new ArrayList();
     Collection grantees = null;
     Realm realm = getJAZNRealm(_primaryConfig.getDefaultRealm(), _primaryConfig);
     JAZNPolicy jaznpolicy = getRealmPolicy(realm);
     try
     {
         if (jaznpolicy == null)
         {
            jaznpolicy = getGlobalPolicy();
            grantees = ((GlobalPolicy) jaznpolicy).getGrantees(); 
         }
         else
         {
            grantees = ((RealmPolicy) jaznpolicy).getGrantees(); 
         }

         Iterator iter = grantees.iterator();
         while (iter.hasNext())
         {
             Grantee grantee = (Grantee)iter.next();
             ArrayList permissions = retrieveGrantedPermissions(jaznpolicy, grantee, new Class[] {permissionClass});
             Set principals = grantee.getPrincipals();
             Iterator i = principals.iterator();
             while (i.hasNext())
             {
                Principal p = (Principal) i.next();
    		if (_anyoneGrantee == null)
	        {
		   if (p.getName().equals(SecurityEnv.ADF_ANYONE_ROLE))
		   {
		       _anyoneGrantee = grantee;
		   }
		}
                for (int j = 0; j < permissions.size(); j++)
                {
                   Permission perm = (Permission) permissions.get(j);    
                   if (perm.getName().equals(resourceId))
                   {
                       stmts.add(new PolicyStatement(p, perm));
                   }
                }
            }
        }
     }
     catch (JAZNException e)
     {
     }
     return (PolicyStatement[])stmts.toArray(new PolicyStatement[stmts.size()]);
  }

  public PermissionClassDescriptor[] getPermissionClassDescriptors()
  {
     return null;
  }

  public boolean addPermissionClassDescriptor(PermissionClassDescriptor permClassDescriptor)
  {
     PermissionClassDescriptor permDesc = getPermissionClassDescriptor(permClassDescriptor.getPermissionClass());
     if (permDesc == null)
     {
        PermissionActionDescriptor[] actionDescs = permClassDescriptor.getPermissionActionDescriptors();
        String actions[] = null;
        if (actionDescs != null && actionDescs.length > 0)
        {
           actions = new String[actionDescs.length];
           for (int i = 0; i < actionDescs.length; i++)
           {
              actions[i] = actionDescs[i].getName();
           }
        }
        
        addPerm(permClassDescriptor.getDisplayName() /* dispalyName */,
                permClassDescriptor.getPermissionClass().getName(),
                actions,
                permClassDescriptor.getDisplayName(), "ADF");

     }
     return true;
  }

  public boolean removePermissionClassDescriptor(Class permClass)
  {
     //TODO: need to check no grantee for permClass before remove
     return false;
  }

  public PermissionClassDescriptor getPermissionClassDescriptor(Class permClass)
  {
     PermissionClassManager permMgr = _primaryConfig.getPermissionClassManager();
     PermissionClassDesc desc = permMgr.getPermissionClass(permClass.getName());
     if (desc == null)
     {
        return null;
     }

     ItemDesc itemDesc = desc.getClassDesc(); 
    // String className =  ((NVPair)itemDesc).getName();

     Collection actionsDesc = desc.getActionsDesc();
     Iterator actionsDescIter = actionsDesc.iterator();
     PermissionActionDescriptor[] actionDescs = new PermissionActionDescriptor[actionsDesc.size()];
     int i = 0;
     while (actionsDescIter.hasNext())
     {
        NVPair nvPair = (NVPair)actionsDescIter.next();
        PermissionActionDescriptor actionDesc = new PermissionActionDescriptor(nvPair.getName(), nvPair.getValue());
        actionDescs[i++] = actionDesc; 
     }

     Collection targetsDesc = desc.getTargetsDesc();
     Iterator targetsDescIter = targetsDesc.iterator();
     PermissionTargetDescriptor[] targetDescs = new PermissionTargetDescriptor[targetsDesc.size()];
     i = 0;
     while (targetsDescIter.hasNext())
     {
        NVPair nvPair = (NVPair)targetsDescIter.next();
        PermissionTargetDescriptor targetDesc = new PermissionTargetDescriptor(nvPair.getName(), nvPair.getValue());
        targetDescs[i++] = targetDesc; 
     }

    return new PermissionClassDescriptor(itemDesc.getDisplayName(), permClass,
                                      actionDescs, targetDescs);
  }

  private String getGrantName(Permission permission)
  {
      StringBuffer s = new StringBuffer(permission.getName());
      s.append(NAME_ACTION_SEPARATOR).append(permission.getActions());
      return s.toString();
  }


  public void grantPermission(Principal principal, Realm realm, String permClassName, String permClsParams[], JAZNConfig jaznconfig)
  {
      try
      {
          Grantee grantee = createGrantee(realm, principal);

          JAZNPolicy jaznpolicy = getRealmPolicy(realm, jaznconfig);
          if (jaznpolicy == null)
          {
             jaznpolicy = getGlobalPolicy(jaznconfig);
          }

          Constructor aconstructor[] = Class.forName(permClassName).getConstructors();
          Object obj = null;
          if (permClsParams == null)
          {
             permClsParams = new String[0];
          }
          else
          {
             for (int i = 0; i < aconstructor.length; i++)
             {
                 try
                 {
                    if (permClsParams.length == aconstructor[i].getParameterTypes().length)
                    {
                       obj = aconstructor[i].newInstance(permClsParams);
                    }
                 }
                 catch (IllegalArgumentException illegalargumentexception)
                 {
                 }
             }
          }

          if (obj == null)
          {
             System.out.println("Invalid argument ");
          }
          else
          {
             jaznpolicy.grant(grantee, (Permission)obj);
          }
      }
      catch(Exception exception)
      {
         exception.printStackTrace();
      }
   }

   private ArrayList retrieveGrantedPermissions(JAZNPolicy jaznpolicy, Grantee grantee, Class[] permissionClasses)
   {
       ArrayList permissions = new ArrayList();
       try
       {
           for (int i = 0; i < permissionClasses.length; i++ )
           {
              PermissionCollection permissioncollection = jaznpolicy.getPermissions(grantee, permissionClasses[i]);
              if (permissioncollection == null)
              {
                 continue;
              }

              Enumeration enumeration = permissioncollection.elements();

              for (; enumeration.hasMoreElements();)
              {
                 Permission p = (Permission)enumeration.nextElement();
                 if (p.getClass() == permissionClasses[i])
                 {
                    //System.out.println(p.getClass().getProtectionDomain().getCodeSource().getLocation());
                    //System.out.println("Permission: " + p.getName()); 
                    permissions.add(p);
                 }
              }
           }
       }
       catch (Exception e)
       {
          e.printStackTrace();
       }
       return permissions;
   }


   private ArrayList retrieveGrantedPermissions(Realm realm, Principal role, Class[] permissionClasses)
   {
       ArrayList permissions = new ArrayList();
       try
       {
           JAZNPolicy jaznpolicy = getRealmPolicy(realm);
           if (jaznpolicy == null)
           {
              jaznpolicy = getGlobalPolicy();
           }

           Grantee grantee = new Grantee(role);

           for (int i = 0; i < permissionClasses.length; i++ )
           {
              PermissionCollection permissioncollection = jaznpolicy.getPermissions(grantee, permissionClasses[i]);
              if (permissioncollection == null)
              {
                 continue;
              }

              Enumeration enumeration = permissioncollection.elements();

              for (; enumeration.hasMoreElements();)
              {
                 Permission p = (Permission)enumeration.nextElement();
                 if (p.getClass() == permissionClasses[i])
                 {
                    //System.out.println(p.getClass().getProtectionDomain().getCodeSource().getLocation());
                    //System.out.println("Permission: " + p.getName()); 
                    permissions.add(p);
                 }
              }
           }
       }
       catch (Exception e)
       {
          e.printStackTrace();
       }
       return permissions;
   }

   private void addPerm(String s, String s1, String[] s2, String s3, String permissionDescType)
   {
      if(s2.equals("-null"))
          s2 = null;
      if(s3.equals("-null"))
          s3 = null;
      byte byte0;
      if(s1.startsWith("oracle.security.jazn"))
          byte0 = 1;
      else
      if(s1.startsWith("java"))
          byte0 = 0;
      else
      if(s1.startsWith("oracle"))
          byte0 = 2;
      else
          byte0 = 3;

      ItemDesc itemdesc = new ItemDesc(s1, permissionDescType, s);

      NVPair anvpair[] = null;
      if(s2 != null)
      {
         anvpair = new NVPair[s2.length];
         for (int i = 0; i < s2.length; i++)
         {
            anvpair[i] = new NVPair(s2[i], "");
         }
      }
      else
          anvpair = null;

      NVPair anvpair1[] = new NVPair[1];
      if(s3 != null)
          anvpair1[0] = new NVPair(s3, "");
      else
          anvpair1 = null;

      try
      {
         JAZNContextHelper.getPermissionClassManager().addPermissionClass(new PermissionClassDesc(byte0, itemdesc, anvpair1, anvpair));
      }
      catch (Exception e)
      {
          e.printStackTrace();
      }
   }

   void revokePerm(Principal principal, Permission perm, JAZNConfig jaznconfig)
   {
      try
      {
          Realm realm = getRealm(principal, jaznconfig);
          JAZNPolicy jaznpolicy = getRealmPolicy(realm, jaznconfig);
          if (jaznpolicy == null)
          {
             jaznpolicy = getGlobalPolicy(jaznconfig);
          }

          Grantee grantee = createGrantee(realm, principal);

          //System.out.println("Remove Permission: "+ perm.getClass().getName());
          jaznpolicy.revoke(grantee, perm);
      }
      catch (Exception e)
      {
         _contextHelper.getADFSecurityLogger().log(Level.FINE, "Error revoke perm " + perm.getName());
      }
   }

   public boolean hasPermission(Permission perm, Principal principal)
   {
      if (principal == null || perm == null)
      {
         return false;
      }

      Realm realm = getRealm(principal);
      ArrayList principals = getGrantedRoles(principal, realm); 
 
      try
      {
         JAZNPolicy jaznpolicy = null;
         if (isRealmPolicySupported && realm != null)
         {
            jaznpolicy = getRealmPolicy(realm);
         }
         if (jaznpolicy == null)
         {
            jaznpolicy = getGlobalPolicy();
         }
         for (int j = 0; j < principals.size(); j++)
         {
            Grantee grantee = new Grantee((Principal)principals.get(j));
            if (jaznpolicy.hasPermission(grantee, perm))
            {
               return true;
            }
         }  
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return false;   
   }

   Realm getRealm(Principal principal)
   {
      return getRealm(principal, _primaryConfig);
   }

   Realm getRealm(Principal principal, JAZNConfig jaznConfig)
   {
      if (principal == null)
      {
         return null;
      }

      Realm realm = null;
      String name = principal.getName();
      try
      {
         int sep = name.indexOf('/');
         if (sep != -1)
         {
            String realm_name = name.substring(0, sep);
            realm = jaznConfig.getRealmManager().getRealm(realm_name);
         }
         else
         {
            realm = jaznConfig.getRealmManager().getRealm(jaznConfig.getDefaultRealm());
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return realm;
   }

   Principal getRealmPrincipal(Realm realm, String userName)
   {
      RealmUser realmUser = null;
      try
      {
         realmUser = realm.getUserManager().getUser(userName);
      }
      catch (JAZNException e)
      {
        e.printStackTrace();
      }
     return (Principal)realmUser;
   }

   String getPrivileges(String permCls, String target, Principal principal)
   {
       StringBuffer  actionsBuffer = new StringBuffer();
 
       Realm realm = getRealm(principal);
       ArrayList principals = getGrantedRoles(principal, realm); 
       principals.add(principal);

       try
       {
           JAZNPolicy jaznpolicy = getRealmPolicy(realm);
           if (jaznpolicy == null)
           {
              jaznpolicy = getGlobalPolicy();
           }

           for (int j = 0; j < principals.size(); j++)
           {
              Grantee grantee = new Grantee((RealmPrincipal)principals.get(j));
             
              String[] permClasses = new String[]{permCls};
              int count = 0;
             
              for (int i = 0; i < permClasses.length; i++ )
              {
                 PermissionCollection permissioncollection = jaznpolicy.getPermissions(grantee, Class.forName(permClasses[i]));
                 if (permissioncollection == null)
                 {
                    continue;
                 }
             
                 Enumeration enumeration = permissioncollection.elements();
             
                 for (; enumeration.hasMoreElements();)
                 {
                    Permission p = (Permission)enumeration.nextElement();
                    if (p.getName().equals(target))
                    {
                       if (count > 0)
                       {
                          actionsBuffer.append(",");
                       }
                       actionsBuffer.append(p.getActions());
                       count++;
                    }
                 }
             }
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }

      Vector actionsVector = ADFPermission.parseActions(actionsBuffer.toString());
      String actions = "";
      for (int i = 0; i < actionsVector.size(); i++)
      {
        if (i > 0 && i < actionsVector.size())
          actions += ",";
         actions += (String)actionsVector.elementAt(i);
      }
      return actions;
   }

   ArrayList getGrantedRoles(Principal p, Realm realm)
   {
      Subject s = ADFContext.getCurrent().getSecurityContext().getSubject();
      if (s != null) 
         return getRolesFromSubject(s);

      ArrayList roleList = new ArrayList();
      roleList.add(p);

      if (ADFContext.getCurrent().getSecurityContext().isAnyoneEnabled())
      {
	 Principal anonymous = new ADFUserPrincipal(SecurityEnv.ADF_ANONYMOUS_USER);
	 Principal anyone = new ADFRolePrincipal(SecurityEnv.ADF_ANYONE_ROLE);
	 ((ADFRolePrincipal)anyone).addUserGrantee(anonymous);
	 roleList.add(anyone);
      }


      RealmManager realmMgr = _primaryConfig.getRealmManager();
      if (realm != null && realmMgr instanceof XMLRealmManager)
      {
         try
         {
            RoleManager roleMgr = realm.getRoleManager();
            Principal principal = getRealmPrincipal(realm, p.getName());
            Set roles = ((XMLRoleManager)roleMgr).getGrantedRoles((RealmPrincipal) principal, false);
            Iterator i = roles.iterator();
            while (i.hasNext())
            {
               roleList.add(i.next());
            }
       
         }
         catch (Exception e)
         {
            e.printStackTrace();
         }
      }
      return roleList;
   }

   Grantee createGrantee(Realm realm, Principal principal)
   {
      Grantee grantee = null;
      try
      {
         RoleManager roleMgr = realm.getRoleManager();
	 String name = principal.getName();
         RealmPrincipal realmPrincipal = roleMgr.getRole(name);
         if (realmPrincipal == null)
         {
            realmPrincipal = (RealmPrincipal) getRealmPrincipal(realm, name);
         }
         if (realmPrincipal != null)
         {
            grantee = new Grantee(realmPrincipal);
         }
	 else if (name.equals(SecurityEnv.ADF_ANYONE_ROLE))
	 {
	    if (_anyoneGrantee == null)
	    {
	        grantee = new Grantee(principal);
	        _anyoneGrantee = grantee;
	    }
	    else 
	    {
	       grantee = _anyoneGrantee;
	    }
	 }
      }
      catch(Exception exception)
      {
         exception.printStackTrace();
      }

      return grantee;
   }

   ArrayList getRolesFromSubject(Subject s)
   {
       ArrayList arraylist = new ArrayList();
       Iterator principalIterator = s.getPrincipals().iterator();
       while (principalIterator.hasNext())
       {
          Principal p = (Principal)principalIterator.next();
          if (p instanceof RealmRole)
          {
             arraylist.add(p);
          }
       }
       return arraylist;
   }
}





