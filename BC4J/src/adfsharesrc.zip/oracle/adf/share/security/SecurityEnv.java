package oracle.adf.share.security;

import java.io.File;

public class SecurityEnv
{
   public static final String ATTR_JAAS_CONTEXT = "initialContextFactoryClass";
   public static final String ATTR_JAAS_PROVIDER = "jaasProviderClass";
   public static final String ATTR_JAZN_CONFIG = "jaznConfigPath";
   public static final String ATTR_AUTHORIZATION_ENFORCE = "authorizationEnforce";
   public static final String ATTR_AUTHENTICATION_REQUIRE = "authenticationRequire";

   public static final String ATTR_CREDENTIAL_STORE_DEFAULT_USER = "credentialStoreDefaultUser";
   public static final String ATTR_CREDENTIAL_STORE_PROVIDER = "credentialStoreClass";
   public static final String ATTR_CREDENTIAL_STORE_LOCATION = "credentialStoreLocation";
   public static final String ATTR_CREDENTIAL_STORE_DEFAULT_REALM = "credentialStoreDefaultRealm";

   public static final String PROP_JAAS_CONTEXT_FACTORY = "oracle.adf.security.context";
   public static final String PROP_AUTHORIZATION_ENFORCE = "oracle.adf.security.authorization.enforce";
   public static final String PROP_AUTHENTICATION_REQUIRE = "oracle.adf.security.authentication.require";
   public static final String PROP_JAZN_CONFIG = "oracle.security.jazn.config";
   public static final String PROP_JAZN_SIMPLE_NAME = "jaas.username.simple";
   public static final String PROP_ANYONE_ENABLED = "oracle.adf.security.anyone.enable";

   public static final String PROP_CREDENTIAL_STORE_PROVIDER = "oracle.adf.security.credentialstore";
   public static final String PROP_CREDENTIAL_STORE_DEFAULT_USER = "oracle.adf.security.credentialstore.default.user";
   public static final String PROP_CREDENTIAL_STORE_LOCATION = "oracle.adf.security.credentialstore.location";
   public static final String PROP_CREDENTIAL_STORE_DEFAULT_REALM = "oracle.adf.security.credentialstore.default.realm";

   public static final String PROP_EMBEDDED_CONFIG_PATH = "oracle.adf.security.embedded.location";
   public static final String PROP_DUAL_AUTH = "oracle.adf.security.authorization.dual";

   public static final String JAAS_SUBJECT = "jaas.subject";

   public static final String JAAS_CONTEXT_JAZN = "oracle.adf.share.security.providers.jazn.JAZNSecurityContext";
   public static final String JAAS_CONTEXT_DEFAULT = "oracle.adf.share.security.SecurityContextImpl";

   public static final String JAAS_PERMISSION_CHECK = "jaas.permissioncheck";

   public static String AUTHORIZATION_ENFORCE_DEFAULT = "false";
   public static String AUTHENTICATION_REQUIRE_DEFAULT = "false";

   public static String CREDENTIAL_STORE_USER_DEFAULT = "anonymous";
   public static String CREDENTIAL_STORE_PROVIDER_DEFAULT = "oracle.adf.share.security.providers.jazn.JAZNCredentialStore";

   public static String JAZN_CONFIG_DIR_DEFAULT  = "config";
   public static String JAZN_CONFIG_FILE_DEFAULT= JAZN_CONFIG_DIR_DEFAULT + File.separatorChar + "jazn.xml";
   public static String JAZN_SIMPLE_NAME_DEFAULT = "true";
   public static String JAZN_REALM_DEFAULT  = "jazn.com";

   public static String JSSO_PROPERTY_LOGOUT = "custom.sso.logout";      
   //Use Internally
   public static final String  SECURITY_AUTHENTICATED = "oracle.adf.security.authenticated";
   public static final String  SECURITY_AUTHORIZATION_ENFORCE = "oracle.adf.security.authorization.enforce";
   public static final String  SECURITY_CHECKED = "true";

   public static String[][] SECURITY_CONFIG = {
	{ATTR_JAAS_PROVIDER, PROP_JAAS_CONTEXT_FACTORY},
	{ATTR_JAZN_CONFIG, PROP_JAZN_CONFIG},
	{ATTR_AUTHORIZATION_ENFORCE, PROP_AUTHORIZATION_ENFORCE},
	{ATTR_AUTHENTICATION_REQUIRE, PROP_AUTHENTICATION_REQUIRE},
    };

    public static String[][] CREDENTIALSTORE_CONFIG = {
	{ATTR_CREDENTIAL_STORE_PROVIDER, PROP_CREDENTIAL_STORE_PROVIDER},
	{ATTR_CREDENTIAL_STORE_DEFAULT_USER, PROP_CREDENTIAL_STORE_DEFAULT_USER},
        {ATTR_CREDENTIAL_STORE_LOCATION, PROP_CREDENTIAL_STORE_LOCATION},
	{ATTR_CREDENTIAL_STORE_DEFAULT_REALM, PROP_CREDENTIAL_STORE_DEFAULT_REALM},
    };

    public static final String ADF_ANONYMOUS_USER = "anonymous";
    public static final String ADF_ANYONE_ROLE = "anyone";
}

