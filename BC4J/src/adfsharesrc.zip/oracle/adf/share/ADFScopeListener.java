package oracle.adf.share;

/* $Header: ADFScopeListener.java 17-aug-2005.16:03:18 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    08/17/05 - 
    jsmiljan    02/09/05 - jsmiljan_scope_020805_1
    jsmiljan    02/08/05 - Creation
 */

/**
 *  @version $Header: ADFScopeListener.java 17-aug-2005.16:03:18 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public interface ADFScopeListener
{
   public void scopeInvalidated(String scopeName);
}

