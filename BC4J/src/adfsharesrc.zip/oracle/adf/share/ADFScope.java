package oracle.adf.share;

/* $Header: ADFScope.java 09-feb-2005.15:52:18 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    02/09/05 - jsmiljan_scope_020805_1
    jsmiljan    02/08/05 - Creation
 */

import java.util.Map;

/**
 *  @version $Header: ADFScope.java 09-feb-2005.15:52:18 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 *  <p>
 *  Defines an interface for ADFScopes.
 *  <p>
 *  This interface defines scope operations that are not supported by
 *  the base <tt>Map</tt> scope interface.  These operations include:
 *  Scope invalidation, scope lifecycle notifications.
 *  <p>
 *  A scope user may invalidate a scope by invoking the invalidate() operation
 *  on this interface.  After an ADFScope is invalidated the scope's state will be
 *  unreachable and all cached references to the invalid ADFScope must be nulled.
 *  If a scope is used after it is invalidated it may throw a RuntimeException
 *  (InvalidStateException).
 *  <p>
 *  A scope client may be notified of invalidation events by using the
 *  <tt>addScopeListener(ADFScopeListener)</tt> to register an invalidation listener.
 */
public interface ADFScope extends Map
{
   public void invalidate();
   public void addScopeListener(ADFScopeListener listener);
   public void removeScopeListener(ADFScopeListener listener);
}
