package oracle.adf.share.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;

class ADFObjectInputStream extends ObjectInputStream
{
   public ADFObjectInputStream(InputStream in) throws IOException
   {
      super(in);
   }

   protected Class resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException
   {
      Class cls = null;
      try
      {
         cls = super.resolveClass(desc);
      }
      catch(ClassNotFoundException ex)
      {
         try 
         { 
            cls = Class.forName(desc.getName(), false, Thread.currentThread().getContextClassLoader()); 
         }
         catch (ClassNotFoundException e)
         { 
            throw e; 
         }
      }
      return cls;
   }
}


