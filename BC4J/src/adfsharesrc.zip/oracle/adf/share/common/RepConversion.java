/* $Header: RepConversion.java 05-nov-2005.11:17:35 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051028 from 
                           main 
    ychua       06/30/05 - Creation
 */

/**
 *  @version $Header: RepConversion.java 05-nov-2005.11:17:35 rvangri Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.common;

/**
 * Numbers' representation conversion/manipulation routines. <br>
 */
//copied from oracle.jbo.common
//copied from jdbc source for byte to string conversion.
public class RepConversion
{
    /**
     * print byte in Hex. <br>
     * Takes a byte as an argument and prints its value in Hex. For example
     * the number 255 will print FF with no new line. <p>
     * @param b  byte to convert to hex
     */
    public static void printInHex(byte b)
    {
        // Prints the high byte 
        System.out.print( (char)nibbleToHex( (byte)( (b&0xF0)>>4) ));
        System.out.print( (char)nibbleToHex( (byte)( (b&0x0F)   ) ));
    }

    /**
     * nibble To hex. <br>
     * This will take a nibble (4 low bits of the byte passed) and
     * convert it into the Hex value. If the value of <i> nibble </i>
     * is greater than 4 bits, the 4 high bits will be filtered. <p>
     *
     * @param    nibble    Byte with a 4 bit value to convert to Hex.
     * @return hex value
     */
    public static byte nibbleToHex(byte nibble)
    {
        nibble &= (byte)0x0F;              // Filtering High byte
        return((byte)((nibble < 10)?(nibble + '0'):(nibble - 10 + 'A')));
    }

    /**
     * Converting an ascii nibble in decimal ( [0-9a-f-A-F] should be in the
     * hex range) to a 4 bit number which is the hex value (nibble). <br>
     * The ascii value passed should be in the range of [a-fA-F0-9]. There is 
     * a catch for this function, if the value passed can not be converted
     * to Hex, because it is not within this ascii range [a-fA-F0-9] the 
     * result will be the same value passed from the user. We may change
     * later to raise an exception in this case. <p>
     * nibble of the result<p>
     *
     * @param    b byte with a hex value to convert to decimal
     * @return   converted value of 4 bits (if not an error)
     */
    public static byte asciiHexToNibble(byte b)
    {
        byte value;

        if ( b >= 'a' && b <= 'f' )
            value = (byte)(b - 'a' + 10);

        else if ( b >= 'A' && b <= 'F' )
            value = (byte)(b - 'A' + 10);

        else if ( b >= '0' && b <= '9' )
            value = (byte)(b - '0');

        else
            value = b;  // Return the same value passed in

        return(value);
    }
    /**
     * Byte array to nibbles. <br>
     * Takes an array of bytes and converts it into an array of nibbles.
     * The nibbles array must be at least double the size of array. <p>
     *
     * @param       array     array of bytes to convert
     * @param       nibbles   array where the nibbles will be stored
     */
    public static void bArray2nibbles(byte[] array, byte[] nibbles)
    {
      for (int i=0; i<array.length; i++)
      {
          nibbles[i*2]     = nibbleToHex((byte)((array[i] & 0xF0) >> 4));
          nibbles[(i*2)+1] = nibbleToHex((byte)(array[i] & 0x0F)); 
      }
    }
    
    /**
     * Byte array to String. <br>
     * Takes an array of bytes and converts it into a String containing
     * its hex reprenstation.
     *
     * @param       array     array of bytes to convert
     */
    public static String bArray2String(byte[] array)
    {
      StringBuffer result = new StringBuffer (array.length * 2);
      for (int i=0; i<array.length; i++)
      {
         result.append ((char)nibbleToHex((byte)((array[i] & 0xF0) >> 4)));
         result.append ((char)nibbleToHex((byte)(array[i] & 0x0F)));
      }
      return result.toString ();
    }
    

    /**
     * Nibbles to byte array. <br>
     * Puts an array of nibbles into an array of bytes (2 nibbles per byte)
     *
     * @param      nibbles     array of nibbles 
     * @return     array       array of bytes 
     */
    public static byte[] nibbles2bArray(byte[] nibbles)
    {
        // Two nibbles per byte, we only need have the length of the array
        byte[] array = new byte[nibbles.length/2];
        
        // Put all the nibbles into a byte array
        for ( int i=0; i< array.length; i++)
        {
            array[i]  = (byte)(asciiHexToNibble(nibbles[i*2]) <<4); 
            array[i] |= asciiHexToNibble(nibbles[i*2+1]); 
        }
        return(array);
    }

    public static void printInHex(long value)
    {
        byte[] hexValue = toHex(value);
        System.out.print(new String(hexValue));
    }

    public static void printInHex(int value)
    {
        byte[] hexValue = toHex(value);
        System.out.print(new String(hexValue));
    }

    public static void printInHex(short value)
    {
        byte[] hexValue = toHex(value);
        System.out.print(new String(hexValue));
    }

    public static byte[] toHex(long value)
    {
        int lsize  = 8*2;
        byte[] hex = new byte[lsize];

        for (int i=lsize-1; i>=0; i--)
        {
            hex[i]   = nibbleToHex((byte)(value & 0x000000000000000F));
            value  >>= 4;
        }
        return(hex);
    }

    public static byte[] toHex(int value)
    {
        int lsize  = 4*2;
        byte[] hex = new byte[lsize];

        for (int i=lsize-1; i>=0; i--)
        {
            hex[i]   = nibbleToHex((byte)(value & 0x0000000F));
            value  >>= 4;
        }
        return(hex);
    }

    public static byte[] toHex(short value)
    {
        int lsize  = 2*2;
        byte[] hex = new byte[lsize];

        for (int i=lsize-1; i>=0; i--)
        {
            hex[i]   = nibbleToHex((byte)(value & 0x000F));
            value  >>= 4;
        }
        return(hex);
    }


   //the following two utitlity methods to convert from string 
   //copied from oraclexsu stuff 

  //===========================================================================
  // NAME
  //   convertCharToInt -- private static int
  // PARAMETERS
  //   charVal     (IN) - hex digit to be converted to decimal int
  // RETURNS
  //   returns a decimal integer representation of the hex digit passed in
  // DESCRIPTION
  //   converts a hex digit into a decimal digit (i.e. 0 -> 0; a -> 10 etc)
  //---------------------------------------------------------------------------
  static int convertCharToInt(char charVal)
  {
    switch(charVal)
    {
      case '0': return 0;
      case '1': return 1;
      case '2': return 2;
      case '3': return 3;
      case '4': return 4;
      case '5': return 5;
      case '6': return 6;
      case '7': return 7;
      case '8': return 8;
      case '9': return 9;
      case 'a': case 'A': return 10;
      case 'b': case 'B': return 11;
      case 'c': case 'C': return 12;
      case 'd': case 'D': return 13;
      case 'e': case 'E': return 14;
      case 'f': case 'F': return 15;
    }
    return '0';
  }

  //===========================================================================
  // NAME
  //   convertHexStringToByte -- public static byte[]
  // PARAMETERS
  //   refString     (IN) - hex string
  // RETURNS
  //   byte representation of the hex string
  // DESCRIPTION
  //   converts hexadecimal chars to bytes..
  //---------------------------------------------------------------------------
  static public byte[] convertHexStringToByte(String refString)
  {
    byte[] byteArray = new byte[refString.length()/2];

    int intVal;                                              // temporary value
    Integer newInt;                                              // temp. value

    for(int i =0; i < refString.length(); i+=2)
    {
      // handle the first digit in the hex nibble (hex digit pair)
      intVal = convertCharToInt(refString.charAt(i));
      newInt = new Integer((0xF0 & (intVal << 4)));
      byteArray[i/2] = newInt.byteValue(); 

      // handle the second digit of the nibble
      intVal = convertCharToInt(refString.charAt(i+1));
      newInt = new Integer(0x0F & intVal);
      byteArray[i/2] |= newInt.byteValue();
    }
    return byteArray;
  } 

}

