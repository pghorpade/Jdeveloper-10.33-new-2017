/* $Header: SerializableObject.java 14-mar-2006.07:34:06 ychua Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    ychua       06/30/05 - Creation
 */

/**
 *  @version $Header: SerializableObject.java 14-mar-2006.07:34:06 ychua Exp $
 *  @author  ychua   
 *  @since   release specific (what release of product did this appear in)
 */
package oracle.adf.share.common;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class SerializableObject implements Serializable
{
  Serializable mAnySerializableObject = null;
  static final long serialVersionUID = -8244401167068790334L;

  public SerializableObject(Serializable obj)
  {
      mAnySerializableObject = obj;
  }

  public Serializable getSerializableObject()
  {
     return mAnySerializableObject;
  }

  public String streamToString()
  {
      try
      {
         ByteArrayOutputStream bOut = new ByteArrayOutputStream();
         ObjectOutputStream oStrm = new ObjectOutputStream(bOut);
         oStrm.writeObject(this);
         oStrm.flush();
         oStrm.close();

         return (RepConversion.bArray2String(bOut.toByteArray()));
      }
      catch(IOException ex)
      {
         return null;
      }
   }

   public static Object streamStringToObject(String sString)
   {
      try
      {
         ByteArrayInputStream bIn = new ByteArrayInputStream(
         RepConversion.nibbles2bArray(sString.getBytes()));
         ADFObjectInputStream oStrm = new ADFObjectInputStream(bIn);
     
         SerializableObject serCred = (SerializableObject) oStrm.readObject();
        
         return serCred;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         return null;
      }
   }
}

