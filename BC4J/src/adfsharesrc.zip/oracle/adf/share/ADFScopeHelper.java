package oracle.adf.share;

/* $Header: ADFScopeHelper.java 17-aug-2005.16:02:38 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    08/17/05 - 
    jsmiljan    02/09/05 - jsmiljan_scope_020805_1
    jsmiljan    02/08/05 - Creation
 */

import java.util.ArrayList;

/**
 *  @version $Header: ADFScopeHelper.java 17-aug-2005.16:02:38 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 *
 * Internal use only.  Defines some utitlity functions for ADFScope implementations.
 */
public class ADFScopeHelper
{
   private final ArrayList mScopeListeners = new ArrayList(4);

   public void addScopeListener(ADFScopeListener listener)
   {
      if (!mScopeListeners.contains(listener))
      {
         mScopeListeners.add(listener);
      }
   }

   public void removeScopeListener(ADFScopeListener listener)
   {
      mScopeListeners.remove(listener);
   }

   public void fireScopeInvalidated(String scopeName)
   {
      for (int i=mScopeListeners.size() - 1; i >= 0; --i)
      {
         ((ADFScopeListener)mScopeListeners.get(i)).scopeInvalidated(scopeName);
      }
   }

}

