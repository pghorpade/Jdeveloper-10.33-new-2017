/*
 * @(#)ADFConfig.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.adf.share;

import java.util.Map;
import javax.naming.Context;
import javax.naming.NamingException;


/**
 * This is an interface of ADF configuration object. The Application Configuration 
 * object will manage and store the Application wide configuration information 
 * for different components of an ADF application.  
 * <p>
 * ADF configuration object is initilzed with ADF context object.
 * <p>
 *
 * @version 10.1.3, 02/05/05
 * @since 10.1.3
 * 
 */
 public interface ADFConfig 
 {

   public final static String ADFCONFIG_WAR_FILENAME = "WEB-INF/adf-config.xml";
   public final static String ADFCONFIG_META_FILENAME = "META-INF/adf-config.xml";
   /**
    *  Name of the default configuration for each component type. 
    */
   public final static String DEFAULT_CONFIGURATION = "default";

  
  /**
   * get the configuration object information stored for the provided namespace
   * 
   * @return java.util.Map storedResults for this namespace.
   * @param namespace namespace for which configObject is to be returned
   */
  public Map getConfigObject(String namespace);  
  
 /**
   *  Gets the mds instance configured for this application
   */
  public Object getMDSInstance();
  

  /**
   *  Unique identifier for this application 
   */
  public Object getId();


  
   /*  
    *  JNDI context containing the application connection 
    *  definitions. 
    *  
    */
   public Context getConnectionsContext() throws NamingException;

   /*  
    *  Security context containing the jaas configuration. 
    *  
    */
   public Context getSecurityContext() throws NamingException;
   
  

}
