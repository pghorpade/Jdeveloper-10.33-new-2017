/* $Header: ServletADFContext.java 13-sep-2006.10:47:28 nvarma Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    nvarma      08/18/06 - XbranchMerge nvarma_bug-4948621 from main
    jsmiljan    05/22/06 - 
    nvarma      11/11/05 - 
    jsmiljan    09/29/05 - 
    jsmiljan    09/01/05 - 
    jsmiljan    08/31/05 - 
    dmutreja    08/30/05 - dmutreja_move_webapp_threadcontext_to_adf_share_30aug05
    dmutreja    08/30/05 - Creation
 */

/**
 *  @version $Header: ServletADFContext.java 13-sep-2006.10:47:28 nvarma Exp $
 *  @author  dmutreja
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adf.share.http;

import java.security.Principal;

import java.util.Map;
import java.util.Hashtable;

import javax.naming.Context;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.servlet.jsp.el.VariableResolver;

import oracle.adf.share.ADFContext;
import oracle.adf.share.ADFConfig;
import oracle.adf.share.ADFScope;
import oracle.adf.share.Environment;

import oracle.adf.share.security.SecurityContext;
import oracle.adf.share.config.ADFConfigFactory;

import java.lang.reflect.Method;

import java.util.Iterator;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import oracle.adf.share.logging.ADFLogger;

/**
 *  @version $Header: ServletADFContext.java 13-sep-2006.10:47:28 nvarma Exp $
 *  @author  dmutreja
 *  @since   release specific (what release of product did this appear in)
 */
public class

ServletADFContext extends ADFContext
{
   private Environment env;
   private ADFConfig application;
   private String deployedAppName = null ;
   private static ADFLogger logger = ADFLogger.createADFLogger(ServletADFContext.class);

   private static final String SERVLET_CONTEXT_APPLICATION_SCOPE_KEY =
   "__adf_application_scope__";
    private static final String SERVLET_CONTEXT_APPLICATION_NAME_SCOPE_KEY =
    "__adf_applicationname_scope__";

   private static final String HTTP_SESSION_SCOPE_KEY = "__adf_session_scope__";

   private static HttpUtil mUtil = HttpUtil.getInstance();

   ServletADFContext()
   {
   }

   ServletADFContext(SecurityContext securityContext,
                     Environment env)
   {
      this();

      setSecurityContext(securityContext);
      setEnvironment(env);
   }

   /**
    *  Gets the ADF configuration Object used by current 
    *  thread.
    */
   public ADFConfig getADFConfig()
   {
      Environment env = getEnvironment();
      if (application == null)
      {
         if (env!= null && env.getContext()!= null )
         {
            application = ADFConfigFactory.findOrCreateADFConfig(
               env.getContext()
               , ADFConfig.ADFCONFIG_WAR_FILENAME);
         }
         else
         {
            application = ADFConfigFactory.findOrCreateADFConfig();         
         }
      }
      return application;
   }

    /**
     * Gets the Application Name. Queries the MBeanServerFactory to query for
     * JSR77 based J2EE Managed Object J2EEApplication
     */
    public String getApplicationName(){
        Map scope = getScope(APPLICATION_SCOPE);
        return (String)scope.get(SERVLET_CONTEXT_APPLICATION_NAME_SCOPE_KEY);
    }

    private void getDeployedAppName(){
        if (deployedAppName != null)
		return;
        try {
            MBeanServer mbs = MBeanServerFactory.newMBeanServer();
            String query = "*:j2eeType=J2EEApplication,*";
            java.util.Set set = mbs.queryNames(new javax.management.ObjectName(query), null);
            Iterator iter = set.iterator();
            ObjectName elem=null;
            if (iter.hasNext()) {
                elem = (ObjectName) iter.next();
            }

            deployedAppName = elem.getKeyProperty("name");

        } catch (Exception e) {
            // Do not throw error if applicationName cannot be found. 
            logger.fine("Application Name not created");
        }           
    }

   public Map createScope(String name)
   {
      Map scope = null;
      if (SESSION_SCOPE.equals(name))
      {
         HttpServletRequest request = getHttpRequest();
         if (request != null)
         {
            HttpSession session = getHttpRequest().getSession(true);
            scope = (Map)mUtil.getAttribute(session, HTTP_SESSION_SCOPE_KEY);

            if (scope == null
                || !scope.containsKey(HttpSessionScopeAdapter.VALID))
            {
               synchronized(session)
               {
                  // DCL
                  scope = (Map)mUtil.getAttribute(
                     session, HTTP_SESSION_SCOPE_KEY);

                  if (scope == null
                      || !scope.containsKey(HttpSessionScopeAdapter.VALID))
                  {
                     scope = new HttpSessionScopeAdapter(
                        SESSION_SCOPE, session);

                     mUtil.setAttribute(
                        session, HTTP_SESSION_SCOPE_KEY, scope);
                  }
               }
            }
         }
         else
         {
            super.createScope(name);
         }
      }
      else
      {
         scope = super.createScope(name);
      }

      return scope;
   }

   protected HttpServletRequest getHttpRequest()
   {
      return(HttpServletRequest) env.getRequest();
   }

   protected HttpServletResponse getHttpResponse()
   {
      return(HttpServletResponse) env.getResponse();
   }

   protected void setSecurityContext(SecurityContext ctx)
   {
      super.setSecurityContext(ctx);
      setUserPrincipal();
   }

   private void setUserPrincipal()
   {
      Principal p = getUserPrincipal();
      if (p != null)
      {
         try
         {
            SecurityContext secCtx = getSecurityContext();
            secCtx.addToEnvironment(Context.SECURITY_PRINCIPAL, p);
         }
         catch (Exception e)
         {
            e.printStackTrace();
         }
      }
   }

   protected Principal getUserPrincipal()
   {
      return mUtil.getUserPrincipal(getHttpRequest());
   }

   protected void setEnvironment(Environment env)
   {
      this.env = env;
   }

   protected Environment loadEnvironment()
   {
      return env;
   }

   public Map getStateManager(String scopeName, Hashtable env)
   {
      return new HttpStateManagerScopeAdapter(scopeName, env);
   }

   public boolean hasSession()
   {
      Object request = getEnvironment().getRequest();
      if (request instanceof HttpServletRequest)
      {
         return ((HttpServletRequest)request).getSession(false) != null;
      }

      return super.hasSession();
   }

   public int getContextType()
   {
      return TYPE_HTTP;
   }

   public boolean isHttpContext()
   {
      return true;
   }

   public static void initThreadContext(ServletContext servletContext,
                                        ServletRequest request,
                                        ServletResponse response)
   {
      ServletADFContext threadCtx = new ServletADFContext();
      threadCtx.initialize(servletContext, request, response);
   }

   protected void initialize(ServletContext servletContext
      , ServletRequest request
      , ServletResponse response)
   {
       ADFContext oldContext = ADFContext.getCurrent();
       Map requestScope = oldContext.getRequestScope();
      // This should be initialized only once per request. Use a refCount on 
      // the request to ensure this.
      
      setEnvironment(
         new ServletEnvironment(servletContext
            , (HttpServletRequest)request, (HttpServletResponse)response));

      setAsCurrent(); 
      getSecurityContext();

      // JRS 11/08/2005 Copy the old context variable resolver
      // reference.  The faces filter may set the variable resolver
      // before the ServletADFContext is initialized.
      setVariableResolver(new HttpADFContextVariableResolverImpl(
         oldContext.getVariableResolver()));

      setExpressionEvaluator(oldContext.getExpressionEvaluator());

      if (servletContext != null)
      {
         Map scope = (Map)mUtil.getAttribute(
            servletContext, SERVLET_CONTEXT_APPLICATION_SCOPE_KEY);

         if (scope == null)
         {
            synchronized(servletContext)
            {
               scope = (Map)mUtil.getAttribute(
                  servletContext, SERVLET_CONTEXT_APPLICATION_SCOPE_KEY);

               if (scope == null)
               {
                  scope = new ServletContextScopeAdapter(ADFContext.APPLICATION_SCOPE, 
                                                         servletContext);
                  mUtil.setAttribute(servletContext
                     , SERVLET_CONTEXT_APPLICATION_SCOPE_KEY, scope);
                     getDeployedAppName();
                 scope.put(SERVLET_CONTEXT_APPLICATION_NAME_SCOPE_KEY, deployedAppName);
               }
            }
         }
         putScope(ADFContext.APPLICATION_SCOPE, scope);
      }

      // bind the session scope lazily.  declare the name for now.
      putScope(ADFContext.SESSION_SCOPE, null);
      if (request != null)
      {
         HttpServletRequestScopeAdapter reqAdapter = new 
                        HttpServletRequestScopeAdapter(ADFContext.REQUEST_SCOPE, 
                                             (HttpServletRequest)request);
         putScope(ADFContext.REQUEST_SCOPE, reqAdapter);
      }

   }

   public static void resetThreadContext()
   {
      ADFContext threadCtx = ADFContext.getCurrent();
      ADFScope requestScope = (ADFScope)threadCtx.getRequestScope();
      
      if (requestScope != null)
      {
         requestScope.invalidate();

         // JRS Shouldn't the scope do this?  Not implementing for right
         // now because it is too risky
         threadCtx.removeScope(ADFContext.REQUEST_SCOPE);
      }

      threadCtx.removeAsCurrent();
   }

   public boolean hasEnvironment()
   {
      return true;
   }
}
