package oracle.adf.share.http;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Locale;

import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import oracle.adf.share.Environment;

public class ServletEnvironment extends Environment
{
   private final ServletContext mServletContext;
   private final HttpServletRequest mRequest;
   private final HttpServletResponse mResponse;
   
   public ServletEnvironment(ServletContext servletContext,
                             ServletRequest request,
                             ServletResponse response)
   {
      mServletContext = servletContext;
      mRequest = (HttpServletRequest)request;
      mResponse = (HttpServletResponse)response;
   }
           
   public Object getRequest()
   {
      return mRequest;
   }
   
   public Object getResponse()
   {
      return mResponse;
   }

   public Object getContext()
   {
      return mServletContext;
   }

   public Locale getRequestLocale()
   {
      return mRequest.getLocale();
   }

   public String getRequestServletPath()
   {
      return mRequest.getServletPath();
   }

   public String getRequestPathInfo()
   {
      return mRequest.getPathInfo();
   }

   public String encodeResourceURL(String url)
   {
      return mResponse.encodeURL(url);
   }

   public void redirect(String url)
      throws IOException
   {
      mResponse.sendRedirect(url);
   }

   public String getRequestContextPath()
   {
      return mRequest.getContextPath();
   }

   public String getRequestURI()
   {
      return mRequest.getRequestURI();
   }

   public String getRequestCharacterEncoding()
   {
      return mRequest.getCharacterEncoding();
   }

   public void setRequestCharacterEncoding(String encoding) throws IOException
   {
      mRequest.setCharacterEncoding(encoding);
   }
   
   // We may need to return an immutable map like Faces does. For now
   // it returns the real thing.
   public Map getRequestParameterMap()
   {
      return mRequest.getParameterMap();
   }
   
   public void dispatch(String requestURI)
      throws IOException
   {
      RequestDispatcher rd = mRequest.getRequestDispatcher(requestURI);

      if (rd == null)
      {
         mResponse.sendError(
             HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
             "No request dispatcher for " + requestURI);
         return;
      }

      try
      {
         rd.forward(mRequest, mResponse);
      }
      catch (IOException ioe)
      {
         throw ioe;
      }

      catch (ServletException se)
      {
         // TODO
         // Need to somehow wrap the exception here
      }
   }
   
   
   
} 
