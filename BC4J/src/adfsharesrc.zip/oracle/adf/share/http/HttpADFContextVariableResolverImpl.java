package oracle.adf.share.http;


/* $Header: HttpADFContextVariableResolverImpl.java 10-nov-2005.10:06:10 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    11/10/05 - XbranchMerge jsmiljan_fix_kava_103105 from main 
    jsmiljan    09/13/05 - 
    jsmiljan    08/12/05 - jsmiljan_bug-3688418
    jsmiljan    07/19/05 - 
    jsmiljan    07/13/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/22/05 - Creation
 */

import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.VariableResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

import javax.servlet.ServletContext;

import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Set;
import java.util.Collection;

import oracle.adf.share.ADFContext;

import oracle.adf.share.el.ADFContextVariableResolverImpl;

/**
 *  A variable resolver that may be used against the ADFContext.  This 
 *  variable resolver may be used when other variable resolvers like the
 *  FacesContext variable resolver and the PageContext variable resolver are
 *  not available.
 *  <p>
 *  This variable resolver should not be seen as a replacement for the
 *  JSP/JSF variable resolvers.  Those variable resolvers should be used
 *  whenever they are available in the container.
 *  <p>
 *  This variable resolver attempts to support many of the implicit objects
 *  that are defined for both the JSP variable resolver and the Faces
 *  resolver.  The following standard implicit objects are supported:
 *  <p>
 *  <tt>requestScope</tt>
 *  <tt>sessionScope</tt>
 *  <tt>applicationScope</tt>
 *  <tt>param</tt>
 *  <tt>paramValues</tt>
 *  <tt>header</tt>
 *  <tt>initParam</tt>
 *  <tt>cookie</tt>
 *  <p>
 *  Please see the JSP/JSF specifications for more information about
 *  each of these implicit objects.
 *  <p>
 *  The HttpADFContextVariableResolverImpl does define an extended implicit
 * object set for ADF.  The following ADF implicit objects are supported:
 * <p>
 * <tt>securityContext</tt> -- Resolves to the current {@link oracle.adf.share.security.SecurityContext}.
 *    Equivalent to invoking:
 *       <tt> ADFContext.getCurrent().getSecurityContext()</tt>
 *    
 * <p>
 * If you wish to use the ADF variable resolver with one of the JSP or
 * JSF variable resolvers then you may pass the JSP/JSF variable resolver
 * to the HttpADFContextVariableResovler constructor.  This will cause the
 * JSP/JSF variable resolver to be decorated by the ADF variable resolver.
 * You may then pass the ADF variable resolver to the JSP/JSF expression
 * evaluator.
 *
 *  @version $Header: HttpADFContextVariableResolverImpl.java 10-nov-2005.10:06:10 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpADFContextVariableResolverImpl implements VariableResolver
{
   static final String HTTP_REQUEST_SCOPE = "__http_request_scope__";
   static final String PORTLET_REQUEST_SCOPE = "__portlet_request_scope__";
   static final String HTTP_SESSION_SCOPE  = "__http_session_scope__";
   static final String PORTLET_SESSION_SCOPE = "__portlet_session_scope__";
   static final String HTTP_APPLICATION_SCOPE  = "__http_application_scope__";
   static final String PORTLET_APPLICATION_SCOPE = "__portlet_application_scope__";
   static final String HTTP_PARAM_MAP = "__http_param_map__";
   static final String HTTP_PARAM_VALUES_MAP = "__http_param_values_map__";
   static final String HTTP_HEADER_MAP = "__http_header_map__";
   static final String HTTP_HEADER_VALUES_MAP = "__http_header_values_map__";
   static final String HTTP_INIT_PARAM_MAP = "__http_init_param_map__";
   static final String HTTP_COOKIE_MAP = "__http_cookie_map__";

   private final Hashtable mMapCache = new Hashtable(10);

   private final VariableResolver mParentResolver;

   private boolean mResolveImplicit = true;

   public HttpADFContextVariableResolverImpl(VariableResolver parentResolver)
   {
      if (parentResolver == null)
         parentResolver = new ADFContextVariableResolverImpl();

      mParentResolver = parentResolver;
   }

   public Object resolveVariable(String name) throws ELException
   {
      ADFContext adfContext = ADFContext.getCurrent();

      if (isResolveImplicit())
      {
         // STANDARD IMPLICIT OBJECTS
         // Check for implicit objects
   //      if ("pageScope".equals (name))
   //      {
   //      }
         if ("requestScope".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpRequestScope((HttpServletRequest)request);
            }
   //         else if (request instanceof PortletRequest)
   //         {
   //            return getPortletRequestScope((PortletRequest)request);
   //         }

            return null;
         }
         else if ("sessionScope".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpSessionScope(((HttpServletRequest)request).getSession(true));
            }

            return null;
         }
         else if ("applicationScope".equals (name))
         {
            Object context = adfContext.getEnvironment().getContext();
            if (context instanceof ServletContext)
            {
               return getHttpApplicationScope((ServletContext)context);
            }
   //         else if (context instanceof PortletContext)
   //         {
   //            return getPortletApplicationScope((PortletContext)context);
   //         }

            return null;
         }
         else if ("param".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpParamMap((HttpServletRequest)request);
            }

            return null;
         }
         else if ("paramValues".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpParamValuesMap((HttpServletRequest)request);
            }

            return null;
         }
         else if ("header".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpHeaderMap((HttpServletRequest)request);
            }

            return null;
         }
   //      else if ("headerValues".equals (name))
   //      {
   //         Object request = adfCont.getEnvironment().getRequest();
   //         if (request instanceof HttpServletRequest)
   //         {
   //            return getHttpHeaderValuesMap((HttpServletRequest)request);
   //         }
   //
   //         return null;
   //      }
         else if ("initParam".equals (name))
         {
            Object context = adfContext.getEnvironment().getContext();
            if (context instanceof ServletContext)
            {
               return getHttpInitParamMap((ServletContext)context);
            }

            return null;
         }
         else if ("cookie".equals (name))
         {
            Object request = adfContext.getEnvironment().getRequest();
            if (request instanceof HttpServletRequest)
            {
               return getHttpCookieMap((HttpServletRequest)request);
            }

            return null;
         }
      }

      Object rtn = mParentResolver.resolveVariable(name);
      if (rtn != null) return rtn;

      // now start the check in the default scopes, request, session
      // and application.
      if (isResolveImplicit())
      {
         Object request = adfContext.getEnvironment().getRequest();
         if (request instanceof HttpServletRequest)
         {
            rtn = ((HttpServletRequest)request).getAttribute(name);
            if (rtn != null) return rtn;

            HttpSession session = ((HttpServletRequest)request)
               .getSession(false);

            rtn = session.getAttribute(name);
            if (rtn != null) return rtn;
         }

         Object application = adfContext.getEnvironment().getContext();
         if (application instanceof ServletContext)
         {
            rtn = ((ServletContext)application).getAttribute(name);
            if (rtn != null) return rtn;
         }
      }

      return null;
   }

   public void setResolveImplicit(boolean resolveImplicit)
   {
      mResolveImplicit = resolveImplicit;
   }

   /**
    * When false the resolver will not attempt implicit object
    * resolution.
    */
   public boolean isResolveImplicit()
   {
      return mResolveImplicit;
   }
   private Object getHttpRequestScope(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_REQUEST_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_REQUEST_SCOPE, map);
      }
      return map;
   }

/*
   private Object getPortletRequestScope(final PortletRequest request)
   {
      Map map = (Map)mMapCache.get(PORTLET_REQUEST_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_REQUEST_SCOPE, map);
      }
      return map;
   }
*/

   private Object getHttpSessionScope(final HttpSession session)
   {
      Map map = (Map)mMapCache.get(HTTP_SESSION_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return session.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_SESSION_SCOPE, map);
      }
      return map;
   }

   private Object getHttpApplicationScope(final ServletContext context)
   {
      Map map = (Map)mMapCache.get(HTTP_APPLICATION_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return context.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_APPLICATION_SCOPE, map);
      }
      return map;
   }

/*
   private Object getPortletApplicationScope(final PortletContext context)
   {
      Map map = (Map)mMapCache.get(PORTLET_APPLICATION_SCOPE);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return context.getAttribute((String)key);
               }
               return null;
            }
         };
         mMapCache.put(PORTLET_APPLICATION_SCOPE, map);
      }
      return map;
   }
*/

   private Object getHttpParamMap(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_PARAM_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getParameter((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_PARAM_MAP, map);
      }
      return map;
   }

   private Object getHttpParamValuesMap(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_PARAM_VALUES_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getParameterValues((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_PARAM_VALUES_MAP, map);
      }
      return map;
   }

   private Object getHttpHeaderMap(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_HEADER_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getHeader((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_HEADER_MAP, map);
      }
      return map;
   }
/*
   private Object getHttpHeaderValuesMap(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_HEADER_VALUES_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return request.getAttribute((String)key);
               }
               return null;
            }
         }
         mMapCache.put(HTTP_HEADER_VALUES_MAP, map);
      }
      return map;
   }
*/

   private Object getHttpInitParamMap(final ServletContext context)
   {
      Map map = (Map)mMapCache.get(HTTP_INIT_PARAM_MAP);
      if (map == null)
      {
         map = new ImplicitObjectMapAdapter()
         {
            public Object get(Object key)
            {
               if (key instanceof String)
               {
                  return context.getInitParameter((String)key);
               }
               return null;
            }
         };
         mMapCache.put(HTTP_INIT_PARAM_MAP, map);
      }
      return map;
   }

   private Object getHttpCookieMap(final HttpServletRequest request)
   {
      Map map = (Map)mMapCache.get(HTTP_COOKIE_MAP);
      if (map == null)
      {
         Cookie[] cookies = request.getCookies();
         map = new HashMap(cookies.length);
         for (int i=0; i < cookies.length; i++)
         {
            map.put(cookies[i].getName(), cookies[i]);
         }
         mMapCache.put(HTTP_COOKIE_MAP, map);
      };
      return map;
   }


   abstract class ImplicitObjectMapAdapter implements Map
   {
      public int size()
      {
         return -1;
      }

      public boolean isEmpty()
      {
         return false;
      }

      public boolean containsKey(Object key)
      {
         return false;
      }

      public boolean containsValue(Object value)
      {
         return false;
      }

      abstract public Object get(Object key);

      public Object put(Object key, Object value)
      {
         return null;
      }

      public Object remove(Object key)
      {
         return null;
      }

      public void putAll(Map t)
      {
      }

      public void clear()
      {
      }

      public Set keySet()
      {
         return null;
      }

      public Collection values()
      {
         return null;
      }

      public Set entrySet()
      {
         return null;
      }
   }
}
