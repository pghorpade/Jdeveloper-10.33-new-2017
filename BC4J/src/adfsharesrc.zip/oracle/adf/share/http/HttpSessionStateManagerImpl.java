package oracle.adf.share.http;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import oracle.adf.share.ADFContext;

import oracle.adf.share.statemanager.StateManager;
import oracle.adf.share.statemanager.Policy;

import java.util.Hashtable;

/* $Header: HttpSessionStateManagerImpl.java 10-oct-2005.09:02:54 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    An implementation of the StateManager that uses the HttpSession as
    a repository.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    10/06/05 - Creation
 */

/**
 * The HttpSessionStateManagerImpl uses the HttpSession as a repository.
 * 
 * This StateManager implementation may be used by applications that
 * allow the use of the HttpSession.  The advnantage of the HttpSession
 * based repository is that an application may leverage the HttpSession
 * state management facilities to manage their ADF state.
 *
 *  @version $Header: HttpSessionStateManagerImpl.java 10-oct-2005.09:02:54 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpSessionStateManagerImpl implements StateManager
{
   public HttpSessionStateManagerImpl()
   {
   }
   
   public void init(Hashtable env)
   {
   }
   
   public Object getState(Object context, Object id)
   {
      return getSession().getAttribute(id.toString());
   }

   public Object putState(Object context, Object id, Object state)
   {
      getSession().setAttribute(id.toString(), state);
      return state;
   }

   public Object putState(
      Object context, Object id, Object state, Policy policy)
   {
      getSession().setAttribute(id.toString(), state);
      return state;
   }

   public Object removeState(Object context, Object id)
   {
      HttpSession session = getSession();
      Object state = session.getAttribute(id.toString());

      if (state != null)
      {
         getSession().removeAttribute(id.toString());
      }

      return state;
   }

   public void clearStates(Object context)
   {
      // not supported
   }  

   private HttpSession getSession()
   {
      ADFContext ctx = ADFContext.getCurrent();
      return ((HttpServletRequest)ctx.getEnvironment().getRequest())
         .getSession(true);
   }
}

