package oracle.adf.share.http;

import oracle.adf.share.statemanager.StateManagerScopeAdapter;
import oracle.adf.share.statemanager.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

import java.util.Hashtable;
import java.util.Map;

import oracle.adf.share.ADFContext;

import java.net.URLEncoder;

/* $Header: HttpStateManagerScopeAdapter.java 12-dec-2005.07:44:39 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    12/12/05 - XbranchMerge jsmiljan_bug-4734276 from main 
    jsmiljan    11/21/05 - XbranchMerge jsmiljan_bug-4737504 from main 
    jsmiljan    10/14/05 - XbranchMerge jsmiljan_fix_kava_100605 from main 
    jsmiljan    09/28/05 - 
    jsmiljan    08/18/05 - jsmiljan_bug-3527906
    jsmiljan    08/16/05 - Creation
 */

/**
 *  @version $Header: HttpStateManagerScopeAdapter.java 12-dec-2005.07:44:39 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpStateManagerScopeAdapter extends StateManagerScopeAdapter
{
   private static final String COOKIE_PREFIX = "ORA_adf_";

   public HttpStateManagerScopeAdapter(String scopeName, Hashtable env)
   {
      super(scopeName, env);

   }

   protected Object generateStateManagerId(Map scope)
   {
      Object rtn = null;

      String browserCookieName = generateBrowserCookieName();
      String strCookieValue = null;
      Object cookieValue = null;

      ADFContext adfCtx = ADFContext.getCurrent();

      // if the scope is an HttpSession then don't bother to write the 
      // state manager id for the scope.  depend upon HttpSession
      // distribution/session tracking to manage the state manager id
      // for the scope.
      if (scope instanceof HttpSessionScopeAdapter)
      {
         strCookieValue = (String)scope.get(browserCookieName);
      }
      else if (adfCtx.hasEnvironment())
      {
         Object request = adfCtx.getEnvironment().getRequest();
         if (request instanceof HttpServletRequest)
         {
            strCookieValue = readCookieValue(
               (HttpServletRequest)request, browserCookieName);

         }
      }

      if (strCookieValue != null)
      {
         cookieValue = UUID.generateUUID(strCookieValue);
      }
      if (cookieValue == null)
      {
         cookieValue = super.generateStateManagerId(scope);

         // if the scope is an HttpSession then don't bother to write the 
         // state manager id for the scope.  depend upon HttpSession
         // distribution/session tracking to manage the state manager id
         // for the scope.
         if (scope instanceof HttpSessionScopeAdapter)
         {
            scope.put(browserCookieName, cookieValue.toString());
         }
         else if (adfCtx.hasEnvironment())
         {
            Object response = adfCtx.getEnvironment().getResponse();
            if (response instanceof HttpServletResponse)
            {
               writeCookieValue(
                  (HttpServletResponse)response
                  , browserCookieName
                  , cookieValue.toString());
           }
         }
      }

      return cookieValue;
   }

   private String generateBrowserCookieName()
   {
      StringBuffer sb = new StringBuffer(64);
      sb.append(COOKIE_PREFIX);
      sb.append(getScopeName());

      return sb.toString();
   }

   private void writeCookieValue(
      HttpServletResponse response
      , String applicationName
      , String cookieValue)
   {
      // copied from oracle.jbo.http.HttpSessionCookieHelperImpl
      if (response.isCommitted())
      {
         return;
      }

      // JRS ARB Don't need "encryption".  The cookie value is not
      // guessable.
      //String encCookieValue = encodeCookieValue(cookieValue);
      String cookieName = null;
      try
      {
         cookieName = URLEncoder.encode(
            applicationName
            , "UTF-8");
      }
      catch (java.io.UnsupportedEncodingException e) {}

      Cookie cookie = new Cookie(cookieName, cookieValue);

      response.addCookie(cookie);
   }

   private String readCookieValue(
      HttpServletRequest request
      , String applicationName)
   {
      // copied from oracle.jbo.http.HttpSessionCookieHelperImpl
      String cookieName = null;
      try
      {
         cookieName = URLEncoder.encode(
            applicationName
            , "UTF-8");
      }
      catch (java.io.UnsupportedEncodingException e) {}



      Cookie cookie = null;

      Cookie[] cookies = request.getCookies();
      if (cookies != null)
      {
         for (int i=0; i < cookies.length; i++)
         {
            if (cookies[i].getName().equals(cookieName))
            {
               cookie = cookies[i];
               break;
            }
         }
      }

      String cookieValue = null;
      if (cookie != null)
      {
         cookieValue = cookie.getValue();
      }
      // Try to read the cookie value from the request parameters
      else if (request != null)
      {
         cookieValue = request.getParameter(cookieName);
      }

      // JRS ARB Don't need "encryption".  The cookie value is not
      // guessable.
      return cookieValue;
   }
}
