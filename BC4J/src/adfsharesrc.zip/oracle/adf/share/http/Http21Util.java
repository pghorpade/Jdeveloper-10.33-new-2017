package oracle.adf.share.http;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.security.Principal;

/* $Header: Http21Util.java 06-oct-2005.12:04:38 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
      Extends HttpUtil with Servlet 2.1 replacements for the Http
      operations that are supported by HttpUtil.  The HttpUtil
      singleton manager will automatically instantiate an instance
      of this class when it detects that it is running in a Servlet 2.1
      container.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/30/05 - jsmiljan_perf_092805
    jsmiljan    09/29/05 - Creation
 */

/**
 *  @version $Header: Http21Util.java 06-oct-2005.12:04:38 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class Http21Util extends HttpUtil
{
   Http21Util()
   {
   }

   public Principal getUserPrincipal(HttpServletRequest request)
   {
      return null;
   }

   public Object getAttribute(HttpSession session, String name)
   {
      return session.getValue(name);
   }

   public Object getAttribute(ServletContext context, String name)
   {
      return null;
   }

   public Object getAttribute(HttpServletRequest request, String name)
   {
      return null;
   }

   public Object setAttribute(HttpSession session, String name, Object value)
   {
      session.putValue(name, value);
      return value;
   }

   public Object setAttribute(
      HttpServletRequest request, String name, Object value)
   {
      return null;
   }

   public Object setAttribute(
      ServletContext context, String name, Object value)
   {
      return null;
   }
}
