package oracle.adf.share.http;

import javax.servlet.ServletContext;

import java.util.Map;
import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ArrayList;

import oracle.adf.share.ADFScope;
import oracle.adf.share.ADFScopeListener;
import oracle.adf.share.ADFScopeHelper;
import oracle.adf.share.ADFContext;

/* $Header: ServletContextScopeAdapter.java 29-sep-2005.12:11:33 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/29/05 - 
    jsmiljan    09/01/05 - 
    jsmiljan    08/17/05 - ..
    edelaube    06/15/05 - (String)key ==> key.toString()
    jsmiljan    02/08/05 - 
    jsmiljan    02/01/05 - jsmiljan_statemanager_012505
    jsmiljan    01/26/05 - Creation
 */

/**
 *  @version $Header: ServletContextScopeAdapter.java 29-sep-2005.12:11:33 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class ServletContextScopeAdapter implements ADFScope
{
   private ServletContext mAdaptee;
   private final ADFScopeHelper mHelper;

   private final String mScopeName;

   public ServletContextScopeAdapter(String scopeName, ServletContext adaptee)
   {
      mScopeName = scopeName;

      mAdaptee = adaptee;
      mHelper = new ADFScopeHelper();
   }

   public int size()
   {
      int size = 0;
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         size++;
      }
      
      return size;
   }

   public void clear()
   {
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         mAdaptee.removeAttribute((String)attrNames.nextElement());
      }
   }

   public boolean isEmpty()
   {
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         return false;
      }
      return true;
   }

   public boolean containsKey(Object key)
   {
      if (key == null)
      {
         return false;
      }
      
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         if (key.equals(attrNames.nextElement()))
         {
            return true;
         }
      }
      
      return false;

   }

   public boolean containsValue(Object value)
   {
      if (value == null)
      {
         return false;
      }
      
      // linear search.  optimize later if this is used heavily.
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         if (value.equals(mAdaptee.getAttribute((String)attrNames.nextElement())))
         {
            return true;
         }
      }
      
      return false;
   }

   public Collection values()
   {
      ArrayList values = new ArrayList();

      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         values.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
      }

      return values;
   }

   public void putAll(Map map)
   {
      Iterator keys = map.keySet().iterator();
      while (keys.hasNext())
      {
         Object key = keys.next();
         HttpUtil.getInstance().setAttribute(mAdaptee, key.toString(), map.get(key));
      }
   }

   public Set entrySet()
   {
      HashSet entrySet = new HashSet();
      
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         entrySet.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
      }
      
      return entrySet;
   }

   public Set keySet()
   {
      Set keySet = new HashSet();
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         keySet.add(attrNames.nextElement());
      }
      return keySet;
   }

   public Object get(Object key)
   {
      if (key == null) return null;
      
      return HttpUtil.getInstance().getAttribute(mAdaptee, key.toString());
   }

   public Object remove(Object key)
   {
      if (key == null) return null;
      
      Object rtn = get(key);
      mAdaptee.removeAttribute(key.toString());
      
      return rtn;
   }

   public Object put(Object key, Object value)
   {
      if (key == null || value == null) return null;
      
      Object rtn = get(key);
      HttpUtil.getInstance().setAttribute(mAdaptee, key.toString(), value);
      
      return rtn;
   }

   public void invalidate()
   {
      mHelper.fireScopeInvalidated(mScopeName);
      mAdaptee = null;
   }

   public void addScopeListener(ADFScopeListener listener)
   {
      mHelper.addScopeListener(listener);
   }

   public void removeScopeListener(ADFScopeListener listener)
   {
      mHelper.removeScopeListener(listener);
   }
}

