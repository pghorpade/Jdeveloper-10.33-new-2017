package oracle.adf.share.http;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import java.util.Map;
import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Hashtable;

import oracle.adf.share.ADFScope;
import oracle.adf.share.ADFScopeHelper;
import oracle.adf.share.ADFScopeListener;
import oracle.adf.share.ADFContext;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/* $Header: HttpSessionScopeAdapter.java 29-sep-2005.11:29:19 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/29/05 - 
    jsmiljan    09/01/05 - 
    jsmiljan    08/30/05 - 
    jsmiljan    08/17/05 - 
    jsmiljan    08/15/05 - 
    jsmiljan    08/02/05 - 
    jsmiljan    06/21/05 - 
    edelaube    06/15/05 - (String)key ==> key.toString()
    jsmiljan    04/13/05 - 
    jsmiljan    02/08/05 - 
    jsmiljan    02/01/05 - jsmiljan_statemanager_012505
    jsmiljan    01/26/05 - Creation
 */

/**
 *  @version $Header: HttpSessionScopeAdapter.java 29-sep-2005.11:29:19 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpSessionScopeAdapter implements ADFScope
   , HttpSessionBindingListener, Externalizable
{
   private transient HttpSession mAdaptee;
   private transient ADFScopeHelper mHelper;

   private static Hashtable mSessionAdapters = new Hashtable();

   public static final String VALID = "__valid__";

   private final String mScopeName;

   static final long serialVersionUID = -414166398739154544L;

   public HttpSessionScopeAdapter()
   {
      // must maintain the public no-arg constructor to support the
      // Externalizable interface.
      mScopeName = null;
   }

   public HttpSessionScopeAdapter(String scopeName)
   {
      mScopeName = scopeName;

      mAdaptee = null;
      mHelper = null;
   }

   public HttpSessionScopeAdapter(String scopeName, HttpSession adaptee)
   {
      mScopeName = scopeName;

      mAdaptee = adaptee;
      mHelper = new ADFScopeHelper();

      // JRS 020805
      // this could be optimized to use an HttpSessionListener.  In this way
      // we would not be introducing another, potentially serialized state,
      // into the session.
      // JRS 06/30/05 bug 4205821
      // still need to optimize this.  however, running into problems using
      // this class as an HttpSessionListener right now because of
      // issues with loading the listener from the global classloader
      // (I think).  still investigating.  in the meantime, continue to
      // use the AttributeBindingListener.

      // for future use
      //mSessionAdapters.put(adaptee, this);
   }

   public int size()
   {
      int size = 0;
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         size++;
      }
      
      return size;
   }

   public void clear()
   {
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         mAdaptee.removeAttribute((String)attrNames.nextElement());
      }
   }

   public boolean isEmpty()
   {
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         return false;
      }
      return true;
   }

   public boolean containsKey(Object key)
   {
      if (key == null)
      {
         return false;
      }

      if (VALID.equals(key))
      {
         return (mAdaptee != null);
      }
      
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         if (key.equals(attrNames.nextElement()))
         {
            return true;
         }
      }
      
      return false;

   }

   public boolean containsValue(Object value)
   {
      if (value == null)
      {
         return false;
      }
      
      // linear search.  optimize later if this is used heavily.
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         if (value.equals(HttpUtil.getInstance().getAttribute(
            mAdaptee, (String)attrNames.nextElement())))
         {
            return true;
         }
      }
      
      return false;
   }

   public Collection values()
   {
      ArrayList values = new ArrayList();

      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         values.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
      }

      return values;
   }

   public void putAll(Map map)
   {
      Iterator keys = map.keySet().iterator();
      while (keys.hasNext())
      {
         Object key = keys.next();
         HttpUtil.getInstance().setAttribute(
            mAdaptee, key.toString(), map.get(key));
      }
   }

   public Set entrySet()
   {
      HashSet entrySet = new HashSet();
      
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         entrySet.add(mAdaptee.getAttribute((String)attrNames.nextElement()));
      }
      
      return entrySet;
   }

   public Set keySet()
   {
      Set keySet = new HashSet();
      Enumeration attrNames = mAdaptee.getAttributeNames();
      while (attrNames.hasMoreElements())
      {
         keySet.add(attrNames.nextElement());
      }
      return keySet;
   }

   public Object get(Object key)
   {
      if (key == null) return null;
      
      return HttpUtil.getInstance().getAttribute(mAdaptee, key.toString());
   }

   public Object remove(Object key)
   {
      if (key == null) return null;
      
      Object rtn = get(key);
      mAdaptee.removeAttribute(key.toString());
      
      return rtn;
   }

   public Object put(Object key, Object value)
   {
      if (key == null || value == null) return null;
      
      Object rtn = get(key);
      HttpUtil.getInstance().setAttribute(mAdaptee, key.toString(), value);
      
      return rtn;
   }

   public void invalidate()
   {
      mHelper.fireScopeInvalidated(mScopeName);
      mAdaptee = null;
   }

   public void addScopeListener(ADFScopeListener listener)
   {
      mHelper.addScopeListener(listener);
   }

   public void removeScopeListener(ADFScopeListener listener)
   {
      mHelper.removeScopeListener(listener);
   }

   public void sessionCreated(HttpSessionEvent se)
   {
   }

   public void sessionDestroyed(HttpSessionEvent se)
   {
      HttpSessionScopeAdapter adapter = 
         (HttpSessionScopeAdapter)mSessionAdapters.remove(se.getSession());

      if (adapter != null)
      {
         adapter.invalidate();
      }
   }

   public void valueBound(HttpSessionBindingEvent ev)
   {
      // don't re-initialize the adaptee here.  this should be performed
      // by the container if we detect a stale adaptee.
      //
      // this important to prevent premature invalidation events from
      // being thrown.  the usecase is the tomcat container which will
      // potentially invoke valueBound when loading persistent sessions.
   }

   public void valueUnbound(HttpSessionBindingEvent ev)
   {
      // indicates that the adaptee has not yet been initialized.
      // ignore this case.  this only happens when replacing an empty
      // scope adapter with a new one.  what to do with the listeners
      // that were regsistered?  we could otherwise leak persistent states.
      // for example, the statemanager depends upon this event to clean up
      // persisted session state.
      //
      // note that this will fire for a previously active session once
      // that session times out.  the issue will be a failed over session
      // that expires before it becomes active.
      //
      // we may have to consider making the listeners seriazible to handle
      // this scenario.  of course, then we will also have to take some
      // special care to not fire the invalidation events when we are just
      // doing internal work to re-initialize the scope adapter (like in the
      // scenario mentioned above).
      if (mAdaptee != null)
      {
         invalidate();
      }
   }

   public void writeExternal(ObjectOutput out) throws IOException
   {
      // no-op.  don't write anything for this object.  it will be
      // re-created properly whenever we create a new
      // HttpSessionScopeAdapter.
   }

   public void readExternal(ObjectInput in)
      throws IOException, ClassNotFoundException
   {
   }
}
