package oracle.adf.share.http;


/* $Header: JSPADFContextVariableResolverImpl.java 10-nov-2005.10:06:10 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    11/10/05 - XbranchMerge jsmiljan_fix_kava_103105 from main 
    jsmiljan    09/14/05 - 
    jsmiljan    08/16/05 - 
    jsmiljan    08/12/05 - jsmiljan_bug-3688418
    jsmiljan    08/12/05 - 
    jsmiljan    07/19/05 - jsmiljan_fix_build_071705
    jsmiljan    07/19/05 - 
    jsmiljan    07/13/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/22/05 - Creation
 */

import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.VariableResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

import javax.servlet.ServletContext;

import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Set;
import java.util.Collection;

import oracle.adf.share.ADFContext;

import oracle.adf.share.el.ADFContextVariableResolverImpl;

/**
 *  May be passed to a JSP expression evaluator to resolve ADF implicit
 *  objects.   This variable resolver differs from
 *  a ADFContextVariableResolverImpl because it can use an inner JSP
 *  VariableResolver to perform JSP implicit object resolution.
 *  <p>
 *  This variable resolver should be used whenever a native JSP
 *  variable resolver is available.
 * 
 *  @version $Header: JSPADFContextVariableResolverImpl.java 10-nov-2005.10:06:10 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class JSPADFContextVariableResolverImpl implements VariableResolver
{
   private final VariableResolver  mParentResolver;

   public JSPADFContextVariableResolverImpl()
   {
      this(null);
   }

   public JSPADFContextVariableResolverImpl(VariableResolver parentResolver)
   {
      mParentResolver =
         new HttpADFContextVariableResolverImpl(parentResolver);

      ((HttpADFContextVariableResolverImpl)mParentResolver)
         .setResolveImplicit(parentResolver == null);
   }

   public Object resolveVariable(String name) throws ELException
   {
      return mParentResolver.resolveVariable(name);
   }
}
