package oracle.adf.share.http;

import javax.servlet.jsp.JspContext;

import javax.servlet.jsp.el.VariableResolver;
import javax.servlet.jsp.el.ELException;

import oracle.adf.share.ADFContext;

import oracle.adf.share.el.ADFExpressionEvaluator;

/* $Header: JSPExpressionEvaluatorImpl.java 10-nov-2005.10:06:11 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    11/10/05 - XbranchMerge jsmiljan_fix_kava_103105 from main 
    jsmiljan    08/12/05 - jsmiljan_bug-3688418
    jsmiljan    07/19/05 - 
    cgayraud    07/19/05 - 
    jsmiljan    07/19/05 - 
    jsmiljan    03/28/05 - jsmiljan_el_031605
    jsmiljan    03/16/05 - Creation
 */

/**
 *  @version $Header: JSPExpressionEvaluatorImpl.java 10-nov-2005.10:06:11 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */

public class JSPExpressionEvaluatorImpl implements ADFExpressionEvaluator
{
   private final JspContext mJspContext;

   public JSPExpressionEvaluatorImpl(JspContext jspContext)
   {
      mJspContext = jspContext;

      ADFContext adfCtx = ADFContext.getCurrent();
      VariableResolver resolver = new JSPADFContextVariableResolverImpl(
         jspContext.getVariableResolver());

      adfCtx.setVariableResolver(resolver);
   }

   public Object evaluate(String expression)
   {
      return evaluate(expression, getVariableResolver());
   }

   public Object evaluate(String expression, VariableResolver variableResolver)
   {
      return evaluateInternal(expression, variableResolver);
   }

   public void setValue(String expression, Object value)
   {
      throw new UnsupportedOperationException();
   }

   public void setValue(String expression, Object value, VariableResolver variableResolver)
   {
      throw new UnsupportedOperationException();
   }

   private Object evaluateInternal(String expression, VariableResolver variableResolver)
   {
      try
      {
         return mJspContext.getExpressionEvaluator().evaluate(
            expression, Object.class, variableResolver
            , null /* functionMapper */ );
      }
      catch (ELException e)
      {
         throw new RuntimeException(e);
      }
   }

   public VariableResolver getVariableResolver()
   {
       return ADFContext.getCurrent().getVariableResolver();
   }
}

