package oracle.adf.share.http;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.security.Principal;

import java.lang.reflect.Method;

/* $Header: HttpUtil.java 06-oct-2005.12:04:13 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Created to encapsulate Servlet 2.2 and later operations.  This
    class may be subclassed to replace the 2.2 operations with their
    2.1 equivalents (if they exist).  All classes that require 2.2 operations
    should delegate to this class to perform that work.  See 
    {@link oracle.adf.share.http.ServletADFContext}.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    09/30/05 - jsmiljan_perf_092805
    jsmiljan    09/29/05 - Creation
 */

/**
 *  @version $Header: HttpUtil.java 06-oct-2005.12:04:13 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpUtil
{
   private static Boolean mIsServlet21 = null;
   private static HttpUtil mInstance = null;

   HttpUtil()
   {
   }

   public static HttpUtil getInstance()
   {
      if (mInstance == null)
      {
         if (isServlet21())
         {
            mInstance = new Http21Util();
         }
         else
         {
            mInstance = new HttpUtil();
         }
      }

      return mInstance;
   }

   public static boolean isServlet21()
   {
      if (mIsServlet21 == null)
      {
         mIsServlet21 = Boolean.TRUE;

         try
         {
            Method meth = javax.servlet.http.HttpSession.class
               .getDeclaredMethod("getServletContext", null);

            if (meth != null)
               mIsServlet21 = Boolean.FALSE;
         }
         catch (Exception e)
         {
         }
      }

      return mIsServlet21.booleanValue();
   }

   public Principal getUserPrincipal(HttpServletRequest request)
   {
      return request.getUserPrincipal();
   }

   public Object getAttribute(HttpSession session, String name)
   {
      return session.getAttribute(name);
   }

   public Object getAttribute(HttpServletRequest request, String name)
   {
     return request.getAttribute(name);
   }

   public Object getAttribute(ServletContext context, String name)
   {
      return context.getAttribute(name);
   }

   public Object setAttribute(HttpSession session, String name, Object value)
   {
      session.setAttribute(name, value);
      return value;
   }

   public Object setAttribute(
      HttpServletRequest request, String name, Object value)
   {
      request.setAttribute(name, value);
      return value;
   }

   public Object setAttribute(
      ServletContext context, String name, Object value)
   {
      context.setAttribute(name, value);
      return value;
   }
}
