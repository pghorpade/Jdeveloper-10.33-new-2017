/*
 * @(#)Constants.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11;

/**
 * <p>Constants used by the BC4J model support for Struts.</p>
 *
 * @since JDeveloper 9.0.3
 */

public interface Constants 
{
   /**
    * <p>param-name in the web.xml where the model definition file name is stored.
    * <pre>
    * &lt;servlet&gt;
    * &nbsp;&nbsp;&lt;servlet-name&gt;action&lt;/servlet-name&gt;
    * &nbsp;&nbsp;&lt;servlet-class&gt;org.apache.struts.action.ActionServlet&lt;/servlet-class&gt;
    * &nbsp;&nbsp;...
    * &nbsp;&nbsp;&lt;init-param&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;!-- use Project2.cpx model definition file --&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-name&gt;BC4JDefinition&lt;/param-name&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-value&gt;Project2&lt;/param-value&gt;
    * &nbsp;&nbsp;&lt;/init-param&gt;
    * &nbsp;&nbsp;...
    * &lt;/servlet&gt;
    * </pre>
    */
   public static final String BC4JWepAppParamName = "BC4JDefinition";

   /**
    * <p>param-name in the web.xml where the lock mode for the model is stored.
    * Default value is false.
    * <pre>
    * &lt;servlet&gt;
    * &nbsp;&nbsp;&lt;servlet-name&gt;action&lt;/servlet-name&gt;
    * &nbsp;&nbsp;&lt;servlet-class&gt;org.apache.struts.action.ActionServlet&lt;/servlet-class&gt;
    * &nbsp;&nbsp;...
    * &nbsp;&nbsp;&lt;init-param&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;!-- specify whether a session lock should be acquired for the
    * shared application module resource --&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-name&gt;BC4JLock&lt;/param-name&gt;
    * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-value&gt;true&lt;/param-value&gt;
    * &nbsp;&nbsp;&lt;/init-param&gt;
    * &nbsp;&nbsp;...
    * &lt;/servlet&gt;
    * </pre>
    *
    * @since JDeveloper 9.0.4
    */
   public static final String BC4JWepAppLockModeParamName = "BC4JLock";

   /**
    * Name of the default forward used by the action
    */
   public static final String SUCCESS_FORWARD = "success";

   /**
    * attribute name used to store the <code>MultipartRequestHandler</code> 
    * object in the request context
    */
   public static final String BC4J_MULTIPART_HANDLER_ATTR_NAME = "BC4JMultipartHandler";
}
