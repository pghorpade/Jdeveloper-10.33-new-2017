/*
 * @(#)BC4JRequestProcessor.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11;

import java.io.IOException;

import java.util.Locale;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.html.BC4JContext;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.http.HttpContainer;
import oracle.jbo.http.HttpSessionCookieFactory;
import oracle.jbo.http.HttpUtil;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.RequestProcessor;
import org.apache.struts.config.ForwardConfig;
import org.apache.struts.upload.MultipartRequestHandler;
import org.apache.struts.upload.MultipartRequestWrapper;

/**
 * <p><strong>BC4JRequestProcessor</strong> is a customization of Struts1.1
 * request processing behavior. It override several methods to provide
 * integration with the BC4J Model.</p>
 *
 * @since JDeveloper 9.0.3
 */

public class BC4JRequestProcessor extends RequestProcessor 
{
   /**
    * Override the forward process to lock/release the ApplicationModule.
    * Simply wrap the base processForward method with the page init and
    * page release code. Return
    * <code>true</code> if standard processing should continue, or
    * <code>false</code> if we have already handled this request.
    *
    * @param request The servlet request we are processing
    * @param response The servlet response we are creating
    * @param mapping The ActionMapping we are using
    */
   protected boolean processForward(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping)
      throws IOException, ServletException
   {
      boolean cont = super.processForward(request, response, mapping); 

      // Execute postProcess only if the request has been handled by processForward
      if (!cont && mapping instanceof BC4JActionMapping)
      {
         processPostForward(request, response);
      }

      return cont;
   }

   protected boolean processInclude(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping)
      throws IOException, ServletException
   {
      boolean cont = super.processInclude(request, response, mapping); 

      // Execute postProcess only if the request has been handled by processInclude
      if (!cont && mapping instanceof BC4JActionMapping)
      {
         processPostForward(request, response);
      }

      return cont;
   }

   /**
    * Override 
    */
   protected void processForwardConfig(HttpServletRequest request,
                                       HttpServletResponse response,
                                       ForwardConfig forward)
      throws IOException, ServletException
   {
      super.processForwardConfig(request, response, forward);

      // Only postForward if this is a BC4JActionMapping
      ActionMapping mapping = (ActionMapping) request.getAttribute(Globals.MAPPING_KEY);
      if (mapping instanceof BC4JActionMapping)
      {
         processPostForward(request, response);
      }
   }

   /**
    * Override 
    *    
    * Create the BC4J context when the mapping is processed.
    * Some of the context information may come from the mapping.
    */
   protected ActionMapping processMapping(HttpServletRequest request, HttpServletResponse response, String path)
        throws IOException
   {
      ActionMapping actionMapping = super.processMapping(request, response, path);
            
      if (actionMapping instanceof BC4JActionMapping)
      {
         BC4JActionMapping bc4jMapping = (BC4JActionMapping) actionMapping;
            
         BC4JContext context = (BC4JContext)request.getAttribute(BC4JContext.ContextAttrName);
         // Instanciate the context and save it on the request
         if (context == null)
         {
            context = new BC4JContext();
            request.setAttribute(BC4JContext.ContextAttrName, context);
         }
   
         if (initPageFromPath(bc4jMapping, request, response))
         {
            // First initialize context with the existing mapping values
            bc4jMapping.initializeContext(request, response, context);
                  
            // Then use request parameter values
            context.initialize(request, response);
         }
      }

      return actionMapping;
   }

   /**
    * Override 
    *    
    * Set the request character encoding using the controller contentType
    * This allow the parameters to be decoded correctly in the action since
    * the encoding from the JSP has not been processed yet.
    */
   protected void processContent(HttpServletRequest request,
                                 HttpServletResponse response)
    {
       super.processContent(request, response);
       
       String contentType = moduleConfig.getControllerConfig().getContentType();

       if (contentType != null)
       {
          int encodingIndex;
          if ((encodingIndex = contentType.indexOf("charset=")) > 0)
          {
            int encodingIndexEnd = contentType.indexOf(';', encodingIndex);
            String characterEncoding = contentType.substring(encodingIndex + 8, encodingIndexEnd < 0 ? contentType.length() : encodingIndexEnd).trim();
            if (characterEncoding != null && characterEncoding.length() > 0)
            {
               try
               {
                  if ((getServletContext().getMajorVersion() >= 2) &&
                      (getServletContext().getMinorVersion() >= 3))
                  {
                     request.setCharacterEncoding(characterEncoding);
                  }
                  /* This is a possible alternative for older Servlet API using OJSP
                  else
                  {
                     oracle.jsp.util.PublicUtil.setReqCharacterEncoding(request, characterEncoding);
                  }
                  */                  
               }
               catch (java.io.UnsupportedEncodingException ex)
               {
                  throw new JboException(ex);
               }
            }
         }
      }
   }


   protected void processPostForward(HttpServletRequest request,
                                     HttpServletResponse response)
   {
      // Release am resources after the page has been processed
      releasePageResources(request, response);
   }

   /**
    * Build the application full name as the pool manager expect it.
    * Format is: "Client Data Model file name"."BC4J application module name"
    */
   protected String buildApplicationDefinitionName(String appId)
   {
      // The definition name is stored in web.xml
      String bc4jDefFileName = (String) servlet.getServletConfig().getInitParameter(Constants.BC4JWepAppParamName);
      return bc4jDefFileName + "." + appId;
   }
   
   /**
    * Return the locking mode for the applicationModule
    * The lock specify whether a session lock should be acquired for the
    * shared application module resource.
    * The locking mode is store in the web.xml
    */
   protected boolean getApplicationLockingMode()
   {
      final String lock = servlet.getServletConfig().getInitParameter(Constants.BC4JWepAppLockModeParamName);
      return (lock != null && (lock.equalsIgnoreCase("true") || lock.equalsIgnoreCase("yes")));
   }
   
   /**
    * Execute the BC4J model initialization.
    */
   protected boolean initPageFromPath(BC4JActionMapping mapping, HttpServletRequest request, HttpServletResponse response)
   {
      Properties props = new Properties();
      props.put(HttpSessionCookieFactory.HTTP_SERVLET_REQUEST, request);
      
      // Retrieve the appId from the mapping or the request if not in the mapping.
      String appId = mapping.getApplication();
      if (appId == null || appId.length() == 0)
      {
         appId = request.getParameter("amId");

         if (appId == null || appId.length() == 0)
         {
            return false;
         }
      }

      SessionCookie cookie = HttpContainer.findSessionCookie(
                  request.getSession(),
                  appId,
                  buildApplicationDefinitionName(appId),
                  props);
      
      // locks the session cookie for the current session thread
      // checks out the cookie application module
      ApplicationModule am = cookie.useApplicationModule(getApplicationLockingMode());

      Locale locale = HttpUtil.determineLocale(request);

      // setup the Application Module's Locale based on the incoming request information
      if (locale != null)
         am.getSession().setLocale(locale);
      
      // Only set the releasemode on the first action of the request.
      String releaseMode = (String)request.getAttribute(
         oracle.jbo.html.jsp.datatags.Utils.buildReleaseModeKey(cookie));

      if (releaseMode == null || releaseMode.length() == 0)
      {
         releaseMode = mapping.getReleasemode();
         if (releaseMode == null || releaseMode.length() == 0)
         {
            releaseMode = (String) cookie.getEnvironment(PropertyMetadata.AM_RELEASE_MODE.getName());
            
            if (releaseMode == null || releaseMode.length() == 0)
            {
               releaseMode = JboEnvUtil.getProperty(PropertyMetadata.AM_RELEASE_MODE.getName(),
                                                    PropertyMetadata.AM_RELEASE_MODE.getDefault());
            }
         }

         request.setAttribute(
            oracle.jbo.html.jsp.datatags.Utils.buildReleaseModeKey(cookie)
            , releaseMode);
      }

      // Reserve a passivation id if the release mode is stateful
      if (PropertyConstants.AM_RELEASE_STATEFUL.equals(releaseMode))
      {
         cookie.reservePassivationId();
      }

      // Write the cookie value now.  This is to handle the case where the
      // response buffer gets flushed before the cookie value has been added
      // to the headers.  It is alright to write the cookie value here
      // because the next passivation id has already been generated.
      // JRS What will happen to the old passivation id?  Okay until the
      // first flush.  After that we may not be able to activate the old
      // state.
      cookie.writeValue(response);

      // place default renderers into session, these will not be
      // exposed via config file
      HtmlServices.registerORDrenderer(request.getSession());

      return true;
   }
   
   /**
    *  
    */
   protected void releasePageResources(HttpServletRequest request, HttpServletResponse response)
   {
      HttpContainer container = HttpContainer.getInstanceFromSession(request.getSession());

      SessionCookie[] cookies = container.getSessionCookies();
      for (int i = 0; i < cookies.length; i++)
      {
         synchronized(cookies[i].getSyncLock())
         {
            if (!cookies[i].isApplicationModuleReleasedByThread())
            {
               String releaseMode = (String)request.getAttribute(
                  oracle.jbo.html.jsp.datatags.Utils.buildReleaseModeKey(cookies[i]));

               oracle.jbo.html.jsp.datatags.Utils.releaseApplicationModule(
                  getServletContext(), response, cookies[i], releaseMode);
            }
         }
      }

      MultipartRequestHandler handler = MultipartUtil.retrieveMultipartHandler(request);

      if (handler != null)
      {
         handler.finish();
         request.removeAttribute(Constants.BC4J_MULTIPART_HANDLER_ATTR_NAME);
      }
   }


  /**
   * If this is a multipart request, wrap it with a special wrapper. Parse 
   * the multipart request using <code>MultipartRequestHandler</code>.
   * Otherwise, return the request unchanged.
   *
   * @param request The HttpServletRequest we are processing
   */
   protected HttpServletRequest processMultipart(HttpServletRequest request) 
   {
      if (HtmlServices.isMultipartPost(request))
      {
         MultipartRequestHandler handler = MultipartUtil.retrieveMultipartHandler(request);

         if (handler == null)
         {
            try
            {
               request = MultipartUtil.parseMultipartRequest(request, servlet);
            }
            catch(ServletException se)
            {
               throw new RuntimeException(se.getMessage());
            }
         }
         else
         {
            //
            // This is a forward from a Multipart Post upload
            //
            if(! (request instanceof MultipartRequestWrapper))
            {
               request = new MultipartRequestWrapper(request);
               MultipartUtil.setWrapperParams(handler, (MultipartRequestWrapper)request);
            }
            else
            {
               // do nothing
            }
         }
      }

      return (request);
  }

  /**
   * Populate the properties of the specified ActionForm instance from
   * the request parameters included with this request.
   *
   * @param request The servlet request we are processing
   * @param response The servlet response we are creating
   * @param form The ActionForm instance we are populating
   * @param mapping The ActionMapping we are using
   *
   * @exception ServletException if thrown by RequestUtils.populate()
   */
   protected void processPopulate(HttpServletRequest request,
                                  HttpServletResponse response,
                                  ActionForm form,
                                  ActionMapping mapping)
      throws ServletException 
   {
      if (! (mapping instanceof BC4JActionMapping) )
      {
         super.processPopulate(request, response, form, mapping);
         return;
      }
      
      if (form == null) 
      {
         return;
      }

      // Populate the bean properties of this ActionForm instance
      if (log.isDebugEnabled())
      {
         log.debug(" Populating bean properties from this request");
      }

      form.setServlet(this.servlet);
      form.reset(mapping, request);
   
      /*
      if (mapping.getMultipartClass() != null) 
      {
         request.setAttribute(Globals.MULTIPART_KEY,
                              mapping.getMultipartClass());
      }
      */
   
      MultipartUtil.populate(form, mapping.getPrefix(), mapping.getSuffix(), request);

      /*
       * Struts 1.1 RequestProcessor now notices request cancellation
       * by the presence of this CANCEL_KEY attribute. It is set in
       * the RequestProcessor.processPopulate which we've overridden here.
       */
      // Set the cancellation request attribute if appropriate
      if ((request.getParameter(org.apache.struts.taglib.html.Constants.CANCEL_PROPERTY) != null) ||
          (request.getParameter(org.apache.struts.taglib.html.Constants.CANCEL_PROPERTY_X) != null))
      {
         request.setAttribute(Globals.CANCEL_KEY, Boolean.TRUE);
      }
  }
}
