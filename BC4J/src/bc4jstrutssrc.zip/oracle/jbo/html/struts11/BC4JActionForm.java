/*
 * @(#)BC4JActionForm.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11;

import java.util.HashMap;
import org.apache.struts.action.ActionForm;

import oracle.jbo.html.jsp.datatags.DataTagBase;
import oracle.jbo.html.jsp.datatags.OnEventTag;

/**
 * <p><strong>BC4JActionForm</strong> is a customization of Struts1.1
 * ActionForm Javabean. It override several methods to provide
 * integration with the BC4J Model.</p>
 *
 * <p>This class is typically subclassed for each ViewObject definition.
 * Subclasses should generate property getter and setter for each attribute
 * of the ViewObject they which to expose. Each getter and setter should call
 * setAttribute and getAttribute using the name of the attribute as parameter.
 * This class provide the default functionality to access the BC4J model</p>
 *
 * @since JDeveloper 9.0.3
 */

public class BC4JActionForm extends ActionForm
{
   /**
    * Name of the ViewObject Definition handled by this instance
    * This value will be set by the constructor of the subclass
    */
   protected final String viewObjectDefName;
   
   /**
    * The set of attribute values for this ViewObject, keyed by
    * attribute name.
    */
   protected final HashMap attrVals = new HashMap();
   

   public BC4JActionForm(String voName)
   {
      // Only one FormBean instance per ViewObject definition
      viewObjectDefName = voName;
   }

   public void setJboEvent(String jboEvent)
   {
      setAttribute(OnEventTag.JBOEVENT, jboEvent);
   }

   public String getJboEvent()
   {
      return (String)getAttribute(OnEventTag.JBOEVENT);
   }

   public void setJboEventVo(String jboEventVo)
   {
      setAttribute(OnEventTag.JBOEVENTVO, jboEventVo);
   }

   public String getJboEventVo()
   {
      return (String)getAttribute(OnEventTag.JBOEVENTVO);
   }

   public void setAmId(String amId)
   {
      setAttribute("amId", amId);
   }

   public String getAmId()
   {
      return (String)getAttribute("amId");
   }

   public void setJboRowKey(String rowKey)
   {
      setAttribute(DataTagBase.ROWKEY_PARAM, rowKey);
   }

   public String getJboRowKey()
   {
      return (String)getAttribute(DataTagBase.ROWKEY_PARAM);
   }
   
   public Object getAttribute(String attrName)
   {
      return attrVals.get(attrName);
   }
   
   public void setAttribute(String attrName, Object value)
   {
      attrVals.put(attrName, value);
   }

   public void reset(org.apache.struts.action.ActionMapping mapping
      , javax.servlet.ServletRequest request)
   {
      super.reset(mapping, request);
      attrVals.clear();
   }

   public void reset(org.apache.struts.action.ActionMapping mapping
      , javax.servlet.http.HttpServletRequest request)
   {
      super.reset(mapping, request);
      attrVals.clear();
   }  
}
