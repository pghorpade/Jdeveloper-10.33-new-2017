/*
 * @(#)LovCompAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import oracle.jbo.html.jsp.datatags.OnEventTag;
import oracle.jbo.html.struts11.Constants;

/**
 * <p><strong>LovCompAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.4
 */
public class LovCompAction extends Action 
{
   public static final String LOVVO_NAME = "jboLovVo";
   
   public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
      String appDef = request.getParameter("appDef");
      String amId = appDef.substring(appDef.indexOf('.') + 1);
      
      ActionForward forward = mapping.findForward(Constants.SUCCESS_FORWARD);
      return new ActionForward(forward.getName(), forward.getPath() + "?amId=" + amId + "&" + OnEventTag.JBOEVENTVO + "=" + LOVVO_NAME,
                               forward.getRedirect(),
                               forward.getContextRelative());
   }
}
