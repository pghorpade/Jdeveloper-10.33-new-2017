/*
 * @(#)NavigationAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.html.struts11.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;
import org.apache.struts.actions.DispatchAction;

import oracle.jbo.html.struts11.BC4JUtils;
import oracle.jbo.RowSet;
import oracle.jbo.RowIterator;
import oracle.jbo.html.BC4JContext;

/**
 * <p><strong>NavigationAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class NavigationAction extends DispatchAction
{
   /**
    * "next" dispatch method called by DispatchAction
    * 
    */
   public ActionForward next(ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getViewObject().next();

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "previous" dispatch method called by DispatchAction
    * 
    */
   public ActionForward previous(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getViewObject().previous();

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "first" dispatch method called by DispatchAction
    * 
    */
   public ActionForward first(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getViewObject().first();

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "last" dispatch method called by DispatchAction
    * 
    */
   public ActionForward last(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getViewObject().last();

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "nextSet" dispatch method called by DispatchAction
    * 
    */
   public ActionForward nextSet(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      RowSet rs = context.getViewObject();
      rs.scrollRange(rs.getRangeSize());

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "previousSet" dispatch method called by DispatchAction
    * 
    */
   public ActionForward previousSet(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      RowSet rs = context.getViewObject();

      int scrollAmount;
      int rangeSize = rs.getRangeSize();
      
      if (rs.getIterMode() == RowIterator.ITER_MODE_LAST_PAGE_FULL && rangeSize > 1)
      {
         long totalCount = rs.getEstimatedRowCount();
         long rangeStart = rs.getRangeStart();
         
         // If at the end of the set, only go back to the previous zero base step
         if (rangeStart + rangeSize == totalCount)
         {
            scrollAmount = (int) (((((rangeStart +1) / rangeSize) -1)  * rangeSize) - rangeStart);
         }
         else
         {
            scrollAmount = -rangeSize;
         }
      }
      else
      {
         scrollAmount = -rangeSize;
      }
      
      rs.scrollRange(scrollAmount);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "firstSet" dispatch method called by DispatchAction
    * 
    */
   public ActionForward firstSet(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      context.getViewObject().setRangeStart(0);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "lastSet" dispatch method called by DispatchAction
    * 
    */
   public ActionForward lastSet(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      RowSet rs = context.getViewObject();

      int rangeSize = rs.getRangeSize();
      while (rs.scrollRange(rangeSize) > 0);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "gotoSet" dispatch method called by DispatchAction
    * 
    */
   public ActionForward gotoSet(ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      RowSet rs = context.getViewObject();

      String value = request.getParameter("value");
      int start = -1;
      if (value != null)
      {
         try
         {
            start = Integer.parseInt(value) - 1;
         }
         catch (NumberFormatException ex)
         {
         }

         if (start >= 0)
         {
            rs.setRangeStart(start);
         }
      }

      return BC4JUtils.getForwardFromContext(context, mapping);
   }
}