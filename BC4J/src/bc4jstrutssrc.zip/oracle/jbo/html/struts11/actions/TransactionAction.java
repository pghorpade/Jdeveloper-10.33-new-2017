/*
 * @(#)TransactionAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.html.struts11.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import oracle.jbo.html.BC4JContext;
import oracle.jbo.html.struts11.BC4JUtils;

/**
 * <p><strong>TransactionAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.3
 */
public class TransactionAction extends DispatchAction
{
   /**
    * "commit" dispatch method called by DispatchAction
    * 
    */
   public ActionForward commit(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      commit(context);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   /**
    * "rollback" dispatch method called by DispatchAction
    * 
    */
   public ActionForward rollback(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);

      rollback(context);

      return BC4JUtils.getForwardFromContext(context, mapping);
   }

   protected void commit(BC4JContext context)
   {
      context.getApplicationModule().getTransaction().commit();
   }

   protected void rollback(BC4JContext context)
   {
      context.getApplicationModule().getTransaction().rollback();
   }
}