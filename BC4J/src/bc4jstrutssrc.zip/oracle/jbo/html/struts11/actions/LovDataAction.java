/*
 * @(#)LovDataAction.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11.actions;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import oracle.jbo.ViewObject;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.html.BC4JContext;
import oracle.jbo.html.struts11.Constants;

import java.util.StringTokenizer;
import java.util.ArrayList;

/**
 * <p><strong>LovDataAction</strong>
 * </p>
 *
 * @since JDeveloper 9.0.4
 */
public class LovDataAction extends Action 
{
   public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
      BC4JContext context = BC4JContext.getContext(request);
      
      // Retrieve the name of the VO we need to "clone"
      String origVoName = request.getParameter("lovvo");
      
      // Only when the lovvo parameter is present do we need to initialize the working ViewObject
      if (origVoName != null)
      {
         init(context, origVoName);
      }
      
      String searchValue = request.getParameter("svalue");
      if (searchValue != null)
      {
         searchValue = searchValue.trim();
         if (searchValue.length() == 0)
         {
            searchValue = null;
         }
      }

      if (searchValue != null)
      {
         request.setAttribute("svalue", searchValue);

         searchValue = "like '" + searchValue + "'";
         ArrayList dispAttrs = getDisplayAttributes(request);
         
         ViewObject vo = context.getViewObject();
         ViewCriteria vc = vo.createViewCriteria();

         // Iterate through the display list
         for (int index=0; index < dispAttrs.size(); index++)
         {
            AttributeDef attrDef = vo.findAttributeDef((String)dispAttrs.get(index));
            if (!attrDef.isQueriable())
            {
               continue;
            }

            ViewCriteriaRow vr = vc.createViewCriteriaRow();
            vr.setAttribute(attrDef.getName(), searchValue);
            vc.addElement(vr);
         }
         
         vo.applyViewCriteria(vc);
         vo.executeQuery();
      }
      else
      {
         searchValue = "%";
         
         // Retrieve current search criteria to display it in the form input text
         ViewObject vo = context.getViewObject();
         if (vo != null)
         {
            ViewCriteria vc = vo.getViewCriteria();
            if (vc != null)
            {
               ViewCriteriaRow vr = (ViewCriteriaRow) vc.first();
               if (vr != null)
               {
                  ArrayList dispAttrs = getDisplayAttributes(request);
          
                  if (dispAttrs.size() > 0)
                  {
                     String element = (String)vr.getAttribute((String)dispAttrs.get(0));
                     if (element != null && element.length() > 0)
                     {
                        if (element.startsWith("like '"))
                        {
                           searchValue = element.substring(element.indexOf('\'') + 1);
                           searchValue = searchValue.substring(0, searchValue.indexOf('\''));
                        }
                     }
                  }
               }
            }
         }

         request.setAttribute("svalue", searchValue);
      }
         
      return mapping.findForward(Constants.SUCCESS_FORWARD);
   }
   
   protected void init(BC4JContext context, String origVoName)
   {
      ViewObject clonedVo = context.getViewObject();
      
      // If a previous version of the clonedVo exist, destroy it
      if (clonedVo != null)
      {
         clonedVo.remove();
      }
      
      ApplicationModule am = context.getApplicationModule();
      ViewObject origVo = am.findViewObject(origVoName);
      
      clonedVo = am.createViewObject(LovCompAction.LOVVO_NAME, origVo.getDefFullName());

      // Apply original View criteria and orderBy clause.
      final ViewCriteria vc = origVo.getViewCriteria();
      if (vc != null)
      {
         clonedVo.applyViewCriteria(vc);
      }
      final String orderByClause = origVo.getOrderByClause();
      if (orderByClause != null && orderByClause.length() > 0)
      {
         clonedVo.setOrderByClause(orderByClause);
      }

      clonedVo.setRangeSize(10);
      clonedVo.setIterMode(ViewObject.ITER_MODE_LAST_PAGE_PARTIAL);
      clonedVo.executeQuery();
   }

   protected ArrayList getDisplayAttributes(HttpServletRequest request)
   {
      ArrayList dispAttrs = new ArrayList();
      StringTokenizer strtok = new StringTokenizer(request.getParameter("dattr") , ",");
      String sCol;
 
      while (strtok.hasMoreTokens())
      {  
         sCol = strtok.nextToken();
         sCol = sCol.trim();
         dispAttrs.add(sCol);
      }
      
      return dispAttrs;
   }
   
}
