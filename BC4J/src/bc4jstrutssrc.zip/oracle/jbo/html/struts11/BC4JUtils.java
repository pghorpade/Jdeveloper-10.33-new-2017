/*
 * @(#)BC4JUtils.java
 *
 * Copyright 2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.struts11;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import oracle.jbo.html.BC4JContext;

/**
 * <p><strong>BC4JUtils</strong> contains a set of method to facilitate usage of the BC4JContext.</p>
 *
 * @since JDeveloper 9.0.3
 */
public class BC4JUtils
{
   /**
    * Retrieve the ActionForward to be return by the execute method of an Action class
    * using information from the <code>BC4JContext</code>.
    * @see BC4JUtils#getForwardFromContext(BC4JContext, BC4JActionMapping)
    */
   public static ActionForward getForwardFromContext(HttpServletRequest request, ActionMapping mapping)
   {
      return getForwardFromContext(BC4JContext.getContext(request), (BC4JActionMapping) mapping);
   }
   
   /**
    * Retrieve the ActionForward to be return by the execute method of an Action class
    * using information from the <code>BC4JContext</code>.
    * @see BC4JUtils#getForwardFromContext(BC4JContext, BC4JActionMapping)
    */
   public static ActionForward getForwardFromContext(BC4JContext ctx, ActionMapping mapping)
   {
      return getForwardFromContext(ctx, (BC4JActionMapping) mapping);
   }

   /**
    * <p>Retrieve the ActionForward to be return by the execute method of an Action class
    * using information from the <code>BC4JContext</code>.
    * Use the following rule to retrieve the best forward for the situation.<p>
    * 
    * <ul>
    * <li>look in the mapping for a forward with the name of the current event.</li>
    * <li>if not, look in the mapping for a forward with the name "success".</li>
    * <li>if not, build an ActionForward back to the same page.</li>
    * </ul>
    *
    * @see org.apache.struts.action.Action#execute
    */
   public static ActionForward getForwardFromContext(BC4JContext ctx, BC4JActionMapping mapping)
   {
      // Use the forward associated with the event name
      // Each event can have their own forward.
      ActionForward actionForward = null;

      String forward = ctx.getEvent();
      if (forward == null)
      {
         actionForward = mapping.findForward(Constants.SUCCESS_FORWARD);
      }
      else
      {
         // Try the event name
         actionForward = mapping.findForward(forward);
      
         // Then give "success" a chance.
         if (actionForward == null)
         {
            actionForward = mapping.findForward(Constants.SUCCESS_FORWARD);
         }
      }

      // If the forward path has not been defined for this event in the Struts-Config,
      // the default is to return to the same page.
      if (actionForward == null)
      {
         actionForward = new ActionForward(ctx.getPreviousPath());
      }

      return actionForward;
      
   }

}