package oracle.jbo.domain;

import oracle.jbo.common.Diagnostic;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.ROWID;    
import java.sql.SQLException;

import oracle.jbo.Transaction;


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.RowID</tt>,
* the Java representation of the
* ROWID database type. This wrapper allows an instance of the
* <tt>oracle.sql.RowID</tt> to be used as an immutable Domain object.
* <p>
* <p><code>RowID</code> objects consist of data (a byte array)
* and a Domain type code.
* Domain row IDs extend SQL row IDs by being convertable to
* JDBC values.
* <p>
* The <tt>oracle.jbo.domain.RowID</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* @since JDeveloper 3.0
 * 
 * @javabean.class name=RowID
 * 
*/
public class RowID
             extends oracle.sql.ROWID
             implements DomainInterface,
                        KeyAttributeInterface,
                        CustomDatum,
                        java.io.Serializable
{
  private static final long serialVersionUID = -1471694256812793030L;

  static CustomDatumFactory fac = null;

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>RowID</code> Domain.
    *
    * This method is invoked when Business Components for Java is initialized.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>RowID</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass implements DatumFactory
        {
            public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new RowID(data) : null;
            }
            
            public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new RowID(data) : null;
            }
            
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new RowID(d.getBytes());
               }
               return null;
            }
        };
        fac = new facClass();
     }
     return fac;
  }

  /**
     * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>RowID</code> Domain object back into an
    * SQL <code>ROWID</code> object.
    *
    * @param conn <code>OracleConnection</code> Not used.
    * @return A <code>Datum</code> containing <code>ROWID</code> object.
    * @throws java.sql.SQLException Never.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new ROWID(getBytes());
  }
  
  /**
    * Creates a default <code>RowID</code> Domain object.
    *
    * <p>This constructor does not create a null RowID. To create a
    * null RowID,
    * use one of the {@link oracle.jbo.domain.NullValue} objects to indicate
    * <tt>null</tt>.
    */
  public RowID() {
     super();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
    * <p>Creates a <code>RowID</code> Domain object from the given byte array.
    *
    * @param value a value returned by a previous call to
    * <code>getBytes()</code> on an SQL object compatable with
    * <code>RowID</code>.
    */
  public RowID(oracle.sql.ROWID value) 
  {
     super(value.getBytes());
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
    * <p>Creates a <code>RowID</code> Domain object from the given byte array.
    *
    * @param value byte array containing the value of the RowID.
    */
  public RowID(byte[] value) {
     super(value);
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
    * <p> Creates a <code>RowID</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param   value   a textual representation of a <code>RowID</code>.
    * @throws  java.sql.SQLException if the representation is invalid.
    */
  public RowID(String value) {
     super(value.getBytes());
  }

  /**
   * Return a String object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
  * @javabean.property 
   */
  public String getValue()
  {
     return toString();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>
    * Converts <code>this</code> to a JDBC object.
    *
    *
    * @return the JDBC representation of <code>this</code>, or  <code>null</code>,
    * if the conversion fails.
    */
  public Object getData() {
    try
    {
       return toJdbc();
    }
    catch( Exception e )
    {
       Diagnostic.printStackTrace(e);
    }
    return null;
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    *
  */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }
  
  /**
    * For testing purposes only: converts <code>this</code> to a textual representation.
    */
  public String toString() {
     //creating RowID from this string should be able to create an equivalent RowID object.
     return new String(getBytes());
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * <p>The argument is converted to a <code>RowID</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (!other.getClass().equals(getClass()))
     {
        return false;
     }
     return super.equals(other);
  }
   
  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
  public int hashCode()
  {
//     return getBytes().hashCode();
     return stringValue().hashCode();
  }
  
   private void writeObject(java.io.ObjectOutputStream out)
     throws java.io.IOException
   {
      byte[] bytes = getBytes();
      out.writeInt(bytes.length);
      out.write(bytes);
   }
   
   private void readObject(java.io.ObjectInputStream in)
     throws java.io.IOException, ClassNotFoundException
   {
      int size = in.readInt();
      byte[] bytes = new byte[size];
      in.read(bytes);
      setBytes(bytes);
   }
   
   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   /*
   public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainFactory 
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
            if (mAttrClass != RowID.class) 
            {
               if (Diagnostic.isOn()) 
               {
                  Diagnostic.println("EXCEPTION: No support for subclasses of RowID in XML");
               }
            }
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               //since RowID is rendered in xml as string representation of the bytes.
               org.w3c.dom.Node domNode = node.getFirstChild();
               if (domNode != null)
               {
                  return new RowID(Raw.readBytesFromXML(domNode));
               }
               return null;
               
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
         }
      }
      
      return new facClass(attrClass);
   }
   */
}



 
