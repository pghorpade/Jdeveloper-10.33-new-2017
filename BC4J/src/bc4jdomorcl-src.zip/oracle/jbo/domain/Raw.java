package oracle.jbo.domain;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.RepConversion;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.RAW;    
import java.sql.SQLException;

import oracle.jbo.Transaction;

// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.Raw</tt>,
* the Java representation of the
* RAW database type. This wrapper allows an instance of the
* <tt>oracle.sql.Raw</tt> to be used as an immutable Domain object.
* <p>
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <tt>oracle.sql</tt> class such that it returns an instance of an
* <tt>oracle.jbo.domain.*</tt> object.
* <p><code>Raw</code> objects consist of data (a byte array)
* and a Domain type code.
* <p>
* The <tt>oracle.jbo.domain.Raw</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* @since JDeveloper 3.0
 * 
 * @javabean.class name=Raw
 * 
*/
public class Raw
             extends oracle.sql.RAW
             implements DomainInterface, 
                        KeyAttributeInterface,
                        CustomDatum,
                        java.io.Serializable 
{
  private static final long serialVersionUID = -2170531656806664663L;
  private static int mUseStringAsBytes = -1;
  int mHashCode = 0;

  static CustomDatumFactory fac = null;
  static
  {
     //custom converters tested in domain\sv33

     TypeFactory.addCustomConverter(oracle.jbo.domain.Raw.class, java.lang.String.class, 
     new TypeConvMapEntry()
     {
         protected Object convert(Class toClass, Class valClass, Object val)
         {
             try
             {
                return new oracle.jbo.domain.Raw((String)val);
             }
             catch (Exception e)
             {
                //check for null/ String and 0 length.
                if (val instanceof String && ((String)val).trim().length() == 0)
                {
                   return null;
                }
                throw new DataCreationException(toClass.getName(), val, e);
             }
          }
     }
     );

     TypeFactory.addCustomConverter(oracle.jbo.domain.Raw.class, JBOClass.findDataClass("[B"),
     new TypeConvMapEntry()
     {
         protected Object convert(Class toClass, Class valClass, Object val)
         {
             try
             {
                return new oracle.jbo.domain.Raw((byte[])val);
             }
             catch (Exception e)
             {
                //check for null/ String and 0 length.
                if (val == null || ((byte[])val).length == 0)
                {
                   return null;
                }
                throw new DataCreationException(toClass.getName(), val, e);
             }
          }
     }
     );
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Raw</code> Domain.
    *
    * This method is invoked when Business Components for Java is initialized.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Raw</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass implements DatumFactory
        {
            public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Raw(data) : null;
            }
            
            public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Raw(data) : null;
            }

            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new Raw(d.getBytes());
               }
               return null;
            }
        };
        fac = new facClass();
     }
     return fac;
  }
  
  static boolean useStringAsBytes()
  {
     if (mUseStringAsBytes == -1)
     {
        mUseStringAsBytes = (PropertyMetadata.DOMAIN_STRING_AS_BYTES_FOR_RAW.getPropertyAsBoolean()) ? 1 : 0;
     }

     return mUseStringAsBytes == 1;
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Raw</code> Domain object back into an
    * SQL <code>RAW</code> object.
    *
    * @param conn <code>OracleConnection</code> Not used.
    * @return A <code>Datum</code> containing <code>RAW</code> object.
    * @throws <code>SQLException</code> Never.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new RAW(getBytes());
  }
  
  /**
    * Creates a default <code>Raw</code> Domain object.
    *
    * <p>This constructor does not create a null object. To create a null object,
    * use the {@link oracle.jbo.domain.NullValue} object to indicate null.
    */
  public Raw() {
     super();
  }

  /**
    * Creates a <code>Raw</code> object identical to an
    * existing <code>Raw</code> object.
    *
    * @param value a <code>Raw</code> Domain object.
    * @throws	java.sql.SQLException never.
    */
  public Raw(Raw value) throws SQLException {
     super(value.getBytes());
  }             

  /**
    * Creates a <code>Raw</code> Domain object encapsulating an SQL
    * <code>RAW</code> object.
    *
    * @param value a <code>RAW</code> SQL object.
    * @throws	java.sql.SQLException never.
    */
  public Raw(RAW value) throws SQLException {
     super(value.getBytes());
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this constructor.</em>
    * <p>Creates a <code>Raw</code> Domain object from the given byte array.
    *
    * @param value a value returned by a previous call to
    * <code>getBytes()</code> on an SQL object compatable with
    * <code>Raw</code>.
    */
  public Raw(byte[] value) {
     super(value);
  }             

  /**
    * Creates a <code>Raw</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param 	value   a textual representation of a <code>Raw</code> object.
    * @throws	<code>SQLException</code> if the representation is invalid.
    */
  public Raw(String value) throws SQLException{
     // super(value.getBytes());
     super((useStringAsBytes()) ? (Object) value.getBytes() : (Object) value);
  }

  /**
    * Creates a <code>Raw</code> Domain object from a
    * Java <code>Object</code>.
    *
    * <p>The <code>Object</code> must be an instance of <code>byte[]</code>,
    * which becomes the body of the <code>Raw</code> object, or an instance of
    * <code>String</code>, which is first converted into a byte array.
    *
    * @param 	value   an arbitrary <code>Object</code>.
    * @throws	java.sql.SQLException if the object is not an instance
    * of <code>byte[]</code> or <code>String</code>.
    */
  public Raw(Object value) throws SQLException {
     super(value);
  }

  /**
   * Return a byte[] object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
  * @javabean.property 
   */
  public byte[] getValue()
  {
     return (byte[])getData();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * Converts <code>this</code> to a JDBC object.
    *
    * @return the internal byte array of <code>this</code> as a JBDC object.
    */
  public Object getData() {
    try
    {
       return toJdbc();
    }
    catch( Exception e )
    {
       Diagnostic.printStackTrace(e);
    }
    return null;
  }

  /**
 * <b>Internal:</b> <em>Applications should not invoke this method.</em>
  */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }
  
  /**
    * For testing purposes only: converts <code>this</code> to a character string.
    */
  public String toString() {
     return stringValue();
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * <p>The argument is converted to a <code>Raw</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (other == null) 
     {
        return false;
     }
     if (!other.getClass().equals(getClass()))
     {
        try
        {
           Raw charOther = new Raw(other);
           return super.equals(charOther);
        }
        catch( Exception sqle )
        {
           return false;
        }
     }
     return super.equals(other);
  }          
   
  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
  public int hashCode()
  {
     if (mHashCode == 0)
     {
        byte[] bytes = getBytes();
        int code = 0;
        int shifter = 0;
        for (int i = 0; i < bytes.length; i++)
        {
           code ^= bytes[i] << shifter;
           ++shifter;
        }
        if (code == 0)
        {
           code = -7876;
        }
        mHashCode = code;
     }
     return mHashCode;
  }

   private void writeObject(java.io.ObjectOutputStream out)
     throws java.io.IOException
   {
      byte[] bytes = getBytes();
      out.writeInt(bytes.length);
      out.write(bytes);
   }

   private void readObject(java.io.ObjectInputStream in)
     throws java.io.IOException, ClassNotFoundException
   {
      int size = in.readInt();
      byte[] bytes = new byte[size];
      in.read(bytes);
      setBytes(bytes);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainFactory 
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               Raw s = (Raw)mAttrClass.newInstance();
               org.w3c.dom.Node domNode = node.getFirstChild();
               if (domNode != null)
               {
                  s.setBytes(Raw.readBytesFromXML(domNode));
               }
               return s;
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
         }
      }
      
      return new facClass(attrClass);
   }

   //utility methods to read byte from xml.
   static byte[] readBytesFromXML(org.w3c.dom.Node node)
   {
      return RepConversion.convertHexStringToByte(node.getNodeValue()); //returns String
   }
   
}



 
