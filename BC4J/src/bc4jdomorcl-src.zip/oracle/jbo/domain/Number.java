package oracle.jbo.domain;

import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.NUMBER;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.io.IOException;
import java.io.Serializable;

import oracle.jbo.Transaction;
import oracle.jbo.common.Diagnostic;


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------

/**
* This class extends <tt>oracle.sql.NUMBER</tt>,
* Oracle's Java representation of the NUMBER database type. This class allows an
* instance of the <tt>oracle.sql.NUMBER</tt> to be used as a domain object.
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <tt>oracle.sql.NUMBER</tt> class such that it returns an instance of an
* <tt>oracle.jbo.domain.Number</tt> object.
*
* <p>
* The <tt>oracle.jbo.domain.Number</tt> domain class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* <p>
* @since JDeveloper 3.0
 * 
 * @javabean.class name=Number
 * 
*/
public class Number
             extends oracle.sql.NUMBER
             implements DomainInterface, 
                        KeyAttributeInterface,
                        CustomDatum,
                        Serializable
{
  private static final long serialVersionUID = -6507359405709672486L;
  private int mHashCode = 0;

  static 
  {
     TypeFactory.addCustomConverter(oracle.jbo.domain.Number.class, java.lang.String.class, 
     new TypeConvMapEntry()
     {
         protected Object convert(Class toClass, Class valClass, Object val)
         {
             try
             {
                return new oracle.jbo.domain.Number((String)val);
             }
             catch (Exception e)
             {
                //check for null/ String and 0 length.
                if (val instanceof String && ((String)val).trim().length() == 0)
                {
                   return null;
                }
                throw new DataCreationException(toClass.getName(), val, e);
             }
          }
     }
     );
  }

  static CustomDatumFactory fac = null;
  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Number</code> Domain.
    *
    * This method is invoked when JBO is initialized.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Number</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass
              implements DatumFactory
        {
           public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
           {
              byte[] data = jdbc.getBytes(index);
              return (data != null) ? new Number(data) : null;
           }
           
           public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
           {
              byte[] data = jdbc.getBytes(index);
              return (data != null) ? new Number(data) : null;
           }
           
           public CustomDatum create(Datum d, int sql_type_code) throws SQLException
           {
              if (d != null)
              {
                 return new Number(d.getBytes());
              }
              return null;
           }
        };
        fac = new facClass();
     }
     return fac;
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Number</code> Domain object back into an
    * SQL <code>NUMBER</code> object.
    *
    * @param conn <code>OracleConnection</code> Not used.
    * @return A <code>Datum</code> containing <code>NUMBER</code> object.
    * @throws <code>SQLException</code> Never.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new NUMBER(getBytes());
  }

  /**
    * Creates a <code>Number</code> Domain object representing zero.
    *
    * Use one of the <code>NullValue()</code> constructors to create
    * a null <code>Number</code> object.
    */
  public Number() {
     super();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Creates a <code>Number</code> Domain object from the given byte array.
    *
    * @param value a value returned by a previous call to
    * <code>getBytes()</code> on an SQL object compatable with
    * <code>Number</code>.
    */
  public Number(byte[] value) {
     super(value);
  }             

  /**
    * Creates a <code>Number</code> Domain object from a <code>byte</code>.
    *
    * @param value an 8-bit signed integer.
    */
  public Number(byte value) {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>int</code>.
    *
    * @param value a 32-bit signed integer.
    */
  public Number(int value) {
     super(value);
  }


  /**
    * Creates a <code>Number</code> Domain object from an <code>Long</code> object.
    *
    * @param value a 32-bit floating-point value.
    */
  public Number(Long value) {
     super(value.longValue());
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>long</code>.
    *
    * @param value a 64-bit signed integer.
    */
  public Number(long value) {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>short</code>.
    *
    * @param value a 16-bit signed integer.
    */
  public Number(short value) {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>float</code>.
    *
    * @param value a 32-bit floating-point value.
    */
  public Number(float value) {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>double</code>.
    *
    * @param value a 64-bit floating-point value.
    * @throws  <code>SQLException</code> on over/underflow of the exponent
    * or on overflow of the mantissa.
    */
  public Number(double value) throws SQLException {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an <code>Double</code> object.
    *
    * @param value a 64-bit floating-point value.
    * @throws  <code>SQLException</code> on over/underflow of the exponent
    * or on overflow of the mantissa.
    */
  public Number(Double value) throws SQLException {
     super(value.doubleValue());
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * <code>BigDecimal</code>.
    *
    * <p>Limitations:
    * <ul><li>This method may not preserve the scaling of the argument.
    *     <li>A <code>BigDecimal</code> distinguishes between 0 and -0.
    *         This information will be lost in the conversion.
    *     <li>At present, this method does not round.  If the argument's
    *         mantissa has two many digits an exception is thrown.
    * </ul>
    * @param value an arbitrarily precise floating-point value.
    * @throws  <code>SQLException</code> on over/underflow of the exponent
    * or on overflow of the mantissa.
    */
  public Number(BigDecimal value) throws SQLException {
     super(value);
  }

  /**
  * Creates a <code>Number</code> Domain object from a
    * <code>BigInteger</code>.
    *
    * @param value an arbitrarily integer.
    * @throws  <code>SQLException</code> on overflow.
    */
  public Number(BigInteger value) throws SQLException {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param   value   a textual representation of a fixed-point number.
    * @param precision the maximum length of the string.
    * @throws  <code>SQLException</code> on overflow.
    * @throws <code>NumberFormatException</code> if value does not represent a 
    * valid <code> BigDecimal</code> value.
    */
  public Number(String value, int precision) throws SQLException {
     super(value.trim(), precision);
  }

  /**
    * Creates a <code>Number</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param   value   a textual representation of a <code>BigDecimal</code>.
    * @throws <code>SQLException</code> on over/underflow of the exponent
    * @throws <code>NumberFormatException</code> if value does not represent a 
    * valid <code> BigDecimal</code> value.
    */
  public Number(String value) throws SQLException {
     //super(new BigDecimal(value.trim()));
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from a <code>Boolean</code>.
    *
    * @param value <code>true</code> or <code>false</code>.
    * The instance is <code>0</code> if <code>value</code> is <code>false</code>,
    * or <code>1</code> otherwise.
    */
  public Number(boolean value) {
     super(value);
  }

  /**
    * Creates a <code>Number</code> Domain object from an arbitrary
    * <code>Object</code>.
    *
    * One of the other constructors for <code>Number</code> is invoked,
    * depending on the type of the argument.
    * @param value an arbitrary object.
    * @throws <code>SQLException</code> if the called method fails,
    * or if the argument's type is not recognized.
    * @throws <code>NumberFormatException</code> if value does not represent a 
    * valid <code> BigDecimal</code> value.
    */
  public Number(Object value) throws SQLException {
     super(value);
  }             

  /**
    * Creates a <code>Number</code> identical to an
    * existing <code>Number</code>.
    *
    * @param value a <code>Number</code> Domain object.
    * @throws  <code>SQLException</code> never.
    */
  public Number(Number value) {
     setBytes(value.getBytes());
  }

  /**
    * Creates a <code>Number</code> Domain object from an SQL
    * <code>NUMBER</code>.
    *
    * @param value a <code>NUMBER</code> SQL object.
    * @throws  <code>SQLException</code> never.
    */
  public Number(NUMBER value) {
     setBytes(value.getBytes());
  }


  /**
   * Return a this domain's value as BigDecimal
   * This method may be used to access the value for this domain in EL-expressions.
  * @javabean.property 
   */
  public BigDecimal getBigDecimalValue()
  {
     return bigDecimalValue();
  }

  /**
   * Return a this domain's value as double
   * This method may be used to access the value for this domain in EL-expressions.
  * @javabean.property 
   */
  public double getValue()
  {
     return doubleValue();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * Converts <code>this</code> to a JDBC object.
    *
    */
  public Object getData() {
     try
     {
        return toJdbc();
     }
     catch( Exception e )
     {
        Diagnostic.printStackTrace(e);
     }
     return null;
  }

  /**
   * <b>Internal:</b> <em>Applications should not invoke this method.</em>
   *
  */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }
  
  /**
    * For testing purposes only: converts <code>this</code> to a fixed-point number presented as a string.
    */
  public String toString() {
     return stringValue();
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * The argument is converted to a <code>Number</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (other == null) 
     {
        return false;
     }
     if (!other.getClass().equals(getClass()))
     {
        try
        {
           Number numOther = new Number(other);
           return super.equals(numOther);
        }
        catch( Exception sqle )
        {
           return false;
        }
     }
     return super.equals(other);
  }          
   
  /**
    * Computes the hash code.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      if (mHashCode == 0)
      {
         mHashCode = bigDecimalValue().hashCode();
         if (mHashCode == 0)
         {
            mHashCode = -6859;
         }
      }
      return mHashCode;
   }

  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
     byte[] bytes = getBytes();
     out.writeInt(bytes.length);
     out.write(bytes);
  }
   
  private void readObject(java.io.ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
     int size = in.readInt();
     byte[] bytes = new byte[size];
     in.read(bytes);
     setBytes(bytes);
  }

  /**
   * Calls NUMBER.longValue() to convert internal Oracle Number to a Java long.
   * @return   a Java long value
   */
  public long longValue() 
  {
     try
     {
        return super.longValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.longValue", null, sqle); 
     }
  } // longValue()

  /**
   * Calls NUMBER.intValue() to convert internal Oracle Number to a Java int.
   *
   * @return   a Java int value
   */
  public int intValue() 
  {
     try
     {
        return super.intValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.intValue", null, sqle); 
     }
  } // intValue()

  /**
   * Calls NUMBER.shortValue() to convert internal Oracle Number to a Java short.
   *
   * @return   a Java short value
   */
  public short shortValue() 
  {
     try
     {
        return super.shortValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.shortValue", null, sqle); 
     }
  } // shortValue()

  /**
   * Calls NUMBER.byteValue() to convert internal Oracle Number to a Java byte.
   *
   * @return   a Java byte value
   */
  public byte byteValue() 
  {
     try
     {
        return super.byteValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.byteValue", null, sqle); 
     }
  } // byteValue()

  /**
   * Calls NUMBER.bigIntegerValue() to convert internal Oracle Number to a Java BigInteger.
   *
   * @return   a Java BigInteger value
   */
  public BigInteger bigIntegerValue() 
  {
     try
     {
        return super.bigIntegerValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.bigIntegerValue", null, sqle);
     }
  } // bigIntegerValue()

  /**
   * Calls NUMBER.bigDecimalValue() to convert internal Oracle Number into a Java 
   * BigDecimal.
   *
   * @return   a Java BigDecimal value
   */
  public BigDecimal bigDecimalValue() 
  {
     try
     {
        return super.bigDecimalValue();
     }
     catch (Exception sqle)
     {
        throw new GenericDomainException("Number.bigDecimalValue", null, sqle);
     }
  } // bigDecimalValue()
  
  /* ----------------------- Arithmetic Methods --------------------------- */
  /**
   * Adds another number to <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number add(Number n) 
  {
     try
     {
        return new Number(super.add(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.add", n, sqle);
     }
  }

  /**
   * Adds another number to <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number add(double n) 
  {
     try
     {
        return add(new Number(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.add", new Double(n), sqle);
     }
  }

  /**
   * Adds another number to <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number add(int n) 
  {
    return add(new Number(n));
  }

  /**
   * Adds another number to <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   * @exception SQLException if the Java implementation is not available.
   */
  public NUMBER add(NUMBER n) 
  {
    return add(new Number(n));
  }

  /**
   * Subtracts another number from <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number subtract(Number n) 
  {
     try
     {
        return new Number(super.sub(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.subtract", n, sqle);
     }
  }

  /**
   * Subtracts another number from <code>this</code>.
   *
   * @param     n a double number
   * @return   a new <code>Number</code> object.
   */
  public Number subtract(double n) 
  {
     try
     {
        return subtract(new Number(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.subtract", new Double(n), sqle);
     }
  }

  /**
   * Subtracts another number from <code>this</code>.
   *
   * @param     n a int number
   * @return   a new <code>Number</code> object.
   */
  public Number subtract(int n) 
  {
     return subtract(new Number(n));
  }

  /**
   * Subtracts another number from <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER subtract(NUMBER n) 
  {
    return subtract(new Number(n));
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number multiply(Number n) 
  {
     try
     {
        return new Number(super.mul(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.multiply", n, sqle);
     }
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number multiply(double n) 
  {
     try
     {
        return multiply(new Number(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.multiply", new Double(n), sqle);
     }
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number multiply(int n) 
  {
     return multiply(new Number(n));
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER multiply(NUMBER n) 
  {
    return multiply(new Number(n));
  }

   /**
   * Divides <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number divide(Number n)
  {
     try
     {
        return new Number(super.div(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.divide", n, sqle);
     }
  }

   /**
   * Divides <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number divide(double n)
  {
     try
     {
        return divide(new Number(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.divide", new Double(n), sqle);
     }
  }

   /**
   * Divides <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number divide(int n)
  {
    return divide(new Number(n));
  }

   /**
   * Divides <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER divide(NUMBER n)
  {
    return divide(new Number(n));
  }

   // These methods are defined in oracle.sql.NUMBER and return an object
   //of that type. Overridden to return an object of type oracle.jbo.domain.Number
   /**
   * Finds the absolute value of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   * @exception <code>SQLException</code> if the Java implementation is not available.
   */
  public NUMBER abs() 
  {
     try
     {
        return new Number(super.abs());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.abs", this, sqle);
     }
  }

   /**
   * Calculates the arc cosine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER acos() 
  {
     try
     {
        return new Number(super.acos());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.acos", this, sqle);
     }
  }

   /**
   * Calculates the arc sine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER asin() 
  {
     try
     {
        return new Number(super.asin());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.asin", this, sqle);
     }
  }

   /**
   * Calculates the arc tangent of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER atan() 
  {
     try
     {
        return new Number(super.atan());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.atan", this, sqle);
     }
  }

   /**
   * Calculates <code>atan(this, x)</code>.
   *
   * @param     x    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number atan2(Number x) 
  {
     try
     {
        return new Number(super.atan2(x));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.atan2", x, sqle);
     }
  }

   /**
   * Calculates <code>atan(this, x)</code>.
   *
   * @param     x    an SQL number.
   * @return   a new <code>Number</code> object.
   * @exception SQLException if the Java implementation is not available.
   */
  public NUMBER atan2(NUMBER x)
  {
    return atan2(new Number(x));
  }

   /**
   * Finds the ceiling of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER ceil() 
  {
     try
     {
        return new Number(super.ceil());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.ceil", this, sqle);
     }
  }

  /**
   * Returns -1 if NUMBER is less than n, 0 if NUMBER and n are equal (==), 
   * 1 if NUMBER is greater than n.
   * @param     n   input Oracle Number
   * @return   integer result of comparison
   */
  public int compareTo(int n)
  {
    return compareBytes(this.shareBytes(), new NUMBER(n).shareBytes());
  }


  /**
   * Returns -1 if NUMBER is less than n, 0 if NUMBER and n are equal (==), 
   * 1 if NUMBER is greater than n.
   * @param     n   input Oracle Number
   * @return   integer result of comparison
   */
  public int compareTo(double n)
  {
     try
     {
         return compareBytes(this.shareBytes(), new NUMBER(n).shareBytes());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.compareTo", this, sqle);
     }
  }
  
   /**
   * Calculates the cosine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER cos()
  {
     try
     {
        return new Number(super.cos());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.cos", this, sqle);
     }
  }

   /**
   * Calculates the hyperbolic cosine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER cosh() 
  {
     try
     {
        return new Number(super.cosh());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.cosh", this, sqle);
     }
  }

   /**
   * Subtracts <code>1</code> from <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER decrement() 
  {
     try
     {
        return new Number(super.decrement());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.decrement", this, sqle);
     }
  }

   /**
   * Divides <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER div(NUMBER n)
  {
    return divide(new Number(n));
  }

   /**
   * Raises <code>e</code> to the power of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER exp() 
  {
     try
     {
        return new Number(super.exp());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.exp", this, sqle);
     }
  }

   /**
   * Rounds <code>this</code> to a specified precision.
   *
   * @param     precision    the number of significant decimal places.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER floatingPointRound(int precision) 
  {
     try
     {
        return new Number(super.floatingPointRound(precision));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.floatingPointRound", this, sqle);
     }
  }

   /**
   * Finds the floor of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER floor() 
  {
     try
     {
        return new Number(super.floor());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.floor", this, sqle);
     }
  }

   /**
   * Adds <code>1</code> to <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER increment()
  {
     try
     {
        return new Number(super.increment());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.increment", this, sqle);
     }
  }

   /**
   * Calculates the natural logarithm of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER ln() 
  {
     try
     {
        return new Number(super.ln());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.ln", this, sqle);
     }
  }

   /**
   * Calculates the log of <code>this</code> to the specified <code>base</code>.
   *
   * @param     base    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number log(Number base) 
  {
     try
     {
        return new Number(super.log(base));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.log", base, sqle);
     }
  }

   /**
   * Calculates the log of <code>this</code> to the specified <code>base</code>.
   *
   * @param     base    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number log(double base) 
  {
     try
     {
        return log(new Number(base));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.log", new Double(base), sqle);
     }
  }

   /**
   * Calculates the log of <code>this</code> to the specified <code>base</code>.
   *
   * @param     base    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number log(int base) 
  {
     return log(new Number(base));
  }

   /**
   * Calculates the log of <code>this</code> to the specified <code>base</code>.
   *
   * @param     base    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER log(NUMBER base) 
  {
     return log(new Number(base));
  }

   /**
   * Calculates the remainder of <code>this/n</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number mod(Number n) 
  {
     try
     {
        return new Number(super.mod(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.mod", n, sqle);
     }
 }


   /**
   * Calculates the remainder of <code>this/n</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number mod(double n) 
  {
     try
     {
        return mod(new Number(n));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.mod", new Double(n), sqle);
     }
 }

   /**
   * Calculates the remainder of <code>this/n</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number mod(int n) 
  {
     return mod(new Number(n));
  }

   /**
   * Calculates the remainder of <code>this/n</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER mod(NUMBER n) 
  {
     return mod(new Number(n));
  }

   /**
   * Multiplies <code>this</code> by another number.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER mul(NUMBER n) 
  {
    return multiply(new Number(n));
  }

   /**
   * Calculates <code>0 - this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER negate() 
  {
     try
     {
        return new Number(super.negate());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.negate", this, sqle);
     }
  }

   /**
   * Raises <code>this</code> to the power of <code>exp</code>.
   *
   * @param     exp    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public Number pow(Number exp) 
  {
     try
     {
        return new Number(super.pow(exp));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.pow", exp, sqle);
     }
  }

   /**
   * Raises <code>this</code> to the power of <code>exp</code>.
   *
   * @param     exp    a Java 32-bit integer.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER pow(int exp) 
  {
     try
     {
        return new Number(super.pow(exp));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.pow", this, sqle);
     }
  }

   /**
   * Raises <code>this</code> to the power of <code>exp</code>.
   *
   * @param     exp    a Java 32-bit integer.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER pow(NUMBER exp) 
  {
     return pow(new Number(exp));
  }

   /**
   * Rounds <code>this</code> to a specified precision.
   *
   * @param     decimal_place    the number of significant decimal places.
   * @return   a Java <tt>int</tt>.
   */
  public NUMBER round(int decimal_place) 
  {
     try
     {
        return new Number(super.round(decimal_place));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.round", this, sqle);
     }
  }

  /**
   * Rounds <code>this</code> to a specified precision, and tests for excessive
   * magnitude.
   * @param left the maximum number of decimal digits allowed to the left of the
   *                     decimal point. If this limit is exceeded
   *                     <code>big</code> is set, but digits are not truncated.
   * @param right  the maximum number of decimal digits allowed to the right of the
   *                     decimal point. The result is rounded to this precision.
   *                     When this parameter is negative digits to the
   *                     right of the decimal are forced to zero.
   * @param big    a flag set to <code>true</code> only if the number of
   *                  digits left of the decimal exceeds <code>left</code>.
   * @return   a new <code>Number</code> object
   * @exception <code>SQLException</code> if the Java implementation is not available.
   */
  public NUMBER scale(int left, int right, boolean [] big)
  {
     try
     {
        return new Number(super.scale(left, right, big));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.scale", this, sqle);
     }
  }

   /**
   * Shift <code>this</code> a specified number of decimal places.
   * Positive values shift right, negative values shift left.
   *
   * @param     digits  a Java <tt>int</tt>.
   * @return   a Java <tt>int</tt>.
   */
  public NUMBER shift(int digits) 
  {
     try
     {
        return new Number(super.shift(digits));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.shift", this, sqle);
     }
  }

   /**
   * Calculates the sine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER sin() 
  {
     try
     {
        return new Number(super.sin());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.sin", this, sqle);
     }
  }

   /**
   * Calculates the hyperbolic sine of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER sinh() 
  {
     try
     {
        return new Number(super.sinh());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.sinh", this, sqle);
     }
  }

   /**
   * Calculates the square root of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER sqroot() 
  {
     try
     {
        return new Number(super.sqroot());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.sqroot", this, sqle);
     }
  }

  /**
   * Subtracts another number from <code>this</code>.
   *
   * @param     n    an SQL number.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER sub(NUMBER n)
  {
    return subtract(new Number(n));
  }

   /**
   * Calculates the tangent of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER tan() 
  {
     try
     {
        return new Number(super.tan());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.tan", this, sqle);
     }
  }

   /**
   * Calculates the hyperbolic tangent of <code>this</code>.
   *
   * @return   a new <code>Number</code> object.
   */
  public NUMBER tanh() 
  {
     try
     {
        return new Number(super.tanh());
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.tanh", this, sqle);
     }
  }

   /**
   * Truncates <code>this</code>.
   *
   * @param     decimal_place    a Java integer.
   * @return   a new <code>Number</code> object.
   */
  public NUMBER truncate(int decimal_place)
  {
     try
     {
        return new Number(super.truncate(decimal_place));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.truncate", this, sqle);
     }
  }

  /* ---------------- Text Formatting Methods ------------------ */

   // These methods are defined by the interface LnxLib

  /**
   * Interprets a string as a number.
   * @param num         a string representing a numeric value.
   * @param     fmt      a format string [see "Oracle 8 Server Concepts
   *                        Manual" or "CORE User's Guide Appendix D"]
   * @param     lang     the NLS language the conversion is to be
   *                        performed in.  If null the default language is used.
   * @return   a new <code>Number</code> object.
   */
  public static NUMBER formattedTextToNumber(String num,
                                             String fmt,
                                             String lang)
  {
     try
     {
        return new Number(NUMBER.formattedTextToNumber(num, fmt, lang));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.formattedTextToNumber", num, sqle);
     }
  }

  /**
   * Converts a string to a number with specified precision.
   * @param num         a string representing a numeric value.
   * @param     precflag     a flag indicating that precision restriction
   *                          should be applied.
   * @param     preclen
   * the maximum number of the decimal digits the
   * result may have, subject to the scale requirement.
   * This argument is ignored if <code>precflag</code> is <code>false</code>.
   * If the number of digits would otherwise exceed <code>preclen</code>
   * the number will be rounded.
   * @param     scaleflag  a flag indicating that the scale restriction should
   *                          be applied.
   * @param     scalelen
   * the maximum number of decimal places allowed
   * to the right of the decimal point. Negative values are allowed.
   * This argument is ignored if <code>scaleflag</code> is <code>false</code>.
   * This argument takes precedence over <code>preclen</code>.
   * If precision is specified but scale is not, the
   * scale is assumed to be 0.
   * @param     lang     the NLS language the conversion is to be
   *                        performed in.  If null the default language is used.
   * @return   a new <code>Number</code> object.
   */
  public static NUMBER textToPrecisionNumber(String num, boolean precflag,
                                             int preclen, boolean scaleflag,
                                             int scalelen, String lang)
  {
     try
     {
        return new Number(NUMBER.textToPrecisionNumber(num, precflag, preclen, scaleflag, scalelen, lang));
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Number.textToPreicisionNumber", num, sqle);
     }
  }

  //------------------------------------------------------------------------
  //
  // Test Methods
  //
  //------------------------------------------------------------------------
   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    */
  public static void main(
    String[]       argv
    )
    throws SQLException
  {
    System.out.println("Number Test BEGIN");

    try
    {
       Number zero = new Number();
       Number ten = new Number("10");
       Number two = new Number("2");

       if (zero.multiply(ten) instanceof Number)
       {
          System.out.println(zero.multiply(ten));  //prints 0
          System.out.println(two.multiply(ten)); //prints 20
       }
       else
       {
          throw new Exception ("failed");
       }
       if (ten.divide(two) instanceof Number)
       {
          System.out.println(ten.divide(two)); //prints 5
       }
       else
       {
          throw new Exception ("failed");
       }
       if (ten.subtract(two) instanceof Number)
       {
          System.out.println(ten.subtract(two)); //prints 8
       }
       else
       {
          throw new Exception ("failed");
       }
       if (ten.sin() instanceof Number)
       {
          System.out.println(ten.sin()); //prints -0.54402....
       }
       else
       {
          throw new Exception ("failed");
       }
       System.out.println(Number.textToPrecisionNumber("50", true, 2, false, 0, ""));
    }
    catch (Exception e)
    {
       e.printStackTrace();
    }
  }                       
}



 
