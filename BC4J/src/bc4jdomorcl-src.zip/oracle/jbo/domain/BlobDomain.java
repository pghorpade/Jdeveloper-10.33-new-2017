package oracle.jbo.domain;

import java.io.OutputStreamWriter;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Method;
// import oracle.jbo.server.DBTransactionImpl;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.JboException;
import oracle.svcmsg.ResponseValues;

// Oracle Specific JDBC classes: 
import oracle.sql.Datum;
import oracle.sql.BLOB;

// Core JDBC classes: 
import java.sql.SQLException;


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: BlobDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.BLOB</tt>,
* the Java representation of the
* BLOB database type. This wrapper allows an instance of the
* <tt>oracle.sql.BLOB</tt> to be used as a domain object.
* <p>
* @since JDeveloper 3.0
*/
public class BlobDomain extends BaseLobDomain implements 
                                                LobStreamInterface, 
                                                XMLDomainInterface,
                                                java.io.Serializable {

   private static final long serialVersionUID = 3776103424947309941L;
   transient BLOB mylob;

   /**
   * Constructor for this object.
   **/
   public BlobDomain() {}

   /**
   *
   * Constructor for this object. This is for use by JDBC.
   * This constructor uses the transaction context from <code>blob</code>
   * to use the blob-locator
   * in the database.
   * @param blob the BLOB from which to construct the BlobDomain.
   **/
   public BlobDomain(BLOB blob)
   {
      super(blob);
      mylob = blob;
   }

   /**
   * Constructor for this class. Creates an instance of this class
   * with data as described in <code>blobData</code>.
   * @param data data for the BLOB.
   **/
   public BlobDomain(byte[] data)
   {
      super(data);
   }

   /**
   *
   * Creates an instance of this class with data as described in <code>blobData</code>
   * and using the transaction context from <code>blob</code> to use the blob-locator
   * in the database.
   * <p>
   * @param blob transaction context for the BLOB locator, as a BLOB object.
   * @param blobData data for the BLOB.
   **/
   public BlobDomain(BLOB blob, byte[] blobData) 
   {
      super(blob, blobData);
      mylob = blob;
   }

   /**
   * Creates an instance of this class with data as described in <code>blobData</code>
   * and using the transaction context from <code>blob</code> to use the blob-locator
   * in the database.
   * <p>This constructor should be used by applications using the framework to create
   * BlobDomain objects.
   * <p>
   * @param nblob transaction context for the BLOB locator as a BlobDomain object.
   * @param blobData data for the BLOB.
   **/
   public BlobDomain(BlobDomain nblob, byte[] blobData) 
   {
      super(nblob, blobData);
      try
      {
         if (nblob.lob != null) 
         {
            syncLob(new BLOB((oracle.jdbc.OracleConnection)nblob.mylob.getJavaSqlConnection()));
         }
      }
      catch (SQLException sqle)
      {
         throw new JboException(sqle);
      }
   }


   public BlobDomain(ResponseValues respVals)
   {
      super(respVals);
   }

   
   /**
   * Obselete
   **/
   public void useBLOB(BLOB nBlob)
   {
      if (nBlob != null) 
      {
         syncLob(nBlob);
         if (mDataModified && mData == null) 
         {
            //an attempt to reuse an old LOB in a new domain.
            //mark the new domain unmodified as LOB has the real data.
            mDataModified = false;
         }
      }
   }


  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  * <p>
  * @param context an internal framework context.
  **/
   public void   prepareForDML(Object context)
   {
      //if mData is null, fill in empty lob.
      if (mylob == null)
      {
         try
         {
            syncLob(BLOB.empty_lob());
            mClient = false;
         }
         catch (SQLException sqle)
         {
            throw new JboException(sqle);
         }
      }
   }




   /**
   * Tests for equality between <tt>this</tt> and <tt>obj</tt>.
   * Converts all the data into a String and compares the two strings.
   * This is a default implementation of equals which could be overridden
   * to perform more scalable application-specific comparisons.
   * <p>
   * @param obj the data item to compare against.
   **/
   public boolean equals(Object obj) 
   {
      if (obj instanceof BlobDomain) 
      {
         return super.equals(obj);
      }
      return false;
   }


   /*
   private void writeObject(ObjectOutputStream out)
     throws IOException
   {
      write(out);
   }
   
   private void readObject(ObjectInputStream in)
     throws IOException, ClassNotFoundException
   {
      read(this, in);
   }
   */
   
   /**
   * Returns this class name as an XML-element tag for this Struct domain object.
   * Override this method to return a custom XML-element tag for this domain.
   **/
   protected String getXMLElementTag()
   {
      //in the generated code, we should always generate this method and return
      //hardcoded classname to avoid slow runtime performance due to calculation 
      //of the name.
      String className = this.getClass().getName();
      int index = className.lastIndexOf('.');
      if (index > 0) 
      {
         className = className.substring(index+1);
      }
      return className;
   }
   
   /**
   * Creates the XML node in the given XML document for this domain's data.
   * <p>
   * @param xmlDoc name of the XML document.
   **/
   public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc)
   {
      //String xmlName = getXMLElementTag();
      //org.w3c.dom.Node e = xmlDoc.createElement(xmlName);
      byte[] bytesVal = toByteArray();
      org.w3c.dom.Node n = xmlDoc.createTextNode((bytesVal != null) 
                                                  ? oracle.jbo.common.RepConversion.bArray2String(bytesVal)
                                                  : "");
      //e.appendChild(n);
      //return e;
      return n;
   }

   /**
   * Prints the DTD information for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p>
   * @param allDefs name of hashtable containing key-value pairs of XML tags
   * and their values. 
   * @param pw printwriter on which the information should be printed.
   * @param bContainees whether this domain container has containees.
   **/
   public String printXMLDefinition(java.util.Hashtable allDefs, PrintWriter pw,
                             boolean bContainees)
   {
      return "#PCDATA";
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainFactory getXMLDomainFactory(Class attrClass)
   {
      class facClass implements XMLDomainFactory
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               BlobDomain s = (BlobDomain)mAttrClass.newInstance();
               org.w3c.dom.Node domNode = node.getFirstChild();
               if (domNode != null)
               {
                  s.setBytes(Raw.readBytesFromXML(domNode));
               }

               return s;
            }
            catch (JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new JboException(e);
            }
         }
      }

      return new facClass(attrClass);
   }

  /**
  * Creates an empty Blob object.
  * <p>
  * @param context an internal framework context.
  **/
   public static BLOB createEmptyBLOB(Object context)
   {
      try
      {
         return BLOB.empty_lob();
      }
      catch (SQLException sqle)
      {
         throw new JboException(sqle);
      }
   }

  public OutputStream getBinaryOutputStream() throws SQLException 
  {
     return getOutputStream();
  }

  public InputStream getBinaryStream() 
  {
     return getInputStream();
  }

  public byte[] getBytes(long offset, int length)
  {
     if (mData != null) 
     {
        byte[] bytes = new byte[length];
        System.arraycopy (mData.getStorage(), (int)offset, bytes, 0, length);
        return bytes;
     }
     else if (mClient)
     {
        Method mth  = getInvokeDomainMethod();
        try
        {
           if (mIndexString == null) 
           {
              //simply write the absolute index : rowindex[.structindex]*
              getRemoteIdString();
           }
           return (byte[])mth.invoke(xAct, new Object[] {
                             getOwnerRow(),
                             mIndexString, 
                             Boolean.FALSE, 
                             "getBytes", 
                             new String[] {Long.TYPE.getName(), Integer.TYPE.getName()},
                             new Object[] {new Long(offset), new Integer(length)}
                            });
        }
        catch (Exception e)
        {
           throw new JboException(e);
        }
     }
     else if (mylob != null) 
     {
        return readBytesFromLob(offset, length);
     }
     return null;
  }

  //abstract methods.
  byte[] readBytesFromLob(long offset, int length)
  {
     try
     {
        return mylob.getBytes(offset, length);
     }
     catch (SQLException sqle)
     {
        throw new JboException (sqle);
     }
  }

  void writeBytesToLob()
  {
     try
     {
        mylob.putBytes(1, mData.toByteArray());
        super.resetCachedData();
     }
     catch (SQLException sqle)
     {
        throw new JboException (sqle);
     }
  }

  OutputStream getInternalOutputStream()
  {
     try
     {
        return mylob.getBinaryOutputStream();
     }
     catch (SQLException sqle)
     {
        throw new JboException (sqle);
     }
  }

  InputStream getInternalStream()
  {
     try
     {
        return mylob.getBinaryStream();
     }
     catch (SQLException sqle)
     {
        throw new JboException (sqle);
     }
  }

  InputStream getInternalDataStream()
  {
     return new ByteArrayInputStream(mData.toByteArray());
  }

  void syncLob (Datum otherLob)
  {
     lob = mylob = (BLOB)otherLob;
  }

  public long getLength()
  {
     if (mClient)
     {
        return super.getRemoteLength();
     }
     
     if (!mDataModified && mylob != null) 
     {
        try
        {
           return mylob.length();
        }
        catch (SQLException sqle)
        {
           Diagnostic.println("Warning : SQLException during BlobDomain.getLength()");
        }
     }

     if (mData != null) 
     {
        return mData.size();
     }
     return 0;
  }
  
  public int getBufferSize() 
  {
     if (mClient)
     {
        return super.getRemoteBufferSize();
     }
     
     if (!mDataModified && mylob != null) 
     {
        try
        {
           return mylob.getBufferSize();
        }
        catch (SQLException sqle)
        {
           Diagnostic.println("Warning : SQLException during BlobDomain.getLength()");
        }
     }

     if (mData != null) 
     {
        return mData.size();
     }
     return 0;
  }
  
  /*
   private ByteArrayOutputStream dumpBlob (BLOB blob) 
   {

      //oracle.jbo.server.DBTransactionImpl xact = txn;
      //need this for flush/close
      try
      {
         mData = new ByteArrayOutputStream();
         byte[] buf;
         try
         {
            int index = 0;
            int chunk = 31 * 1024;
            do
            {
               buf = blob.getBytes(index+1, chunk);
               if (buf == null) 
               {
                  break;
               }
               mData.write(buf, 0, buf.length);
               index += buf.length;
            } while(buf.length == chunk);
         }
         catch (NullPointerException ioe)
         {
            //ignore null pointer exception as that;s
            //thrown when blob is done reading.
         }
         mData.flush();
         mData.close();
      }
      catch (Exception sqle)
      {
         new JboException (sqle);
      }
      
      return mData;
   }

   private ByteArrayOutputStream dumpBlob (InputStream in) 
   {

      //oracle.jbo.server.DBTransactionImpl xact = txn;
      //need this for flush/close
      try
      {
         mData = new ByteArrayOutputStream();
         try
         {
            int index = 0;
            int chunk = 31 * 1024;
            byte[] buf = new byte[chunk];
            do
            {
               chunk = in.read(buf, 0, chunk);
               mData.write(buf, 0, chunk);
            } while(buf.length == chunk);
         }
         catch (NullPointerException ioe)
         {
            //ignore null pointer exception as that;s
            //thrown when blob is done reading.
         }
         mData.flush();
         in.close();
         mData.close();
      }
      catch (Exception sqle)
      {
         new JboException (sqle);
      }
      
      return mData;
   }

  */


  public int getBytes(long pos, int length, byte[] buf)
  {
    //if(mylob == null)
    //  throw new JboException("BlobDomain is not initialized.");

    if (mClient)
    {
       byte [] bytes = getBytes(pos, length);
       if (bytes != null) 
       {
          length = bytes.length;
          System.arraycopy(bytes, 0, buf, 0, length);
          return length;
       }
       return 0;
    }
    else
    {
      try
      {
         return mylob.getBytes(pos, length, buf);
      }
      catch (SQLException sqle)
      {
         throw new JboException(sqle);
      }
    }
  }             
  /*
   * Share the same interfaces with ClobDomain, should not use it in the 
   * BlobDomain.
   */
  
  
  public java.io.Writer getCharacterOutputStream()
  {
    return new OutputStreamWriter(getOutputStream());
  }
  
  public void closeCharacterOutputStream()
  {
    closeOutputStream();
  }
}




