package oracle.jbo.domain;

import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.TIMESTAMP;    
import java.sql.SQLException;
import java.io.IOException;
import java.io.Serializable;

import oracle.jbo.Transaction;

// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: TimestampDomain
// ---------------------------------------------------

/**
* This class extends <tt>oracle.sql.TIMESTAMP</tt>,
* Oracle's Java representation of the
* TIMESTAMP database type. This class allows an instance of the
* <tt>oracle.sql.TIMESTAMP</tt> to be used as an immutable domain object.
* <p>
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <tt>oracle.sql</tt> class such that it returns an instance of an
* <tt>oracle.jbo.domain.*</tt> object.
* <p>
* The <tt>oracle.jbo.domain.Timestamp</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
* <p>
* <code>Timestamp</code> objects consist of data (a byte array)
* and a Domain type code.
* Domain dates extend SQL dates by being convertable to and from
* JDBC values.
* <h3>Timestamp/Time Formats Accepted</h3>
* The <tt>oracle.jbo.domain.Timestamp</tt> class accepts dates and times in the
* same format accepted by <tt>java.sql.TimeStamp</tt> (either a long milliseconds time value
* or the year, month, day, hour,
* minute, second, nano format) and <tt>java.sql.Timestamp</tt> (either a milliseconds time value
* or the year, month, day format).
* @since JDeveloper 3.0
 * 
 * @javabean.class name=Timestamp
 * 
*/
public class Timestamp
             extends oracle.sql.TIMESTAMP 
             implements DomainInterface, 
                        XMLDomainWriter,
                        KeyAttributeInterface,
                        CustomDatum,
                        Serializable 
{
  private static final long serialVersionUID = 5600076615126868258L;

  static CustomDatumFactory fac = null;
  static
  {

     TypeFactory.addCustomConverter(oracle.jbo.domain.Timestamp.class, java.lang.String.class, 
     new TypeConvMapEntry()
     {
         protected Object convert(Class toClass, Class valClass, Object val)
         {
             try
             {
                return new oracle.jbo.domain.Timestamp((String)val);
             }
             catch (Exception e)
             {
                //check for null/ String and 0 length.
                if (val instanceof String && ((String)val).trim().length() == 0)
                {
                   return null;
                }
                throw new DataCreationException(toClass.getName(), val, e);
             }
          }
     }
     );

  }
  private int mHashCode = 0;

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Timestamp</code> Domain.
    *
    * <p>This method is invoked when JBO is initialized.
    * Applications should not call this method directly.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Timestamp</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass implements DatumFactory
        {
            public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Timestamp(data) : null;
            }
            
            public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
            {
               byte[] data = jdbc.getBytes(index);
               return (data != null) ? new Timestamp(data) : null;
            }
         
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new Timestamp( d.getBytes());
               }
               return null;
            }
        };
        fac = new facClass();
     }
     return fac;
  }
  
  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Timestamp</code> Domain object back into an
    * SQL <code>TIMESTAMP</code> object.
    *
    * @param conn <code>OracleConnection</code> Not used.
    * @return A <code>Datum</code> containing <code>TIMESTAMP</code> object.
    * @throws <code>SQLException</code> Never.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new TIMESTAMP(getBytes());
  }
  
  /**
    * Creates a default <code>Timestamp</code> Domain object.
    *
    * <p>This constructor does not create a null date:
    * use one of the <code>NullValue()</code> constructors.
    */
  public Timestamp() {
     super();
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Creates a <code>Timestamp</code> Domain object from the given byte array.
    *
    * @param value a value returned by a previous call to
    * <code>getBytes()</code> on an SQL object compatable with
    * <code>Timestamp</code>.
    */
  public Timestamp(byte[] value) {
     super(value);
  }             

  public Timestamp(Date value)
  {
     setBytes(new TIMESTAMP(value.timestampValue()).getBytes());
  }

  /**
    * Creates a <code>Timestamp</code> Domain object from an Oracle SQL
    * <code>TIMESTAMP</code>.
    *
    * @param value a <code>TIMESTAMP</code> SQL object.
     */
  public Timestamp(TIMESTAMP value) {
     super(value.getBytes());
  }             

  /**
    * Creates a <code>Timestamp</code> identical to an
    * existing <code>Timestamp</code>.
    *
    * @param value a <code>Timestamp</code> Domain object.
    */
  public Timestamp(Timestamp value) {
     super(value.getBytes());
  }

  /**
    * Creates a <code>Timestamp</code> Domain object from a JDBC
    * <code>Timestamp</code>.
    *
    * @param value a <code>TIMESTAMP</code> SQL object.
     */
  public Timestamp(java.sql.Timestamp value) {
     super(value);
  }        

  /**
    * Creates a <code>Timestamp</code> Domain object from a long
    * <code>Timestamp</code> value. Uses java.sql.Timestamp(long)
    * to create this domain instance. This value should usually
    * be the value returned from System.currentTimeMillis()
    * or from Timestamp.getTime() method
    */
  public Timestamp(long value) {
     super(new java.sql.Timestamp(value));
  }             

  /**
    * Creates a <code>Timestamp</code> Domain object from a JDBC
    * <code>java.sql.Date</code> object.
    *
    * @param value a <code>Time</code> SQL object.
     */
  public Timestamp(java.sql.Date value) {
     super(value);
  }             

  /**
    * Creates a <code>Timestamp</code> Domain object from a JDBC
    * <code>java.util.Date</code> object.
    *
    * @param value a <code>TimeStamp</code> SQL object.
     */
  public Timestamp(java.util.Date value) {
     super(new java.sql.Timestamp(value.getTime()));
  }             

  /**
    * Creates a <code>Timestamp</code> Domain object from a
    * JDBC <code>Object</code>.
    *
    * @param   value   an <code>Object</code> that is an instance of
    * <code>Timestamp</code>,
    * <code>Time</code>, <code>Timestamp</code>, or
    * <code>String</code>.
    * @throws  SQLException if the object is not of one of the recognized classes.
    */
  //public Timestamp(Object value) throws SQLException {
  //   if (value instanceof String)
  //   {
  //      setBytes(toTimestamp((String)value).getBytes());
  //   }
  //   else
  //   {
  //      setBytes((new TIMESTAMP(value)).getBytes());
  //   }
  //}             
  
  /**
    * Creates a <code>Timestamp</code> Domain object from a
    * Java <code>String</code>.
    *
    * @param   value   a textual representation of a <code>Timestamp</code>.
    */
  public Timestamp(String value) {
     setBytes(toTimestamp(value).toBytes());
          
  } 

  /**
   * Returns the time as a long value using timestampValue().getTime().
   **/
  public long getTime()
  {
     try
     {
        return timestampValue().getTime();
     }
     catch (java.sql.SQLException sqle)
     {
        throw new oracle.jbo.JboException(sqle);
     }
  }

  /**
   * Return a java.sql.Timestamp object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
   * 
  * @javabean.property 
   */
  public java.sql.Timestamp getValue()
  {
     return (java.sql.Timestamp)getData();
  }

  /**
     * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    *
    * @value The JDBC representation of <code>this</code>,
    */
  public Object getData() {
     try
     {
        return timestampValue();
     }
     catch (SQLException e)
     {
        throw new oracle.jbo.JboException(e);
     }
  }

  /**
   * Convert to a Date representation of the Timestamp object
   * 
   * @return java.sql.Date representation of the Timestamp object
   * @exception SQLException, if no Date representation exists
   */
  public java.sql.Date dateValue() throws SQLException
  {
     return new java.sql.Date(timestampValue().getTime());
  }

  /**
   * <b>Internal:</b> <em>Applications should not invoke this method.</em>
   */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }

  /**
   * Converts an Oracle Timestamp expressed as a string to a Java Timestamp. The Java
   * date can be either an <tt>java.sql.Timestamp</tt> or an <tt>java.sql.Timestamp</tt>.
   * @return returns a <tt>java.sql.Timestamp</tt> object.
   */
  public static Timestamp toTimestamp(String value)
  {
     TIMESTAMP dt;
     value = value.trim();
     try
     {
        //this would try timestamp format.
        dt = new TIMESTAMP(value);
     }
     catch(Exception e)
     {
        java.sql.Timestamp javaObj = java.sql.Timestamp.valueOf(value);
        dt = new TIMESTAMP(javaObj);
     }

     return new Timestamp(dt);
  }

  /**
    * For testing purposes only: converts <code>this</code> to a textual
    * representation.
    */
  public String toString() {
     Object ts = getData();
     if( ts != null  )
     {
        return ts.toString();
     }
     return null;
  }

  /**
    * Tests <code>this</code> for equality with another object.
    *
    * The argument is converted to a <code>Timestamp</code> object, if necessary.
    *
    * @param other  an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (other == null)
     {
        return false;
     }

     if (!other.getClass().equals(getClass()))
     {
        Timestamp charOther;
        try
        {
           if (other instanceof String)
           {
              charOther = new Timestamp((String)other);
           }
           else if (other instanceof java.sql.Timestamp)
           {
              charOther = new Timestamp((java.sql.Timestamp)other);
           }
           else if (other instanceof java.util.Date)
           {
              charOther = new Timestamp((java.util.Date)other);
           }
           else if (other instanceof Date)
           {
              charOther = new Timestamp((Date)other);
           }
           else
           {
              return false;
           }
        }
        catch( Exception sqle )
        {
           //for any exception simply return false from equals.
           return false;
        }
        return super.equals(charOther);
     }
     return super.equals(other);
  }

  /*
  public boolean equals( Object obj )
  {
     if( obj instanceof Timestamp )
     {
        return (compareTo((TIMESTAMP)obj) == 0);
     }
     return false;
  }
  */

  /**
    * Computes a hash code for <code>this</code>.
    *
    * @return the hash code of <code>this</code>.
    */
   public int hashCode()
   {
      if (mHashCode == 0)
      {
         mHashCode = getData().hashCode();
         if (mHashCode == 0)
         {
            mHashCode = -6234;
         }
      }
      return mHashCode;
   }

  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
     byte[] bytes = getBytes();
     out.writeInt(bytes.length);
     out.write(bytes);
  }

  private void readObject(java.io.ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
     int size = in.readInt();
     byte[] bytes = new byte[size];
     in.read(bytes);
     setBytes(bytes);
  }


   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   public String printXMLDefinition(java.util.Hashtable allDefs, java.io.PrintWriter pw, 
                             boolean bContainees)
   {
      return "#PCDATA";
   }

  /**
  * Creates the xml node in the given xml document for this domain's data.
  * @param xmlDoc name of the XML document in which the node should be created.
  **/
  public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc)
  {
     return xmlDoc.createTextNode(toString());
  }

  /**
  * Creates the xml node in the given xml document for this domain's data in hex format of the byte[]
  * representation of the data.
  * @param xmlDoc name of the XML document in which the node should be created.
  **/
  public org.w3c.dom.Node getSerializedDomainXML(org.w3c.dom.Document xmlDoc)
  {
     //for now render as String. If we find that this leads to NLS issues, we should
     //revert back to the RepConversion solution.
     return xmlDoc.createTextNode(toString());
     //return xmlDoc.createTextNode(oracle.jbo.common.RepConversion.bArray2String(getBytes()));
  }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainReaderFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainReaderFactory, XMLDomainFactory
      {
         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element attrElem)
         {
            try
            {
               org.w3c.dom.Node valNode = (org.w3c.dom.Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     //get the properly typed-attribute value 
                     return new Timestamp(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
         
         public Object createDomainFromSerializedXML(org.w3c.dom.Element attrElem)
         {
            try
            {
               org.w3c.dom.Node valNode = (org.w3c.dom.Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     //for now render as String. If we find that this leads to NLS issues, we should
                     //revert back to the RepConversion solution.
                     //return new Timestamp(oracle.jbo.common.RepConversion.convertHexStringToByte(attrValue));
                     return new Timestamp(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
      }
      
      return new facClass();
   }
}



 
