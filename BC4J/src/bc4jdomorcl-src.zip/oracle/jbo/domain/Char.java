package oracle.jbo.domain;

import oracle.sql.CHAR;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.CharacterSet;
import java.sql.SQLException;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.io.IOException;
import java.io.Serializable;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.SvcMsgResponseValues;
import oracle.jbo.Transaction;
import oracle.svcmsg.ResponseValues;


/*
class CharMarshaller implements oracle.jbo.common.ObjectMarshaller
{
   public Object marshal(Object obj)
   {
      if (obj instanceof Char)
      {
         return new SvcMsgResponseValues(SvcMsgResponseValues.RES_GET_CHAR_DOMAIN_VALUE, null).setObjectValues(new Object[] { ((Char) obj).toString() });
      }

      return null;
   }
   
   public Object unMarshal(Object obj)
   {
      if (obj instanceof SvcMsgResponseValues)
      {
         if (((SvcMsgResponseValues) obj).getOperation() == SvcMsgResponseValues.RES_GET_CHAR_DOMAIN_VALUE)
         {
            try
            {
               return new Char((String) ((SvcMsgResponseValues) obj).getObjectValues()[0]);
            }
            catch(Exception ex)
            {
               throw new DataCreationException(Char.class.getName(), obj, ex);
            }
         }
      }

      return null;
   }
   
   public boolean isCustomMarshalled(Object obj)
   {
      return obj instanceof Char;
   }
   
   public String getMarshalledTypeName(Object obj)
   {
      return null;
   }
   
   public void finishedPiggybacking()
   {
   }
}
*/


// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.CHAR</tt>,
* the Java representation of the
* CHAR database type. This wrapper allows an instance of the
* <tt>oracle.sql.CHAR</tt> to be used as an immutable Domain object.
* <p>
* The intent of many of the methods in this class is to wrap the corresponding
* method in the <tt>oracle.sql</tt> class such that it returns an instance of an
* <tt>oracle.jbo.domain.*</tt> object.
* <p>
* The <tt>oracle.jbo.domain.CHAR</tt> class is the Java representation
* of the underlying
* database type that you must use if you want to exploit the domain feature of
* Business Components for Java.
*
* @since JDeveloper 3.0
 * 
 * 
 * @javabean.class name=Char
*/
public class Char
             extends oracle.sql.CHAR
             implements DomainInterface, 
                        KeyAttributeInterface,
                        CustomDatum,
                        Serializable,
                        MarshalledDomain
{
/*
  static
  {
     oracle.jbo.common.TypeMarshaller.addCustomMarshaller(new CharMarshaller());
  }
*/
  
  private int mHashCode = 0;
  private static final long serialVersionUID = -5720324827729458337L;  

  static CustomDatumFactory fac = null;

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Initializes the <code>Char</code> Domain.
    *
    * <p>This method is invoked when Business Components for Java is initialized.
    * Applications should not call this method directly.
    *
    * @return the <code>CustomDatumFactory</code> for the
    * <code>Char</code> Domain.
    */
  public static CustomDatumFactory getCustomDatumFactory()
  {
     if( fac == null )
     {
        class facClass implements DatumFactory
        {
            public Datum createDatum(java.sql.CallableStatement jdbc, int index)
               throws SQLException
            {
               CHAR ch = ((oracle.jdbc.OracleCallableStatement)jdbc).getCHAR(index);
               return new Char(ch.shareBytes(), ch.getCharacterSet());
/*
               byte[] data = jdbc.getBytes(index);
               //System.out.println("-------------->statement");

               // conversion field no longer accessible 
               // in the 10g connection implementation which 
               // causes the build to fail. 
               // Use default CharacterSet until that 
               // gets resolved. 
               // -dm 4/13/2004
               /*
               return (data != null) 
                            ? new Char(data, ((oracle.jdbc.driver.OracleConnection)
                                              ((oracle.jdbc.driver.OracleStatement)jdbc)
                                                .getConnection()).
                                             conversion.getAccessCharSetObj()) 
                            : null;
*/
            }
            
            public Datum createDatum(java.sql.ResultSet jdbc, int index)
               throws SQLException
            {
               
               try
               {
                  CHAR ch = ((oracle.jdbc.OracleResultSet)jdbc).getCHAR(index);
                  return (ch != null) ? new Char(ch.shareBytes(), ch.getCharacterSet()) : null;
               }
               catch (java.sql.SQLException sqle)
               {
                  //getCHAR fails in jdbc 10.1.0 for non-varchar2 columns. 
                  return new Char(((oracle.jdbc.OracleResultSet)jdbc).getString(index));
               }
/*
               byte[] data = jdbc.getBytes(index);
               //System.out.println("-------------->resultset");
               /*
               // conversion field no longer accessible 
               // in the 10g connection implementation which 
               // causes the build to fail. 
               // Use default CharacterSet until that 
               // gets resolved. 
               // -dm 4/13/2004
               
               return (data != null) 
                            ? new Char(data, ((oracle.jdbc.driver.OracleConnection)  
                                              ((oracle.jdbc.driver.OracleStatement)
                                                ((oracle.jdbc.driver.OracleResultSet)jdbc)
                                                 .getStatement())
                                                 .getConnection()).
                                             conversion.getAccessCharSetObj())
                            : null;
*/            
            }
            
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if( d instanceof CHAR )
               {
                  return new Char((CHAR)d);
               }
               if ( d != null )
               {
                  return new Char( d.getBytes(), CharacterSet.make(CharacterSet.DEFAULT_CHARSET));
               }
               return null;
            }
        }
        fac = new facClass();
     }
     return fac;
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Converts this <code>Char</code> Domain object back into an
    * SQL <code>CHAR</code> object.
    *
    * @return A <code>Datum</code> containing <code>CHAR</code> object.
    * @throws <code>SQLException</code>.
    */
  public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
  {
     return new CHAR(getBytes(), getCharacterSet());
  }

  /**
    * Creates a <code>Char</code> Domain object representing the null string.
    *
    * <p>This constructor does not create a null object:
    * use one of the {@link oracle.jbo.domain.NullValue} objects to indicate <tt>null</tt>.
    * @throws <code>SQLException</code> if the empty string is not defined as a
    * character in <code>DEFAULT_CHARSET</code>.
    */
  public Char() throws SQLException
  {
     super("",  CharacterSet.make(CharacterSet.DEFAULT_CHARSET));
  }
  
  /**
    * Creates a <code>Char</code> identical to an
    * existing <code>Char</code>.
    *
    * @param val a <code>Char</code> Domain object.
    * @throws  SQLException never.
    */
  public Char(Char val) throws SQLException {
     super( val, val.getCharacterSet());
  }
  
  /**
    * Creates a <code>Char</code> Domain object from a SQL
    * <code>CHAR</code>.
    *
    * @param val a <code>CHAR</code> SQL object.
    * @throws  SQLException never.
    */
  public Char(CHAR val) throws SQLException {
     super( val.getBytes(), val.getCharacterSet());
     //setValue(val.getBytes(), val.getCharacterSet());
     //super(val);
  }
  
  /**
    * Creates a <code>Char</code> Domain object from a <code>String</code>.
    *
    * @param val  A unicode string interpreted as a
    * <code>DEFAULT_CHARSET</code> string.
    * @throws <code>SQLException</code> if <code>val</code> does not
    * represent a character.
    */
  public Char(String val) throws SQLException {
     super( val, CharacterSet.make(CharacterSet.DEFAULT_CHARSET));
  }
  
  /**
    * Creates a <code>Char</code> Domain object from an <code>Object</code>.
    *
    * @param val  An object that will be converted using <code>toString()</code>
    * into a <code>DEFAULT_CHARSET</code> string.
    * @throws <code>SQLException</code> if the string does not represent a
    * character.
    */
  public Char(Object val) throws SQLException {
     super( val, CharacterSet.make(CharacterSet.DEFAULT_CHARSET));
  }
  
  /**
    *
    * <p>Creates a <code>Char</code> Domain object from a byte array representing
    * a string of a given character set.
    *
    * <p>No validation is performed.
    *
    * @param val  A byte array representing a <code>charset</code> string.
    * @param charset  An Oracle character set.
    */
  public Char(byte[] val, CharacterSet charset) {
     super(val, charset);
     //setValue(val, charset);
  }

  /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>Creates a <code>Char</code> Domain object from a range of a byte array
    * representing a string of a given character set.
    *
    * <p>No validation is performed.
    *
    * @param val  A byte array representing a <code>charset</code> string.
    * @param p1  The index of the first byte in the range.
    * @param p2  The number of bytes in the range.
    * @param charset  An Oracle character set.
    */
  public Char(byte[] val, int p1, int p2, CharacterSet charset) {
     super(val, charset);
  }                               

  /**
    * Creates a <code>Char</code> Domain object from a <code>String</code>
    * interpreted as a string of a given character set.
    *
    * @param val  A unicode string interpreted as a
    * <code>charset</code> string.
    * @param charset  An Oracle character set.
    * @throws <code>SQLException</code> if <code>val</code> does not
    * represent a character.
    */
  public Char(String val, CharacterSet charset) throws SQLException {
     super(val, charset);
  }                               

  /**
    * Creates a <code>Char</code> Domain object from an <code>Object</code>
    * interpreted as a string of a given character set.
    *
    * @param val  An object that will be converted using <code>toString()</code>
    * into a <code>charset</code> string.
    * @param charset  An Oracle character set.
    * @throws <code>SQLException</code> if the string does not represent a
    * character.
    */
  public Char(Object val, CharacterSet charset) throws SQLException {
     super(val, charset);
  }                               
  
  public Char(ResponseValues respVals)
     throws SQLException
  {
     this((String) respVals.getObjectValues()[1]);
  }

  /**
   * Return a java.lang.String object with this domain's value.
   * This method may be used to access the value for this domain in EL-expressions.
   * 
  * @javabean.property 
   */
  public String getValue()
  {
     return (String)getData();
  }


  /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    */
  public Object getData() {
     try
     {
        return toJdbc();
     }
     catch( Exception e )
     {
        Diagnostic.printStackTrace(e);
     }
     return null;
  }
    /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     */
  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }

/**
    * Computes a hash code for <code>this</code> CharDomain object.
    * The Domain type is ignored.
    * @return the hash code of <code>this</code> CharDomain object.
    */
   public int hashCode()
   {
      if (mHashCode == 0)
      {
         mHashCode = toString().hashCode();
         if (mHashCode == 0)
         {
            mHashCode = -6857;
         }
      }
      return mHashCode;
   }

   /**
    * Tests <code>this</code> for equality with another object. 
    * Since JDeveloper 9.0.2, this method will also compare Char objects of different
    * CharacterSets by converting the two CharacterSets into a common characterset if 
    * required, so as to compare and return the actual string differences. 
    * <p>
    * Note that oracle.sql.CHAR does not perform such conversion before comparision. 
    * In Oracle9i database charset may be different from the charset of a client machine and 
    * that leads to different charsets in the CHAR object.
    *
    * @param other  An arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
  public boolean equals(Object other) {
     if (other == null) 
     {
        return false;
     }
     if (!other.getClass().equals(getClass()))
     {
        try
        {
           Char charOther = new Char(other.toString(), this.getCharacterSet());
           return super.equals(charOther);
        }
        catch( Exception sqle )
        {
           return false;
        }
     }
     CharacterSet set = this.getCharacterSet();
     CHAR otherChar = (CHAR)other;
     if (!otherChar.getCharacterSet().equals(set)) 
     {
        byte[] bytes = otherChar.getBytes();
        try
        {
           return (new Char(set.convert(otherChar.getCharacterSet(), bytes, 0, bytes.length), set)).equals(this);
        }
        catch (Exception sqle)
        {
           return false;
        }
     }

     return super.equals(other);
  }          

   
  //------------------------------------------------------------------------
  //
  // Test Methods
  //
  //------------------------------------------------------------------------

   /**
    * <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>For testing purposes only.
    */
  public static void main(
    String[]       argv
    )
    throws SQLException
  {
    System.out.println("Char Test BEGIN");

    //
    // String and byte test.
    //
    /*
    System.out.println("  String and Byte Test ...");

    CHAR        c = new CHAR("abc", null);
    int         x = c.getCharacterSet().getOracleId();
    String      s = c.stringValue();

    c = new CHAR(s.getBytes(), CharacterSet.make(x));

    System.out.println("  Expecting \"abc\": " + c.stringValue());
    */

    //
    // Simple conversion test.
    //
    System.out.println("  Simple Conversion Test ...");

    try
    {
      Integer     my_num = new Integer(123);
      Char        my_CHAR = new Char(my_num,
                    CharacterSet.make(CharacterSet.UNICODE_2_CHARSET));

      System.out.print("  String value (expect 123): ");
      if (my_CHAR.isConvertibleTo(Class.forName("java.lang.String")) == true)
      {
        System.out.println(my_CHAR.stringValue());
      }
      else
      {
        System.out.println("failed");
      }

      System.out.print("  Long value   (expect 123): ");
      if (my_CHAR.isConvertibleTo(Class.forName("java.lang.Long")) == true)
      {
        System.out.println(my_CHAR.longValue());
      }
      else
      {
        System.out.println("failed");
      }

      if(my_CHAR.isConvertibleTo(Class.forName("java.lang.Integer")) == true)
      {
        System.out.println("  You should never see this string !!!");
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    //
    // Test end.
    //
    System.out.println("CHAR Test END");
  }

  
   public ResponseValues marshal()
   {
      return new SvcMsgResponseValues(SvcMsgResponseValues.RES_MARSHALLED_DOMAIN_VALUE, null)
                    .setObjectValues(new Object[] { getClass().getName(), toString() });
   }

   
   private void writeObject(java.io.ObjectOutputStream out)
     throws IOException
   {
      byte[] bytes = getBytes();
      out.writeInt(bytes.length);
      out.write(bytes);
   }

   private void readObject(java.io.ObjectInputStream in)
     throws IOException, ClassNotFoundException
   {
      int size = in.readInt();
      byte[] bytes = new byte[size];
      in.read(bytes);
      setBytes(bytes);
   }

   /**
    * Tests whether this data object can be converted to the specified
    * Java data type.
    *
    * @param         jClass
    *                specifies the Java data type to test against.
    *
    * @return        true if this data object is convertible to the
    *                specified Java class, and a corresponding xxxValue()
    *                method is available; otherwise, a false is returned.
    */
   public boolean isConvertibleTo(
     Class           jClass
     )
   {
     String      cls_name = jClass.getName();
 
     if ((cls_name.compareTo("java.lang.Integer")    == 0) || 
         (cls_name.compareTo("java.lang.Long")       == 0) || 
         (cls_name.compareTo("java.lang.Float")      == 0) || 
         (cls_name.compareTo("java.lang.Double")     == 0) || 
         (cls_name.compareTo("java.math.BigInteger") == 0) || 
         (cls_name.compareTo("java.math.BigDecimal") == 0) || 
         (cls_name.compareTo("java.lang.String")     == 0) ||
         (cls_name.compareTo("java.lang.Boolean")    == 0))
     {
       return true;
     }
     else
     {
       return false;
     }
   }
 
   /**
    * Convert this data object into a int.
    *
    * @return        the data value in int representation.
    */
   public int intValue()
   {
      try
      {
         return super.bigDecimalValue().intValue();
      }
      catch (SQLException sqle)
      {
         throw new GenericDomainException("Char.intValue", this, sqle);
      }
   }

   /**
    * Converts this data object into a <tt>long</tt>.
    *
    * @return        the data value in long representation.
    */
   public long longValue()
   {
      try
      {
         return super.bigDecimalValue().longValue();
      }
      catch (SQLException sqle)
      {
         throw new GenericDomainException("Char.longValue", this, sqle);
      }
   }
 
 
   /**
    * Converts this data object into a float.
    *
    * @return        the data value in float representation.
    */
   public float floatValue()
   {
      try
      {
         return super.bigDecimalValue().floatValue();
      }
      catch (SQLException sqle)
      {
         throw new GenericDomainException("Char.floatValue", this, sqle);
      }
   }
 
   /**
    * Converts this data object into a double.
    *
    * @return        the data value in double representation.
    */
   public double doubleValue()
   {
      try
      {
         return super.bigDecimalValue().doubleValue();
      }
      catch (SQLException sqle)
      {
         throw new GenericDomainException("Char.doubleValue", this, sqle);
      }
   }
 
   /**
    * Converts this data object into a BigInteger.
    *
    * @return        the data value in BigInteger representation.
    */
   public BigInteger bigIntegerValue()
   {
      try
      {
         return super.bigDecimalValue().toBigInteger();
      }
      catch (SQLException sqle)
      {
         throw new GenericDomainException("Char.bigIntegerValue", this, sqle);
      }
   }
   
   /**
    * Converts this data object into a boolean.
    *
    * @return        the data value in boolean representation.
    */
   public boolean booleanValue()
   {
      return new Boolean(stringValue()).booleanValue();
   }
 
  /**
   * Calls <tt>CHAR.bigDecimalValue()</tt> to convert this object into a Java
   * <tt>BigDecimal</tt>.
   *
   * @return   a Java BigDecimal value
   */
  public BigDecimal bigDecimalValue()
  {
     try
     {
        return super.bigDecimalValue();
     }
     catch (SQLException sqle)
     {
        throw new GenericDomainException("Char.bigDecimalValue", this, sqle);
     }
  } // bigDecimalValue()

}



 
