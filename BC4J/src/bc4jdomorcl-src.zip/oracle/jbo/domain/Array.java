
package oracle.jbo.domain;


import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;
import java.lang.reflect.Method;
import com.sun.java.util.collections.HashMap; 

import oracle.jdbc.OracleTypes;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.ArrayDescriptor;

import oracle.jbo.Transaction;
import oracle.jbo.AttributeList;
import oracle.jbo.common.JboXMLUtil;
import oracle.jbo.common.TypeMarshaller;
import oracle.jbo.common.Diagnostic;
import oracle.svcmsg.ResponseValues;

import org.w3c.dom.Node;
import oracle.xml.parser.v2.XMLElement;

/**
* This class provides a lightweight wrapper for <tt>oracle.sql.ARRAY</tt>,
* the Java representation of the
* ARRAY database type. This wrapper allows an instance of the
* <tt>oracle.sql.ARRAY</tt> to be used as an immutable Domain object.
* This class also provides a wrapper for the data that comes from
* nested tables and nested arrays.
 * 
*  @since JDeveloper 3.0
 * @javabean.class name=Array
 * 
*/
public class Array implements LobInterface, 
                              DomainOwnerInterface,
                              XMLDomainInterface,
                              CustomDatum,
                              Serializable,
                              MarshalledDomain
{
   transient boolean mNotInitElemXMLFactory = true;
   transient Datum mData;
   Object[] mElemData;
   boolean mFetchedElemData = false;
   transient CustomDatumFactory mElemFactory;
   Class mElemType;
   
   /**
   * Index of the attribute in the domain owner's container.
   */
   protected int mOwnerAttrIndex = -1;

   XMLDomainFactory mElemXMLFactory;
   Transaction mTrans;
   DomainOwnerInterface mOwner;
   String mSqlTypeName;

   static CustomDatumFactory fac = null;

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static CustomDatumFactory getCustomDatumFactory()
   {
      if( fac == null )
      {
         class facClass implements CustomDatumFactory
         {
            public CustomDatum create(Datum d, int sql_type_code) throws SQLException
            {
               if (d != null)
               {
                  return new Array(d);
               }
               return null;
            }
         }  ;
         fac = new facClass();
      }
      return fac;
   }

   /**
   * Constructs an instance of this class.
   */
   protected Array()
      throws SQLException
   {
   }

   /**
    * This constructor does not verify that this array's length w.r.t the corresponding
    * database/source description. Length validation is performed when this array is 
    * set into a Bc4J row as an attribute.
    */
   public Array(Object[] elements)
   {
      mElemData = elements;
      mFetchedElemData = true;
      
      // Set the type to the Class of the first non null element in the Array
      for(int i = 0; i < elements.length; i++)
      {
         if (elements[i] != null)
         {
            mElemType = elements[i].getClass();
            break;
         }
      }
      // If the array contains zero elements or all null elements
      // set the type to the generic Object
      if (mElemType == null)
         mElemType = java.lang.Object.class;
   }

   /**
    * This constructor does not verify that this array's length w.r.t the corresponding
    * database/source description. Length validation is performed when this array is 
    * set into a Bc4J row as an attribute.
    */
   public Array(List list)
   {
      this(list.toArray());
   }


   /**
   * <b>Internal:</b> <em>Applications should not use this constructor.</em>
   */
   public Array(ArrayDescriptor type, Connection conn, Object elements)
      throws SQLException
   {
      mData = new oracle.sql.ARRAY(type, conn, elements);
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this constructor.</em>
   */
   public Array(ArrayDescriptor descriptor, Connection conn, byte[] bytes)
      throws SQLException 
   {
      mData = new oracle.sql.ARRAY(descriptor, conn, bytes);
   }

    /**
   * <b>Internal:</b> <em>Applications should not use this constructor.</em>
   */
   public Array(Datum d)
      throws SQLException
   {
      mData = d;
   }

   /**
    * If this array's element Type is not already set, use the given
    * class as the element Type for this array.
    */
   public void useElementType(Class claz)
   {
      if (mElemType != null)
      {
         mElemType = claz;
      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public Datum toDatum(oracle.jdbc.driver.OracleConnection conn) throws SQLException
   {
      return mData;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public Object getData()
   {
      return mData;
   }

   /**
   * Notification method that this domain calls whenever any of its
   * attribute values are about
   * to be modified. This Domain should always notify its owner.
   * @param d the domain being modified.
   */
   public void domainToBeModified(DomainInterface d)
   {
      if (mOwner != null)
      {
         mOwner.domainToBeModified(d);
      }
      if (mOwner instanceof AttributeList && mOwnerAttrIndex > -1) 
      {
         //this may be too slow, but hey, we need to perform attribute validations
         //on the domain once any attribute on it are changed somewhere.
         ((AttributeList)mOwner).setAttribute(mOwnerAttrIndex, this);

      }
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
      mOwner = owner;
      HashMap context = (HashMap)ctx;
      if (context.containsKey(DomainContext.ELEMENT_TYPE)) 
      {
         mElemType = (Class)context.get(DomainContext.ELEMENT_TYPE);
      }
      if (context.containsKey(DomainContext.ELEMENT_FACTORY)) 
      {
         mElemFactory = (CustomDatumFactory) context.get(DomainContext.ELEMENT_FACTORY);
      }
      if (context.containsKey(DomainContext.ELEMENT_SQL_NAME)) 
      {
         mSqlTypeName = (String)context.get(DomainContext.ELEMENT_SQL_NAME); 
      }
      if (context.containsKey(DomainContext.RELATIVE_INDEX)) 
      {
         mOwnerAttrIndex = ((Integer)context.get(DomainContext.RELATIVE_INDEX)).intValue();
      }
      mTrans = trans;
   }

   public String getRemoteIdString()
   {
      return null;
   }

   /**
   * Returns the elements of this array into an Object array. The elements
   * are converted to the Java types corresponding to the SQL type of the
   * data in the original array.
   * @return an Object array that contains the array elements.
   * @javabean.property 
   */
   public Object[] getArray()
   {
      //make sure internal array is realized.
      getInternalArray();

      Object[] arr = new Object[mElemData.length];
      System.arraycopy(mElemData, 0, arr, 0, mElemData.length);
      return arr;
   }

   /**
   * Returns the elements of this array in a List object. The elements
   * are converted to the Java types corresponding to the SQL type of the
   * data in the original array.
   * @return a List that contains the array elements.
   * @javabean.property 
   */
   public List getList()
   {
      //make sure internal array is realized.
      getInternalArray();

      java.util.ArrayList arr = new java.util.ArrayList();
      for (int i = 0; i < mElemData.length; i++)
      {
         arr.add(mElemData[i]);
      }

      return arr;
   }


   /*
   * Returns the internal array that contains the elements. 
   * Note : Applications should not modify the contents of this array directly.
   * That may lead to failure when posting this data back into the database.
   * To mutate the elements of this array, get a copy of the elements using
   * getArray() method and mutate that array and set it back into the attribute
   * that owns this array.
   */
   public Object[] getInternalArray()
   {
      if (!mFetchedElemData && mData != null)
      {
         try
         {
            Object[] oraData = (Object[]) ((oracle.sql.ARRAY)mData).getOracleArray();
            HashMap ctx = new HashMap(3);
            ctx.put(DomainContext.VARRAY_ELEMENT, "1");
            ctx.put(DomainContext.RELATIVE_INDEX, new Integer(-1));
            mElemData = new Object[oraData.length];

            if (mElemType == null)
            {
               //allow elements of any type, since none was established.
               mElemType = java.lang.Object.class;
               Diagnostic.println("Warning:No element type set on this array. Assuming java.lang.Object.");
            }

            if (mElemFactory == null)
            {
               for (int j = 0; j < oraData.length; j++)
               {
                  mElemData[j] = TypeFactory.getInstance(mElemType, oraData[j]);
                  if (mElemData[j] instanceof DomainInterface)
                  {
                     ((DomainInterface)mElemData[j]).setContext(this, mTrans, ctx);
                  }
               }
            }
            else
            {
               for (int j = 0; j < oraData.length; j++)
               {
                  mElemData[j] = mElemFactory.create((Datum) oraData[j], OracleTypes.STRUCT);
                  if (mElemData[j] instanceof DomainInterface)
                  {
                     ((DomainInterface)mElemData[j]).setContext(this, mTrans, ctx);
                  }
               }
            }
            mFetchedElemData = true;
         }
         catch(SQLException ex)
         {
            throw new GenericDomainException("Array.getArray", this, ex);
         }
      }
      return mElemData;
   }

    
   /**
    * Contents of this array should be of this type.
    */
   public Class getElemType()
   {
      return mElemType;
   }
    
    /**
    * Tests <code>this</code> for equality with another object.
    *
    * @param obj an arbitrary <code>Object</code>.
    * @return <code>true</code> if conversion was successful and the converted
    * argument is identical to <code>this</code>.
    */
   public boolean equals(Object obj)
   {
      if (obj instanceof Array)
      {
         Object[] vals = getArray();
         Array theOtherArray = (Array) obj;
         Object[] theOtherVals = theOtherArray.getArray();

         if (vals == null && theOtherVals == null)
         {
            return true;
         }

         if (vals == null || theOtherVals == null)
         {
            return false;
         }

         if (vals.length != theOtherVals.length)
         {
            return false;
         }

         for (int j = 0; j < vals.length; j++)
         {
            if (vals[j] == null)
            {
               if (theOtherVals[j] != null)
               {
                  return false;
               }
               else
               {
                  continue;
               }
            }
            
            if (!vals[j].equals(theOtherVals[j]))
            {
               return false;
            }
         }

         return true;
      }

      return false;
   }



   /**
   * Returns this class name as XML-element tag for this Array domain object.
   * Override this method to return a custom XML-element tag for this domain.
   **/
   protected String getXMLElementTag()
   {
      //in the generated code, we should always generate this method and return
      //hardcoded classname to avoid slow runtime performance due to calculation 
      //of the name.
      String className = this.getClass().getName();
      int index = className.lastIndexOf('.');
      if (index > 0) 
      {
         className = className.substring(index+1);
      }
      return className;
   }

   /**
   * Returns the classname of this domain, appended with the name of the 
   * attribute  as XML-element tag for this domain-attribute.
   * 
   * Override this method to return a custom XML-element tag for the given
   * attribute.
   **/
   protected String getElemXMLElementTag()
   {
      return getXMLElementTag()+"_Element";
   }

   /**
   * Returns false always.
   * Override to determine whether the given domain-attribute is 
   * to be rendered in CDATA format in xml.
   **/
   protected boolean isElemXMLCData()
   {
      return false;
   }
   
   /**
   * Creates the XML node in the given xml document for this domain's data.
   * @param xmlDoc the XML document in which the node is to be created.
   **/
   public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc)
   {
      String xmlName = getXMLElementTag();
      org.w3c.dom.Node e = xmlDoc.createElement(xmlName);
      org.w3c.dom.Node n;
      org.w3c.dom.Node c;

      Object[] arr = getArray();
      
      xmlName = getElemXMLElementTag();

      for (int i = 0; i < arr.length; i++)
      {
         c = DomainAttributeDef.getXMLContentNode(xmlDoc, arr[i], isElemXMLCData(), false);
         if (c != null) 
         {
            n = xmlDoc.createElement(xmlName);
            n.appendChild(c);
            e.appendChild(n);
         }
      }
      return e;
      
   }

   /**
   * Reads all the attribute values from the XML-element and sets them
   * into this row.
   * If the XML has a process instruction of the form:
   * &lt;?bc4j remove?&gt; then, invokes <tt>remove()</tt> on this row.
   * @param rowElt the XML element from which the attribute values should be read.
   **/
   protected void readAttrsFromXML(org.w3c.dom.Element rowElt)
   {

      Object value = null;
      org.w3c.dom.NodeList nl = rowElt.getElementsByTagName(getElemXMLElementTag());
      
      if (mNotInitElemXMLFactory && mElemXMLFactory == null) 
      {
         try
         {
            Method mth = mElemType.getMethod("getXMLDomainFactory", new Class[] {java.lang.Class.class});
            mElemXMLFactory = (XMLDomainFactory)mth.invoke(null, new Class[] {mElemType});
         }
         catch (Exception e)
         {
         }
      }
      //have atleast tried once so set this guy to true.
      mNotInitElemXMLFactory = false;
      mFetchedElemData = true;

      int size = nl.getLength();
      Object attrValue;
      if (size > 0)
      {
         mElemData = new Object[size];
         for (int i = 0; i < size; i++) 
         {
            value = null;
            if (mElemXMLFactory == null) 
            {
               XMLElement attrElem = (XMLElement)nl.item(i);
               Node valNode = JboXMLUtil.getFirstChildByType(attrElem, Node.TEXT_NODE);
               if (valNode == null)
               {
                  //try CDATA if Text node not found.
                  valNode = JboXMLUtil.getFirstChildByType(attrElem, Node.CDATA_SECTION_NODE);
               }

               if( valNode != null)
               {
                  attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     //get the properly typed-attribute value 
                     value = TypeFactory.getInstance(mElemType, attrValue);
                  }
               }
               else
               {
                  // if null == true, attrValue is null.
                  if (!attrElem.getAttribute("null").equalsIgnoreCase("true")) 
                  {
                     value = TypeFactory.getInstance(mElemType, "");
                  }
               }
            }
            else
            {
               value = (DomainInterface) mElemXMLFactory.createDomainFromXMLElement((org.w3c.dom.Element)nl.item(i));
            }
            mElemData[i] = value;
         }
      }
   }

   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   public String printXMLDefinition(Hashtable allDefs, PrintWriter pw, 
                             boolean bContainees)
   {
      String xmlTag = getXMLElementTag();

      if (allDefs.get(xmlTag) == null) 
      {
         StringBuffer elementStr = (new StringBuffer("<!ELEMENT ")
                                        .append(xmlTag)
                                        .append(" (")
                                   );

         String attrTag = getElemXMLElementTag();
         if (allDefs.get(attrTag) == null) 
         {
            Object sValue = getArray()[0];
            String elemStr = "#PCDATA";
   
            if (sValue instanceof XMLDomainInterface)
            {
               elemStr = ((XMLDomainInterface)sValue).printXMLDefinition(allDefs, pw, bContainees);
            }
            
            pw.println((new StringBuffer("<!ELEMENT ")
                            .append(attrTag)
                            .append(" (")
                            .append(elemStr)
                            .append(")>"))
                            .toString()
                       );

            allDefs.put(attrTag, attrTag);
         }
         elementStr.append(attrTag).append("*)>");
         allDefs.put(xmlTag, xmlTag);
         pw.println(elementStr.toString());
      }
      return xmlTag;
   }

   public static XMLDomainFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainFactory 
      {
         Class mAttrClass;
         facClass(Class clas)
         {
            mAttrClass = clas;
         }

         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element node)
         {
            try
            {
               Array a = new Array();
               a.mElemType = mAttrClass;
               a.readAttrsFromXML(node);
               return a;
            }
            catch (SQLException e)
            {
               throw new oracle.jbo.JboException(e);
            }
         }
      }
      
      return new facClass(attrClass);
   }
   
   /*
   protected void initAttrXMLDomainFactories(AttributeDef attrs[])
   {
      if (mAttrXmlFac == null)
      {
         mAttrXmlFac = new XMLDomainFactory[attrs.length];
         for (int i = 0; i < mAttrXmlFac.length; i++)
         {
            try
            {
               Object arg[] = new Object[] {attrs[i].getJavaType()};
               Method mth = ((Class)arg[0]).getMethod(
                                        "getXMLDomainFactory", new Class[] {arg[0].getClass()});
               //must be a static method.
               mAttrXmlFac[i] = (XMLDomainFactory)mth.invoke(null, arg);
            }
            catch (Exception e)
            {
               //ignore.
            }
         }
      }
   }
   */

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    * Loads the actual data of the LOB-type database attribute into memory.
    *
    * <p>The transaction argument is needed to perform an additional query into
    * the database to extract the data.
    * <p>This method does not need to be invoked for a new attribute.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * of the current Application Module.
    */
   public void loadFromDatabase( Transaction transaction )
      throws Exception
   {
   }

   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p> Saves data in memory to a database LOB-type attribute.
    *
    * <p>The transaction argument is is needed to perform an additional query into
    * the database to write the data.
    * <p>This method does not need to be invoked if this attribute's data
    * has not changed.
    *
    * @param transaction the {@link oracle.jbo.server.DBTransactionImpl}
    * instance of the current Application Module.
    */
   public void saveToDatabase( Transaction transaction )
      throws Exception
   {
      //redundant.
   }

      /**
     * <b>Internal:</b> <em>Applications should not use this method.</em>
     * <p>
     * Uses the given transaction context to store data back into the
     * database using the LOB-locator which should
     * be set before this method is invoked.
     */
   public void saveToDatabase( Transaction transaction, Object postedSQLObject )
      throws Exception
   {
   }

   public void  prepareForDML( Object context )
   {
      Connection conn = (Connection)context;
      if (mSqlTypeName == null)
      {
         throw new oracle.jbo.JboException("Cannot insert/update Array without context information");
      }
      try
      {
         oracle.sql.ArrayDescriptor desc = oracle.sql.ArrayDescriptor.createDescriptor(mSqlTypeName, conn);
         mData = new oracle.sql.ARRAY(desc, conn, getArray()); 
      }
      catch (SQLException sqle)
      {
         throw new oracle.jbo.JboException(sqle);
      }
   }


   public void syncClientLob(LobInterface old)
   {
      Array oldArr = (Array)old;
      mElemType = oldArr.mElemType;
      mElemData = oldArr.mElemData;
      mFetchedElemData = oldArr.mFetchedElemData;
   }
 
   public void syncServerLob(LobInterface oldObj)
   {
      //may have to invoke sync on each element in the array.
   }

   public DomainOwnerInterface getOwner()
   {
      return mOwner;
   }

   public int getOwnerAttributeIndex()
   {
      return mOwnerAttrIndex;
   }

   public long getSize()
   {
      return (long)(getArray().length);
   }

   public ResponseValues marshal()
   {
      return TypeMarshaller.serializeObject(this);
   }
   
   private void writeObject(java.io.ObjectOutputStream out)
     throws IOException
   {
      if (mElemType != null) 
      {
         out.writeObject(mElemType.getName());
      }
      else
      {
         out.writeObject("");
      }
      Object[] arr = getInternalArray();
      if (arr != null) 
      {
         int size = arr.length;
         out.writeInt(size);
         for (int i = 0; i < size; i++) 
         {
            out.writeObject(arr[i]);
         }
      }
      else
      {
         out.writeInt(-1);
      }
   }

   private void readObject(java.io.ObjectInputStream in)
     throws IOException, ClassNotFoundException
   {
      String name = (String)in.readObject();
      if (name.length() > 0) 
      {
         mElemType = oracle.jbo.common.JBOClass.forName(name);
      }
      
      mFetchedElemData = true;
      int size = in.readInt();
      if (size >= 0) 
      {
         Object[] arr = new Object[size];
         for (int i = 0; i < size; i++) 
         {
            arr[i] = in.readObject();
         }
         mElemData = arr;
      }
   }


}
