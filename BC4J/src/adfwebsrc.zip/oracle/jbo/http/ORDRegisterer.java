/*
 * @(#)ORDRegisterer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.http;

import javax.servlet.http.HttpSession;

import java.util.AbstractMap;
import java.util.Map;
import java.util.Set;

import oracle.adf.share.ADFContext;


public class ORDRegisterer 
{
   /**
    * The field type value for Display renderer
    */
   static public final String  DISP_RENDERER_KEY = "Renderer";
   /**
    * The field type value for Edit renderer
    */
   static public final String  EDIT_RENDERER_KEY = "EditRenderer";

   static private final String ORD_IM_PACKAGE = "oracle_ord_im";
   
   /**
    * Default Intermedia Display renderer class name
    */
   static public final String ORD_DISPLAYRENDERER_CLASSNAME = "oracle.ord.html.OrdBuildURLRenderer";
   /**
    * Default Intermedia Edit renderer class name
    */
   static public final String ORD_EDITRENDERER_CLASSNAME = "oracle.ord.html.OrdUploadFileRenderer";

   static private final String ORDIMAGEDOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdImageDomain_" + DISP_RENDERER_KEY;
   static private final String ORDAUDIODOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdAudioDomain_" + DISP_RENDERER_KEY;
   static private final String ORDVIDEODOMAIN_DISP_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdVideoDomain_" + DISP_RENDERER_KEY;
   static private final String ORDDOCDOMAIN_DISP_RENDERER_KEY =   ORD_IM_PACKAGE + "_OrdDocDomain_" + DISP_RENDERER_KEY;

   static private final String ORDIMAGEDOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdImageDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDAUDIODOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdAudioDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDVIDEODOMAIN_EDIT_RENDERER_KEY = ORD_IM_PACKAGE + "_OrdVideoDomain_" + EDIT_RENDERER_KEY;
   static private final String ORDDOCDOMAIN_EDIT_RENDERER_KEY =   ORD_IM_PACKAGE + "_OrdDocDomain_" + EDIT_RENDERER_KEY;

   static public void registerRenderer(final HttpSession session)
   {
      registerRenderer(new AbstractMap()
         {
            public Object put(Object key, Object value)
            {
               session.setAttribute(key.toString(), value);
               return value;
            }

            public Set entrySet()
            {
               return null;
            }
         });
   }

   static public void registerRenderer(Map sessionScope)
   {
      sessionScope.put(ORDIMAGEDOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      sessionScope.put(ORDAUDIODOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      sessionScope.put(ORDVIDEODOMAIN_DISP_RENDERER_KEY,  ORD_DISPLAYRENDERER_CLASSNAME);
      sessionScope.put(ORDDOCDOMAIN_DISP_RENDERER_KEY,    ORD_DISPLAYRENDERER_CLASSNAME);

      sessionScope.put(ORDIMAGEDOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      sessionScope.put(ORDAUDIODOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      sessionScope.put(ORDVIDEODOMAIN_EDIT_RENDERER_KEY,  ORD_EDITRENDERER_CLASSNAME);
      sessionScope.put(ORDDOCDOMAIN_EDIT_RENDERER_KEY,    ORD_EDITRENDERER_CLASSNAME);
  }
}
