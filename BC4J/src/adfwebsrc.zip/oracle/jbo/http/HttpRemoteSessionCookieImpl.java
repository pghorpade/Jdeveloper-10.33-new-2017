/*
 * @(#)HttpRemoteSessionCookieImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.security.Principal;

import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.RemotePoolCookie;
import oracle.jbo.common.ampool.RemoteCookieHelper;

import oracle.jbo.ApplicationModule;

public class HttpRemoteSessionCookieImpl
   extends HttpSessionCookieImpl implements RemotePoolCookie
{
   private RemoteCookieHelper mHelper = null;

   /**
    * This constructor may be used if the sessionId is already known.
    */
   public HttpRemoteSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool)
   {
      super(applicationId, sessionId, pool);

      mHelper = new RemoteCookieHelper(
         pool.getEnvironment(), pool.getConnectionStrategy());
  }

   public HttpRemoteSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal
      , HttpServletRequest request)
   {
      super(applicationId, sessionId, pool, userPrincipal, request);

      mHelper = new RemoteCookieHelper(
         pool.getEnvironment(), pool.getConnectionStrategy());
  }


   public HttpRemoteSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal
      , HttpSession session)
   {
      super(applicationId, sessionId, pool, userPrincipal, session);

      mHelper = new RemoteCookieHelper(
         pool.getEnvironment(), pool.getConnectionStrategy());
  }

   public ApplicationModule createWorkerApplicationModule()
   {
      return mHelper.createWorkerApplicationModule();
   }
}
