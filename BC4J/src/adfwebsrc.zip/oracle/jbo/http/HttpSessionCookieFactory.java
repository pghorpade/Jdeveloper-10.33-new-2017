/*
 * @(#)HttpSessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieFactory;
import oracle.jbo.JboException;

import java.lang.reflect.Constructor;

import oracle.jbo.common.Diagnostic;

import java.security.Principal;

import oracle.adf.share.ADFContext;

/**
 * Factory for HttpSessionCookieImpl instances.
 */
public class HttpSessionCookieFactory implements SessionCookieFactory
{  
   public static final String PROP_HTTP_REQUEST = "jbo.http.httprequest";

   /**
    * @deprecated use the ADFContext environment instead.
    */
   public static final String PROP_HTTP_SESSION = "jbo.http.httpsession";

  /**
    * @deprecated use PROP_HTTP_REQUEST instead.
    */
   public static final String HTTP_SERVLET_REQUEST = PROP_HTTP_REQUEST;

   /**
    * @deprecated use PROP_HTTP_SESSION instead.
    */
  public static final String HTTP_SESSION = PROP_HTTP_SESSION;


   /**
    * Creates a HttpSessionCookieImpl instance.
    * <p>
    * The properties object may contain an entry with an instance of an
    * HttpServletRequest.  The static , PROP_HTTP_REQUEST,
    * should be used to add the request object to the properties.
    * <p>
    * The request object is used to retrieve the cookie value.
    * <p>
    * @param applicationId an identifier which may be used to uniquely
    *    identify this cookie within the context of a session
    * <p>
    * @param sessionId an option identifier which may be used to uniquely
    *    identify this cookie across sessions.  If a sessionId is not specified
    *    then the HttpServletRequest above will be used to acquire the
    *    sessionId from the servlet request's session.
    * <p>
    * @param pool the applicationPool instance which will be used to acquire
    *    ApplicationModule instances for this SessionCookie.
    * <p>
    * @param properties an optional properties object which may be used
    *    to pass additional creation properties to the SessionCookieFactory.
    * 
    */
   public SessionCookie createSessionCookie(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Properties properties)
   {
      SessionCookie cookie = null;
      Principal userPrincipal = null;

      if (properties != null)
      {
         userPrincipal = (Principal)properties.get(PROP_USER_PRINCIPAL_KEY);
      }

      ADFContext context = ADFContext.getCurrent();

      Object request = context.hasEnvironment() ? context.getEnvironment().getRequest() : null;

      HttpSessionCookieHelper helper =
         HttpSessionCookieHelperManager.getHttpSessionCookieHelper();

      if (request != null && request instanceof HttpServletRequest)
      {
         if (userPrincipal == null)
         {
            try
            {
               userPrincipal = ((HttpServletRequest)request).getUserPrincipal();
            }
            catch (NoSuchMethodError e)
            {
               // ignore.  servlet 2.0 compatibility issue.
            }
         }

         sessionId = helper.generateSessionId((HttpServletRequest)request);
     }
     else if (properties != null)
     {
        // this should be a dead code branch maintained for backwards
        // compability only.  framework code will have a
        // ServletADFContext available to retrieve the request/session.
        HttpSession session = (HttpSession)properties.get(PROP_HTTP_SESSION);
        if (session != null)
        {
           sessionId = helper.generateSessionId(session);
        }
     }
         

      Class cookieClass = getSessionCookieClass();
      if ((HttpSessionCookieImpl.class).getName().equals(cookieClass.getName()))
      {
         cookie = new HttpSessionCookieImpl(
            applicationId, sessionId, pool, userPrincipal, (HttpSession)null);
      }
      else
      {
         // must use reflection
         Constructor cons = null;
         try
         {
            try
            {
               cons = cookieClass.getConstructor(
                  new Class[]{String.class, String.class
                     , ApplicationPool.class, Principal.class});
            }
            catch (NoSuchMethodException r)
            {
            }

            if (cons != null)
            {
               cookie = (SessionCookie)cons.newInstance(
                  new Object[]{applicationId, sessionId, pool, userPrincipal});
            }

            // the constructors below should be necessary only for 10.1.2
            // applications and earlier.
            if (cookie == null)
            {
               try
               {
                  cons = cookieClass.getConstructor(
                     new Class[]{String.class, String.class
                        , ApplicationPool.class, Principal.class
                        , HttpServletRequest.class});
               }
               catch (NoSuchMethodException r)
               {
               }

               if (cons != null)
               {
                  cookie = (SessionCookie)cons.newInstance(
                     new Object[]{applicationId, sessionId, pool
                        , userPrincipal
                        , request instanceof HttpServletRequest
                           ? (HttpServletRequest)request
                           : (HttpServletRequest)null});
               }
            }

            if (cookie == null)
            {
               try
               {
                  cons = cookieClass.getConstructor(
                     new Class[]{String.class, String.class
                        , ApplicationPool.class, Principal.class
                        , HttpSession.class});
               }
               catch (NoSuchMethodException r)
               {
               }

               if (cons != null)
               {
                  cookie = (SessionCookie)cons.newInstance(
                     new Object[]{applicationId, sessionId, pool
                        , userPrincipal
                        , request instanceof HttpServletRequest
                           ? ((HttpServletRequest)request).getSession(true)
                           : (HttpSession)null});
               }
            }

            if (cookie == null)
            {
               throw new JboException(
                  "HttpSessionCookieImpl constructor not found");
            }
         }
         catch (Exception e)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Could not create a SessionCookie of the specified class:  " + cookieClass.getName());
               Diagnostic.printStackTrace(e);
            }
            
            cookie = new HttpSessionCookieImpl(applicationId, sessionId
               , pool, userPrincipal, (HttpSession)null);
         }
      }

      return cookie;
   }

   public Class getSessionCookieClass()
   {
      return HttpSessionCookieImpl.class;
   }
}
