package oracle.adfinternal.model.adapter.utils;

import javax.naming.Context;

import oracle.adf.model.adapter.DTContext;

/**
 * To get the initial context for JNDI lookup
 */
public class DCInitialContext
{
  /*
  public static Context getInitialContext() throws Exception
  {
    return DTContext.getInstance().getConnectionContext();
  }
   */
}
