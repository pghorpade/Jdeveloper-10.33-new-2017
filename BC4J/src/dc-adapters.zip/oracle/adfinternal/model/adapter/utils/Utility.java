package oracle.adfinternal.model.adapter.utils;

import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import oracle.adf.model.utils.SimpleStringBuffer;

/**
 * This class contains various utilities used across the adapter data control.
 * The major utility methods included here are - 
 * <pre>
 * 1. Get the the parameter list from the string containing params
 * 2. Substitute the param values in the string containing params
 * </pre>
 */

public class Utility
{
  /**
   * Get the list of parameters from a string containing params marked between
   * ## marks.
   *
   * @param inStr Input string to search for pameters.
   * @return The list of paramater names.
   */
  public static List getParamList(String inStr)
  {
    // Look for the names between ## marks
    ArrayList list = new ArrayList();

    if (inStr == null)
      return list;

    String newText = inStr;
    int first  = -1;
    int second = -1;

    first = newText.indexOf("##",0);
    if (-1 != first)
      second = newText.indexOf("##", first+1);

    while ((first != -1) && (second != -1) )
    {
      String paramName = newText.substring(first+2,second);
      list.add(paramName);
      
      newText = newText.substring(second+2,newText.length());
      first = newText.indexOf("##",0);
      if (first != -1)
        second = newText.indexOf("##",first+1);
    }

    return list;
  }

  /**
   * Substitute the parameters with the values. Params are stuffed within ##. 
   * The values of the parameters are deined in the name value pair passed.
   *
   * @param inStr  String that may contain parameters.
   * @param params Parameter name value pairs.
   */
  public static String substituteParamValue(String inStr, Map params)
  {
    // Look for the names between ## marks

    if (inStr == null)
      return null;
    if (null == params)
      return inStr;

    String newText = inStr;
    int first  = -1;
    int second = -1;

    first = newText.indexOf("##",0);
    if (-1 != first)
      second = newText.indexOf("##", first+1);

    while ((first != -1) && (second != -1) )
    {
      String paramName    = newText.substring(first+2,second);
      SimpleStringBuffer newTextSB =
        new SimpleStringBuffer(newText.substring(0,first));

      String paramVal =(String)params.get(paramName);

      if (paramVal != null)
      {
          newTextSB.append(paramVal);
      }
      
      newTextSB.append(newText.substring(second+2,newText.length()));
      newText = newTextSB.toString();

      first = newText.indexOf("##",0);
      if (first != -1)
        second = newText.indexOf("##",first+1);
    }

    return newText;

  }

}
