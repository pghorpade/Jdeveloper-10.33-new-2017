/* $Header: EjbDefinition.java 23-dec-2005.09:39:49 jobracke Exp $ */

/* Copyright (c) 2004, 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Defines the AbstractDefinition for Ejb data controls.  Extends the
    BeanAbstractDefinition implementation to handle AbstractDefinition
    meta data delegation.

   MODIFIED    (MM/DD/YY)
    jobracke    12/23/05 - Remove flag indicating support for find mode. 
    jwetherb    12/09/05 - Re-enabled clobbered support for UPDATES 
    jwetherb    12/07/05 - Override shouldCompileProjectOnCreate() to return 
                           true 
    jwetherb    12/05/05 - Re-enable sort operations
    jwetherb    11/30/05 - Remoted SORT support until the feature support is
                           resolved
    jwetherb    11/29/05 - Remove support for transactions; add support for
                           sorting
    jwetherb    09/14/05 - Re-enable Transaction support to fix bug 4610640
    jwetherb    09/09/05 - Disable TRANSACTION support. We support only CMT in
                           10.1.3.
    jobracke    08/25/05 -
    alai        08/16/05 - Overrides getFullName() to include ".dataProvider"
    alai        08/01/05 -
    alai        07/25/05 - Replace javax.binding with oracle.binding
    jwetherb    07/26/05 - Remove RANGE_SIZE support
    jwetherb    07/22/05 - Enable FIND_MODE and RANGE_SIZE
    jwetherb    07/11/05 - Return TRUE for SUPPORTS_TRANSACTION property
    jwetherb    07/06/05 - Override isStructureDirty() to return true if
                           refresh is true
    jwetherb    06/21/05 - Add ejb-type and ejb-business-interface properties,
                           for use during creation of <ejb-ref> in web.xml
    jwetherb    06/21/05 -
    jwetherb    06/07/05 - Expose InitialContext properties to allow client to
                           chose runtime deployment target
    jwetherb    06/06/05 -
    jwetherb    06/02/05 - Refine the set of runtime meta data properties
    jwetherb    06/01/05 - Assign adapterType value to match EJB adapter name
                           in adapter-definition.xml
    jwetherb    05/31/05 - Add assignDefaultPackage() override
    jwetherb    05/26/05 - Disable TRANSACTION methods
    jwetherb    05/24/05 - Cleanup runtime
    jwetherb    05/23/05 - jwetherb_050517_migrate_ejb_data_control_to_jsr_227
    jwetherb    05/19/05 - Introduce the new EJB adapter
    jwetherb    05/17/05 - Creation
 */
package oracle.adfinternal.model.adapter.ejb;

import oracle.adf.model.adapter.AbstractDefinition;

import oracle.binding.DataControl;

import oracle.adf.model.meta.DataControlDefinition;
import oracle.adfinternal.model.adapter.generic.BeanAbstractDefinition;
import oracle.adfinternal.model.adapter.generic.DataControlStructure;


/**
 * Defines the AbstractDefinition for Ejb data controls.  Extends the BeanAbstractDefinition
 * implementation to handle AbstractDefinition meta data delegation.
 *
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractDefinition
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter
 * @see oracle.adfdtinternal.model.adapter.ejb.EjbDataControlProvider
 *
 * @version $Header: EjbDefinition.java 23-dec-2005.09:39:49 jobracke Exp $
 * @author  jwetherb
 * @since   10.1.3
 */
public class EjbDefinition
  extends BeanAbstractDefinition
{
  public static final String EJB_DEFINITION = "ejb-definition"; //NORES
  public static final String EJB_DEFINITION_URI = 
    "http://xmlns.oracle.com/adfm/adapter/ejb"; //NORES

  /**
   *  EJB_VERSION is defined in oracle.jdeveloper.ejb.EjbConstants
   *  as EJB20_STR, EJB21_STR, or EJB30_STR
   */
  public static final String EJB_VERSION = "ejb-version"; //NORES
  public static final String EJB_NAME = "ejb-name"; //NORES
  public static final String EJB_TYPE = "ejb-type"; //NORES
  public static final String EJB_INTERFACE_TYPE = 
    "ejb-interface-type"; //NORES
  public static final String EJB_BUSINESS_INTERFACE = 
    "ejb-business-interface"; //NORES
  public static final String EJB_HOME_INTERFACE = 
    "ejb-home-interface"; //NORES
  public static final String EJB_LOCAL_HOME_INTERFACE = 
    "ejb-local-home-interface"; //NORES
  public static final String J2EE_APPNAME = "j2ee-appname"; //NORES
  public static final String INITIAL_CONTEXT_FACTORY = 
    "initial-context-factory"; //NORES
  public static final String SECURITY_PRINCIPAL = 
    "security-principal"; //NORES
  public static final String SECURITY_CREDENTIALS = 
    "security-credentials"; //NORES
  public static final String PROVIDER_URL = "provider-url"; //NORES

  private static final String ADAPTER_TYPE = 
    "oracle.adfm.adapter.EjbDataControl"; //NORES -- must match adapter-definition.xml file

  /**
   * Zero arg constructor required by the framework.
   */
  public EjbDefinition()
  {
    super();
  }

  /**
   * Constructor used by the BeanAbstractAdapter.
   */
  public EjbDefinition(DataControlStructure definition)
  {
    super(definition);
  }

  /**
   * Creates data control at runtime.
   */
  public DataControl createDataControl()
  {
    return new EjbDataControl(this);
  }

  /**
   * Returns the dc structure provider type for this BeanAbstractDefinition.
   */
  protected String getProviderType()
  {
    return EjbAdapter.EJB_PROVIDER;
  }

  public boolean isSupported(String operation)
  {
    if (DataControlDefinition.SUPPORTS_UPDATES.equals(operation) ||
        DataControlDefinition.SUPPORTS_SORT_COLLECTION.equals(operation))
    {
      return true;
    }
    return super.isSupported(operation);
  }

  public String getFullName()
  {
    // overrides superclass' getFullName() because EJB DC uses
    // ".dataProvider" as path to its instance instead of the default
    // ".root".
    return getName() + ".dataProvider";
  }

  public String getAdapterType()
  {
    return ADAPTER_TYPE;
  }

  /**
   * @return false to indicate that EJB data controls maintain
   * their own package info in the structure defs they create.
   */
  public boolean assignDefaultPackage()
  {
    return false;
  }

  public int getCachingMode()
  {
    return AbstractDefinition.CACHE_TO_SOURCEPATH;
  }

  public boolean usePersistedStructure()
  {
    return getCachingMode() == AbstractDefinition.CACHE_TO_SOURCEPATH;
  }

  public boolean shouldCompileProjectOnCreate()
  {
    return true;
  }
}

