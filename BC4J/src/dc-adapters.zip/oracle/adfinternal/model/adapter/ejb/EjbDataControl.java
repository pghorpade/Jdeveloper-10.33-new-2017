/* $Header: EjbDataControl.java3444 08-mar-2006.22:52:49 jwetherb Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Addin for registering J2EE and OC4J descriptor documents
    as generic DescriptorNodes.

   MODIFIED    (MM/DD/YY)
    jwetherb    03/08/06 - Use the current thread's classloader to find the 
                           Session bean's EJB Home iface 
    jobracke    12/22/05 - Removed overrided removeRowData implementation per 
                           bug 4905105. 
    jwetherb    12/21/05 - Modify removeRowData to wrap exceptions in 
                           JboException and rethrow 
    jwetherb    12/13/05 - Override removeRowData() to call removeEntity() on 
                           the Session bean before delegating to the framework 
    jwetherb    12/12/05 - Extend DefaultUpdateableBeanDataControl to provide
                           default impl
    jwetherb    11/29/05 - Remove impl for TransactionalDataControl
    jsmiljan    11/18/05 - Implement UpdateableDataControl
    jsmiljan    11/21/05 - XbranchMerge jsmiljan_bug-4737504 from main
    jwetherb    10/19/05 - Fix EJB 2.x LocalHome interface lookup
    jwetherb    09/14/05 - Re-enable Transaction support to fix bug 4610640
    jwetherb    09/09/05 - Disable TRANSACTION support. We support only CMT in
                           10.1.3.
    jwetherb    08/21/05 - Add backup lookup to support JClient
    jwetherb    08/11/05 - Exceptions thrown from method invocations are now
                           unwrapped from their InvocationTargetException
                           wrappers and rethrown as JboException so they can
                           be handled by the framework
    jwetherb    08/09/05 - Add workaround support for invoking methods on the
                           root session bean instance
    jwetherb    08/09/05 - Lookup the method invocation instance in the
                           binding context instead of always using the EJB
                           business interface
    jwetherb    08/08/05 - Resolve the params to be an ordered Object list by
                           cross referencing the param values w/ the ordered
                           param names
    alai        07/25/05 - Replace javax.binding with oracle.binding
    jwetherb    07/21/05 - Call processResult() when assigning the ejb
                           business iface to the bindingcontext
    jwetherb    07/19/05 - Track dirty and removed objects
    jwetherb    07/14/05 - Add createRowData() impl
    jwetherb    07/11/05 - Implement TransactionalDataControl
    jdijamco    07/08/05 - Fixed build breakage from txn:jwetherb_050708_fix_ejb_datacontrol_parameterized_method_execution
    jwetherb    07/08/05 - Fixed the no-arg method execution case
    jwetherb    07/08/05 - Add parameterized method execution support
    jwetherb    07/07/05 - Modified invokeOperation() to return false if
                           operationInfo is null (this signals the framework
                           to handle the operation with a built-in impl
    jwetherb    06/23/05 - Return the _ejbBusinessInterface from invoke() for
                           ordinary method calls
    jwetherb    06/20/05 - Fix EJB 2.1 local Session bean lookup
    jwetherb    06/14/05 - Tweak EJB 3.0 lookup code
    jwetherb    06/07/05 - EJB 3.0 and runtime InitialContext lookup support
    jwetherb    06/02/05 - Workaround duplicate <Source> elem issue
    jwetherb    06/02/05 - Add runtime support for obtaining the RT meta data
                           and handling invokeOperation() requests
    jwetherb    06/01/05 - Extract runtime data from EjbDefinition
    jwetherb    05/24/05 - Cleanup runtime
    jwetherb    05/24/05 - Cache the EJB Home/LocalHome (for EJB 2.x) and
                           business interface instances
    jwetherb    05/23/05 - jwetherb_050517_migrate_ejb_data_control_to_jsr_227
    jwetherb    05/19/05 - Introduce the new EJB adapter
    jwetherb    05/17/05 - Creation
 */
package oracle.adfinternal.model.adapter.ejb;

import java.lang.reflect.Method;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import oracle.adfinternal.model.adapter.bean.DefaultUpdateableBeanDataControl;
import oracle.adfinternal.model.adapter.ejb.EjbDefinition;
import oracle.jbo.JboException;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
   Data Control implementation class for EJB objects.

   @version $Header: EjbDataControl.java3444 08-mar-2006.22:52:49 jwetherb Exp $
   @author  jwetherb
   @since   10.1.3
 */
public class EjbDataControl
  extends DefaultUpdateableBeanDataControl
{
  // Constants
  private static final String EJB30_STR = "3.0";
  private static final String RMIINITIALCONTEXTFACTORY = "oracle.j2ee.rmi.RMIInitialContextFactory";
  
  //  Cache the chosen Stateless Session bean business interface
  private String _ejbName;
  private Object _ejbBusinessInterface;
  private boolean _isEjb30;

  EjbDataControl(EjbDefinition ejbDefinition)
  {
    final Node node = ejbDefinition.getMetadata();
    if (node != null)
    {
      final NodeList childList = node.getChildNodes();
      if (childList != null && childList.getLength() == 1)
      {
        Node ejbDefNode = childList.item(0);
        if (ejbDefNode != null)
        {
          final NamedNodeMap ejbDefAttrs = ejbDefNode.getAttributes();
          if (ejbDefAttrs != null)
          {
            Node attr;
            attr = ejbDefAttrs.getNamedItem(EjbDefinition.EJB_VERSION);
            final String ejbVersion = 
              (attr != null ? attr.getNodeValue() : null);
            attr = ejbDefAttrs.getNamedItem(EjbDefinition.EJB_NAME);
            _ejbName = (attr != null ? attr.getNodeValue() : null);
            attr = 
                ejbDefAttrs.getNamedItem(EjbDefinition.EJB_INTERFACE_TYPE);
            final String ejbInterfaceType = 
              (attr != null ? attr.getNodeValue() : "remote");
            String ejbHomeInterface = null;
            if ("remote".equals(ejbInterfaceType))
            {
              attr = 
                  ejbDefAttrs.getNamedItem(EjbDefinition.EJB_HOME_INTERFACE);
              ejbHomeInterface = 
                  (attr != null ? attr.getNodeValue() : null);
            }

            try
            {
              final Context context = getInitialContext(ejbDefAttrs);
              if (EJB30_STR.equals(ejbVersion))
              {
                _isEjb30 = true;
                attr = 
                    ejbDefAttrs.getNamedItem(EjbDefinition.INITIAL_CONTEXT_FACTORY);
                final String factory = 
                  (attr != null ? attr.getNodeValue() : null);
                String lookupStr;
                if (RMIINITIALCONTEXTFACTORY.equals(factory))
                {
                  lookupStr = _ejbName;
                }
                else if ("local".equals(ejbInterfaceType))
                {
                  lookupStr = "java:comp/env/ejb/local/" + _ejbName;
                }
                else
                {
                  lookupStr = "java:comp/env/ejb/" + _ejbName;
                }
                try
                {
                  _ejbBusinessInterface = context.lookup(lookupStr);
                }
                catch (Exception e)
                {
                  _ejbBusinessInterface = context.lookup(_ejbName);
                }
              }
              else
              {
                final Object home;
                if (ejbHomeInterface != null && 
                    ejbHomeInterface.length() > 0)
                {
                  final Class homeClass = 
                      Thread.currentThread().getContextClassLoader().loadClass(ejbHomeInterface);
                  home = 
                      PortableRemoteObject.narrow(context.lookup(_ejbName), 
                                                  homeClass);
                }
                else
                {
                  /*
                    Local Home interface lookup, assumes the following ejb-local-ref has
                    been added to web.xml or application-client.xml to access this EJB:
                      <ejb-local-ref>
                        <ejb-ref-name>ejb/local/Sales</ejb-ref-name>
                        <ejb-ref-type>Session</ejb-ref-type>
                        <local-home>model.SalesLocalHome</local-home>
                        <local>model.SalesLocal</local>
                        <ejb-link>Sales</ejb-link>
                      </ejb-local-ref>
                  */
                  home = 
                      context.lookup("java:comp/env/ejb/local/" + _ejbName);
                }

                final Method createMethod = 
                  home.getClass().getMethod("create", null); //NORES
                _ejbBusinessInterface = createMethod.invoke(home, null);
              }
            }
            catch (Exception e) {
                throw new JboException(e);
            }
          }
        }
      }
    }
  }

  /**
   *  Hashtable env = new Hashtable();
   *  env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");//NORES
   *  env.put(Context.SECURITY_PRINCIPAL, "admin");//NORES
   *  env.put(Context.SECURITY_CREDENTIALS, "welcome");//NORES
   *  env.put(Context.PROVIDER_URL, "ormi://localhost/__ejbapp__");//NORES
   */
  private Context getInitialContext(NamedNodeMap ejbDefAttrs)
    throws NamingException
  {
    Node attr;
    attr = ejbDefAttrs.getNamedItem(EjbDefinition.INITIAL_CONTEXT_FACTORY);
    final String factory = (attr != null ? attr.getNodeValue() : null);
    attr = ejbDefAttrs.getNamedItem(EjbDefinition.SECURITY_PRINCIPAL);
    final String username = (attr != null ? attr.getNodeValue() : null);
    attr = ejbDefAttrs.getNamedItem(EjbDefinition.SECURITY_CREDENTIALS);
    final String password = (attr != null ? attr.getNodeValue() : null);
    attr = ejbDefAttrs.getNamedItem(EjbDefinition.PROVIDER_URL);
    final String url = (attr != null ? attr.getNodeValue() : null);

    final Hashtable env = new Hashtable();
    if (hasLength(factory))
    {
      env.put(Context.INITIAL_CONTEXT_FACTORY, factory);
    }
    if (hasLength(username))
    {
      env.put(Context.SECURITY_PRINCIPAL, username);
    }
    if (hasLength(password))
    {
      env.put(Context.SECURITY_CREDENTIALS, password);
    }
    if (hasLength(url))
    {
      env.put(Context.PROVIDER_URL, url);
    }

    return new InitialContext(env);
  }

  private boolean hasLength(String val)
  {
    return val != null && val.length() > 0;
  }

  public Object getDataProvider()
  {
    return _ejbBusinessInterface;
  }

  public void release(int flags)
  {
    if ((flags & REL_ALL_REFS) > 0 || (flags & REL_DATA_REFS) > 0)
    {
      _ejbBusinessInterface = null;
    }
  }
}
