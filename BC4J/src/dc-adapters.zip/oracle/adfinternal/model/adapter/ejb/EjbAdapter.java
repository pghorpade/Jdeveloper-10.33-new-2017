/* $Header: EjbAdapter.java 28-jul-2005.14:02:43 jobracke Exp $ */
 
/* Copyright (c) 2004, 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    Defines the AbstractAdapter for EJB Stateless Session beans.  
    Utilizes the BaseAbtractAdapter framework to handle
    meta data creation.

   MODIFIED    (MM/DD/YY)
    jobracke    07/28/05 - 
    jwetherb    07/22/05 - Add 'EJB Data Control' library during 
                           configureClientProject() 
    jwetherb    06/21/05 - Fixup configureClientProject() to add an <ejb-ref> 
                           for EJB 3.0 beans, and an <ejb-local-ref> for EJB 
                           2.x beans, to the web.xml file 
    jwetherb    06/21/05 - Configure client project for EJB 3.0 data controls 
                           by adding an <ejb-ref> elem to web.xml 
    jwetherb    06/20/05 - Implement new configureClientProject() override on 
                           AbstractAdapter to add an ejb-ref to web.xml when 
                           needed 
    jwetherb    06/14/05 - Constraint EJB 3.0 beans to only Stateless Session 
                           beans for now 
    jwetherb    05/24/05 - Cleanup runtime 
    jwetherb    05/23/05 - jwetherb_050517_migrate_ejb_data_control_to_jsr_227
    jwetherb    05/22/05 - Restrict EJB 2.x data controls to SessionContainer 
                           elements 
    jwetherb    05/19/05 - Introduce the new EJB adapter 
    jwetherb    05/17/05 - Creation
 */
package oracle.adfinternal.model.adapter.ejb;

import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter;
import oracle.adfinternal.model.adapter.generic.DataControlStructure;



/**
 * Defines the AbstractAdapter for EJB Stateless Session beans.  
 * Utilizes the BaseAbtractAdapter framework to handle
 * meta data creation.
 * 
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter
 * 
 * @version $Header: EjbAdapter.java 28-jul-2005.14:02:43 jobracke Exp $
 * @author  jwetherb
 * @since   10.1.3
 */
public class EjbAdapter 
    extends BeanAbstractAdapter 
{
  public EjbAdapter() 
  {
    super();
  }
  
  /** Ejb DataControlStructureProvider identifier */
  public static final String EJB_PROVIDER = "ejb";
 
  
  /**
   * Creates the EJB-specific AbstractDefinition.
   */
  protected AbstractDefinition getDefinition(DataControlStructure metaDataDef) 
  {
    return new EjbDefinition( metaDataDef );
  }    
  
  /**
   * Returns the Structure provider type.
   */
  protected String getProviderType() 
  {
    return EJB_PROVIDER;
  }
}
