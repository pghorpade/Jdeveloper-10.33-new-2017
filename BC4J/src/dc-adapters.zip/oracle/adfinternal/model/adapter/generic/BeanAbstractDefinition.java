package oracle.adfinternal.model.adapter.generic;

import java.util.Map;
import oracle.binding.meta.StructureDefinition;
import oracle.adf.model.adapter.AbstractDefinition;
import org.w3c.dom.Node;

/**
 * This abstract implementation of <code>AbstractDefinition</code> provides structure definition and associated meta data
 * creation behavior via the DataControlStructure framework.  There are three cases when an AbstractDefinition
 * will be created in ADF:
 * 
 * 1) Runtime: The AbstractDefinition will be created via a zero arg constructor and will be provided the
 * data control name, meta data, and parameters.  It is then expected to know how to create the rt data control.
 * 2) Designtime via the AbstractAdapter: In this case, the AbstractDefinition is created with a non zero arg
 * contructor.  It is expected to provide the StructureDefinition, dc name, and meta data.
 * 3) Designtime via the Adapter framework: The AbstractDefinition is created via a zero arg constructor.  It is 
 * expected to provide the StructureDefinition. The meta data and and dc name are provided by the Adapter framework.
 * 
 * This class provides facilities for handling these cases in a uniform fashion without introducing 
 * direct designtime dependencies in the concrete AbstractDefinition implementation.  
 * 
 * Case 1: Follow the AbstractAdapter pattern for handling meta data loading and data control creation.  
 * Case 2: In the BeanAbstractAdapter implementation return the concrete implementation of this class in the getDefinition(DataControlStructure)
 * method initialized with the DataControlStructure constructor.
 * Case 3: The abstract implementation will load the required DataControlStructure when needed from the DataControlStructureProvider 
 * registered with the DCStructureProviderFactory for the definition type.
 * 
 * Implementors of this class must indicate the provider type via the <code>getProviderType()</code> method.  
 * 
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructure
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructureProvider
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter
 * @see oracle.adf.model.adapter.AbstractDefinition
 * 
 * 
 * @version 10.1.3
 *
 */
public abstract class BeanAbstractDefinition extends AbstractDefinition {

    private DataControlStructure dcStructure;
    protected Node metaData;
    protected Map parameters;
    
    /**
     * Called by the framework.
     */
    public BeanAbstractDefinition() {
        super();
    }
    
    /**
     * Called by the BeanAbstractAdapter to create an initialized AbstractDefinition. 
     */
    public BeanAbstractDefinition(DataControlStructure dcStructure) {
        super();
        this.dcStructure = dcStructure;
    }

    /**
     * Accessor that returns the DC parameters passed in by the <code>loadFromMetadata()</code> method.
     */
    protected Map getRuntimeParameters() {
        return this.parameters;
    }
    
    /**
     * Accessor that returns the DC meta data passed in by the <code>loadFromMetadata()</code> method.
     */
    protected Node getRuntimeMetaData() {
        return this.metaData;
    }
    
    /**
     * Indicates the type of DataControlStructureProvider to use during initialization.
     */
    protected abstract String getProviderType();

    protected final String getDCName() {
        if (dcStructure == null) {
            return getName();
        }
        return dcStructure.getDataControlName();
    }
    // ------- AbstractAdapter methods  -------------------
     
    public final StructureDefinition getStructure() {
        return ( dcStructure != null ? dcStructure.getStructure() : null );
    }
    
    public final Node getMetadata() {
        if (dcStructure == null) {
            return metaData;
        }
        return dcStructure.getMetadata();
    }

    public final void loadFromMetadata(Node metaData, Map parameters) {
        this.metaData = metaData;
        this.parameters = parameters;
    }  

    /**
     * Indicates whether the definition delegates to the framework the task of
     * deserializing its StructureDefinition (for example, from bean .xml 
     * files on disk).
     * 
     * Overrides base method on AbstractDefinition.
     */
    public boolean usePersistedStructure()
    {
      return true;
    }
    
    /**
     * Indicates to the Adapter framework to always recreate the DC on refresh.
     */
    public boolean isStructureDirty( boolean refresh )
    {
      return refresh;
    }
}
