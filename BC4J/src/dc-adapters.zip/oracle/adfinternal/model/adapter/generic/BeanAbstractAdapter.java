package oracle.adfinternal.model.adapter.generic;

import oracle.adf.model.adapter.AbstractAdapter;
import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.DTContext;

/**
 * DataControlStructure driven AbstractAdapter implementation.  This class
 * handles the AbstractDefinition creation lifecycle and initialization based on the registered 
 * DataControlStructureProvider for the given adapter.  Implementors of this class must
 * implement the <code>getDefinition(DataControlStructure)</code> method providing the concrete AbstractDefinition
 * as well as the <code>getProviderType()</code> method indicating the DataControlStructureProvider
 * registered with the environment for this Adapter.
 * 
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructureProvider
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructure
 * @see oracle.adfinternal.model.adapter.generic.DCStructureProviderFactory
 * 
 * @author jobracke
 */
public abstract class BeanAbstractAdapter extends AbstractAdapter {

    private Object sourceObj;
    private DTContext dtCtx;
    private DataControlStructure dcStructure;

    
    /**
     * Caches objects passed in during initialization.
     */
    public final void initialize(Object sourceObj, DTContext ctx) {
            this.sourceObj = sourceObj;
            this.dtCtx = ctx;
    }

    /**
     * Constructs and returns the AbstractDefinition.
     */
    public final AbstractDefinition getDefinition() {
        return getDefinition(this.dcStructure);
    }
    
    /**
     * Implementing classes must define this method to return the correct AbstractDefinition
     * instance based on the given DataControlStructure.
     */
    protected abstract AbstractDefinition getDefinition(DataControlStructure dcStructure);
    
    /**
     * Indicates the DataControlStructureProvider type registered with the DCStructureProviderFactory to call
     * during DataControlStructure creation.
     */
    protected abstract String getProviderType();

    /**
     * Invokes the DataControlStructureProvider indicated by the provider type to do environment specific initialization
     * of the DataControlStructure used in construction of the AbstractDefinition. 
     */
    public final boolean invokeUI() {
        DataControlStructureProvider provider = getStructureProvider();
        this.dcStructure = provider.createDefinition(sourceObj, dtCtx);
 
        return this.dcStructure != null;
    }
    
    /**
     * Defers to the DataControlStructureProvider indicated by <code>getProviderType()</code> to
     * determine if this Adapter can create the AbstractDefinition for the source object.
     */
    public boolean canCreateDataControl(Object source) {
        return getStructureProvider().canCreateDefinition(source);
    }
    
    /**
     * Convenience method for obtaining the DataControlStructureProvider.
     */
    protected DataControlStructureProvider getStructureProvider() {
        return DCStructureProviderFactory.instance().getProvider(getProviderType());
    }
    
    public void configureClientProject(Object sourceObj, DTContext ctx) {
        getStructureProvider().configureClientProject(sourceObj, ctx);
    }
    
}
