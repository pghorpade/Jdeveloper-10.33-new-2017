package oracle.adfinternal.model.adapter.generic;

import oracle.binding.meta.StructureDefinition;

import org.w3c.dom.Node;

/**
 * Implementors of this interface provide the necessary meta data to construct an 
 * <code>AbstractDefinition</code> object to be used in designtime mode in the ADF
 * adapter based framework. 
 *
 * @see oracle.adf.model.adapter.AbstractDefinition
 * @see oracle.adfinternal.model.adapter.toplink.TopLinkDefinition
 * 
 * @author jobracke
 */
public interface DataControlStructure {

    /**
     * Returns the structure definition describing the data control being created 
     * for this DataControlStructure.
     */
    public StructureDefinition getStructure();
    
    /**
     * Returns the name of this data control.
     */
    public String getDataControlName();
    
    /**
     * Returns the node representing the deployment settings for the data control being 
     * created for this definition.
     */
    public Node getMetadata();
}
