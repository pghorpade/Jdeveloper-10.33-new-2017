package oracle.adfinternal.model.adapter.generic;

import java.util.HashMap;
import java.util.Map;


/**
 * Singleton class that acts as a factory for MetaDataProviders for the given environment(jdev, worplace, etc).
 * This singleton must have the correct DCDefinitionProviderBuilder installed at designtime
 * environment initialization or prior to DataControlStructureProvider construction.  the main benefit 
 * provided by this class is a level of indirection between runtime and designtime components
 * of the ADF adapter based framework.  The TopLink AbstractAdapter and AbstractDefinition
 * implementations need not know about the designtime details (UI and meta data creation) of the environment
 * to create the DataControlStructureProvider. Also a level of abstraction is provided such that multiple persistence 
 * technology flavors (OR, EJB, XML) can be incorporated in via their own DataControlStructure and asssociated
 * provider.
 * 
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructureProvider
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructure
 * 
 * @author jobracke
 */
public final class DCStructureProviderFactory {

    /** Singleton instance **/
    private static DCStructureProviderFactory INSTANCE;
    
    /** Instance of the builder to be used in this environment */
    private Map builders; 
    
    
    /**
     * Restricted constructor.
     */
    private DCStructureProviderFactory() {
        super();
        this.builders = new HashMap();
        
    }
 
    /**
     * Singleton method.
     */
    public static DCStructureProviderFactory instance() {
        if (INSTANCE == null) {
            INSTANCE = new DCStructureProviderFactory();
            //INSTANCE.setProviderBuilder(new BeanProviderBuilder());
        }
        return INSTANCE;
    }
    
    /**
     * Creates a DataControlStructureProvider based on the DCDefinitionProviderBuilder given by the environment.
     */
    public DataControlStructureProvider getProvider(String type) {
        return (DataControlStructureProvider)builders.get(type);
    }
    
    /**
     * To be called during environment initialization or prior to data control creation. This method
     * allows for each technology type to register their environment specifc mechanism for building the DataControlStructureProvider.
     */
    public void addProviderBuilder(String builderType, DataControlStructureProvider provider) {
        this.builders.put(builderType, provider);
    }
}
