/**
 * 
 */
package oracle.adfinternal.model.adapter.generic;

import oracle.binding.meta.StructureDefinition;


import org.w3c.dom.Node;

/**
 * Default <code>DataConrolDefinition</code> implementation.
 */
public class DataControlStructureImpl implements DataControlStructure {
    private String dcName;
    private Node rtSettings;
    private StructureDefinition dcStructure;
    
    public DataControlStructureImpl(String dcName, Node rtSettings, StructureDefinition dcStructure) {
        this.dcName = dcName;
        this.rtSettings = rtSettings;
        this.dcStructure = dcStructure;
    }
    
    public String getDataControlName() {
        return dcName;
    }

    public Node getMetadata() {
        return rtSettings;
    }

    public StructureDefinition getStructure() {
        return dcStructure;
    }
}
