package oracle.adfinternal.model.adapter.generic;

import oracle.adf.model.adapter.DTContext;


/**
 * Implementors of this interface provide facilities for creating a DataControlStructure object
 * that describes the required components of an AbstractDefinition in 
 * designtime mode in the ADF adapter-based framework.
 * 
 * @see oracle.adfinternal.model.adapter.generic.DataControlStructure
 * @see oracle.adfinternal.model.adapter.generic.DCStructureProviderFactory
 * @see oracle.adf.model.adapter.AbstractDefinition
 * @see oracle.adfinternal.model.adapter.toplink.TopLinkDefinition
 * @see oracle.adfinternal.model.adapter.toplink.TopLinkAdapter
 * 
 * @author jobracke
 */
public interface DataControlStructureProvider {
    
    /**
     * Creates the DataControlStructure that describes the required components of an AbstractDefinition in 
     * designtime mode in the ADF adapter-based framework. Takes the <code>sourceObj</code>
     * passed by the Adapter during initialization (in jdev, a source node) as well as the
     * <b>ctx</b> which contains design time information.
     */
    public DataControlStructure createDefinition(Object sourceObj, DTContext ctx);
    /**
     * Returns <code>true</code> if this DC Structure provider can create the DataControlStructure from
     * the given design-time object.  In the case of JDeveloper, this object will likely be a <code>Node</code>.
     */
    public boolean canCreateDefinition(Object dtSource);
    
    /**
     * Handles DT specific configuration of the associated project.  In the case of JDev,
     * this would be the <code>oracle.ide.Project</code>. 
     */
    public void configureClientProject(Object sourceObj, DTContext ctx);
}
