package oracle.adfinternal.model.adapter.toplink;

// JDK
import java.util.IdentityHashMap;
import java.util.Map;

import oracle.adf.model.adapter.utils.NodeAttributeHelper;

import org.w3c.dom.Node;

// ADF
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;

// TopLink
import oracle.toplink.internal.helper.ConversionManager;
import oracle.toplink.sessionbroker.SessionBroker;
import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.sessions.Project;
import oracle.toplink.sessions.Session;
import oracle.toplink.threetier.ServerSession;
import oracle.toplink.tools.sessionconfiguration.XMLSessionConfigLoader;
import oracle.toplink.tools.sessionmanagement.SessionManager;
import oracle.toplink.tools.workbench.XMLProjectReader;

import org.w3c.dom.NodeList;

/**
 * <b>Purpose<b>: TopLink abstraction for brokering TopLink Sessions and UnitOfWorks across all
 * ADF TopLink data controls and instances of a given application.<p>
 * <b>Description<b>: Handles transaction creation, allocation, and management related activities for 
 * the TopLink ADF Data Control implementation.  
 * 
 * @see oracle.adf.model.generic.toplink.TransactionBroker
 * @see oracle.adf.model.generic.toplink.TopLinkDataControl
 * @see oracle.adf.model.generic.toplink.DataControlFactoryImpl
 * 
 * @version 10.1.3
 */
public class PersistenceManager implements TopLinkADFConstants
{

    private static Map pmInstances = new IdentityHashMap();
  
    /**
     * Access restricted constructor.  PM instances are delegated
     * by class loaders.
     */
	private PersistenceManager() {
		super();
		initialize();
	}
    
    public static PersistenceManager getManager() {
        ClassLoader currLoader = Thread.currentThread().getContextClassLoader();
        PersistenceManager persistenceManager = (PersistenceManager)pmInstances.get(currLoader);
            if (persistenceManager == null) {
                persistenceManager = new PersistenceManager();
                pmInstances.put(currLoader, persistenceManager);
            }
            return persistenceManager;
    }

	/**
	 * Performs initialization related activities.
	 */
	protected void initialize() {
		// Prime the ConversionManager with the application class loader
		ConversionManager.getDefaultManager().setShouldUseClassLoaderFromCurrentThread(true);
	}

	/**
	 * Builds up a new or retrieves a cached TransactionBroker for the given application BindingContext 
	 * and application parameters.
	 */
	public synchronized TransactionBroker createTransactionBroker(Node metaData) {
        // Get the information from the definition.
        NodeList listChld = metaData.getChildNodes();
        int cnt = listChld.getLength();
        String deploymentDescriptorLocation = null;
        String sessionsXMLLocation = null;
        String sessionName = null;
        boolean shouldPerformDeletesFirst = false;
        boolean sequenceOnCreate = false;
        for (int i = 0; i < cnt; i++) {
            Node chld = listChld.item(i);
            if (TOPLINK_DEFINITION.equalsIgnoreCase(chld.getNodeName())) {
                // Load the required attributes
                NodeAttributeHelper attribs = new NodeAttributeHelper(chld.getAttributes());
                deploymentDescriptorLocation = attribs.getValue(DEPLOYMENT_DESCRIPTOR_PATH);
                sessionsXMLLocation = attribs.getValue(SESSIONS_XML_PATH);
                sessionName = attribs.getValue(SESSION_NAME);
                shouldPerformDeletesFirst = attribs.getValueBoolean(SHOULD_PERFORM_DELETES_FIRST);
                sequenceOnCreate = attribs.getValueBoolean(ASSIGN_SEQUENCE_NUMBERS_ON_CREATE);
                // only iterate through the children until the tl def is found
                break;
            }
        }
        // validate required
        checkParameters(deploymentDescriptorLocation, sessionsXMLLocation, sessionName);
        TransactionBroker transBroker;
        if (deploymentDescriptorLocation != null) {
            transBroker = createTransactionBroker(deploymentDescriptorLocation, shouldPerformDeletesFirst, sequenceOnCreate);
        } else {
            transBroker = createTransactionBroker(sessionsXMLLocation, sessionName, shouldPerformDeletesFirst, sequenceOnCreate);
        }
        return transBroker;
    }

	/**
	 * Determines whether the provided parameters are legitimate. Throws a JBOException indicating the problem
	 * if not. 
	 */
	private void checkParameters(String deploymentDescriptorLocation, String sessionsXMLLocation, String sessionName) {
		if (deploymentDescriptorLocation == null && sessionsXMLLocation == null && sessionName == null) {
			throw new JboException("ERROR: No Parameters specified for this Data Control.");
		} else if (deploymentDescriptorLocation != null && sessionsXMLLocation != null && sessionName != null) {
			throw new JboException(
					"ERROR: Ambiguous Parameters. Either the deployment descriptor location OR the sessions.xml and Session name should be specified.");
		} else if (deploymentDescriptorLocation == null && (sessionsXMLLocation == null || sessionName == null)) {
			throw new JboException(
					"ERROR: When using the sessions.xml, both a sessions.xml location and Session name must be specified.");
		}
	}

	/**
	 * Gets the TransactionBroker for the given application BindingContext and deployment descriptor location.  If
	 * one does not exist, one is created and returned.  
	 */
	synchronized TransactionBroker createTransactionBroker(String deploymentDescriptorLocation, 
                                                            boolean performDeletesFirst, boolean sequenceOnCreate) {
		Project project = XMLProjectReader.read(deploymentDescriptorLocation, JBOClass.getCurrentClassLoader());
        DatabaseSession session = project.createDatabaseSession();
		session.login();
        TransactionBroker transBroker = null;
        if (session.hasExternalTransactionController()) {
            transBroker = new JTATransactionBroker(session, TransactionBroker.ISOLATED_DATABASE_SESSION_TYPE, 
                    performDeletesFirst, sequenceOnCreate);
        } else {
            transBroker = new IsolatedTransactionBroker(session, TransactionBroker.ISOLATED_DATABASE_SESSION_TYPE, 
                    performDeletesFirst, sequenceOnCreate);
        }
        return transBroker;
	}

	/**
	 * Gets the TransactionBroker for the given application BindingContext, sessions.xml location and session name.  If
	 * one does not exist, one is created and returned.  
	 */
    synchronized TransactionBroker createTransactionBroker(String sessionsXMLLocation, String sessionName, 
                                                            boolean performDeletesFirst, boolean sequenceOnCreate) {
		SessionManager sessionManager = SessionManager.getManager();
		Session session = sessionManager.getSession(new XMLSessionConfigLoader(sessionsXMLLocation), sessionName, JBOClass
					.getCurrentClassLoader(), true, false, true);
		if (session == null) {
			throw new JboException("Problem encountered loading Session named: " + sessionName + " from file: "
					+ sessionsXMLLocation);
		}
		Session sessionToUse;
		int sessionType;
        if (session.isSessionBroker()) {
            SessionBroker sessionBroker = (SessionBroker)session;
            if (sessionBroker.isServerSessionBroker()) {
                sessionToUse = ((SessionBroker) session).acquireClientSessionBroker();
                sessionType = TransactionBroker.CLIENT_SESSION_BROKER_TYPE;
            } else {
                sessionToUse = session;
                sessionType = TransactionBroker.SHARED_SESSION_BROKER_TYPE;
            }
		} else if (session.isServerSession()) {
            sessionToUse = ((ServerSession) session).acquireClientSession();
            sessionType = TransactionBroker.CLIENT_SESSION_TYPE;			
		} else {
			sessionToUse = session;
			sessionType = TransactionBroker.SHARED_DATABASE_SESSION_TYPE;
		}
        TransactionBroker transBroker = null;
        if (session.hasExternalTransactionController()) {
            transBroker = new JTATransactionBroker(session, TransactionBroker.ISOLATED_DATABASE_SESSION_TYPE, 
                    performDeletesFirst, sequenceOnCreate);
        } else {
            transBroker = new IsolatedTransactionBroker(session, TransactionBroker.ISOLATED_DATABASE_SESSION_TYPE, 
                    performDeletesFirst, sequenceOnCreate);
        }
		return transBroker;
	}



}
