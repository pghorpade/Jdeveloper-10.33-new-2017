package oracle.adfinternal.model.adapter.toplink;

import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;

/**
 * This class describes a TransactionBroker that uses a JTA-shared transaction model.  Instead of 
 * acquiring a UnitOfWork from the Sesssion and using isolated transaction space, this TransactionBroker
 * always delagates to the Session to use the JTA transaction.  This type of TransactionBroker is employed
 * when the given Session indicates a shared, JTA transaction.  Using a shared, JTA transaction is useful when
 * the data control is one of many services used in a shared transaction application.  
 * 
 * @version 10.1.3
 * @author jobracke
 */
public class JTATransactionBroker extends TransactionBroker {

    /**
     * Creates a new TransactionBroker instance.
     * 
     * @param applicationBindingContext -
     *            BindingContext unique to this application instance.
     * @param session -
     *            TopLink Session for this application instance.
     * @param brokerType -
     *            describes the mode of operation with regards to the underlying
     *            TL Session.
     * @param shouldPerformDeletesFirst -
     *            determines whether the UnitOfWork in this TransactionBroker
     *            should perform deletes first pn commit.
     */

    public JTATransactionBroker(Session session, int brokerType, boolean shouldPerformDeletesFirst,
            boolean shouldSequenceOnCreate) {
        super(session, brokerType, shouldPerformDeletesFirst, shouldSequenceOnCreate);
    }
    
    /**
     * Returns the JTA UnitOfWork from the Session.
     */
    public UnitOfWork getUnitOfWork() {
        return getSession().getActiveUnitOfWork();
    }
    
    /**
     * Only releases the shared UnitOfWork.
     */
    protected void resetUnitOfWork() {
        getUnitOfWork().release();
    }
    
    /**
     * Releases the shared UnitOfWork indicated
     * by the Session.
     */
    protected void releaseUnitOfWork() {
        getUnitOfWork().release();
    }

}
