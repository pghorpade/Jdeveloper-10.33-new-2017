package oracle.adfinternal.model.adapter.toplink;

import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter;
import oracle.adfinternal.model.adapter.generic.DataControlStructure;

/**
 * Defines the AbstractAdapter for TopLink.  Utilizes the BaseAbtractAdapter framework to handle
 * meta data creation.
 * 
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter
 * @see oracle.adfinternal.model.adapter.toplink.TopLinkDefinition
 * 
 * @version 10.1.3
 */
public class TopLinkAdapter extends BeanAbstractAdapter {
        
    public TopLinkAdapter() {
        super();
    }
    
    /** TopLink DataControlStructureProvider identifier */
    public static final String TOPLINK_PROVIDER = "toplink";

    /**
     * Creates the TopLink specific AbstractDefinition.
     */
    protected AbstractDefinition getDefinition(DataControlStructure metaDataDef) {
        return new TopLinkDefinition(metaDataDef);
    }    
    
    /**
     * Returns the Structure provider type.
     */
    protected String getProviderType() {
        return TOPLINK_PROVIDER;
    }
    
}
