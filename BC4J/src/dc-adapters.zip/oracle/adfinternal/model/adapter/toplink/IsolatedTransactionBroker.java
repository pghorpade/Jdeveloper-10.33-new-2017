package oracle.adfinternal.model.adapter.toplink;

// TopLink
import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;

/**
 * This class describes a TransactionBroker that uses an UnitOfWork that is not shared at the Session level,
 * but is isolated to the data control that uses it.  The UnitOfWork is always acquired from the underlying
 * Session directly.
 *
 * @version 10.1.3
 * @author jobracke
 */
public class IsolatedTransactionBroker extends TransactionBroker {
    
    /** Current UnitOfWork for this transaction */
    private UnitOfWork unitOfWork;

    /**
     * Creates a new TransactionBroker instance.
     * 
     * @param applicationBindingContext -
     *            BindingContext unique to this application instance.
     * @param session -
     *            TopLink Session for this application instance.
     * @param brokerType -
     *            describes the mode of operation with regards to the underlying
     *            TL Session.
     * @param shouldPerformDeletesFirst -
     *            determines whether the UnitOfWork in this TransactionBroker
     *            should perform deletes first pn commit.
     */
    public IsolatedTransactionBroker(Session session, int brokerType, boolean shouldPerformDeletesFirst, boolean shouldSequenceOnCreate) {
        super(session, brokerType, shouldPerformDeletesFirst, shouldSequenceOnCreate);
        resetUnitOfWork();
    }

    /**
     *  Releases the active UnitOfWork and acquires a new one from the underlying Session.
     */
    protected void resetUnitOfWork() {
        if (unitOfWork != null)
            unitOfWork.release();
        this.unitOfWork = getSession().acquireUnitOfWork();
        this.unitOfWork.setShouldPerformDeletesFirst(shouldPerformDeletesFirst);
    }

    /**
     * Releases the current UnitOfWork and nulls it out.
     */
    protected void releaseUnitOfWork() {
        this.unitOfWork.release();
        this.unitOfWork = null;
    }

    /**
     * Returns the current UnitOfWork.
     */
    public UnitOfWork getUnitOfWork() {
        return unitOfWork;
    }

}
