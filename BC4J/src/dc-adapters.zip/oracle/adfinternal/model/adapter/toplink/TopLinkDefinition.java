package oracle.adfinternal.model.adapter.toplink;

import oracle.binding.DataControl;

import oracle.adf.model.meta.DataControlDefinition;
import oracle.adfinternal.model.adapter.generic.BeanAbstractDefinition;
import oracle.adfinternal.model.adapter.generic.DataControlStructure;


/**
 * Defines the AbstractDefinition for TopLink data controls.  Extends the BeanAbstractDefinition
 * implementation to handle AbstractDefinition meta data delegation.
 * 
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractDefinition
 * @see oracle.adfinternal.model.adapter.generic.BeanAbstractAdapter
 * @see oracle.adfdtinternal.model.adapter.toplink.TopLinkDataControlProvider
 * 
 * @author jobracke
 */
public class TopLinkDefinition extends BeanAbstractDefinition {

    /**
     * Zero arg constructor required by the framework.
     */
    public TopLinkDefinition() {
        super();
    }

    /**
     * Constructor used by the BeanAbstractAdapter.
     */
    public TopLinkDefinition(DataControlStructure definition) {
        super(definition);
    }

    /**
     * Creates data control at runtime.
     */
    public DataControl createDataControl() {
        PersistenceManager pm = PersistenceManager.getManager();
        TransactionBroker txn = pm.createTransactionBroker(getMetadata());
        
        return new TopLinkDataControl(txn);
    }

    /**
     * Returns the dc structure provider type for this BeanAbstractDefinition.
     */
    protected String getProviderType() {
        return TopLinkAdapter.TOPLINK_PROVIDER;
    }

    public boolean isSupported(String operation) {
        if (DataControlDefinition.SUPPORTS_TRANSACTION.equals(operation) ||
        DataControlDefinition.SUPPORTS_RESET_STATE.equals(operation) ||
        DataControlDefinition.SUPPORTS_SORT_COLLECTION.equals(operation) ||
        DataControlDefinition.SUPPORTS_UPDATES.equals(operation)) {
            return true;
        }
        return super.isSupported(operation);
    }
    
    /**
     * @return false to indicate that TopLink data controls maintain
     * their own package info in the structure defs they create.
     */
    public boolean assignDefaultPackage() {
        return false;
    }

    /**
     * Returns the name of the TopLinkAdapter class as the adapter type.
     */
    public String getAdapterType() {
        return TopLinkAdapter.class.getName();
    }
}
