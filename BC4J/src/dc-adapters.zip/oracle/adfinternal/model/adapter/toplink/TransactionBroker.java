package oracle.adfinternal.model.adapter.toplink;

// JDK
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

// ADF
import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;

// TopLink
import oracle.toplink.descriptors.ClassDescriptor;
import oracle.toplink.descriptors.DescriptorQueryManager;
import oracle.toplink.internal.descriptors.RootDescriptor;
import oracle.toplink.queryframework.DatabaseQuery;
import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;
import oracle.toplink.tools.sessionmanagement.SessionManager;

/**
 * 
 * <b>Purpose<b>: Transactional unti used by all TopLinkDataControls that share
 * common deployment resources in a given application context
 * <p>
 * <b>Description<b>: Defines the transactional behavior and boundaries for a
 * given instance of a TopLink application in ADF and brokers these
 * transactional properties between all TopLinkDataControls in this application
 * instance. This transactional behavior includes operations such as: create,
 * delete, update, query execution, commit, and rollback. The transactional
 * boundaries of a given application are defined by the application
 * BindingContext instance and extend to all TopLinDataControl which share a
 * common binding context and TopLink deployment and data access resources.
 * 
 * @see oracle.adf.model.adapter.toplink.TopLinkDataControl
 * 
 * @version 10.1.3
 */
public abstract class TransactionBroker {
    /**
     * Defines this TransactionBroker as three tier user of a TopLink
     * ClientSession per application instance.
     */
    protected static final int CLIENT_SESSION_TYPE = 1;

    /**
     * Defines this instance as a three tier user of a TopLink Client
     * SessionBroker per application instance.
     */
    protected static final int CLIENT_SESSION_BROKER_TYPE = 2;

    /**
     * Defines this TransactionBroker as using a shared SessionBroker across all
     * application instances.
     */
    protected static final int SHARED_SESSION_BROKER_TYPE = 3;

    /**
     * Defines this TransactionBroker as using a shared DatabaseSession across
     * all application instances.
     */
    protected static final int SHARED_DATABASE_SESSION_TYPE = 4;

    /**
     * Defines this TransactionBroker as using a DatabaseSession per application
     * instance.
     */
    protected static final int ISOLATED_DATABASE_SESSION_TYPE = 5;

    /** Current TopLink Session for this transaction */
    private Session session;

    /** The type of TransactionBroker */
    private int brokerType;

    /** determine if deletes should be performed first upon commit */
    protected boolean shouldPerformDeletesFirst;

    /**
     * determins if the UnitOfWork should assign Sequence Numbers on new object
     * instance creation
     */
    private boolean shouldSequenceOnCreate;

    private Map queryNamesToClasses;

    /**
     * Creates a new TransactionBroker instance.
     * 
     * @param applicationBindingContext -
     *            BindingContext unique to this application instance.
     * @param session -
     *            TopLink Session for this application instance.
     * @param brokerType -
     *            describes the mode of operation with regards to the underlying
     *            TL Session.
     * @param shouldPerformDeletesFirst -
     *            determines whether the UnitOfWork in this TransactionBroker
     *            should perform deletes first pn commit.
     */
    protected TransactionBroker(Session session, int brokerType, boolean shouldPerformDeletesFirst,
            boolean shouldSequenceOnCreate) {
        super();
        initialize(session, brokerType, shouldPerformDeletesFirst, shouldSequenceOnCreate);
    }

    /**
     * Initializes based constructor parameters.
     */
    protected void initialize(Session session, int brokerType, boolean shouldPerformDeletesFirst,
            boolean shouldSequenceOnCreate) {
        this.session = session;
        this.brokerType = brokerType;
        this.shouldPerformDeletesFirst = shouldPerformDeletesFirst;
        this.shouldSequenceOnCreate = shouldSequenceOnCreate;
        buildQueryNamesToClasses();
    }

    /**
     * Returns true if the underlying UnitOfWork has ChangeSets.
     */
    protected boolean isTransactionDirty() {
        return getUnitOfWork().hasChanges();
    }

    /**
     * Commits the UnitOfWork and all changes associated with this
     * TransactionBroker.
     */
    protected synchronized void commitTransaction() {
        Diagnostic.println("TOPLINK ADF: Calling TopLink.commit");
        this.getUnitOfWork().commitAndResume();
    }

    /**
     * Rollback the transaction for all TopLinkDataControls associated with this
     * TransactionBroker. Also resets the transactional state as being rolled
     * back for all TopLinkDataControls that are associated with this
     * TransactionBroker.
     */
    protected synchronized void rollbackTransaction() {
        Diagnostic.println("TOPLINK ADF: Calling TopLink.rollback");
        this.getUnitOfWork().revertAndResume();
    }

    /**
     * Resets the transaction for all TopLinkDataControls associated with this
     * TransactionBroker. Also resets the transactional state as being rolled
     * back for all TopLinkDataControls that are associated with this
     * TransactionBroker.
     */
    protected synchronized void resetState() {
        Diagnostic.println("TOPLINK ADF: Calling TopLink.resetState");
        resetUnitOfWork();
    }

    /**
     * Resets the transactional resources for this TransactionalBroker instance
     * and notifies all associated TopLinkDataControls of that the transactional
     * state has been reset. Specifically, the TopLink UnitOfWork is reset to an
     * initial state.
     */
    protected synchronized void resetTransaction() {
        resetUnitOfWork();
    }

    /**
     * Registers the new Entity with the UnitOfWork.  If this TransactionBroker
     * has been noted to sequence on create, then the new object is assigned
     * its sequence field.  Since the object is registered as a new instance, 
     * the original instance is returned by this method.  Using the original versus
     * the returned value is optional.
     * 
     * @param entity - the entity to register as a new instance with the transaction.
     * @return the registered entity.
     */
    public Object registerNewEntity(Object entity) {
        return registerNewEntity(entity, this.shouldSequenceOnCreate);
    }
    
    /**
     * Registers the new Entity with the UnitOfWork.  If this TransactionBroker
     * has been noted to sequence on create, then the new object is assigned
     * its sequence field.  Since the object is registered as a new instance, 
     * the original instance is returned by this method.  Using the original versus
     * the returned value is optional.
     * 
     * @param entity - the entity to register as a new instance with the transaction.
     * @param assignSequence - indicates whether to do sequencing assignment.
     * @return the registered entity.
     */
    public Object registerNewEntity(Object entity, boolean assignSequence) {
        Object newEntity = this.getUnitOfWork().registerNewObject(entity);
        if (assignSequence) {
            getUnitOfWork().assignSequenceNumber(newEntity);
        }
        return newEntity;
    }
    
    /**
     * Registers the given object in this transaction.
     * 
     * @return - the working copy of the object.
     */
    public Object registerEntity(Object entity) {
        return this.getUnitOfWork().registerObject(entity);
    }

    /**
     * Creates a new object instance based upon the given class type to be
     * created in this transaction. This does not assign a sequence number in
     * the case where the newly created object uses sequencing.
     * 
     * @return the working copy of the newly created object.
     */
    public Object createEntity(Class objectType) {
        return createEntity(objectType, this.shouldSequenceOnCreate);
    }

    /**
     * Creates a new object instance based upon the given class type to be
     * created in this transaction.
     * 
     * @param objectType - type of object.
     * @param assignSequenceNumber - should assign a sequence number in the case 
     *        where sequencing is used with the associated object type.
     * @return the working copy of the newly created object.
     */
    public Object createEntity(Class objectType, boolean assignSequenceNumber) {
        Object newObject = this.getUnitOfWork().newInstance(objectType);
        if (assignSequenceNumber) {
            this.getUnitOfWork().assignSequenceNumber(newObject);
        }
        return newObject;
    }

    /**
     * Marks the given object to be deleted in this transaction.
     * 
     * @return the working copy of the deleted object.
     */
    public Object deleteEntity(Object entity) {
        return this.getUnitOfWork().deleteObject(entity);
    }

    /**
     * Handles the releasing behavior that occurs when associated
     * TopLinkDataControls are released from the binding container and
     * subsequent application server (typically during application timeout or
     * shutdown). For each TopLinkDataControl that this method is invoked on,
     * they are disassociated with this TransactionBroker. Upon the last data
     * control instance being released, the given TransactionBroker instance
     * destroys its TL Session(in the Client Session case) and UnitOfWork as
     * well as removing itself from the PersistenceManager.
     */
    protected synchronized void release() {
        Exception lastExceptionEncountered = null;
        try {
            releaseUnitOfWork();
        } catch (Exception e) {
            lastExceptionEncountered = e;
        }
        try {
            releaseSession();
        } catch (Exception e) {
            lastExceptionEncountered = e;
        }
        if (lastExceptionEncountered != null) {
            throw new JboException(lastExceptionEncountered);
        }
    }

    /**
     * Releases the UnitOfWork for this broker.
     */
    protected abstract void releaseUnitOfWork();

    /**
     * Releases the TL Session and performs a logout if necessary.
     */
    protected void releaseSession() {

        switch (this.brokerType) {
        case SHARED_DATABASE_SESSION_TYPE:
        case SHARED_SESSION_BROKER_TYPE:
            SessionManager.getManager().destroySession(this.session.getName());
            break;
        case ISOLATED_DATABASE_SESSION_TYPE:
            DatabaseSession dbSession = (DatabaseSession) this.session;
            // per the DatabaseSession interface, in order to logout, any open
            // transaction must be rolled back
            if (dbSession.isInTransaction()) {
                dbSession.rollbackTransaction();
            }
            dbSession.logout();
            break;
        case CLIENT_SESSION_BROKER_TYPE:
        case CLIENT_SESSION_TYPE:
            this.session.release();
            break;
        }
        this.session = null;
    }

    /**
     * Executes the defined TopLink query based upon the given class, query
     * name, and parameters.
     * 
     * @return results of the query.
     */
    protected Object executeQuery(String beanClass, String queryName, Vector queryParameters) throws ClassNotFoundException {
        return this.getUnitOfWork()
                .executeQuery(queryName, Thread.currentThread().getContextClassLoader().loadClass(beanClass), queryParameters);
    }

    /**
     * Executes the defined TopLink query based upon the given class, query
     * name, and parameters.
     * 
     * @return results of the query.
     */
    protected Object executeQuery(String queryName, Map parameters) {
        DatabaseQuery query = getQuery(queryName);
        Vector orderedParams = getOrderedQueryParameters(query, parameters);
        return this.getUnitOfWork().executeQuery(query, orderedParams);
    }

    /**
     * Based on the given parameters and query, an ordered List of query
     * parameters is returned.
     */
    private Vector getOrderedQueryParameters(DatabaseQuery query, Map parameters) {
        List queryArgs = query.getArguments();
        Vector queryParams = new Vector(queryArgs.size());
        for (Iterator args = queryArgs.iterator(); args.hasNext();) {
            String argName = (String) args.next();
            Object value = parameters.get(argName);
            queryParams.add(value);
        }
        return queryParams;
    }
    
    /**
     * Creates and configures a the UnitOfWork used by this TransactionBrokers.
     * The way in which the UnitOfWork is reset varies by user implementation.
     */
    protected abstract void resetUnitOfWork();

    /**
     * Returns the UnitOfWork associated with this transaction.
     */
    public abstract UnitOfWork getUnitOfWork();

    /**
     * Returns the Session associated with this transaction.
     */
    public Session getSession() {
        return this.session;
    }
    
    /**
     * Returns the query associated with the given name.
     */
    private DatabaseQuery getQuery(String queryName) {
        Class descClass = getQueryClass(queryName);
        ClassDescriptor desc = (ClassDescriptor) this.getUnitOfWork().getDescriptor(descClass);
        return desc.getQueryManager().getQuery(queryName);
    }
    
    /**
     * Returns the class that the given query was defined on in the TopLink
     * Project.
     */
    private Class getQueryClass(String queryName) {
        return (Class) this.queryNamesToClasses.get(queryName);
    }

    /**
     * Indicates whether the given operation name represents a query defined in
     * the TopLink Project.
     */
    protected boolean isQuery(String operationName) {
        return getQueryClass(operationName) != null;
    }
    
    /**
     * Initialize a Map of all TL queries mapped to the descriptor's .class. In
     * ADF, since there is no return type indicated in the OperationInfo's
     * provided during query execution, TopLink must know the class(descriptor)
     * to execute the query on.
     */
    private void buildQueryNamesToClasses() {
        this.queryNamesToClasses = new HashMap();
        Map descriptors = this.session.getProject().getDescriptors();
        for (Iterator descNames = descriptors.keySet().iterator(); descNames.hasNext();) {
            Class descClass = (Class) descNames.next();
            RootDescriptor desc = (RootDescriptor) descriptors.get(descClass);
            if (!desc.isAggregateDescriptor() && !desc.isDescriptorForInterface()) {
                ClassDescriptor classDesc = (ClassDescriptor) desc;
                DescriptorQueryManager queryManager = (DescriptorQueryManager) classDesc.getQueryManager();
                for (Iterator queries = queryManager.getAllQueries().iterator(); queries.hasNext();) {
                    DatabaseQuery query = (DatabaseQuery) queries.next();
                    String queryName = query.getName();
                    queryNamesToClasses.put(queryName, descClass);
                }
            }
        }
    }
}
