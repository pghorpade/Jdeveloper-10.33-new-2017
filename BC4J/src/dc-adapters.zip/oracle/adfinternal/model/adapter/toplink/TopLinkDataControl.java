package oracle.adfinternal.model.adapter.toplink;

import java.lang.reflect.Method;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.adf.model.generic.DCGenericRowContext;

import oracle.binding.ManagedDataControl;
import oracle.binding.OperationBinding;
import oracle.binding.OperationInfo;
import oracle.binding.RowContext;
import oracle.binding.TransactionalDataControl;
import oracle.binding.UpdateableDataControl;

import oracle.adfinternal.model.adapter.bean.DefaultUpdateableBeanDataControl;

import oracle.jbo.common.JBOClass;

import oracle.toplink.sessions.Session;
import oracle.toplink.sessions.UnitOfWork;

/**
 * <b>Purpose<b>: Data control for use of TopLink within ADF.
 * <p>
 * <b>Description<b>: This data control abstracts the use of TopLink. It allows
 * for a single TransactionBroker to be shared among all live objects derived
 * from an underlying Session. This assumes a single transaction and database
 * session (isolated or *client/1server) per user context.
 * 
 * @see oracle.adfinternal.model.adapter.toplink.TopLinkDefinition
 * @see oracle.adfinternal.model.adapter.toplink.TransactionBroker
 * @see oracle.adfinternal.model.adapter.toplink.PersistenceManager
 * 
 * @version 10.1.3
 */
public class TopLinkDataControl extends DefaultUpdateableBeanDataControl implements UpdateableDataControl, TransactionalDataControl, ManagedDataControl,
        TopLinkADFConstants {

    /** Transactional state for this data control */
    private TransactionBroker txnBroker;

    /** Indicates whether the transaction is dirty */
    private boolean isTransactionDirty = false;

    public TopLinkDataControl(TransactionBroker txnBroker) {
        super();
        this.txnBroker = txnBroker;
    }

    /**
     * Commits the transaction for this data control.
     */
    public void commitTransaction() {
        getTransaction().commitTransaction();
        isTransactionDirty = false;
    }

    public boolean setAttributeValue(oracle.binding.AttributeContext ctx, Object value) {
        // let the framework set the attribute value.
        return false;
    }

    /**
     * Creates the object described by <code>RowContext</code>, adds it to
     * the underlying provider Collection, registers it in the given
     * transaction, and returns the newly created object.
     * 
     * @param ctx -
     *            description of the Row to create
     */
    public Object createRowData(RowContext ctx) {
        Object createdObject = super.createRowData(ctx);
        return getTransaction().registerNewEntity(createdObject);
    }

    /**
     * Indicates whether the TopLink UnitOfWork has any changes.
     */
    public boolean isTransactionDirty() {
        if (!isTransactionDirty) {
            isTransactionDirty = getTransaction().isTransactionDirty();
        }
        return isTransactionDirty;
    }

    /**
     * NOOP: Returns the passed in object as the registered data provider. Since all
     * objects are either registered from the outset or explicit calls are made to associate
     * the object with the transaction, this method always returns the object contained in the
     * row context.
     */
    public Object registerDataProvider(RowContext ctx) {
        return ctx.getRowDataProvider();
    }

    /**
     * Return true if the row at the given index is removed from the the RSI
     * associated with the given iterator-binding. In addition, this method goes
     * into the provider underlying collection removes the object contained in
     * the Row, and marks the object to be deleted in the given transaction.
     */
    public boolean removeRowData(RowContext ctx) {
        Object rowProvider = ctx.getRowDataProvider();
        getTransaction().deleteEntity(rowProvider);
        return super.removeRowData(ctx);
    }

    /**
     * Rollsback the transaction for this data control. The side effect of this
     * method call is that all data controls sharing the same transaction will
     * be commited and have their transactional state reset as well.
     * 
     * @see oracle.adf.model.binding.DCDataControl#rollbackTransaction()()
     */
    public void rollbackTransaction() {
        getTransaction().rollbackTransaction();
        isTransactionDirty = false;
    }

    /**
     * Resets the state of the TopLinkDataControl to it's initial state upon
     * entering the application: a new UnitOfWork is acquired and all RSIs
     * associated with this DataControl are reset to their initial state (old
     * query results are invalidated as well). Calls to this method will also
     * recurse to all TopLinkDataControls that share the same TX space in the
     * application.
     * 
     * @return whether this call has been deferred to the end of the web
     *         request.
     */
    public boolean resetState() {
        getTransaction().resetState();
        return true;
    }

    public void validate() {
        // NOOP
    }

    /**
     * Returns the data provider for this data control. In the case of TopLink,
     * the data provider is the data control itself.
     */
    public Object getDataProvider() {
        return this;
    }

    /**
     * Returns the name of this Data Control.
     */
    public String getName() {
        return this.mName;
    }

    /**
     * Per the Data Control contract, this method handles executing Accessors on
     * this data control as well as operations. In terms of TopLink, this
     * entails initializing and creating empty Accessors for all defined on the
     * Data Control. Also TopLink queries are executed through this method.
     */
    public boolean invokeOperation(Map bindingContext, OperationBinding action) {
        OperationInfo operation = action.getOperationInfo();
        if (operation != null) {
            String operationName = operation.getOperationName();
            // see if this represents a query
            if (getTransaction().isQuery(operationName)) {
                Object result = getTransaction().executeQuery(operation.getOperationName(), action.getParamsMap());
                processResult(result, bindingContext, action);
                return true;
            } 
            // otherwise, determine if this is the persist operation
            else if (isPersistOperation(action)) {
                invokePersistOperation(action, bindingContext);
                return true;
            }
        }
        return false;
    }
    
    /**
     * Invokes the persist operation on the TL data control for the new entity specified
     * as the parameter.  The result of this method is that the passed in entity is made
     * part of the transaction as a new object.
     */
    private void invokePersistOperation(OperationBinding binding, Map bindingContext) {
        OperationInfo operation = binding.getOperationInfo();
        String operationName = operation.getOperationName();
        Object entityToRegister = binding.getParamsMap().get(PERSIST_METHOD_PARAM_NAME);
        Object registeredEntity = getTransaction().registerNewEntity(entityToRegister);
        processResult(registeredEntity, bindingContext, binding);
    }
    
    /**
     * Indicates whether the given OperationBinding represents the persist method 
     * defined on the TL data control for handling new object registration with the
     * Transaction (UnitOfWork).
     */
    private boolean isPersistOperation(OperationBinding binding) {
        OperationInfo operation = binding.getOperationInfo();
        String operationName = operation.getOperationName();
        if (PERSIST_METHOD_NAME.equals(operationName)) {
            return binding.getParamsMap().containsKey(PERSIST_METHOD_PARAM_NAME);
        }
        return false;
    }

    /**
     * Handles releasing TopLink transactional resources when the data control
     * is release from the binding container.
     */
    public void release(int flags) {
        // make sure that the right flags are passed and ensure that this
        // DC has not been previously released.
        if ((flags & REL_DATA_REFS) > 0) {
            getTransaction().release();
        }
    }

    /**
     * Implemented per the ManagedDataControl contract. Tracks when this data
     * control begins an application request.
     */
    public void beginRequest(HashMap requestCtx) {
    }

    /**
     * Implemented per the ManagedDataControl contract. Tracks when this data
     * control has ended an application request.
     */
    public void endRequest(HashMap requestCtx) {
    }

    /**
     * ADVANCED: Returns the TransactionBroker associated with this data
     * control.
     */
    public TransactionBroker getTransaction() {
        return this.txnBroker;
    }

    /**
     * ADVANCED: Returns the TopLink UnitOfWork associated with this data
     * control's transaction. Use care when accessing this UnitOfWork as any
     * transactional state management activities will make the transactional
     * state of this data control inconsistent.
     */
    public UnitOfWork getAssociatedUnitOfWork() {
        return getTransaction().getUnitOfWork();
    }

    /**
     * ADVANCED: Returns the TopLink Session associated with this data control's
     * transaction. Use care when accessing this Session as any transactional
     * state management activities will make the transactional state of this
     * data control inconsistent.
     */
    public Session getSession() {
        return getTransaction().getSession();
    }

}
