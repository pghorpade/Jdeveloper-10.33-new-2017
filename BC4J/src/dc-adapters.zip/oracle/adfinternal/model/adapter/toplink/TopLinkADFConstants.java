package oracle.adfinternal.model.adapter.toplink;

/**
 * <b>Purpose<b>: TopLink related constants that are ADF specific.<p>
 * <b>Description<b>: Constants for application parameters.
 * 
 * @version 10.1.3
 */
public interface TopLinkADFConstants
{
    
    public static final String TOPLINK_DEFINITION = "TopLinkDefinition";    
	/** Parameter key for the TopLink Deployment Descriptor location */
	public static final String DEPLOYMENT_DESCRIPTOR_PATH = "DeploymentDescriptorPath";
	/** Parameter key for the TopLink sessions.xml location */
	public static final String SESSIONS_XML_PATH = "SessionsXMLPath";
	/** Parameter key for the TopLink Session name to be used */
	public static final String SESSION_NAME = "SessionName";
	/** Parameter indicating that sequence numbers should be assigned on object creation */
	public static final String ASSIGN_SEQUENCE_NUMBERS_ON_CREATE = "SequenceOnCreate";
    /** Parameter indicating that the associated UnitOfWork should perform deletes first upon commit*/
	public static final String SHOULD_PERFORM_DELETES_FIRST = "ShouldPerformDeletesFirst";
    /** TopLink specific declaration for an add method to be used by an Accessor on Row creation.*/
    public static final String ACCESSOR_ADD_METHOD = "AddMethod";
    /** TopLink specific declaration for a remove method to be used by an Accessor on Row removal.*/
    public static final String ACCESSOR_REMOVE_METHOD = "RemoveMethod";
    /** TopLink specific declaration for an insert method to be used by an Accessor on Row creation.*/
    public static final String ACCESSOR_INSERT_METHOD = "InsertMethod";
    /** Static representing the constant persist method name for detached objects */
    public static final String PERSIST_METHOD_NAME = "persist";
    /** Static representing the constant persist method parameter name for detached objects */
    public static final String PERSIST_METHOD_PARAM_NAME = "entity";
}
