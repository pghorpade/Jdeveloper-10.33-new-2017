/* $Header: CSVDataControl.java 27-sep-2006.16:22:32 shalin Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    shalin      09/27/06 - correct perf logging usage
    armukher    08/14/06 - 
    jfwang      11/02/05 - XbranchMerge jfwang_fix_memory_leak from main 
    jfwang      10/24/05 - XbranchMerge jfwang_fix_urldc_performance_logging 
                           from main 
    jfwang      09/07/05 - 
    jfwang      08/25/05 - 
    jfwang      08/19/05 - 
    jfwang      08/17/05 - 
    jfwang      08/11/05 - 
    jfwang      08/02/05 - 
    alai        07/22/05 - 
    jfwang      07/20/05 - 
    armukher    06/28/05 - 
    kmchorto    06/24/05 - 
    armukher    06/22/05 - 
    jfwang      06/16/05 - 
    jfwang      06/13/05 - 
    jfwang      06/10/05 - 
    jfwang      05/13/05 - 
    armukher    02/24/05 - 
    jfwang      12/20/04 - Creation
 */

/**
 *  @version $Header: CSVDataControl.java 27-sep-2006.16:22:32 shalin Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adfinternal.model.adapter.url.csv;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;

import javax.naming.Context;

import HTTPClient.HTTPResponse;
import HTTPClient.HTTPConnection;

import java.util.logging.Level;

import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.adfinternal.model.adapter.url.resource.URLMessageResource;

import oracle.binding.ManagedDataControl;
import oracle.binding.OperationInfo;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.AbstractImpl;
import oracle.adf.model.adapter.dataformat.CSVHandler;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.dataformat.FormatDataEventListener;
import oracle.adf.model.adapter.dataformat.FormatDataEvent;
import oracle.adf.model.connection.url.URLConnection;
import oracle.adf.model.utils.SimpleStringBuffer;

import oracle.adfinternal.model.adapter.url.resource.URLMessageArb;
import oracle.adfinternal.model.adapter.url.csv.CSVDCDef;
import oracle.adfinternal.model.adapter.utils.Utility;
import oracle.adf.model.connection.url.FileInteraction;
import oracle.adf.share.perf.Timer;

/**
 * Data control that represents a URL data source with CSV data format.
 */
public class CSVDataControl extends AbstractImpl 
  implements ManagedDataControl 
{
  // csv source location
  private String mConnectionName = null;
  //url query
  private String mUrlQuery = null;
  // flag to indicate whether the first row will be treated as column nmaes.
  private boolean mIsFirstRowNames = false;
  // csv encodingg
  private String mEncStyle = null;
  // Character value separator 
  private String mDelimiter = null;
  // Character used to quote a multi-word string
  private String mQuoteChar = null;

  // csv filteringType
  private String mFilteringType = null;
  
  //csv filtering conditions
  private String[] mFilteringConditions = null;
  
  //csv filtering colname - type map
  private Map mFilteringColTypeMap = null;
  
  //csv filtering colformat - format map
  private Map mFilteringColFormatMap = null;
  
  // List of open connection + data stream listeners. We may need to close 
  // them as the session ends.
  private ArrayList mDataChannels = new ArrayList(20);
  
    
  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger(); 

  // performance sensors
  private static Timer sInvokeOperationTimer = Timer.createTimer(Level.FINER,
                     "/oracle/adf/model/adapter/url",
                     "CSVDataControl.invokeOperation",
                     "Invoking operation in URL Data Control");
  
  /**
   * constructor
   */
  public CSVDataControl()
  {
  }
  
  /**
   * Initialize the data control to get attributes of data control definition.
   * @param context
   * @param node source node that represents the metadata to connect to 
   * the data source
   */
  public void initialize(AbstractDefinition dcDef)
  {
    if (dcDef instanceof CSVDCDef)
    {
      CSVDCDef csvdef = (CSVDCDef)dcDef;
      mConnectionName = csvdef.getConnectionName();
      mUrlQuery = csvdef.getUrlQuery();
      mEncStyle = csvdef.getEncStyle();
      mIsFirstRowNames = csvdef.getIsFirstRowNames();
      mDelimiter = csvdef.getDelimiter();
      mQuoteChar = csvdef.getQuoteChar();
      mFilteringType = csvdef.getFilteringType();
      mFilteringConditions = csvdef.getFilteringConditions();
      mFilteringColTypeMap = csvdef.getFilteringColTypeMap();
      mFilteringColFormatMap = csvdef.getFilteringColFormatMap();
    } 
  }
  
  // BUILD_FIX kmchorto 24jun05
  // This is already defined in the base class - Arnab
  // static public String METHOD_CREATE="Create";

  /**
   * Invoke a method identified by the given action.
   * 
   * @param A Map of bindingContexts that provide access to all binding 
   * related objects.
   * @param action Operartion on the datacontrol to be invoked.
   * @return true if this datacontrol has handled this action, false if the action
   * should be interpreted in the bindings framework or in the caller.
   */
  public boolean invokeOperation(java.util.Map map, oracle.binding.OperationBinding action)
  {
    mLogger.finer("Invoke method from CSV data control");
    Context ctx = null;
      
    try 
    {
      sInvokeOperationTimer.start();
        
      // We are interested of method action binding only. 
      if (action == null)
      {
         return false;
      }

      OperationInfo method = action.getOperationInfo();
      // No method defined, we are not interested.
      if (method == null)
      {
        return false;
      }

      // We'll execute only when the adapter execute is invoked
      if (METHOD_CREATE.equals(method.getOperationName()))
      {
        Object retVal = null;
        if (mConnectionName != null)
        {
          InputStream isData = null;
          
          String delim = null;
          
          if (mDelimiter.equalsIgnoreCase("{tab}"))
          {
            delim = "\t";
          }
          else if(mDelimiter.equalsIgnoreCase("{space}"))
          {
            delim = " ";
          }
          else
          {
            delim = mDelimiter;
          }
          
          String quote = null;
          if (mQuoteChar.equalsIgnoreCase("{none}"))
          {
            quote = "";
          }
          else
          {
            quote = mQuoteChar;
          }
          ctx = getAdapterContext().getConnectionContext();

          URLConnection urlConn = (URLConnection)ctx.lookup(mConnectionName);
          urlConn.open();
          
          URL connUrl = urlConn.getURL();
          String path = connUrl.getPath();

          String pathAndQuery = path;
          if (mUrlQuery != null)
          {
            Map    params     = action.getParamsMap();
            String query = Utility.substituteParamValue(mUrlQuery, params);
            pathAndQuery = path + query;
          }
          
          Object interaction = urlConn.getInteraction();
          if (interaction instanceof HTTPConnection)
          {
            HTTPConnection httpInteraction = (HTTPConnection)interaction;
            HTTPResponse resp;

            resp = httpInteraction.Get(pathAndQuery);
          
            if (resp.getStatusCode() >= 300)
            {
              mLogger.warning("Couldn't access to the data source. Cause: " + 
                                resp.getReasonLine() + resp.getText());
            }
            else
            {
              isData = resp.getInputStream();             
            }
          }
          else if (interaction instanceof FileInteraction)
          {
              FileInteraction fileInteraction = (FileInteraction)interaction;
              isData = fileInteraction.getInputStream();
          }
          
          CSVHandler csvHandler = 
             new CSVHandler(isData,mIsFirstRowNames,mEncStyle,delim,quote);
          // create the data channel to store the connection + data stream
          CSVDataChannel channel = new CSVDataChannel(isData, urlConn);
          // store the channel
          mDataChannels.add(channel);
          
          // add the data event handler 
          csvHandler.setDataEventListener(channel);

          if(mFilteringType != null  && mFilteringConditions != null)
          {
            boolean isAll = false;
            if (mFilteringType.equals(CSVDCDef.FILTER_TYPE_ALL))
            {
              isAll = true;
            }
            
            int condSize = mFilteringConditions.length;
            String[] filteringConds = new String[condSize];
            for (int i = 0; i < condSize; i++)
            {
              String condition = mFilteringConditions[i];
              Map    params     = action.getParamsMap();
              filteringConds[i] = Utility.substituteParamValue(condition, params);
            }
              
            csvHandler.setFilterConditions(isAll,filteringConds);
          }
          Map properties = new HashMap();

          properties.put(CSVHandler.FILTERING_COLTYPE_MAP, mFilteringColTypeMap);
          properties.put(CSVHandler.FILTERING_COLFORMAT_MAP, mFilteringColFormatMap);
  
          retVal = csvHandler.getResult(properties);
        }

        //map.put(method.getReturnName(), retVal);
        processResult(retVal, map, action);
        sInvokeOperationTimer.stop();
        
        return true;
      } 
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      mLogger.warning("Exception invoking method from CSV data control. Cause: " 
                       + e.toString());
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_FAILED_INVOKE_OPERATION).
        setCause(e);
    }  
    finally
    {
      sInvokeOperationTimer.cleanup();
      if (ctx != null) 
      {
        try 
        {
          ctx.close();
          ctx = null;
        }
        catch(Exception e) 
        {
          mLogger.warning("Failed to close the connection context due to:"
                                                    + e.getMessage());    
        }
      }      
    }
    
    return false;
  }
   
  /**
   * Perform request level initialization of the DataControl.
   * @param requestCtx a HashMap representing request context.  
   */
  public void beginRequest(HashMap requestCtx)
  {
  }

  /**
   * perform request level cleanup of the DataControl.
   * @param requestCtx a HashMap representing request context.
   */
  public void endRequest(HashMap requestCtx)
  {
  }

  /**
   * return false as resetState was deferred to endRequest processing
   */
  public boolean resetState()
  {
    return false;
  }

  /**
   * returns the name of the data control.
   */
  public String getName()
  {
    return mName;
  }

  /**
   * releases all references to the objects in the data provider layer 
   */
  public void release(int flags)
  {
    // close the open data channels
    int cnt = mDataChannels.size();
    for (int i = 0; i < cnt; i++)
    {
      CSVDataChannel cn = (CSVDataChannel) mDataChannels.get(i);
      if (cn != null)
      {
        cn.close();
      }
    }
  }
  
  /**
   *Return the Business Service Object that this datacontrol is associated with.
   */
  public Object getDataProvider()
  {
    return null;
  }
  
  
  /**
   * The data event listener.
   */
  private class CSVDataChannel implements FormatDataEventListener
  {
    // Input stream opened for reading
    private InputStream _openStream = null;
    // connection
    private URLConnection _conn = null;
    // if the data channel is open
    private boolean _closed = false;

    // the data stream and the connection to close
    public CSVDataChannel(InputStream isData, URLConnection conn)
    {  
      _openStream = isData;
      _conn = conn;
    }
    
    
    public void onEvent(FormatDataEvent event)
    {
      // close the channel on end of data event
      if (CSVHandler.EV_EOD.equalsIgnoreCase(event.getName()))
      {
        close();
      }
    }
    
    /**
     * Close the data stream and the open connections.
     */
    public void close()
    {
      if (_closed) return;
      mLogger.finer("Closing the URL connection.");
      try
      {
        //close the response stream of the connection once done.
        if(_openStream != null) 
        {
          _openStream.close();
          _openStream = null;
        }
        // close the connection and release it to the pool
        if (_conn != null)
        {
          _conn.close();
          _conn.release();
          _conn = null;
        }
      }
      catch(Exception e)
      {
        _openStream = null;
        _conn = null;
        mLogger.warning("Failed to release connection resources due to: " 
                        + e.getMessage());
      }          
      
      _closed = true;
    }
     
  }

}
