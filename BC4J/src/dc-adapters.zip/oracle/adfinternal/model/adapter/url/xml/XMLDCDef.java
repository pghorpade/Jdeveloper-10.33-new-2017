/* $Header: XMLDCDef.java 27-sep-2006.16:22:56 shalin Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    shalin      09/27/06 - correct perf logging usage
    jfwang      11/02/05 - XbranchMerge jfwang_fix_memory_leak from main 
    jfwang      10/24/05 - XbranchMerge jfwang_fix_urldc_performance_logging 
                           from main 
    jfwang      09/22/05 - 
    jfwang      09/22/05 - 
    jfwang      09/20/05 - 
    jfwang      09/01/05 - 
    jfwang      08/29/05 - 
    jfwang      08/25/05 - 
    jfwang      08/19/05 - 
    jfwang      08/17/05 - 
    jfwang      08/11/05 - 
    alai        08/01/05 - 
    jfwang      07/27/05 - 
    alai        07/22/05 - 
    armukher    06/23/05 - 
    jfwang      05/25/05 - 
    jfwang      05/13/05 - 
    jfwang      03/22/05 - 
    jfwang      12/22/04 - Creation
 */

/**
 *  @version $Header: XMLDCDef.java 27-sep-2006.16:22:56 shalin Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adfinternal.model.adapter.url.xml;

import java.io.InputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import oracle.adfinternal.model.adapter.url.resource.URLMessageResource;

import oracle.binding.DataControl;
import oracle.binding.meta.StructureDefinition;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.dataformat.XSDHandler;
import oracle.adf.model.adapter.utils.NodeAttributeHelper;
import oracle.adfinternal.model.adapter.url.SmartURL;
import oracle.adfinternal.model.adapter.url.resource.URLMessageArb;
import oracle.adfinternal.model.adapter.url.xml.XMLDataControl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import oracle.xml.parser.v2.XMLDocument;
import org.w3c.dom.NodeList;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.xml.parser.schema.XSDConstantValues;
import oracle.adf.model.adapter.dataformat.FormatHelper;
import oracle.adf.model.adapter.dataformat.MethodDef;
import oracle.xml.parser.v2.DOMParser;
import oracle.adfinternal.model.adapter.utils.Utility;
import HTTPClient.HTTPResponse;
import oracle.adf.model.connection.url.URLConnection;
import javax.naming.Context;
import java.net.URL;
import HTTPClient.HTTPConnection;

import java.util.logging.Level;

import oracle.adf.model.connection.url.FileInteraction;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.share.perf.Timer;

/**
 * Data control definition representing XML data. 
 */
public class XMLDCDef extends AbstractDefinition
{
  /**
   * Namespace for the metadata definition.
   */
  public static final String URLXML_NS = 
    "http://xmlns.oracle.com/adfm/adapter/url/xml";
    
  /** Definition tag as the root. */
  public static final String DEFINITION = "Definition"; //NOTRANS
  /** Attribute to contain the source URL. */
  public static final String SOURCE_LOC = "SourceLocation";        //NOTRANS
  /** Attribute to hold the connection name. */
  public static final String CONNECTION_NAME = "ConnectionName"; //NOTRANS
  /** Attribute to hold the URL query. */
  public static final String URL_QUERY = "Source"; //NOTRANS
  /** Attribute to contain the XSD URL. */
  public static final String SCHEMA_LOC = "SchemaLocation";        //NOTRANS
  /** Attribute to contain the XSL URL. */
  public static final String TRANSFORMER_LOC  = "TransformerLocation"; //NOTRANS

  /** Attribute to hold root element **/
  public static final String XML_ROOT_ELEMENT = "RootElement"; 
  
  /** Parameters tag */
  public static final String PARAMETERS = "Parameters"; //NOTRANS 
  /** Parameter tag */
  public static final String PARAMETER = "Parameter"; //NOTRANS
  /** Parameter name tag  */
  public static final String PARAMETER_NAME = "Name"; //NOTRANS
  /** Parameter Value tag  */
  public static final String PARAMETER_VALUE = "Value"; //NOTRANS
  
  // Name of the data control
  private String mName;
  // The data source can be a URL or a URL connection name.
  private String mXMLLoc;
  private String mConnectionName = null;
  private String mUrlQuery = null;

  // The XSD
  private String mXSDLoc;
  // THe XSL
  private String mXSLLoc;
  // The structure of XSD schema
  private StructureDef mStructDef = null;
  
  private Map mParamsMap = new HashMap();
  
  private String mRootElement = null;
  
  private XSDHandler mXsdHandler = null;
  
  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger(); 

  // performance sensors
  private static Timer sGetMetatdataTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/url",
                       "XMLDCDef.getMetadata",
                       "Creating the metadata for XML data control");
  private static Timer sGetStructureTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/url",
                       "XMLDCDef.getStructure",
                       "Creating the Data Control Structure definition");
  private static Timer sLoadMetadataTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/url",
                       "XMLDCDef.loadFromMetadata",
                       "Loading the data control definition from metadata");
  /////////////////// Constructors ///////////////////////////  
  /**
   * Default constructor. Used by runtime only. UI tool designer should not use.
   */
  public XMLDCDef()
  {
    
  }

  /**
   * Creats a URL XML Definition object.
   * @param name  Name of the definition.
   * @param xmlLoc XML URL location
   * @param xsdLoc XML XSD Location.
   * @param xslLoc XML XSL location.
   */
  public XMLDCDef(String name, String xsdLoc, String xslLoc)
  {
    mName = name;
    mXSDLoc = xsdLoc;
    mXSLLoc = xslLoc;
  }

  /**
   * return name of the data control
   */
  public String getDCName()
  {
    return mName;
  }

  /**
   * Gets the name of the data control implementation class for URL XML.
   */
  public String getDataControlImplName()
  {
    return "oracle.adfinternal.model.adapter.url.xml.XMLDataControl"; //NOTRANS
  }
  
  /**
   * Sets the data source location.
   * <p>
   * If the source connection name is defined, the source location value will 
   * not be used to fetch data.
   * @param loc Location of the data source.
   */
  public void setSourceLocation(String loc)
  {
    mXMLLoc = loc;
  }

  /**
   * Sets the name of the URL connection of the data source.
   * @param name Name of the connection that is used as the data source.
   */
  public void setSourceConnectionName(String name)
  {
    mConnectionName = name;
  }
    
  /**
   * Sets the query of the data source.
   * @param query of the data source.
   */
  public void setUrlQuery(String query)
  {
    mUrlQuery = query;
  }  

  /**
   * Sets the parameter Maps for the definition. 
   * The parameter name,value will be used to define the structure of the data.
   */ 
  public void setParamsMap(Map paramsMap)
  {
    mParamsMap = paramsMap;
  }
  
  /**
   * Returns the metadata definition node.
   * @return Node that represents the metadata to connect to the data source 
   *         at the runtime.
   */
  public Node getMetadata()
  { 
    mLogger.finer("Creating the metadata definitions.");
    Context ctx = null;
      
    try
    {
      sGetMetatdataTimer.start();
      XMLDocument xDoc = new XMLDocument();
      Element metadata = xDoc.createElementNS(URLXML_NS,DEFINITION);
      metadata.setAttributeNS("http://www.w3.org/2000/xmlns/",
                              XSDConstantValues._xmlns, URLXML_NS);
       
      if (mConnectionName != null)
      {
        metadata.setAttribute(CONNECTION_NAME, mConnectionName);        
      }
      else
      {
        metadata.setAttribute(SOURCE_LOC, mXMLLoc);
      }
      if (mUrlQuery != null)
      {
        metadata.setAttribute(URL_QUERY, mUrlQuery);
      }

      if (mXSDLoc != null && mXSDLoc.length() > 0)
      {
        metadata.setAttribute(SCHEMA_LOC, mXSDLoc);
      }
      if (mXSLLoc != null && mXSLLoc.length() > 0)
      { 
        metadata.setAttribute(TRANSFORMER_LOC, mXSLLoc);
      }
    
      if (mRootElement == null || mRootElement.length() == 0)
      { 
        try
        { 
          SmartURL su = new SmartURL(mXSDLoc);
          InputStream isXSDData = su.openStream();
          // create the XSDHandler to process the schema.
          mXsdHandler = new XSDHandler(getName());
          mXsdHandler.addSchema(isXSDData);
  
          List topElementsList = mXsdHandler.getTopLevelElements();
          if (topElementsList.size() >1)
          {
            InputStream isData = null;
            // if connection name is defined, we need get the data source from the URL
            // connection.
            if (mConnectionName != null)
            {
              ctx = getAdapterContext().getConnectionContext();
              URLConnection urlConn = (URLConnection)ctx.lookup(mConnectionName);
              URL connUrl = urlConn.getURL();
              String path = connUrl.getPath();
              String pathAndQuery = path;

              urlConn.open();
              Object interaction = urlConn.getInteraction();
              if (interaction instanceof HTTPConnection)
              {
                HTTPConnection httpInteraction = (HTTPConnection)interaction;              
                HTTPResponse resp;
                if (mUrlQuery != null)
                {
                  String query = Utility.substituteParamValue(mUrlQuery, mParamsMap);
                  pathAndQuery = path + query;
                }

                List paramList= Utility.getParamList(pathAndQuery);
                if (paramList.isEmpty()) 
                {
                  resp = httpInteraction.Get(pathAndQuery);
                    
                  if (resp.getStatusCode() >= 300)
                  {
                      System.err.println("Received Error: "+resp.getReasonLine());
                      System.err.println(resp.getText());
                  }
                  else
                  {
                      isData = resp.getInputStream();
                  }
                }
                  
              }
              else if (interaction instanceof FileInteraction)
              {
                FileInteraction fileInteraction = (FileInteraction)interaction;
                isData = fileInteraction.getInputStream();
              }
              if (isData != null)
              {
                DOMParser domParser = new DOMParser();
                domParser.setPreserveWhitespace(false);
                domParser.parse(isData);
                mRootElement = domParser.getDocument().
                                 getDocumentElement().getNodeName(); 
              }
            }
          }
          else 
          {
            mRootElement = (String)topElementsList.get(0);
          }
          mXsdHandler.setRootElementName(mRootElement);
        }
        catch (AdapterException ae)
        {
          throw ae;
        }
        catch (Exception e)
        {
          mLogger.warning("Exception creating structure from XML source. Cause: " 
                          + e.toString());      
          throw new AdapterException(URLMessageArb.class, 
            URLMessageResource.EXC_BAD_DEFINITION).setCause(e);
        }
        finally
        {
          if (ctx != null) 
          {
            try 
            {
              ctx.close();
              ctx = null;
            }
            catch(Exception e) 
            {
              mLogger.warning("Failed to close the connection context due to:"
                                                      + e.getMessage());    
            }
          }
          
        }
      }
    
      if (mRootElement != null && mRootElement.length() > 0)
      { 
        metadata.setAttribute(XML_ROOT_ELEMENT, mRootElement);
      } 
      
      if (mParamsMap.size() >0)
      {
        Element paramsElem = xDoc.createElementNS(URLXML_NS,PARAMETERS);
        List paramNames = new ArrayList(mParamsMap.keySet());
      
        for (Iterator names = paramNames.iterator(); names.hasNext();)
        {
          String paramName = (String) names.next();

          Element paramElem = xDoc.createElementNS(URLXML_NS,PARAMETER);
          paramElem.setAttribute(PARAMETER_NAME, paramName);
          paramElem.setAttribute(PARAMETER_VALUE, (String)mParamsMap.get(paramName));
          paramsElem.appendChild(paramElem);
        }
        metadata.appendChild(paramsElem);
      }
      sGetMetatdataTimer.stop();
      return metadata;
    }
    finally
    {
      sGetMetatdataTimer.cleanup();
    }
  }

  /**
   * Returns the structure definition.
   * @return StructureDefinition which are used by DC palette or runtime.
   */
  public StructureDefinition getStructure()
  { 
    mLogger.finer("Creating the structure definitions from the XML source.");
    try
    {
      sGetStructureTimer.start();
      
      if (mStructDef == null)
      {
        if (mXSDLoc == null)
        {
          return null;
        }
      
        if (mXsdHandler == null)
        {
          SmartURL su = new SmartURL(mXSDLoc);
          InputStream isXSDData = su.openStream();
          // create the XSDHandler to process the schema and 
          // build the structure definition.
          mXsdHandler = new XSDHandler(getName());
          mXsdHandler.addSchema(isXSDData);

          mXsdHandler.setRootElementName(mRootElement);   
        }
        // Create the root structure definition
        mStructDef = new StructureDef(getName());
      
        // get the structure helper. 
        // we need to create a virtual method for the returning collection to 
        // accept definition parameters. 
        FormatHelper.StructureHelper sh = 
               FormatHelper.getStructureHelper(mXsdHandler);
        // the root of the XML data is never a collection
        MethodDef method = sh.getRootMethod(mStructDef, false, null); 
      
        // Adding parameters
        if (mUrlQuery != null)
        {
          List paramList= Utility.getParamList(mUrlQuery);
          if (!paramList.isEmpty())
          {
            for (int i =0; i<paramList.size(); i++)
            {
              method.addParameter((String)paramList.get(i),"java.lang.String");
            }
          }
         }
         mStructDef.addMethod(method); 

      }
      sGetStructureTimer.stop();
        
      return mStructDef;
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      mLogger.warning("Exception creating structure from XML source. Cause: " 
                           + e.toString());      
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_BAD_DEFINITION).setCause(e);
    }
    finally
    {
      sGetStructureTimer.cleanup();
    }
  }

  /**
   * Loads the definition from a metadata <code>Node</code>.
   * @param node the metadata node.  
   * @param params context parameters.
   */
  public void loadFromMetadata(Node node, Map params)
  {
    try
    {
      sLoadMetadataTimer.start();
        
      // Get the information from the definition.
      NodeList listChld = node.getChildNodes();
      int cnt = listChld.getLength();
      Node chld;
      
      for (int i = 0; i < cnt; i++)
      {
        chld = listChld.item(i);
        System.out.println("Tag: " + chld.getNodeName());
        if (DEFINITION.equalsIgnoreCase(chld.getNodeName()))
        {
          // Load the required attributes
          NodeAttributeHelper attribs = 
            new NodeAttributeHelper(chld.getAttributes());

          mConnectionName = attribs.getValue(CONNECTION_NAME);
          mUrlQuery = attribs.getValue(URL_QUERY);

          mXSDLoc = attribs.getValue(SCHEMA_LOC);
          mXSLLoc = attribs.getValue(TRANSFORMER_LOC);
          mRootElement = attribs.getValue(XML_ROOT_ELEMENT);
          
          // Get the child from the definition.
          NodeList childList = chld.getChildNodes();
          int chldcnt = childList.getLength();
          Node paramschld;
          for (int j = 0; j < chldcnt; j++)
          {
            paramschld = childList.item(j);

            if (PARAMETERS.equalsIgnoreCase(paramschld.getNodeName()))
            {
              // Load the required attributes
              NodeAttributeHelper attrs = 
                new NodeAttributeHelper(paramschld.getAttributes());

              // Get the child from the parameter definition.
              NodeList paramsList = paramschld.getChildNodes();
              int paramscnt = paramsList.getLength();
              Node paramchld;
              mParamsMap.clear();
              for (int k = 0; k < paramscnt; k++)
              {
                paramchld = paramsList.item(k);
                if (PARAMETER.equalsIgnoreCase(paramchld.getNodeName()))
                {
                  // Load the required attributes
                  NodeAttributeHelper paramAttrs = 
                    new NodeAttributeHelper(paramchld.getAttributes());
                  String paramName = paramAttrs.getValue(PARAMETER_NAME);
                  String paramValue = paramAttrs.getValue(PARAMETER_VALUE);
                
                  mParamsMap.put(paramName,paramValue);
                }                
              }
            }
          }
        }
      }
      sLoadMetadataTimer.stop();
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      mLogger.warning("Exception loading metadata from CSV definition. Cause: " 
                             + e.toString());
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_FAILED_LOAD_METADATA).
        setCause(e);
    }
    finally
    {
      sLoadMetadataTimer.cleanup();
    }
  }
  
  /** 
   * Creates XML data control instance from the metadata definition.
   *
   * @return the data control instance.
   */
  public DataControl createDataControl()
  {
    XMLDataControl xmlDataControl = new XMLDataControl();
    xmlDataControl.initialize(this);
    
    return xmlDataControl;
  }

  /**
   * return the data source location.
   */
  public String getSourceLocation()
  {
    if (mXMLLoc != null && mXMLLoc.length() > 0)
    {
      return mXMLLoc;
    }
    else
    {
      return null;
    }
  }
 
  /**
   * return the XSD location.
   */
  public String getXSDLocation()
  {
    if (mXSDLoc != null && mXSDLoc.length() > 0)
    {
      return mXSDLoc;
    }
    else
    {
      return null;
    }
  }
 
  /**
   * set the XSD location.
   */
  public void setXSDLocation(String xsdLoc)
  {
    mXSDLoc = xsdLoc;
  } 
  
  /**
   * return the XSL location.
   */
  public String getXSLLocation()
  {
    if (mXSLLoc != null && mXSLLoc.length() > 0)
    {
      return mXSLLoc;
    }
    else
    {
      return null;
    }
  }
  
  /**
   * return the URL connection name.
   */
  public String getConnectionName()
  {
    return mConnectionName;
  }  
  
  /**
   * return the Url query.
   */
  public String getUrlQuery()
  {
    return mUrlQuery;
  }

  /**
   * return the Url query.
   */
  public String getRootElement()
  {
    return mRootElement;
  }
    
  /**
   * Returns the type of the adapter.
   */
  public String getAdapterType()
  {
    return "oracle.adfm.adapter.URLDataControl";
  }
  
  /** 
   * Tells the framework whether the Data control structure is dirty and needs
   * to be refreshed on the palette. 
   * @param refresh flag to indicate if the refresh is requested for the 
   * structure.
   * @return true  The XML DC implementation always returns refresh. 
   */ 
   public boolean isStructureDirty(boolean refresh) 
   { 
     return refresh; 
   } 
}
