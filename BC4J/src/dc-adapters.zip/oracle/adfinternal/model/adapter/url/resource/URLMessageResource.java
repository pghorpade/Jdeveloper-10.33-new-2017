package oracle.adfinternal.model.adapter.url.resource;

/**
 * Error messages for the WebService Data Control
 * 
 * @author Vinay Pamadi
 */
public final class URLMessageResource
{    
  public static final String EXC_BAD_DEFINITION                = "50000";
  public static final String EXC_FAILED_OPEN_SOURCE           = "50001";
  public static final String EXC_TIMEOUT_SOURCE   = "50002";
  public static final String EXC_BAD_URL        = "50003";
  public static final String EXC_STAT_URLACCESS       = "50004";
  public static final String EXC_FAILED_LOAD_METADATA        = "50005";
  public static final String EXC_FAILED_INVOKE_OPERATION       = "50006";
}
