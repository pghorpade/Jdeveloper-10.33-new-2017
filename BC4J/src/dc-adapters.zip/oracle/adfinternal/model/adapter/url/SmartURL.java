/* $Header: SmartURL.java 14-sep-2005.11:44:50 jfwang Exp $ */

/* Copyright (c) 2004, 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jfwang      09/14/05 - 
    jfwang      08/25/05 - 
    jfwang      12/20/04 - jfwang_dcadapter
    jfwang      12/20/04 - Creation
 */

/**
 *  @version $Header: SmartURL.java 14-sep-2005.11:44:50 jfwang Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adfinternal.model.adapter.url;

import java.io.File;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import HTTPClient.HTTPConnection;
import HTTPClient.HTTPResponse;
import HTTPClient.URI;

import oracle.adf.model.adapter.AdapterException;
import oracle.adfinternal.model.adapter.url.resource.URLMessageArb;
import oracle.adf.model.utils.SimpleStringBuffer;

import oracle.adfinternal.model.adapter.url.resource.URLMessageResource;

/**
 * Handles URL connections.
 * <p>
 * Different adapters and data controls will use this class to access a URL.
 * This class can handle the HTTP and HTTPS protocols. It uses the proxy
 * set by the application that runs it.
 *
 * @since 10.1.3
 */
public class SmartURL 
{
  /** Source location. */
  private String mLocation;
  
  /** timeout limit for the connection - 30 second. */
  private static final int TIMEOUT_LIMIT = 30; 
  private int mTimeout = TIMEOUT_LIMIT * 1000;
  
  // Context path for the servlet.
  private String mServletCtxPath = null;
  
  /**
   * Creates the URL object for a location.
   * @param loc Source location for the URL.
   */
  public SmartURL(String loc)
  {
    mLocation = loc;
  }

  /**
   * Creates the URL object for a location.
   * @param loc Source location for the URL.
   * @param servletCtxPath Context path for the servlet.
   */
  public SmartURL(String loc, String servletCtxPath)
  {
    mLocation = loc;
    mServletCtxPath = servletCtxPath;
  }
  
  /**
   * Sets the timeout for the connection. The default is 30 seconds.
   * @param timeout Timeout amount in miliseconds.
   */
  public void setTimeout(int timeout)
  {
    mTimeout = timeout;
  }
   
  /**
   * Open an <code>InputStream</code> for a location. 
   * 
   * If the location points to a http or https file, this method tries to 
   * connect to the file.
   * The location can be a file name as well. This method tries to 
   * create a URL from the location. If fails it will treat the location as a 
   * file name and tries to create a URL for the file. If the file path is not 
   * an absolute path defined, It tries to resolve the name as relative to the 
   * provider home. If fails it then tries to create a URL from the file path 
   * as known to the system.
   *
   * @return Opened input stream of the file specified by the location. 
   * @throws AdapterException If the connection failed or no URL can be formed
   *         from the location.
   */
  public InputStream openStream() throws AdapterException
  {
    InputStream isRet = null;
    try
    {
      // 
      // We will try to open as a URL. If we can't then it could be a file name
      // and we will create the URL by calling cretaeURL(...).
      // If the URL is well formed, we will check the protocol. For http, we can 
      // use HttpClient classes to set the proxy info. 
      //

      try
      {
        // Create an URI, if no protocol is defined (i.e. a relative file name)
        // it will throw ParseException. We will handle this by calling 
        // createURL call.
        URI uri = new URI(mLocation);

        // Now check if it's of http protocol.
        if (uri.getScheme().equalsIgnoreCase("http") ||
            uri.getScheme().equalsIgnoreCase("https"))
        {
          // We assume that the proxy is already set for the environment. 
        
          // Now create the HttpConnection and set the proxy         
          HTTPConnection connection = null;
          try
          {
            connection = new HTTPConnection(uri);
            connection.setTimeout(mTimeout);
            // DO not allow the interaction to pop up dialogs and messages.
            connection.setAllowUserInteraction(false);

            // Get the response input stream
            HTTPResponse response = connection.Get(uri.getPathAndQuery());
            checkStatus(response);

            isRet = response.getInputStream();
          }
          catch (java.io.InterruptedIOException iioe)
          {
            if (null != connection)
            {
              connection.stop();
            }

            throw new AdapterException(URLMessageArb.class, 
              URLMessageResource.EXC_TIMEOUT_SOURCE).setCause(iioe);
          }
          catch (Throwable e)
          {
            throw new AdapterException(URLMessageArb.class, 
              URLMessageResource.EXC_FAILED_OPEN_SOURCE,
              new Object[]{mLocation}).setCause(e);
          }
        }
        else
        {
          // It is not a http. So we can not use HttpConnection class to set the 
          // proxy. In this case we will call the createURL to create the url by
          // handling other issues for file location.
          // Note: We are not handling ftp and other protocols separately for the
          // proxy setting though. We may look at this later.

          return createURL().openStream();
        }
      }
      catch (AdapterException ae)
      {
        throw ae;
      }
      catch (HTTPClient.ParseException ex)
      {
        return createURL().openStream();
      }
      finally
      {
      }
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Throwable e)
    {
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_BAD_URL,
        new Object[]{mLocation}).setCause(e);
    }

    return isRet;  
  }

  /**
   * Createa an URL object.
   * @return Created URL. This method tries to connect the URL also to check 
   *         the validity of the location. So the returned URL will be in 
   *         connected state. 
   * @exception AdapterException If the connection failed or no URL can be formed
   *         from the location.   */
  public URL createURL() throws AdapterException
  {
    if (null != mLocation)
    {
      URL url = null;

      try
      {
        url = new URL(mLocation);
        url.openConnection().connect();
        return url;
      }
      catch (MalformedURLException ex)
      {
        //
        // We'll try to form the absolute path of this file w.r.t. the current
        // servlet context
        //

        // Try to get the session if present, but will not create any
        if (null != mServletCtxPath)
        {
          // Prepend this to the name supplied
          String fs = System.getProperty("file.separator");
          char sep = '/';
          if (fs.length() == 1)
          {
            sep = fs.charAt(0);
          }

          SimpleStringBuffer sbFileName = new SimpleStringBuffer(250);
          sbFileName.append(mServletCtxPath);
          // If the location doesn't start with a file separator add one.
          if ((mLocation.charAt(0) != sep) && 
              (mServletCtxPath.charAt(mServletCtxPath.length() - 1) != sep))
          {
            sbFileName.append(sep);
          }
          sbFileName.append(mLocation);
          String fileLoc = createFileURLPath(sbFileName.toString());

          // Now try to create a URL from this
          try
          {
            url = new URL(fileLoc);
            url.openConnection().connect();
            return url;
          }
          catch (Exception e)
          { 
            // we can not form a URL yet. We will ignore it because the fall 
            // through code will try the file name as reported by the file object. 

            // Falling through
          }
        }

        File f = new File(mLocation);
        String fileLoc = createFileURLPath(f.getAbsolutePath()); 
        try
        {
          url = new URL(fileLoc);
          url.openConnection().connect();
          return url;
        }
        catch (Exception e)
        {
          throw new AdapterException(URLMessageArb.class,
            URLMessageResource.EXC_BAD_URL,
            new Object[]{mLocation});
        }
      }
      catch(Exception excp)
      {
        throw new AdapterException(URLMessageArb.class,
          URLMessageResource.EXC_BAD_URL,
          new Object[] { mLocation });
      }
    }
    return null;
  }
  
  ///////////////////////////// Class Helpers //////////////////////////////////  
  
  /**
   * Checks the return status of a HTTP respoonse.
   * @param response The response to check.
   * @exception Exception is status returned an error.
   */
  private static void checkStatus(HTTPResponse response)
    throws Exception
  {
    int statCode = 0; 
    try
    {
      statCode = response.getStatusCode();

      if (statCode >= 300)
      {
        // If the status is 401, i.e. authorization required, we'll throw a 
        // specific exception. This will help the caller of this class to take
        // appropreate action.
        String strReason = new SimpleStringBuffer(250)
          .append(statCode).append(" - ")
          .append(response.getReasonLine())
          .toString();

        throw new AdapterException(URLMessageArb.class, 
          URLMessageResource.EXC_STAT_URLACCESS,
          new Object[]{strReason});
      }
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
  }

  /**
   * Create the url string from the file path.
   * @param path The file path to convert to a URL.
   * @return URL for the file path provided.
   */
  private String createFileURLPath(String path)
  {
    String fs = System.getProperty("file.separator");
    
    if (fs.length() == 1)
    {
      char sep = fs.charAt(0);
      
      if (sep != '/')
      {
        path = path.replace(sep, '/');
      }
    }
      
    if (path.charAt(0) != '/')
    {
      path = new SimpleStringBuffer(100).append('/').append(path).toString();
    }
    
    path = new SimpleStringBuffer(100).append("file://").
      append(path).toString();
    
    return path;
  }


}