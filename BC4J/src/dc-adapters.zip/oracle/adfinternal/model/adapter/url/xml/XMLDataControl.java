/* $Header: XMLDataControl.java 27-sep-2006.16:22:56 shalin Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    shalin      09/27/06 - correct perf logging usage
    vpamadi     08/18/06 - 
    armukher    06/23/06 - Backport armukher_urldc_accept_relative_path from 
                           main 
    jfwang      11/02/05 - XbranchMerge jfwang_fix_memory_leak from main 
    jfwang      10/24/05 - XbranchMerge jfwang_fix_urldc_performance_logging 
                           from main 
    armukher    06/20/06 - 
    jfwang      09/07/05 - 
    jfwang      08/25/05 - 
    jfwang      08/19/05 - 
    jfwang      08/17/05 - 
    vpamadi     08/08/05 - 
    alai        07/22/05 - 
    armukher    07/12/05 - 
    jfwang      06/08/05 - 
    jfwang      06/06/05 - 
    jfwang      05/13/05 - 
    jfwang      03/22/05 - 
    jfwang      12/20/04 - Creation
 */

/**
 *  @version $Header: XMLDataControl.java 27-sep-2006.16:22:56 shalin Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adfinternal.model.adapter.url.xml;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import oracle.adfinternal.model.adapter.url.resource.URLMessageResource;

import oracle.binding.DataControl;
import oracle.binding.OperationInfo;

import oracle.adf.model.adapter.dataformat.FormatDataEventListener;
import oracle.adf.model.adapter.dataformat.FormatDataEvent;
import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.AbstractImpl;
import oracle.adf.model.adapter.dataformat.XMLHandler;
import oracle.adf.model.utils.SimpleStringBuffer;

import oracle.adfinternal.model.adapter.url.xml.XMLDCDef;
import oracle.adfinternal.model.adapter.url.SmartURL;
import HTTPClient.HTTPResponse;
import oracle.adf.model.connection.url.URLConnection;
import javax.naming.Context;
import HTTPClient.HTTPConnection;
import oracle.adf.model.adapter.AdapterException;
import oracle.adfinternal.model.adapter.url.resource.URLMessageArb;
import java.net.URL;

import java.util.logging.Level;
import java.util.ArrayList;

import oracle.adf.share.ADFContext;

import oracle.adfinternal.model.adapter.utils.Utility;
import oracle.adf.model.connection.url.FileInteraction;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.share.perf.Timer;

/**
 * Data control that represents a URL data source with XML data format.
 */
public class XMLDataControl extends AbstractImpl implements DataControl
{
  // xml url
  private String mConnectionName;
  // xml xsd 
  private String mXSDLocation;
  // xml xsl
  private String mXSLLocation;
  // url query
  private String mUrlQuery;
 
  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger(); 

  // List of open connection + data stream listeners. We may need to close 
  // them as the session ends.
  private ArrayList mDataChannels = new ArrayList(20);

  // performance sensors
  private static Timer sInvokeOperationTimer = Timer.createTimer(Level.FINER,
                       "/oracle/adf/model/adapter/url",
                       "XMLDataControl.invokeOperation",
                       "Invoking operation in URL Data Control");
  
  /**
   * constructor
   */
  public XMLDataControl()
  {
  }
  
  /**
   * Initialize the data control to get attributes of data control definition.
   * @param context
   * @param node source node that represents the metadata to connect to 
   * the data source
   */
  public void initialize(AbstractDefinition dcDef)
  { 
    if (dcDef instanceof XMLDCDef)
    {
      XMLDCDef xmldef = (XMLDCDef)dcDef;
      mConnectionName = xmldef.getConnectionName();
      mUrlQuery = xmldef.getUrlQuery();
      mXSDLocation = xmldef.getXSDLocation();
      mXSLLocation = xmldef.getXSLLocation();
    } 
  }
    
  /**
   * Invoke a method identified by the given action.
   * 
   * @param A Map of bindingContexts that provide access to all binding 
   * related objects.
   * @param action Operartion on the datacontrol to be invoked.
   * @return true if this datacontrol has handled this action, false if the action
     * should be interpreted in the bindings framework or in the caller
   */
  public boolean invokeOperation(java.util.Map map, oracle.binding.OperationBinding action)
  {
    mLogger.finer("Invoke method from XML data control");
    Context ctx = null;
      
    try
    {
      sInvokeOperationTimer.start();
        
      if (action != null && action.getOperationInfo() != null) 
      {        
        Map properties = new HashMap();

        properties.put(XMLDCDef.SCHEMA_LOC, mXSDLocation);
        properties.put(XMLDCDef.TRANSFORMER_LOC, mXSLLocation);

        Object retVal = null;
        InputStream isXSLStream = null;
        
        if (mXSLLocation != null)
        {
          SmartURL su = new SmartURL(mXSLLocation);
          isXSLStream = su.openStream();
        }
       
        InputStream isData = null;
        // if connection name is defined, we need get the data source from the URL
        // connection.
        if (mConnectionName != null)
        {
          // TODO: get isData from the URL connection.
          ctx = ADFContext.getCurrent().getConnectionsContext();
          URLConnection urlConn = (URLConnection)ctx.lookup(mConnectionName);
          urlConn.open();
          
          URL connUrl = urlConn.getURL();
          String path = connUrl.getPath();

          String pathAndQuery = path;
          Object interaction = urlConn.getInteraction();
          if (interaction instanceof HTTPConnection)
          {
            HTTPConnection httpInteraction = (HTTPConnection)interaction;                  
            HTTPResponse resp;
            if (mUrlQuery != null)
            {
              Map    params     = action.getParamsMap();
              String query = Utility.substituteParamValue(mUrlQuery, params);
              pathAndQuery = path + query;
            }

            resp = httpInteraction.Get(pathAndQuery);
                 
            if (resp.getStatusCode() >= 300)
            {
              mLogger.warning("Couldn't access to the data source. Cause: " + 
                                  resp.getReasonLine() + resp.getText());
            }
            else 
            {
              isData = resp.getInputStream();
            }
          }
          else if (interaction instanceof FileInteraction)
          {
            FileInteraction fileInteraction = (FileInteraction)interaction;
            isData = fileInteraction.getInputStream();
          }
          XMLHandler xmlHandler = 
            new XMLHandler(isData, isXSLStream, false);

          // create the data channel to store the connection + data stream
          XMLDataChannel channel = new XMLDataChannel(isData, urlConn);
          // store the channel
          mDataChannels.add(channel);
          // add the data event handler 
          xmlHandler.setDataEventListener(channel);

          retVal = xmlHandler.getResult(properties);     
        }

        processResult(retVal, map, action);
        sInvokeOperationTimer.stop();

        return true;
      }
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      mLogger.warning("Exception invoking method from XML data control. Cause: " 
                         + e.toString());
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_FAILED_INVOKE_OPERATION).
        setCause(e);
    }
    finally
    {
      sInvokeOperationTimer.cleanup();
      if (ctx != null) 
      {
        try 
        {
          ctx.close();
          ctx = null;
        }
        catch(Exception e) 
        {
          mLogger.warning("Failed to close the connection context due to:"
                                                    + e.getMessage());    
        }
      }     
    }

     return false;
  }
 
  /**
   * returns the name of the data control.
   */ 
  public String getName()
  {
    return mName;
  }

  /**
   * releases all references to the objects in the data provider layer 
   */
  public void release(int flags)
  {
    // close the open data channels
    int cnt = mDataChannels.size();
    for (int i = 0; i < cnt; i++)
    {
      XMLDataChannel cn = (XMLDataChannel) mDataChannels.get(i);
      if (cn != null)
      {
        cn.close();
      }
    }
  }
 
  /**
   *Return the Business Service Object that this datacontrol is associated with.
   */ 
  public Object getDataProvider()
  { 
    return null;
  }


   
  /**
   * The data event listener.
   */
  private class XMLDataChannel implements FormatDataEventListener
  {
    // Input stream opened for reading
    private InputStream _openStream = null;
    // connection
    private URLConnection _conn = null;
    // if the data channel is open
    private boolean _closed = false;

    // the data stream and the connection to close
    public XMLDataChannel(InputStream isData, URLConnection conn)
    {  
      _openStream = isData;
      _conn = conn;
    }
    
    
    public void onEvent(FormatDataEvent event)
    {
      // close the channel on end of data event
      if (XMLHandler.EV_EOD.equalsIgnoreCase(event.getName()))
      {
        close();
      }
    }
    
    /**
     * Close the data stream and the open connections.
     */
    public void close()
    {
      if (_closed) return;
      mLogger.finer("Closing the URL connection.");
      try
      {
        //close the response stream of the connection once done.
        if(_openStream != null) 
        {
          _openStream.close();
          _openStream = null;
        }
        // close the connection and release it to the pool
        if (_conn != null)
        {
          _conn.close();
          _conn.release();
          _conn = null;
        }
      }
      catch(Exception e)
      {
        _openStream = null;
        _conn = null;
        mLogger.warning("Failed to release connection resources due to: " 
                        + e.getMessage());
      }          
      
      _closed = true;
    }
     
  }

  
}
