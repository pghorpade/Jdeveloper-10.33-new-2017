/* $Header: CSVDCDef.java 27-sep-2006.16:22:32 shalin Exp $ */

/* Copyright (c) 2004, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    shalin      09/27/06 - correct perf logging usage
    jfwang      11/02/05 - XbranchMerge jfwang_fix_memory_leak from main 
    jfwang      10/24/05 - XbranchMerge jfwang_fix_urldc_performance_logging 
                           from main 
    jfwang      08/29/05 - 
    jfwang      08/25/05 - 
    jfwang      08/17/05 - 
    jfwang      08/10/05 - 
    jfwang      08/01/05 - 
    jfwang      07/27/05 - 
    alai        07/22/05 - 
    jfwang      07/20/05 - 
    armukher    06/30/05 - 
    armukher    06/28/05 - 
    armukher    06/22/05 - 
    jfwang      06/15/05 - 
    jfwang      06/13/05 - 
    jfwang      06/07/05 - 
    jfwang      06/06/05 - 
    dmutreja    05/31/05 - 
    jfwang      03/31/05 - 
    jfwang      03/25/05 - 
    jfwang      12/22/04 - Creation
 */

/**
 *  @version $Header: CSVDCDef.java 27-sep-2006.16:22:32 shalin Exp $
 *  @author  jfwang  
 *  @since   release specific (what release of product did this appear in)
 */

package oracle.adfinternal.model.adapter.url.csv;

import HTTPClient.HTTPConnection;
import HTTPClient.HTTPResponse;
import java.io.InputStream;

import java.net.URL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import oracle.adf.model.adapter.dataformat.csv.ConditionDefinition;

import oracle.adfinternal.model.adapter.url.resource.URLMessageResource;

import oracle.binding.DataControl;
import oracle.binding.meta.StructureDefinition;
import oracle.binding.meta.ParameterDefinition;

import javax.naming.Context;
import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.dataformat.CSVHandler;
import oracle.adf.model.adapter.dataformat.FormatHelper;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.dataformat.MethodDef;
import oracle.adf.model.connection.url.URLConnection;
import oracle.adf.model.meta.DataControlDefinition;
import oracle.adf.model.utils.SimpleStringBuffer;
import oracle.adf.model.adapter.utils.NodeAttributeHelper;

import oracle.adfinternal.model.adapter.url.csv.CSVDataControl;
import oracle.adfinternal.model.adapter.url.resource.URLMessageArb;

import oracle.adfinternal.model.adapter.utils.Utility;

import oracle.xml.parser.schema.XSDConstantValues;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import oracle.xml.parser.v2.XMLDocument;
import java.util.List;
import java.util.logging.Level;

import oracle.adf.model.connection.url.FileInteraction;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.model.adapter.AdapterContext;
import oracle.adf.share.perf.Timer;

/**
 * Data control definition representing CSV data.
 * @param params
 * @param node
 */
public class CSVDCDef extends AbstractDefinition
{
  // Name of the root accessor or the method for a definition
  public static final String RESULT_ACC_NAME = "Result";

  /**
   * Namespace for the metadata definition.
   */
  public static final String URLCSV_NS = 
    "http://xmlns.oracle.com/adfm/adapter/url/csv"; //NOTRANS
  
  /** Definition tag as the root. */
  public static final String DEFINITION = "Definition"; //NOTRANS
  /** Conditions tag  */
  public static final String FILTERCONDITIONS = "Conditions"; //NOTRANS
  /** Conditions tag  */
  public static final String FILTERCONDITION = "Condition"; //NOTRANS
  /** Column tag as filtering condition. */
  public static final String FILTERCOLUMN = "Column"; //NOTRANS
  /** Operator tag  */
  public static final String FILTEROPERATOR = "Operator"; //NOTRANS
  /** Value tag  */
  public static final String FILTERVALUE = "Value"; //NOTRANS
  /** CompareType tag  */
  public static final String FILTERCOMPARETYPE = "CompareType"; //NOTRANS
  /** DataFormat tag  */
  public static final String FILTERDATAFORMAT = "DataFormat"; //NOTRANS
  /** Attribute to contain the filtering match type. */
  public static final String FILTERTYPE = "MatchType"; //NOTRANS
  /** Filtering type - all  */
  public static final String FILTER_TYPE_ALL = "all"; //NOTRANS
  /** Filtering type - any  */
  public static final String FILTER_TYPE_ANY = "any"; //NOTRANS
  
  /** Attribute to contain the source URL. */
  public static final String SOURCE_LOC = "SourceLocation"; //NOTRANS
  /** Attribute to hold the connection name. */
  public static final String CONNECTION_NAME = "ConnectionName"; //NOTRANS
  /** Attribute to hold the URL query. */
  public static final String URL_QUERY = "Source"; //NOTRANS
  
  /** Attribute to contain if the first row will be treated as column names. */
  public static final String IS_FIRST_ROW_NAMES = "IsFirstRowNames"; //NOTRANS
  /** Encoding style of the data. */
  public static final String ENC_STYLE = "Encoding"; //NOTRANS
  /** Delimiter used in the CSV file */
  public static final String DELIMITER = "Delimiter"; //NOTRANS
  /** Character used to denote a quoted text */
  public static final String QUOTE_CHAR = "QuoteChar"; //NOTRANS
 
  /** Parameters tag */
  public static final String PARAMETERS = "Parameters"; //NOTRANS 
  /** Parameter tag */
  public static final String PARAMETER = "Parameter"; //NOTRANS
  /** Parameter name tag  */
  public static final String PARAMETER_NAME = "Name"; //NOTRANS
  /** Parameter Value tag  */
  public static final String PARAMETER_VALUE = "Value"; //NOTRANS
  
  //////////////////// Class variables ///////////////////////
  // Name of the data control
  private String mName;
  
  // The data source can be a URL or a URL connection name.
  private String mSourceLoc = null;
  private String mConnectionName = null;
  private String mUrlQuery = null;
  
  private boolean mIsFirstRowNames = false;
  private String mEncStyle;
  // Character value separator 
  private String mDelimiter;
  // Character used to quote a multi-word string
  private String mQuoteChar;
  
  // the structure definition
  private StructureDef mStructDef = null;
  
  // filtering match type 
  private String mMatchType;
  
  //filtering conditions
  private ArrayList mFilterConditions = new ArrayList();
  
  // filtering col-type map
  private Map mFilteringColTypeMap = new HashMap();
 
  // filtering col-type map
  private Map mFilteringColFormatMap = new HashMap();
  
  // Param names
  private ParameterDefinition[] mParams = null;

  private Map mParamsMap = new HashMap();

  private ADFLogger mLogger = AdapterContext.getDefaultContext().getLogger(); 
  
  // performance sensors
  private static Timer sGetStructureTimer = Timer.createTimer(Level.FINER,
                     "/oracle/adf/model/adapter/url",
                     "CSVDCDef.getStructure",
                     "Creating the Data Control Structure definition");
  private static Timer sLoadFromMetadataTimer = Timer.createTimer(Level.FINER,
                     "/oracle/adf/model/adapter/url",
                     "CSVDCDef.loadFromMetadata",
                     "Loading the data control definition from metadata");

  /////////////////// Constructors ///////////////////////////  
  /**
   * Default constructor. Used by runtime only. UI tool designer should not use.
   */
  public CSVDCDef()
  {
    
  }

  /**
   * Creats a URL CSV Definition object.
   * @param name  Name of the definition.
   * @param isFirstRowNames Flag to indicate if the first row of the CSV data 
   *        can be treated as column names.
   * @param encodingStyle Encoding style of the data.
   * @param delim Character value separators.
   */
  public CSVDCDef(String name, boolean isFirstRowNames, String encodingStyle,
                  String delim, String quoteChar)
  {
    super();
    mName = name;
    mIsFirstRowNames = isFirstRowNames;
    mEncStyle = encodingStyle;
    mDelimiter = delim;
    mQuoteChar = quoteChar;
  } 

  /**
   * Sets the parameter names for the definition. 
   * The parameter names will be used to define the structure of the data.
   */
  public void setParameters(ParameterDefinition[] params)
  {    
    mParams = params;
  }
  
  /**
   * Sets the name of the URL connection of the data source.
   * @param name Name of the connection that is used as the data source.
   */
  public void setSourceConnectionName(String name)
  {
    mConnectionName = name;
  }
  
  /**
   * Sets the data source location.
   * <p>
   * If the source connection name is defined, the source location value will 
   * not be used to fetch data.
   * @param loc Location of the data source.
   */
  public void setSourceLocation(String loc)
  {
    mSourceLoc = loc;
  }

  /**
   * Sets the query part of the data source.
   * @param urlQuery URL query of the data source.
   */
  public void setUrlQuery(String urlQuery)
  {
    mUrlQuery = urlQuery;
  }
  
  /**
   * Indicates that what is supported by csv data control.
   * @return returns true if flag is for sorting which
   *  indicates sorting is supported for CSV data control.
   */
  public boolean isSupported(String flag)
  {
    if (DataControlDefinition.SUPPORTS_SORT_COLLECTION.equals(flag))
    {
      return true;
    }

    return super.isSupported(flag);
  } 
  
  /**
   * Sets the parameter Maps for the definition. 
   * The parameter name,value will be used to define the structure of the data.
   */ 
  public void setParamsMap(Map paramsMap)
  {
    mParamsMap = paramsMap;
  }

  /**
   * Tells the framework to load from the serialized bean XML
   */
  public boolean usePersistedStructure()
  {
    return true;
  }

  
  /**
   * Returns the metadata definition node.
   * @return Node that represents the metadata to connect to the data source 
   *         at the runtime.
   */
  public Node getMetadata()
  {     
    XMLDocument xDoc = new XMLDocument();
    Element metadata = xDoc.createElementNS(URLCSV_NS,DEFINITION);
    metadata.setAttributeNS("http://www.w3.org/2000/xmlns/",XSDConstantValues._xmlns, URLCSV_NS);

    if (mConnectionName == null)
    {
      metadata.setAttribute(SOURCE_LOC, mSourceLoc);    
    }
    else 
    {
      metadata.setAttribute(CONNECTION_NAME, mConnectionName);        
    }
    if (mUrlQuery != null)
    {
      metadata.setAttribute(URL_QUERY, mUrlQuery);
    }
    metadata.setAttribute(DELIMITER, mDelimiter);
    
    metadata.setAttribute(QUOTE_CHAR, mQuoteChar);
    metadata.setAttribute(IS_FIRST_ROW_NAMES, String.valueOf(mIsFirstRowNames));
    metadata.setAttribute(ENC_STYLE, mEncStyle);    
    
    if (mParamsMap.size() >0)
    {
      Element paramsElem = xDoc.createElementNS(URLCSV_NS,PARAMETERS);
      List paramNames = new ArrayList(mParamsMap.keySet());
      
      for (Iterator names = paramNames.iterator(); names.hasNext();)
      {
        String paramName = (String) names.next();

        Element paramElem = xDoc.createElementNS(URLCSV_NS,PARAMETER);
        paramElem.setAttribute(PARAMETER_NAME, paramName);
        paramElem.setAttribute(PARAMETER_VALUE, (String)mParamsMap.get(paramName));
        paramsElem.appendChild(paramElem);
      }
      metadata.appendChild(paramsElem);
    }
    Element conditionsElem = null;
    if (mFilterConditions.size() >0)
    {
      conditionsElem = xDoc.createElementNS(
                                 CSVDCDef.URLCSV_NS, CSVDCDef.FILTERCONDITIONS);     
      conditionsElem.setAttribute(CSVDCDef.FILTERTYPE, mMatchType);

    }
    
    for (int i = 0; i<mFilterConditions.size();i++)
    {
      Element filterElem = xDoc.createElementNS(
                             CSVDCDef.URLCSV_NS, CSVDCDef.FILTERCONDITION);
      ConditionDefinition condDef = (ConditionDefinition)mFilterConditions.get(i);
      String colName = condDef.getColumn();
      String colOperator = condDef.getOperator();
      String colValue = condDef.getValue();
      String colType = condDef.getType();
      String colFormat = condDef.getFormat();
      
      filterElem.setAttribute(FILTERCOLUMN, colName);
      filterElem.setAttribute(FILTEROPERATOR, colOperator);
      filterElem.setAttribute(FILTERVALUE, colValue);
      filterElem.setAttribute(FILTERCOMPARETYPE,colType);
      if (colFormat != null && colFormat.trim().length() != 0)
      {
        filterElem.setAttribute(CSVDCDef.FILTERDATAFORMAT,colFormat);
      }

      conditionsElem.appendChild(filterElem);                       
    }
    
    if (conditionsElem != null)
    {
      metadata.appendChild(conditionsElem);
    }
    return metadata;
  }
  
  /**
   * Returns the structure definition.
   * @return StructureDefinition which are used by DC palette or runtime.
   */
  public StructureDefinition getStructure()
  {
    mLogger.finer("Creating the structure definitions from the CSV source.");
    Context ctx = null;
    try
    {
      sGetStructureTimer.start();
        
      if (mStructDef == null)
      {
        if ((mSourceLoc == null) && (mConnectionName == null))
          return null;
    
        InputStream isData = null;
        // if connection name is defined, we need get the data source from the URL
        // connection.
        if (mConnectionName != null)
        {
          ctx = getAdapterContext().getConnectionContext();
          URLConnection urlConn = (URLConnection)ctx.lookup(mConnectionName);
          URL connUrl = urlConn.getURL();
          String path = connUrl.getPath();
          String pathAndQuery = path;

          urlConn.open();
                
          if (mUrlQuery != null)
          {
            String query = Utility.substituteParamValue(mUrlQuery, mParamsMap);
            pathAndQuery = path + query;
          }
          Object interaction = urlConn.getInteraction();
          if (interaction instanceof HTTPConnection)
          {
            HTTPConnection httpInteraction = (HTTPConnection)interaction;
            
            HTTPResponse resp;
            resp = httpInteraction.Get(pathAndQuery);
        
            if (resp.getStatusCode() >= 300)
            {
              System.err.println("Received Error: "+resp.getReasonLine());
              System.err.println(resp.getText());
            }
            else
            {
              isData = resp.getInputStream();
            }
          }
          else if (interaction instanceof FileInteraction)
          {
            FileInteraction fileInteraction = (FileInteraction)interaction;
            isData = fileInteraction.getInputStream();
          }
          String delim = null;
       
          if (mDelimiter.equalsIgnoreCase("{tab}"))
          {
            delim = "\t";
          }
          else if(mDelimiter.equalsIgnoreCase("{space}"))
          {
            delim = " ";
          }
          else
          {
            delim = mDelimiter;
          }
  
          String quote = null;
          if (mQuoteChar.equalsIgnoreCase("{none}"))
          {
            quote = "";
          }
          else
          {
            quote = mQuoteChar;
          }
  
          CSVHandler csvHandler = 
          new CSVHandler(isData,mIsFirstRowNames,mEncStyle,delim,quote);
    
          // Create the root structure definition
          mStructDef = new StructureDef(getName());
          // get the structure helper. 
          // we need to create a virtual method for the returning collection to 
          // accept definition parameters. 
          FormatHelper.StructureHelper sh = 
                 FormatHelper.getStructureHelper(csvHandler);
          MethodDef method = sh.getRootMethod(mStructDef, true, null); 

          // add the parameters
          List paramList = new ArrayList(mParamsMap.keySet());
          if (!paramList.isEmpty())
          {
            for (int i =0; i<paramList.size(); i++)
            {
              method.addParameter((String)paramList.get(i),"java.lang.String");
            }
          }

          for (int i = 0; i<mFilterConditions.size();i++)
          {
            ConditionDefinition cond = 
               (ConditionDefinition)mFilterConditions.get(i);
            String condVal =  cond.getValue();
            List condParamList = Utility.getParamList(condVal);
            if (!condParamList.isEmpty())
            {
              for (int j =0; j<condParamList.size(); j++)
              {
                method.addParameter((String)condParamList.get(j),"java.lang.String");
              }
            }
          }
          mStructDef.addMethod(method); 

          urlConn.close();
          urlConn.release();
        }
      }
      sGetStructureTimer.stop();
      return mStructDef;
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    {
      mLogger.warning("Exception creating structure from CSV source. Cause: " 
                           + e.toString());
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_BAD_DEFINITION).setCause(e);
    } 
    finally
    {
      sGetStructureTimer.cleanup();
      if (ctx != null) 
      {
        try 
        {
          ctx.close();
          ctx = null;
        }
        catch(Exception e) 
        {
          mLogger.warning("Failed to close the connection context due to:"
                                                  + e.getMessage());    
        }
      }
    }
  }
  
  /**
   * Loads the definition from a metadata <code>Node</code>.
   * @param node the metadata node.  
   * @param params context parameters.
   */
  public void loadFromMetadata(Node node, Map params)
  {
    try
    {
      sLoadFromMetadataTimer.start();
        
      // Get the information from the definition.
      NodeList listChld = node.getChildNodes();
      int cnt = listChld.getLength();
      Node chld;
      
      for (int i = 0; i < cnt; i++)
      {
        chld = listChld.item(i);
        //System.out.println("Tag: " + chld.getNodeName());
        if (DEFINITION.equalsIgnoreCase(chld.getNodeName()))
        {
          // Load the required attributes
          NodeAttributeHelper attribs = 
            new NodeAttributeHelper(chld.getAttributes());

          mConnectionName = attribs.getValue(CONNECTION_NAME);
          mUrlQuery = attribs.getValue(URL_QUERY);
          mEncStyle = attribs.getValue(ENC_STYLE);
          String val = attribs.getValue(IS_FIRST_ROW_NAMES);
          if ("true".equalsIgnoreCase(val))
          {
            mIsFirstRowNames = true;
          }
          else mIsFirstRowNames = false;
          
          mDelimiter = attribs.getValue(DELIMITER);

          mQuoteChar = attribs.getValue(QUOTE_CHAR);
          
          // Get the child from the definition.
          NodeList childList = chld.getChildNodes();
          int chldcnt = childList.getLength();
          Node conditionschld;
          for (int j = 0; j < chldcnt; j++)
          {
            conditionschld = childList.item(j);
            if (FILTERCONDITIONS.equalsIgnoreCase(conditionschld.getNodeName()))
            {
              // Load the required attributes
              NodeAttributeHelper attrs = 
                new NodeAttributeHelper(conditionschld.getAttributes());

              mMatchType = attrs.getValue(FILTERTYPE);
              // Get the child from the definition.
              NodeList filteringList = conditionschld.getChildNodes();
              int filteringcnt = filteringList.getLength();
              Node filteringchld;
              for (int k = 0; k < filteringcnt; k++)
              {
                filteringchld = filteringList.item(k);
                if (FILTERCONDITION.equalsIgnoreCase(filteringchld.getNodeName()))
                {
                  // Load the required attributes
                  NodeAttributeHelper filteringattrs = 
                    new NodeAttributeHelper(filteringchld.getAttributes());
                  String columnName = filteringattrs.getValue(FILTERCOLUMN);
                  String operator = filteringattrs.getValue(FILTEROPERATOR);
                  String colValue = filteringattrs.getValue(FILTERVALUE);
                  String colType = filteringattrs.getValue(FILTERCOMPARETYPE);
                  String colFormat = filteringattrs.getValue(FILTERDATAFORMAT);
                  ConditionDefinition filteringCond = 
                       new ConditionDefinition(columnName, operator, colValue); 
                  mFilterConditions.add(filteringCond);
                  mFilteringColTypeMap.put(columnName, colType);
                  mFilteringColFormatMap.put(columnName, colFormat);
                }                
              }
            }
            if (PARAMETERS.equalsIgnoreCase(conditionschld.getNodeName()))
            {
              // Load the required attributes
              NodeAttributeHelper attrs = 
                new NodeAttributeHelper(conditionschld.getAttributes());

              // Get the child from the parameter definition.
              NodeList paramsList = conditionschld.getChildNodes();
              int paramscnt = paramsList.getLength();
              Node paramchld;
              mParamsMap.clear();
              for (int k = 0; k < paramscnt; k++)
              {
                paramchld = paramsList.item(k);
                if (PARAMETER.equalsIgnoreCase(paramchld.getNodeName()))
                {
                  // Load the required attributes
                  NodeAttributeHelper paramAttrs = 
                    new NodeAttributeHelper(paramchld.getAttributes());
                  String paramName = paramAttrs.getValue(PARAMETER_NAME);
                  String paramValue = paramAttrs.getValue(PARAMETER_VALUE);
                
                  mParamsMap.put(paramName,paramValue);
                }                
              }
            }
            
          }
                   
        }
        
      }
      sLoadFromMetadataTimer.stop();
    }
    catch (AdapterException ae)
    {
      throw ae;
    }
    catch (Exception e)
    { 
      mLogger.warning("Exception loading metadata from CSV definition. Cause: " 
                           + e.toString());
      throw new AdapterException(URLMessageArb.class, 
        URLMessageResource.EXC_FAILED_LOAD_METADATA).
        setCause(e);
    }
    finally
    {
      sLoadFromMetadataTimer.cleanup();
    }
  }
  
  /** 
   * Creates CSV data control instance from the metadata definition.
   *
   * @return the data control instance.
   */
  public DataControl createDataControl()
  {
    CSVDataControl csvDataControl = new CSVDataControl();
    csvDataControl.initialize(this);
    
    return csvDataControl;
  }
  
  /**
   * return name of the data control
   */
  public String getDCName()
  {
    return mName;
  }

  /**
   * Returns the type of the adapter.
   */
  public String getAdapterType()
  {
    return "oracle.adfm.adapter.URLDataControl";
  }
 
  /**
   * Returns the parameters that are defined for the data control metadata.
   * <p>
   * The implementation should override this method if the definition uses
   * parameters. The default implementatiaon returns null.
   */
  public ParameterDefinition[] getParameters()
  {
    return mParams;
  }

  /**
   * return the data source location.
   */
  public String getSourceLocation()
  {
    return mSourceLoc;
  }
  /**
   * return the URL connection name.
   */
  public String getConnectionName()
  {
    return mConnectionName;
  }  
  
  /**
   * return the Url query.
   */
  public String getUrlQuery()
  {
    return mUrlQuery;
  }
  /**
   * return the csv encoding.
   */
  public String getEncStyle()
  {
    return mEncStyle;
  }
  
  /**
   * return the csv delimiter.
   */
  public String getDelimiter()
  {
    return mDelimiter;
  } 

  /**
   * return the csv quote char
   */
  public String getQuoteChar()
  {
    return mQuoteChar;
  } 

  /**
   * return the boolean to indicate whether First rows as columns
   */
  public boolean getIsFirstRowNames()
  {
    return mIsFirstRowNames;
  } 
 
  /**
   * return the filtering type.
   */
  public String getFilteringType()
  {
    return mMatchType;
  } 
 
  /**
   * set the filtering type.
   */
  public void setFilteringType(String filterType)
  {
    mMatchType = filterType;
  } 
  
  /**
   * return the filtering conditions.
   */
  public String[] getFilteringConditions()
  {
    String [] filterCond = new String[mFilterConditions.size()];
    for (int i = 0; i<mFilterConditions.size();i++)
    {
      ConditionDefinition condDef = (ConditionDefinition)mFilterConditions.get(i);
      String colName = condDef.getColumn();
      String colOperator = condDef.getOperator();
      String colValue = condDef.getValue();
      String filteringCond = new SimpleStringBuffer(50)
                          .append(colName).append(" ").append(colOperator)
                          .append(" ").append(colValue).toString();
      filterCond[i] = filteringCond;                    
    }

    return filterCond;
  } 
  
  /**
   * Set the filtering conditions.
   */
  public void setFilteringConditions(ArrayList filterConditions)
  {
    mFilterConditions = filterConditions;
  } 
  
  /**
   * 
   * @return the Map which has the key: colName, value: colType
   */
  public Map getFilteringColTypeMap()
  {
    return mFilteringColTypeMap;
  }
  
  /**
   * 
   * @return the Map which has the key: colName, value: colFormat
   */
  public Map getFilteringColFormatMap()
  {
    return mFilteringColFormatMap;
  }
  
  /** 
   * Tells the framework whether the Data control structure is dirty and needs
   * to be refreshed on the palette. 
   * @param refresh flag to indicate if the refresh is requested for the 
   * structure.
   * @return true The CSV DC implementation always returns refresh flag. 
   */ 
   public boolean isStructureDirty(boolean refresh) 
   { 
     return refresh; 
   } 
}
