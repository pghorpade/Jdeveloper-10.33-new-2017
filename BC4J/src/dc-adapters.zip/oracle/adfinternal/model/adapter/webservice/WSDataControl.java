/*
 * @(#)WSDataControl.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  shalin       09/27/06 - correct perf logging usage
 *  vpamadi      08/23/05 - Remove Refs for DCSecurity 
 *  vpamadi      07/28/05 - Data control's invokeOperation needs to return 
 *                          false for button action operations 
 *  alai         07/22/05 - 
 *  armukher     06/30/05 - 
 *  vpamadi      05/20/05 - Testcase setup 
 *  vpamadi      03/30/05 - Associate the return value with the 
 *                          appropriate name obtained from
 *                          tokenizing the methodaction return name.
 *  vpamadi      01/06/05 - vpamadi_wsdcrt
 *  vpamadi      01/06/05 - creation
 */
package oracle.adfinternal.model.adapter.webservice;

import java.lang.reflect.Constructor;

import java.util.Map;
import java.util.logging.Level;

import oracle.binding.DataControl;
import oracle.binding.OperationBinding;
import oracle.binding.OperationInfo;

import oracle.adf.model.adapter.AbstractImpl;
import oracle.adf.model.adapter.AdapterException;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;

import oracle.adfinternal.model.adapter.webservice.provider.WSProvider;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;


/**
 * The WebService Data control allows the ADF data control to invoke any
 * Webservice via an underlying provider framework of either SOAP runtime
 * or WSIF. The Webservice can be invoked purely from the data described
 * in the Adapter metadata file at design time.
 *
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 */
public class WSDataControl extends AbstractImpl implements DataControl
{
  // Underlying provider instance. The Data control uses a provider
  // based model. The provider can either be SOAP provider for SOAP
  // bindings or can be a WSIF provider.
  private WSProvider      mProvider        = null;
  // Iterator of maps as needed by the binding.
  private Object          mDataProvider    = null;
 
  //======================================================================
  // - Logging suppport
  //======================================================================
  private ADFLogger   _logger = ADFLogger.createADFLogger(WSDefinition.LOGGER);
  // private constant for the class name.
  private static final String  __THISCLASS__ = 
                  "oracle.adfinternal.model.adapter.webservice.WSDataControl";
  // performance sensors
  private static Timer sInvokeOperationTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "invokeOperation",
                   "Invoking operation in Web Service Data Control");
  
  /**
   * Create an instance of the Webservice Data control.
   * 
   * @param name The name of this data control.
   */
  public WSDataControl(
   String name
  )
  {
    mName = name;  
  }


  /** Get the Name of the data control
   *
   * @return The name of the data control.
   */
  public String getName()
  {
    return mName;
  }

  public void initialize(
    String provider,
    Map environment
  )
  {
    _logger.fine("Initializing the Web Service Data control: " + mName);
    
    // Load up the provider
    if(provider != null)
      loadProvider(provider);
    else
    {
      _logger.severe("The provider class: " + provider + " could be found");
      _logger.severe("check if the class is available in the data control adapter jar");
      
      throw new AdapterException(WSDCResourceBundle.class, 
                                 WSDCResource.ERR_INTERNAL_ERR);
     }
    
    mProvider.init(environment);
  }

  /**
   * Get the data provider. A Data provider provides data to the
   * binding layer to be displayed on the view. For ADF this is
   * usually an iterator of maps
   *
   * @return The <code>Object</code> that contains the data.
   */
  public Object getDataProvider()
  {
    return mDataProvider;
  }

  /**
   * Invoke the action associated with this data control. The WebService data
   * control invokes the operation to return the data collection assoicated
   * with the operation invocation.
   * 
   * @param bindingContext A binding context that provide access to all 
   *                       binding related objects.
   * @param action         The action to be performed by the data control.
   *                       For the Webservice data control, the action to 
   *                       be invoked is the webservice operation.
   *
   * @return               <code>true</code> if this datacontrol has handled
   *                       this action, </code>false</code> if the action 
   *                       should be interpreted in the bindings framework or
   *                       in the caller.
   */
  public boolean invokeOperation(
   Map bindingContext, 
   OperationBinding operation
  )
  {
    _logger.entering(__THISCLASS__, "invokeOperation");
   
    try
    {
      sInvokeOperationTimer.start();

      // No operation to invoke, return false.
      if(operation == null)
        return false;
        
      OperationInfo operationInfo = operation.getOperationInfo();
      
      // the operation info is not present to execute the operation
      // on the provider.
      if(operationInfo == null)
        return false;
     
      // Get the operation name and the parameters set from 
      // the operation info.
      String methodName = operation.getName();
      Map    params     = operation.getParamsMap();
     
      _logger.fine("Data Control: " + mName + " invoking service operation: "
                      + methodName); 

      // execute the method on the provider.
      mDataProvider = mProvider.execute(methodName, params);
      processResult(mDataProvider, bindingContext, operation);

      sInvokeOperationTimer.stop();
      
      _logger.exiting(__THISCLASS__, "invokeOperation");
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "invokeOperation", ae);

      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(WSDCResourceBundle.class, 
                                 WSDCResource.ERR_INTERNAL_ERR, 
                                 new Object[]{e.toString()});
 
      _logger.throwing(__THISCLASS__, "invokeOperation" , ae);

      throw ae;
    }
    finally
    {
      sInvokeOperationTimer.cleanup();
    }

    return true;
  }



  /**
   * Based on the value of the flags parameter, releases all references to
   * the objects in the data provider layer
   * Valid values for flags are:
   * <ul>
   *    <li><code>REL_ALL_REFS</code> - if this data control
   *        should release all references to both the view and model
   *        objects.
   *    <li><code>REL_DATA_REFS</code> - if this data control
   *        should release all references to data provider objects. The
   *        likely usage would be when say an Application Module is to
   *        be checked into a pool and this data-control may be given
   *        that or another checked out AM to work with subsequently.
   *    <li><code>REL_VIEW_REFS</code> - if this data control
   *        should release all references to the UI/View layer objects.
   * </ul>
   *
   * @param flags Indicates what references in the datacontrol should 
   *              be released.
   */
  public void release(
   int flags
  )
  {
    _logger.entering(__THISCLASS__, "release");
    
    _logger.fine("Releasing all refs to Model objects");
    
    // see what needs to be released here.
    
    _logger.exiting(__THISCLASS__, "release");
  }

  ////////////////// Private Methods for the data control /////////////////

  /**
   * Load the provider that will handle the nuances of service invocation
   * for the data control. The provider can either be a SOAP provider for
   * SOAP bindings or a WSIF provider for any binding invocation
   */
  private void loadProvider(
    String providerClassName
  )throws AdapterException
  {
    try
    {
      _logger.fine("Attempting to load provider : " + providerClassName);
      
      Class providerClass = Class.forName(providerClassName);

      Constructor constructor = providerClass.getConstructor(new Class[]{});
      mProvider = (WSProvider)constructor.newInstance(new Object[] {});
    }
    catch(Exception e)
    {
      _logger.severe("Failed to load the provider: " + providerClassName); 

      throw new AdapterException(WSDCResourceBundle.class, 
                                 WSDCResource.ERR_INTERNAL_ERR);
    }
  }
}
