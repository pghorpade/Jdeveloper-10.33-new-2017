/*
 * @(#)WSDefinition.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  shalin    09/27/06 - correct perf logging usage
 *  vpamadi   11/02/05 - XbranchMerge vpamadi_mem_leak_fixes from main 
 *  vpamadi   10/24/05 - XbranchMerge vpamadi_xsl_perf_logging_fixes from main 
 *  vpamadi   10/27/05 - Fix up mem leak issues resulting from not closing the 
 *                       connections context 
 *  vpamadi   10/18/05 - Add a new destroy api to clean up the definition when 
 *                       no longer needed 
 *  vpamadi   09/12/05 - Exception message if failed to create Structure 
 *  vpamadi   09/09/05 - Check for SOAP only bindings when creating a 
 *                       Definition 
 *  vpamadi   08/25/05 - Error handling for Naming Exceptions 
 *  vpamadi   08/23/05 - Fix up namespaces for metadata nodes 
 *  vpamadi   08/03/05 - Null out the DC strcuture incase of an exception 
 *  alai      08/01/05 - 
 *  alai      07/22/05 - Replaced javax.binding with oracle.binding
 *  vpamadi   07/21/05 - Support Refresh for the DC , if the source WSDL 
 *                       changed 
 *  vpamadi   07/04/05 - Re-create connection when updating security policy 
 *  vpamadi   06/28/05 - Logging support . expose API to allow connections to 
 *                       be bound to Context passed by caller. The DT DnD / 
 *                       Wizard scenario will pass the connections context to 
 *                       the WSDef to bind the connections to. 
 *  vpamadi   06/24/05 - Changes to Secuirty model 
 *  vpamadi   06/24/05 - Use ADFContext to get the initial context for the 
 *                       connection 
 *  armukher  06/09/05 - 
 *  dmutreja  05/31/05  - 
 *  vpamadi   03/31/05  - Define metadata constants for operation request
 *                        and repsonse parts.
 *  vpamadi   03/02/05  - fix issue on return type iterator for a method 
 *                        return type 
 *  vpamadi   02/14/05  - A message part can return a collection of parameters
 *                        Iterate over the collection to create the methodDef. 
 *  vpamadi   01/05/05  - creation
 */
package oracle.adfinternal.model.adapter.webservice;

import java.net.URL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;

import oracle.binding.DataControl;
import oracle.binding.meta.StructureDefinition;

import javax.naming.Context;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.xml.namespace.QName;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import oracle.adf.model.adapter.AbstractDefinition;
import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.utils.Utility;
import oracle.adf.model.connection.webservice.api.WebServiceConnection;
import oracle.adf.model.connection.webservice.api.WebServiceConnectionFactory;

import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;
import oracle.adfinternal.model.adapter.webservice.security.SecurityModel;
import oracle.adfinternal.model.adapter.webservice.provider.WSProvider;

import oracle.webservices.model.Model;

import oracle.webservices.model.Operation;
import oracle.xml.parser.schema.XSDConstantValues;
import oracle.xml.parser.v2.XMLDocument;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;

/**
/**
 * Definition of the WebService data control instance.
 * <p>
 * The webservice data control definitions can be created in following ways
 * <ul>
 * <li><B>Created by WebService Adapter</B>: 
 * WebService Data control adapter creates this definition from data sources
 * it can handle. These data sources are desgin time objects that describe the 
 * WSDL for the webservice.
 * <li><B>Created by "File-New" wizard</B>: 
 * The creator of the data control invokes a menu selection. In this case the
 * Webservice data control wizard creates the definition for the data control.
 * </li>  
 * <li><B>Created by Framework</B>: 
 * The framework will create the Definition to create a data control from the 
 * data control metadata. The framework calls {@link #loadFromMetdata(Node)}
 * to load from the metadata definition. Once the definition is loaded, 
 * it calls the {@link createDataControl()} to create the data control 
 * instance.
 * </li>  
 * </ul>
 * 
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 * @see oracle.adf.model.adapter.AdbstractDefinition
 */
public class WSDefinition extends AbstractDefinition
{
  //============================================================================
  // Public Constants
  //============================================================================
  /**
   * Namespace in which this metadata is defined 
   */
  public static final String XMLNS =
                 "http://xmlns.oracle.com/adfm/adapter/webservice";

  /**
   * The definition node for this data control
   */ 
  public static final String ELEM_DEFINITION = "definition";
  /**
   * Service Element in the XML Metadata file
   */
  public static final String ELEM_SERVICE    = "service";
  /**
   * Operation Element
   */
  public static final String ELEM_OPERATION  = "operation";
  /**
   * Port Element, describes a port.
   */
  public static final String ELEM_PORT       = "port";
  /**
   * Data Format element, describes a Data format
   */
  public static final String ELEM_DATAFORMAT = "dataformat";
  /**
   * Format attribute 
   */
  public static final String ATTR_FORMAT     = "format";
  /**
   * Provider element, describes the underlying invocation provider 
   * for the data control.
   */
  public static final String ATTR_PROVIDER   = "provider";
  /**
   * Connection Attribute for the Adapter. 
   */
  public static final String ATTR_CONNECTION = "connection";
  /**
   * Name attribute
   */
  public static final String ATTR_NAME       = "name";
  /**
   * Operation Name Space Attribute
   */
  public static final String ATTR_NAMESPACE  = "namespace";
  /**
   * Part Datatype attribute
   */
  public static final String ATTR_DATATYPE   = "datatype";
  /**
   * WSDL attribute
   */
  public static final String ATTR_WSDL       = "wsdl";
  /**
   * Version attribute 
   */
  public static final String ATTR_VERSION    = "version";

  //============================================================================
  // Implementation
  //============================================================================

  // WSDL URL for this definition.
  private URL                  mWSDLUrl        = null;
  // Data control Name
  private String               mName           = null;
  // Data control structure to be exposed to the Strucutre pane.
  private StructureDef         mStructure      = null;
  // WebService model
  private WSModel              mModel          = null;
  // Service Name for this definition
  private QName                mServiceName    = null;
  // Map of Data control Operations. Map contains Port vs List of Operations
  private Map                  mDCOperations   = null; 
  // Node representing the metadata for this Webservice definition
  private Element              mDefinitionNode = null;
  // The security model for this data control. The security model 
  // is based on the security type configured for the data control 
  // and is responsible for generating metadata that is needed to
  // configure the security provider at runtime.
  private SecurityModel        mSecurityModel  = null;
  // The underlying service connection instance for this data control
  private WebServiceConnection mConnection     = null;

  //===========================================================================
  //  -- logging support 
  //============================================================================
  // The Data control logger.
  public static final String    LOGGER = "oracle.adf.adapterDC.webservice";
  private ADFLogger   _logger = ADFLogger.createADFLogger(LOGGER);
  // private constant for the class name.
  private static final String  __THISCLASS__ = 
                "oracle.adfinternal.model.adapter.webservice.WSDefinition";
  // performance sensors
  private static Timer sLoadMetadataTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "loadFromMetadata",
                   "Loading the data control definition from metadata");
  private static Timer sGetMetadataTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "getMetadata",
                   "Creating the metadata for the data control definition");
  private static Timer sGetDfltDCOpTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "getDefaultDCOperations",
                   "Setting up Default operation definitions for the data control");
  private static Timer sBindConnTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "bindServiceConnection",
                   "Binding the WebService connection to the CA context");
  private static Timer sCreateStructureTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "createStructure",
                   "Creating the Data Control Structure definition");
  private static Timer sCreateConnTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "createServiceConnection",
                   "Creating the Service connection for the data control");

  /**
   * Create this Data Control defintion
   * 
   */
  public WSDefinition()
  {
    
  }

  /**
   * Create this Data Control defintion from the WSDL source
   * 
   * @param wsdlURL The <code>WSDL URL</code> describing the service.
   * 
   * @throws {@link AdapterException} if the data control definition 
   *         cannot be created from the WSDL URL
   */
  public WSDefinition(
   URL wsdlURL
  )throws AdapterException
  {
    this(null, wsdlURL);
  }
  
  /**
   * Create this Data control definition instance. The defintion
   * creation initializes the underlying model and the connection 
   * to the service. 
   * 
   * @param name The name of the data control for which the definition
   *             is being created.
   * @param wsdlURL The URL of the service description.
   * 
   * @throws {@link AdapterException} if the definition for this data 
   *         control could be created. This failure may happen if the 
   *         WSDL url is invalid and the model cannot be initialized.
   *         or the underlying connection cannot be created.
   */
  public WSDefinition(
   String name, 
   URL    wsdlURL
  )throws AdapterException
  {
    _logger.entering(__THISCLASS__, "<init>");

    try
    {
      mWSDLUrl = wsdlURL;
      mModel = new WSModel(wsdlURL);
     
      Iterator services = mModel.getServices();
      
      while(services.hasNext())
      {
        // Find the first service that has SOAP Ports ..
        QName thisService = (QName)services.next();
        if(mModel.getServicePorts(thisService).size() > 0)
        {
          mServiceName = thisService;
          break;
        }
      }
      
      if(mServiceName == null)
      {
        throw new AdapterException(WSDCResourceBundle.class,
                                 WSDCResource.ERR_NO_SOAP_BINDING);
      }
      
      mName = (name != null) ? name : mServiceName.getLocalPart();

      super.setName(name);
     
      _logger.exiting(__THISCLASS__, "<init>");
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "<init>", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "<init>", ae);
      throw ae;
    }
  }

  /**
   * Create this Data control definition instance from the WSDL url and 
   * the model representing the service.
   * 
   * @param name        The name of the data control for which the definition
   *                    is being created.
   * @param wsdlURL     The URL of the service description.
   * @param model       The model representing the Service. The model describes
   *                    all the ports and operations exposed by the service
   *                    description.
   * @param serviceName The qualified service name for which the definition
   *                    is to be intialized. The service description may 
   *                    describe more that one service. In such a case
   *                    the definition is created for the requested service.
   * 
   * @throws {@link AdapterException} if the definition for this data 
   *         control could be created. This failure may happen if the 
   *         WSDL url is invalid and the model cannot be initialized.
   *         or the underlying connection cannot be created.
   */
  public WSDefinition(
   String  name,
   URL     wsdlURL,
   WSModel model,
   QName   serviceName
  )throws AdapterException
  {
    try
    {
      mModel = model;
      mName = name;
      mWSDLUrl = wsdlURL;
  
      // Check if the provided service can be supported 
      // and has SOAP ports.    
      if(mModel.getServicePorts(serviceName).size() > 0)
      {
        mServiceName = serviceName;
      }
      
      if(mServiceName == null)
      {
        throw new AdapterException(WSDCResourceBundle.class,
                                 WSDCResource.ERR_NO_SOAP_BINDING);
      }
      
      super.setName(name);
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "<init>", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "<init>", ae);
      throw ae;
    }
  }

  /**
   * Get the name of the Data control for which this Definition is created.
   * 
   * @return The Data Control name.
   */
  public String getDCName()
  {
    return mName;
  }

  /**
   * Get the underlying webservice model for this definition's source.
   *
   * @return The instance of the webservice model.
   */
  public WSModel getModel()
  {
    return mModel;
  }

  /**
   * Get the operations that the data control can invoke on the service
   *
   * @return A {@link Map} of the operations for this data control
   */
  public Map getDCOperations()
  {
    return mDCOperations;
  }

  /**
   * Set the Data control operations in this Defintion.
   *
   * @param dcOperations The {@link Map} of the operations for this
   *                     data control
   */
  public void setDCOperations(
   Map dcOperations
  )
  {
    mDCOperations = dcOperations;
  }

  /**
   * Get the default service name for this Data control definition
   *
   * @return The default service name.
   */
  public QName getServiceName()
  {
    return mServiceName;
  }

  /**
   * Set the Service Name for this data control definition
   *
   * @param serviceName The Service name for for this definition
   */
  public void setServiceName(
   QName serviceName
  )
  {
    mServiceName = serviceName;
  }

  /**
   * Get the adapter type of this data control. The adapter type is a 
   * string description of this adapter. The adapter type is needed 
   * to associate the dependent libraries when creating a project 
   * that uses this data control.
   * 
   * @return the type description of this data control.
   */
  public String getAdapterType()
  {
    return "oracle.adfm.adapter.WebServiceDataControl";
  }

  /**
   * Get the underlying security model for this Data control.
   */ 
  public SecurityModel getSecurityModel()
  {
    if(mSecurityModel == null)
     mSecurityModel = new SecurityModel();

    return mSecurityModel;
  }
  
  
  /**
   * Creates an instance of the Webservice data control generated
   * from the metadata definition.
   *
   * @return the instance of the Webservice data control.
   *         <code>null</code> If the data control instance could
   *         not be created.
   */
  public DataControl createDataControl()
  {
    try
    {
      _logger.entering(__THISCLASS__, "createDataControl");

      WSDataControl wsdc = new WSDataControl(mName);
      HashMap environment = new HashMap();

      environment.put(WSProvider.PROVIDER_CONNECTION, mConnection);
      environment.put(WSProvider.PROVIDER_OPERATIONS, mDCOperations);
      environment.put(WSProvider.PROVIDER_SERVICE, mServiceName);

      String provider = mDefinitionNode.getAttribute(
                                         WSDefinition.ATTR_PROVIDER);

      _logger.fine("Attempting to initialize the Web Service data control");

      wsdc.initialize(provider, environment);

      _logger.exiting(__THISCLASS__, "createDataControl");

      return wsdc;
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "createDataControl", ae);
      throw ae;
    }
    catch (Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "createDataControl", ae);
      throw new AdapterException(ae);
    }
  }
  
  /**
   * Loads the definition from a metadata <code>Node</code>.
   *
   * @param node the metadata node. It can be null if no metadata is defined.
   * @param params context parameters.
   * 
   * @throws {@link AdapterException} if the data control definition
   *         cannot be reconstructed back from the metadata information.
   */
  public void loadFromMetadata(
   Node node, 
   Map  params
  )throws AdapterException
  {
    _logger.entering(__THISCLASS__, "loadFromMetadata");

    Context ctx = null;

    try
    {
      sLoadMetadataTimer.start();

      //// Metadata already loaded and operations are created..
      if (mDCOperations != null)
      {
        _logger.finer("metdata already loaded");
        return;
      }
    
      mDCOperations = new HashMap();
      
      _logger.fine("Loading from " + node.getNodeName());

      mDefinitionNode = (Element)node.getFirstChild();
      Element defnElem = mDefinitionNode;
      Element serviceElem = Utility.getChildElement(defnElem,
                                                   WSDefinition.ELEM_SERVICE);
      mName = defnElem.getAttribute(ATTR_NAME);
      mServiceName = new QName(serviceElem.getAttribute(ATTR_NAMESPACE),
                                 serviceElem.getAttribute(ATTR_NAME));
      // build the WSDL URL
      String wsdlURL = defnElem.getAttribute(ATTR_WSDL);
      mWSDLUrl = new URL(wsdlURL);
      
      // Get the connection reference 
      String connRef = serviceElem.getAttribute(ATTR_CONNECTION);
      // ensure that we have the right context
      ctx = getContext();

      _logger.fine("looking up for connection " + connRef);
      // Get the connection from the context.
      mConnection = (WebServiceConnection)ctx.lookup(connRef);  
    
      _logger.fine("attempting to load the model from the connection");
      
      // Load the model from connection into the DC model.
      mModel = new WSModel(mConnection.getModel());
    
      // Get all the ports defined in the metdata for this service
      // and construct the DC operation map  
      NodeList ports = serviceElem.getChildNodes();
      for (int i = 0; i < ports.getLength(); i++)
      {
        Element port = (Element)ports.item(i);
        String portName = port.getAttribute(ATTR_NAME);
        Vector operations = new Vector(); 
        
        NodeList operationList = port.getChildNodes();
        for(int j = 0; j < operationList.getLength(); j++)
        {
          Element operationElem = (Element)operationList.item(j); 
          String opName = operationElem.getAttribute(ATTR_NAME);
 
          _logger.fine("Loading operation '" + opName + "'");
 
          WSOperation operation =  new WSOperation(opName, 
                               mModel.getOperation(mServiceName, 
                                                   portName, opName));
          operations.add(operation);
          Element formatElem = Utility.getChildElement(operationElem, 
                                                WSDefinition.ELEM_DATAFORMAT);
          if(formatElem != null)
          {
            String formatName = 
                        formatElem.getAttribute(WSDefinition.ATTR_FORMAT);
            DataFormat format = new DataFormat(formatName);
            operation.setResponseFormat(format);
            NamedNodeMap attrs = formatElem.getAttributes();
            for(int attrIdx = 0; attrIdx < attrs.getLength(); attrIdx ++)
            {
              Node attr = attrs.item(attrIdx);
              format.addProperty(attr.getNodeName(), attr.getNodeValue());
            }
          }
        }
        mDCOperations.put(portName, operations);
      }

      sLoadMetadataTimer.stop();
  
      _logger.exiting(__THISCLASS__, "loadFromMetadata");
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "loadFromMetadata", ae);
      throw ae;
    }
    catch(NamingException ne)
    {
      Throwable rootCause = ne.getRootCause();
      AdapterException ae = null;
      String message = ne.getMessage();
      
      if(rootCause != null)
      {
        message = rootCause.getMessage();
      }
      
      ae =  new AdapterException(WSDCResourceBundle.class,
                                 WSDCResource.ERR_CONN_CREATE_FAIL,
                                 new Object[]{message});
      
      _logger.throwing(__THISCLASS__, "loadFromMetadata", ae);
      
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "loadFromMetadata", ae);
      throw ae;
    }
    finally
    {
      sLoadMetadataTimer.cleanup();
        
      if(ctx != null)
      {
        try
        {
          ctx.close();
          ctx = null;
        }
        catch(Exception e)
        {
          _logger.warning("Failed to close the connections context due to :" 
                                                  + e.getMessage());
        }
      }
    }
  }

  /**
   * Get the strcuture definition for the data 
   * 
   * @return The {@link StructureDefinition} representing the strcuture 
   *         of the data returned by this data control.
   */
  public StructureDefinition getStructure()
  {
    if (mStructure == null)
      createStructure();

    return mStructure;
  }
  
  /** 
   * Tells the framework whether the Data control structure is dirty and needs
   * to be refreshed on the palette. The framework passes a flag 
   * <code>refresh</code> if refresh is requested. If a refresh is needed,
   * the data control definition recreates the underlying model and connection
   * to update the metadata of any possible changes to the service operation
   * signature.
   * 
   * @param refresh flag to indicate if the refresh is requested for the 
   *                structure. If <code>true</code>, the definition 
   *                regenerates the underlying model, operation map and 
   *                connection information. This re-generation is needed to 
   *                rebuild the structure and make sure that the runtime 
   *                has the right connection metadata to execute any modified
   *                operation bindings
   *                 
   * @return        <code>true</code> if the implementation decides that the 
   *                structure of the data should be regenerated,
   *                <code>false</code> otherwise. 
   * 
   */ 
   public boolean isStructureDirty(
    boolean refresh
   ) 
   { 
     _logger.entering(__THISCLASS__, "isStructureDirty");
    
     try
     {
       // We will go ahead and refresh . Cannot determine if a refresh is 
       // really needed since a lot of logistics involved, in that each and 
       // every operation and signature must be examined, which is tedious.
       if(refresh)
       {
         // Straight away create a new model for the WSDL. 
         _logger.info(__THISCLASS__, "Recreating the definition model");
         mModel = new WSModel(mWSDLUrl);
         
//////////////////////////////////////////////////////////////////////////  
// I may need this code someday if right click->Refresh is supported from DC
// palette . For Now creating a new model and binding the underlying connection
// should solve our case, for regeneration of the DC. 
//

     /* 
         // Ok, some wise guy changed the whole WSDL. We need to refresh
         // the whole Definition
         if(mModel.getService(mServiceName) == null)
         {
           mServiceName = mModel.getDefaultServiceName();
         }
         else
         {
           // create a new map for the modified operations.
           HashMap newDCOperations  = new HashMap();
           // Get the iterator for ports in the operations mapping.
           Iterator portIterator = mDCOperations.keySet().iterator();
           // Iterate and refresh the port operations.
           while (portIterator.hasNext())
           {
             String portName = (String)portIterator.next();
             
             List operationsList = null;
             operationsList = (List)mDCOperations.get(portName);
             
             Iterator opIter = operationsList.iterator();
             // create a new List for this port for the modified operations.
             ArrayList newOperationsList = new ArrayList();
             while (opIter.hasNext())
             {
               // get the old operation from the previous DC operations set
               WSOperation operation = (WSOperation)opIter.next();
               // get the new Operation 
               Operation mddsOp = mModel.getOperation(mServiceName, portName,
                                  operation.getOperation().getOperationName());
               // The operation may not exisit anymore... so check for null
               if(mddsOp != null)
               {
                 // if it exists refresh the DC operation and add it to the 
                 // list.
                 String operationName = operation.getName();
                 operation = null;
                 operation = new WSOperation(operationName, mddsOp);
                 newOperationsList.add(operation);
               }
               
               // update the new DC operations list, for the new operations.
               // Another possibility is all the ports for this service has 
               // changed in which case, the newOperationsList will still be
               // empty, this would mean the newDCoperations mapping will 
               // still be empty, and would allow to be populated when the 
               // metdata is attempted to be created.
               
               if(newOperationsList.size() > 0)
                 newDCOperations.put(portName, newOperationsList);
             }
           }           
           // clear out the exisiting mapping
           mDCOperations.clear();
           mDCOperations = newDCOperations;
         }
/////////////////////////////////////////////////////////////////////////////         
  */
         // if everything went fine ... bind the service connection to 
         // update the underlying mdds metadata. Note that this will have a 
         // side effect of removing all the security settings done on 
         // the old DC. Since the MDDS metadata is recreated.
         
         _logger.fine(__THISCLASS__, "update the service connection for refresh");
         
         bindServiceConnection(getContext());
       }  
     
       return refresh;
     }
     catch(AdapterException ae)
     {
       _logger.throwing(__THISCLASS__, "isStructureDirty", ae);
       throw ae;
     }
     catch(Exception e)
     {
       _logger.throwing(__THISCLASS__, "isStructureDirty", e);
       throw new AdapterException(e);
     }
   } 

  /**
   * Returns the element that defines the metadata for the data control.
   * <p>
   * The WSDL is parsed to extract as much information as is needed to be 
   * stored in the metdata to invoke the service operation at runtime.
   *</p>
   * 
   * @return a <code>Node</code> that defines the metadata for this instance.
   *         This metadata will be used at the runtime to fetch data from the
   *         data source. 
   */
  public Node getMetadata()
  {
    Element          serviceElem     = null;
    String           portName        = null;
    XMLDocument      doc             = new XMLDocument();
    
    try
    {
      _logger.entering(__THISCLASS__, "getMetadata");

      sGetMetadataTimer.start();


      // Definition node is already created. send it back
      if (mDefinitionNode != null)
      {
        return mDefinitionNode;
      }

      // Wizard was not invoked...
      if (mDCOperations == null || mDCOperations.size() == 0)
      {
        _logger.fine("Setting default operations for this service ");

        if(mServiceName == null)
          mServiceName = getServiceName();

        mDCOperations = getDefaultDCOperations(mServiceName);
      }
     
      mDefinitionNode = doc.createElementNS(XMLNS, ELEM_DEFINITION);
      mDefinitionNode.setAttributeNS("http://www.w3.org/2000/xmlns/", 
                                     XSDConstantValues._xmlns, XMLNS);
                                     
      mDefinitionNode.setAttribute(ATTR_NAME, mName);
      mDefinitionNode.setAttribute(ATTR_VERSION, "1.0");
      mDefinitionNode.setAttribute(ATTR_PROVIDER,
    "oracle.adfinternal.model.adapter.webservice.provider.soap.SOAPProvider");
      mDefinitionNode.setAttribute(ATTR_WSDL, stripJdevBindings(mWSDLUrl));

      serviceElem = doc.createElementNS(XMLNS, ELEM_SERVICE);
      
      serviceElem.setAttribute(ATTR_NAME, mServiceName.getLocalPart());
      serviceElem.setAttribute(ATTR_NAMESPACE, mServiceName.getNamespaceURI());
      mDefinitionNode.appendChild(serviceElem);
      
      serviceElem.setAttribute(ATTR_CONNECTION, mName); 
                                 
      Iterator portIterator = mDCOperations.keySet().iterator();
      while (portIterator.hasNext())
      {
        Element portElem = doc.createElementNS(XMLNS, ELEM_PORT);
        
        portName = (String)portIterator.next();
        portElem.setAttribute(ATTR_NAME, portName);
        serviceElem.appendChild(portElem);
        Iterator operationIter = ((List)(mDCOperations.get(portName))).iterator();

        while (operationIter.hasNext())
        {
          WSOperation operation = (WSOperation)operationIter.next();
          portElem.appendChild(doc.adoptNode(operation.getOperationNode()));
        }
      }
     
      _logger.fine("Finished creating the metadata node");
      _logger.exiting(__THISCLASS__, "getMetadata", mDefinitionNode);

      sGetMetadataTimer.stop();
      
      return mDefinitionNode;
    }
    catch (DOMException de)
    {
      AdapterException ae = new AdapterException(WSDCResourceBundle.class,
                                         WSDCResource.ERR_METADATA_CREATE_FAIL,
                                             new Object[]{de.getMessage()});

      _logger.throwing(__THISCLASS__, "getMetadata", ae);
      
      mDefinitionNode = null;
      
      throw ae;
    }
    catch (Exception e)
    {
      AdapterException ae = new AdapterException(WSDCResourceBundle.class,
                                        WSDCResource.ERR_METADATA_CREATE_FAIL,
                                        new Object[]{e.getMessage()});

      _logger.throwing(__THISCLASS__, "getMetadata", ae);
      
      mDefinitionNode = null;
      
      throw ae;
    }
    finally
    {
      sGetMetadataTimer.cleanup();
    }
  }

  /**
   * Get the Default operations for a given service.
   * 
   * @param serviceName The Qualified service Name for which operations
   *                    must be fetched.
   * 
   * @return {@link Map} of Operations for this service.
   * 
   * @throws {@link AdapterException} if the service does not exist in 
   *         the underlying model.
   */
  public Map getDefaultDCOperations(
   QName serviceName
  )throws AdapterException
  {
    try
    {
      sGetDfltDCOpTimer.start();
  
      // fetch the service operations for this service name
      Map serviceOperations = mModel.getServiceOperations(serviceName);
      HashMap dcOperations = new HashMap();

      // build the Operations table for this service. This is the 
      // data control operation table 
      if (serviceOperations != null)
      {
        Iterator ports = serviceOperations.keySet().iterator();
        while (ports.hasNext())
        {
          String portName = (String)ports.next();
          Map operations = (Map)serviceOperations.get(portName); 
          Iterator opIter = operations.keySet().iterator();
          ArrayList dcOperationsList = new ArrayList();
 
          while(opIter.hasNext())
          {
            String opName = (String)opIter.next();
            WSOperation dcOperation =  new WSOperation(opName, 
                                        (Operation)operations.get(opName));
            dcOperationsList.add(dcOperation); 
          } 

          dcOperations.put(portName, dcOperationsList);
        }
      }

      sGetDfltDCOpTimer.stop();

      return dcOperations;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
    finally
    {
      sGetDfltDCOpTimer.cleanup();
    }
  }

  /**
   * Bind the underlying connection used by this data control into the
   * context provided by the caller. The data control loads the connection 
   * both at design time and runtime. Allowing the context to be provided
   * by caller allows more flexibility to bind and load the connection 
   * information irrespective of the DT / RT operations.
   * 
   * @param context The {@link Context} provided by the caller into which 
   *                the connection for this service is to be bound.
   * 
   * @throws {@link AdapterException} If the connection cannot be bound into 
   *         the context provided. 
   */
  public void bindServiceConnection(
   Context context
  )throws AdapterException 
  {
    try
    {
      _logger.fine("Binding the Service connection to the context");

      sBindConnTimer.start();

      // create the connection if not already present. If updating 
      // the connection then no need to re-create.
      //   if(mConnection == null)
      createServiceConnection(mName, mServiceName);
        
      context.rebind(mName, mConnection);

      sBindConnTimer.stop();
    }
    catch(Exception e)
    { 
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "bindServiceConnection", ae);
     
      throw ae;
    }
    finally
    {
      // close the connections context.
      try
      {
        context.close();
      }
      catch(Exception e)
      {
        _logger.warning("Encountered exception when closing the context" + e);
      }

      sBindConnTimer.cleanup();
    }
  }
  
  //=========================================================================
  //     -- Protected API's 
  //=========================================================================
  
  /**
   * Destroy this definition instance. 
   *<p>
   * Should be invoked by the data control when it is released from an 
   * application. The data control definition is voided out once the 
   * destroy is invoked. This includes cleaning up of the operations table,
   * purging out the security model and the underlying connection bindings. 
   * The definition is not usable anymore once it is destroyed. A new instance 
   * of the definition must be created for the dc by loading the definition 
   * from the metadata.
   *</p>
   *
   * @throws AdapterException if the definition cannot be destroyed.
   */  
  protected void destroy()throws AdapterException
  {
    try
    {
      // clear the operations table.
      if(!mDCOperations.isEmpty())    
        mDCOperations.clear();
      
      mDCOperations = null;
      mConnection = null;
    
      // destroy the security model.
      if(mSecurityModel != null)
        mSecurityModel.destroy();

      // null out the model.  
      mModel = null;
    }
    catch(Exception e)
    {
      _logger.throwing(__THISCLASS__, "destroy", e);
    }
  }

  //==========================================================================
  //  ---- Private Helpers -----
  //========================================================================== 
  
  /**
   * Create the Data control structure. The method strcuture for all the DC 
   * operations are created. Each operation builds the parameter and the 
   * return type structure and loads it into the top level Data control 
   * structure definition.
   */
  private void createStructure() throws AdapterException
  {
    try
    {
      _logger.entering(__THISCLASS__, "createStructure");

      sCreateStructureTimer.start();

      if (mStructure == null)
      {
        // create the top level strcuture definition
        mStructure = new StructureDef(mName);

        Iterator operationsIter = mDCOperations.values().iterator();
        //  create the structure for each DC operation and load it into 
        // the top level structure definition.
        while (operationsIter.hasNext())
        {
          Iterator operationIter = ((List)operationsIter.next()).iterator();
          while (operationIter.hasNext())
          {
            WSOperation operation = (WSOperation)operationIter.next();
            mStructure.addMethod(operation.getMethodDefintion(mStructure));
          }
        }
      }

      sCreateStructureTimer.stop();
    }
    // Null out the structure incase of an exception.
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "createStructure", ae);
      
      mStructure = null;   
      throw ae;
    }
    catch(Exception e)
    {
      _logger.severe("Failed to model the data control structure due to : " +
                       e.getMessage());
      mStructure = null;
      throw new AdapterException(e);
    }
    finally
    {
      sCreateStructureTimer.cleanup();
    }
  
    _logger.exiting(__THISCLASS__, "createStructure");
  }
  
  /**
   * Create the underlying service connection. The Service connection stores all 
   * the mdds metadata that describes the operations that can be invoked on the 
   * data control
   *
   * @param connName    The name of this connection. 
   * @param serviceName The serviceName of for which this connection is to be 
   *                    created.
   *
   * @throws {@link AdapterException} in case the service connection cannot
   *         be set up.
   */
  private void createServiceConnection(
   String connName,
   QName  serviceName
  )throws AdapterException
  {
    try
    {
      _logger.fine("Creating the service connection for the data control");

      sCreateConnTimer.start();
      
      WebServiceConnectionFactory factory = new WebServiceConnectionFactory();
      Attributes attrs = new BasicAttributes();
      Model model = mModel.getMddsModel();
      attrs.put("name", connName);
      attrs.put("wsdl", stripJdevBindings(mWSDLUrl));
      attrs.put("model", model);
      attrs.put("service", serviceName);
      
      mConnection = (WebServiceConnection)factory.newInstance(attrs);

      sCreateConnTimer.stop();

      _logger.exiting(__THISCLASS__, "createServiceConnection", mConnection);
    }
    catch (Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "createServiceConnection", ae);
      throw ae;
    }
    finally
    {
      sCreateConnTimer.cleanup();
    }
  }
 
  /*
   * Get the current context based on DT Context
   */
  private Context getContext() throws Exception
  {
    Context ctx = null;
    
    if(getAdapterContext() != null)
    {
      ctx = getAdapterContext().getConnectionContext();
    }
   
    // This is just a temporary hack. 
    // getAdapterContext() returns null at DT when DnD 
    // from UDDI - registry. 
    // NPE all over the place.  Seen when Jdeveloper starts up
    // and loadFromMetdata is called to initalize all DC's
    else
    {  
      ctx = 
            oracle.adf.model.adapter.DTContext.getInstance().
                       getConnectionContext();
    }

    return ctx;
  }
 
  /**
   * Take out the Jdev UDDI design time bindings from the URL 
   * protocol. 
   */
  private String stripJdevBindings(
   URL wsdl
  )
  {
    final String JDEV_UDDI_BINDING = "jdev.uddi.bindingtemplate:";
    String wsdlurl = wsdl.toExternalForm();
    
    if(wsdlurl.startsWith(JDEV_UDDI_BINDING))
    {
       int idx = wsdlurl.indexOf(':');
       if(idx > -1)
         wsdlurl = wsdlurl.substring(idx + 1, wsdlurl.length());
    }
    return wsdlurl;
  }
}
