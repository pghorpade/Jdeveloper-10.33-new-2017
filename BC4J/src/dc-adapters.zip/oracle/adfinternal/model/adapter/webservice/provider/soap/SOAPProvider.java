/*
 * @(#)SOAPProvider.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  shalin       09/27/06 - correct perf logging usage
 *  vpamadi      07/12/06 - Backport vpamadi_complex_param_val_query from main 
 *  vpamadi      07/11/06 - Query complex param val based on the QName if doc 
 *                          lit style 
 *  vpamadi      04/24/06 - fix doc literal headers 
 *  vpamadi      12/21/05 - XbranchMerge vpamadi_rad_race_fixes from main 
 *  vpamadi      10/24/05 - XbranchMerge vpamadi_xsl_perf_logging_fixes from 
 *                          main 
 *  vpamadi      12/20/05 - Allow null values for parameters if nillable 
 *                          specified in the schema 
 *  vpamadi      09/08/05 - Fix up the collections when response has headers 
 *  armukher     09/02/05 - 
 *  vpamadi      08/12/05 - Take out SOAP Message dumps 
 *  vpamadi      07/26/05 - Pass the Root Reference when resolving href's in 
 *                          the SOAP payload 
 *  vpamadi      07/12/05 - 
 *  vpamadi      07/01/05 - Change the logger name 
 *  vpamadi      06/27/05 - Logging support 
 *  vpamadi      06/22/05 - Fix oneway operation handling at runtime 
 *  vpamadi      06/08/05  - 
 *  vpamadi      06/01/05  - Include SOAP Headers in the result RSI creation.
 *                           Create a ROOT accessor under which the BODY and
 *                           Header RSI's sit as individual top level
 *                           accessors.
 *  vpamadi      03/31/05  - Handle Metadata changes, each operation
 *                           is now intialized with O/P parts as well.
 *  vpamadi      03/17/05  - Support for other data formats. 
 *  vpamadi      01/06/05  - creation
 */
package oracle.adfinternal.model.adapter.webservice.provider.soap;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import oracle.j2ee.ws.mdds.adt.ADTEnvelopeSerializer;
import oracle.j2ee.ws.mdds.SAAJEnvelopeBuilder;
import oracle.j2ee.ws.mdds.adt.ComplexNodeImpl;
import oracle.j2ee.ws.client.ClientTransportException;

import oracle.webservices.mdds.adt.ArrayNode;
import oracle.webservices.mdds.adt.ComplexNode;
import oracle.webservices.mdds.adt.DataTreeFactory;
import oracle.webservices.mdds.adt.MessageNode;
import oracle.webservices.mdds.ArrayPrototype;
import oracle.webservices.mdds.AtomicPrototype;
import oracle.webservices.mdds.ComplexPrototype;
import oracle.webservices.mdds.HeaderPrototype;
import oracle.webservices.mdds.MessagePrototype;
import oracle.webservices.mdds.Prototype;
import oracle.webservices.model.Message;
import oracle.webservices.model.Operation;
import oracle.webservices.model.soap.SoapPort;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.connection.webservice.api.SaajInteraction;
import oracle.adf.model.connection.webservice.api.WebServiceConnection;

import oracle.adf.share.perf.Timer;
import oracle.adf.share.logging.ADFLogger;

import oracle.adfinternal.model.adapter.webservice.DataFormat;
import oracle.adfinternal.model.adapter.webservice.provider.WSProvider;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;
import oracle.adfinternal.model.adapter.webservice.WSOperation;
import oracle.adfinternal.model.adapter.webservice.WSDefinition;

/**
 * Concrete Data control Provider implementation for the SOAP binding.
 * <p>
 * The SOAPProvider allows the Data Control to invoke Webservices defined
 * for <code>SOAP</code> bindings. The provider abstracts out the invocation
 * protocol details at the Data Control level. 
 * </p>
 * <p>
 * The SOAPProvider is intialized from the metadata configuration. The 
 * Provider intializes all the necessary classes to convert the operaton 
 * invocation requests to SOAP payload and return the response payload as
 * an iterator of maps. For the Data control, the underlying classes used
 * by the provider are not visible, neither is the data control aware of
 * the existance of these instances. All operation invocations by the data
 * control happen via the provider.
 * </p>
 * <p>
 * The provider is also repsonsible for processing the <code>SOAP</code>
 * messages for security. The Data control registers the security 
 * implmentation via a standard interface {@link DCSecurity}. The SOAPProvider
 * uses the registered implementation to enable <code>SOAP</code> message 
 * level security.
 * </p>
 * 
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 *
 * @see     SOAPOperation
 * @see     DCSecurity
 */
public class SOAPProvider implements WSProvider
{
  // Operations table for this data control for this provider. This table lists
  // all the valid operations that can be invoked on this data control
  private Map                    mOperations  = new HashMap();
  // Provider environment. The environment is a table of properites and any other
  // data needed to configure and initialize this provider.
  private Map                    mEnvironment = null;
  // The underlying webservice connection to use to invoke operations on the 
  // remote service.
  private WebServiceConnection   mConn        = null;
  // The MDDS data factory to serialize the SOAP payload.
  private DataTreeFactory        mADTFactory  = DataTreeFactory.newInstance();
  
  // Private constants to normalize part names.
  private static final char      HYPHEN       = '-';
  private static final char      UNDERSCORE   = '_';

  //=========================================================================
  // --- Logging support .
  private final ADFLogger        _logger_    = 
                               ADFLogger.createADFLogger(WSDefinition.LOGGER);
  private static final String  __THISCLASS__ = 
      "oracle.adfinternal.model.adapter.webservice.provider.soap.SOAPProvider";
     
  //=========================================================================
  
  // performance sensors
  private static Timer sExecuteTimer = Timer.createTimer(Level.FINER,
                  "/oracle/adf/model/adapter/webservice",
                  "execute",
                  "Provider executing the service operation");
  private static Timer sSetHeaderTimer = Timer.createTimer(Level.FINEST,
                   "/oracle/adf/model/adapter/webservice",
                   "setHeaderParts",
                   "Setting up the SOAP header for the request message");
  private static Timer sSetParamTimer = Timer.createTimer(Level.FINEST,
                   "/oracle/adf/model/adapter/webservice",
                   "setParameters",
                   "Setting up operation parameters for the request message");
  private static Timer sGetResultTimer = Timer.createTimer(Level.FINEST,
                   "/oracle/adf/model/adapter/webservice",
                   "getResult",
                   "Processing SOAP response message for the result.");
  private static Timer sProcessResponseTimer = Timer.createTimer(Level.FINEST,
                   "/oracle/adf/model/adapter/webservice",
                   "processResponseHeaders",
                   "Processing Headers in the SOAP response message " +
                   "to set up the master accessor.");

  /**
   * Create the instance of this SOAPProvider
   */
  public SOAPProvider()
  {
  }
  
  /**
   * Initialize the Provider with the DC environment. The DC can initialize
   * the provider with parameters such as supported operations, the underlying
   * connection to use and any other parameter needed by the provider
   * to make a successful invocation of the operation.
   *
   * @param environment The Parameters needed by this provider to 
   *                    make a successful invocation of the DC operation.
   */ 
  public void init(
   Map environment
  )
  {
    _logger_.entering(__THISCLASS__, "init");

    mEnvironment = environment;
    mConn = (WebServiceConnection)environment.get(
                             WSProvider.PROVIDER_CONNECTION);
    mOperations = (Map)environment.get(WSProvider.PROVIDER_OPERATIONS);

    _logger_.exiting(__THISCLASS__, "init");
  }
  
  /**
   * Invoke the service operation
   * Create the request payload against the endpoint URL. Enable the 
   * message level security if the security implementation is registered. 
   * The response is processed and iterator of maps is created and returned
   * to the data control
   * 
   * @param operationName  The name of the operation to be invoked.
   * @param params         The parameters for this operation invocation.
   * 
   * @return The result of this operation invocation. The provider sends the
   *         result back as an iterator of maps.
   *
   * @throws {@link AdapterException} if the invocation fails.
   */
  public Object execute(
    String operationName,
    Map params
  )throws AdapterException
  {
    try 
    {
      _logger_.entering(__THISCLASS__, "execute");
      _logger_.fine("Preparing to Invoke  operation " + operationName);

      sExecuteTimer.start();
      
      WSOperation dcOperation = findServiceOperation(operationName);
      Operation   operation = dcOperation.getOperation();
      SaajInteraction call = mConn.getSaajInteraction(operation);
      MessageNode messageNode = mADTFactory.createMessageNode();
      MessagePrototype inMessage = 
               (MessagePrototype)operation.getInputMessage().getExtension(
                                             MessagePrototype.EXTENSION_TYPE);
             
      setHeaderParts(inMessage, messageNode, params);
      
      if(inMessage.isDocLitWrapped())
      {
        ComplexNode wrapperNode = mADTFactory.createComplexNode();
        setParameters(inMessage.getWrappedParams(), wrapperNode, params, false);
        messageNode.setPart(inMessage.getPartName(0), wrapperNode);
      }
      else
       setParameters(inMessage, messageNode, params, 
                     (inMessage.getStyle() == MessagePrototype.STYLE_DOCUMENT));
 
      SAAJEnvelopeBuilder builder = new SAAJEnvelopeBuilder();
      ADTEnvelopeSerializer serializer = new ADTEnvelopeSerializer();

      serializer.serialize(inMessage, messageNode, builder);
      SOAPMessage request = builder.getMessage();
     
      // dump the request message to log
      dumpMessage(request);
      
      _logger_.fine("Invoking the SOAP Request");

      SOAPMessage response = null;
      
      try
      {
        response = call.execute(request);
      }
      // NO route to host available
      catch(ClientTransportException cte)
      {
      	SoapPort port = (SoapPort)(operation.getPort().
      	                           getExtension(SoapPort.EXTENSION_TYPE));
      	                           
      	_logger_.severe("The service endpoint URL : '"+ port.getAddressUrl() 
      	                +"' is not reachable");
      	_logger_.severe("Verify if the URL is accessible and the correct "+ 
      	                 "proxy settings have been configured");
      	                 
        AdapterException ae =  new AdapterException(WSDCResourceBundle.class,
                                          WSDCResource.ERR_MESG_SEND_FAILED);
        throw ae;
      }
      
      // Nothing to do if the response is null. A null response 
      // indicates a one way style of service... 
      if(response == null)
       return null;
 
      // dump the response message to log
      dumpMessage(response);
      
      DataFormat formatHandler = dcOperation.getResponseFormat();
      // Default handlet is XML 
      if(formatHandler == null)
        formatHandler = new DataFormat(DataFormat.FORMAT_XML);
      
      _logger_.fine("Processing the SOAP response ");
      
      Object result = getResult(operation, response, formatHandler);
      
      _logger_.exiting(__THISCLASS__, "execute");
      
      sExecuteTimer.stop();

      return result;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae =  new AdapterException(WSDCResourceBundle.class,
                                              WSDCResource.ERR_INTERNAL_ERR);
      throw ae;
    }
    finally 
    {
      sExecuteTimer.cleanup();    
    }
  }
 
  //===========================================================================
  // ----  Private Methods for this provider ---
  //===========================================================================

  /**
   * Find the DC Operation for the sepcified operation name to be invoked
   * 
   * @param operationName The DCOperation to be executed. 
   * @return The DC operation.
   */
  private WSOperation findServiceOperation(
   String operationName
  )throws AdapterException
  {
    _logger_.fine("lookup operation '" + operationName + "'");

    Iterator portIterator = mOperations.keySet().iterator();
    while (portIterator.hasNext())
    {
      String portName = (String)portIterator.next();
      List operations  = (List)mOperations.get(portName);
      Iterator operationIter = operations.iterator();
      while(operationIter.hasNext())
      {
        WSOperation operation = (WSOperation)operationIter.next();
        if(operation.getName().equalsIgnoreCase(operationName))
          return operation;
      }   
    }
    
    // Fatal Error if the operation to invoke could not be found
    throw new AdapterException(WSDCResourceBundle.class, 
                               WSDCResource.ERR_NOSUCH_OPERATION, 
                               new Object[]{operationName});
  }

  //===========================================================================
  //  -------- Private methods to Build the SOAP request ----------
  //===========================================================================
  
  /**
   * Set the Header part values on the request message. 
   *
   * @param message     The Request message
   * @param messageNode The Complex message node representing the payload
   *                    for this message.
   * @param params      The Parameter Map for the values to be set on the 
   *                    header parts.
   */
  private void setHeaderParts(
   MessagePrototype message,
   MessageNode messageNode,
   Map params
  )throws Exception
  {
    try
    {
      _logger_.entering(__THISCLASS__, "setHeaderParts");
      _logger_.fine("Setting SOAP headers on the request message");
      
      sSetHeaderTimer.start();
      
      DataTreeFactory adtFact = DataTreeFactory.newInstance();
      for(int i = 0; i < message.getNumHeaders(); i++)
      {
        HeaderPrototype header = message.getHeaderPrototype(i);
        ComplexNode headerNode  = adtFact.createComplexNode();
        // Headers are always doc lit -- as per WSDL spec
        setParameters(header, headerNode, params, true);
        messageNode.setHeaderPart(i, headerNode);
      }
      
      sSetHeaderTimer.stop();
       
      _logger_.exiting(__THISCLASS__, "setHeaderParts");
    }
    finally 
    {
      sSetHeaderTimer.cleanup();    
    }
  }

  /**
   * Set the part values on the body part for this message. 
   * 
   * @param message    The Message whose SOAP body parts need to be set.
   * @param messageNode The Node representing the message payload.
   * @param params      The parameter values for the SOAP body parts.
   */
  private void setParameters(
   ComplexPrototype message,
   ComplexNode messageNode, 
   Map params,
   boolean isDocLitOnly
  )throws AdapterException
  {
    try
    {
      sSetParamTimer.start();

      _logger_.entering(__THISCLASS__ , "setParameters");
      
      // Set the attribute  values on this message node 
      setAttributes(null, message, messageNode, params);

      Object paramVal = null;
      // build the complex payload structure by populating the message parameters
      for(int i = 0; i < message.getNumParts(); i++)
      {
        String partName = message.getPartName(i);
       
        Prototype partP = message.getPartPrototype(i);
        // Normalize part names for the lookup. When building the JSR 227 
        // Strcuture definition, all Hyphens are replaced by underscores. 
        // this normalization is only done for the lookup. 
        // Request is populated with the actual parameter name, i.e with Hyphens
        paramVal = params.get(partName.replace(HYPHEN, UNDERSCORE));
  
        _logger_.fine("Setting value '" + paramVal + "' for parameter '" +
                      partName +"'"); 
       
        // Set the parameter value based on the part type.
        if(partP instanceof AtomicPrototype)
        {
          if(paramVal != null)
          {
            messageNode.setPart(partName, paramVal);
          }
          // If the part is required and not NILLABLE
          else if(message.isPartRequired(i) && !message.isPartNillable(i))
          {
            _logger_.severe("Value for parameter '" + partName + 
                                                       "' cannot be null");
            throw new AdapterException(WSDCResourceBundle.class, 
                                       WSDCResource.ERR_NULL_PART_VALUE,
                                       new Object[]{partName});
          }
        }
        // Complex parameter
        if(partP instanceof ComplexPrototype)
        {
          ComplexNode complexNode = null;
          
          String topPartName = partName;
          // if the message is doc lit only, then the top element appears under
          // body node.
          if(isDocLitOnly && message.getQName() != null)
          {
            topPartName = message.getQName().getLocalPart();
          }
          
          paramVal = params.get(topPartName.replace(HYPHEN, UNDERSCORE));
          
          // If this is an object based parameter passing model, then 
          // the value is introspected and the payload is set up .
          if(paramVal != null && !isSimpleContent((ComplexPrototype)partP))
          {
            complexNode = createComplexPart(paramVal, (ComplexPrototype)partP);
          }
          // If this is a flattened complex parameter passing method, then
          // look up the param map to see if it contains flattened param
          // names. 
          else if(hasValue(topPartName, params))
          {
            complexNode = createComplexNode(topPartName,
                                           (ComplexPrototype)partP, params);
          }
          // If it is neither and the part is required, then 
          // flag this as an error.
          else if(message.isPartRequired(i) &&  !message.isPartNillable(i))
          {
            _logger_.severe("Value for parameter '" + topPartName + 
                                                        "' cannot be null");
            throw new AdapterException(WSDCResourceBundle.class, 
                                       WSDCResource.ERR_NULL_PART_VALUE,
                                       new Object[]{topPartName});
          }
          // Complex node is created. set it up on the message node. 
          if(complexNode != null)
            messageNode.setPart(partName, complexNode);
        }  
        // parameter is an array.
        if(partP instanceof ArrayPrototype)
        {
          // For arrays we use the object introspection model always... 
          // Semantics of flattened heirachy cannot be established.
          if(paramVal != null)
          {
            ArrayNode arrayNode = createArrayPart((ArrayPrototype)partP, 
                                                  paramVal);
            messageNode.setPart(partName, arrayNode);
          }
          else if(message.isPartRequired(i) && !message.isPartNillable(i))
          {
            throw new AdapterException(WSDCResourceBundle.class, 
                                       WSDCResource.ERR_NULL_PART_VALUE,
                                       new Object[]{partName});
          }        
        }
      }
      
      sSetParamTimer.stop();
  
      _logger_.exiting(__THISCLASS__, "setParameters");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(WSDCResourceBundle.class, 
                                 WSDCResource.ERR_CREATE_SOAP_REQUEST);
    }
    finally
    {
      sSetParamTimer.cleanup();
    }
  }

  /**
   * Create a Complex Node for the parts, based on the fully qualified part name.
   * 
   * @param partPath The fully qualified part name in a complex structure.
   * @param part     The prototype describing this part structure.
   * @param params   The parameter table to look up for values for the 
   *                 part structure.
   */
  private ComplexNode createComplexNode(
   String partPath,
   ComplexPrototype part,
   Map params
  )throws Exception
  {
    _logger_.entering(__THISCLASS__, "createComplexNode");

    ComplexNode complexNode = mADTFactory.createComplexNode();
    String fullName = null;
    Object val = null;

    // Set the attributes on the complex node
    setAttributes(partPath, part, complexNode, params);

    // If this complex type is an extension of simple content..     
    // Set the content on this node.
    if(part.hasContent())
    {     
      val = params.get(partPath);
      if(val != null)
      {
        _logger_.fine("part is a simple content with value " + val);

        complexNode.setContent(val);
      }
    }

    // Set the Values on the parts.
    for(int i = 0; i < part.getNumParts(); i++)
    {
      String partName = part.getPartName(i);
      fullName = new StringBuffer(partPath).append('_').
                 append(partName).toString().replace(HYPHEN, UNDERSCORE);
      
      Prototype partP = part.getPartPrototype(i);

      _logger_.fine("setting value for parameter " + fullName);

      // Get the parameter value
      val = params.get(fullName);
      
      if(partP instanceof AtomicPrototype)
      {
        if(val != null) 
        {
          complexNode.setPart(partName, val);
        }
        else if(part.isPartRequired(i) && !part.isPartNillable(i))
        {
          _logger_.severe("Value for parameter '" + fullName + 
                                                  "' cannot be null");
          throw new AdapterException(WSDCResourceBundle.class, 
                                     WSDCResource.ERR_NULL_PART_VALUE,
                                      new Object[]{fullName});
        }
      }
       
      if(partP instanceof ComplexPrototype)
      {
        ComplexNode partNode = null;

        if(hasValue(fullName, params))
        {
          partNode = createComplexNode(fullName,(ComplexPrototype)partP,
                                        params);
          complexNode.setPart(partName, partNode);
        }
        else if(part.isPartRequired(i) && !part.isPartNillable(i))
        {
          _logger_.severe("Value for parameter '" + fullName + 
                                                  "' cannot be null");
          throw new AdapterException(WSDCResourceBundle.class, 
                                     WSDCResource.ERR_NULL_PART_VALUE,
                                     new Object[]{fullName});
        }
      }
      if(partP instanceof ArrayPrototype)
      {
      	if(val != null)
      	{
          ArrayNode arrayNode = createArrayPart((ArrayPrototype)partP, 
                                             val);
          complexNode.setPart(partName, arrayNode);
        }
        else if(part.isPartRequired(i) && !part.isPartNillable(i))
        {
          throw new AdapterException(WSDCResourceBundle.class, 
                                     WSDCResource.ERR_NULL_PART_VALUE,
                                     new Object[]{fullName});
        }
      }
    }
    return complexNode;
    
  }

  /**  
   * Create an ArrayNode representing an array parameter with 
   * all the array items
   *
   * @param part   The prototype describing this array part.
   * @param arrVal The Object representing this array value.
   * 
   * @return The Array node representing the array part in 
   *         the SOAP payload.
   *
   * @throws Exception if the ArrayPart cannot be constructed for the 
   *         payload.
   */
  private ArrayNode createArrayPart(
   ArrayPrototype part,
   Object arrVal
  )throws Exception
  {
    int dimensions = part.getNumDimensions();
    ArrayNode arrNode = mADTFactory.createArrayNode(dimensions);
                
    Prototype partPrototype = part.getPrototype();
    if(partPrototype instanceof AtomicPrototype)
    {
      arrNode.setValues(arrVal);
    }
    if(partPrototype instanceof ComplexPrototype)
    {
      int[] arrDimensions = new int[dimensions];
      int length = Array.getLength(arrVal);
      arrDimensions[0] = length;
      Object nodes = Array.newInstance(ComplexNodeImpl.class,
                                       arrDimensions);
      for(int i = 0; i < length; i++)
      {
        Object item = createArrayItem(Array.get(arrVal, i), 
                                      dimensions -1, 
                                     (ComplexPrototype)partPrototype);
        Array.set(nodes, i, item);
      }
      arrNode.setValues(nodes);
    }
    return arrNode;
  }

  /**  
   * Create an Array Item at the Nth Dimension. 
   * 
   * @param val The Object representing the Array Value at the Nth
   *            dimension. 
   * @param dimension The dimension at which the item is to be created
   * @param part      The prototype that describes the item content for this
   *                  array item 
   * 
   * @return The array item. The array item can be an item representing the 
   *         complex part if the current dimension is the last dimensions. 
   *         If the array item is a part of multidimensional array then the 
   *         array item is a single dimension array 
   */
  private Object createArrayItem(
   Object val,
   int dimension,
   ComplexPrototype part
  )throws Exception
  {
    if(dimension == 0)
     return createComplexPart(val, part);
      
    int length = Array.getLength(val);
    Object nodes = Array.newInstance(ComplexNodeImpl.class,
                                     length);
    dimension --;                                     
    for(int i = 0; i < length; i++)
     Array.set(nodes, i, createArrayItem(Array.get(val, i), dimension, part));
 
    return nodes;
  }

  /**  
   * Create a Complex Part by introspecting the parameter value representing 
   * the value of the part.
   * 
   * @param paramVal The Object representing the parameter value.
   * @param part     The Prototype that describes this part.
   *
   * @return The Complex Node that describes this part structure in the 
   *         SOAP payload.
   */
  private ComplexNode createComplexPart(
   Object paramVal,
   ComplexPrototype part
  )throws Exception
  {
    ComplexNode complexNode = mADTFactory.createComplexNode();
    Map valueMap = getValueMap(paramVal);

    setAttributes(null, part, complexNode, valueMap);
    
    for(int i = 0; i < part.getNumParts(); i++)
    {
      String partName = part.getPartName(i);
      Prototype partP = part.getPartPrototype(i);
      Object val =  valueMap.get(partName.toLowerCase());
      
      if(val != null)
      {
        if(partP instanceof AtomicPrototype)
          complexNode.setPart(partName, val);
       
        if(partP instanceof ComplexPrototype)
        {
          ComplexNode partNode = createComplexPart(val, (ComplexPrototype)partP);
          complexNode.setPart(partName, partNode);
        }
        if(partP instanceof ArrayPrototype)
        {
          ArrayNode arrayNode = createArrayPart((ArrayPrototype)partP, 
                                                 val);
          complexNode.setPart(partName, arrayNode);
        } 
      }
      else if(part.isPartRequired(i) && !part.isPartNillable(i))
      {
        _logger_.severe("Value for parameter '" + partName + 
                                                   "' cannot be null");
        throw new AdapterException(WSDCResourceBundle.class, 
                                   WSDCResource.ERR_NULL_PART_VALUE,
                                   new Object[]{partName});
      }
    }
    return complexNode;
  }

  /**
   * Introspect a object representing a part value and build 
   * a map to query the values. 
   * 
   * @param val The Object representing a complex part value
   *            that needs to be introspected.
   *
   * @return The Map represnting the values.
   */
  private Map getValueMap(
   Object val
  )throws Exception
  {
    HashMap valueMap = new HashMap();

    if(val == null)
      return valueMap;

    BeanInfo beanInfo = Introspector.getBeanInfo(val.getClass());
    PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors();

    for(int i = 0; i < descriptors.length; i++)
    {
      String propertyName = descriptors[i].getName();
      Method readMethod = descriptors[i].getReadMethod();
      if(readMethod != null)
      {
        Object propertyVal = readMethod.invoke(val, new Object[]{});
        valueMap.put(propertyName.toLowerCase(), propertyVal);
      }
    }
    return valueMap;
  }

  /**  
   * Set the Attribute values on a part. 
   * 
   * @param part The prototype that describes the part.
   * @param partNode The Node that represents the payload with the 
   *                 attributes value set.
   * @param params   The values of the attributes to be set on the 
   *                 message part.
   */
  private void setAttributes(
   String pathName,
   ComplexPrototype part, 
   ComplexNode partNode,
   Map params
  )throws AdapterException
  {
    _logger_.entering(__THISCLASS__, "setAttributes");

    String attName     = null;
    String fullAttName = null;
    Object attVal      = null;

    for(int i = 0; i < part.getNumAtts(); i++)
    {
      attName = part.getAttName(i);

      if(pathName != null)
      {
        // normalize attribute names for lookup.
        fullAttName = new StringBuffer(pathName).append('_').
  	               append(attName).toString().replace(HYPHEN, UNDERSCORE);
      }
      else
      {
        fullAttName = attName;     
      }

      attVal = params.get(fullAttName);
     
      if(attVal != null)
      {
      	_logger_.fine("setting value '" + attVal +
                             "' for attribute '"+ fullAttName);
        partNode.setAtt(attName, attVal);                             
      }
      else if(part.isAttRequired(i) && attVal == null)
      {
        _logger_.severe("Value for parameter '" + fullAttName + 
                                                    "' cannot be null");
        throw new AdapterException(WSDCResourceBundle.class, 
                                   WSDCResource.ERR_NULL_PART_VALUE,
                                   new Object[]{attName});
      }
    }
  
    _logger_.exiting(__THISCLASS__, "setAttributes");
  }

  /**
   * Private helper that checks if the params map has been populated with 
   * a complex parameter value.
   */ 
  private boolean hasValue(
   String paramName,
   Map params
  ) 
  {
    java.util.Set set = params.entrySet();    
    Iterator paramIter = set.iterator();
    Map.Entry paramEntry = null;

    while(paramIter.hasNext())
    {
      paramEntry = (Map.Entry)paramIter.next();
      String pName = (String)paramEntry.getKey();

      if(paramName.length() > 0 && pName.startsWith(paramName) && 
         paramEntry.getValue() != null)
       return true;
    }
    return false;
  }
  
  /**
   * Check if the Complex type is really an extension of a 
   * Simple XSD type.
   * 
   * @param part The complex type to be checked
   * @return <code>true</code> if the complex part is indeed an 
   *         extension of simple content, <code>false</code> otherwise
   */
  private boolean isSimpleContent(
   ComplexPrototype part
  )
  {
    return (part != null && 
            part.hasContent() && part.getNumAtts() == 0 && 
            part.getNumParts() == 0);
  }

  //==========================================================================
  // --------- Private API's to handle SOAP response ---------
  //==========================================================================

  /**
   * Get the Java return type of this operation, if the Operation returns 
   * a simple type.
   * 
   * @param The operation whose return type is needed.
   * 
   * @return the String representing the java return type of this 
   *         operation. returns null if the return type is a 
   *         complex structure.
   */
  private String getReturnType(
   MessagePrototype outMessage 
  )
  {
    ComplexPrototype outPart = null;

    // unwrap the parts if we are dealing with Wrapped style of services. 
    if(outMessage.isDocLitWrapped())
      outPart = outMessage.getWrappedParams();
    else 
      outPart = outMessage;

    // If the message has just one out part and is an atomic part, 
    // return its type.
    if(outPart.getNumParts() == 1 && 
        outPart.getPartPrototype(0) instanceof AtomicPrototype)
      return ((AtomicPrototype)outPart.getPartPrototype(0)).getType();
    
    return null;   
  } 

  /**
   * Handle the SOAP fault if the repsonse generated one.
   * 
   * @param fault The SOAP fault generated by the response.
   * 
   * @throws AdapterException
   */
  private void handleFault(
   SOAPFault fault
  )throws AdapterException
  {
    //String faultStr = fault.getFaultCodeAsName().getQualifiedName();
    String faultStr = fault.getFaultString();

    _logger_.severe("The Web Service call generated a SOAP Fault : " +
                    faultStr);
    
    throw new AdapterException(WSDCResourceBundle.class,
                               WSDCResource.ERR_SOAP_FAULT, 
                               new Object[]{faultStr});
  }
  
  /**
   * Get the result RSI or the Java object representation for the result for 
   * the operation from the SOAP response. 
   * <p>
   *  The result can be a simple value such as string or integer. The java
   *  Object instance for that type representation is returned for e.g
   *  java.lang.Integer / java.lang.String etc. 
   * </p>
   * <p> 
   *  If the SOAP response returns a collection or a complex XML structure, 
   *  the the iterators to build the RSI are created. 
   * </p>
   * <p>
   *  The SOAP response can also return data in complex strcutures as a part of 
   *  the response headers. In this case, each header structure is a top level
   *  RSI along with the data returned by in the body. Each RSI now becomes a 
   *  top level accessor in the final result structure.
   *  In such a case a root level accessor is constructed and all the top level
   *  Accessors are placed under the root accessor. The root accessor then
   *  defines the final structure of the result.
   * </p>
   * 
   * @param operation The operation that was invoked. 
   * @param response  The SOAP response generated for this operation invocation
   * @param format    The expected format of the data in the soap response. The
   *                  actual format can be either CSV or XML content.
   * 
   * @return The result of the operation, that could either be an iterator if
   *          the operation returns a complex type or the java object 
   *          representation of the simple type.
   * 
   * @throws AdapterException if an invalid reponse was generated or SOAP fault
   *         occurred or the format handlers are unable to construct the 
   *         result iterator structures for the response data.
   */
  private Object getResult(
   Operation operation,
   SOAPMessage response,
   DataFormat format
  )throws AdapterException
  {
    Object result = null;
    try
    {
      _logger_.entering(__THISCLASS__, "getResult");
      
      sGetResultTimer.start();
        
      SOAPPart soapPart = response.getSOAPPart();
      SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
      SOAPBody soapBody = soapEnvelope.getBody();
      SOAPHeader soapHeader = soapEnvelope.getHeader();
     
      if(soapBody.hasFault())
        handleFault(soapBody.getFault());
        
      Message outMessage = operation.getOutputMessage();
      // One way operation.. nothing to return.
      if(outMessage == null)
        return null;

      MessagePrototype outMessagePrototype = 
                            (MessagePrototype)outMessage.getExtension(
                                              MessagePrototype.EXTENSION_TYPE);

      // This is a one way operation .. no return value.
      if(outMessagePrototype == null)
        return null;

     Object bodypayLoad = processBody(soapBody, outMessagePrototype, format);
     Object headerpayLoad = processHeaders(soapHeader, outMessagePrototype);
                                                   
     int numHeaders = outMessagePrototype.getNumHeaders();
     
     // No SOAP body payload.
     if(bodypayLoad == null)
     {
       //Case 1 : No SOAP Body && no Headers i.e No Response payload at all.. 
       // Ideally this may not happen, But there may be some wierdo services
       // one way style services, that return an empty envelope. 
       if(numHeaders == 0)
        return null;
        
       //Case 2 : NO SOAP Body && just one header (Simple / Complex Type). The 
       // single haeader will be treated just as a normal return value.
       if(numHeaders == 1)
       {
         result = headerpayLoad;
       }
       // Case 3 : No SOAP Body and Multiple headers. This is a multiple return
       // type case.
       else
       {
         result = createRootRSI(operation, headerpayLoad, null);
       }
     }
     else
     {
       // Case 4: SOAP Body exists .. but no return headers. 
       if(numHeaders == 0 && getNumParts(outMessagePrototype) == 1)
       {
         result = bodypayLoad;
       }
       //Case 5 : SOAP Body and Headers exist.
       //Case 6 : No Headers, but multiple return values.
       else
       {
         result = createRootRSI(operation, headerpayLoad, bodypayLoad);
       }
     }
      
     sGetResultTimer.stop();
 
      _logger_.exiting(__THISCLASS__, "getResult", result);

      return result;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      _logger_.severe("verify if the incomming response confirms to the schema" +
                      "structure defined in the WSDL");
      
      AdapterException ae = new AdapterException(WSDCResourceBundle.class,
                                            WSDCResource.ERR_PROCESS_SOAP_RESP);
      throw ae;
    }
    finally 
    {
      sGetResultTimer.cleanup();
    }
  }
  
  /** Create the ROOT accessor
   * If there are SOAP headers in the response payload, then there 
   * will be mulitple RSI sets that will be returned by this operation.
   * Each RSI will now have to be made as an accessor. Now create a 
   * ROOT Accessor for the entire response payload. We will call this
   * ROOT accessor for the response as the RESULT.  
   * Under the RESULT Accessor, the Accessors for the header RSI's 
   * are pushed in first. The Accessor for the Body RSI is pushed
   * after that. The rsiMap contains the accessors for all the RSI's. 
   * Once the RSI Map is set up, create a List for our root Accessor 
   * "RESULT" and update it with the RSI map.
   */
  private Object createRootRSI(
   Operation operation,
   Object headerpayLoad,
   Object bodypayLoad
  ) throws Exception
  {
    HashMap rootMap = new HashMap();
    ArrayList rootList = new ArrayList();
    ArrayList returnList = new ArrayList();
    Map rsiMap = new HashMap();
    
    String rootAccName = new StringBuffer(operation.getOperationName()).
                      append('_').append(WSOperation.RESULT).toString();
 
    Message outMessage = operation.getOutputMessage();
    MessagePrototype outMessagePrototype = 
                          (MessagePrototype)outMessage.getExtension(
                                            MessagePrototype.EXTENSION_TYPE);

    
    _logger_.fine("Creating Root Accessor " + rootAccName);
    
    returnList.add(rootMap);
    rootMap.put(rootAccName, rootList);
    
    String payloadName = getHeaderName(outMessagePrototype);
    addPayLoad(payloadName, headerpayLoad, rsiMap, rootList);
    
    payloadName = getReturnName(outMessagePrototype, null);
    addPayLoad(payloadName, bodypayLoad, rsiMap, rootList);
    
    rootList.add(rsiMap);
    return returnList.iterator();
  }
  
  private void addPayLoad(
    String payLoadName,
    Object payLoad,
    Map rsiMap, 
    List rootList
  )
  {
    Iterator resultIter;
    if(payLoad instanceof Collection)
    { 
       resultIter = ((Collection)payLoad).iterator();
       Map returnMap = (Map)resultIter.next();
       
       Iterator keyIter = returnMap.keySet().iterator();
       while(keyIter.hasNext())
       {
         String name = (String)keyIter.next();
         rsiMap.put(name, returnMap.get(name));
       }
     }
     // TODO -- See if this can be optimized for CSV
     else if(payLoad instanceof Iterator)
     {
       while( ((Iterator)payLoad).hasNext())
       {
         rootList.add(((Iterator)payLoad).next());
       }
     }
     else
     {
       // put the simple type result in the toplevel RSI Map.
       rsiMap.put(payLoadName, payLoad);
     }
  }
  
  /**
   * Get the result name from which the iterators can be created. 
   * @param outMessagePrototype
   * @return
   */
  private String getReturnName(
   MessagePrototype outMessagePrototype, 
   SOAPBody soapBody
  )
  {
    String returnName = null;
    int numParts =  getNumParts(outMessagePrototype);
    
    // No return parts.... return null.
    if(numParts == 0)
      return null;
    
    if(outMessagePrototype.isDocLitWrapped()) 
    {
      // If we have a single return part after unwrapping .......
      if(numParts == 1)
        returnName = outMessagePrototype.getWrappedParams().getPartName(0);
      else
        // The result name from which the root iterator will be created
        // will be the wrapper. 
        returnName = outMessagePrototype.getQName().getLocalPart();
    }
    // For doc-literal unwrapped style services, the return structure
    // is the name of the outmessage part.
    else if(outMessagePrototype.getStyle() == MessagePrototype.STYLE_DOCUMENT
            && outMessagePrototype.getUse() == MessagePrototype.USE_LITERAL)
    {
      // Single return part....
      if(numParts == 1)
        returnName = outMessagePrototype.getQName().getLocalPart();
      else if(soapBody != null)
        returnName = soapBody.getLocalName();
    }
    // if rpc style service, get the first part name.
    else if (outMessagePrototype.getStyle() == MessagePrototype.STYLE_RPC)
    {
      if(numParts == 1)
        returnName = outMessagePrototype.getPartName(0);
      else
        returnName = outMessagePrototype.getQName().getLocalPart();
    }
    
    return returnName;
  }
  
  
  private int getNumParts(
   MessagePrototype message
  ) 
  {
    int numParts = 0;
    
    if(message.isDocLitWrapped())
      numParts = message.getWrappedParams().getNumParts();
    else
      numParts = message.getNumParts();
      
    return numParts;
  }
 
  
  private Object processBody(
   SOAPBody soapBody,
   MessagePrototype outMessagePrototype,
   DataFormat format
  ) throws Exception
  {
    Node resultNode = null;
    Object result = null;
    String returnName = getReturnName(outMessagePrototype, soapBody);
    String returnType = getReturnType(outMessagePrototype);
    
    // Get the name of the toplevel node in the response payload that 
    // represents the return type for this operation execution
    
    if(returnName == null)
      return null;
      
    // Process the SOAP Body. Get the TOP level nede representing the response
    // payload and process the Node based on the operations format handler.
    NodeList resultList = soapBody.getElementsByTagName(returnName);
    if(resultList.getLength() > 1)
    {
      _logger_.fine("Result is a collection of "
                                   + resultList.getLength() + " items");

      // result is a collection. Get the parent of the collection and 
      // create the iterator, we will pick put the collection 
      // iterator from the parent.
      resultNode = resultList.item(0).getParentNode(); 
      // get the node name whose children are the collection.
      String collectionName = resultNode.getLocalName();
      result = format.processData(resultNode, soapBody, returnType);

      //if the result is transformed, then do not manipulate it. We assume
      // the user has provided the appropriate transformation to enable the
      // resulting data to confirm with the transformation XSD provided. 
      if(format.getProperty(DataFormat.TRANS_LOC) == null)
      {
        Iterator collectionIter = ((Collection)result).iterator();
        Map collectionMap = (Map)collectionIter.next();
        result = collectionMap.get(collectionName);
      }
    }
    else
    {
      // Transformation / no transformation we are returning the 
      // non-collection result as is. At this point the result strcuture 
      // created should be confirmant either with the schema published in 
      // the WSDL or a transformation xsd provided by the user incase XSL
      // is applied. If the result is null here, then look for some thing
      // wrong in either the XSD or XSL. 
      // Non collection iterator.
      resultNode = resultList.item(0);
      if(resultNode != null)
       result = format.processData(resultNode, soapBody, returnType);
    }
    
    //Modify the result here ......
    if(getNumParts(outMessagePrototype) > 1 && 
       format.getProperty(DataFormat.TRANS_LOC) == null)
    {
      if(result instanceof Collection)
      {
        Iterator iter = ((Collection)result).iterator();
        Map resultMap = (Map)iter.next();
        result = resultMap.get(returnName);
      }
    }
    return result;
  }

  /**
   * Process the response headers and return a map contaning the 
   * RSI for each header in the response.
   * 
   * @param resultRSIMap The RSIMap which contains the result RSI's
   * @param header The SOAPHeader returned in the response payload.
   * @param message The response message Prototype that describes the 
   *                structure of the headers.
   * @param format The Format describing the header data contents.
   */
  private Object processHeaders(
   SOAPHeader header,
   MessagePrototype message
  )throws Exception
  {
    Object headerPayLoad = null;
    String   headerName   = null;
    Node     headerNode   = null;
    String   javaType = null;
    //Data format for procesing headers is always XML.
    DataFormat format = new DataFormat(DataFormat.FORMAT_XML);

    try
    {
      _logger_.entering(__THISCLASS__, "processResponseHeaders");
      
      int numHeaders = message.getNumHeaders();
      
      if(numHeaders == 0)
       return null;
      
      sProcessResponseTimer.start();
      
      if(numHeaders == 1)
      {
        HeaderPrototype headerPrototype = message.getHeaderPrototype(0);
        headerName = headerPrototype.getQName().getLocalPart();
        Prototype part = headerPrototype.getPartPrototype(0);
        // If the one and only header is a simple type.
        if(part instanceof AtomicPrototype)
        {
          javaType = ((AtomicPrototype)part).getType();
        }
        
        headerNode = getChildElement(header, headerName);
      }
      else
      {
        // Header node is the top level header itself.
        headerNode = header;
      }
        
      headerPayLoad = format.processData(headerNode, header, javaType);
      
      if(numHeaders > 1)
      {
        //if the payload is a collection of multiple headers.. 
        // return the list to the collection.
        if(headerPayLoad instanceof Collection)
        {
          Iterator iter = ((Collection)headerPayLoad).iterator();
          Map resultMap = (Map)iter.next();
          headerPayLoad = resultMap.get(headerNode.getLocalName());
        }
      }
      
      sProcessResponseTimer.stop();
      
      _logger_.exiting(__THISCLASS__, "processResponseHeaders");
      
    }
    finally
    {
      sProcessResponseTimer.cleanup();
    }
    
    return headerPayLoad;
  }
  
  
  private String getHeaderName(
    MessagePrototype message
  )
  {
    if(message.getNumHeaders() == 1)
    {
      HeaderPrototype headerPrototype = message.getHeaderPrototype(0);
      String headerName = headerPrototype.getQName().getLocalPart();
      return headerName;
    }
    
    return null;
  }

  /**
   * Pick out the first Child element from a parent, given the child's
   * name.
   *
   * @param parent The Parent Element
   * @param kid    The name of the child element.
   */
  private Node getChildElement(
   Element parent,
   String kid
  )
  {
    NodeList resultList = parent.getElementsByTagName(kid);
    if(resultList.getLength() > 0)
      return resultList.item(0);
      
    return null;
  }
  
  //====================================================================
  // Utility method to dump the message to log
  //====================================================================
  
  /**
   * dump this SOAP message to the log.
   */
  private void dumpMessage(
   SOAPMessage message
  )
  {
    try
    {
      java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
      message.writeTo(bos);
      String messageStr = bos.toString();
      _logger_.finest(messageStr);
      bos.close();
    }
    catch(Exception e)
    {
      // don;t care ....
    }
  }
}
