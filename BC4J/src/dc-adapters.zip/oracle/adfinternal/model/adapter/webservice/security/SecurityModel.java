/*
 * @(#)SecurityModel.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 * 
 * DESCRIPTION
 *    
 * NOTES
 * 
 * MODIFIED    
 *    vpamadi    10/18/05 - Some API changes in the WSS layer is causing the 
 *                          DC security model to break. The wssec config 
 *                          serializers need to be explicitly initialized now. 
 *    vpamadi    06/29/05 - SAML and X509 Support 
 *    vpamadi    01/05/05 - creation
 */

package oracle.adfinternal.model.adapter.webservice.security;

import java.util.HashMap;
import java.util.Iterator;

import oracle.j2ee.ws.common.mgmt.ConfigSerializer;
import oracle.security.wss.config.DecryptConfigType;
import oracle.security.wss.config.DecryptConfigTypeImpl;
import oracle.security.wss.config.EncryptConfigType;
import oracle.security.wss.config.EncryptConfigTypeImpl;
import oracle.security.wss.config.EncryptionMethodsConfigType;
import oracle.security.wss.config.EncryptionMethodsConfigTypeImpl;
import oracle.security.wss.config.InboundConfigType;
import oracle.security.wss.config.InboundConfigTypeImpl;
import oracle.security.wss.config.KeyConfigType;
import oracle.security.wss.config.KeyConfigTypeImpl;
import oracle.security.wss.config.KeyStoreConfigType;
import oracle.security.wss.config.KeyStoreConfigTypeImpl;
import oracle.security.wss.config.OutboundConfigType;
import oracle.security.wss.config.OutboundConfigTypeImpl;
import oracle.security.wss.config.SamlAuthorityConfigType;
import oracle.security.wss.config.SamlAuthorityConfigTypeImpl;
import oracle.security.wss.config.SamlTokenConfigType;
import oracle.security.wss.config.SamlTokenConfigTypeImpl;
import oracle.security.wss.config.SecurityOperation;
import oracle.security.wss.config.SecurityOperationImpl;
import oracle.security.wss.config.SecurityPort;
import oracle.security.wss.config.SecurityPortImpl;
import oracle.security.wss.config.SignatureConfigType;
import oracle.security.wss.config.SignatureConfigTypeImpl;
import oracle.security.wss.config.SubjectConfirmationMethodConfigType;
import oracle.security.wss.config.SubjectConfirmationMethodConfigTypeImpl;
import oracle.security.wss.config.TimestampConfigType;
import oracle.security.wss.config.TimestampConfigTypeImpl;
import oracle.security.wss.config.UsernameTokenConfigType;
import oracle.security.wss.config.UsernameTokenConfigTypeImpl;
import oracle.security.wss.config.VerifySignatureConfigTypeImpl;
import oracle.security.wss.config.X509TokenConfigType;
import oracle.security.wss.config.X509TokenConfigTypeImpl;
import oracle.security.wss.interceptors.ClientSecurityDescriptor;
import oracle.security.wss.config.VerifySignatureConfigType;

import oracle.webservices.model.Component;
import oracle.webservices.model.Operation;
import oracle.webservices.model.Port;

import oracle.xml.parser.v2.XMLDocument;
import org.w3c.dom.Element;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.model.adapter.AdapterException;
import oracle.adfinternal.model.adapter.webservice.WSDefinition;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;
import oracle.adf.model.connection.webservice.api.WebServicePolicies;

/**
 * SecurityModel defines the Security configuration for a Data control.
 * The current security model for the data control is the WS-SEC Standard 
 * proposed by the OASIS group
 * 
 * @author Vinay.Pamadi
 * @version 1.0
 * @since 10.1.3
 */

public class SecurityModel
{
  // security policy name 
  private static final String SECURITY_POLICY    = "security";

  // The XML document to that owns the XML representation of the 
  // component security configuration
  private XMLDocument      mDoc                 = new XMLDocument();
  
  // the security descriptor to create the serializers for the ports
  // and operations.
  private ClientSecurityDescriptor mDescriptor   = 
                                        new ClientSecurityDescriptor();
  // Seralizers for the Port and the operation security model
  private ConfigSerializer mPortSerializer      = null;
  private ConfigSerializer mOperationSerializer = null;
  // Map of the various port level and operation level configurations of 
  // this security model. The various configurations are held in this map
  // to avoid repeated serializations and de-serializations by the seralizers
  // when a component is accessed.
  private HashMap          mConfig               = null;
  
  //========================================================================
  //              ------ Logging support -----
  //========================================================================
  private ADFLogger _logger = ADFLogger.createADFLogger(WSDefinition.LOGGER);
  //Class name for logging .....
  private String           __thisClass__         = this.getClass().getName(); 

  /**
   * Instantiate this security model. Set up the configuration table and the 
   * security configuration serializers for the ports and operations.
   */
  public SecurityModel()
  {
    mConfig = new HashMap();
    // initialize the serializers.
    mDescriptor.initPortAndOpSerializer();
    mPortSerializer = mDescriptor.getPortSerializer();
    mOperationSerializer = mDescriptor.getOperationSerializer();
  }

  /**
   * Get or Create a {@link UsernameTokenConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be either a 
   * {@link oracle.webservices.model.Port} or a
   * {@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} for which
   *                  a {@link UsernameTokenConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link UsernameTokenConfigType} 
   *                  is to be created, incase it is not already configured 
   *                  for that component. <code>false<code> if creation is not
   *                  required. In this case, the token will be returned if it
   *                  had been configured on the component earlier, otherwise
   *                  null is returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link UsernameTokenConfigType} is configured and 
   *                  returned for the component. If the configuration does 
   *                  not exist and creation is not needed, a 
   *                  <code>null</code> is returned.
   *           
   * @throws {@link oracle.adf.model.adapter.AdapterException}
   *           If the {@link UsernameTokenConfigType} could not be configured 
   *           on the {@link oracle.webservices.model.Component}.
   */
  public UsernameTokenConfigType getUsernameToken(
   Component component,
   boolean create
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "getUsernameToken");

      UsernameTokenConfigType usernameConfig = null;
      // get the outbound configuration for this component.
      // create if not already present.
      OutboundConfigType config = getOutboundConfig(component, create);

      if(config != null)
      {
        // Try and fetch the username token configured on this component.
        usernameConfig = config.getUsernameToken();
        // if not yet configured and creation requested.. then create the
        // username config token
        if(usernameConfig == null && create)
        {
          _logger.fine("Creating and configuring username token on "+ 
                        component.getName());

          usernameConfig = new UsernameTokenConfigTypeImpl(mDoc);
          config.setUsernameToken(usernameConfig);
        }
      }

      _logger.exiting(__thisClass__, "getUsernameToken");
   
      return usernameConfig;
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__thisClass__, "getUsernameToken", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__thisClass__, "getUsernameToken", ae);
      throw ae;
    }
  }
  
  /**
   * Clear out all the authentication tokens set on a component
   * 
   * @param The port or the operation {@link Component} for which 
   *        the authentication tokens are to be cleared.
   */ 
  public void clearAuthenticationTokens(
   Component component
  )
  {
    try
    {
      _logger.entering(__thisClass__, "clearUsernameToken");

      UsernameTokenConfigType usernameConfig = null;
      // get the outbound configuration for this component.
      // create if not already present.
      OutboundConfigType config = getOutboundConfig(component, false);

      if(config != null)
      {
        config.setUsernameToken(null);
        config.setX509Token(null);
        config.setSamlToken(null);
      }

      _logger.exiting(__thisClass__, "clearUsernameToken");
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__thisClass__, "clearUsernameToken", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__thisClass__, "getUsernameToken", ae);
      throw ae;
    }
  }

  /**
   * Get or Create a {@link X509TokenConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can only be a 
   * {@link oracle.webservices.model.Port}.
   * 
   * @param component The port {@link oracle.webservices.model.Component} 
   *                  for which a {@link X509TokenConfigType} is to be created
   *                  or fetched.
   * @param create    <code>true</code> if the {@link X509TokenConfigType} 
   *                  is to be created, incase it is not already configured 
   *                  for that component. <code>false<code> if creation is not
   *                  required. In this case, the token will be returned if it
   *                  had been configured on the component earlier, otherwise
   *                  null is returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link X509TokenConfigType} is configured and 
   *                  returned for the component. If the configuration does 
   *                  not exist and creation is not needed, a <code>null</code>
   *                  is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link X509TokenConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */ 
  public X509TokenConfigType getX509TokenConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getX509TokenConfig");

    X509TokenConfigType x509Config = null;
    try
    {
      // get the outbound configuration for this component.
      // create if not already present.
      OutboundConfigType config = getOutboundConfig(component, create);

      // Get the outbound configuration for this component.
      if(config != null)
      {
        // Is an X509 Configuration already done on the component
        x509Config = config.getX509Token();

        // Create the configuration if requested.
        if(x509Config == null && create)
        {
          _logger.fine("Creating and configuring X509 token on "+ 
                               component.getName());

          x509Config = new X509TokenConfigTypeImpl(mDoc);
          config.setX509Token(x509Config);
        }
      }
   
      _logger.exiting(__thisClass__, "getX509TokenConfig", x509Config);
      
      return x509Config;
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__thisClass__, "getX509TokenConfig", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__thisClass__, "getX509TokenConfig", ae);
      throw ae;
    }
  }
  
  /**
   * Get or Create a {@link SamlTokenConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be a 
   * {@link oracle.webservices.model.Port} or a 
   * (@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} 
   *                  for which a {@link SamlTokenConfigType} is to be created
   *                  or fetched.
   * @param create    <code>true</code> if the {@link SamlTokenConfigType} 
   *                  is to be created, incase it is not already configured 
   *                  for that component. <code>false<code> if creation is not
   *                  required. In this case, the token will be returned if it
   *                  had been configured on the component earlier, otherwise
   *                  null is returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link SamlTokenConfigType} is configured and 
   *                  returned for the component. If the configuration does 
   *                  not exist and creation is not needed, a <code>null</code>
   *                  is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link SamlTokenConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */ 
  public SamlTokenConfigType getSamlTokenConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    SamlTokenConfigType samlToken = null;
    
    _logger.entering(__thisClass__, "getSamlTokenConfig");

    try
    {
      _logger.fine("Getting SAML token configuration for '"
                                          + component.getName() + "'");
                    
      // get the outbound configuration for this component.
      // create if not already present.
      OutboundConfigType config = getOutboundConfig(component, create);

      if(config != null)
      {
        // Is a SAML token already configured on the outbound 
        // configuration for this component.
        samlToken = config.getSamlToken();

        // Create and configure one if not already configured and 
        // creation is requested.
        if(samlToken == null && create)
        {
          _logger.fine("Creating and configuring Saml token on "+ 
                               component.getName());

          samlToken = new SamlTokenConfigTypeImpl(mDoc);
          config.setSamlToken(samlToken);
        }
      }
      
      _logger.exiting(__thisClass__, "getSamlTokenConfig", samlToken);

      return samlToken;
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__thisClass__, "getSamlTokenConfig", ae);
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__thisClass__, "getSamlTokenConfig", ae);
      throw ae;
    }
  }

  /**  
   * Create a new instance of the <code>SAML Authority</code> configuration. 
   * The <code>SAML Authority</code> is the entity that generates <code>SAML
   *</code> assertions on the subject'si authentication status.
   * 
   * @return A new instance of 
   *         {@link oracle.security.wss.config.SamlAuthorityConfigType}
   */
  public SamlAuthorityConfigType newSamlAuthorityConfig()
  {
    return new SamlAuthorityConfigTypeImpl(mDoc);
  }
  
  /**
   * Create a new instance of the Subject confirmation method configuration.
   * The Subject confirmation method specifies the method by which the 
   * subject's authentication status is asserted. 
   * 
   * @return A new instance of 
   *     {@link oracle.security.wss.config.SubjectConfirmationMethodConfigType}
   */
  public SubjectConfirmationMethodConfigType newSubjectConfirmationConfig()
  {
    return new SubjectConfirmationMethodConfigTypeImpl(mDoc);
  }

  /**
   * Get or Create a {@link SignatureConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be either a 
   * {@link oracle.webservices.model.Port} or a
   * {@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  a {@link SignatureConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link SignatureConfigType} is 
   *                  to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link SignatureConfigType} is configured and returned
   *                  for the component. If the configuration does not exist and 
   *                  creation is not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link SignatureConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */
  public SignatureConfigType getSignatureConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "getSignatureConfig");

      SignatureConfigType signConfig = null;
      // get the Outbound configuration for the component. create if not
      // already present.
      OutboundConfigType config = getOutboundConfig(component, create);
  
      if(config != null)
      {  
        // if the cofiguration has been configured for a signature.
        signConfig = config.getSignature();
        if(signConfig == null && create)
        {
          // create a new Signature config, if not already configured.
          signConfig = new SignatureConfigTypeImpl(mDoc);
          // set the signature configuration on the outbound configuration
          // for this component.
          config.setSignature(signConfig);
        }
      }
  
      _logger.exiting(__thisClass__, "getSignatureConfig");

      return signConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Clear the signature config for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        signature configuration should be removed.
   */
  public void clearSignatureConfig(
   Component component
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "clearSignatureConfig");

      SignatureConfigType signConfig = null;
      // get the Outbound configuration for the component. create if not
      // already present.
      OutboundConfigType config = getOutboundConfig(component, false);
  
      if(config != null)
      {  
        config.setSignature(null);
      }
      
      _logger.exiting(__thisClass__, "clearSignatureConfig"); 
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }  

  /**
   * Create a new instance of {@link TimestampConfigType}.
   *
   * @return a new instance of {@link TimestampConfigType}.
   */
  public TimestampConfigType newTimeStampConfig()
  {
    return new TimestampConfigTypeImpl(mDoc);
  }

  /**
   * Create a new instance of {@link KeyConfig}.
   *
   * @return a new instance of {@link KeyConfig}.
   */
  public KeyConfigType newKeyConfig()
  {
    return new KeyConfigTypeImpl(mDoc);
  }

  /**
   * Get or Create a {@link EncryptConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be either a 
   * {@link oracle.webservices.model.Port} or a
   * {@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  a {@link EncryptConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link EncryptConfigType} is 
   *                  to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link EncryptConfigType} is configured and returned
   *                  for the component. If the configuration does not exist and 
   *                  creation is not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link EncryptConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */
  public EncryptConfigType getEncryptConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "getEncryptConfig");

      EncryptConfigType encryptConfig = null;
      // get the outbound config for this component.
      OutboundConfigType config = getOutboundConfig(component, create);

      if(config != null)
      {
        // get the encryption configuration. Create one if it is 
        // not already created.
        encryptConfig = config.getEncrypt();
       
        if(encryptConfig == null && create)
        {
          encryptConfig = new EncryptConfigTypeImpl(mDoc);
          config.setEncrypt(encryptConfig);
        }
      }

      _logger.exiting(__thisClass__, "getEncryptConfig");

      return encryptConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Clear the Encryption configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        Encryption configuration should be removed.
   */
  public void clearEncryptConfig(
   Component component
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "clearEncryptConfig");

      // get the outbound config for this component.
      OutboundConfigType config = getOutboundConfig(component, false);

      if(config != null)
      {
        config.setEncrypt(null);
      }

      _logger.exiting(__thisClass__, "clearEncryptConfig");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Get or Create a {@link DecryptConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be either a 
   * {@link oracle.webservices.model.Port} or a
   * {@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  a {@link DecryptConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link DecryptConfigType} is 
   *                  to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link EncryptConfigType} is configured and returned
   *                  for the component. If the configuration does not exist and 
   *                  creation is not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link DecryptConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */
  public DecryptConfigType getDecryptConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "getDecryptConfig");

      DecryptConfigType decryptConfig = null;
      // Get the Inbound configuration for this component. 
      // create if not already configured.
      InboundConfigType config = getInboundConfig(component, create);

      if(config != null)
      {
        // get the decrypt configuration on this
        decryptConfig = config.getDecrypt();
        // if null, and needed to be created, then create and 
        // configure a new instance on this inbound configuration
        if(decryptConfig == null && create)
        {
          decryptConfig = new DecryptConfigTypeImpl(mDoc);
          config.setDecrypt(decryptConfig);
        }
      }
  
      _logger.exiting(__thisClass__, "getDecryptConfig");

      return decryptConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Clear the Decryption configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        decryption configuration should be removed.
   */
  public void clearDecryptConfig(
   Component component
  )throws AdapterException
  {
    try
    {
      _logger.entering(__thisClass__, "clearDecryptConfig");
      // get the outbound config for this component.
      InboundConfigType config = getInboundConfig(component, false);

      if(config != null)
      {
        config.setDecrypt(null);
      }

      _logger.exiting(__thisClass__, "clearDeccryptConfig");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Create a new instance of {@link EncryptionMethodsConfigType}.
   *
   * @return a new instance of {@link EncryptionMethodsConfigType}.
   */  
  public EncryptionMethodsConfigType getEncryptionMethods()
  {
    return new EncryptionMethodsConfigTypeImpl(mDoc);
  }

  /**
   * Get or Create a {@link VerifySignatureConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be either a 
   * {@link oracle.webservices.model.Port} or a
   * {@link oracle.webservices.model.Operation}.
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  a {@link DecryptConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link VerifySignatureConfigType}
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link VerifySignatureConfigType} is configured and 
   *                  returned for the component. If the configuration does not exist
   *                  and creation is not needed, a <code>null</code> 
   *                  is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link VerifySignatureConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */  
  public VerifySignatureConfigType getVerifySignatureConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getVerifySignatureConfig");

    VerifySignatureConfigType verifySignConfig = null;
    try
    {
      // Get the inbound configuration on the component.
      InboundConfigType config = getInboundConfig(component, create);
 
      if(config != null)
      {
        // get the verify signature configuration on the component
        // create if required and not already configured on the
        // component.
        verifySignConfig = config.getVerifySignature();
        if(verifySignConfig == null && create)
        {
          verifySignConfig = new VerifySignatureConfigTypeImpl(mDoc);
          config.setVerifySignature(verifySignConfig);
        }
      }

      _logger.exiting(__thisClass__, "getVerifySignatureConfig");
  
      return verifySignConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Clear the Signature Verification Configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        signature verification configuration should be removed.
   */
  public void clearVerifySignatureConfig(
   Component component
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getVerifySignatureConfig");

    try
    {
      // Get the inbound configuration on the component.
      InboundConfigType config = getInboundConfig(component, false);
  
      if(config != null)
      {
        config.setVerifySignature(null);
      }

      _logger.exiting(__thisClass__, "getVerifySignatureConfig");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }  

  /**
   * Get or Create a {@link KeyStoreConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port}
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  a {@link DecryptConfigType} is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the {@link KeyStoreConfigType}
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link KeyStoreConfigType} is configured and 
   *                  returned for the component. If the keystore does not exist
   *                  and creation is not needed, a <code>null</code> 
   *                  is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link KeyStoreConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  public KeyStoreConfigType getKeyStoreConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getKeyStoreConfig");

    KeyStoreConfigType keyStoreConfig = null;
    try
    {
      // Get the security port for the port component. Create 
      // if needed. 
      SecurityPort secPort = getSecurityPort(component, create);
      if(secPort != null )
      {
        // is a keystore configured. Create and configure if 
        // required. 
        keyStoreConfig = secPort.getKeyStore();   
        if(keyStoreConfig == null && create)
        {
          keyStoreConfig = new KeyStoreConfigTypeImpl(mDoc);
          secPort.setKeyStore(keyStoreConfig);
        } 
      }

      _logger.exiting(__thisClass__, "getKeyStoreConfig");    

      return keyStoreConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Clear the keystore configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        keystore configuration should be removed.
   */
  public void clearKeyStoreConfig(
   Component component
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "clearKeyStoreConfig");

    try
    {
      // Get the security port for the port component. Create 
      // if needed. 
      SecurityPort secPort = getSecurityPort(component, false);
      if(secPort != null )
      {
        secPort.setKeyStore(null);
      }
      
      _logger.exiting(__thisClass__, "getKeyStoreConfig");    
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }  

  /**
   * Get or Create a Signature key for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the Siganture Key is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the Signature key
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link KeyConfigType} for the signature key is 
   *                  is configured and returned for the component.
   *                  If the key does not exist and creation is not needed, a 
   *                  <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link KeyConfigType} for the signature key could
   *                  not be configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */  
  public KeyConfigType getSignatureKey(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getSignatureKey");

    KeyConfigType keyConfig = null;
    try
    {
      // Get the port level security configuration.
      SecurityPort secPort = getSecurityPort(component, create);
      if(secPort != null )
      {
        // verify if a signature key is configured. create otherwise.
        keyConfig = secPort.getSignatureKey();
        if(keyConfig == null && create)
        {
          keyConfig = new KeyConfigTypeImpl(mDoc);
          secPort.setSignatureKey(keyConfig);
        }
      }

      _logger.exiting(__thisClass__, "getSignatureKey");
    
      return keyConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Clear the signature key configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        signature key configuration should be removed.
   */
  public void clearSignatureKey(
   Component component
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "clearSignatureKey");

    try
    {
      // Get the port level security configuration.
      SecurityPort secPort = getSecurityPort(component, false);
      if(secPort != null )
      {
        secPort.setSignatureKey(null);
      }

      _logger.exiting(__thisClass__, "clearSignatureKey");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }  

  /**
   * Get or Create a Encryption key for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the Encryption Key is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the Encryption key
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   *                  In this case, the token will be returned if it had been 
   *                  configured on the component earlier, otherwise null is 
   *                  returned.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link KeyConfigType} for the Encryption key is 
   *                  is configured and returned for the component.
   *                  If the key does not exist and creation is not needed, a 
   *                  <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link KeyConfigType} for the Encryption key could
   *                  not be configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  public KeyConfigType getEncryptionKey(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getEncryptionKey");

    KeyConfigType keyConfig = null;
    try
    {
      // Get port level security configuration for this component
      SecurityPort secPort = getSecurityPort(component, create);
      if(secPort != null )
      {
        // if a encryption key is not configured, create and 
        // configure one 
        keyConfig = secPort.getEncryptionKey();
        if(keyConfig == null && create)
        {
          keyConfig = new KeyConfigTypeImpl(mDoc);
          secPort.setEncryptionKey(keyConfig);
        }
      }
    
      _logger.exiting(__thisClass__, "getEncryptionKey");
 
      return keyConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Clear the Encryption key configuration for the componenet. 
   * 
   * @param The Port / Operation {@link Component} for which the 
   *        Encryption key configuration should be removed.
   */
  public void clearEncryptionKey(
   Component component
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getEncryptionKey");

    try
    {
      // Get port level security configuration for this component
      SecurityPort secPort = getSecurityPort(component, false);
      if(secPort != null )
      {
        secPort.setEncryptionKey(null);
      }
    
      _logger.exiting(__thisClass__, "getEncryptionKey");
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Update the security configuration for individual components into the 
   * security policy for the components 
   * 
   *<p>
   * The individual configurations, port level or Operation level are 
   * serialized and updated into the {@link WebServicePolicies}
   *</p>
   *
   * @throws {@link AdapterException} if the policies cannot be 
   *         configured with the security information for any of the component.
   */
  public void updatePolicy()throws AdapterException
  {
    try 
    {
      _logger.entering(__thisClass__, "updatePolicy");

      // Get the components cached in the configuration map.
      Iterator iter = mConfig.keySet().iterator();
      Component component = null;
      while(iter.hasNext())
      {
        component = (Component)iter.next();
        // Fetch the policies for the component.
        WebServicePolicies policy = 
                               (WebServicePolicies)component.getExtension(
                                    WebServicePolicies.EXTENSION_TYPE, false);

        _logger.fine("Attempting to configure security for " +
                      component.getName());
        // If security is configured at the port level, seralize the 
        // configuration using a port level serilizer into the policy.
        if(component.getType() == Port.PORT_COMPONENT_TYPE)
        {


          SecurityPort secPort = (SecurityPort)mConfig.get(component);
          // Port level configuration cannot be null at this stage.
          if(secPort == null)
          {
            _logger.severe("Security configuration for port" + 
                           component.getName() + " cannot be null");
                           
            throw new AdapterException(WSDCResourceBundle.class,
                                       WSDCResource.ERR_SEC_PORT,
                                       new Object[]{component.getName()});
          }
        
          // update the port level security configuration
          policy.setPolicy(SECURITY_POLICY,
                          mPortSerializer.convertObjectsToDom(mDoc, secPort));
        }
      
        // If the component is an operation, serialize the security 
        // information using operation level serializers and update the 
        // operation level policy.
        if(component.getType() == Operation.OPERATION_COMPONENT_TYPE)
        {
          SecurityOperation secOperation = 
                                    (SecurityOperation)mConfig.get(component);
          // secOperation cannot be null at this stage. It is an error if we have 
          // a null in the configuration map.
          if(secOperation == null)
          {
            _logger.severe("Security configuration for operation :" 
                           + component.getName() + " cannot be null");
                           
            throw new AdapterException(WSDCResourceBundle.class,
                                       WSDCResource.ERR_SEC_OPERATION,
                                       new Object[]{component.getName()});
          }
          // update the operation level security configuration.
          policy.setPolicy(SECURITY_POLICY,
                          mOperationSerializer.convertObjectsToDom(mDoc, 
                                                            secOperation));
        }
      }
   
      _logger.exiting(__thisClass__, "updatePolicy");
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Reset the Security model. The cached configuration state is cleared
   * when reset is called. If called before {@link #updatePolicy()} then
   * any security information configured is lost.
   */
  public void reset()
  {
    _logger.fine("Resetting the SecurityModel");
    // clear the current configuration state. 
    if(!mConfig.isEmpty())
      mConfig.clear();
  }
  
  /**
   * Destroy this security model. 
   * <p>
   * Release all configuration and serializer handle references.
   * The security model becomes void after this call. 
   * The Data control definition should not attempt to use the use the reference
   * to this security model anymore. Subsequent security configurations must 
   * create a new SecurityModel instance. 
   *</p>
   */
  public void destroy()
  {
    _logger.fine("Destroying the security model. The model is now invalid");
    
    mDescriptor.destroyPortAndOpSerializer(); 
    // clear out the configuration.
    if(!mConfig.isEmpty())
      mConfig.clear();
    
    mPortSerializer = null;
    mOperationSerializer = null;
    mDescriptor = null;
    mConfig = null;
  }
  
 //================================================================================
 //                      Private API's for Security model
 //================================================================================  
 
 
  /**
   * Get or Create a {@link InboundConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the InboundConfigType is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the InboundConfigType
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link InboundConfigType}
   *                  is configured and returned for the component.
   *                  If the InboundConfigType does not exist and creation is 
   *                  not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link InboundConfigType}
   *                  could not be configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  private InboundConfigType getInboundConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    InboundConfigType inbound = null;
    
    _logger.entering(__thisClass__, "getInboundConfig");

    try
    {
      if(component.getType() == Port.PORT_COMPONENT_TYPE)
      {
        SecurityPort secPort = getSecurityPort(component, create);
        if(secPort != null)
        {  
          inbound = secPort.getInbound();
          if(inbound == null && create)
          {
            inbound = new InboundConfigTypeImpl(mDoc);
            secPort.setInbound(inbound);
          }
        }
      }
      if(component.getType() == Operation.OPERATION_COMPONENT_TYPE)
      {
        SecurityOperation secOperation = getSecurityOperation(component, create);
        if(secOperation != null)
        {   
          inbound = secOperation.getInbound();
          if(inbound == null && create)
          {
            inbound = new InboundConfigTypeImpl(mDoc);
            secOperation.setInbound(inbound);
          }
        }
      }
   
      _logger.exiting(__thisClass__, "getInboundConfig", inbound);

      return inbound;
    }
    catch(AdapterException ae)
    {
      throw ae;
    } 
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Get or Create a {@link OutboundConfigType} for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the OutboundConfigType is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the InboundConfigType
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link OutboundConfigType}
   *                  is configured and returned for the component.
   *                  If the OutboundConfigType does not exist and creation is 
   *                  not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link OutboundConfigType} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  private OutboundConfigType getOutboundConfig(
   Component component,
   boolean create
  )throws AdapterException
  {
    OutboundConfigType outboundConfig = null;

    _logger.entering(__thisClass__ , "getOutboundConfig");

    try
    {
      if(component.getType() == Port.PORT_COMPONENT_TYPE)
      {
        SecurityPort secPort = getSecurityPort(component, create);
        if(secPort != null)
        {  
          outboundConfig = secPort.getOutbound();
          if(outboundConfig == null && create)
          {
            outboundConfig = new OutboundConfigTypeImpl(mDoc);
            secPort.setOutbound(outboundConfig);
          }
        }
      }
      if(component.getType() == Operation.OPERATION_COMPONENT_TYPE)
      {
        SecurityOperation secOperation = getSecurityOperation(component, create);
        if(secOperation != null)
        {   
          outboundConfig = secOperation.getOutbound();
          if(outboundConfig == null && create)
          {
            outboundConfig = new OutboundConfigTypeImpl(mDoc);
            secOperation.setOutbound(outboundConfig);
          }
        }
      }
      
      _logger.exiting(__thisClass__, "getOutboundConfig", outboundConfig);

      return outboundConfig;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }

  /**
   * Get or Create a {@link SecurityPort} for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the SecurityPort is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the SecurityPort
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link SecurityPort}
   *                  is configured and returned for the component.
   *                  If the SecurityPort does not exist and creation is 
   *                  not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link SecurityPort} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  private SecurityPort getSecurityPort(
   Component component,
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getSecurityPort");

    try
    {
      // check if the port level security for this port component
      // has already been configured and cached. If there is a 
      // cached configuration, return that.
      SecurityPort secPort = (SecurityPort)mConfig.get(component);
      
      if(secPort != null)
       return secPort;
     
      // get the policy for this component. If the port level configuration
      // is not cached, then this is the first reference to the configuration
      // either it exists and need to be derialzied , or a new configuaration
      // mustr be created. 
      WebServicePolicies policy = (WebServicePolicies)component.getExtension(
                                    WebServicePolicies.EXTENSION_TYPE, create);
      if(policy == null)
      {
        _logger.fine("Cannot find Policy for '"+ component.getName() +"'");
        return null;
      }
       
      // Is there a serialzed version of this configuration from which this 
      // port level configuration can be constructed. 
      Element configElem = policy.getPolicy(SECURITY_POLICY);
      if(configElem == null)
      {
        // create if this is first reference to the port level security 
        // configuration. No serialzied information exists, and creation
        // is required.
        if(create)
         secPort = new SecurityPortImpl(mDoc);
        else
         secPort = null;
      }
      else
       // A serialized configuration exists, construct the port level 
       // security configuration by de-serializing the configuration info.
       secPort = (SecurityPort)mPortSerializer.convertDomToObjects(configElem,
                                                                   true);
      // Update the configuration map with the port level security information
      // for this component.
      mConfig.put(component, secPort);

      _logger.exiting(__thisClass__, "getSecurityPort", secPort);
      
      return secPort;
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__thisClass__, "getSecurityPort", ae);
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  }
  
  /**
   * Get or Create a {@link SecurityOperation} for the component. The 
   * {@link oracle.webservices.model.Component} can be only a 
   * {@link oracle.webservices.model.Port} 
   * 
   * @param component The {@link oracle.webservices.model.Component} for which 
   *                  the SecurityPort is to be created or 
   *                  fetched.
   * @param create    <code>true</code> if the SecurityOperation
   *                  is to be created, incase it is not configured for that
   *                  component. <code>false<code> if creation is not required.
   * @return          Based on the value of <code>create</code>. 
   *                  A {@link SecurityOperation}
   *                  is configured and returned for the component.
   *                  If the SecurityOperation does not exist and creation is 
   *                  not needed, a <code>null</code> is returned.
   *           
   * @throws          {@link oracle.adf.model.adapter.AdapterException}
   *                  If the {@link SecurityOperation} could not be 
   *                  configured on the 
   *                  {@link oracle.webservices.model.Component}.
   */    
  private SecurityOperation getSecurityOperation(
   Component component, 
   boolean create
  )throws AdapterException
  {
    _logger.entering(__thisClass__, "getSecurityOperation");

    try
    {
      // check if the operation level security is already configured in the
      // configuration map.
      SecurityOperation secOperation = 
                              (SecurityOperation)mConfig.get(component);

      // return the cached configuration, if there is one. 
      if(secOperation != null)
      {
        _logger.fine("Found security configuration for operation");
        return secOperation;
      }

      // NO cached configuration. Then this may be the first reference to the 
      // operation level security configuration.
      // get the policy associated with the component.
      WebServicePolicies policy = 
                        (WebServicePolicies)component.getExtension(
                                  WebServicePolicies.EXTENSION_TYPE, create);
                                        
      if(policy == null)
      {
       _logger.fine("Found no policy configured on '" +
                                    component.getName() + "'");
        return null;
      }
   
      // Is there a serialzed version of this configuration from which this 
      // operation level configuration can be constructed. 
      Element configElem = policy.getPolicy(SECURITY_POLICY);

      if(configElem == null)
      {
        // create if this is first reference to the operation level security 
        // configuration. No serialized information exists, and creation
        // is required.
        if(create)
         secOperation = new SecurityOperationImpl(mDoc);
        else
         secOperation = null;
      }
      else
      {
        // A serialized configuration exists, construct the operation level 
       // security configuration by de-serializing the configuration info.
        secOperation = 
          (SecurityOperation)mOperationSerializer.convertDomToObjects(
                                                            configElem, true);
      }
      // Update the configuration map with the operation level security 
      // information for this component.
      mConfig.put(component, secOperation);
   
      _logger.exiting(__thisClass__, "getSecurityOperation", secOperation);

      return secOperation;
    }
    catch(AdapterException ae)
    {
      throw ae;
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
  } 
}
