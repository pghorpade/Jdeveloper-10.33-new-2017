/*
 * @(#)WSProvider.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  vpamadi      10/24/05  - XbranchMerge vpamadi_xsl_perf_logging_fixes from 
 *                           main 
 *  vpamadi      01/06/05  - vpamadi_wsdcrt
 *  vpamadi      01/06/05  - creation
 */
package oracle.adfinternal.model.adapter.webservice.provider;

import java.util.Map;

import oracle.adf.model.adapter.AdapterException;

/**
 * Provider interface for the Webservice data control.
 * <p>
 * Specific providers will need to implement this interface to provide
 * the underlying framework for the webservice invocation. 
 * The Data control can invoke a service operation only via the provider
 * interface. This keeps the Adapter framework flexible to use any 
 * underlying provider and not bind the adapter to any specific invocation 
 * protocol. 
 * </p>
 * 
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 */
public interface WSProvider 
{
   /**
    * The Actual physical connection for this provider to invoke the
    * service operations. The connection is responsible for the underlying
    * transport of the serialized request to the endpoint.
    */
   public static final String PROVIDER_CONNECTION = "connection";
   /**
    * The Operations that the provider can invoke on the service endpoint.
    * The Set of operations is determined by the owning data control definition.
    */
   public static final String PROVIDER_OPERATIONS = "operations";
   /**
    * The Service attribute that defines the name of the service this 
    * provider is capable of servicing, i.e the service against which this 
    * provider implementation can invoke operations.
    */
   public static final String PROVIDER_SERVICE    = "service";
 
   /**
     * Initialize the provider with the necessary environment to enable 
     * the provider to execute the service operation. The environment 
     * could be any generic parameters such as a physical connection reference 
     * or a set of supported operations inaccordence with the data control
     * definition.
     * In addition clients of a provider can pass any custom parameters that is 
     * specific to the provider implementation.
     * 
     * @param environment The necessary set of parameters to intialize this 
     *                    provider instance to make a successful service 
     *                    operation invocation.
     */
   public void init(
    Map environment
   );
   
   /**
    * Execute a Webservice operation. Concrete implementors will
    * bind this invocation with the underlying protocol. The 
    * provider will handle the task of converting the high level
    * opertion invocation to structures needed for the underlying
    * invocation protocol.
    * 
    * @param operation  The service  operation to be invoked
    * @param params     Parameters to the service operation.
    * 
    * @throws {@link AdapterException} If the operation invocation 
    *         fails. It is upto the provider to define what would 
    *         translate to an invocation failure.
    */
   public Object execute(
     String operationName, 
     Map    params
   )throws AdapterException;
   
}
