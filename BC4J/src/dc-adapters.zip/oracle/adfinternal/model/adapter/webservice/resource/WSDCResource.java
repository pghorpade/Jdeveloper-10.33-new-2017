/*
 * @(#)WSDCResource.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  vpamadi      09/12/05 - More error messages 
 *  vpamadi      08/26/05 - More Error constants 
 *  vpamadi      08/03/05 - Add constants for Resource Strings 
 *  vpamadi      06/27/05 - Fix up the resource strings for errors defined in 
 *                           the bundle 
 *  vpamadi      01/06/05 - vpamadi_wsdcrt
 *  vpamadi      01/06/05 - creation
 */
package oracle.adfinternal.model.adapter.webservice.resource;

/**
 * Error messages for the WebService Data Control
 * 
 * @author Vinay Pamadi
 */
public final class WSDCResource
{
  // Generic undefined internal error.
  public static final String ERR_INTERNAL_ERR             = "40000";
  // specific runtime errors.
  public static final String ERR_NO_WSDL                  = "40001";
  public static final String ERR_INVALID_WSDL             = "40002";
  public static final String ERR_METADATA_CREATE_FAIL     = "40003";
  public static final String ERR_NO_SOAP_BINDING          = "40004";
  public static final String ERR_NULL_PART_VALUE          = "40005";
  public static final String ERR_NOSUCH_OPERATION         = "40006";
  public static final String ERR_MESG_SEND_FAILED         = "40007";
  public static final String ERR_CREATE_SOAP_REQUEST      = "40008";
  public static final String ERR_PROCESS_SOAP_RESP        = "40009";
  public static final String ERR_SOAP_FAULT               = "40010";
  public static final String ERR_CYCLIC_REFERENCE         = "40011";
  public static final String ERR_CONN_CREATE_FAIL         = "40012";
  public static final String ERR_PORT_UNSUPPORTED         = "40013";
  public static final String ERR_OPERATION_UNSUPPORTED    = "40014";
  public static final String ERR_COMPLEXTYPE_UNSUPPORTED  = "40015";
  
  // Security configuration errors 
  public static final String ERR_SEC_PORT                 = "40016";
  public static final String ERR_SEC_OPERATION            = "40017";
}
