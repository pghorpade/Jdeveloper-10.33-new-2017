/*
 * @(#)MessagePart.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  nishah    03/12/07 - Backport nishah_bug-5688840 from st_jdevadf_10131soa
 *  nishah    02/19/07 - Bug fix for bug5688840
 *  vpamadi   05/22/06 - Backport vpamadi_multiple_return_types_2 from main 
 *  alai      04/24/06 - 
 *  vpamadi   04/12/06 - Fix up ComplexPrototypes that are simple content 
 *  vpamadi   04/12/06 - Fix up ComplexPrototypes that are simple content 
 *  vpamadi   01/23/06 - Check if the qname is available 
 *  vpamadi   09/12/05 - Throw exceptions if <any> strcuture is encountered 
 *  vpamadi   08/03/05 - check for self referential complex types 
 *  vpamadi   07/27/05 - Fix up soap and embedded collections 
 *  alai      07/22/05 - 
 *  vpamadi   07/20/05 - 
 *  vpamadi   07/15/05 - Parameter structure created by transformation URL 
 *                       should be treated as a collection 
 *  vpamadi   07/06/05 - Name the top level strcuture def when transformed 
 *  vpamadi   06/22/05 - Normalize names , to initcap strings that resemble 
 *                       Java keywords 
 *  vpamadi   02/15/05 - Change the Way parameter Definition is created for
 *                       a Messagepart. For Wrapped parts, the part can
 *                       translate into a collection of parameters either
 *                       simple or complex. Modify the creation of
 *                       parameters to return a collection always, which can
 *                       either reprsent a single or a collection of
 *                       parameters
 *
 */
package oracle.adfinternal.model.adapter.webservice;


import java.lang.reflect.Array;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.namespace.QName;

import oracle.binding.meta.VariableDefinition;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.dataformat.FormatHelper;
import oracle.adf.model.adapter.dataformat.AccessorDef;
import oracle.adf.model.adapter.dataformat.AttributeDef;
import oracle.adf.model.adapter.dataformat.ParamDef;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.dataformat.xml.TypeMap;
import oracle.adf.model.adapter.dataformat.XSDHandler;
import oracle.adf.model.adapter.utils.Utility;
import oracle.adf.share.logging.ADFLogger;

import oracle.webservices.mdds.ArrayPrototype;
import oracle.webservices.mdds.AtomicPrototype;
import oracle.webservices.mdds.ComplexPrototype;
import oracle.webservices.mdds.Prototype;

import oracle.adfinternal.model.adapter.webservice.WSDefinition;

import oracle.binding.meta.DefinitionContainer;
import oracle.binding.meta.NamedDefinition;

/**
 * MessagePart represents the structure of the SOAP operation part.
 * Message part could be simple, with simple data types or complex.
 * Complex part have a nested structure of simple parts.
 *
 * <p>Nested Structures are defined by
 * {@link oracle.binding.meta.StrucutureDefinition}
 *
 * @author  Vinay Pamadi
 * @version 1.0
 */
public class MessagePart
{
  // Name of the Part
  private String    mName          = null;
  // name of the parent object that contains this part. It could be a 
  // method definition or , the qualified name of another top level part
  private String    mParentName    = null;
  // The part protottype. This basically holds the type information
  // be it either a simple type or the collection of lower level parts.
  private Prototype mPartPrototype = null;

  //======================================================================
  //  - Logging support 
  //======================================================================
  // constant for this class name
  private final static String __THISCLASS__ = 
                   "oracle.adfinternal.model.adapter.webservice.MessagePart";
  // logger
  private ADFLogger _logger        =
                              ADFLogger.createADFLogger(WSDefinition.LOGGER);

  /**
   * Create a new Message part.
   *
   * @param name Name of the message part
   * @param isSimple Is the message part a simple part of complex part.
   *                 A value of <code>true</code> instantiates a Simple part
   *                 <code>false</code> instantiates a complex part.
   */
  public MessagePart(
   String name
  )
  {
    mName = Utility.normalizeString(name);
  }
  
  /**
   * Create this Messagepart instance. 
   * 
   * @param name       The name of this message part
   * @param parentName The name of the parent container for this part. The
   *                   parent container can be a method or a higher level
   *                   part incase of a complex / collection part.
   * @param partPrototype The prototype of this part. A prototype of the part
   *                      defines the type of the part. The type can be a  
   *                      simple java type or a complex schema construct as 
   *                      defined in the schema.
   */
  public MessagePart(
   String name,
   String parentName,
   Prototype partPrototype
  )
  {
    this(name);
    mParentName = parentName;
    mPartPrototype = partPrototype;    
  }

  /**
   * Get the name of the message part
   *
   * @return The name of the message part
   */
  public String getName()
  {
    return mName;
  }

  /**
   * Create the <code>JSR 227</code> {@link ParameterDefinition} for this 
   * Message part. 
   * 
   * @param result The Parent {@link StructureDefinition} that defines the 
   *               structure of this parameter
   * @param transformURL The transformation URL if this parameter is to 
   *                     be transformed to another structure.
   * 
   * @return {@link ParameterDefinition} for this message part
   * 
   * @throws {@link AdapterException} if the {@link ParameterDefinition} 
   *          cannot be created.
   */
  public ParamDef getParameterDefintion(
    String rootName
  )throws AdapterException
  {
    try
    {
      _logger.finer("Creating JSR227 Parameter definition for : " + mName);

      StructureDef root = new StructureDef(rootName);
      VariableDefinition def = getBaseDefintion(root);
      
      //NISHAH  
      if(def != null)
      {
        switch(def.getDefinitionType())
        {
            case VariableDefinition.TYPE_ATTRIBUTE: 
            {
                return new ParamDef(mName, def.getJavaTypeString(), null, false);
            }
            case VariableDefinition.TYPE_ACCESSOR: 
            {
                root.addAccessor((AccessorDef)def); 
                return new ParamDef(mName, root, null, 
                                    ((AccessorDef)def).isCollection());
            }
        }
      }
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "getParameterDefinition", ae);

      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae = new AdapterException(e);
      _logger.throwing(__THISCLASS__, "getParameterDefinition", ae);
      throw ae;
    }
    
    return null;
  }
  

  /**  
   * Create the Base definition of this part. The base definition of this 
   * part is the JSR 227 type of this Message part. The base definition of 
   * this Message Part could be {@link AttributeDefinition} if this is a 
   * simple part, {@link AccessorDefinition} if this message part is a 
   * complex Strcuture or a collection
   * 
   * @param parentDef The parent StructureDefinition for this base definition.
   * 
   * @return The {@link VariableDefinition} that represents this message
   *         part.
   */
  VariableDefinition getBaseDefintion(
   StructureDef parent
  )throws AdapterException
  {
    VariableDefinition baseDef = null;
    
    if(mPartPrototype instanceof AtomicPrototype)
    {
      baseDef = createAttribute(mName, (AtomicPrototype)mPartPrototype, parent);
    }
    if(mPartPrototype instanceof ComplexPrototype)
    {
      //NISHAH
      if(checkComplexPrototype(mName, (ComplexPrototype)mPartPrototype))
      {
        if(isSimpleContent((ComplexPrototype)mPartPrototype))
        {
            baseDef = createAttribute(mName, 
                     ((ComplexPrototype)mPartPrototype).getContentPrototype(),
                               parent);
        }
        else
        {
            baseDef = createAccessor(mName, (ComplexPrototype)mPartPrototype, 
                                 parent, false);
        }
      }
    }
    else if (mPartPrototype instanceof ArrayPrototype)
    {
      baseDef = createCollection(mName, null, parent,
                                 (ArrayPrototype)mPartPrototype, null);
    }
 
    return baseDef;
  }

  /**
   * Return a Collection of parameters for this message part. 
   * A message part that represents a complex structure or a collection
   * can be represented as a collection of simple types by 
   * flattening out the hierarchy.
   * 
   * @return A {@link Collection} of parameters.
   */
  Collection getParameters() throws AdapterException
  {
    _logger.finer("Creating parameter collection for this message part");

    Collection parameters = null; 

    if(mPartPrototype instanceof AtomicPrototype)
    {
      parameters = new ArrayList();
      AtomicPrototype simplePart = (AtomicPrototype)mPartPrototype;
      String javaType = TypeMap.getJavaType(simplePart.getType());
      parameters.add(new ParamDef(mName, javaType, null, false));

      _logger.finer("part is a simple java type : " + javaType);
    }
    else 
    if(mPartPrototype instanceof ComplexPrototype)
    {
      _logger.finer("part is a complex structure");

      parameters = getParameters(mName, (ComplexPrototype)mPartPrototype);
    }
    else if(mPartPrototype instanceof ArrayPrototype)
    {
      _logger.finer("Part is a collection");

      parameters = getParameters(mName, (ArrayPrototype)mPartPrototype);
    }

    return parameters;
  }

  //===========================================================================
  //  -- Prvate API's to construct the parameter structure
  //===========================================================================

  /**
   * Handle the array prototype. Create a collection accessor if the type of
   * this message part is a collection
   *
   * @param partName The name of the part 
   * @param parentDef The structure definition of the container object.
   * @param arr The Prototype defining the array structure of this part.
   */
  private AccessorDef createCollection(
   String partName,
   QName parentQName,
   StructureDef parentDef, 
   ArrayPrototype arr,
   AccessorDef parentAcc
  )throws AdapterException
  {
    AttributeDef attDef = null;
    Prototype arrPart = arr.getPrototype();
    
    String fullName = new StringBuffer(mParentName).append('.').
                                      append(partName).toString();
    _logger.finer("Creating the array type for :" + fullName);
                                      
    // create the structure def for this array part.
    StructureDef strDef = new StructureDef(fullName);
    // Collection Accessor for this Array.
    AccessorDef accDef = new AccessorDef(partName, parentDef, strDef, true);
    AccessorDef childAccDef = null;
    
    if(arrPart instanceof AtomicPrototype)
    {
      // create a common type of attribute for SOAP / Embedded array.
      // Since SOAP style arrays use "item"element for an array item
      // we will stick with the same convention for embedded style 
      // arrays.
      attDef = createAttribute(XSDHandler.ARRAY_ITEM, 
                               (AtomicPrototype)arrPart, strDef);
      //Multidimensional SOAP arrays are also flattened out under a 
      // single accessor   
      strDef.addAttribute(attDef);
    }
    else if(arrPart instanceof ComplexPrototype)
    {
      if(isSimpleContent((ComplexPrototype)arrPart))
      {
        attDef = createAttribute(XSDHandler.ARRAY_ITEM, 
                             ((ComplexPrototype)arrPart).getContentPrototype(),
                               strDef);
        strDef.addAttribute(attDef);
      }
      else
      {
        QName partQName = ((ComplexPrototype)arrPart).getQName();
        //cyclic reference
        if(partQName != null && parentQName != null &&
           partQName.equals(parentQName))
        {
          accDef.setStructure(parentAcc.getStructure());
        }
        else
        {
          accDef = createAccessor(partName, (ComplexPrototype)arrPart,
                                  parentDef, true);
        }
      }
    }
    // I need to check if this is needed. The type of an array
    // can be simple or complex .. but when will the type of an array 
    // be another array.
    else if(arrPart instanceof ArrayPrototype)
    {
      childAccDef = createCollection(partName, parentQName,
                                     strDef, (ArrayPrototype)arrPart, accDef);
        //NISHAH
        if(childAccDef != null)
            strDef.addAccessor(childAccDef);
    }
    
    //NISHAH
    if(accDef != null)
    {
        // Set the collection structure for Array
        accDef.setCollectionStructure(
            FormatHelper.createStandardCollectionOpStructure(parentDef));
    }
    
    return accDef;
  }
  
  /**     
   * Build the JSR 227 accessor definition for the complex schema construct
   * this part represents.
   * 
   * @param name The name of the complex parameter.
   * @param complexPart The prototype defining the complex schema construct of 
   *                    this part.
   * @param structureDef The JSR 227 structure definition describing this 
   *                     Accessor definition.
   * 
   */
  private AccessorDef createAccessor(
    String name,
    ComplexPrototype complexPart, 
    StructureDef parentStruct,
    boolean collection
  )throws AdapterException
  {
    AccessorDef childAccDef = null;
    AttributeDef attDef     = null;
    AtomicPrototype contentType = null;
    QName parentQName = complexPart.getQName();
    
    //NISHAH
    if(!checkComplexPrototype(name, complexPart))
        return null;
    
    // Handle the attributes
    String fullName = new StringBuffer(mParentName).append('.').
                                     append(name).toString();
    StructureDef partStrDef = new StructureDef(fullName);
    AccessorDef accDef = new AccessorDef(name, parentStruct,
                                         partStrDef, collection);
    partStrDef.setParent(parentStruct);
    
    for(int i = 0; i < complexPart.getNumAtts(); i++)
    {
      String attName = Utility.normalizeString(complexPart.getAttName(i));

      _logger.finer("Adding schema attribute " + attName);

      AtomicPrototype attPrototype = complexPart.getAttPrototype(i);
      attDef = createAttribute(attName, attPrototype, partStrDef);
      partStrDef.addAttribute(attDef);
    }
     // See if the complex type has some derived content 
    if((contentType = complexPart.getContentPrototype()) != null)
    {   
      attDef = createAttribute(XSDHandler.LEAFELEMENT_DATA, contentType,
                                 partStrDef);
      partStrDef.addAttribute(attDef);
    }
   
    for(int i = 0; i < complexPart.getNumParts(); i++)
    {
      Prototype part = complexPart.getPartPrototype(i);
      String partName = Utility.normalizeString(complexPart.getPartName(i));
   
      if(part instanceof AtomicPrototype)
      {
        attDef = createAttribute(partName, (AtomicPrototype)part, partStrDef);
        partStrDef.addAttribute(attDef);
      }
      else if(part instanceof ComplexPrototype)
      {
        if(isSimpleContent((ComplexPrototype)part))
        {
          attDef = createAttribute(partName, 
                               ((ComplexPrototype)part).getContentPrototype(),
                                   partStrDef);
          partStrDef.addAttribute(attDef);
        }
        else
        {
          QName childQName = ((ComplexPrototype)part).getQName();
         
          // If cyclic .. then child contains reference to parent.
          if(childQName != null && parentQName != null && 
             parentQName.equals(childQName))
          {   
            fullName = new StringBuffer(mParentName).append('.').
                                          append(partName).toString();
            StructureDef strDef = new StructureDef(fullName);
            childAccDef = new AccessorDef(partName, partStrDef, strDef, false);
            strDef.addAccessor(accDef);         
          }
          else
          {
            childAccDef = createAccessor(partName, (ComplexPrototype)part,
                                          partStrDef, false);
          }
            // NISHAH
          if(childAccDef != null)
            partStrDef.addAccessor(childAccDef);
        }
      }
      if(part instanceof ArrayPrototype)
      {
        ArrayPrototype arr = (ArrayPrototype)part;
        
        AccessorDef collDef = 
             createCollection(partName, parentQName, partStrDef, arr, accDef);
             
        //NISHAH
        if(collDef != null)
            partStrDef.addAccessor(collDef);
      }
    }
    
    return accDef;
  }
  
  private boolean isSimpleContent(
   ComplexPrototype part
  )
  {
    return (part.hasContent() && part.getNumAtts() == 0 && 
            part.getNumParts() == 0);
  }

  //===========================================================================
  // -- API's to build the Input parameter strcuture 
  //===========================================================================

  /**
   * Creating a collection of parameters that this message part represents. 
   * A collection is created if this is a input message part and is a 
   * collection type .
   * The collection part is split up into a collection of fully qualified
   * ( by '_' ) simple parts. 
   * The simple parts are no more than simple java type representable constructs.
   *
   * @param rootName The rootName to be inserted for the qualified type names
   *                 generated.
   * @param arrPrototype The array type definition for this part.
   */  
  private Collection getParameters(
    String rootName, 
    ArrayPrototype arrPrototype
  )
  {
    Prototype arrPart = arrPrototype.getPrototype();
    ArrayList paramList = new ArrayList();
    
    Object arrayClass = null;
    int dimensions = arrPrototype.getNumDimensions(); 
    String javaType = null;
    
    if(arrPart instanceof AtomicPrototype)
    {
      javaType = TypeMap.getJavaType(((AtomicPrototype)arrPart).getType());
      try
      {
        arrayClass = Array.newInstance(Class.forName(javaType),
                                               new int[dimensions]);
      } 
      catch(Exception e)
      {
        // If class is not found create an array of objects... 
        arrayClass = Array.newInstance(new Object().getClass(), 
                                           new int[dimensions]);
      }
    }
    else
    {
      arrayClass = Array.newInstance(new Object().getClass(), 
                                         new int[dimensions]);
    }
    
    javaType = arrayClass.getClass().getName();
    //javaType = arrayClass.getClass().getCanonicalName();
   
    _logger.finer("Creating collection for type: " + javaType);

    paramList.add(new ParamDef(rootName, javaType, null, true));
    
    return paramList;
  }

  /**
   * Creating a collection of parameters that this message part represents. 
   * A collection is created if this is a input message part and is a 
   * complex schema construct.
   * The complex part is split up into a collection of fully qualified
   * ( by '_' ) simple parts. 
   * The simple parts are no more than simple java type representable constructs.
   *
   * @param rootName The rootName to be inserted for the qualified type names
   *                 generated.
   * @param complexPart The complex schema construct type of this part.
   */    
  private Collection getParameters(
   String rootName,
   ComplexPrototype complexPart
  )throws AdapterException
  {
    ArrayList paramList = new ArrayList();
    addAttributes(paramList, rootName, complexPart);
    AtomicPrototype contentType = null;
    
    // See if the complex type has some derived content 
    if( (contentType = complexPart.getContentPrototype()) != null)
    {
      String javaType = TypeMap.getJavaType(contentType.getType());
      paramList.add(new ParamDef(rootName, javaType, null, false));
    }

    for(int i = 0; i < complexPart.getNumParts(); i++)
    {
      Prototype part = complexPart.getPartPrototype(i);
      String partName = complexPart.getPartName(i);

      partName = new StringBuffer(rootName).append('_').append(
                              Utility.normalizeString(partName)).toString();

      if(part instanceof AtomicPrototype)
      {
        AtomicPrototype simplePart = (AtomicPrototype)part;
        String javaType = TypeMap.getJavaType(simplePart.getType());
        paramList.add(new ParamDef(partName, javaType, null, false));
      }
      else if(part instanceof ComplexPrototype)
      {
        // Cough out an exception if this complex type is a cyclic 
        // reference to self
        QName childQName = ((ComplexPrototype)part).getQName();
        QName parentQName = complexPart.getQName();
 
        // If there is a cyclic reference, we add the parameter
        //type as a java.lang.Object. 
        if(childQName != null && parentQName != null && 
           parentQName.equals(childQName))
        {
          paramList.add(new ParamDef(partName, "java.lang.Object", null, false));
        }
        else
        {
          Collection list = getParameters(partName, (ComplexPrototype)part);
          paramList.addAll(list);
        }
      }
      else if (part instanceof ArrayPrototype)
      {
        paramList.addAll(getParameters(partName, (ArrayPrototype)part));
      }
    }
    return paramList;
  }

  /**
   * Add the attributes for this complex part. The Schema attributes defined for 
   * this complex type need to be fully qualified, as this becomes a complex type
   * 
   * @param params The collection into which these attributes must be added after 
   *               being fully qualified.
   * @param rootName The root name with respect to which the fully qualified name
   *                 should be generated.
   * @param part   The complex part definition that describes the schema 
   *               attributes for this part.
   */ 
  private void addAttributes(
   Collection params,
   String     rootName,
   ComplexPrototype part
  )
  {
    AtomicPrototype att = null;
    String attName = null;
    for(int i = 0; i < part.getNumAtts(); i++)
    {
      att = part.getAttPrototype(i);
      attName = part.getAttName(i);

      attName = new StringBuffer(rootName).append('_').append( 
                                  Utility.normalizeString(attName)).toString();

      params.add(new ParamDef(attName, TypeMap.getJavaType(att.getType()),
                              null, false)); 
    }
  }
  
  /**
   * Create a Simple Attribute with the respective Java type for this part.
   * 
   * @param partName   The name of the attribute.
   * @param simplePart The Prototype describing the java type of this attribute
   * @param parent     The parent structure definition to which this attribute 
   *                   belongs.
   *
   * @return The JSR 227 AttributeDefinition representing this simple type.
   */
  private AttributeDef createAttribute(
    String partName,
    AtomicPrototype simplePart, 
    StructureDef parent
  )
  {
    AttributeDef attribute = new AttributeDef(partName, 
                                              parent,
                                  TypeMap.getJavaType(simplePart.getType()));
    return attribute;
  }
  
  /**
   * Check if this complex type is supported. We will support only those types for
   * which MDDS can find an attribute / child elemenets / content. 
   * If none of these exist then we do not support the complex type. 
   * Examples of unsupported types could be 
   *
   *  <element name="foo"..>
   *   <complexType>
   *     <any/>
   *   </complexType>
   *  </element>
   *
   * @param partName    The name of the schema element / message part
   * @param complexPart The Prototype representing this complex part.
   *
   * @throws <code>AdapterException</code> if the complex schema element 
   *         cannot be supported by underlying MDDS layer.
   */
  private boolean checkComplexPrototype(
    String partName,
    ComplexPrototype complexPart
  )throws AdapterException
  {
    //check if the complex type has atleast an attribute / content part /
    // a child element.
    if(complexPart.getNumAtts() == 0 && 
       complexPart.getNumParts() == 0 &&
       complexPart.getContentPrototype() == null)
    {
        //NISHAH
        _logger.warning("Complex type '" + complexPart.getQName() + "' cannot be supported");
        return false;
    }
        return true;
  } 
  
  //--------- API's to fix up the ancestors for an accessor Def -----
  // NOT USED CURRENTLY
  private void fixUpAncestors(AccessorDef defn)  
  {
    StructureDef partStrDef = (StructureDef)defn.getStructure();
    Iterator iter = partStrDef.getAccessorDefinitions().iterator();
    AccessorDef parent = getDecentAncestor(defn);
    while(iter.hasNext())
    {
      AccessorDef childAccDef = (AccessorDef)iter.next();
      childAccDef.setParentAccessor(parent);
      fixUpAncestors(childAccDef);
    }
  }
  
  private AccessorDef getDecentAncestor(NamedDefinition def)
  {
    // If we are dealing with an Accessor
    while(def != null && 
           def.getDefinitionType() == NamedDefinition.TYPE_ACCESSOR) 
    {
      AccessorDef defn = (AccessorDef)def;
      StructureDef strDef = (StructureDef)defn.getStructure();
      DefinitionContainer container = strDef.getAttributeDefinitions();
     
      if(!container.isEmpty())
         return defn;
         
       def = defn.getParentAccessor();
    }
    return null;
  }
}
