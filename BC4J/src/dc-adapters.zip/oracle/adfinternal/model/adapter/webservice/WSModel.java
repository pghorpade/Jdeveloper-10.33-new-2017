/*
 * @(#)WSModel.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 * 
 * DESCRIPTION
 *    
 * NOTES
 * 
 * MODIFIED    (MM/DD/YY)
 *    shalin    09/27/06 - correct perf logging usage
 *    vpamadi   08/26/05 - Exception handling and Logging 
 *    vpamadi   08/17/05 - Set the MDDS error handler 
 *    armukher  06/09/05 - Catching NPEs, other minor fixes, readability.
 *    vpamadi   06/07/05 - Fetch Service Operations for SOAP port only 
 *    vpamadi   03/09/05 - Propagate changes done in core WS layer to WSDL 
 *                         Parsing. Change the way the schema node is 
 *                         extracted from the types element 
 *    vpamadi   02/25/05 - Return ports only for SOAP bindings 
 *    vpamadi   02/22/05 - Error messages for WSDL Parsing errors 
 */
package oracle.adfinternal.model.adapter.webservice;

import java.net.URL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.io.FileNotFoundException;

import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;

import oracle.webservices.mdds.ComplexPrototype;
import oracle.webservices.mdds.HeaderPrototype;
import oracle.webservices.mdds.MddsModelFactory;
import oracle.webservices.mdds.MessagePrototype;
import oracle.webservices.mdds.Prototype;
import oracle.webservices.model.Model;
import oracle.webservices.model.Operation;
import oracle.webservices.model.Port;
import oracle.webservices.model.Service;
import oracle.webservices.model.soap.SoapPort;
import oracle.webservices.mdds.MddsException;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.model.adapter.utils.DebugLog;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;

import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;


/**
 * WSModel provides the design time model for the webservice data control.
 * <p>
 * The WSModel handles the nuances of parsing a WSDL at design time and 
 * extracting information that is needed by the Data control design time
 * to generate the metadata. 
 * <p>The webservice operations are abstracted as {@link WSOperation}, which 
 * is the design time representation of a webservice operation containing all
 * that information needed for metadata generation. 
 *
 * @author Vinay Pamadi
 * @version 1.0
 * @see oracle.adfdtinternal.adapter.model.webservice.WSOperation
 */
public class WSModel 
{
  // The WSDL url describing the webservice
  private URL     mWSDLURL           = null;
  // The MDDS model 
  private Model   mModel             = null;
  // services described by this model i.e wsdl 
  private HashMap mServices          = null;
  // Fast look up map for Services and the associated ports for each
  // service.
  private HashMap mServicePorts      = null;
  // Fast lookup map for the operations associated with a service. This
  // is a set of all the operations of all the ports belonging to the 
  // service.
  private HashMap mServiceOperations = null;
  
  //===========================================================================
  //  -- Logging support
  //===========================================================================
  private ADFLogger _logger = ADFLogger.createADFLogger(WSDefinition.LOGGER);
  
  private static final String __THISCLASS__ = 
                         "oracle.adfinternal.model.adapter.webservice.WSModel";

  // Finer grain logging employed here. This data is not so critical to be logged. 
  // once the MDDS model is created sucessfully in the constructor, clients can
  // expect this class to function safely. Hence "fine" logging may not be 
  // needed. Turn on the logging to the next finer grain, incase any foul play
  // is suspected in WSModel.

  // performance sensors
  private static Timer sWSModelTimer = Timer.createTimer(Level.FINER,
                   "/oracle/adf/model/adapter/webservice",
                   "WSModel",
                   "Setting up the backend MDDS model for the data control" +
                   "to query for service information.");
  /**
   * Create an instance of the WSDL model from the WSDL URL. Once the model
   * is created the design time can query this instance to fetch the data to
   * generate the design time metadata.
   * 
   * @wsdlURL {@link java.net.URL} that describes the target WebSerivce.
   * @throws  {@link AdapterException} if the initialization of the model
   *          fails.
   */
  public WSModel(
   URL wsdlURL
  )throws AdapterException
  {
    try
    {
      sWSModelTimer.start();

      _logger.entering(__THISCLASS__, "<init>");
      
      MddsModelFactory factory = MddsModelFactory.newInstance();
      
      _logger.finer("Created the MDDS factory to parse the WSDL " 
                       + wsdlURL.toExternalForm());
                       
      factory.setErrorHandler(new DCMddsErrorHandler());
      mModel = factory.createModelFromWSDL(wsdlURL.toExternalForm());
      
      _logger.finer("Created the MDDS model successfully");
                            
      mWSDLURL = wsdlURL;

      sWSModelTimer.stop();
    }
    catch(AdapterException ae)
    {
      _logger.throwing(__THISCLASS__, "<init>", ae);
      throw ae;
    }
    catch(WSDLException we)
    {
      Throwable te = we.getTargetException();
      String faultCode = we.getFaultCode();
      AdapterException ae = null;
      
      if(te instanceof FileNotFoundException || 
        (faultCode.equals(WSDLException.OTHER_ERROR) && te == null))
      {
      	ae  = new AdapterException(WSDCResourceBundle.class,
                                   WSDCResource.ERR_NO_WSDL,
                                   new Object[]{wsdlURL.toExternalForm()});
      }
      else
      {
        ae  = new AdapterException(WSDCResourceBundle.class,
                                   WSDCResource.ERR_INVALID_WSDL,
                                   new Object[]{we.getLocalizedMessage()});
      }
     
      _logger.throwing(__THISCLASS__, "<init>", ae); 
      throw ae;
    }
    catch(Exception e)
    {
      AdapterException ae  = new AdapterException(WSDCResourceBundle.class,
                                           WSDCResource.ERR_INVALID_WSDL,
                                        new Object[]{e.getLocalizedMessage()});
      
                                           
      _logger.throwing(__THISCLASS__, "<init>", ae);
    
      throw ae;
    }
    finally
    {
      sWSModelTimer.cleanup();
    }
  }
  
  /**
   * Instantiate this Data control model with a associated MDDS model
   * @param Model The <code>MDDS</code> model to create the data control.
   */
  public WSModel(
   Model model
  )
  {
    mModel = model;
  }


  /**
   * Gets the services described by this Model.
   * @return {@link Iterator} of services published. 
   */
  public Iterator getServices()
  {
    _logger.entering(__THISCLASS__, "getServices");
    
    if (mServices == null)
    {
      mServices = new HashMap();
      Service[] services = mModel.getServices();
      for(int i = 0; i < services.length; i++)
       mServices.put(services[i].getName(), services[i]);
    }
    
    _logger.exiting(__THISCLASS__, "getServices");

    return mServices.keySet().iterator();
  }

  /**
   * Gets the service from a service name. 
   * @param serviceName anem of the service to get.
   * @return the service object if found, otherwise returns null.
   */
  public Service getService(
   QName serviceName
  )
  {
    if (mServices == null)
    {
      getServices();
    }
 
    return (Service) mServices.get(serviceName);
  }

  /**
   * Gets the ports given a serivce name. A <code>Port</code> is a collection
   * of webservice operations.
   *
   * @param  Service name for which the portlist is desired.
   * @return Set of ports published by this service.
   */
  public List getServicePorts(
   QName serviceName
  )
  {
    _logger.finer("Getting a list of Service ports for: " + serviceName);

    // Lazy loading of all the service ports, set up when the 
    // first query comes in.
    if (mServicePorts == null)
    {
      mServicePorts = new HashMap();
      Iterator iter = getServices();
      while (iter.hasNext())
      {
        QName sName = (QName)iter.next();
        Service service = mModel.getService(sName);
        if (service != null)
        {
          Port[] ports = service.getPorts();
          ArrayList portsList = new ArrayList();
          for (int i = 0; i < ports.length; i++)
          {
           // For now bother about ports with SOAP bindings.
           if (ports[i].getExtension(SoapPort.EXTENSION_TYPE) != null)
            portsList.add(ports[i].getName());
          }

          mServicePorts.put(sName, portsList);
        }      
      }
    }
    
    List listOfPorts = (List)mServicePorts.get(serviceName);
    
    _logger.exiting(__THISCLASS__, "getServicePorts", listOfPorts);

    return listOfPorts;
  }
  
  /**
   * Get a look up table for all the operations for a particular service.
   * The lookup table contains the portname as the key and the list
   * of operations in that port.
   * 
   * @param {@link QName} service name for which the operations are 
   *                      desired.
   * @return look up map with the portname and list of operations 
   *         for that port.
   */
  public Map getServiceOperations(
   QName serviceName
  )
  {
    _logger.finer("Fetching service operations for service: " + serviceName);

    if (mServiceOperations == null)
    {
      mServiceOperations = new HashMap();
      Iterator services = getServices();
      while (services.hasNext())
      {
        QName sName = (QName)services.next();
        Service service = getService(sName);
        if (service != null)
        {
          List portList = getServicePorts(sName);
          if (portList != null)
          {
            Iterator ports = portList.iterator();
            HashMap portOperations = new HashMap();

            while (ports.hasNext())
            {
              QName portQName = (QName)ports.next();
              Port thisPort = service.getPort(portQName.getLocalPart());
              if (thisPort != null)
              {
                HashMap operationMap = new HashMap();
                Operation[] operations = thisPort.getOperations(); 

                for (int j = 0; j < operations.length; j++)
                {
                  operationMap.put(operations[j].getOperationName(), 
                                   operations[j]);
                }

                portOperations.put(portQName.getLocalPart(), operationMap);
              }
            }

            mServiceOperations.put(sName, portOperations);
          }
        }
      }
    }

    Map operMap = (Map)mServiceOperations.get(serviceName);

    _logger.exiting(__THISCLASS__, "getServiceOperations", operMap);

    return operMap;
  }
  
  /**
   * Returns the end point for a given service and a port.
   */
  public String getEndpointURL(
   QName serviceName,
   String portName
  )
  {
    Service service = mModel.getService(serviceName);
    Port[] ports = service.getPorts();
    for (int i = 0; i < ports.length; i++)
    {
      if (ports[i].getName().getLocalPart().equals(portName))
      {
        return ((SoapPort)ports[i].getExtension(SoapPort.EXTENSION_TYPE, true)).
          getAddressUrl();
      }
    }
    
    return null;
  }
  
  /**
   * Get the default service name for this model. 
   * 
   * @return {@link QName} default service name.
   */
  public QName getDefaultServiceName()
  {
    Service service = mModel.getServices()[0];
    return service.getName();
  }
  
  /**
   * Get a list of all the operations that can be invoked for a 
   * particular port. The list contains instances of {@link WSOperation}. 
   * The <code>WSOperation</code> abstracts a webservice operation 
   * encapsulating all the design time information needed for a particular
   * operation.
   * 
   * @param portName name of the port for which the operation list is to be 
   *                 retrieved.
   * @return list of operations defined by the port.
   */
  public Iterator getPortOperations(
   QName serviceName, 
   String portName
  )
  {
    _logger.finer("Fetching operations for port : " + portName +
                                           ", for Service: "+serviceName);

    Map serviceOperations = getServiceOperations(serviceName);
    Map portOperations =  (Map)serviceOperations.get(portName);
    Iterator operations = portOperations.values().iterator();
 
    _logger.exiting(__THISCLASS__, "getPortOperations", operations);

    return operations;
  }

  /**
   * Gets the operation for a given combination of service name, port name and 
   * operation name.
   */
  public Operation getOperation(
   QName serviceName,
   String portName,
   String operationName
  )
  {
    _logger.finer("Looking for operation: " + operationName + 
             ", for port: " + portName + ", under service: " + serviceName);

    Map serviceOperations = getServiceOperations(serviceName);
    Map portOperations = (Map)serviceOperations.get(portName);

    Operation operation = (Operation)portOperations.get(operationName);

    _logger.exiting(__THISCLASS__, "getOperation", operation);
   
    return operation;
  }
  

  ///////////////////////////////// Class Helpers //////////////////////////////

  Model getMddsModel()
  {
    return mModel;
  }
}
