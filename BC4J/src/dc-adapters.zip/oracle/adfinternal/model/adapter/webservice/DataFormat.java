/*
 * @(#)DataFormat.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  shalin       09/27/06  - correct perf logging usage
 *  vpamadi      10/24/05  - XbranchMerge vpamadi_xsl_perf_logging_fixes from 
 *                           main 
 *  vpamadi      08/23/05  - Namespace for metadata 
 *  vpamadi      07/26/05  - Pass the reference node for resolving #href's 
 *  vpamadi      03/31/05  - Changes to FormatDatahandler API,
 *                           In case of a simple java return type
 *                           a return type string is passed to 
 *                           fetch the return type as an instance of 
 *                           that type.
 *  vpamadi      03/17/05  - Process Response Data for the Provider 
 *  vpamadi      01/06/05  - creation
 */
package oracle.adfinternal.model.adapter.webservice;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import oracle.xml.parser.v2.XMLDocument;

import oracle.adf.model.adapter.dataformat.FormatDataHandler;
import oracle.adf.model.adapter.dataformat.XMLHandler;
import oracle.adf.model.adapter.dataformat.CSVHandler;

import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.perf.Timer;


/**
 * DataFormat defines the format of the <code>SOAP</code> response contents.
 * The repsonse envelope though in XML format can actually contain different
 * data in the body. The content of the body could be a CSV stream or 
 * HTML content
 *  
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 */
public class DataFormat
{
  ///////////// Types of DataFormat supported /////////////
  /**
   * XML format 
   */
  public static final String FORMAT_XML         = "xml";
  /**
   * CSV format 
   */
  public static final String FORMAT_CSV         = "csv";

  /////////// Properties for the Data format
  /**
   * Encoding style for CSV format
   */
  public static final String ENC_STYLE          = "Encoding"; //NOTRANS
  /**
   * does the first row of CSV stream denote column names
   */
  public static final String IS_FIRST_ROW_NAMES = "IsFirstRowNames";//NOTRANS
  /**
   * Delimiter character for CSV data
   */
  public static final String DELIMITER          = "Delimiter"; //NOTRANS
  /**
   * Quote character for CSV data
   */ 
  public static final String QUOTE_CHAR         = "QuoteChar"; //NOTRANS
  /**
   * XSL Location for XML format
   */
  public static final String TRANS_LOC          = "TransLoc"; //NOTRANS
  
  public static final String TRANS_RESULT        = "ResultTransform";

  /////// data format members /////////////////
  // The data format 
  private String mFormat     = null;
  // One or more of the above listed properties of the data format.
  private Map    mProperties = null;
  // InputReader to read off the XSL transformation content
  private Reader mXSLReader  = null;

  //=======================================================================
  // Logger support 
  //=======================================================================
  // Logger
  private ADFLogger   _logger = ADFLogger.createADFLogger(WSDefinition.LOGGER);
  // private constant for the class name.
  private static final String  __THISCLASS__ = 
                 "oracle.adfinternal.model.adapter.webservice.DataFormat";
  // performance sensors
  private static Timer sProcessDataTimer = Timer.createTimer(Level.FINE,
                   "/oracle/adf/model/adapter/webservice",
                   "processData",
                   "Format specific processing of the response data");

  /**
   * Instantiate this DataFormat. 
   *
   * @param format The data format value for this DataFormat
   */
  public DataFormat(
   String format
  )
  {
    mFormat = format;
    mProperties = new HashMap();
  }

  /**
   * Instantiate this DataFormat
   * 
   * @param format      The data format value for this DataFormat.
   * @param formatProps The properties for this data format
   */
  public DataFormat(
   String format,
   Map    formatProps
  )
  {
    mFormat = format;
    mProperties = formatProps;
  } 

  /**
   * Add a property to this DataFormat
   * 
   * @param propName The Name of this property
   * @param propVal  The property Value
   */
  public void addProperty(
   String propName,
   String propVal
  )
  {
    mProperties.put(propName, propVal);
  }

  /**
   * Get the format represented by this Data Format
   *
   * @return The format represented by this DataFormat
   */
  public String getFormat()
  {
    return mFormat;
  }

  /**
   * Get the specified property for this DataFormat
   * 
   * @param propName the Property to be queried
   */
  public String getProperty(
   String propName
  )
  { 
    return (String)mProperties.get(propName);
  }

  /**
   * Get all the properties associated with this DataFormat
   *
   * @return {@link Map} of all the properties for this
   *         DataFormat.
   */
  public Map getProperties()
  {
    return mProperties;
  }

  ///////// Package level API's ///////////////////////////
  /**
   * Get the XML representation of this DataFormat. The XML
   * representation is put in the data control metdata 
   * definition.
   */
  Node toXML()
  {
    XMLDocument doc = new XMLDocument();
    Element formatElem = doc.createElementNS(WSDefinition.XMLNS, 
                                             WSDefinition.ELEM_DATAFORMAT);
                                             
    formatElem.setAttribute(WSDefinition.ATTR_FORMAT, mFormat);
   
    if(mProperties != null)
    {
      Iterator propIter = mProperties.keySet().iterator();
      while(propIter.hasNext())
      {
        String propName = (String)propIter.next();
        formatElem.setAttribute(propName, 
                                (String)mProperties.get(propName));
      }
    }
    return formatElem;
  }

  /**
   * Process the data based on the handler properties this 
   * data format encapsulates.
   * 
   * @param source The raw data to be processed. 
   * 
   * @return The processed data representation as is provided by the 
   *         {@link FormatDataHandler}.
   */
  public Object processData(
   Object source, 
   Object referenceRoot,
   String returnType
  )throws Exception
  {
    _logger.entering(__THISCLASS__, "processData");

    Object result = null;

    try
    {
      _logger.fine("Processing data for format: " + mFormat);

      sProcessDataTimer.start();

      FormatDataHandler handler = null;
    
      HashMap params = new HashMap();
      params.putAll(mProperties);
    
      params.put(XMLHandler.REFERENCE_ROOT, referenceRoot);
    
      if(source instanceof Node)
      {
        if(mFormat.equalsIgnoreCase(FORMAT_XML))
        {
          //initialize the handler with transformation data
          handler = new XMLHandler((Node)source, getTransformationData());
        }
      
        else if(mFormat.equalsIgnoreCase(FORMAT_CSV))
        {
          _logger.fine("Format is CSV, Setting up pipe XMLHandler ==> CSVHandler");

          XMLHandler xmlHandler = new XMLHandler((Node)source);
          Object data = xmlHandler.getResult(params, returnType);

          if(data instanceof String)
          {
            ByteArrayInputStream is = new ByteArrayInputStream(
                                                    ((String)data).getBytes());
            String delim = (String)mProperties.get(DELIMITER);
            // Quote char
            String quote = (String)mProperties.get(QUOTE_CHAR);
            if (quote.equalsIgnoreCase("\""))
              quote = "&quot;";
            else if(quote.equalsIgnoreCase("{none}"))
             quote = " ";
           
            _logger.fine("Recieved from XMLHandler " + data);
          
            handler = new CSVHandler(is, true, 
                                    (String)mProperties.get(ENC_STYLE),
                                      delim, quote);
          }
        }
      }

      //// If we need to transform the result, then It cannot be a simple type.
      if(mProperties.get(TRANS_RESULT) != null)
      {
        result = handler.getResult(params, null);
      }
      else
      {
        result =  handler.getResult(params, returnType);
      }

      sProcessDataTimer.stop();

      _logger.exiting(__THISCLASS__, "processData", result);

      return result;
    }
    catch(Exception e)
    {
      _logger.throwing(__THISCLASS__, "processData", e);

      throw e;   
    }
    finally
    {
      sProcessDataTimer.cleanup();

      try
      {
        if(mXSLReader != null)
        {
          _logger.finer("Resetting the XSL Reader");
          mXSLReader.reset();
        }
      }
      catch(Exception e)
      { 
        _logger.finer("Error resetting the XSL Reader: " + e);
        mXSLReader = null;
      } 
    }
  }

  //=========================================================================
  // -- Private API's 
  //=========================================================================

  /**
   * Get the Transformation URL contents and create a reader for it. 
   * This will cache the URL contents once read, to avoid network 
   * latency for successive reads.
   */  
  private Reader getTransformationData() throws Exception
  {
    InputStream is = null;

    try
    {
      if(mXSLReader == null)
      {
        String xslURL = (String)mProperties.get(TRANS_LOC);
        
        if(xslURL != null && xslURL.length() > 0)
        {
          byte data[] = null;
          URL url = new URL(xslURL);
          is = url.openStream();
 
          int avail = is.available();
          if(avail > 0);
          {
            data = new byte[avail];
            is.read(data);
          }
          if(data != null)
          {
            mXSLReader = new StringReader(new String(data));
          } 
        }
      }

      return mXSLReader;
    }
    catch(Exception e)
    {
      _logger.throwing(__THISCLASS__, "getTransformationData", e);
      throw e;
    }
    finally
    {
      try
      {
        if(is != null)
         is.close();
      }
      catch(Exception e)
      {

      }
    }  
  }
}
