/*
 * @(#)DCMddsErrorHandler.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  vpamadi      08/26/05  - Error message 
 *  vpamadi      08/17/05  - vpamadi_ui_fixes
 *  vpamadi      01/06/05  - creation
 */
 
package oracle.adfinternal.model.adapter.webservice;

import oracle.adf.model.adapter.AdapterException;
import oracle.adf.share.logging.ADFLogger;

import oracle.adfinternal.model.adapter.webservice.resource.WSDCResourceBundle;
import oracle.adfinternal.model.adapter.webservice.resource.WSDCResource;

import oracle.webservices.mdds.MddsErrorHandler;
import oracle.webservices.model.Operation;
import oracle.webservices.model.Port;

/**
 * The DCMddsErrorHandler is the data control mdds error handler. 
 * <p>
 * The MDDS users
 * the {@link MddsErrorHandler} interface to inform the clients of any mdds
 * errors that happen when modelling a service from a WSDL. The clients 
 * can then provide appropriate error handling by providing custom 
 * implementations of this interface
 * </p>
 * 
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 */

class DCMddsErrorHandler implements MddsErrorHandler
{
  private ADFLogger _logger = ADFLogger.createADFLogger(WSDefinition.LOGGER);
  /**
   * Initialize this Error handler
   */
  DCMddsErrorHandler()
  {
  }
  
  /**
   * Callback from the MDDS when it fails to model a Webservice port when
   * parsing the wsdl. The Data control's error handler will throw an 
   * {@link AdapterException} with appropriate message when this callback
   * is invoked.
   * 
   * @param thisPort The {@link Port} that could not be modelled. 
   * @param reason   The cause of the failure. 
   * @param detail   The details of the failure.
   */
  public void failedToModelPort(
   Port thisPort,
   String reason,
   String detail
  )
  {
    //throw new AdapterException(WSDCResourceBundle.class,
    //                           WSDCResource.ERR_PORT_UNSUPPORTED,
    //                           new Object[]{thisPort.getName(), 
    //                                        reason});
    // Do not throw an exception, the service can contain multiple
    // ports and one of them could be a soap port. So just log this 
    // message and continue.
    _logger.warning("Port " + thisPort.getName() + 
                 "cannot be supported due to the following reason: " + reason);
  }

  /**
   * Callback from the MDDS when it fails to model a Webservice operation when
   * parsing the wsdl. The Data control's error handler will throw an 
   * {@link AdapterException} with appropriate message when this callback
   * is invoked.
   * 
   * @param operation The {@link operation} that could not be modelled. 
   * @param reason   The cause of the failure. 
   * @param detail   The details of the failure.
   */
  public void failedToModelOperation(
   Operation operation, 
   String reason,
   String detail
  )
  {
    throw new AdapterException(WSDCResourceBundle.class,
                               WSDCResource.ERR_OPERATION_UNSUPPORTED,
                               new Object[]{
                                   operation.getOperationName(),
                                   reason});
  }
}
