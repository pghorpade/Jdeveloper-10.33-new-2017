/*
 * @(#)WSOperation.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  alai         04/19/06 - 
 *  vpamadi      04/24/06 - fix Doc lit headers 
 *  vpamadi      02/03/06 - Root accessor must be collection 
 *  vpamadi      10/24/05 - XbranchMerge vpamadi_xsl_perf_logging_fixes from 
 *                          main 
 *  vpamadi      08/29/05 - Metadata fix. 
 *  vpamadi      08/23/05 - Namespace for metadata 
 *  alai         07/22/05  - 
 *  vpamadi      07/20/05  - Set the collection Strcuture on return type 
 *  vpamadi      07/19/05  - Check for null return parameter in case of void 
 *                           return signatures 
 *  vpamadi      07/15/05  - Add operations for collection return types 
 *  vpamadi      07/06/05  - Normalize structuredef when operation returns CSV 
 *                           format 
 *  vpamadi      03/31/05  - Define the o/p parts for each operation 
 *                           This is needed to treat the simple / 
 *                           complex return types differently.
 *  vpamadi      01/06/05  - creation
 */
package oracle.adfinternal.model.adapter.webservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.Iterator;

import oracle.adf.model.adapter.AdapterException;

import oracle.binding.meta.ArrayListDefinitionContainer;
import oracle.binding.meta.VariableDefinition;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import oracle.xml.parser.v2.XMLDocument;

import oracle.adf.model.adapter.dataformat.AccessorDef;
import oracle.adf.model.adapter.dataformat.AttributeDef;
import oracle.adf.model.adapter.dataformat.MethodDef;
import oracle.adf.model.adapter.dataformat.StructureDef;
import oracle.adf.model.adapter.dataformat.ParamDef;
import oracle.adf.model.adapter.dataformat.FormatHelper;
import oracle.adf.model.adapter.dataformat.XSDHandler;
import oracle.adf.share.logging.ADFLogger;

import oracle.webservices.model.Operation;
import oracle.webservices.mdds.Prototype;
import oracle.webservices.mdds.HeaderPrototype;
import oracle.webservices.mdds.MessagePrototype;
import oracle.webservices.mdds.ComplexPrototype;

import oracle.adfinternal.model.adapter.webservice.WSDefinition;

import oracle.webservices.mdds.AtomicPrototype;

/**
 * WSOperation encapsulates a Webservice operation at ADF design time.
 * <p> The {@link WSModel} creates instances of WSOperation when parsing
 * the WSDL file with information that can be queried by the data control
 * design time classes to generate the metadata.
 * </p>
 *
 * @author  Vinay Pamadi
 * @version 1.0
 * @since   10.1.3
 */
public final class WSOperation
{
  //================================================================
  // static constants for creating the operation strcuture
  //================================================================
  // Root accessor for the result of a DC operation, if the result happens to 
  // have multiple RSI's
  public final static String RESULT  = "Result";

  //name of the operation
  private String mName               = null;
  // The response format of the return type.
  private DataFormat mResponseFormat = null;
  // MDDS webservice operation for this DC operation.
  private Operation mWSOperation     = null;

  //===================================================================
  // Logging support
  //===================================================================
  // The class name
  private final static String __THISCLASS__ = 
                "oracle.adfinternal.model.adapter.webservice.WSOperation";
  private ADFLogger _logger          = 
               ADFLogger.createADFLogger(WSDefinition.LOGGER);



  /**
   * Creates an instance of the WSOperation.
   *
   * @param name The name of the Webservice operation.
   */
  public WSOperation(
   String name
  )
  {
    mName = name;
  }

  /**
   * Create an instance of this WebService operation. 
   * The webservice operation encapsulates all the information 
   * needed to build the DT representation on the DC palette.
   *
   * @param name The name of the operation
   * @param operation The MDDS model {@link Operation} that this 
   *                  DC operation encapsulates.
   */
  public WSOperation(
   String name,
   Operation operation
  )
  {
    mName = name;
    mWSOperation = operation;
  }


  /**
   * Get the Name of this operation.
   *
   * @return the name of this Webservice operation
   */
  public String getName()
  {
    return mName;
  }


  /**
   * Get the reponse format for this operation.
   *
   * @return Reponse format for this operation format.
   * @see #setResponseFormat(DataFormat repsonseFormat)
   */
  public DataFormat getResponseFormat()
  {
    return mResponseFormat;
  }

  /**
   * Set the response format for this operation. The response format is
   * allows the data to be handled by specific data handlers. Although
   * the response to a <i>SOAP</i> service is always <i>XML</i>, the 
   * content of the <i> XML</i> body can be a <i>CSV, HTML</i>content 
   * also. Setting the reponse format for this operation allows the
   * design time to persist this information, so that the appropriate
   * format handlers can be invoked.
   *
   * @param responseFormat Response format for this operation.
   */
  public void setResponseFormat(
    DataFormat responseFormat
  )
  {
    mResponseFormat = responseFormat;
  }

  /**
   * Get the XML representation for this operation. Generate a DOM subtree
   * and return the root {@link Node} of that subtree. This XML representation
   * is a part of the data control metadata. This DOM tree defines the
   * instance construct of the SOAP operation and its parameters at runtime.
   *
   * @return {@link Node} for the XML DOM subtree for this operation
   *                      structure.
   * 
   */
  public Node getOperationNode()
  {
    _logger.finer("Creating the operation metadata node");

    XMLDocument doc = new XMLDocument();
    Element operationElem = doc.createElementNS(WSDefinition.XMLNS, 
                                                WSDefinition.ELEM_OPERATION);
                                                
    operationElem.setAttribute(WSDefinition.ATTR_NAME, mName);
    
    if(mResponseFormat != null)
    {
      operationElem.appendChild(
                       doc.adoptNode(mResponseFormat.toXML()));
    }

    _logger.exiting(__THISCLASS__, "getOperationNode", operationElem);
      
    return operationElem;
  }

  /**
   * Get the WebService {@link Operation} associated with this 
   * Data Control Operation.
   *
   * @return {@link Operation} associated with this Data Control
   *         operation.
   */
  public Operation getOperation()
  {
    return mWSOperation;
  }
  
  /**
   * Create the JSR227 {@link MethodDefinition} for this operation. The 
   * Appropriate JSR227 structures are built for the input parameters and
   * the return types. 
   * 
   * <p>
   * The return type can be a set of multiple RSI's, typically in a case
   * where the <code>SOAP</code> payload  can return complex header 
   * strucutres along with a complex structures in the body. Each of these
   * strcutures are independent RSI's. In such a case a ROOT 
   * {@link AccessorDefinition} is created, whose {@link StructureDefinition}
   * contains these top level accessors. 
   * </p>
   * 
   * <p>
   * The Method parameters can also be complex {@link StructureDefinitions} or
   * collections. In such a case, the Complex Structure is flattened out as 
   * <code>&lt;parent&gt;_&lt;child&gt;</code>. The parameter values passed are
   * then collated to build complex payload.  
   * </p>
   * 
   * @param dcParent The Data control Root Structure which contains
   *                 all the MethodDefinitions.
   * @return The JSR227 {@link MethodDefinition} for this WebService
   *         operation
   */
    // TODO - -Return type must be JSR227 MethodDefinition ... 
  public MethodDef getMethodDefintion(
   StructureDef dcParent
  )
  {
    _logger.entering(__THISCLASS__, "getMethodDefinition");

    _logger.finer("Creating the JSR227 method definition for operation: "
                                               + mName);

    // Create the Method Definition
    MethodDef   methodDef = new MethodDef(mName, dcParent);

    // Fetch the input and output message for the corresponding
    // webservice operation. These are needed to build the 
    // parameters and return type structure.
    MessagePrototype inMessage = 
           (MessagePrototype)mWSOperation.getInputMessage().
                               getExtension(MessagePrototype.EXTENSION_TYPE);
    MessagePrototype outMessage = 
        (MessagePrototype)mWSOperation.getOutputMessage().
                                getExtension(MessagePrototype.EXTENSION_TYPE);
  
    /// Do the input parameters for this method definition 
    setInputParameters(methodDef, inMessage);
 
    // Set the return type on this method Definition
    setReturnType(methodDef, outMessage);

    _logger.exiting(__THISCLASS__, "getMethodDefinition", methodDef);

    return methodDef;
  }

  /////////////////////////////  Private API'S //////////////////////////////
  /**
   * Set the Input parameters on the method definition. This API flattens out 
   * the parameter structure. An operation can also have soap headers associated
   * with the input message. The structures of the SOAP Message is also flattened
   * out as the parameter to this message
   * 
   */ 
  private void setInputParameters(
    MethodDef method,
    MessagePrototype inMessage
  )
  {
    _logger.entering(__THISCLASS__, "setInputParameters");

    Collection  parameters = new ArrayList();
    String      partName   = null;
    MessagePart part       = null;
    Prototype   type     = null;
    
    // Do the headers as input parts for the parameter                                
    for(int i = 0 ; i < inMessage.getNumHeaders(); i++)
    {
      HeaderPrototype headerPrototype = inMessage.getHeaderPrototype(i);
      for(int k = 0; k < headerPrototype.getNumParts(); k++)
      {
        // Flatten each header part into the message
        _logger.finer("Creating parameter for SOAP header part: " + partName);

        partName = headerPrototype.getPartName(k);
        // header name is always the qualified name of the toplevel element
        // since headers do not have parameters, doc style is always assumed
        if(headerPrototype.getQName() != null)
           partName = headerPrototype.getQName().getLocalPart();
           
        type = headerPrototype.getPartPrototype(k);
        part = new MessagePart(partName, null,  type);
        parameters.addAll(part.getParameters());
      }
    }
                                
    // Get the top level part unwrap the parameters in case of 
    // DOC Literal wrapped style of services.
    ComplexPrototype topPart = null;
      
    if(inMessage.isDocLitWrapped())
      topPart = inMessage.getWrappedParams();
    else
      topPart = inMessage;
     
    // Build a collection of parameters for this method.
    for(int j = 0 ; j < topPart.getNumParts(); j++)
    {
      type = topPart.getPartPrototype(j);
      partName = topPart.getPartName(j);

      _logger.finer("Creating method parameter for Body Part: " + partName);

      part = new MessagePart(partName, null, type);
      parameters.addAll(part.getParameters());
    }
  
    /// Update the method with all parameters
    Iterator paramIter = parameters.iterator();
    while(paramIter.hasNext())
    {
      ParamDef param = (ParamDef)paramIter.next();
      param.setParent(method);
      method.addParameter(param);
    }

    _logger.exiting(__THISCLASS__, "setInputParameters");
  }

  /**
   * Set the Return type on this MethodDefinition. The return type can either 
   * be simple return type or a complex Structure definition. The SOAP message
   * can also define header structures for the message. These header structures 
   * must be accomodated under a single root accessor that defines both the 
   * SOAP body structure as well as the headers.
   */
  private void setReturnType(
    MethodDef method, 
    MessagePrototype outMessage
  )
  {
    ComplexPrototype topPart = null;
    ParamDef    parameter  = null;
    MessagePart part     = null;
    Prototype   type     = null;
    String      partName = null;

    _logger.entering(__THISCLASS__, "setReturnType");

    // This is a one Way message 
    if(outMessage == null)
    {
      _logger.finer("Operation is one way (void return type)");
      return;
    }

    String parentName = ((StructureDef)(method.getDefinitionParent())).getFullName();
    String rootAccName = new StringBuffer(parentName).append('.').
                                                 append(mName).toString();
                                                   
    List returnHeaders = new ArrayList();     
    
    for(int j = 0 ; j < outMessage.getNumHeaders(); j++)
    {
      HeaderPrototype headerPrototype = outMessage.getHeaderPrototype(j);
      
      for(int k = 0; k < headerPrototype.getNumParts(); k++)
      {
        partName = headerPrototype.getPartName(k);
        // header name is always the qualified name of the toplevel element
        // since headers do not have parameters, doc style is always assumed
        if(headerPrototype.getQName() != null)
           partName = headerPrototype.getQName().getLocalPart();

        type = headerPrototype.getPartPrototype(k);
        
        part = new MessagePart(partName, rootAccName, type);
        returnHeaders.add(part);
      }
    }
    
    StructureDef resultDef = getTransformedResult(rootAccName);
    boolean collection = false;
    
    // TODO -- Transformed result must also account for headers isnt it ? 
    if(resultDef != null)
    {
      if(mResponseFormat != null && 
         mResponseFormat.getFormat().equalsIgnoreCase(DataFormat.FORMAT_CSV))
      {
        collection = true;
      }
      if(returnHeaders.size() > 0)
      {
        resultDef = getFullReturnDefintion(rootAccName, returnHeaders, 
                                           resultDef);
      }
    }
    else
    {
      if(outMessage.isDocLitWrapped())
       topPart = outMessage.getWrappedParams(); 
      else
       topPart = outMessage;
     
      for(int j = 0 ; j < topPart.getNumParts(); j++)
      {
        type = topPart.getPartPrototype(j);
        partName = topPart.getPartName(j);
        
        // for doc literal style, part name is name of the 
        // toplevel element in the response.
        if(!outMessage.isDocLitWrapped() && 
           outMessage.getStyle() == MessagePrototype.STYLE_DOCUMENT &&
           outMessage.getUse() == MessagePrototype.USE_LITERAL)
         {
           if(outMessage.getQName() != null)
             partName = outMessage.getQName().getLocalPart();
         }
           
        part = new MessagePart(partName, rootAccName, type);
        returnHeaders.add(part);
      }
      
      if(returnHeaders.size() > 1 )
      {
        resultDef = getFullReturnDefintion(rootAccName, returnHeaders, null);
      }  
      else if(returnHeaders.size() == 1)
      {
        part = (MessagePart)returnHeaders.get(0);
    
        parameter = part.getParameterDefintion(rootAccName);
        if(parameter.isStructured() || parameter.isCollection())
        {
          resultDef = (StructureDef)parameter.getStructure();
          if(parameter.isCollection())
            collection = true;
        }
        else
        {
          _logger.finer("Return type is a simple java type : " +
                                                parameter.getJavaTypeString());
          method.setReturnType(parameter.getJavaTypeString());  
        }
      }
    }
    
    if(resultDef != null)
    {
      resultDef.setParent(method);
      method.setReturnType(resultDef, collection);
      if(collection)
      {
        method.setReturnCollectionStructure(
                  FormatHelper.createStandardCollectionOpStructure(resultDef));
      }
                    
      _logger.fine("Return type is a complex structure definition.");
    }
    
    _logger.exiting(__THISCLASS__, "setReturnType");
  }
  
  /**
   * Get the Full return definition associated with this method. A full 
   * return definition involves asscociating all the header strcutures 
   * under the root result structure. 
   */
  private StructureDef getFullReturnDefintion(
   String rootStrName,
   List bodyParts,
   StructureDef resultDef
  )
  {
    _logger.finer("Adding response header parts to the return definition");

    // Create a root accessor name. operationName_result.
    String rootAccName = new StringBuffer(mName).append('_').
                                           append(RESULT).toString();
    // Create the root structure name.                                           
    String accStrName = new StringBuffer(rootStrName).append('_').
                                           append(RESULT).toString();

    _logger.finer("Master root Accessor is: " + rootAccName);

    // Build the root strcuture and the accessors for this method.
    StructureDef rootStructure   = new StructureDef(rootStrName);
    StructureDef rootStrDef = new StructureDef(accStrName);
    
    AccessorDef rootAccDef = null; 
    
    if(mResponseFormat != null && 
       mResponseFormat.getFormat().equalsIgnoreCase(DataFormat.FORMAT_CSV))
    {
      rootAccDef = new AccessorDef(rootAccName, rootStructure,  
                                   rootStrDef, true);
    }
    else
    {
      rootAccDef = new AccessorDef(rootAccName, rootStructure, 
                                   rootStrDef, false);
    }
    
    rootStructure.addAccessor(rootAccDef);

    Iterator iter = bodyParts.iterator();
    while(iter.hasNext())
    {
      MessagePart part = (MessagePart)iter.next();
      VariableDefinition headerPartDef = part.getBaseDefintion(rootStrDef);
      
      if(headerPartDef instanceof AccessorDef)
        rootStrDef.addAccessor((AccessorDef)headerPartDef);

      else if(headerPartDef instanceof AttributeDef)
        rootStrDef.addAttribute((AttributeDef)headerPartDef);
    }

    if(resultDef != null)
    {
      ((ArrayList)(rootStrDef.getAccessorDefinitions())).addAll(
                         (ArrayList)resultDef.getAccessorDefinitions());
      // Add all the attributes of the root Structure Def.  
      ((ArrayList)(rootStrDef.getAttributeDefinitions())).
                  addAll((ArrayList)resultDef.getAttributeDefinitions());
    }
   
    return rootStructure;
  }
  
  
  private StructureDef getTransformedResult(
   String rootName
  ) throws AdapterException
  {
    try
    {
      if(mResponseFormat == null)
       return null;
       
      String transformURL = 
                     mResponseFormat.getProperty(DataFormat.TRANS_RESULT);
      if(transformURL != null)
      {
        XSDHandler handler = new XSDHandler(rootName);
        handler.addSchema(transformURL);
        StructureDef def = (StructureDef)handler.getStructure(rootName, null);
       
        if(mResponseFormat.getFormat().equalsIgnoreCase(DataFormat.FORMAT_CSV)) 
        {
          StructureDef newStrDef = new StructureDef(def.getName());
          newStrDef.setFullName(def.getFullName());
          
          Iterator iter = def.getAccessorDefinitions().iterator();
          while(iter.hasNext())
          {
            AccessorDef accDef = (AccessorDef)iter.next();
            StructureDef accStr = (StructureDef)accDef.getStructure();
            ((ArrayList)(newStrDef.getAttributeDefinitions())).
                         addAll((ArrayList)accStr.getAttributeDefinitions());
          }
          
          def = newStrDef;
        }
        
        return def;
      }
    }
    catch(Exception e)
    {
      throw new AdapterException(e);
    }
    return null;
  }
}
