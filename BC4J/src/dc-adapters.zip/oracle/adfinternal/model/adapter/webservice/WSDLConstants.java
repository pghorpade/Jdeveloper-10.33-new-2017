/*
 * @(#)WSDLConstants.java
 *
 * Copyright 2004 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 *
 * DESCRIPTION
 *
 * NOTES
 *
 * MODIFIED    (MM/DD/YY)
 *  vpamadi      01/06/05  - vpamadi_wsdcrt
 *  vpamadi      01/06/05  - creation
 */

package oracle.adfinternal.model.adapter.webservice;

import javax.xml.namespace.QName;

/**
 * WSDLConstants provides an interface to constants referenced by the 
 * {@link WSModel} when parsing a WSDL URL. <code>SOAP</code> 
 * Namespaces and other WSDL literals are described here for easy
 * access.
 * 
 * @author  Vinay.Pamadi
 * @version 1.0
 * @since   10.1.3
 */
public interface WSDLConstants 
{
  /**
   * SOAP version 1.1 namespace 
   */
  public static final String NS_SOAP = 
                                    "http://schemas.xmlsoap.org/wsdl/soap/";

  /**
   * SOAP version 1.2 namespace 
   */
  public static final String NS_SOAP12 = 
                                    "http://schemas.xmlsoap.org/wsdl/soap12/";
  /**
   * SOAP version 1.1 namespace prefix
   */
  public static final String PREFIX_SOAP   = "soap";

  /**
   * SOAP version 1.2 namespace prefix
   */
  public static final String PREFIX_SOAP12 = "soap12";
 
  /**
   * Qualified names for the accessing the endpoint address
   * in the WSDL for SOAP 1.1 binding. 
   */
  public static final QName QNAME_ADDRESS = 
                             new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                       "address", "soap");
  /**
   * Qualified names for the accessing the endpoint address
   * in the WSDL for SOAP 1.2 binding. 
   */
  public static final QName QNAME_ADDRESS12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/",
                                  "address", "soap12");
  /**
   * Qualified names for accessing the bindings in the WSDL with 
   * SOAP 1.1 binding. 
   */
  public static final QName QNAME_BINDING = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                    "binding", "soap");
  /**
   * Qualified names for accessing the bindings in the WSDL with 
   * SOAP 1.2 binding. 
   */
  public static final QName QNAME_BINDING12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/", 
                                    "binding", "soap12");
  /**
   * Qualified names for accessing the SOAP body element in the WSDL with  
   * SOAP ver 1.1 binding.
   */
  public static final QName QNAME_BODY = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                    "body", "soap");
  /**
   * Qualified names for accessing the SOAP body element in the WSDL with  
   * SOAP ver 1.2 binding.
   */
  public static final QName QNAME_BODY12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/", 
                                    "body", "soap12");
  /**
   * Qualified names for accessing the SOAP fault element in the WSDL with
   * SOAP ver 1.1 binding
   */
  public static final QName QNAME_FAULT = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                   "fault", "soap");
  /**
   * Qualified names for accessing the SOAP fault element in the WSDL with
   * SOAP ver 1.2 binding
   */
  public static final QName QNAME_FAULT12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/", 
                                  "fault", "soap12");

  /**
   * Qualified names for accessing the SOAP header fault element in the WSDL
   * with SOAP ver 1.1 bindings.
   */
  public static final QName QNAME_HEADER_FAULT =
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                    "headerfault", "soap");
  /**
   * Qualified names for accessing the SOAP header fault element in the WSDL
   * with SOAP ver 1.2 bindings.
   */
  public static final QName QNAME_HEADER_FAULT12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/",
                                    "headerfault", "soap12");

  /**
   * Qualified names for accessing the SOAP header element in the WSDL
   * with SOAP ver 1.1 bindings.
   */
   public static final QName QNAME_HEADER = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/",
                                    "header", "soap");

  /**
   * Qualified names for accessing the SOAP header element in the WSDL
   * with SOAP ver 1.2 bindings.
   */
  public static final QName QNAME_HEADER12 =
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/",
                                    "header", "soap12");
  
  /**
   * Qualified names for accessing the SOAP operation element in the WSDL
   * with SOAP ver 1.1 bindings.
   */
  public static final QName QNAME_OPERATION = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap/", 
                                    "operation", "soap");

  /**
   * Qualified names for accessing the SOAP header element in the WSDL
   * with SOAP ver 1.2 bindings.
   */
  public static final QName QNAME_OPERATION12 = 
                          new QName("http://schemas.xmlsoap.org/wsdl/soap12/",
                                     "operation", "soap12");
                      
  /**               
   * Literal encoding for operation parts in the WSDL
   */
  public static final String ENCODING_LITERAL = "literal";
  
  /**
   * Document style invocation
   */
  public static final String STYLE_DOCUMENT   = "document";
  
  /**
   * RPC style invocation
   */
  public static final String STYLE_RPC        = "rpc";

  /**
   * Array Type in a WSDL 
   */
  public static final String ARRAY_TYPE       = "arrayType";
 
  /**
   * Prefix for SOAP encoding namespace 
   */
  public static final String SOAP_ENC         = "SOAP_ENC";
}
