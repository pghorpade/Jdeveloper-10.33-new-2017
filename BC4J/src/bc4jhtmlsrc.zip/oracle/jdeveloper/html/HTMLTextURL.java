/*
 * @(#)HTMLTextURL.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *	Constructs an anchor tag with a prompt.
 *
 * @version PUBLIC
 *
 **/
public class HTMLTextURL extends HTMLElement
{
   protected   String      Text;
   protected   String      URL;
   protected   String      Target = null;
   protected   String      clickHandler = null;

   {
      setCSSClassName("vrTextURL");
   }

   /**
   *	Constructs a new URL object.
   *
   *	@param  Text		Text for anchor tag
   *	@param	URL			URL to be invokied when text is clicked.
   */
   public HTMLTextURL(String Text , String URL)
   {
      this.Text = Text;
      this.URL = URL;
   }

   /**
   *	Sets the target window for the URL.
   *
   *	@param target	the name of the target window.
   */
   public void setTarget(String target)
   {
      Target = target;
   }

   /**
   *	Sets up the JavaScript click handler for the URL. This is added as the value of the ONCLICK attribute.
   */
   public void setClickHandler(String handler)
   {
      clickHandler = handler;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      String sText;

      sText = "<A CLASS=\"" + getCSSClassName() + "\" HREF=\"" + URL + "\"";

      if(Target != null)
         sText = sText + " TARGET=\"" + Target + "\"";

      if(clickHandler != null)
         sText = sText + " ONCLICK=\"" + clickHandler + "\"";
      
      sText = sText + "> " + Text + "</A>";         
      
      out.print(sText);
   }
}