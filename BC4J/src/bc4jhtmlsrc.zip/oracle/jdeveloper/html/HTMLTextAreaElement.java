/*
 * @(#)HTMLTextAreaElement.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.HashMap;
import java.util.Iterator;
import java.io.PrintWriter;

/**
 *
 * Represents a text element. This is an element you can add to a page when no tag is necessary.
 * @version PUBLIC
 *
 **/
public class HTMLTextAreaElement extends HTMLElement
{
   static final String  tagName = "TEXTAREA";
   protected final HashMap htmlAttributes  = new HashMap();
   
   public HTMLTextAreaElement()
   {
   }

   public void setName(String name)
   {
      htmlAttributes.put("NAME", name);
   }
   
   public String getName()
   {
      return (String)htmlAttributes.get("NAME");
   }

   public void setCols(String cols)
   {
      htmlAttributes.put("COLS", cols);
   }
   
   public String getCols()
   {
      return (String)htmlAttributes.get("COLS");
   }

   public void setCols(int cols)
   {
      setCols(Integer.toString(cols));
   }
   
   public void setRows(String rows)
   {
      htmlAttributes.put("ROWS", rows);
   }
   
   public String getRows()
   {
      return (String)htmlAttributes.get("ROWS");
   }

   public void setRows(int rows)
   {
      setRows(Integer.toString(rows));
   }
   
   public void setValue(String value)
   {
      htmlAttributes.put("VALUE", value);
   }
   
   public String getValue()
   {
      return (String)htmlAttributes.get("VALUE");
   }
   
   public void setClassName(String className)
   {
      setCSSClassName(className);
   }
   
   public String getClassName()
   {
      return getCSSClassName();
   }
   
   public void setCSSClassName(String className)
   {
      htmlAttributes.put("CLASS", className);
   }
   
   public String getCSSClassName()
   {
      return (String)htmlAttributes.get("CLASS");
   }

   public void setDisabled(boolean disabled)
   {
      if (disabled)
      {
         htmlAttributes.put("DISABLED", "");
      }
      else
      {
         htmlAttributes.remove("DISABLED");
      }
   }
   
   public boolean getDisabled()
   {
      return (htmlAttributes.get("DISABLED") != null);
   }

   public void setReadOnly(boolean ro)
   {
      if (ro)
      {
         htmlAttributes.put("READONLY", "");
      }
      else
      {
         htmlAttributes.remove("READONLY");
      }
   }
   
   public boolean getReadOnly()
   {
      return (htmlAttributes.get("READONLY") != null);
   }
   
   public void setTabIndex(String sTabIndex)
   {
      htmlAttributes.put("TABINDEX", sTabIndex);
   }
   
   public void setTabIndex(int tabIndex)
   {
      setTabIndex(Integer.toString(tabIndex));
   }
   
   public int getTabIndex()
   {
      try
      {
         return Integer.parseInt((String) htmlAttributes.get("TABINDEX"));
      }
      catch (NumberFormatException ex)
      {
         return -1;
      }
   }

   public void setOnFocus(String onFocus)
   {
      htmlAttributes.put("onfocus", onFocus);
   }
   
   public String getOnFocus()
   {
      return (String) htmlAttributes.get("onfocus");
   }
   
   public void setOnChange(String onChange)
   {
      htmlAttributes.put("onchange", onChange);
   }
   
   public String getOnChange()
   {
      return (String) htmlAttributes.get("onchange");
   }
   
   public void setOnSelect(String onSelect)
   {
      htmlAttributes.put("onselect", onSelect);
   }
   
   public String getOnSelect()
   {
      return (String) htmlAttributes.get("onselect");
   }
   
   public void setOnBlur(String onBlur)
   {
      htmlAttributes.put("onblur", onBlur);
   }
   
   public String getOnBlur()
   {
      return (String) htmlAttributes.get("onblur");
   }

   public final void setHtmlAttributes(HashMap attrs)
   {
      htmlAttributes.putAll(attrs); 
   }
   
   public void render(PrintWriter out) throws Exception
   {
      String value;
      
      out.print("<");
      out.print(tagName);
      
      Iterator iter = htmlAttributes.keySet().iterator();
      while (iter.hasNext())
      {
         String key = (String) iter.next();
         
         // Skip value which is not an attribute but handled in the body of the tag
         if ("VALUE".equals(key))
         {
            continue;
         }

         value = (String) htmlAttributes.get(key);

         out.print(" ");
         out.print(key);
         // Boolean like READONLY do not have any value
         if (value != null && value.length() > 0)
         {
            out.print("=\"");
            out.print(value);
            out.print("\"");
         }
      }
      
      out.print(">");

      value = getValue();
      if (value != null && value.length() > 0)
      {
         out.print(value);
      }

      out.print("</");
      out.print(tagName);
      out.println(">");
   }

}