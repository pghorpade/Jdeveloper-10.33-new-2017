/*
 * @(#)HTMLFieldRenderer.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.HashMap;
import javax.servlet.jsp.PageContext;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.html.DataSource;

/**
 *
 * The <tt>HTMLFieldRenderer</tt> interface defines the set of functions to be implemented by
 * a field renderer. If you are creating a field renderer for use in the
 * <tt>oracle.jbo.html.databeans.EditCurrentRecord</tt> Data Web Bean, you can avoid
 * implementing all of the methods by extending your field renderer class from the
 * <tt>HTMLFieldRendererImpl</tt> class. The only method you need to override
 * is <tt>populateForm()</tt>.
 *
 *
 **/
public interface HTMLFieldRenderer extends HTMLRenderingContext
{
   void setPageContext(PageContext page);

   PageContext getPageContext();
   
   void setDatasource(DataSource dataSource);

   DataSource getDatasource();
   
   void setAttributeDef(AttributeDef attrDef);
   
   AttributeDef getAttributeDef();
   
   /**
   *	Sets this FORM field's name. This will be the name of the input parameter
   *  when the HTML form is submitted.
   * <p>
   * @param sName name of this FORM field.
   */
   void setFieldName(String sName);
   
   /**
   *	Gets this FORM field's name. This will be the name of the input parameter
   *   when the HTML form is submitted.
   * <p>
   * @return this FORM field's name.
   */
   String getFieldName();

   /**
   *	Sets the display width, in characters, of this field.
   * <p>
   * @param nWidth the display width, in characters.
   */
   void setDisplayWidth(int nWidth);
   
   /**
   *	Gets the display width, in characters, of this field.
   * <P>
   * @return the display width, in characters.
   */
   int getDisplayWidth();

   /**
   *	Sets the display height, in characters, of this field.
   * <p>
   * @param nHeight the display height, in characters.
   */
   void setDisplayHeight(int nHeight);

   /**
   *	Gets the display height, in characters, of this field.
   * <p>
   * @return the display height, in characters.
   */
   int getDisplayHeight();

   /**
   *	Sets the maximum input length, in characters, of this field. The user will
   * not be able to enter more than <tt>nLength</tt> characters.
   * <p>
   * @param nLength the maximum input length, in characters.
   */
   void setMaxDataLength(int nLength);

   /**
   * Gets the maximum input length, in characters, of this field. This is the maximum
   * number of characters the user can enter in the field.
   * <p>
   *	@return the maximum input length, in characters.
   */
   int getMaxDataLength();

   /**
   *	Sets the CSS (cascading style sheet) class name to be used by this field. You
   * can the use this class name
   * in your CSS file to change the visual attributes of the field.
   * <p>
   * @param sClass the class name of the CSS.
   */
   void setCSSClassName(String sClass);

   /**
   * Gets the name of the CSS (cascading style sheet) used by this field.
   * <p>
   *	@return the class name of the CSS.
   */
   String getCSSClassName();

   /**
   * Sets this field's current value.
   * <p>
   * @param sValue current value of this field.
   */
   void setValue(String sValue);

   /**
   * Gets this field's current value.
   *	<p>
   * @return this field's current value.
   */
   String getValue();

   /**
   * Sets multiple html field in once
   * Each element of the HashMap contain the name of the attribute as the key and 
   * the value of the html attribute in the value.
   * <p>
   * @param attrs Map of the html attributes
   */
   void setHtmlAttributes(HashMap attrs);
   
   /**
   **  This method is called when the field renderers are being used from the Tag library
   **  and from the DataWebBeans. 
   **/
   String renderToString(Row row);
}
