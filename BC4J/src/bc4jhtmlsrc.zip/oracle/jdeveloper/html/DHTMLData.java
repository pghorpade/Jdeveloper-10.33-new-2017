/*
 * @(#)DHTMLData.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLData extends DHTMLElement
{
   protected String text;
   protected String action;
   protected String image;
   
   public DHTMLData()
   {
   }

   public DHTMLData(String text, String action, String image)
   {
      setText(text);
      setAction(action);
      setImage(image);
   }
   
   public void setText(String text)
   {
      this.text = text;
   }
   
   public String getText()
   {
      return text;
   }

   public void setAction(String action)
   {
      this.action = action;
   }
   
   public String getAction()
   {
      return action;
   }

   public void setImage(String image)
   {
      this.image = image;
   }
   
   public String getImage()
   {
      return image;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      out.print("new dataOnly(\"text:" + ((text == null) ? "" : text));
      if (action != null && action.length() > 0)
      {
         out.print("; action:" + action);
      }
   
      if (image != null && image.length() > 0)
      {
         out.print("; image:" + image);
      }

      out.print("\")");
   }
}

