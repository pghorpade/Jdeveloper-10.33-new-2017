/*
 * @(#)DHTMLTab.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLTab extends DHTMLElement
{
   protected String  name;
   protected String  text;
   protected String  hint;
   protected String  disabledHint;
   protected String  url;
   protected boolean enabled = true;
   protected boolean visible = true;
   protected boolean alwaysActive = false;
   protected String  iconObj;
   
   public DHTMLTab()
   {
   }
   
   public DHTMLTab(String name)
   {
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setText(String text)
   {
      this.text = text;
   }
   
   public String getText()
   {
      return text;
   }

   public void setHint(String hint)
   {
      this.hint = hint;
   }
   
   public String getHint()
   {
      return hint;
   }

   public void setDisabledHint(String disabledHint)
   {
      this.disabledHint = disabledHint;
   }
   
   public String getDisabledHint()
   {
      return disabledHint;
   }
   
   public void setUrl(String url)
   {
      this.url = url;
   }
   
   public String getUrl()
   {
      return url;
   }

   public void setEnabled(boolean enabled)
   {
      this.enabled = enabled;
   }
   
   public boolean getEnabled()
   {
      return enabled;
   }
   
   public void setVisible(boolean visible)
   {
      this.visible = visible;
   }
   
   public boolean getVisible()
   {
      return visible;
   }
   
   public void setAlwaysActive(boolean alwaysActive)
   {
      this.alwaysActive = alwaysActive;
   }
   
   public boolean getAlwaysActive()
   {
      return alwaysActive;
   }
   
   public void setIconObject(String iconObj)
   {
      this.iconObj = iconObj;
   }
   
   public String getIconObject()
   {
      return iconObj;
   }
   
   public void render(PrintWriter out) throws Exception
   {
      StringBuffer buf = new StringBuffer();
      
      buf.append(name);
      buf.append(" = new tab(\"text:");
      buf.append((text == null) ? "" : text);
      
      if (name != null && name.length() > 0)
      {
         buf.append("; name:");
         buf.append(name);
      }
   
      if (hint != null && hint.length() > 0)
      {
         buf.append("; hint:");
         buf.append(hint);
      }

      if (disabledHint != null && disabledHint.length() > 0)
      {
         buf.append("; disabledhint:");
         buf.append(disabledHint);
      }
      
      if (url != null && url.length() > 0)
      {
         buf.append("; url:");
         buf.append(url);
      }

      if (!enabled)
      {
         buf.append("; enabled:false"); // default is true
      }

      if (!visible)
      {
         buf.append("; visible:false"); // default is true
      }

      if (alwaysActive)
      {
         buf.append("; alwaysactive:true"); // default is true
      }
      
      if (iconObj != null && iconObj.length() > 0)
      {
         buf.append("; iconobj:");
         buf.append(iconObj);
      }

      buf.append("\");\n");

      out.print(buf.toString());
   }
}

