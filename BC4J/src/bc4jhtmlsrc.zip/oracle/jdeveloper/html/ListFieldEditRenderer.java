/*
 * @(#)ListFieldEditRenderer.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jdeveloper.html.StaticPickList;
import oracle.jbo.Row;
import oracle.jbo.AttributeDef;
import java.util.StringTokenizer;

/**
**  The ListFieldEditRenderer takes advantage of the BC4J attribute properties in order to render an attribute
**  by mapping it's current value to a set of display values provided
**  via the LF_DISPLAY_LIST property. The control type is provided by
**  the LF_CONTROL_TYPE property which can be COMBOBOX, LISTBOX,
**  RADIOGROUP or CHECKBOXGROUP.
**  The syntax for this proper is <short Value=display value>,<short Value=display value>. If you need to map
**  Y to YES and N to NO, the value of the property would be Y=YES,N=NO. If the renderer doesn't find this property
**  in the attribute, it will default to rendering the raw value.
**/
public class ListFieldEditRenderer extends StaticPickList {
	public ListFieldEditRenderer() {
	}

	public String renderToString(Row row) {
		setValueFromRow(row);

		AttributeDef aDef = getAttributeDef();
		String sAttrValue = getValue();

		String sControlType = (String)aDef.getProperty("LF_CONTROL_TYPE");

		if ( sControlType != null )
			setControlType(sControlType);
		setUseLineBreaks(false);

		String sList = (String)aDef.getProperty("LF_DISPLAY_LIST");
		if (sAttrValue != null && sList != null) {
			StringTokenizer tokens = new StringTokenizer(sList, ",", false);
			int tokenCount = tokens.countTokens();

			String labels[] = new String[tokenCount];
			String values[] = new String[tokenCount];

			int currentToken = 0;
			while (tokens.hasMoreTokens()) {
				String sEntry = tokens.nextToken();
				String sValue = sEntry.substring(sEntry.indexOf('=') + 1); 
				String sKey = sEntry.substring(0, sEntry.indexOf('='));
				labels[currentToken] = sValue;
				values[currentToken] = sKey;
				currentToken++;
			}
			setDataSource(labels, values);
		}

		return getRenderedString();
	}
}
