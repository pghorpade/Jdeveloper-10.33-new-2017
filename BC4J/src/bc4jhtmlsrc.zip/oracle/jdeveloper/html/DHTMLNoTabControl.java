/*
 * @(#)DHTMLNoTabControl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLNoTabControl extends HTMLScript
{
   protected String  name;
   protected String  title;
   protected String  helpText;
   protected boolean longPage = true;

   public DHTMLNoTabControl()
   {
      setVersion("javascript");
   }
   
   public DHTMLNoTabControl(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setTitle(String title)
   {
      this.title = title;
   }
   
   public String getTitle()
   {
      return title;
   }

   public void setHelpText(String helpText)
   {
      this.helpText = helpText;
   }
   
   public String getHelpText()
   {
      return helpText;
   }

/* Not in this release   
   public void setLongPage(boolean longPage)
   {
      this.longPage = longPage;
   }
   
   public boolean getLongPage()
   {
      return longPage;
   }
*/
   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      
      boolean needsc = false;
      StringBuffer buf = new StringBuffer();
      buf.append(name);
      buf.append(" = new notabcontrol(\"");
      
      if (title != null && title.length() > 0)
      {
         buf.append("title:");
         buf.append(title);
         needsc = true;
      }
   
      if (helpText != null && helpText.length() > 0)
      {
         if (needsc)
         {
            buf.append("; ");
         }
         buf.append("helptext:");
         buf.append(helpText);
      }

      buf.append("\");");
      out.println(buf.toString());
   }
}

