/*
 * @(#)HTMLElement.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLEncoder;

/**
 * A class representing the base root class used by all HTML
 * generation classes. Is is never instantiated, it simply
 * provides some common services shared by all derived
 * classes.
 *
 * @version PUBLIC
 *
 */
public abstract class HTMLElement
{
   protected String sClassName;

   abstract public void render(PrintWriter out) throws Exception;

   public HTMLElement()
   {
      sClassName = "clsElement";
   }
   
   public String getAsString()
   {
      String sRet = "error";

      try
      {
         StringWriter sw = new StringWriter();
         PrintWriter pw = new PrintWriter(sw);
         
         render(pw);

         pw.flush();
         sRet = sw.toString();
         pw.close();
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
      }

      return sRet;
   }
   /**
   *	@return the CSS class name for this element
   */
   public String getCSSClassName()
   {
      return sClassName;
   }

   /**
   *	Sets the CSS class name for this element.
   */
   public void setCSSClassName(String sClass)
   {
      sClassName = sClass;
   }
   
   
   /**
    * Fixes a URL value that is to be embedded in an HTML page.
    *
    * URL values need to be fixed up prior to being embedded in an
    * HTML page. This function replaces all 'special' characters so
    * that they don't become altered when they are subsequently passed
    * back to the HTTP server.
    */
   static public String fixFieldValueForHTML(String sValue)
   {
      return URLEncoder.encode(sValue);
   }
   
   /** Quote metacharacters in HTML. */
   public static String quote(String x)
   {
      if (x == null)
      {
         return null;
      }
      else
      {
         // deal with ampersands first so we can ignore the ones we add later
         int c, oldC = -1;
         while ((c = x.substring(oldC + 1).indexOf('&')) != -1)
         {
            c += oldC + 1;          // adjust back to real string start
            x = new String((new StringBuffer(x)).replace(c, c+1, "&amp;"));
            //JDK1.1 version 
            //x = x.substring(0, c) + "&amp;" + x.substring(c + 1);
            oldC = c;
         }
         while ((c = x.indexOf('"')) != -1)
         {
            x = new String((new StringBuffer(x)).replace(c, c+1, "&quot;"));
            //JDK1.1 version 
            //x = x.substring(0, c) + "&quot;" + x.substring(c + 1);
         }
         while ((c = x.indexOf('<')) != -1)
         {
            x = new String((new StringBuffer(x)).replace(c, c+1, "&lt;"));
            //JDK1.1 version 
            //x = x.substring(0, c) + "&lt;" + x.substring(c + 1);
         }
         while ((c = x.indexOf('>')) != -1)
         {
            x = new String((new StringBuffer(x)).replace(c, c+1, "&gt;"));
            //JDK1.1 version 
            //x = x.substring(0, c) + "&gt;" + x.substring(c + 1);
         }
         
         return x;
      }
   }
   
   /**
    *  Renders the object to the HTML output stream.
    *
    *  Render is the key function that needs to be implemented by
    *  all derived classes. It basically renders the HTML representation
    *  of the given HTML object.
    */
   public void render(OutputStream out) throws Exception
   {
      PrintWriter   pw = new PrintWriter(out);
       
      render(pw);
   }

}