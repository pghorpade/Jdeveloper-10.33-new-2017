/*
 * @(#)DateField.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import javax.servlet.http.HttpServletRequest;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.html.HtmlServices;

/**
 *
 *	Represents a date field render.
 *
 * @version PUBLIC
 *
 **/
public class DateField extends TextField implements DateFieldContext
{
   private String sFormat;
   private String sFormatter;
   protected HttpServletRequest request;

   public String createDateField()
   {
      HTMLInputElement input = getHTMLInputElement();
      String imageBase = WebBean.defaultImageBase;
      LocaleContext locale = ds.getLocaleContext();
      StringBuffer sLocale = new StringBuffer();
      sLocale.append(locale.getLocale().getLanguage());
      String sCountry = locale.getLocale().getCountry();
      if (sCountry != null && sCountry.length() > 0)
      {
         sLocale.append('_');
         sLocale.append(sCountry);
      }
      String sVariant = locale.getLocale().getVariant();
      if (sVariant != null && sVariant.length() > 0)
      {
         sLocale.append('_');
         sLocale.append(sVariant);
      }

      DHTMLElementContainer cnt = new DHTMLElementContainer();
      cnt.addElement(input);
      cnt.addElement(new HTMLTextElement("<a onclick=\"launchDatePicker('" + CABO_JSPS + "frameRedirect.jsp?redirect=" + WebBean.defaultJSPBase + "/calendar.jsp&locale=" +
                                         sLocale.toString() +
                                         "&enc="+ HtmlServices.treatInvalidCharacter(getPageContext().getResponse().getCharacterEncoding()) + "', '" +
                                         sFormName + "', '" +
                                         getFieldName() + "', '" +
                                         HtmlServices.treatInvalidCharacter(sFormat) + "', '" +
                                         sFormatter + "'); return false\" href=\"#\"><img src=" + imageBase + "/FNDICLDR.gif align=absmiddle border=0 alt=\"" + Res.getString(Res.CALENDAR_TOOLTIP) + "\"></a>"));
      
      if(!getDatasource().isBindingContainerDataSource())
         cnt.addElement(getHiddenFieldForValue());

      return cnt.getAsString();
   }

   // DataFieldContext implementation
   public void setNLSFormat(String format)
   {
      this.sFormat = format;
   }

   public String getNLSFormat()
   {
      return sFormat;
   }

   public void setHttpServletRequest(HttpServletRequest request)
   {
      this.request = request;
   }

   public String renderToString(Row row)
   {
      StringBuffer sRet = new StringBuffer();
      LocaleContext locale = ds.getLocaleContext();
      
      try
      {
         setValueFromRow(row);

         // If the format has not been explicitely set
         if (sFormat == null)
         {
            // First look at the attribute for a UI hint.
            sFormat = (String) attrDef.getProperty("NLSFormat");
            
            if (sFormat == null)
            {
               AttributeHints hints = attrDef.getUIHelper();
               
               // Then look at the format
               if (hints.hasFormatInformation(locale))
               {
                  sFormat = hints.getFormat(locale);;
                  sFormatter = hints.getFormatterClassName(locale);
               }

            }
            
            // Then the last resort is to get the default value
            if (sFormat == null)
            {
               // Special case java.sql.timestamp
               Class javaType = attrDef.getJavaType();
               if ("java.sql.Timestamp".equals(javaType.getName()))
               {
                  sFormat = "yyyy-MM-dd HH:mm:ss.SSSSSSSSS";
               }
               else
               {
                  sFormat = WebBean.defaultNLSFormat;
               }
            }

            if (sFormatter == null)
            {
               sFormatter = "";
            }
         }
         

         // If not already set (like by example the control hint), use 20
         if (getDisplayWidth() < 0)
         {
            setDisplayWidth(20);
         }
         
         // At least one of page or request need to be valid
         sRet.append(initJS(getPageContext(), request, "/webapp/jsLibs/DateField.js"));
         sRet.append(createDateField());
      }
      catch(Exception ex)
      {
         ex.printStackTrace();
      }

      return sRet.toString();
   }
}

 