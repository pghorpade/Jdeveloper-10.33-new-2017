/*
 * @(#)HTMLInputElement.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.HashMap;
import java.util.Iterator;
import java.io.PrintWriter;

/**
 *
 * Represents a text element. This is an element you can add to a page when no tag is necessary.
 * @version PUBLIC
 *
 **/
public class HTMLInputElement extends HTMLElement
{
   protected HashMap htmlAttributes = new HashMap();
   protected String  label;

   public HTMLInputElement()
   {
   }

   public void setName(String name)
   {
      htmlAttributes.put("NAME", name);
   }
   
   public String getName()
   {
      return (String)htmlAttributes.get("NAME");
   }

   public void setType(String type)
   {
      htmlAttributes.put("TYPE", type);
   }
   
   public String getType()
   {
      return (String)htmlAttributes.get("TYPE");
   }
   
   public void setMaxLength(String smaxLength)
   {
      htmlAttributes.put("MAXLENGTH", smaxLength);
   }
   
   public String getMaxLengthAsString()
   {
      return (String)htmlAttributes.get("MAXLENGTH");
   }
   
   public void setMaxLength(int maxLength)
   {
      setMaxLength(Integer.toString(maxLength));
   }
   
   public int getMaxLength()
   {
      try
      {
         return Integer.parseInt(getMaxLengthAsString());
      }
      catch (NumberFormatException ex)
      {
         return -1;
      }
   }

   public void setSize(String size)
   {
      htmlAttributes.put("SIZE", size);
   }
   
   public String getSize()
   {
      return (String)htmlAttributes.get("SIZE");
   }

   public void setSize(int size)
   {
      setSize(Integer.toString(size));
   }
   
   public void setValue(String value)
   {
      htmlAttributes.put("VALUE", value);
   }
   
   public String getValue()
   {
      return (String)htmlAttributes.get("VALUE");
   }
   
   public void setClassName(String className)
   {
      setCSSClassName(className);
   }
   
   public String getClassName()
   {
      return getCSSClassName();
   }
   
   public void setCSSClassName(String className)
   {
      htmlAttributes.put("CLASS", className);
   }
   
   public String getCSSClassName()
   {
      return (String)htmlAttributes.get("CLASS");
   }

   public void setLabel(String label)
   {
      this.label = label;
   }
   
   public String getLabel()
   {
      return label;
   }

   public void setChecked(boolean checked)
   {
      if (checked)
      {
         htmlAttributes.put("CHECKED", "");
      }
      else
      {
         htmlAttributes.remove("CHECKED");
      }
   }
   
   public boolean getChecked()
   {
      return (htmlAttributes.get("CHECKED") != null);
   }

   public void setReadOnly(boolean ro)
   {
      if (ro)
      {
         htmlAttributes.put("READONLY", "");
      }
      else
      {
         htmlAttributes.remove("READONLY");
      }
   }
   
   public boolean getReadOnly()
   {
      return (htmlAttributes.get("READONLY") != null);
   }
   
   public void setTabIndex(String sTabIndex)
   {
      htmlAttributes.put("TABINDEX", sTabIndex);
   }
   
   public void setTabIndex(int tabIndex)
   {
      setTabIndex(Integer.toString(tabIndex));
   }
   
   public int getTabIndex()
   {
      try
      {
         return Integer.parseInt((String) htmlAttributes.get("TABINDEX"));
      }
      catch (NumberFormatException ex)
      {
         return -1;
      }
   }

   public void setOnFocus(String onFocus)
   {
      htmlAttributes.put("onfocus", onFocus);
   }
   
   public String getOnFocus()
   {
      return (String) htmlAttributes.get("onfocus");
   }
   
   public void setOnChange(String onChange)
   {
      htmlAttributes.put("onchange", onChange);
   }
   
   public String getOnChange()
   {
      return (String) htmlAttributes.get("onchange");
   }
   
   public void setOnSelect(String onSelect)
   {
      htmlAttributes.put("onselect", onSelect);
   }
   
   public String getOnSelect()
   {
      return (String) htmlAttributes.get("onselect");
   }
   
   public void setOnBlur(String onBlur)
   {
      htmlAttributes.put("onblur", onBlur);
   }
   
   public String getOnBlur()
   {
      return (String) htmlAttributes.get("onblur");
   }

   public final void setHtmlAttributes(HashMap attrs)
   {
      htmlAttributes.putAll(attrs); 
   }
   
   public void render(PrintWriter out) throws Exception
   {
      String value;

      out.print("<INPUT");
      
      Iterator iter = htmlAttributes.keySet().iterator();
      while (iter.hasNext())
      {
         String key = (String) iter.next();
         value = (String) htmlAttributes.get(key);

         out.print(" ");
         out.print(key);
         // Boolean like READONLY do not have any value
         if (value != null && value.length() > 0)
         {
            out.print("=\"");
            out.print(value);
            out.print("\"");
         }
      }
      
      out.print(">");
      
      if (label != null && label.length() > 0)
      {
         out.println(label);
      }
      else
      {
         out.println("");
      }
   }

   static public HTMLInputElement getHidden(String sName, String sValue)
   {
      HTMLInputElement input = new HTMLInputElement();
     
      input.setType("HIDDEN");
      input.setName(sName);
      input.setValue(sValue);

      return input;
   }

}