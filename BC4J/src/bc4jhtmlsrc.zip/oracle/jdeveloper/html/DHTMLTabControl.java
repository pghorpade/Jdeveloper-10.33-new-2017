/*
 * @(#)DHTMLTabControl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import java.util.Vector;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLTabControl extends HTMLScript
{
   protected String  name;
   protected String  title;
   protected String  helpText;
   protected int     initialTab;
   protected Vector  tabs = new Vector();

   public DHTMLTabControl()
   {
      setVersion("javascript");
   }
   
   public DHTMLTabControl(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setTitle(String title)
   {
      this.title = title;
   }
   
   public String getTitle()
   {
      return title;
   }

   public void setHelpText(String helpText)
   {
      this.helpText = helpText;
   }
   
   public String getHelpText()
   {
      return helpText;
   }

   public void setInitialTab(int initialTab)
   {
      this.initialTab = initialTab;
   }
   
   public int getInitialTab()
   {
      return initialTab;
   }

   public void addTab(DHTMLTab tab)
   {
      StringBuffer output = new StringBuffer();
      
      output.append(name);
      output.append(".addtab(");
      output.append(tab.getName());
      output.append(");\n");

      addElement(new HTMLTextElement(output.toString()));
      tabs.addElement(tab);
   }

   public void addTab(String name, String text, String hint, String disabledHint, String url, boolean enabled, boolean visible, boolean alwaysActive, String iconObj)
   {
      DHTMLTab tab = new DHTMLTab(name);
      tab.setText(text);
      tab.setHint(hint);
      tab.setDisabledHint(disabledHint);
      tab.setUrl(url);
      tab.setEnabled(enabled);
      tab.setVisible(visible);
      tab.setAlwaysActive(alwaysActive);
      tab.setIconObject(iconObj);
      addTab(tab);
   }

   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      
      // Generate the tabs creation
      try
      {
         for (int i = 0 ; i < tabs.size(); i++)
         {
            ((DHTMLTab) tabs.elementAt(i)).render(out);
         }
      }
      catch (Exception ex)
      {
      }
      
      StringBuffer buf = new StringBuffer();
      buf.append(name);
      buf.append(" = new tabcontrol(\"objectref:");
      buf.append(name);
      buf.append("; targetframe:");
      buf.append(WebBean.contentFrameName);
      
      if (title != null && title.length() > 0)
      {
         buf.append("; title:");
         buf.append(title);
      }
   
      if (helpText != null && helpText.length() > 0)
      {
         buf.append("; helptext:");
         buf.append(helpText);
      }

      if (initialTab <= 0)
      {
         initialTab = 1;
      }
      else if (initialTab > tabs.size())
      {
         initialTab = tabs.size();
      }
      
      buf.append("; initialtab:");
      buf.append(Integer.toString(initialTab));

      buf.append("\");\n");

      // Override the switchtab method
/*      
      buf.append(name);
      buf.append(".base_switchtab = ");
      buf.append(name);
      buf.append(".switchtab;\n");

      buf.append("function myswitchtab(currtab, window_Ref, frame_ref, newurl )\n");
      buf.append("{\n ");
      buf.append(name);
      buf.append(".base_switchtab(currtab, window_Ref, frame_ref, newurl +\"?a=\" + Math.random())\n");
      buf.append("}\n");
      
      buf.append(name);
      buf.append(".switchtab = myswitchtab\n");
*/      
      buf.append("var baseHref = document.location;\n");

      out.println(buf.toString());
   }
}

