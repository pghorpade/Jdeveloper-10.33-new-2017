/*
 * @(#)DHTMLTree.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 *
 * @version PUBLIC
 */
public class DHTMLTree extends HTMLScript
{
   protected String name;
   protected String refName;
   protected String targetFrame;
   protected String dataSource;
   protected String folderOpenImage;
   protected String folderClosedImage;
   
   public DHTMLTree()
   {
      setVersion("javascript");
   }
   
   public DHTMLTree(String name)
   {
      this();
      setName(name);
   }
   
   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }
   
   public void setRefName(String refName)
   {
      DHTMLElement.CheckValidName(refName);
      this.refName = refName;
   }
   
   public String getRefName()
   {
      return refName;
   }

   public void setTargetFrame(String targetFrame)
   {
      this.targetFrame = targetFrame;
   }
   
   public String getTargetFrame()
   {
      return targetFrame;
   }

   public void setDataSource(String dataSource)
   {
      this.dataSource = dataSource;
   }
   
   public String getDataSource()
   {
      return dataSource;
   }
   
   public void setFolderOpenImage(String image)
   {
      this.folderOpenImage = image;
   }
   
   public String getFolderOpenImage()
   {
      return folderOpenImage;
   }

   public void setFolderClosedImage(String image)
   {
      this.folderClosedImage = image;
   }
   
   public String getFolderClosedImage()
   {
      return folderClosedImage;
   }
   
   protected void renderContainerHeader(PrintWriter out)
   {
      super.renderContainerHeader(out);
      
      out.println("function myCallPage(line, window_obj)");
      out.println("{");
      out.println("doUrl = this.data[line].url;");
      if (targetFrame != null && targetFrame.length() > 0)
      {
         out.print("if (doUrl) parent." + targetFrame);
      }
      else
      {
         out.print("if (doUrl) document");
      }
      out.println(".location.href=doUrl+\"?line=\"+line+\"&text=\"+this.data[line].text+\"&child=\"+this.data[line].childcount+\"&state=\"+this.data[line].state;");
      out.println("}");

      out.println("function myToggle(line, window_obj)");
      out.println("{");
      out.println("doUrl = this.data[line].url;");
      out.println("if (doUrl) document.location.href=doUrl+\"?line=\"+line+\"&toggle=\"+this.data[line].state;");
      out.println("}");

      if (folderOpenImage != null && folderOpenImage.length() > 0)
      {
         out.print("folder_open=\"");
         out.print(folderOpenImage);
         out.println("\";");
      }
      
      if (folderClosedImage != null && folderClosedImage.length() > 0)
      {
         out.print("folder_closed=\"");
         out.print(folderClosedImage);
         out.println("\";");
      }
      
      out.print(name);
      out.print("=new tree(\"");
      
      String tmpName;
      if (refName != null && refName.length() > 0)
      {
         tmpName = refName;
      }
      else
      {
         tmpName = name;
      }
         
      out.print("name:");
      out.print(tmpName);
      
/*      if (targetFrame != null && targetFrame.length() > 0)
      {
         out.print("; targetframe:");
         out.print(targetFrame);
      }
*/
      out.println("\");");

      out.print(name);
      out.println(".loadPage=myCallPage;");
      out.print(name);
      out.println(".toggle=myToggle;");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      if (dataSource != null && dataSource.length() > 0)
      {
         out.println(name + ".setDataSource(" + dataSource + ");");
      }

      out.println(name + ".render(window);");
      super.renderContainerFooter(out);
   }

}

