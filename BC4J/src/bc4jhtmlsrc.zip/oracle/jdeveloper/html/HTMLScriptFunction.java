/*
 * @(#)HTMLScriptFunction.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 * Represents a JavaScript function that is to be added to a script. 
 *
 * @version PUBLIC
 *
 **/
public class HTMLScriptFunction extends HTMLElementContainer
{

   protected   String Description;
   protected   String Source;
   
   /**
   *	@param Description	A comment tobe added in front of the function
   *	@param Source		The function's source code.
   */
   public HTMLScriptFunction(String Description, String Source)
   {
      this.Description = Description;
      this.Source = Source;
   }

   /**
   *	@param sDescription	A comment tobe added in front of the function
   */   
   public void setDescription(String sDescription)
   {
	   this.Description = sDescription;
   }

   /*
	*	@param Source		The function's source code.
   */
   public void setSource(String source)
   {
      Source = source;
   }
   
   public void render(PrintWriter out)
   {
      out.println("//" + Description);
      if(Source != null)
         out.print(Source);
      out.println("//--------------------------------------");
   }
}