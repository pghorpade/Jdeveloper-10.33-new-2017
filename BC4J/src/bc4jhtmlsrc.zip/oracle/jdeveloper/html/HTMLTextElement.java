/*
 * @(#)HTMLTextElement.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 * Represents a text element. This is an element you can add to a page when no tag is necessary.
 * @version PUBLIC
 *
 **/
public class HTMLTextElement extends HTMLElement
{
   protected   String   theText = null;

   /**
   *	Constructs element providing it's text.
   *
   *	@param sText	text for new element.
   */
   public HTMLTextElement(String sText)
   {
      theText = sText;
   }

   public void render(PrintWriter out) throws Exception
   {
      out.print(theText);
   }

}