/*
 * @(#)DisplayArrayField.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jbo.Row;

/**
 *
 *	Represents a read-only field generator.
 *
 * @version PUBLIC
 *
 **/
public class DisplayArrayField extends ReadOnlyField
{
   protected String getHTMLValue(Row row)
   {
      if (row == null)
      {
         return "&nbsp;";
      }
         
      oracle.jbo.domain.Array array = (oracle.jbo.domain.Array) row.getAttribute(getAttributeDef().getIndex());
   
      if (array == null)
      {
         return "&nbsp;";
      }

      Object[] objArray = null;
      
      int size = 0;
      if (array != null)
      {
         objArray = array.getArray();
      }
      if (objArray != null)
      {
         size = objArray.length;
      }
      
      StringBuffer buf = new StringBuffer();
      buf.append('[');
      for (int i = 0; i < size; i++)
      {
         buf.append(objArray[i]);
         buf.append(',');
      }
      // Remove last comma
      if (size > 0)
      {
         // buf.deleteCharAt(buf.length()-1);
         buf.setLength(buf.length() - 1);
      }
      buf.append(']');

      return HTMLElement.quote(buf.toString());
   }
}
