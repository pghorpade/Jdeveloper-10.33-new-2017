/*
 * @(#)TextField.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;
import oracle.jbo.Row;

/**
 *
 *	Represents a text field render.
 *
 * @version PUBLIC
 *
 **/
public class TextField extends HTMLFieldRendererImpl
{
   static final String jsInfoParam = "JBO_JS_INFO";
   static final String CABO_CONTEXT = "/webapp/cabo";
   static final String CABO_JSPS = CABO_CONTEXT + "/jsps/";
   static final String CABO_SCRIPTS = CABO_CONTEXT + "/jsLibs/";
   static final String CABO_MARLINCORE = CABO_SCRIPTS + "MarlinCore.js";
   
   public void setReadOnly(boolean ro)
   {
      if (ro)
      {
         htmlAttributes.put("READONLY", "");
      }
      else
      {
         htmlAttributes.remove("READONLY");
      }
   }

   /**
   */
   public boolean getReadOnly()
   {
      return (htmlAttributes.get("READONLY") != null);
   }

   protected HTMLInputElement getHTMLInputElement()
   {
      HTMLInputElement input = new HTMLInputElement();
      
      input.setType("TEXT");
      input.setHtmlAttributes(htmlAttributes);

      return input;
   }

   // Used by DateField and LOVField to add the js file if necessary
   protected String initJS(PageContext pageCtx, HttpServletRequest req, String jsFile)
   {
      ArrayList jsInfo;

      jsInfo = (ArrayList) WebBeanImpl.getRequestVariable(pageCtx, req, jsInfoParam);

      if (jsInfo == null)
      {
         jsInfo = new ArrayList(3);
         jsInfo.add(CABO_MARLINCORE);
         jsInfo.add(jsFile);
         
         WebBeanImpl.setRequestVariable(pageCtx, req, jsInfoParam, jsInfo);

         return "<script src=\"" + CABO_MARLINCORE + "\" language=\"javascript\"></script>\n<script src=\"" + jsFile + "\" language=\"javascript\"></script>";
      }
      else if (!jsInfo.contains(jsFile))
      {
         jsInfo.add(jsFile);
      
         return "<script src=\"" + jsFile + "\" language=\"javascript\"></script>";
      }
      else
      {
         return "";
      }
   }

   public String renderToString(Row row)
   {
      // use the field width only if it has not been overriden
      if (getValue() == null && getDisplayWidth() <= 0)
      {
         setDisplayWidth(attrDef.getPrecision());
      }

      if (row != null && !getReadOnly())
      {
         setReadOnly(!row.isAttributeUpdateable(attrDef.getIndex()));
      }

      setValueFromRow(row);
      
      HTMLElementContainer htmlContainer = new HTMLElementContainer();
      
      int nHeight = getDisplayHeight();
      if (nHeight > 1)
      {
         HTMLTextAreaElement input = new HTMLTextAreaElement();
         
         // TEXTAREA use COLS instead of size
         input.setCols((String)htmlAttributes.remove("SIZE"));
         // Still give precedence to user setting
         input.setHtmlAttributes(htmlAttributes);
         
         htmlContainer.addElement(input);
      }
      else
      {
         htmlContainer.addElement(getHTMLInputElement());
      }
      
      // also add the hidden field for use in comparisons
      if(!getDatasource().isBindingContainerDataSource())
         htmlContainer.addElement(getHiddenFieldForValue());

      return htmlContainer.getAsString();
   }
}

 