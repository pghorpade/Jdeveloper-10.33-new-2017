/*
 * @(#)HTMLTable.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import java.util.Vector;

/**
 *
 * Represents an HTML TABLE. You populate the table by adding rows to it. A row may be any HTMLElement.
 *
 * @version PUBLIC
 *
 **/
public class HTMLTable extends HTMLElement 
{
   protected   Vector   Headers = new Vector();
   protected   Vector   Rows    = new Vector();
   protected   String   Title = null;
   protected   boolean  useBorder = true;
   protected   String   sWidth = "100%";
   
   {
      setCSSClassName("vrTable");
   }
   
   /**
   *	Sets whether the table will use borders or not.
   */
   public void setUseBorder(boolean useBorder)
   {
      this.useBorder = useBorder;
   }

   /**
   *	Sets the table's width. e.g. "100%" or "90%"
   */
   public void setWidth(String sWidth)
   {
      this.sWidth = sWidth;
   }   

   public String getWidth()
   {
      return sWidth;
   }

   /**
   *	Adds a header to the table.
   *
   * @param sText header title
   */
   public void addHeader(String sText)
   {
      String HeaderText;

      HeaderText = "<TH CLASS=\"vrTableHeader\">" + sText + "</TH>";
      Headers.addElement(new HTMLTextElement(HeaderText));
   }

   /**
   *	Adds a header row to the table. A header row is a header that spans more than one column. This
   *    header actually adds a new row to the table.
   *
   *	@param sText		header title
   *	@param sColSpan		the colspan of the new header
   */   
   public void addHeaderRow(String sText , String sColSpan)
   {
      String HeaderText;

      HeaderText = "<TR><TH CLASS=\"vrTableHeader\" colspan=\"" + sColSpan + "\" >" + sText + "</TH></TR>";
      Headers.addElement(new HTMLTextElement(HeaderText));
   }

   /**
   *	Adds a fixed header row to the table. 
   *
   *	@param sText		header title
   *	@param sWidth		the width of the new header
   */      
   public void addFixedHeader(String sText, String sWidth)
   {
      String HeaderText;

      HeaderText = "<TH CLASS=\"vrTableHeader\" WIDTH=\""+ sWidth + "\">" + sText + "</TH>";
      Headers.addElement(new HTMLTextElement(HeaderText));
   }   

   /**
   *	Adds a column spanning header to the table. This header will not cause a new row to be added.
   *
   *
   *	@param sText		new header's title
   *	@param sColSpan		number of columns for the header to span
   */
   public void addHeader(String sText , String sColSpan)
   {
      String HeaderText;

      HeaderText = "<TH CLASS=\"vrTableHeader\" colspan=\"" + sColSpan + "\">" + sText + "</TH>";
      Headers.addElement(new HTMLTextElement(HeaderText));
   }
   
   /**
   *	Adds a column spanning header to the table. This header will not cause a new row to be added.
   *	You can also specify a width for this new header.
   *
   *	@param sText		new header's title
   *	@param sColSpan		number of columns for the header to span
   *	@param sWidth		the width of the new header   
   */
   public void addHeader(String sText , String sColSpan, String sWidth)
   {
      String HeaderText;

      HeaderText = "<TH CLASS=\"vrTableHeader\" WIDTH=\""+ sWidth + "\" colspan=\"" + sColSpan + "\">" + sText + "</TH>";
      Headers.addElement(new HTMLTextElement(HeaderText));
   }
   
   /**
   *	Sets the HTML TABLE'S title
   */
   public void setTitle(String Title)
   {
      this.Title = Title;
   }

   /**
   *	Adds a new row to the HTML TABLE.
   *
   *	@param row	HTMLElement that is repsonsible for rendering the contents of the new row.
   */
   public void addRow(HTMLElement row)
   {
      Rows.addElement(row);
   }

   /**
   *	Inserts a new row to the beginning of the HTML TABLE.
   *
   *	@param row	HTMLElement that is repsonsible for rendering the contents of the new row.
   */   
   public void insertRow(HTMLElement row)
   {
      Rows.insertElementAt(row, 0);
   }

   public void render(PrintWriter out) throws Exception
   {
      HTMLElement elem;
      String      TblHdr;

      if(useBorder)
         TblHdr = "<TABLE WIDTH=\"" + sWidth + "\" BORDER=\"1\" CLASS=\"" + getCSSClassName() + "\" >";
      else
         TblHdr = "<TABLE WIDTH=\"" + sWidth + "\" CLASS=\"" + getCSSClassName() + "\" >";
      
      out.println(TblHdr);
      
      if(Title != null)
      {
         out.println("<CAPTION>" + Title + "</CAPTION>");         
      }
      
      // this will render the headers
      int nSize = Headers.size();

	  if(nSize > 0)
	  {
		  out.println("<TR CLASS=\"clsTableHeaderRow\" >");
		  for(int i = 0 ; i < nSize ; i++)
		  {
			  elem = (HTMLElement)Headers.elementAt(i);
			  elem.render(out);
		  }
		  out.println("</TR>");
	  }
	  
      // render the rows
      nSize = Rows.size();

      for(int i = 0 ; i < nSize ; i++)
      {
         elem = (HTMLElement)Rows.elementAt(i);
         elem.render(out);
      }

      out.println("</TABLE>");      

   }   
}