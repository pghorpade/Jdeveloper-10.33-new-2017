/*
 * @(#)DHTMLArray.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;

/**
 *
 **/
public class DHTMLArray extends DHTMLElementContainer
{
   protected   String name;

   public DHTMLArray()
   {
   }

   public DHTMLArray(String name)
   {
      setName(name);
   }

   public void setName(String name)
   {
      DHTMLElement.CheckValidName(name);
      this.name = name;
   }
   
   public String getName()
   {
      return name;
   }

   protected void renderContainerHeader(PrintWriter out)
   {
      if (name != null && name.length() > 0)
      {
         out.print(name + "=");
      }
      out.print("new Array(");
   }
   
   protected void renderContainerFooter(PrintWriter out)
   {
      out.print(")");
      if (name != null && name.length() > 0)
      {
         out.println(";");
      }
   }

   protected void renderElementFooter(PrintWriter out) throws Exception
   {
      out.println(",");      
   }
}