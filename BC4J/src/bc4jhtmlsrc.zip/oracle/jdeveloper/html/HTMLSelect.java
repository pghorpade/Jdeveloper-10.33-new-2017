/*
 * @(#)HTMLSelect.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.util.HashMap;
import java.util.Iterator;
import java.io.PrintWriter;
import java.util.Vector;

/**
 *
 * Represents an HTML SELECT field. The SELECT FIELD is used to present a selection list to the user. If the SELECT
 * field allows selection of multiple values, a comman delimited list is sent to the HTML FORM processor.
 *
 * @version PUBLIC
 *
 **/
public class HTMLSelect extends HTMLElement
{
   static final String  tagName = "SELECT";
   static final String  className = "vrSelectField"; 
   protected    HashMap htmlAttributes = new HashMap();
   protected    Vector  Elements = new Vector();
   
   /**
   *	contructs the SELECT object providing the field's name.
   */
   public HTMLSelect()
   {
      this(null, false, className);
   }
   
   /**
   *	contructs the SELECT object providing the field's name.
   */
   public HTMLSelect(String sName)
   {
      this(sName, false, className);
   }

   /**
   *	contructs the SELECT object providing the field's name and a boolean for enabling/disabling
   * multiple selection.
   */
   public HTMLSelect(String sName, boolean bMultiple)
   {
      this(sName, bMultiple, className);
   }

   /**
   *	contructs the SELECT object providing the field's name and the CSS class name.
   */
   public HTMLSelect(String sName, String sClass)
   {
      this(sName, false, sClass);
   }   

   protected HTMLSelect(String sName, boolean bMultiple, String sClass)
   {
      if (sName != null)
      {
         setName(sName);
      }
      if (bMultiple)
      {
         setMultiple();
      }
      setCSSClassName(sClass);      
   }   
   
   public void setName(String name)
   {
      htmlAttributes.put("NAME", name);
   }
   
   public String getName()
   {
      return (String)htmlAttributes.get("NAME");
   }

   /*
   *	Enables multiple selection.
   */
   public void setMultiple()
   {
      htmlAttributes.put("MULTIPLE", "");
   }

   /**
   *	Disables multiple selection.
   */
   public void clearMultiple()
   {
      htmlAttributes.remove("MULTIPLE");
   }
   
   /**
   *	Sets the field width
   */
   public void setWidth(String sWidth)
   {
      htmlAttributes.put("WIDTH", sWidth);
   }

   public String getWidth()
   {
      return (String)htmlAttributes.get("WIDTH");
   }

   /**
   *	Sets the field height
   */
   
   public void setHeight(String sHeight)
   {
      htmlAttributes.put("HEIGHT", sHeight);
   }

   public String getHeight()
   {
      return (String)htmlAttributes.get("HEIGHT");
   }
   
   public final void setHtmlAttributes(HashMap attrs)
   {
      htmlAttributes.putAll(attrs); 
   }
   
   /**
   *	Adds an option to the list.
   *
   *	@param sOption	string value of the new option
   */
   public void addOption(String sOption)
   {
      Elements.addElement("<OPTION VALUE=\"" + sOption + "\">" + sOption);
   }

   /**
   *	Adds a selected option to the list.
   *
   *	@param sOption	string value of the new option
   */   
   public void addSelectedOption(String sOption)
   {
      Elements.addElement("<OPTION SELECTED VALUE=\"" + sOption + "\" >" + sOption);
   }

   /**
   *	Adds an option to the list.
   *
   *	@param sOption	string value of the new option
   *	@param sValue	the value for the new option.
   */   
   public void addOption(String sOption, String sValue)
   {
     Elements.addElement("<OPTION VALUE=\"" + sValue + "\">" + sOption); 
   }

   /**
   *	Adds a selected option to the list.
   *
   *	@param sOption	string value of the new option
   *	@param sValue	the value for the new option.
   */      
   public void addSelectedOption(String sOption, String sValue)
   {
     Elements.addElement("<OPTION SELECTED VALUE=\"" + sValue + "\">" + sOption); 
   }

   public void render(PrintWriter out)
   {
      String value;
      
      out.print("<");
      out.print(tagName);
      
      Iterator iter = htmlAttributes.keySet().iterator();
      while (iter.hasNext())
      {
         String key = (String) iter.next();
         
         value = (String) htmlAttributes.get(key);

         out.print(" ");
         out.print(key);
         // Boolean like READONLY do not have any value
         if (value != null && value.length() > 0)
         {
            out.print("=\"");
            out.print(value);
            out.print("\"");
         }
      }
      
      out.println(">");
      
      int nSize = Elements.size();
      for(int i = 0 ; i < nSize ; i++)
      {
         out.println(Elements.elementAt(i));
      }

      out.print("</");
      out.print(tagName);
      out.println(">");
   }


}