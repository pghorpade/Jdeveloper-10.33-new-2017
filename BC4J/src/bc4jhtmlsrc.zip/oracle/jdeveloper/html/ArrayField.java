/*
 * @(#)ArrayField.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.domain.LobInterface;
import oracle.jbo.html.HtmlServices;

public class ArrayField extends HTMLFieldRendererImpl 
{
   public String renderToString(Row row)
   {
      HTMLElementContainer htmlContainer = new HTMLElementContainer();

      try
      {
         oracle.jbo.domain.Array array = (oracle.jbo.domain.Array) row.getAttribute(getAttributeDef().getIndex());

         Object[] objArray = null;
         
         if (array == null)
         {
            objArray = new Object[0];
         }
         else
         {
            objArray = array.getArray();
         }

         int size = objArray.length;
            
         // If the element is a struct or an array, can't edit it.
         if (LobInterface.class.isAssignableFrom(getAttributeDef().getElemType()))
         {
            return Res.getString(Res.ARRAY_FIELD_NOT_EDITABLE);
         }
                  
         HTMLFieldRenderer fldRnd = new TextField();

         fldRnd.setDatasource(ds);
         fldRnd.setAttributeDef(attrDef);
         fldRnd.setDisplayWidth(30);
         fldRnd.setMaxDataLength(-1); // Remove maxlength since we don't know how long it is.
         
         for (int i = 0; i <= size; i++)
         {
            String sName = HtmlServices.getArrayAttributeName(getAttributeDef(), i);

            fldRnd.setFieldName(sName);
            
            Object value;
            String strValue;
            if (i < size)
            {
               htmlContainer.addElement(new HTMLTextElement("[" + i + "] "));
               value = objArray[i];
            }
            else
            {
               htmlContainer.addElement(new HTMLTextElement(Res.getString(Res.ARRAY_FIELD_ADD)));
               value = null;
            }

            if (value == null)
            {
               strValue = "";
            }
            else
            {
               strValue = HTMLElement.quote(value.toString());
            }

            fldRnd.setValue(strValue);

            htmlContainer.addElement(new HTMLTextElement(fldRnd.renderToString(row)));
            htmlContainer.skipLine(1);
         }
      }
      catch (Exception e)
      {
         throw new JboException(e.getMessage());
      }

      return htmlContainer.getAsString();
   }
  
}