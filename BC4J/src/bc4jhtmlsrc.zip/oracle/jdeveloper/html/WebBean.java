/*
 * @(#)WebBean.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

/**
 * Implements basic rendering and initialization functionality for
 * Web Beans.
 */
public interface WebBean
{
   public static final int JSUtilitiesLib              = 1;
   public static final int JSTableConstructLib         = 2;
   public static final int JSDataConstructLib          = 4;
   public static final int JSTreeConstructLib          = 8;
   public static final int JSToolbarConstructorLib     = 16;
   public static final int JSCalendarConstructorLib    = 32;
   public static final int JSModalPageConstructorLib   = 64;
   public static final int JSButtonConstructorLib      = 128;
   public static final int JSContainerConstructorLib   = 256;

   public static final String JS_LIBRARIES = "JS_LIBRARIES";
   public static final String JS_NAMEID = "JS_NAMEID";
   public static final String contentFrameName = "_cnt";
   public static final String defaultImageBase = "/webapp/images";
   public static final String defaultCaboImageBase = "/webapp/jsimages";
   public static final String defaultJSPBase = "/webapp/jsp";
   public static final String defaultCaboBase = "/webapp/cabo";
   // Default format use by the date picker
   public static final String defaultNLSFormat = "yyyy-MM-dd";

   /**
   * Initializes this Web Bean object to
   * access the important objects of the JSP: application, session,
   * request, response, and out.
   * <p>
   * @param appContext     the JSP page's ServletContext.
   * @param session        the JSP page's HttpSession.
   * @param request        the JSP page's HttpServletRequest.
   * @param response       the JSP page's HttpServletResponse.
   * @param out            the PrintWriter to render to.
   */	
	public void        initialize(ServletContext appContext, HttpSession session , HttpServletRequest request, HttpServletResponse response, PrintWriter out)  throws Exception;

   /**
   * Initializes this Web Bean object to
   * access the important objects of the JSP: application, session,
   * request, response, and out.
   *
   * @param page           the JSP page's ServletContext.
   */	
	public void        initialize(PageContext page)  throws Exception;
   
   /**
	*	Internal initialize.
   * This method should be overriden by any WebBean needing to initialize some internal data
   * after all the base class member have been initialize properly.
	*/
   public void        internalInitialize()  throws Exception; 
   
   /**
	*	Renders the Web Bean's contents to the output stream.
	*/
	public void        render()  throws Exception;

	/**
	*	Renders the Web Bean's contents to the specified PrintWriter.
	* <p>
	*	@param out	the PrintWriter to render to.
	*/
	public void        render(PrintWriter out) throws Exception;

}