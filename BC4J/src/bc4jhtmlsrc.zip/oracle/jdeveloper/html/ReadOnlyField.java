/*
 * @(#)ReadOnlyField.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

import oracle.jbo.Row;

/**
 *
 *	Represents a read-only field generator.
 *
 * @version PUBLIC
 *
 **/
public class ReadOnlyField extends HTMLFieldRendererImpl
{
   public String renderToString(Row row)
   {
      setValueFromRow(row);
      
      String retValue = getValue();

      if (retValue == null || retValue.length() == 0)
      {
         retValue = "&nbsp;";
      }

      return retValue;
   }
}
