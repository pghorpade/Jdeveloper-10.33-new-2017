/*
 * @(#)HTMLRenderingContext.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jdeveloper.html;

public interface HTMLRenderingContext
{
   void setFormName(String sFormName);

   String getFormName();

   /**
   *	Sets the prompt to be displayed next to this input field.
   * <p>
   * @param sPrompt the prompt for this input field.
   */
   void setPromptText(String sPrompt);
   
   /**
   *	Gets the prompt to be displayed next to this input field.
   * <p>
   * @return the prompt displayed next to this input field.
   */
   String getPromptText();

}
