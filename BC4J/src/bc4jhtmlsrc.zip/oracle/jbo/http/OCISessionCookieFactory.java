package oracle.jbo.http;

import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieFactory;
import oracle.jbo.common.ampool.EnvInfoProvider;
import oracle.jbo.common.ampool.OCIEnvInfoProvider;

import oracle.jbo.client.Configuration;

import java.util.Properties;
import java.util.Hashtable;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import oracle.adf.share.ADFContext;

/**
 * An OCISessionCookieFactory.  This SessionCookieFactory will
 * instantiate a {@link oracle.jbo.common.ampool.OCIEnvInfoProvider}
 * instance and associate that EnvInfoProvider with each <tt>SessionCookie</tt>
 * which is created.
 * <p>
 * In order to use the <tt>OCISessionCookieFactory</tt> please set the 
 * framework property, jbo.ampool.sessioncookiefactoryclass.  For example,
 * <p><pre>
 * -Djbo.ampool.sessioncookiefactoryclass=oracle.jbo.http.OCISessionCookieFactory
 * </pre>
 * <p>
 * This class assumes that the application has stored the OCI proxy username
 * and possibly the proxy password in the HttpSession context.  It looks
 * for these values in the session context with the <tt>oracle.jbo.client.Configuration.DB_USERNAME_PROPERTY</tt>
 * and <tt>oracle.jbo.client.Configuration.DB_PASSWORD_PROPERTY</tt>
 * respectively.
 */
public class OCISessionCookieFactory implements SessionCookieFactory 
{
   private HttpSessionCookieFactory mFactory = new HttpSessionCookieFactory();

   public SessionCookie createSessionCookie(
      String name, String value, ApplicationPool pool, Properties properties)
   {
      SessionCookie cookie = mFactory.createSessionCookie(
         name, value, pool, properties);

      if (properties != null) 
      { 
         HttpServletRequest request = (HttpServletRequest)properties.get(
            HttpSessionCookieFactory.PROP_HTTP_REQUEST);

         if (request != null) 
         { 
            // Get the database username and password from the pool
            // configuration
            Hashtable env = pool.getEnvironment(); 
            String ociUserName = (String)env.get(
               Configuration.DB_USERNAME_PROPERTY);

            String ociPassword = (String)env.get(
               Configuration.DB_PASSWORD_PROPERTY);

            // The proxy username and password were set by the client in the
            // http session
            Map sessionScope = ADFContext.getCurrent().getSessionScope();
            String proxyUserName = (String)sessionScope.get(
               Configuration.DB_USERNAME_PROPERTY);

            String proxyPassword = (String)sessionScope.get(
               Configuration.DB_PASSWORD_PROPERTY);

            EnvInfoProvider provider = new OCIEnvInfoProvider(
               ociUserName, ociPassword, proxyUserName, proxyPassword);

            cookie.setEnvInfoProvider(provider);
         } 
      } 

      return cookie; 
   }
}
