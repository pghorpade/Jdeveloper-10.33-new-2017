/*
 * @(#)HttpSessionCookieFactory.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Factory for HttpRemoteSessionCookieImpl instances.
 */
public class HttpRemoteSessionCookieFactory extends HttpSessionCookieFactory
{
   public Class getSessionCookieClass()
   {
      return HttpRemoteSessionCookieImpl.class;
   }
}
