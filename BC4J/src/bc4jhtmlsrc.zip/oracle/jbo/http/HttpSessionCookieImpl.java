/*
 * @(#)HttpSessionCookieImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.Map;

import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.SessionCookieImpl;
import oracle.jbo.common.TransactionControl;
//import oracle.jbo.common.ContextUtil;

import oracle.jbo.JboContext;
import oracle.jbo.ApplicationModule;
import java.security.Principal;

import oracle.adf.share.ADFContext;

/**
 * Default HttpSessionCookie implementation.
 * <p>
 * The implementation uses a pluggable helper interface, {@link oracle.jbo.http.HttpSessionCookieHelper},
 * to generate unique session identifiers for browser sessions, to read browser
 * cookie values, and to write browser cookie values.
 * <p>
 * Implements the {@link oracle.jbo.http.BindingListener} interface.  When
 * a session {@link oracle.jbo.http.HttpContainer} instance is unbound from
 * an HttpSession context the BindingListeners will be notified that a timeout
 * event occured.  The timeout implementation releases the application module
 * resource to the application pool.  The release is unmanaged since the
 * request is assumed to have already ended.
 * <p>
 * The HttpSessionCookieImpl also implements additional support for
 * BC4J based authentication.  If a single sign on module like mod_osso is not
 * being used then an application developer can set a security principal and
 * security credential in the HttpSession context for later authentication
 * by the BC4J security login module.  In order to enable this mode the
 * application developer must have configured the <tt>jbo.security.enforce</tt>
 * property.  The principal and credentials should be cached in the session as
 * follows:
 * <p>
 * <tt>
 *    session.setAttribute(
 *        JboContext.SECURITY_PRINCIPAL, (String)<principal name>); 
 *    session.setAttribute(
 *        JboContext.SECURITY_CREDENTIALS, (String)<credential>);
 * </tt>
 * <p>
 * Finally, the HttpSessionCookie implementation uses composition to implement
 * the SessionCookie interface.  All SessionCookie methods are delegated to
 * an instance of the default SessionCookie implementation.  Please see
 * {@link oracle.jbo.common.ampool.SessionCookieImpl} for more infomartion
 * regarding the default session cookie implementation.
 */
public class HttpSessionCookieImpl
   extends SessionCookieImpl
   implements HttpSessionCookie, BindingListener, Serializable
{
   static final long serialVersionUID = -5336195329607336406L;
   private boolean mInSuspend = false;
   
   /**
    * This constructor may be used if the sessionId is already known.
    */
   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool)
   {
      this(
         applicationId
         , sessionId
         , pool
         , null // userPrincipal
         , (HttpSession)null); // request
   }

   /**
    * @deprecated since 10.1.3.  Application should use the ADFContxt
    * to acquire the request context.
    */
   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal
      , HttpServletRequest request)
   {
      this(
         applicationId
         , sessionId
         , pool
         , userPrincipal
         , (HttpSession)null);

   }

   /**
    * @deprecated since 10.1.3.  Application should use the ADFContxt
    * to acquire the session context.
    */
   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal
      , HttpSession session)
   {
      this(applicationId, sessionId, pool, userPrincipal);
   }

   public HttpSessionCookieImpl(
      String applicationId
      , String sessionId
      , ApplicationPool pool
      , Principal userPrincipal)
  {
      super(applicationId, sessionId, pool, userPrincipal);

      setSingleThreaded(false);

      ADFContext adfContext = ADFContext.getCurrent();
      String value = readValue(
         adfContext.hasEnvironment()
            ? adfContext.getEnvironment().getRequest() : null);

      if (value != null && value.length() > 0)
      {
         setPassivationId((new Integer(value)).intValue());
      }
  }

   public void valueBound(BindingEvent ev)
   {
      // Do nothing.
   }

   public void valueUnbound(BindingEvent ev)
   {
      timeout();
   }

   public void timeout(BindingEvent ev)
   {
      timeout();
   }

   public void writeValue(Object sink)
   {
      writeValue(sink, getValue());
   }

   public void writeValue(Object sink, String value)
   {
      if ((sink instanceof HttpServletResponse) && isWriteCookieValue())
      {
         HttpServletResponse response = (HttpServletResponse)sink;

         HttpSessionCookieHelper helper = 
            HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
         helper.writeCookieValue(response
            , HttpContainer.APPLICATION_COOKIE_PREFIX + getApplicationId()
            , (String)getValue());
      }
   }

   public String readValue(Object source)
   {
      String value = null;
      if ((source != null) && (source instanceof HttpServletRequest))
      {
         synchronized(source)
         {
            HttpServletRequest request = (HttpServletRequest)source;
            HttpSessionCookieHelper helper = HttpSessionCookieHelperManager.getHttpSessionCookieHelper();
            value = helper.readCookieValue(request
               , HttpContainer.APPLICATION_COOKIE_PREFIX + getApplicationId());
         }
      }

      return value;
   }

   public boolean isFailoverEnabled()
   {
      return getProperty(
         PropertyMetadata.ENV_DO_FAILOVER.pName
         , mEnvironment
         , Boolean.valueOf(PropertyMetadata.ENV_DO_FAILOVER.pDefault)
            .booleanValue());
   }

   protected void beforeApplicationModuleRelease(ApplicationModule am)
   {
      // invoked immediately before the ApplicationModule will physically
      // be released to the pool.  Care should be taken here to not mutate
      // the state of the releasing cookie.  The use call here
      mInSuspend = true;
      if(am instanceof oracle.jbo.common.TransactionControl)
      {
         ((TransactionControl)am).suspend();
      }
   }

   protected void afterApplicationModuleRelease()
   {
      mInSuspend = false;  
      //ContextUtil.getInstance().resetCurrentContext();
   }

   public ApplicationModule useApplicationModule(boolean lock, long waitTimeout)
   {
      synchronized(getSyncLock())
      {
         //ContextUtil.getInstance().setCurrentContext(
         //   Thread.currentThread().getContextClassLoader());

         ApplicationModule am = super.useApplicationModule(lock, waitTimeout);
         if(!mInSuspend && (am instanceof oracle.jbo.common.TransactionControl))
         {
            ((TransactionControl)am).resume();
         }
         return am;
      }
   }

}
