package oracle.jbo.http;

import oracle.adf.share.http.ServletADFContext;
import oracle.jbo.pool.ResourcePoolMonitor;
import oracle.jbo.pool.ResourcePoolManager;

import oracle.adf.share.Environment;
import oracle.adf.share.ADFContext;

import java.lang.ref.WeakReference;

import javax.servlet.ServletContext;

import java.util.Stack;

/* $Header: HttpResourcePoolMonitor.java 17-oct-2005.14:25:08 jsmiljan Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    10/17/05 - Creation
 */

/**
 *  @version $Header: HttpResourcePoolMonitor.java 17-oct-2005.14:25:08 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpResourcePoolMonitor extends ResourcePoolMonitor
{
   private WeakReference mServletContextRef = null;

   public HttpResourcePoolMonitor(ResourcePoolManager manager
      , ClassLoader loader
      , long interval)
   {
      super(manager, loader, interval);

      Environment env = ADFContext.getCurrent().getEnvironment();
      Object servletContext = env.getContext();
      if (servletContext instanceof ServletContext)
      {
         mServletContextRef = new WeakReference(servletContext);
      }
   }

   protected void initializeThreadContext(Stack holder)
   {
      super.initializeThreadContext(holder);

      if (mServletContextRef != null)
      {
         ServletADFContext.initThreadContext(
            (ServletContext)mServletContextRef.get(), null, null);

         holder.push(Boolean.TRUE); 
      }
      else
      {
         holder.push(Boolean.FALSE);
      }
   }

   protected void resetThreadContext(Stack holder)
   {
      if (((Boolean)holder.pop()).booleanValue())
      {
         ServletADFContext.resetThreadContext();
      }

      super.resetThreadContext(holder);
   }
}
