/*
 * @(#)HttpContainer.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Iterator;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Properties;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletContext;

import oracle.jbo.JboContext;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.JBOClass;
import oracle.jbo.common.ampool.AMPoolMessageBundle;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.ApplicationPoolException;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.SessionCookieFactory;
import oracle.jbo.common.ampool.SessionCookieListener;

import oracle.jbo.common.Diagnostic;

import oracle.adf.share.http.ServletADFContext;

/**
 * A container for BC4J HTTP context resources.  This class is intended for
 * use by BC4J classes that must cache application resources in one of the
 * servlet/jsp contexts.  This may include the HttpSession, the
 * HttpServletRequest, the HttpServletResponse, and the PageContext.
 * <p>
 * The container provides a listener interface to notify cached BC4J resources
 * when they are bound and unbound from the context container.
 * </p>
 */
public class HttpContainer extends Object
   implements HttpSessionBindingListener, SessionCookieListener, Serializable
{
   static final long serialVersionUID = -4535142613500954819L;
   
   // External container property names
   public static final String PAGE_CONTEXT_CONTAINER_NAME         = "jbo.PageContext";
   public static final String SESSION_CONTEXT_CONTAINER_NAME      = "jbo.SessionContext";
   public static final String APPLICATION_COOKIE_PREFIX           = "jbo.ApplicationCookie.";

   // Internal container property names
   public static final String APPLICATION_BINDING_LISTENER_PREFIX = "ApplicationBindingListener_";
   public static final String APPLICATION_PREFIX                  = "Application_";

   // Store the session cookies in a different collection than the other
   // container resources.  This is necessary because the session cookies
   // are serializable.
   private HashMap               mCookies                         = new HashMap(1);

   private transient HashMap     mResources                       = null;
   private transient boolean     mRefreshingSession               = false;
   private transient HttpSession mSession                         = null;
   private transient Object      mLock                            = null;

   // Retain a backwards pointer to the containing context
   // JRS This is a bad idea.  The container may be load balanced between
   // clustered nodes.  In this scenario the contextRef instance may change.
   // Retain for 5.0 backwards compability.  Beware that using this may result
   // in bugs in a load balanced deployment configuration.
   private transient Object  mContextRef                          = null;

   private static HashMap mSessionLockMap                     = new HashMap();

   /**
    * Constructor
    *
    * @deprecated  This class should not be instantiated directly.  Use
    * {@link #getInstanceFromSession(HttpSession)} instead.
    */
   public HttpContainer(Object contextRef)
   {
      super();
      mContextRef = contextRef;
      initialize();
   }

   /**
    * Should not be invoked directly.  Use
    * {@link #getInstanceFromSession(HttpSession)} instead.
    * Public for backwards compatibility only.
    */
   public HttpContainer()
   {
      super();
      initialize();
   }

   private static Object getSessionSyncLock(Object key)
   {
      synchronized(mSessionLockMap)
      {
         Object syncLock = mSessionLockMap.get(key);

         if (syncLock == null)
         {
            syncLock = new Object();
            mSessionLockMap.put(key, syncLock);
         }
         return syncLock;
      }
   }

   private static Object removeSessionSyncLock(Object key)
   {
      synchronized(mSessionLockMap)
      {
         return mSessionLockMap.remove(key);
      }
   }

   public Object getValue(Object key)
   {
      Object rtn = null;

      if (mResources != null)
      {
         rtn = getValue(mResources, key);
      }
      
      return rtn;
   }

   public Object removeValue(Object key, Properties userProperties)
   {
      Object rtn = null;

      if (mResources != null)
      {
         rtn = removeValue(mResources, key, userProperties, true);
      }
      
      return rtn;
   }

   public Object removeValueInternal(Object key)
   {
      Object rtn = null;

      if (mResources != null)
      {
         rtn = removeValue(mResources, key, null, false);
      }
      
      return rtn;
   }

   public void clear(Properties userProperties)
   {
      HashMap resources = null;
      HashMap cookies = null;
      BindingEvent ev = null;

      synchronized(mLock)
      {
         if (mResources != null)
         {
            resources = (HashMap)mResources.clone();
            mResources.clear();
         }
         
         cookies = (HashMap)mCookies.clone();
         mCookies.clear();
         ev = buildBindingEvent(userProperties);
      }

      if (resources != null)
      {
         Iterator values = resources.values().iterator();

         while (values.hasNext())
         {
            Object value = values.next();
            fireValueUnbound(value, ev);
         }
      }

      // now iterate a cookies enumeration
      Iterator values = cookies.values().iterator();
      while (values.hasNext())
      {
         Object value = values.next();
         fireValueUnbound(value, ev);
      }
   }

   public void timeout(Properties userProperties)
   {
      HashMap resources = null;
      HashMap cookies = null;
      BindingEvent ev = null;

      synchronized(mLock)
      {
         if (mResources != null)
         {
            resources = (HashMap)mResources.clone();
            mResources.clear();
         }
         
         cookies = (HashMap)mCookies.clone();
         mCookies.clear();
         
         ev = buildBindingEvent(userProperties);   
      }

      if (resources != null)
      {
         Iterator listenerEnum = resources.values().iterator();
         while (listenerEnum.hasNext())
         {
            Object listener = listenerEnum.next();
            fireTimeout(listener, ev);
         }
      }

      Iterator listenerEnum = cookies.values().iterator();
      while (listenerEnum.hasNext())
      {
         Object listener = listenerEnum.next();
         fireTimeout(listener, ev);
      }
   }

   public Object putValue(Object key, Object value, Properties userProperties)
   {
      if (mResources == null)
      {
         mResources = new HashMap();
      }
      
      return setValue(mResources, key, value, userProperties);
   }

   public void valueBound(HttpSessionBindingEvent e)
   {
      synchronized(mLock)
      {
         if (!mRefreshingSession)
         {
            // If the context reference is null then bind it to the session
            // reference.  It is possible that this container has been
            // serialized and moved to another web server VM.
            mSession = e.getSession();
            initialize();
         }
      }
   }

   public void valueUnbound(HttpSessionBindingEvent e)
   {
      boolean timeout = false;
      synchronized(mLock)
      {
         if (!mRefreshingSession)
         {
            if (mSession != null)
            {
               removeSessionSyncLock(mSession);
            }

            mSession = null;
            timeout = true;
         }
      }

      // do not invoke timeout() in a synchronized block.  timeout is
      // already properly synchronized.  Invoking in a synchronized
      // block may result in bug 2779463:
      //
      // th0:  Invokes HttpSession.invalidate.  Acquires HttpContainer
      // lock here.  Invokes releaseApplicationModule on SessionCookie(s)
      // in container.  Waits on SessionCookie lock held by th1 below.
      // 
      // th1:  Invokes SessionCookie.releaseApplicationModule.  Acquires
      // SessionCookie lock.  Invokes cookieUpdated to update the
      // HttpSession.  Waits on the HttpContainer lock held by th0 above.
      if (timeout)
      {
         timeout(null);
      }

   }

   /**
    * Retrieve an http container instance from the http session context.
    *
    * @param session the target http session context
    */
   public static HttpContainer getInstanceFromSession(HttpSession session)
   {
      HttpContainer container = null;
      boolean isNewContainer = false;

      synchronized(getSessionSyncLock(session))
      {
         container = (HttpContainer)session.getValue(SESSION_CONTEXT_CONTAINER_NAME);

         if (container == null)
         {
            container = new HttpContainer();

            session.putValue(SESSION_CONTEXT_CONTAINER_NAME , container);
            isNewContainer = true;
         }
      }

      if (!isNewContainer)
      {
         synchronized(container.mLock)
         {
            // Make sure that container session is initialized.  This may
            // seem odd, but it is necessary because the container may have
            // been retrieved through de-serialization (clustered OC4J server)
            // which does not guarantee that the valueBound event is fired
            // by the session context.
            container.mSession = session;
         }
      }

      return container;
   }

   /**
    * Get a session cookie instance from the http session container.
    *
    * @param applicationId the application id that will be used to reference the
    * session cookie
    */
   public SessionCookie getSessionCookie(String applicationId)
   {
      String key = APPLICATION_COOKIE_PREFIX + applicationId;
      return (SessionCookie)getValue(mCookies, key);
   }

   /**
    * Get all session cookie instances from the http session container.
    */
   public SessionCookie[] getSessionCookies()
   {
      synchronized(mLock)
      {
         SessionCookie[] cookies = new SessionCookie[mCookies.size()];
         mCookies.values().toArray(cookies);

         return cookies;
      }
   }

   /**
    * Set a session cookie instance in the http session container.  The
    * cookie name will be used to store the session cookie.
    *
    * @param applicationId the application id that will be used to reference the
    *    session cookie
    * @param cookie the session cookie instance that will be stored
    */
   public void setSessionCookie(String applicationId, SessionCookie cookie)
   {
      String key = APPLICATION_COOKIE_PREFIX + applicationId;
      Object rtn = setValue(mCookies, key, cookie, null);

      // Add a cookie listener for the container.  This will be used
      // to notify the container that the session cookie state has been updated.
      // The cookie listener is a lightweight object because it may be
      // serializable.
      if (cookie != null)
      {
         cookie.setSessionCookieListener(this);
      }
      else if (rtn != null)
      {
         ((SessionCookie)rtn).setSessionCookieListener(null);  
      }
   }

   /**
    * Encode a URL with the values of the session cookies that are contained
    * by this container.  The encoded values will be decoded by the
    * default implementation of {@link oracle.jbo.http.HttpSessionCookie#readValue(Object)}
    * when and if the session cookie is re-instantiated.
    */
   public String encodeURL(String url)
   {
      synchronized(mLock)
      {
         HttpSessionCookieHelper helper =
            HttpSessionCookieHelperManager.getHttpSessionCookieHelper();

         url = helper.encodeURL(url, getSessionCookies());

         return url;
      }
   }

   private Object setValue(HashMap target, Object key, Object value, Properties properties)
   {
      Object rtn = null;
      boolean fireValueBound = false;
      boolean fireValueUnbound = false;
      BindingEvent ev = null;

      synchronized(mLock)
      {
         boolean exists = (getValue(target, key) != null);
         if (!exists)
         {
            if (value != null)
            {
               rtn = target.put(key, value);
               ev = buildBindingEvent(null);
               fireValueBound = true;
            }
         }
         else if (exists && (value == null))
         {
            rtn = target.remove(key);
            ev = buildBindingEvent(null);
            fireValueUnbound = true;
         }
      }

      if (fireValueBound)
      {
         fireValueBound(rtn, ev);
      }
      else if (fireValueUnbound)
      {
         fireValueUnbound(rtn, ev);
      }

      return rtn;
   }

   private Object getValue(HashMap target, Object key)
   {
      return target.get(key);
   }

   private BindingEvent buildBindingEvent(Properties props)
   {
      synchronized(mLock)
      {
         BindingEvent ev
            = new BindingEvent(mContextRef != null ? mContextRef : mSession);
         if (props != null)
         {
            ev.setUserProperties(props);
         }
         return ev;
      }
   }

   private Object removeValue(
      HashMap target, Object key, Properties properties, boolean notify)
   {
      Object rtn = null;
      BindingEvent ev = null;

      synchronized(mLock)
      {
         rtn = target.remove(key);
         ev = buildBindingEvent(properties);
      }

      if ((notify) && (rtn != null))
      {
         fireValueUnbound(rtn, ev);
      }

      return rtn;
   }

   private void fireValueUnbound(Object value, BindingEvent ev)
   {
      if ((value != null) && (value instanceof BindingListener))
      {
         ((BindingListener)value).valueUnbound(ev);
      }
   }

   private void fireValueBound(Object value, BindingEvent ev)
   {
      if ((value != null) && (value instanceof BindingListener))
      {
         ((BindingListener)value).valueBound(ev);
      }
   }

   private void fireTimeout(Object object, BindingEvent ev)
   {
      if ((object != null) && (object instanceof BindingListener))
      {
         ((BindingListener)object).timeout(ev);
      }
   }

   private void initialize()
   {
      if (mLock == null)
      {
         mLock = new Object();
      }
   }

   public void cookieUpdated()
   {
      // This method was necessary to force OC4J to replicate the container
      // state between clustered nodes.  Otherwise, OC4J does not recognize
      // the updates to the state of the objects in the container.
      synchronized(mLock)
      {
         if (mSession != null)
         {
            try
            {
               mRefreshingSession = true;
               mSession.putValue(SESSION_CONTEXT_CONTAINER_NAME , this);
            }
            catch(java.lang.IllegalStateException iex)
            {
               // Eat the illegal state exception if it occurs.  The session
               // must be invalidated which means that the cookie is being
               // timed out.
               // 02/06/2003 - Should no longer be necessary.  See comment
               // in valueUnbound.

            }
            finally
            {
               mRefreshingSession = false;
            }
         }
      }
   }

   private void readObject(ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      try
      {
         in.defaultReadObject();
      }
      catch (java.io.NotActiveException naex)
      {
         // Only thrown if defaultReadObject is not invoked from readObject
      }

      initialize();

      SessionCookie[] cookies = getSessionCookies();
      for (int i=0; i < cookies.length; i++)
      {
         cookies[i].setSessionCookieListener(this);
      }
   }

   /**
    * Locates a <tt>SessionCookie</tt> instance with the specified applicationId
    * in the <tt>HttpContainer</tt> associated with this session.  If a cookie
    * is not located then one will be created.
    * <p>
    * This method will use an application defintion (defined in a .cpx
    * file) to create/locate an ApplicationPool.  That ApplicationPool will
    * be used to generate the requested SessionCookie.
    * <p>
    * The  cookie properties parameter is used to pass properties through to
    * the {@link oracle.jbo.common.ampool.SessionCookieFactory} instance
    * which will create the SessionCookie.  As of 10.1.3, the
    * {@link oracle.jbo.http.HttpSessionCookieFactory} must be passed 
    * the current <tt>HttpServletRequest</tt> in the properties object with the
    * <tt>oracle.jbo.http.HttpSessionCookieFacotry.PROP_HTTP_REQUEST</tt>
    * key.  The request will be used to acquire a sessionId from the
    * HttpSession and to determine if a BC4J application cookie, representing
    * a failed over ApplicationModule state, was written in a previous request.
    * <p>
    * This method will register an HttpSessionCookieFactory with the target
    * pool unless a custom SessionCookieFactory has been specified.
    * <p>
    * Please see the javadoc for the SessionCookieFactory implementation
    * which has been specified for more information about supported
    * properties.
    * <p>
    * @see oracle.jbo.common.ampool.SessionCookie
    * @see oracle.jbo.common.ampool.ApplicationPool
    * @see oracle.jbo.uicli.mom.JUMetaObjectManager
    * @see oracle.jbo.http.HttpSessionCookieFactory
    * @see oracle.jbo.http.SharedSessionCookieFactory
    * @see oracle.jbo.common.ampool.DefaultSessionCookieFactory
    * <p>
    * @param session -  the session in which the cookie will be cached
    * @param applicationId  - the cookie cache key.  The application id will
    *    also be used as part of the cookie identity if a cookie must be
    *    created.
    * @param applicationDefinitionName - a named ApplicationDefinition.  The
    *    applicationDefintionName will be used to locate/create an
    *    ApplicationPool.
    * @param cookieProperties - a collection of Properties to be used during
    *    cookie creation (see {@link oracle.jbo.common.ampool.SessionCookieFactory#createSessionCookie(String, String, ApplicationPool, Properties)}).
    *
    */
   public static SessionCookie findSessionCookie(
      HttpSession session
      , String applicationId
      , String applicationDefinitionName
      , Properties cookieProperties)
   {
      HttpContainer container = getInstanceFromSession(session);
      synchronized(container.mLock)
      {
         boolean createdWebAppThreadContext = false;
         try
         {
            if (cookieProperties != null)
            {
               HttpServletRequest request = (HttpServletRequest)
                  cookieProperties
                     .get(HttpSessionCookieFactory.PROP_HTTP_REQUEST);

               try
               {
                  ServletADFContext.initThreadContext(
                     null
                     , request
                     , null);

                  createdWebAppThreadContext = true;
               }
               catch (Exception e)
               {
               }
            }

            if (!createdWebAppThreadContext)
            {
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("***********WARNING*************:  HttpContainer.findSessionCookie could not instantiate ServletADFContext.");
                  Diagnostic.println("Please pass HttpSessionCookieFactory.PROP_HTTP_REQUEST through the cookieProperties");
               }
            }

            SessionCookie cookie = container.getSessionCookie(applicationId);
            if (cookie == null)
            {
               Properties poolProps = new Properties();
               poolProps.put(JboContext.USE_DEFAULT_CONTEXT,
                             "true");

               ApplicationPool pool = 
                  oracle.jbo.uicli.mom.JUMetaObjectManager.createPool(
                     applicationDefinitionName
                     , poolProps);

               // Make sure that the HttpSessionCookieFactory is set on the pool
               // if a custom session cookie factory has not been specified
               SessionCookieFactory factory = pool.getSessionCookieFactory();
               if (PropertyMetadata.ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME.pDefault.equals(factory.getClass().getName()))
               {
                  pool.setSessionCookieFactory(new HttpSessionCookieFactory());
               }

               Properties httpCookieProps = new HttpSessionCookieProperties();
               if (cookieProperties != null)
               {
                  httpCookieProps.putAll(cookieProperties);
               }

               // go ahead and pass the session in on the cookie props.
               // the damage has already been done by creating the session.
               // 
               // this is a backwards compatibility issue only
               if (session != null)
               {
                  httpCookieProps.put(
                     HttpSessionCookieFactory.PROP_HTTP_SESSION, session);
               }

               httpCookieProps.put(SessionCookieFactory.PROP_IS_WEB_APP
                  , new Boolean(true));

               try
               {
                  cookie = pool.createSessionCookie(applicationId, null, httpCookieProps);
               }
               catch(ApplicationPoolException apex)
               {
                  // Bug 2026193
                  if (AMPoolMessageBundle.EXC_AMPOOL_COOKIE_ALREADY_EXISTS.equals(apex.getErrorCode()))
                  {
                     cookie = apex.getSessionCookie();
                  }
                  else
                  {
                     throw apex;
                  }
               }
               
               container.setSessionCookie(applicationId, cookie);
            }
            else
            {
               String configName =
                  oracle.jbo.uicli.mom.JUMetaObjectManager.getConfigName(applicationDefinitionName);

               String cookieConfigName = cookie.getEnvConfigurationName();

               // if the fully qualified cookie config name does not contain
               // the application definition config name then throw an
               // exception.  The application developer requested a cookie
               // with a configuration environment that does not match that of the
               // specified configuration.
               if (configName != null
                  && cookieConfigName != null
                  && (cookieConfigName.indexOf(configName) < 0))
               {
                  throw new ApplicationPoolException(
                     AMPoolMessageBundle.class
                     , AMPoolMessageBundle.EXC_AMPOOL_CONFIG_MISMATCH
                     , new Object[] {
                        cookie.getApplicationId()
                        , cookie.getSessionId()
                        , cookieConfigName
                        , configName});
               }
            }

            return cookie;
         }
         finally
         {
            if (createdWebAppThreadContext)
            {
               ServletADFContext.resetThreadContext();
            }
         }
      }
   }

   /**
    * Locates a <tt>SessionCookie</tt> instance with the specified applicationId
    * in the <tt>HttpContainer</tt> associated with this session.  If a cookie
    * is not located then one will be created.
    * <p>
    * This method will use the pool name and a named configuration (defined in
    * a .xcfg file) to create/locate an ApplicationPool.  That ApplicationPool
    * will be used to generate the requested SessionCookie if a cookie is not
    * located.
    * <p>
    * The optional pool properties parameter may be used to configure the pool
    * at runtime.  If a pool must be created then the pool properties will be
    * merged with the specified configuration (please note that the properties
    * will not be used if the pool already exists).  In the case of property
    * conflicts between the runtime specified properties and the Configuration
    * properties, the runtime properties will take precendence.  The
    * merged Configuration and pool properties will be copied into the
    * ApplicationPool environment and eventually into the SessionCookie
    * environment.  Examples of valid pool properties include:
    * <p>
    * <tt>PropertyConstants.ENV_DO_FAILOVER</tt>
    * <tt>PropertyConstants.ENV_DO_CONNECTION_POOLING</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_MAX_POOL_SIZE</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_INIT_POOL_SIZE</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_MIN_AVAIL_SIZE</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_MAX_AVAIL_SIZE</tt>
    * <tt>PropertyConstants.ENV_AMPOOL_MAX_INACTIVE_AGE</tt>
    * <p>
    * Please see the BC4J documentation for a description of each of these
    * properties.
    * <p>
    * The  cookie properties parameter is used to pass properties through to
    * the {@link oracle.jbo.common.ampool.SessionCookieFactory} instance
    * which will create the SessionCookie.  As of 10.1.3, the
    * {@link oracle.jbo.http.HttpSessionCookieFactory} must be passed 
    * the current <tt>HttpServletRequest</tt> in the properties object with the
    * <tt>oracle.jbo.http.HttpSessionCookieFacotry.PROP_HTTP_REQUEST</tt>
    * key.  The request will be used to acquire a sessionId from the
    * HttpSession and to determine if a BC4J application cookie, representing
    * a failed over ApplicationModule state, was written in a previous request.
    * <p>
    * This method will register an HttpSessionCookieFactory with the target
    * pool unless a custom SessionCookieFactory has been specified.
    * <p>
    * Please see the javadoc for the SessionCookieFactory implementation
    * which has been specified for more information about supported
    * properties.
    * <p>
    * @see oracle.jbo.common.ampool.SessionCookie
    * @see oracle.jbo.common.ampool.ApplicationPool
    * @see oracle.jbo.uicli.mom.JUMetaObjectManager
    * @see oracle.jbo.http.HttpSessionCookieFactory
    * @see oracle.jbo.http.SharedSessionCookieFactory
    * @see oracle.jbo.common.ampool.DefaultSessionCookieFactory
    * <p>
    * @param session -  the session in which the cookie will be cached
    * @param applicationId  - the cookie cache key.  The application id will
    *    also be used as part of the cookie identity if a cookie must be
    *    created.
    * @param poolName - the pool key of the ApplicationPool which will be used
    *    to generate the SessionCookie (see {@link oracle.jbo.common.ampool.PoolMgr#findPool(String, String, String, Properties)}).
    * <p>
    * @param configPackage - the configuration package.  For instance, if the
    *    configuration is defined for an ApplicationModule with the full name,
    *    "hrpackage.HRAppModule", then the configPackage name is
    *    "hrpackage".
    * <p>
    * @param configSection - the configuration name.  In the example for
    *    the configuration package above the configuration name might be
    *    "HRAppModuleLocal".
    * <p>
    * @param poolProps - a collection of properties to be used during pool
    *    creation.
    * <p>
    * @param cookieProps - a collection of Properties to be used during cookie creation.
    * @see oracle.jbo.common.ampool.SessionCookieFactory#createSessionCookie(String, String, ApplicationPool, Properties)
    *
    */
   public static SessionCookie findSessionCookie(
      HttpSession session
      , String applicationId
      , String poolName
      , String configPackage
      , String configSection
      , Properties poolProps
      , Properties cookieProps)
   {
      // NOTE:  The JSPApplicationRegistry may invoke this method with a null
      // configPackage and configSection name
      HttpContainer container = getInstanceFromSession(session);
      synchronized(container.mLock)
      {
         boolean createdWebAppThreadContext = false;
         try
         {
            if (cookieProps != null)
            {
               HttpServletRequest request = (HttpServletRequest)
                  cookieProps
                     .get(HttpSessionCookieFactory.PROP_HTTP_REQUEST);

               try
               {
                  ServletADFContext.initThreadContext(
                     null
                     , request
                     , null);
               }
               catch (Exception e)
               {
               }

               createdWebAppThreadContext = true;
            }

            if (!createdWebAppThreadContext)
            {
               if (Diagnostic.isOn())
               {
                  Diagnostic.println("***********WARNING*************:  HttpContainer.findSessionCookie could not instantiate ServletADFContext.");
                  Diagnostic.println("Please pass HttpSessionCookieFactory.PROP_HTTP_REQUEST through the cookieProps");
               }
            }

            String configName = null;
            if (configPackage != null && configSection != null)
            {
               configName = new StringBuffer(configPackage)
                  .append(".")
                  .append(configSection)
                  .toString();
            }
    
            SessionCookie cookie = container.getSessionCookie(applicationId);
            if (cookie == null)
            {
               // Tell our jndi implementation that 
               // we are running insde an appserver 
               if(poolProps == null)
               {
                  poolProps = new Properties();
               }
               poolProps.put(JboContext.USE_DEFAULT_CONTEXT,
                             "true");

               ApplicationPool pool = PoolMgr.getInstance().findPool(
                  poolName
                  , configPackage
                  , configSection
                  , poolProps);

               // Make sure that the HttpSessionCookieFactory is set on the pool if a
               // custom session cookie factory has not been specified
               SessionCookieFactory factory = pool.getSessionCookieFactory();
               if (PropertyMetadata.ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME.pDefault.equals(factory.getClass().getName()))
               {
                  pool.setSessionCookieFactory(new HttpSessionCookieFactory());
               }

               Properties httpCookieProps = new HttpSessionCookieProperties();
               
               if (cookieProps != null)
               {
                  httpCookieProps.putAll(cookieProps);
               }

               // go ahead and pass the session in on the cookie props.
               // the damage has already been done by creating the session.
               // 
               // this is a backwards compatibility issue only
               if (session != null)
               {
                  httpCookieProps.put(
                     HttpSessionCookieFactory.PROP_HTTP_SESSION, session);
               }

               try
               {
                  cookie = pool.createSessionCookie(
                     applicationId, null, httpCookieProps);
               }
               catch(ApplicationPoolException apex)
               {
                  // Bug 2026193
                  if (AMPoolMessageBundle.EXC_AMPOOL_COOKIE_ALREADY_EXISTS.equals(apex.getErrorCode()))
                  {
                     cookie = apex.getSessionCookie();
                  }
                  else
                  {
                     throw apex;
                  }
               }

               container.setSessionCookie(applicationId, cookie);            
            }
            else
            {
               // bug 2234454
               String cookieConfigName = cookie.getEnvConfigurationName();
               if (cookieConfigName != null
                  && configName != null
                  && cookieConfigName.indexOf(configName) < 0)
               {
                  throw new ApplicationPoolException(
                     AMPoolMessageBundle.class
                     , AMPoolMessageBundle.EXC_AMPOOL_CONFIG_MISMATCH
                     , new Object[] {
                        cookie.getApplicationId()
                        , cookie.getSessionId()
                        , cookieConfigName
                        , configName});
               }
            }

            return cookie;
         }
         finally
         {
            if (createdWebAppThreadContext)
            {
               ServletADFContext.resetThreadContext();
            }
         }
      }
   }
}

