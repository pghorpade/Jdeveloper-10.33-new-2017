/*
 * @(#)HttpSessionCookieHelperManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

/**
 */
public class HttpSessionCookieHelperManager extends Object
{
   private static HttpSessionCookieHelper mHelper = null;

   private HttpSessionCookieHelperManager()
   {
   }

   public static synchronized HttpSessionCookieHelper getHttpSessionCookieHelper()
   {
      if (mHelper == null)
      {
         mHelper = new HttpSessionCookieHelperImpl();
      }

      return mHelper;
   }
}

 