/*
 * @(#)HttpSessionCookieHelperImpl.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.client.Configuration;
import java.net.URLEncoder;

/**
 * Default HttpSessionCookieHelper implementation.
 */
public class HttpSessionCookieHelperImpl extends Object
   implements HttpSessionCookieHelper
{
   /**
    * Constructor
    */
   public HttpSessionCookieHelperImpl()
   {
   }

   public String readCookieValue(
      HttpServletRequest request
      , String applicationName)
   {
      return readCookieValueInternal(
         request, request.getCookies(), applicationName);
   }

   public String readCookieValue(
      Cookie[] cookies 
      , String applicationName)
   {
      return readCookieValueInternal(null, cookies, applicationName);
   }

   private String readCookieValueInternal(
      HttpServletRequest request
      , Cookie[] cookies
      , String applicationName)
   {
      String cookieName = null;
      try
      {
         cookieName = URLEncoder.encode(
            applicationName
            , "UTF-8");
      }
      catch (java.io.UnsupportedEncodingException e) {}


      String cookieValue = null;

      Cookie cookie = null;

      if (cookies != null)
      {
         for (int i=0; i < cookies.length; i++)
         {
            if (cookies[i].getName().equals(cookieName))
            {
               cookie = cookies[i];
               break;
            }
         }
      }

      if (cookie != null)
      {
         cookieValue = cookie.getValue();
      }
      // Try to read the cookie value from the request parameters
      else if (request != null)
      {
         cookieValue = request.getParameter(cookieName);
      }

      String decryptCookieValue =
         Configuration.getRestoredChecksumValue(cookieValue);

      return decryptCookieValue;
   }

   public void writeCookieValue(
      HttpServletResponse response
      , String applicationName
      , String cookieValue)
   {
      int cookieAge = JboEnvUtil.getPropertyAsInt(
         PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.pName
         , Integer.valueOf(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.pDefault)
            .intValue());

      writeCookieValueInternal(
         response, applicationName, cookieValue, cookieAge);
   }

   public void writeCookieValue(
      HttpServletResponse response, SessionCookie sessionCookie)
   {
      int cookieAge = PoolMgr.getProperty(
         PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.pName
         , sessionCookie.getEnvironment()
         , Integer.valueOf(PropertyMetadata.ENV_MAX_POOL_COOKIE_AGE.pDefault)
            .intValue());

      writeCookieValueInternal(
         response
         , sessionCookie.getApplicationId()
         , (String)sessionCookie.getValue()
         , cookieAge);
   }

   private void writeCookieValueInternal(
      HttpServletResponse response
      , String applicationName
      , String cookieValue
      , int cookieAge)
   {
      if (response.isCommitted())
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.println("WARNING:  Cannot write SessionCookie value to a commited response.");
         }
         return;
      }


      String encCookieValue = Configuration.getChecksumValue(cookieValue);
      String cookieName = null;
      try
      {
         cookieName = URLEncoder.encode(
            applicationName
            , "UTF-8");
      }
      catch (java.io.UnsupportedEncodingException e) {}

      Cookie cookie = new Cookie(cookieName, encCookieValue);


      if (cookieAge >= 0)
      {
         cookie.setMaxAge(cookieAge);
      }

      response.addCookie(cookie);
   }

   public String generateSessionId(HttpSession session)
   {
      return session.getId();
   }

   public String generateSessionId(HttpServletRequest request)
   {
      return request.getSession(true).getId();
   }

   public String encodeURL(String url, SessionCookie[] cookies)
   {
      String path = null;
      String query = "";
      String amp = "";
      

      int question = url.indexOf('?');
      if (question < 0)
      {
         amp = "?";
      }
      else
      {
         amp = "&";
      }

      StringBuffer sb = new StringBuffer(url);
      for (int i = 0; i < cookies.length; i++)
      {
         sb.append(amp);
         sb.append(HttpContainer.APPLICATION_COOKIE_PREFIX);
         sb.append(cookies[i].getApplicationId());
         sb.append('=');
         sb.append(cookies[i].getValue());
         amp = "&";
      }

      return sb.toString();
   }
}

