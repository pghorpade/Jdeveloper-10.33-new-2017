/*
 * @(#)HttpSessionCookie.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.http;

import oracle.jbo.common.ampool.SessionCookie;

/**
 *  An interface for web session cookies.
 * <p>
 * HttpSessionCookies may extend a session cookie implementation with
 * additional logic to read and write cookie values from Http requests or
 * reponses.
 * <p>
 * @see oracle.jbo.common.ampool.SessionCookie
 */
public interface HttpSessionCookie extends SessionCookie
{
}
