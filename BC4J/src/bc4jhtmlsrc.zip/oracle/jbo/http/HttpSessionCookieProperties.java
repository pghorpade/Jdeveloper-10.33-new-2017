package oracle.jbo.http;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.share.ADFContext;

/* $Header: HttpSessionCookieProperties.java 22-may-2006.08:34:07 jsmiljan Exp $ */

/* Copyright (c) 2005, 2006, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    jsmiljan    08/11/05 - jsmiljan_bug-4367616
    jsmiljan    08/10/05 - Creation
 */

/**
 *  @version $Header: HttpSessionCookieProperties.java 22-may-2006.08:34:07 jsmiljan Exp $
 *  @author  jsmiljan
 *  @since   release specific (what release of product did this appear in)
 */
public class HttpSessionCookieProperties extends Properties
{
   public HttpSessionCookieProperties()
   {
      super();
   }

   public HttpSessionCookieProperties(Properties props)
   {
      super(props);
   }

   public Object get(Object key)
   {
      Object rtn = super.get(key);
      if (rtn == null)
      {
         if (HttpSessionCookieFactory.PROP_HTTP_REQUEST.equals(key))
         {
            rtn = ADFContext.getCurrent().getEnvironment().getRequest();
         }
         else if (HttpSessionCookieFactory.PROP_HTTP_SESSION.equals(key))
         {
            Object request = ADFContext.getCurrent().getEnvironment()
               .getRequest();

            if (request instanceof HttpServletRequest)
            {
               rtn = ((HttpServletRequest)request).getSession(true);
            }
         }
      }

      return rtn;
   }
}
