/*
 * @(#)SessionTimeOutHandler.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.html.jsp.JSPApplicationRegistry;

public class SessionTimeOutHandler implements HttpSessionBindingListener
{
  String            poolName;
  ApplicationModule am = null;
  static PoolMgr poolManager = PoolMgr.getInstance();
  
  public SessionTimeOutHandler(String poolName , ApplicationModule am)
  {
    this.poolName = poolName;
    this.am = am;
  }

  public void valueBound(HttpSessionBindingEvent e)
  {
  }

  public void valueUnbound(HttpSessionBindingEvent e)
  {
    JSPApplicationRegistry.getInstance().releaseAppModuleInstance(
      poolName
      , e.getSession()
      , null
      , JSPApplicationRegistry.STATELESS);
      
    System.err.println("************* AM was released" + am.toString());
    
  }
  
}