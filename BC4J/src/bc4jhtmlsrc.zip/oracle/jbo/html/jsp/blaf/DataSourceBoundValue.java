/*
 * @(#)DataSourceBoundValue.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import oracle.cabo.ui.RenderingContext;
import oracle.cabo.ui.data.BoundValue;
import oracle.cabo.ui.data.DataObject;
import javax.servlet.jsp.PageContext;

public class DataSourceBoundValue implements BoundValue 
{
   String      _dataSource;
   String      _dataItem;
   PageContext _pageContext;
   
   public DataSourceBoundValue(PageContext pageContext, String sDataSource, String sDataItem)
   {
      _dataSource = sDataSource;
      _dataItem = sDataItem;
      _pageContext = pageContext;
   }

   public Object getValue(RenderingContext rctx)
   {
      DataObject dataObject = (DataObject)JboUtil.getCaboDataSource(_pageContext, _dataSource);

      if(dataObject == null)
         return null;

      if(_dataItem != null)
         return dataObject.selectValue(rctx, _dataItem);
      return dataObject;
   }
}