/*
 * @(#)OrdURLBoundValue.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.RenderingContext;
import oracle.cabo.ui.data.DataObject;
import oracle.cabo.ui.data.BoundValue;
import oracle.jbo.html.DataSource;
import oracle.jbo.Row;
import oracle.ord.html.OrdURLBuilder;

public class OrdURLBoundValue implements BoundValue
{
  private DataSource m_dataSource;
  private String m_attrName;
  private String m_dsName;  //DataSource name
  private String m_amConfig;
  private String m_retrievePath;
  private PageContext m_pageContext;

  public OrdURLBoundValue(DataSource dataSource, 
                          String attrName, 
                          String dsName,
                          String amConfig,
                          PageContext pageContext)
  {
    this.m_dataSource = dataSource;
    this.m_attrName = attrName;
    this.m_dsName = dsName;
    this.m_amConfig = amConfig;
    this.m_pageContext = pageContext;
    this.m_retrievePath = OrdUixJspUtil._getRetrievePath(dataSource);
  }
  
  public Object getValue(RenderingContext context)
  {
    DataObject source = (DataObject)m_pageContext.getAttribute(m_dsName + "uix");
    Row row = (Row)source.selectValue
      (context,
       oracle.ord.common.PropertyConstants.ORD_UIX_JSP_SELECT_ROW
       );

    String url = null;

    if(row.getAttribute(m_attrName) != null)
    {
      //
      //Only if domain not equal to null, shall it output HTML.
      //
      OrdURLBuilder urlBuilder = 
        new OrdURLBuilder(m_dataSource, row , m_attrName,
                          m_retrievePath, m_amConfig);
      url = urlBuilder.getOrdDomainURL();
    }

    return url;
  }

}
