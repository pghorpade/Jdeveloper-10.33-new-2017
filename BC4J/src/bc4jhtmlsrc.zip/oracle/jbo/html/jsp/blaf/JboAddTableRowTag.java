/*
 * @(#)JboAddTableRowTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.JspException;
import oracle.cabo.ui.jsps.tags.AddTableRowTag;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.PageContext;

public class JboAddTableRowTag extends AddTableRowTag
{
   public JboAddTableRowTag()
   {
   }

   /**
   * doEndTag
   * @return int
   * @exception javax.servlet.jsp.JspException
   */
   public int doEndTag() throws JspException
   {
      JboTableTag parent = (JboTableTag)TagSupport.findAncestorWithClass(this, JboTableTag.class);

      if(parent != null)
      {
         // get the datasource name
         String datasource = parent.getDatasource();
         
         // handle any events here
         JboUtil.handleAddRowEvent(getPageContext(), datasource);
      }

      // let the standard table row do it's work
      return super.doEndTag();
   }

   protected PageContext getPageContext()
   {
      // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
      return super.getPageContext();
   }
}

