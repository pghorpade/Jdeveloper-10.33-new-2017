/*
 * @(#)JboNavigationBarTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import oracle.cabo.ui.jsps.tags.NavigationBarTag;
import oracle.cabo.ui.beans.nav.NavigationBarBean;
import oracle.cabo.ui.MutableUINode;
import javax.servlet.jsp.PageContext;


public class JboNavigationBarTag extends NavigationBarTag
{
   String datasource;

   /**
    * Constructor
    */
   public JboNavigationBarTag() {
   }

   public String getDatasource() {
      return datasource;
   }

   public void setDatasource(String newDatasource) {
      datasource = newDatasource;
   }

   /**
    * initializeProperties
    */
  public void setProperties(MutableUINode node) 
   {
      super.setProperties(node);

      NavigationBarBean bean = (NavigationBarBean)node;
      
      if(datasource == null)
         return;

      JboUtil.configureNavigatorBarFromDataSource(getPageContext(), datasource, bean);
   }

   /**
    * releaseBean
    */
   public void release() {
      super.release();

      datasource = null;
   }

   protected PageContext getPageContext()
   {
      // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
      return super.getPageContext();
   }
}

