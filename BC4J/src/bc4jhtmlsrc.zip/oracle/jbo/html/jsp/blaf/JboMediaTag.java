/*
 * @(#)JboImageTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.MutableUINode;
import oracle.cabo.ui.jsps.tags.MediaTag;
import oracle.cabo.ui.beans.MediaBean;



public class JboMediaTag extends MediaTag
{
  private String m_dsName;
  private String m_attrName;
  private String m_amConfig;

  /**
   * Constructor
   */
  public JboMediaTag() 
  {
  }

  public String getDatasource()
  {
    return m_dsName;
  }

  public void setDatasource(String newDatasource)
  {
    m_dsName = newDatasource;
  }

  public String getAttrName()
  {
    return m_attrName;
  }

  public void setAttrName(String newAttrName)
  {
    m_attrName = newAttrName;
  }
   
  public String getAmConfig()
  {
    return m_amConfig;
  }

  public void setAmConfig(String amConfig)
  {
    m_amConfig = amConfig;
  }

  /**
   * initializeProperties
   */
  public void setProperties(MutableUINode node)
  {
    super.setProperties(node);
    
    MediaBean bean = (MediaBean)node;

    if(m_dsName == null)
    {
      throw new RuntimeException("datasource attribute must not be null");
    }

    if(m_attrName == null)
    {
      throw new RuntimeException("attrName attribute must not be null");
    }

    OrdUixJspUtil.bindJboMediaBean(bean,
                                   this,
                                   m_dsName,
                                   m_attrName,
                                   m_amConfig,
                                   getPageContext()
                                   );

    /*
    
    JboUtil.registerBC4JProvider(pageContext, this);
    
    if(m_attrName != null)
    {
      if(m_dataSource != null)
      {
        //
        // datasource and attrName attributes have to be specified.
        //
        DataSource ds = 
          Utils.getDataSourceFromContext(pageContext, m_dataSource);

	//
        // These attributes should be set after all other "basic" attributes
        // were already set. So, it's safe to call bean.getXXXX() to get
        // the attributes value.
        //
        if(bean.getSource() == null)
        {
          //
          // Only if user does not specify "source" attribute
          //
          bean.setSourceBinding(new OrdURLBoundValue(ds, 
                                                     m_attrName, 
                                                     m_dataSource, 
                                                     m_amConfig, 
                                                     m_retrievePath)
                                );
          
          if(bean.getInnerHeight() == null && bean.getInnerWidth() == null)
          {
            bean.setInnerHeightBinding(new OrdHeightBoundValue(m_attrName, 
                                                               m_dataSource)
                                       );

            bean.setInnerWidthBinding(new OrdWidthBoundValue(m_attrName, 
                                                             m_dataSource)
                                      );
          }

          if(bean.getContentType() == null)
          {
            bean.setContentTypeBinding
              (new OrdContentTypeBoundValue(m_attrName,
                                            m_dataSource)
               );
          }
        }
      }
    }      
    */
  }

  /**
   * releaseBean
   */
  public void release() 
  {
    super.release();
    
    m_dsName = null;
    m_attrName = null;
    m_amConfig = null;
  }

  protected PageContext getPageContext()
  {
    // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
    return super.getPageContext();
  }
}

