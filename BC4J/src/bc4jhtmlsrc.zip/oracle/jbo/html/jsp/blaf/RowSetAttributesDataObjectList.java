/*
 * @(#)RowSetAttributesDataObjectList.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import oracle.cabo.ui.RenderingContext;
import oracle.cabo.ui.data.DataObject;
import oracle.cabo.ui.data.DataObjectList;

import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.RowSet;
import oracle.jbo.common.DefLocaleContext;

public class RowSetAttributesDataObjectList implements DataObjectList, DataObject
{
   protected RowSet   rs = null;
   protected AttributeDefDataObjectList current = null;
   protected ArrayList _attributeDefs;
   
   /**
    * Constructor
    */
   public RowSetAttributesDataObjectList(RowSet   rs, Vector displayAttributes)
   {
      this.rs = rs;

      _attributeDefs = new ArrayList();
      
      AttributeDef adefs[] = rs.getViewObject().getAttributeDefs();
      LocaleContext locale = rs.getApplicationModule().getSession().getLocaleContext();
      int nCount = 0;
       
      for(int i = 0 ; i < adefs.length; i++)
      {
         boolean bVisible = adefs[i].getUIHelper().getDisplayHint(locale).equals(AttributeHints.ATTRIBUTE_DISPLAY_HINT_DISPLAY);
         if(bVisible)
            _attributeDefs.add(adefs[i]);
      }
  
      // the display attributes override any other settings
      if(displayAttributes == null)
        return;

      _attributeDefs.clear();
      
      Enumeration e = displayAttributes.elements();

      while(e.hasMoreElements())
      {
        String sAttribute = (String)e.nextElement();
        AttributeDef aDef = rs.getViewObject().findAttributeDef(sAttribute);

        if(aDef != null)
          _attributeDefs.add(aDef);
      }
   }

   public int getLength()
   {
      return _attributeDefs.size();
   }

   public DataObject getItem(int index)
   {
      AttributeDef aDef = (AttributeDef)_attributeDefs.get(index);
      
      return new AttributeDefDataObjectList(rs , aDef);
   }

   public Object selectValue(RenderingContext context, Object select)
   {
      return current;
   }
}


class AttributeDefDataObjectList implements DataObjectList, DataObject
{
   protected RowSet           rs         = null;
   protected AttributeDef     aDef       = null;

   public AttributeDefDataObjectList(RowSet  rs, AttributeDef     aDef)
   {
      this.rs = rs;
      this.aDef = aDef;
   }

   public int getLength()
   {
      return 6;
   }

   public DataObject getItem(int index)
   {
      return this;
   }

   public Object selectValue(RenderingContext context, Object select)
   {
      String sAttribute = select.toString();
      String sValue = "";
      LocaleContext locale = new DefLocaleContext(context.getLocaleContext().getLocale());
      
      if(sAttribute.equalsIgnoreCase("name"))
      {
         sValue = aDef.getName();
      }
      else
      {
         sValue = aDef.getUIHelper().getHint(locale, sAttribute);
         if(sValue == null)
          sValue = (String)aDef.getProperty(sAttribute);
      }

      return sValue;
   }

}