/*
 * @(#)OrdUixJspUtil.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import java.util.Hashtable;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import oracle.cabo.ui.beans.ImageBean;
import oracle.cabo.ui.beans.MediaBean;
import oracle.cabo.ui.beans.nav.LinkBean;
import oracle.jbo.html.DataSource;
import oracle.jbo.Row;
import oracle.jbo.ApplicationModule;
import oracle.jbo.html.jsp.datatags.Utils;
import oracle.jbo.html.jsp.datatags.DataTagBase;
import oracle.ord.html.OrdURLBuilder;
import oracle.ord.im.OrdImageDomain;
import oracle.ord.im.OrdVideoDomain;
import oracle.jbo.common.PropertyMetadata;

class OrdUixJspUtil
{
  /**
   * Adds an ImageBean to the UINode tree. Bind the interMedia attribute
   * to the ImageBean.
   */
  static void bindJboImageBean(ImageBean imageBean,
                               Tag tag,
                               String dsName,
                               String attrName,
                               String amConfig,
                               PageContext pageContext
                               )
  {
    if(imageBean.getSource() == null)
    {
      //
      // The BC4J interMedia binding only makes sense when the "source"
      // attribute is not specified.
      //

      //
      // See if the ImageBean is used inside a TableBean and the "datasource"
      // attributes are the same.
      //
      boolean useContextualBinding = JboUtil.useUixBoundValue(tag, dsName);
      
      DataSource ds = 
        Utils.getDataSourceFromContext(pageContext, dsName);
      
      if(useContextualBinding)
      {
        //
        // The ImageBean is used inside a TableBean, and the <bc4juix:Image>
        // datasource attribute is equal to the <bc4juix:Table> datasource
        // attribute. So the ImageBean will be bound to the currentDataObject
        // through row set iteration in the rendering time.
        //
        // e.g.
        //
        //  <bc4juix:Table width="100%" datasource="ds1" >
        //
        //    <uix:columnHeaderStamp>
        //       <uix:styledText textBinding="LABEL"/>
        //    </uix:columnHeaderStamp>
        //
        //    <bc4juix:RenderValue datasource="ds1" dataitem="EmpNo" />
        //    <bc4juix:RenderValue datasource="ds1" dataitem="EmpName" />
        //    <bc4juix:Image datasource="ds1" attrName="EmpPic" />
        //  </bc4juix:Table>
        //

        imageBean.setSourceBinding(new OrdURLBoundValue(ds, 
                                                        attrName, 
                                                        dsName, 
                                                        amConfig, 
                                                        pageContext)
                                   );
        
        if(imageBean.getHeight() == null && imageBean.getWidth() == null)
        {
          imageBean.setAttributeValue(imageBean.HEIGHT_ATTR, 
                                      new OrdHeightBoundValue(attrName, 
                                                              dsName,
                                                              pageContext)
                                      );
          
          imageBean.setAttributeValue(imageBean.WIDTH_ATTR,
                                      new OrdWidthBoundValue(attrName, 
                                                             dsName,
                                                             pageContext)
                                      );
        }
      }else
      {
        //
        // The ImageBean is used statically. For example:
        // 
        // <jbo:DataSource id="ds1" ..../>
        // <jbo:Row id="row1" datasource="ds1" action="Find" rowKey="xxxx" >
        //   <bc4juix:Image datasource="ds1" attrName="Picture" />
        // </jbo:Row>
        //
        
        // Step 1. Get the current Row and the domain object
        
        //
        // The current Row might come from the parent <RowsetNavigate>, 
        // <RowsetIterate>, or <Row> tag. If not, then come from DataSource's
        // RowSet's currentRow.
        //
        Row currentRow = DataTagBase.getRowFromContext(tag, dsName, ds);
        Object domain = currentRow.getAttribute(attrName);

        String retrievePath = _getRetrievePath(ds);

        // Step 2. Construct the URL, set to ImageBean
        if(domain != null)
        {
          //
          //Only if domain not equal to null, shall it output HTML.
          //
          OrdURLBuilder urlBuilder = 
            new OrdURLBuilder(ds, currentRow , attrName,
                              retrievePath, amConfig);
          String url = urlBuilder.getOrdDomainURL();
          imageBean.setSource(url);
          
          // Step 3. Get the width and height, set to ImageBean
          if(imageBean.getWidth() == null && imageBean.getHeight() == null)
          {
            //
            // This step is needed only when user did not set width and
            // height attributes.
            //
            int width = 0;
            int height = 0;
            try
            {
              if(domain instanceof OrdImageDomain)
              {
                width = ((OrdImageDomain)domain).getWidth();
                height = ((OrdImageDomain)domain).getHeight();
              }else if(domain instanceof OrdVideoDomain)
              {
                width = ((OrdVideoDomain)domain).getWidth();
                height = ((OrdVideoDomain)domain).getHeight();
              }
            }catch(Exception e) 
            {
              width = 0;
              height = 0;
            }
            
            if(width > 0 && height > 0)
            {
              imageBean.setWidth(width);
              imageBean.setHeight(height);
            }
          }
        }
      }
    }
  }

  /**
   * Adds an LinkBean to the UINode tree. Bind the interMedia attribute
   * to the LinkBean.
   */
  static void bindJboLinkBean (LinkBean linkBean,
                               Tag tag,
                               String dsName,
                               String attrName,
                               String amConfig,
                               PageContext pageContext
                               )
  {
    if(linkBean.getDestination() == null)
    {
      //
      // The BC4J interMedia binding only makes sense when the "destination"
      // attribute is not specified.
      //

      //
      // See if the LinkBean is used inside a TableBean and the "datasource"
      // attributes are the same.
      //
      boolean useContextualBinding = JboUtil.useUixBoundValue(tag, dsName);
      

      DataSource ds = 
        Utils.getDataSourceFromContext(pageContext, dsName);
      
      if(useContextualBinding)
      {
        //
        // The LinkBean is used inside a TableBean, and the <bc4juix:Link>
        // datasource attribute is equal to the <bc4juix:Table> datasource
        // attribute. So the LinkBean will be bound to the currentDataObject
        // through row set iteration in the rendering time.
        //
        // e.g.
        //
        //  <bc4juix:Table width="100%" datasource="ds1" >
        //
        //    <uix:columnHeaderStamp>
        //       <uix:styledText textBinding="LABEL"/>
        //    </uix:columnHeaderStamp>
        //
        //    <bc4juix:RenderValue datasource="ds1" dataitem="EmpNo" />
        //    <bc4juix:RenderValue datasource="ds1" dataitem="EmpName" />
        //    <bc4juix:Link datasource="ds1" attrName="EmpClip" text="clip" />
        //  </bc4juix:Table>
        //

        linkBean.setDestinationBinding(new OrdURLBoundValue(ds, 
                                                            attrName, 
                                                            dsName, 
                                                            amConfig, 
                                                            pageContext)
                                       );
        
      }else
      {
        //
        // The LinkBean is used statically. For example:
        // 
        // <jbo:DataSource id="ds1" ..../>
        // <jbo:Row id="row1" datasource="ds1" action="Find" rowKey="xxxx" >
        //   <bc4juix:Link datasource="ds1" attrName="Picture" text="a picture" />
        // </jbo:Row>
        //
        
        // Step 1. Get the current Row and the domain object
        
        //
        // The current Row might come from the parent <RowsetNavigate>, 
        // <RowsetIterate>, or <Row> tag. If not, then come from DataSource's
        // RowSet's currentRow.
        //
        Row currentRow = DataTagBase.getRowFromContext(tag, dsName, ds);
        Object domain = currentRow.getAttribute(attrName);
        
        String retrievePath = _getRetrievePath(ds);

        // Step 2. Construct the URL, set to LinkBean
        if(domain != null)
        {
          OrdURLBuilder urlBuilder = 
            new OrdURLBuilder(ds, currentRow , attrName,
                              retrievePath, amConfig);
          String url = urlBuilder.getOrdDomainURL();
          linkBean.setDestination(url);
          
        }
      }
    }

    //
    // If the "text" attribute is null, then use "attrName"
    //
    if(linkBean.getText() == null)
    {
      linkBean.setText(attrName);
    }
  }

  /**
   * Adds an MediaBean to the UINode tree. Bind the interMedia attribute
   * to the MediaBean.
   */
  static void bindJboMediaBean(MediaBean mediaBean,
                               Tag tag,
                               String dsName,
                               String attrName,
                               String amConfig,
                               PageContext pageContext
                               )
  {
    if(mediaBean.getSource() == null)
    {
      //
      // The BC4J interMedia binding only makes sense when the "source"
      // attribute is not specified.
      //

      //
      // See if the MediaBean is used inside a TableBean and the "datasource"
      // attributes are the same.
      //
      boolean useContextualBinding = JboUtil.useUixBoundValue(tag, dsName);
      

      DataSource ds = 
        Utils.getDataSourceFromContext(pageContext, dsName);
      
      if(useContextualBinding)
      {

        mediaBean.setSourceBinding(new OrdURLBoundValue(ds, 
                                                        attrName, 
                                                        dsName, 
                                                        amConfig, 
                                                        pageContext)
                                   );
          
        if(mediaBean.getAttributeValue(mediaBean.INNER_WIDTH_ATTR) == null && 
           mediaBean.getAttributeValue(mediaBean.INNER_HEIGHT_ATTR) == null)
        {
          mediaBean.setAttributeValue(mediaBean.INNER_HEIGHT_ATTR, 
                                      new OrdHeightBoundValue(attrName, 
                                                              dsName,
                                                              pageContext)
                                      );
          
          mediaBean.setAttributeValue(mediaBean.INNER_WIDTH_ATTR,
                                      new OrdWidthBoundValue(attrName, 
                                                             dsName,
                                                             pageContext)
                                      );
        }

        if(mediaBean.getContentType() == null)
        {
          mediaBean.setAttributeValue(mediaBean.CONTENT_TYPE_ATTR,
                                       new OrdContentTypeBoundValue(attrName,
                                                                    dsName,
                                                                    pageContext)
                                       );
        }
      }
      else
      {
        //
        // The MediaBean is used statically. For example:
        // 
        // <jbo:DataSource id="ds1" ..../>
        // <jbo:Row id="row1" datasource="ds1" action="Find" rowKey="xxxx" >
        //   <bc4juix:Media datasource="ds1" attrName="Picture" />
        // </jbo:Row>
        //
        
        // Step 1. Get the current Row and the domain object
        
        //
        // The current Row might come from the parent <RowsetNavigate>, 
        // <RowsetIterate>, or <Row> tag. If not, then come from DataSource's
        // RowSet's currentRow.
        //
        Row currentRow = DataTagBase.getRowFromContext(tag, dsName, ds);
        Object domain = currentRow.getAttribute(attrName);
        
        String retrievePath = _getRetrievePath(ds);

        // Step 2. Construct the URL, set to ImageBean
        if(domain != null)
        {
          //
          //Only if domain not equal to null, shall it output HTML.
          //
          OrdURLBuilder urlBuilder = 
            new OrdURLBuilder(ds, currentRow , attrName,
                              retrievePath, amConfig);
          String url = urlBuilder.getOrdDomainURL();
          mediaBean.setSource(url);
          
          // Step 3. Get the width and height, set to ImageBean
          if(mediaBean.getAttributeValue(mediaBean.INNER_WIDTH_ATTR) == null && 
             mediaBean.getAttributeValue(mediaBean.INNER_HEIGHT_ATTR) == null)
          {
            //
            // This step is needed only when user did not set width and
            // height attributes.
            //
            int width = 0;
            int height = 0;
            try
            {
              if(domain instanceof OrdImageDomain)
              {
                width = ((OrdImageDomain)domain).getWidth();
                height = ((OrdImageDomain)domain).getHeight();
              }else if(domain instanceof OrdVideoDomain)
              {
                width = ((OrdVideoDomain)domain).getWidth();
                height = ((OrdVideoDomain)domain).getHeight();
              }
            }catch(Exception e) 
            {
              width = 0;
              height = 0;
            }

            if(width > 0 && height > 0)
            {
              mediaBean.setInnerWidth(width);
              mediaBean.setInnerHeight(height);
            }
          }
        }
      }
    }    

    //
    // If "shortDescription" attribute is not set by users, use the interMedia
    // attribute name as the default value.
    //
    if(mediaBean.getShortDesc() == null)
    {
      mediaBean.setShortDesc(attrName);
    }

  }  

  static String _getRetrievePath(DataSource ds)
  {

    ApplicationModule am = ds.getApplicationModule();
    Hashtable env = am.getSession().getEnvironment();
    
    String retrievePath = (String)
      env.get(oracle.jbo.common.PropertyConstants.ORD_RETRIEVE_PATH);

    if (retrievePath == null || retrievePath.length() == 0)
    {
      retrievePath = PropertyMetadata.ORD_RETRIEVE_PATH.getProperty();

      /*
      retrievePath = 
        oracle.ord.common.PropertyConstants.ORD_DEFAULT_RETRIEVE_PATH;
      */
    }

    return retrievePath;
  }
}
