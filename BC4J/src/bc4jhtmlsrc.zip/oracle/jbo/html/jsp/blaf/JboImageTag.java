/*
 * @(#)JboImageTag.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.jsp.blaf;

import javax.servlet.jsp.PageContext;
import oracle.cabo.ui.MutableUINode;
import oracle.cabo.ui.jsps.tags.ImageTag;
import oracle.cabo.ui.beans.ImageBean;

public class JboImageTag extends ImageTag
{
  private String m_dsName; // DataSource name
  private String m_attrName;
  private String m_amConfig;

  /**
   * Constructor
   */
  public JboImageTag() 
  {
  }

  public String getDatasource()
  {
    return m_dsName;
  }

  public void setDatasource(String newDatasource)
  {
    m_dsName = newDatasource;
  }

  public String getAttrName()
  {
    return m_attrName;
  }

  public void setAttrName(String newAttrName)
  {
    m_attrName = newAttrName;
  }
   
  public String getAmConfig()
  {
    return m_amConfig;
  }

  public void setAmConfig(String amConfig)
  {
    m_amConfig = amConfig;
  }

  /**
   * initializeProperties
   */
   public void setProperties(MutableUINode node) 
   {
      super.setProperties(node);

    if(m_dsName == null)
    {
      throw new RuntimeException("datasource attribute must not be null");
    }

    if(m_attrName == null)
    {
      throw new RuntimeException("attrName attribute must not be null");
    }

    ImageBean bean = (ImageBean)node;

    OrdUixJspUtil.bindJboImageBean(bean,
                                   this,
                                   m_dsName,
                                   m_attrName,
                                   m_amConfig,
                                   getPageContext()
                                   );
  }

  /**
   * releaseBean
   */
  public void release() 
  {
    super.release();
    
    m_dsName = null;
    m_attrName = null;
    m_amConfig = null;
  }

  protected PageContext getPageContext()
  {
    // TODO:  Override this oracle.cabo.ui.jsps.tags.BaseTag method
    return super.getPageContext();
  }

}

