/*
 * @(#)StructAttributesHandler.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.StructureDef;

final class StructAttributesHandler
{
   StructAttributesHandler()
   {
   }

   public void setAttributeFromRequestParameters(Row row, AttributeDef attrDef, RequestParameters params, LocaleContext locale)
      throws java.lang.IllegalAccessException, java.lang.InstantiationException
   {
      String baseName = attrDef.getName();
      
      oracle.jbo.domain.Struct struct = (oracle.jbo.domain.Struct) row.getAttribute(baseName);
      boolean isNew = false;
      boolean isNull = true;
      
      if (struct == null)
      {
         struct = (oracle.jbo.domain.Struct)attrDef.getJavaType().newInstance();
         isNew =true;
      }
      
      StructureDef sDef = struct.getStructureDef();
   
      for (int i = 0; i < sDef.getAttributeCount(); i++)
      {
         AttributeDef subAttrDef = sDef.getAttributeDef(i);
         HtmlServices.internalSetAttribute(HtmlServices.getStructAttributeName(attrDef, subAttrDef), struct, subAttrDef, params, locale);
         if (isNull)
         {
            isNull = (struct.getAttribute(i) == null);
         }
      }
   
      if (isNew)
      {
         if (!isNull)
         {
            row.setAttribute(attrDef.getIndex(), struct);
         }
      }
      else
      {
         if (isNull)
         {
            row.setAttribute(attrDef.getIndex(), null);
         }
      }
   }
}
   
