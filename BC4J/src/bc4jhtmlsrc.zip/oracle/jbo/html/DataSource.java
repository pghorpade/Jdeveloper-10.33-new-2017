/*
 * @(#)DataSource.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jbo.LocaleContext;

/**
 * The DataSource interface is a data provider abstraction used by DataWebBean and DataTags.
 *
 * @since JDeveloper 9.0.2
 */
public interface DataSource
{
   /**
    * Default size of the range use by the DataWebBean when the ViewObject range is 1.
    * DataTags do not use this value.
    */
   static final int	   DEFAULT_RANGE_SIZE = 10;

   /**
    * Return the name of the ViewObject bind to this datasource.
    * <p>
    * @return ViewObject name
    * @see oracle.jbo.ViewObject
    */
   String getViewObjectName();

   /**
    * Name of the ApplicationModule containing the ViewObject bind to this datasource.
    * <p>
    * @return ApplicationModule name
    * @see ApplicationModule
    */
   ApplicationModule getApplicationModule();

   /**
    * Bind a datasource to a BC4J ApplicationModule and retrieve find the ViewObject.
    * <p>
    * @param appName
    * @param am
    */
   void setApplicationModule(String appName, ApplicationModule am);

   /**
    * Return the RowSet instance of the ViewObject bind to this datasource.
    * <p>
    * @return the RowSet instance
    * @see RowSet
    */
   RowSet getRowSet();

   /**
    * Return identificator for the ApplicationModule. For the DataWebBean, it is the name of the
    * ApplicationModule, for the data tags, it is the application module id
    * <p>
    * @return id
    */
   String getApplicationId();

   HTMLFieldRenderer getEditFieldRenderer(PageContext page, Row row, AttributeDef attrDef);
   
   /**
   * Retrieves the default field renderer for a specified attribute definition
   * (that is, the attribute metadata).
   * <p>
   * @param attrDef an attribute definition.
   * @return default field renderer for the attribute definition.
   */
   HTMLFieldRenderer getEditFieldRenderer(PageContext page, HttpSession session, Row row, AttributeDef attrDef);
   
   HTMLFieldRenderer getDisplayFieldRenderer(PageContext page, Row row, AttributeDef attrDef);
   
   /**
   * Retrieves the default field renderer for a specified attribute definition
   * (that is, the attribute metadata).
   * <p>
   * @param attrDef an attribute definition.
   * @return default field renderer for the attribute definition.
   */
   HTMLFieldRenderer getDisplayFieldRenderer(PageContext page, HttpSession session, Row row, AttributeDef attrDef);

   // Return renderer class name from attribute definition or PageContext or SessionContext
   String getContextFieldRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef, String renderKey);
   
   String getDefaultFieldRendererClassName(AttributeDef attrDef, String renderKey);
   
   String getDefaultEditRendererClassName(AttributeDef attrDef);
   
   String getDefaultDisplayRendererClassName(AttributeDef attrDef);
   
   String getFieldRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef, String renderKey);
   
   String getEditRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef);
   
   String getDisplayRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef);

   
   /**
    *  Assigns an instance-level display field renderer to be used in the DataWebBean
    */
   void setDisplayFieldRenderer(AttributeDef attrDef, HTMLFieldRenderer rdr);

   /**
    *  Assigns an instance-level edit field renderer to be used in the DataWebBean
    */
   void setEditFieldRenderer(AttributeDef attrDef, HTMLFieldRenderer rdr);

   /**
    *  Assigns an instance-level display field renderer to be used in the DataWebBean
    */
   void setDisplayFieldRenderer(int nIndex, HTMLFieldRenderer rdr);

   /**
    *  Assigns an instance-level edit field renderer to be used in the DataWebBean
    */
   void setEditFieldRenderer(int nIndex, HTMLFieldRenderer rdr);
   
   boolean shouldDisplayAttribute(AttributeDef attrDef);

   String getAttributeLabel(String sAttribute);

   String getAttributeLabel(AttributeDef aDef);

   Row getRowFromKey(String sKey);

   /**
    * Determines if the DataSource is queryable based on the ViewObject information.
    * <p>
    * @return true is the ViewObject bind to the DataSource has any queryable fields.
    */
   public boolean isQueryable();
   
   /**
    * Returns the locale context
    */
   public LocaleContext getLocaleContext();
   
   /**
    * Synchronizes client changes with remote application.
    */
   public void synchronize();
   
   /**
    * 
    * @return true if this data source is based ona binding container
    */
   public boolean isBindingContainerDataSource();
   
   /**
    * Pass in the request object
    */
   public void setRequest(HttpServletRequest request);
   
   /**
    * Returns true if there is a custom render
    */
   public boolean hasFieldRenderer(PageContext page, Row row, AttributeDef attrDef, String sRendererKey);
}
