/*
 * @(#)QueryDefinition.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Vector;

/**
 * <B>Internal</B>: <EM>Applications should not use this
 * class.</EM>
 *
 **/
public class QueryDefinition
{
   public Vector queryRows = new Vector();   
}

