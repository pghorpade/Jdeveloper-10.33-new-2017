/*
 * @(#)XmlData.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import oracle.jbo.server.xml.XmlRowSetRenderer;
import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XSLException;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import oracle.jbo.common.JboXMLUtil;

/**
 * 
 * The <tt>XmlData</tt> class renders a canonical XML representation for the rows
 * of an <tt>oracle.jbo.RowSet</tt>. Since <tt>oracle.jbo.ViewObject</tt> implements
 * RowSet, <tt>XmlData</tt> can be used on any RowSet or View Object.
 * <p>
 * <tt>XmlData</tt> renders a canonical XML representation by iterating through
 * the attribute defs for
 * the initial "root" RowSet you specify when you instantiate it. It produces equivalent
 * XML tags for each scalar attribute. When <tt>XmlData</tt> detects that an attribute is a "nested
 * RowSet", it recurses into itself to print the nested XML for the nested RowSet.
 * The result is an XML "tree" of elements, reflecting the deep data print of all
 * the rows in the root RowSet, along with any nested (View Linked) detail information.
 * <p>
 * Optionally, the <tt>setStyleSheet</tt> method lets you transform the results of
 * <tt>XmlData</tt> according to an XSLT stylesheet.
 * <p>
 * You instantiate <TT>XmlData</TT> by declaring:
 * <p>
 * <pre>
 * XmlData d = new XmlData (rowset);
 * </pre>
 * <p>
 * No other special set up is required, however, <tt>XmlData</tt> includes funtionality to
 * let you:
 * <p>
 * <ul>
 * <li>Set the result element (that is, the document element) tag. </li>
 * <li>Limit the maximum number of master rows to render. </li>
 * <li>Associate an XSLT Stylesheet with the <tt>XmlData</tt> object.</li>
 * </ul>
 * <p>
 * By using custom properties, you can customize your XML output without
 * having to edit your Java classes.
 * <ul>
 *    <LI>By default, <tt>XmlData</tt> uses the View Object's name as the XML Element name of
 *    a View Object row. You can control the XML Element name used for a View Object row by
 *    adding a custom property to your View Object named <tt>XML_ELEMENT</tt>. Set
 *    <tt>XML_ELEMENT</tt> equal to the element name you want to use. </LI>
 *
 *    <LI>By default, <tt>XmlRowSetRenderer</tt> uses the View Object attribute's
 *    name as the XML Element name of a View Object attribute.
 *    You can control the XML Element name used for an attribute in a
 *    View Object row by adding a custom property to your View Object Attribute
 *    named <code>XML_ELEMENT</code>. Set
 *    <tt>XML_ELEMENT</tt> equal to the element name you want to use.
 *    To hide the attribute in the XML document, set that attribute's
 *    <tt>XML_ELEMENT</tt> equal to the value <tt>#hide</tt>.</LI>
 * </ul>
 * <p>
 * If you have a View Object attribute value that contains characters requiring
 * quotes, such as less-than (<) or ampersand (&), <tt>XmlData</tt> lets you treat it as an
 * XML CDATA section. Within a CDATA section, you can omit quotes from characters
 * that would otherwise require it. To treat an attribute value as a CDATA section,
 * add a custom property to your
 * View Object Attribute named CDATA with a value equal to "<tt>Y</tt>".
 * <p>
 * <h3>XmlData and the JSP Element Wizard</h3>
 * JDeveloper's JSP Element Wizard instantiates the <TT>XmlData</TT> class in a
 * <TT>jsp:useBean</TT> tag in a <TT>.jsp</TT> file. Along with the class, the wizard
 * also includes an ID and scope declaration set to <tt>request</tt>.
 * If you change the scope to any other value, you will have to handle possible
 * multithreading issues.
 * <p>
 *  The JSP Element Wizard's definition of an
 * <TT>XmlData</TT> instance includes these methods: <TT>setResultElement</TT>,
 * <TT>setStylesheet</TT>, <TT>setMaxRows</TT>,
 * <TT>setReleaseApplicationResources</TT>,
 * <TT>initialize</TT>, and <TT>render</TT>. For example,
 * <PRE>
 * &lt;jsp:useBean   class="oracle.jbo.html.databeans.XmlData"  id="xmlGen"
 *                            scope="request" &gt;
 * &lt;%
 *
 *    xmlGen.setResultElement("Deptno");
 *    xmlGen.setStylesheet("myXSL.xsl");
 *    xmlGen.setMaxRows(10);
 *    xmlGen.setReleaseApplicationResources(false);
 *    xmlGen.initialize(application,session, request,response,out,
 *                 "package3_Package3Module.DeptView");
 *    xmlGen.render();
 * %&gt;
 * &lt;/jsp:useBean&gt;
 * </PRE>
 * <p>
 * The value assigned to the <TT>setReleaseApplicationResources</TT> method
 * determines whether the Application Module is released after the
 * <tt>XmlData</tt> Data Web Bean processes it. Typically, the value should
 * not be set to true unless this is the last Web Bean to be processed in
 * the JSP page.
 * <p>
 **/
public class XmlData extends oracle.jbo.html.DataWebBeanImpl
{
  static final String INCLUDED_REQUEST_URI = "javax.servlet.include.request_uri";
  static final String INCLUDED_SERVLET_PATH = "javax.servlet.include.servlet_path";
  private String uri = null;
  private XmlRowSetRenderer xrr = null;
  private boolean inOracle8i = false;

  public XmlData()
  {
    String env = System.getProperty("oracle.server.version");
    inOracle8i = (env != null && !env.equals(""));
    xrr = new XmlRowSetRenderer();
    // For compatibility with JDev 3.0 behavior of XmlData
    xrr.setRowSetTag("Results");
  }

 /**
   *
   * Override the default XML Element name to be used for each Row
   * in each rowset.
   * <p>
   *
   * @param tag XML Element name for each Row.
   *
   **/
  public void setRowTag(String tag) {
    xrr.setRowTag(tag);
  }

  /**
   *
   * Specifies the name of the document element for the results. The document
   * element is the single, top-most, parent, enclosing tag
   * for the document. A valid XML document must have one and only
   * one document element.
   * <p>
   * If you do not specify a document element name, <tt>XmlData</tt> gives
   * it the default name "Result".
   * <p>
   * @param elt any valid XML element name.
   *
   **/
  public void setResultElement(String elt)
  {
    xrr.setRowSetTag(elt);
  }

 /**
   *
   * Overvie the default XML Element name to be used for the entire RowSet
   *
   * @param tag XML Element name for rowset
   *
   **/
  public void setRowSetTag(String tag) {
    xrr.setRowSetTag(tag);
  }

 /**
   *
   * Sets the URI of the XSLT stylesheet to (optionally) transform XML results.
   * If you do not specify a style sheet, the raw XML results
   * are returned.
   * <p>
   * @param uri URI of the stylesheet. The URI can be expressed in any of these
   * formats:
   *  <ul>
   *    <li> http://xxxx/yyy.xsl  </li>
   *    <li> /yyy.xsl  </li>
   *    <li> yyy.xsl  </li>
   *  </ul>
   **/
  public void setStylesheet(String uri)
  {
    this.uri = uri;
  }

 /**
   *
   * Sets the instance of an XSLTStylesheet object to use to (optionally)
   * transform XML results.
   **/
  public void setStylesheet(XSLStylesheet sheet) {
    xrr.setStylesheet(sheet);
  }

 /**
   *
   * Specifies the maximum number of master rows to render. Here, master row
   * is defined as a row in the original "root" rowset,
   * with its "detail" rows. A detail row is defined as a nested View Linked
   * rowset.
   * <p>
   * A suggested, useful value for the maximum is 1.
   * If you do not specify a maximum, all master rows are returned.
   * <p>
   * @param val number of rows to render.
   *
   **/
  public void setMaxRows( int val )
  {
    xrr.setMaxRows(val);
  }

  /**
   *
   * Prints the XML results to a PrintWriter.
   * <p>
   * @param out target of the PrintWriter function.
   *
   **/
  public void print(PrintWriter out) throws Exception
  {
    xrr.print(out);
  }

  /**
   *
   * Returns an in-memory DOM Document for the ViewObject
   *
   **/
   public Document getXMLDocument() throws Exception
   {
       try
       {
         setStylesheetFromName();
         return xrr.getXMLDocument();
       }
       finally {
         releaseApplicationResources();
       }
   }

   public void render() throws Exception
   {
       try
       {
         setStylesheetFromName();
         print(out);
       }
       finally {
         releaseApplicationResources();
       }
   }


  public void setStylesheetParam(String name, String value) {
    xrr.setStylesheetParam(name,value);
  }

  public void setStylesheetParamXPath(String name, String value) {
    xrr.setStylesheetParamXPath(name,value);
  }

  //--------------- PRIVATE CODE -----------------//

  private void setStylesheetFromName() {
    if (uri == null || uri.equals("")) {
      return;
    }
    URL u = null;
    try
    {
      u = new URL(translateURL(uri));
    }
    catch(MalformedURLException m)
    {
      throw new RuntimeException("Stylesheet URL is malformed.");
    }

    if (u != null)
    {
      try
      {
        DOMParser d = JboXMLUtil.createDOMParser(false);
        d.setValidationMode(DOMParser.NONVALIDATING);
        d.parse(u);
        XSLProcessor proc = new XSLProcessor();
        proc.setBaseURL(u);
        XSLStylesheet xslt = proc.newXSLStylesheet(d.getDocument());
        xrr.setStylesheet(xslt,u);
      }
      catch (IOException x)
      {
        throw new RuntimeException("Stylesheet "+uri+" not found.");
      }
      catch (SAXParseException x)
      {
        throw new RuntimeException(xmlError(x));
      }
      catch (SAXException x)
      {
        throw new RuntimeException(x.getMessage());
      }
      catch (XSLException x)
      {
        throw new RuntimeException(x.getMessage());
      }
    }
  }

  private String getSourceDocumentURI() {
    String pageurl = null;
    String fwdPath = (String) request.getAttribute(INCLUDED_REQUEST_URI);
    if (fwdPath != null) {
      pageurl = request.getSession().getServletContext().getRealPath(fwdPath);
    }
    else {
      String pathInfo       = request.getPathInfo();
      String reqURI         = request.getServletPath();
      if (pathInfo == null) {
        pageurl = reqURI != null ? request.getSession().getServletContext().getRealPath(reqURI) : null;
      }
      else {
        pageurl = request.getPathTranslated();
        if (pageurl == null||inOracle8i) {
          String servPath = request.getServletPath();
          pageurl = servPath != null ? request.getSession().getServletContext().getRealPath(servPath) : null;
        }
      }
    }
    pageurl = pageurl != null ? pageurl.replace('\\','/') : null;
    return pageurl;
  }

  private String translateURL(String path) {
    if ( path.startsWith("http:/") ) {
      return path;
    }
    else {
      if ( path.charAt(0) == '/' ) {
        String serverName = request.getServerName();
        String scheme     = request.getScheme();
        int    port       = request.getServerPort();
        return scheme + "://" + serverName + ( port != -1 ? ":" + port : "") + path;
      }
      else {
        int pos = -1;
        String s = getSourceDocumentURI();
        if (File.separatorChar != '/') {
           pos = s.lastIndexOf(File.separatorChar);
          if (pos == -1) {
            pos = s.lastIndexOf('/');
          }
        }
        else {
          pos = s.lastIndexOf('/');
        }

        String t = s.substring(0,pos+1);
        return "file:///" + t + path;

      }
    }
  }

  private String xmlError(SAXParseException s) {
     int lineNum = s.getLineNumber();
     int  colNum = s.getColumnNumber();
     String file = s.getSystemId();
     String  err = s.getMessage();

     return "XML parse error in file " + file +
            "\n" + "at line " + lineNum + ", character " + colNum +
            "\n" + err;

  }


  public void internalInitialize() throws Exception {
    super.internalInitialize();
    xrr.setRowSet(getRowSet());
  }
}
