/*
 * @(#)NavigatorBar.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Enumeration;

/**
 *
 * The NavigatorBar Data Web Bean renders itself as an Oracle toolbar. It
 * is responsible for providing
 * a toolbar UI for navigating a RowSet's rows.
 * <p>
 * This
 * Web Bean aggregates the <TT>oracle.jbo.html.databeans.RowsetNavigator</TT>.
 * Navigation requests such as "Next Page", that are activated by clicking
 * the buttons on the toolbar,
 * are passed to <TT>RowsetNavigator</TT>. <TT>RowsetNavigator</TT> processes
 * the requests and performs the designated action.
 * <P>
 * JDeveloper's JSP Element wizard instantiates the <TT>NavigatorBar</TT>
 * class in a <TT>jsp:useBean</TT> tag in a <TT>.jsp</TT> file. Along with the
 * class, the wizard also includes an ID and a scope declaration set to
 * <TT>request</TT>.
 * If you change the scope to any other value, you will have
 * to handle possible multithreading issues.
 * <P>
 * The definition of a
 * navigation bar provided by the wizard includes the methods:
 * <TT>setShowNavigationButtons</TT>, <TT>setReleaseApplicationResources</TT>,
 * <TT>initialize</TT>, and <TT>render</TT>. For example:
 * <P>
 * <PRE>
 * &lt;jsp:useBean   class="oracle.jbo.html.databeans.NavigatorBar"  id="myNavBar"
 *                  scope="request" &gt;
 * &lt;%
 *
 *	   myNavBar.setShowNavigationButtons(true);
 *	   myNavBar.setReleaseApplicationResources(false);
 *	   myNavBar.initialize(application,session, request,response,out,
 *            "package3_Package3Module.EmpView");
 *	   myNavBar.render();
 * %&gt;
 * &lt;/jsp:useBean&gt;
 * </PRE>
 * <P>
 * The value assigned to the <TT>setReleaseApplicationResources</TT> method
 * determines whether the Application Module is released after the
 * NavigatorBar Data Web Bean processes it. Typically, the value should
 * not be set to true unless this is the last Web Bean to be processed in
 * the JSP page.
 * <P>
 * The rendered navigation bar UI provides buttons that perform these
 * actions:
 * <UL>
 *   <LI>Goto first record</LI>
 *   <LI>Goto previous record</LI>
 *   <LI>Goto previous page</LI>
 *   <LI>Goto next page</LI>
 *   <LI>Goto next record</LI>
 *   <LI>Goto last record</LI>
 *   <LI>Delete record (row)</LI>
 *   <LI>Commit changes to the database (COMMIT)</LI>
 *   <LI>Discard changes in the form (ROLLBACK)</LI>
 * </UL>
 * <P>
 * The code for the navigation bar should be placed
 * prior to any Data Web Beans that will be displaying the
 * RowSet being operated on by the <TT>NavigatorBar</TT>. For example, you would place a
 * <TT>NavigatorBar</TT> Data Web Bean before the View Current Record Data Web Bean. This is
 * important since the <TT>NavigatorBar</TT> can adjust the current row in the RowSet
 * and the other Data Web Beans need to visualize the correct row after it has
 * been placed in context by the <TT>NavigatorBar</TT>.
 * <P>
 * The <TT>NavigatorBar</TT> class aggregates
 * <TT>oracle.jdeveloper.jsp.wb.Toolbar</TT>
 * to re-use its HTML generation functionality. You can add your own toolbar items
 * to the end of the navigation bar. For example, you can add toolbar items that
 * provide additional URLs that can be navigated
 * by using the toolbar. You can access the aggregated toolbar
 * by using the <TT>getContainer()</TT> function.
 *
 *
 *
 *
 **/
public class NavigatorBar extends BaseNavigatorBar
{
   protected oracle.jdeveloper.jsp.wb.Toolbar toolBar;
   
   public NavigatorBar()
   {
   }

   public void internalInitialize() throws Exception
   {
      super.internalInitialize();
      
      toolBar = new oracle.jdeveloper.jsp.wb.Toolbar();
   	toolBar.initialize(application, session , request, response, out);
   }
   
   
   public void populateToolBarFromCommands()
   {
      boolean isDividerButton = false;
      
      // setup the context
      buttons.setContext(this);

      Enumeration e = buttons.elements();

      while(e.hasMoreElements())
      {
         ToolBarButton button = (ToolBarButton)e.nextElement();

         if(!button.isButtonVisible())
               continue;

         if(button.getButtonType() == button.TYPE_DIVIDER)
         {
            // if we just added a divider, don't allow another one next to it
            if(!isDividerButton)
            {
               isDividerButton = true;
               toolBar.addSeparator(ImageDir + button.getImageUrl());
            }
         }
         else
         {
            isDividerButton = false;
            
            if(button.isEnabled())
            {
               toolBar.addButton(ImageDir + button.getImageUrl(), button.getCommandUrl(), button.getToolTipText());
            }
            else
            {
               toolBar.addDisabledButton(ImageDir + button.getDisabledImageUrl(), button.getToolTipText());
            }
         }
      }
   }

   public oracle.jdeveloper.jsp.wb.Toolbar getContainer()
   {
      return this.toolBar;
   }


   /**
   * Renders the HTML toolbar on the JSP page.
   * This method is the main entry point where the rendering of the toolbar
   * actually happens.
   */
   public void render() throws Exception
   {
      super.render();
	   
      toolBar.render();
      releaseApplicationResources();
   }
}
