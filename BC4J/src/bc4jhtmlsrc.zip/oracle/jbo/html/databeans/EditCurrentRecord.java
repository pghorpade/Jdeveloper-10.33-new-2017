/*
 * @(#)EditCurrentRecord.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import oracle.jbo.AttributeDef;
import oracle.jbo.DMLException;
import oracle.jbo.JboException;
import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowNotFoundException;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;
import oracle.jbo.common.TransPostControl;
import oracle.jbo.common.ampool.SessionCookie;
import oracle.jbo.html.HtmlServices;
import oracle.jbo.html.RequestParameters;
import oracle.jbo.http.HttpContainer;

import oracle.jdeveloper.html.DateField;
import oracle.jdeveloper.html.DateFieldContext;
import oracle.jdeveloper.html.FormFieldValueEncoder;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.HTMLForm;
import oracle.jdeveloper.html.HTMLFormField;
import oracle.jdeveloper.html.HTMLTextElement;
import oracle.jdeveloper.html.HiddenField;
import oracle.jdeveloper.html.PickList;
import oracle.jdeveloper.html.StaticPickList;
import oracle.jdeveloper.html.TextArea;
import oracle.jdeveloper.html.TextField;
import oracle.jdeveloper.html.LOVField;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.jsp.wb.EditForm;

/**
 * The EditCurrentRecord Data Web Bean edits the current record
 * of a View Object's RowSet. This Web
 * Bean contains two main entry points <TT>render()</TT> and <TT>execute()</TT>.
 * <P></P>
 *  <UL>
 *      <LI><TT>render()</TT> - generates the HTML FORM used for editing the row.</LI>
 *      <LI><TT>execute()</TT> - applied to a JSP page that will be the target
 * of the HTML FORM.</LI>
 *    </UL>
 * <P>
 * JDeveloper's JSP Element wizard instantiates the <TT>EditCurrentRecord</TT>
 * class in a <TT>jsp:useBean</TT> tag in a <TT>.JSP</TT> file. Along with the
 * class, the wizard also includes an ID and a scope declaration set to
 * <TT>request</TT>.
 * If you change the scope to any other value, you will have
 * to handle possible multithreading issues.
 * <P>
 * The definition of an
 * EditCurrentRecord edit form provided by the wizard includes these
 * methods:
 * <TT>setUseRoundedCorners</TT>, <TT>setSubmitText</TT>, <TT>setDeleteText</TT>,
 * <TT>setShowRecordNumbers</TT>,
 * <TT>setReleaseApplicationResources</TT>, <TT>initialize</TT>, and <TT>render</TT>.
 * For example:
 * <PRE>
 * &lt;jsp:useBean   class="oracle.jbo.html.databeans.EditCurrentRecord"
 *                          id="efDetail"  scope="request" &gt;
 * &lt;%
 *
 * &nbsp;&nbsp;&nbsp;efDetail.setUseRoundedCorners(true);
 * &nbsp;&nbsp;&nbsp;efDetail.setSubmitText("Save Changes");
 * &nbsp;&nbsp;&nbsp;efDetail.setDeleteText("Delete Record");
 * &nbsp;&nbsp;&nbsp;efDetail.setShowRecordNumbers(true);
 * &nbsp;&nbsp;&nbsp;efDetail.initialize(application,session, request,response,out,
 *                       "package3_Package3Module.EmpView");
 * &nbsp;&nbsp;&nbsp;efDetail.render();
 * %&gt;
 *  &lt;/jsp:useBean&gt;
 * </pre>
 * <P>
 * The EditCurrentRecord Data Web Bean renders the page by using field renderers.
 * A field renderer is a technique of rendering an attribute. For example,
 * TextAreas and Lists are field renderers. The field
 * renderers are responsible for rendering a single attribute
 * from the current row. The <TT>createDefaultFieldRenderers()</TT> function populates the
 * collection of field renderes for all the visible attributes. You can retrieve
 * an attribute's field renderer by using the <TT>getFieldRenderer()</TT> function. You can also
 * create your own field renderers:</P>
 * <P></P>
 *    <OL>
 *     <LI>Implement the <TT>oracle.jdeveloper.html.HTMLFieldRenderer</TT> interface.</LI>
 *     <LI>Place your field renderer class on the form and use the
 *         <TT>setFieldRenderer()</TT> function to associate it with an attribute.</LI>
 *    </OL>
 *
 *
 **/
public class EditCurrentRecord extends oracle.jbo.html.DataWebBeanImpl
{
   static final String ROW_OPERATION_PARAM   = "_ROWOPERATION";
   static final String IS_NEW_ROW_PARAM      = "_ISNEWROW";
   static final String ROW_KEY_PARAM         = "_ROWKEY";
   
   /**
   * The target URL of the HTML form.
   */
   protected   String      sTargetUrl = "";
   /**
   * Text displayed on the "Save" button. The default value is
   * <tt>Save Changes</tt>.
   */
   protected   String      sSaveChanges = "Save Changes";

   /**
   * Text displayed on the "Delete" button. The default value is
   * <tt>Delete Record</tt>.
   */
   protected   String      sDeleteRecord = "Delete Record";
   /**
   * Determines whether new rows will be inserted into the form.
   * The value is <TT>true</TT> in INSERT mode. The default value is
   * <TT>false</tt>.
   */
   protected   boolean     renderNewRow = false;
   /**
   * Stores the new row when <TT>EditCurrentRecord</TT> is in INSERT mode.
   */
   protected   Row         newRow = null;
   /**
   * Determines whether record numbers are displayed on the form.
   * The value is <TT>true</TT> to display numbers. The default value is
   * <TT>false</tt>
   */
   protected   boolean     showRecordNumber = false;
   /**
   * Determines the threshold width  (in characters) of the field. If
   * this number is exceeded,
   * then the field becomes a TextArea by default. The default value is 70.
   */
   protected   int         maxFieldWidth = 70;
   /**
   * The default display height (in characters) for an attribute. The
   * default height is 10.
   */
   protected   int         maxFieldHeight = 10;
   /**
   * Determines whether rounded or squared corners are used on the
   * HTML form. The value is <TT>true</TT> for rounded corners.
   */
   protected   boolean     useRoundedCorners;
   /**
   * Determines whether JavaScript is used for the dynamic version of
   * <tt>EditCurrentRecord</tt>.
   */
   protected   boolean     useJS = false;
   /**
   * Determines whether the bean has already generated the required JavaScript
   * libraries.
   */
   protected   int         JSlibNeeded = 0;

   /**
   * Determines the default date format. The default format
   * is <tt>RRRR-MM-DD</tt>.
   */
   protected   String      NLSFormat = WebBean.defaultNLSFormat;


   /**
   *   Show\Hide delete button
   **/
   protected boolean       bShowDeleteButton = true;

   /**
   *     Enable\disable use of multi-part mime type
   **/
   boolean bUseMultiPartMimeType = true;


   public EditCurrentRecord()
   {
      setUseRoundedCorners(false);
   }

   /**
   ** Sets whether to show\hide the delete button
   **/
   public void setShowDeleteButton(boolean bShow)
   {
      bShowDeleteButton = bShow;
   }

   /**
   **    returns whether the delete button will be rendered or not.
   **/
   public boolean getShowDeleteButton()
   {
      return bShowDeleteButton;
   }
   
   /**
    *    Enables or disables the use of rounded corners in the HTML table generated by this
    *    Web Bean.
    * <p>
    *    @param bSet <TT>true</TT> to use rounded corners in the table; <TT>false</TT> to use
    *    squared corners.
    */
   public void setUseRoundedCorners(boolean bSet)
   {
      useRoundedCorners = bSet;
   }

   /**
    * Sets the NLS format for the date as defined by the Cabo API.
    * <p>
    * @param format the date format.
    *  @deprecated  As of Jdev9i, replaced by support for User Interface Hints. See documentation
    */
   public void setNLSFormat(String format)
   {
      NLSFormat = format;
   }

   /**
   * Returns the NLS date format defined by the Cabo API.
   *  @deprecated  As of Jdev9i, replaced by support for User Interface Hints. See documentation   
   */
   public String getNLSFormat()
   {
      return NLSFormat;
   }

   /**
   * Determines whether JavaScript is used for the dynamic version of
   * <tt>EditCurrentRecord</tt>.
   * <p>
   * @param bSet <tt>true</tt> to use JavaScript; <tt>false</tt> otherwise.
   */
   public void setUseJS(boolean bSet)
   {
      useJS = bSet;
   }

   /**
   * Sets the maximum field width, measured in number of characters, reserved for
   * the attribute. If an attribute exceeds this width, a TextArea
   * (a multi-line text region) will be used to edit the contents.
   * <p>
   *  @param nWidth width of the field, measured in number of characters.
   *  @deprecated  As of Jdev9i, replaced by support for User Interface Hints. See documentation
   */

   public void setMaximumFieldWidth(int nWidth)
   {
      maxFieldWidth = nWidth;
   }

   /**
    *   Sets the maximum field height for a TextArea (a multi-line text region).
    * <p>
    *  @param nHeight height of the TextArea, measured in characters.
    *  @deprecated  As of Jdev9i, replaced by support for User Interface Hints. See documentation
    */

   public void setMaximumFieldHeight(int nHeight)
   {
      maxFieldHeight = nHeight;
   }

   /**
   *	Determines whether the control will render the record numbers on the form.
   * <p>
   *  @param bShow <TT>true</TT> to render record numbers on the form; <TT>false</TT> to
   *  omit record numbers.
   */
   public void setShowRecordNumbers(boolean bShow)
   {
      showRecordNumber = bShow;
   }

   /**
   *	Specifies the title used on the SUBMIT button displayed by the form.
   * <p>
   *  @param sText text displayed on the SUBMIT button.
   */
   public void setSubmitText(String sText)
   {
      sSaveChanges = sText;
   }


   /**
   *	Specifies the title used on the DELETE button displayed by the form.
   *  @param sText text displayed on the DELETE button.
   */
   public void setDeleteText(String sText)
   {
      sDeleteRecord = sText;
   }

   /**
   * Specifies the target URL that will receive the HTML FORM parameters when the user
   * clicks the SUBMIT button.
   * <p>
   * @param sUrl target URL for the HTML FORM parameters.
   *
   */
   public void setTargetUrl(String sUrl)
   {
      sTargetUrl = sUrl;
   }


   /**
   * Gets the target URL that will receive the HTML FORM parameters when the user clicks
   * the SUBMIT button.
   * <p>
   * @return URL that receives the HTML FORM parameters.
   */
   public String getTargetUrl()
   {
      return sTargetUrl;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Sets up the RowSet that contains the row to be edited. That is, it clears the field
   * renderers if the row to be edited is null; otherwise, it populates the
   * the row with its field renderers.
   * <P>
   * The RowSet is automatically retrieved as a side effect of
   * the <TT>initialize()</TT> function. Call <TT>setRowSet</TT> only if you need to
   * initialize the Web Bean with a RowSet other than the one designated by the
   * <TT>initialize</TT> method.
   * <p>
   * @param aQuery the RowSet to be edited.
   *
   * @deprecated  Deprecated since 5.0.  RowSet is now defined with the DataSource
   */
   public void setRowSet(RowSet aQuery)
   {
      // deprecated
   }

   /**
   * Directs the EditCurrentRecord Web Bean to create a new row in the RowSet
   * and to give focus to this row when generating
   * the edit form. This method also sets the control in "new row" mode so
   * that it can encode enough information in the HTML FORM to handle the
   * subsequent submission.
   */
   public void createNewRow()
   {
      // Create row for a webbean from a tag need to be execute after the initialize
      // but before the render and both of these operations are done in the doEndTag.
      doCreateRow();
   }

   private void doCreateRow()
   {
      if (ds == null)
      {
         throw new RuntimeException(Res.getString(Res.MSG_VO_NOT_FOUND));
      }

      RowSet rs = ds.getRowSet(); 
      Row row = rs.createRow();

      if (row != null)
      {
         Key newKey = row.getKey();

         rs.insertRow(row);

         renderNewRow = true;
         newRow = row;
      }
   }

   /**
   * Populates the collection of field renderers with the defaults obtained from the
   * View Object attributes. If you want to add your own field renderer, you must add
   * it after this call is made; otherwise, it will be removed from the list.
   *
   * @deprecated  Deprecated since 5.0.  Field renderer are now created lazily
   */
   public void createDefaultFieldRenderers()
   {
      // No-op
   }

   /**
   * Retrieves the default field renderer for a specified attribute definition
   * (that is, the attribute metadata).
   * <p>
   * @param attrDef an attribute definition.
   * @return default field renderer for the attribute definition.
   */
   public HTMLFieldRenderer getDefaultFieldRenderer(AttributeDef attrDef)
   {
      HTMLFieldRenderer rField = null;
      Row               row = null;
      RowSet            rs = ds.getRowSet();
      boolean           isReadOnly = false;

      if (renderNewRow == true)
         row = newRow;
      else
         row = rs.getCurrentRow();

      if (row == null)
      {
         row = rs.first();
      }

      // Use the super instead of going to the datasource because we need the session
      return super.getEditFieldRenderer(row, attrDef);
   }


   /**
   * Associates the provided field renderer with the provided attribute. Use
   * this method if you
   * want to associate your own field renderer with a row's attribute.
   * <p>
   * @param sAttrName name of the attribute.
   * @param rField name of the field renderer.
   */
   public void setFieldRenderer(String sAttrName , HTMLFieldRenderer rField)
   {
      // Use the storage in the datasource
      ds.setEditFieldRenderer(ds.getRowSet().getViewObject().findAttributeDef(sAttrName), rField);
   }

   /**
   * Returns the current field renderer associated with the specified attribute. This
   * function is very useful when you need to Set or Get
   * an attribute of the field renderer to, for example, change the field prompt or width.
   * <p>
   * @param sAttrName name of the attribute.
   * @return current field renderer for the specified attribute.
   *
   * @deprecated  Deprecated since 5.0.  Use getDefaultFieldRenderer(AttributeDef attrDef);
   */
   public HTMLFieldRenderer getFieldRenderer(String sAttrName)
   {
      return ds.getEditFieldRenderer(page, session, null, ds.getRowSet().getViewObject().findAttributeDef(sAttrName));
   }

   /**
   * A shortcut method for associating a combo box with the given attribute. The combo box
   * control is populated using the provided SQL query. The query must be valid within the
   * connection being used by
   * the application module that contains the RowSet. The <TT>sLabel</TT> parameter
   * specifies the name of the column to
   * be used for the prompt. The <TT>sValue</TT> parameter specifies the name of
   * the column to be used for the value. The
   * <TT>sLabel</TT> and <TT>sValue</TT> columns must be part of the result set defined
   * by the provided query.
   * <p>
   * @param sAttribute name of the attribute to be associated with the combo box.
   * @param sQuery string representing the query used to populate the combo box.
   * @param sLabel name of the column used for the prompt.
   * @param sValue name of the column used for the value.
   */
   public void useComboBox(String sAttribute, String sQuery, String sLabel, String sValue )
   {
      PickList rField = new PickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);

      rField.setAllowNulls(!attr.isMandatory());
      rField.setDisplayAttributes(sLabel);
      rField.setDataAttributes(sValue);
      rField.setDataSourceInfo(rs.getApplicationModule(), sQuery);
      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      setFieldRenderer(sAttribute , rField);
   }

   /**
   * Defines an attribute's combo box picklist that is populated from two arrays:
   * one for the labels and the other for the values. The combo box displays the
   * name of the attribute next to the input field. The <tt>labels</tt> and
   * <tt>values</tt> arrays must have the same dimension.
   * <p>
   *    @param  sAttribute   name of attribute represented by the combo box.
   *    @param  labels       String array containing the labels for each value.
   *    @param  values       String array containing the values assoicated with each label.
   */
   public void useStaticComboBox(String sAttribute, String[] labels, String[] values )
   {
      StaticPickList rField = new StaticPickList();
      RowSet   rs = ds.getRowSet();
      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);
      
      rField.setDataSource(labels , values);
      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      
      setFieldRenderer(sAttribute , rField);
   }

   /**
   * A shortcut method for associating a list box with the given attribute. The list box
   * control
   * is populated using the specified SQL query. The query must be valid within the
   * connection being used by
   * the application module that contains the RowSet. The <TT>sLabel</TT> parameter
   * specifies the name of the column to
   * be used for the prompt. The <TT>sValue</TT> paramter should contain the name of
   * the column to be used for the value. The
   * <TT>sLabel</TT> and <TT>sValue</TT> columns must be part of the result set defined
   * by the provided query.
   * <p>
   * @param sAttribute name of the attribute to be associated with the list box.
   * @param sQuery string representing the query used to populate the list box.
   * @param sLabel name of the column used for the prompt.
   * @param sValue name of the column used for the value.
   */
   public void useListBox(String sAttribute, String sQuery , String sLabel, String sValue )
   {
      PickList rField = new PickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);

      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setAllowNulls(!attr.isMandatory());
      rField.setDisplayAttributes(sLabel);
      rField.setDataAttributes(sValue);
      rField.setDataSourceInfo(rs.getApplicationModule(), sQuery);
      rField.setControlType(PickList.TYPE_LISTBOX);
      
      setFieldRenderer(sAttribute , rField);
   }


   /**
    * Defines an attribute's list box picklist that is populated from two
    * arrays: one for the labels and the other for the values. The list box displays the
    * name of the attribute next to the input field. The <tt>labels</tt> and
    * <tt>values</tt> arrays must have the same dimension.
    * <p>
    *    @param sAttribute   name of attribute represented by the list box.
    *    @param  labels       String array containing the labels for each value.
    *    @param  values       String array containing the values assoicated with each label.
    */
   public void useStaticListBox(String sAttribute,String[] labels, String[] values )
   {
      StaticPickList rField = new StaticPickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);
      
      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setDataSource(labels, values);
      rField.setControlType(StaticPickList.TYPE_LISTBOX);

      setFieldRenderer(sAttribute , rField);
   }

   /**
    * A shortcut method for associating a radio button group with the
    * given attribute. The radio button group
    * is populated using the specified SQL query. The query must be valid within
    * the connection being used by
    * the application module that contains the RowSet. The <TT>sLabel</TT> parameter
    * specifies the name of the column to
    * be used for the prompt. The <TT>sValue</TT> paramter specifies the name
    * of the column to be used for the value. The
    * <TT>sLabel</TT> and <TT>sValue</TT> columns must be part of the result set
    * defined by the provided query. The radio button group displays the
    * name of the attribute next to the input field.
    * <p>
    * @param sAttribute name of the attribute to be associated with the radio group.
    * @param sQuery string representing the query used to populate the radio group.
    * @param sLabel name of the column used for the prompt.
    * @param sValue name of the column used for the value.
    */
   public void useRadioGroup(String sAttribute, String sQuery , String sLabel, String sValue )
   {
      PickList rField = new PickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);

      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setAllowNulls(!attr.isMandatory());
      rField.setDisplayAttributes(sLabel);
      rField.setDataAttributes(sValue);
      rField.setDataSourceInfo(rs.getApplicationModule(), sQuery);
      rField.setControlType(PickList.TYPE_RADIO_GROUP);
      
      setFieldRenderer(sAttribute , rField);
   }


   /**
   * Defines a radio group picklist that is populated from two arrays: one for
   * the labels and the other for the values. The name of the attribute is displayed
   * with the radio group. The <tt>labels</tt> and
   * <tt>values</tt> arrays must have the same dimension.
   * <p>
   *    @param  sAttribute   name of attribute represented by the radio group.
   *    @param  labels       String array containing the labels for each value.
   *    @param  values       String array containing the values assoicated with each label.
   */
   public void useStaticRadioGroup(String sAttribute, String[] labels, String[] values)
   {
      StaticPickList rField = new StaticPickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);
      
      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setDataSource(labels , values);
      rField.setControlType(StaticPickList.TYPE_RADIO_GROUP);
      setFieldRenderer(sAttribute , rField);
   }

   /**
    *	A shortcut method for associating a check box group with the given attribute.
    *  The check box group
    *  is populated using the specified SQL query. The query must be valid within the
    *  connection being used by
    *  the application module that contains the RowSet. The <TT>sLabel</TT> parameter
    *  specifies the name of the column to
    *  be used for the  prompt. The <TT>sValue</TT> paramter specifies the name
    *  of the column to be used for the value. The
    *  <TT>sLabel</TT> and <TT>sValue</TT> columns must be part of the result set
    *  defined by the provided query.  The name of the attribute is displayed
    *  with the check box group.
    * <p>
    * @param sAttribute name of the attribute to be associated with the check box group.
    * @param sQuery string representing the query used to populate the check box group.
    * @param sLabel name of the column used for the prompt.
    * @param sValue name of the column used for the value.
    */
   public void useCheckBoxGroup(String sAttribute, String sQuery , String sLabel, String sValue )
   {
      PickList rField = new PickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);

      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setAllowNulls(!attr.isMandatory());
      rField.setDisplayAttributes(sLabel);
      rField.setDataAttributes(sValue);
      rField.setDataSourceInfo(rs.getApplicationModule(), sQuery);
      rField.setControlType(PickList.TYPE_CHECKBOX_GROUP);
      setFieldRenderer(sAttribute , rField);
   }

   /**
    *  Defines a check box group picklist that is populated from two arrays:
    *  one for the labels and the other for the values. The <tt>labels</tt> and
    * <tt>values</tt> arrays must have the same dimension.
    * <p>
    *    @param  sAttribute   name of attribute represented by the check box group.
    *    @param  labels       string array containing the labels for each value.
    *    @param  values       string array containing the values assoicated with each label.
    */
   public void useStaticCheckBoxGroup(String sAttribute, String[] labels, String[] values)
   {
      StaticPickList rField = new StaticPickList();
      RowSet   rs = ds.getRowSet();

      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);

      rField.setDatasource(ds);
      rField.setAttributeDef(attr);
      rField.setDataSource(labels , values);
      rField.setControlType(StaticPickList.TYPE_CHECKBOX_GROUP);

      setFieldRenderer(sAttribute , rField);
   }

   /**
   * Displays a single-line edit field in the HMTL form
   * for the specified attribute.
   *  @param sAttribute the attribute for which a single-line edit field
   * should be displayed.
   */
   public void useEditField(String sAttribute)
   {
      setFieldRenderer(sAttribute , new TextField());
   }

   /**
   *  Displays a multi-line edit field in the HTML form for the specified
   * attribute.
   * <p>
   *  @param sAttribute the attribute for which a single-line edit field
   * should be displayed.
   */
   public void useTextArea(String sAttribute)
   {
      setFieldRenderer(sAttribute , new TextArea());
   }

   /**
   * Provides a non-viewable field in the HMTL form for the specified attribute.
   * <p>
   * @param sAttribute name of the attrubute that should be stored in a
   * non-viewable field.
   */
   public void useHiddenField(String sAttribute)
   {
      setFieldRenderer(sAttribute , new HiddenField());
   }

   /**
   * Displays a calendar for the specified attribute.
   *  @param sAttribute the attribute for which a calendar should be displayed.
   */
   public void useDateField(String sAttribute)
   {
      DateField      rField = new DateField();

      rField.setNLSFormat(NLSFormat);
      rField.setHttpServletRequest(request);

      setFieldRenderer(sAttribute , rField);
   }
   /**
   * Enables a LOV (list of values) for the specified attribute in
   * the UI. In the typical case, when an attribute is selected in an
   * HTML form, a LOV will be displayed.
   * <p>
   * This method enables a LOV for one or more of the RowSet's attributes.
   * To return all of the RowSet's attributes,
   * use the {@link #useLOV(String, String) useLOV} method.
   * <p>
   * @param sAttribute name of the attribute for which an LOV
   * should be enabled.
   * @param voName name of the View Object to which the attribute belongs.
   * @param sDisplayAttributes a comma-separated list of the RowSet's attributes
   * that will be displayed when the attribute is selected.
   * @param sDataAttribute the location from which the attributes' values are
   * obtained.
   * @see #useLOV(String, String)
   */
   public void useListOfValues(String sAttribute, String voName, String sDisplayAttributes, String sDataAttribute)
   {
      RowSet rs = ds.getRowSet();
      JSlibNeeded |= WebBean.JSModalPageConstructorLib;

      LOVField lovField = new LOVField();

      lovField.setLovVo(voName);
      lovField.setDatasource(ds);
      AttributeDef attr = rs.getViewObject().findAttributeDef(sAttribute);
      lovField.setAttributeDef(attr);
      
      lovField.setDisplayAttributes(sDisplayAttributes);
      lovField.setDataAttributes(sDataAttribute);
      lovField.setHttpServletRequest(request);

      setFieldRenderer(sAttribute , lovField);
   }

   /**
   * Enables a LOV (list of values) for the specified attribute in the UI.
   * In the typical case, when the specified attribute is selected in an
   * HTML form, a LOV will be displayed.
   * <p>
   * This method enables a LOV for all of the RowSet's attributes.
   * To enable a LOV for a subset of the attributes,
   * use the {@link #useListOfValues(String, String, String, String)
   * useListOfValues} method.
   * <p>
   * @param sAttribute name of the attribute for which an LOV
   * should be enabled.
   * @param voName name of the View Object to which the attribute belongs.
   * @see #useListOfValues(String, String, String, String)
   */
   public void useLOV(String sAttribute, String voName)
   {
      useListOfValues(sAttribute, voName, null, sAttribute);
   }


   /**
    * Reads the <TT>_ROWOPERATION</TT> parameter from the JSP page's request and performs
    * the appropriate row operation on the record being edited. Possible
    * values for <TT>_ROWOPERATION</TT> are:
    *        <UL>
    *          <LI>Save Changes</LI>
    *          <LI>Delete Record</LI>
    *        </UL>
    */
   public void execute() throws Exception
   {
      doExecute();
   }

   private void doExecute() throws Exception
   {
      Row       row = null;
      RowSet    rs  = ds.getRowSet();
      RequestParameters params;

      if (bUsedInTag)
      {
         params = HtmlServices.getRequestParameters(page);
      }
      else
      {
         HttpContainer container = HttpContainer.getInstanceFromSession(session);
         SessionCookie cookie = container.getSessionCookie(getApplicationName());
         
         params = HtmlServices.getRequestParameters(request, response, cookie);
      }

      String sNewRow = params.getParameter(IS_NEW_ROW_PARAM);
      String sRowOperation = params.getParameter(ROW_OPERATION_PARAM);
      boolean isNewRow = (sNewRow != null && sNewRow.equalsIgnoreCase("true"));
      
      // goto the appropriate row
      row = ds.getRowFromKey(params.getParameter(ROW_KEY_PARAM));

      if (row == null)
      {
         if (isNewRow)
         {
            row = rs.getViewObject().createRow();
         }
      }

      if (row != null)
      {
         rs.setCurrentRow(row);

         // Delete operation
         if (sRowOperation.equals(sDeleteRecord))
         {
            Key currKey = row.getKey();

            try
            {
               row.remove();
            }
            catch (DMLException ex)
            {
               JboException toThrow = ex;

               try
               {
                  ((TransPostControl) rs.getApplicationModule()).transPostRevert(ex.getEntityRowHandle());
               }
               catch (RowNotFoundException rnfe)
               {
                  rnfe.addToDetails(ex);
                  toThrow = rnfe;
               }

               // bring back any deleted rows
               rs.executeQuery();
               Row [] rows = rs.findByKey(currKey, 1);
               if (rows.length > 0)
                  rs.setCurrentRow(rows[0]);

               throw toThrow;
            }
         }
         else
         {
            try
            {
               HtmlServices.updateRowAttributesFromRequestParameters(ds, row, params);
            }
            catch (DMLException ex)
            {
               ((TransPostControl) rs.getApplicationModule()).transPostRevert(ex.getEntityRowHandle());
               throw ex;
            }
         }
      }

      handleCommit();
   }

   /**
    * Renders <TT>EditCurrentRecord</TT>'s edit form containing the current record of
    * the View Object's RowSet.
    */
   public void render() throws Exception
   {
      HTMLForm           aForm   = null;
      RowSet             rs = ds.getRowSet();
      Row                row     = rs.getCurrentRow();
      int                RowTag  = rs.getRangeStart() + rs.getRangeIndexOf(row) + 1;

      if (renderNewRow)
      {
         row = newRow;
      }

      if (row == null)
      {
         row = rs.first();
      }

      // no work to be done, get out
      if (row == null)
      {
         releaseApplicationResources();
         return;
      }

      if (useJS)
      {
         JSlibNeeded |= JSButtonConstructorLib;
      }

      // since we dont check to see if we have a date field, always incllude calendar support
      JSlibNeeded |= JSCalendarConstructorLib;

      if (JSlibNeeded != 0)
      {
         initBeanForJS(JSlibNeeded, NLSFormat);

         out.println("<script language=\"javascript\">");
         if ((JSlibNeeded & WebBean.JSModalPageConstructorLib) != 0)
         {
            out.println("window.onFocus = checkModal");
         }
         out.println("</script>");
      }

      if (useRoundedCorners || useJS)
      {
         aForm = new EditForm(getTargetUrl(), "iForm");
         ((EditForm) aForm).setUseRoundedCorners(!useJS);
         ((EditForm) aForm).setUseJS(useJS);
      }
      else
      {
         aForm = new HTMLForm(getTargetUrl(), "iForm");
      }

      // setup default format
      if(isUseMultiPartMimeType())
         aForm.useMultiPartFormat();

      aForm.addHiddenField(ROW_KEY_PARAM, getRowKey(row));

      if (useRoundedCorners || useJS)
      {
         if (page != null)
         {
            ((EditForm)aForm).initialize(page);
         }
         else
         {
            ((EditForm)aForm).initialize(application, session, request, response, out);
         }
      }

      if (showRecordNumber)
         aForm.addReadOnlyField("Record #", "_recno", "" + RowTag, 20);

      AttributeDef[]     attrs   = getDisplayAttributeDefs();
      for (int attrNo = 0; attrNo < attrs.length ; attrNo++)
      {
         if (!shouldDisplayAttribute(attrs[attrNo]))
            continue;

         String sAttrName = attrs[attrNo].getName();
         String sValue = "";

         Object obj = row.getAttribute(attrs[attrNo].getIndex());
         if (obj != null)
            sValue = obj.toString();

         //encode the value
         sValue = FormFieldValueEncoder.encode(sValue);

         HTMLFieldRenderer rField = getEditFieldRenderer(row, attrs[attrNo]);

         if(!NLSFormat.equals(WebBean.defaultNLSFormat))
         {
            if(rField instanceof DateFieldContext)
            {
               ((DateFieldContext)rField).setNLSFormat(NLSFormat);
            }
         }

         rField.setFormName(aForm.getFormName());
         
         String sOutput = rField.renderToString(row);

         aForm.addFieldElement(new HTMLFormField(new HTMLTextElement(rField.getPromptText()), new HTMLTextElement(sOutput)));
      }

      if (!rs.getViewObject().isReadOnly())
      {
         aForm.addSubmitButton(ROW_OPERATION_PARAM, sSaveChanges);
         // since we insert the new row in the createRow() call
         // we need to allow for a deletion from the UI
         if(getShowDeleteButton())
            aForm.addSubmitButton(ROW_OPERATION_PARAM, sDeleteRecord);
      }

      if (renderNewRow)
      {
         aForm.addHiddenField(IS_NEW_ROW_PARAM, "true");         
      }

      if (useRoundedCorners || useJS)
      {
         ((EditForm)aForm).render();
      }
      else
      {
         aForm.render(out);
      }

      releaseApplicationResources();
   }

   /**
    * internalInitialize
    * @exception java.lang.Exception
    */
   public void internalInitialize() throws Exception
   {
      super.internalInitialize();
      // the block was moved to execute(). see the explanation there.
   }

   public boolean isUseMultiPartMimeType() {
      return bUseMultiPartMimeType;
   }

   public void setUseMultiPartMimeType(boolean newBUseMultiPartMimeType) {
      bUseMultiPartMimeType = newBUseMultiPartMimeType;
   }


}
