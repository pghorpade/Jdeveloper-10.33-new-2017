/*
 * @(#)TextColumnUrlInfo.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import oracle.jdeveloper.html.HTMLElement;
import oracle.jdeveloper.html.HTMLTextURL;

public class TextColumnUrlInfo 
{
    public String sUrl;
    public String sText;
    public String sTarget;
    public String sColumnTitle;

    public TextColumnUrlInfo(String sTitle, String sText, String sUrl, String sTarget)
    {
        this.sUrl = sUrl;
        this.sText = sText;
        this.sTarget = sTarget;
        this.sColumnTitle = sTitle;
    }

    public String getTitle()
    {
        return sColumnTitle;
    }



    public HTMLElement getColumnElement(String sUrl)
    {
        HTMLTextURL txtUrl = new HTMLTextURL(sText, sUrl);

        if(sTarget != null)
        {
            txtUrl.setTarget(sTarget);
        }

        return txtUrl;
    }
}

