/*
 * @(#)JSRowSetBrowser.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Vector;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jdeveloper.html.DataWebBeanImpl;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.DHTMLArray;
import oracle.jdeveloper.html.DHTMLData;
import oracle.jdeveloper.html.DHTMLElement;
import oracle.jdeveloper.jsp.wb.JSTable;
import oracle.jdeveloper.jsp.wb.JSTableData;

public class JSRowSetBrowser extends DataWebBeanImpl
{
   int         nVisibleRows = 10;
   String      sRowUrl = null;
   boolean     bShowCurrentRow = true;
   String      sRowUrlTarget = null;
   Vector      extraUrlCols = new Vector();
   boolean     showRecordNumber = false;
   Hashtable   colTitles = new Hashtable();
   String      sRowEditUrl = null;
   String      sRowEditTarget = null;
   JSTable     table;
   JSTableData data;

   public JSRowSetBrowser()
   {
   }

   /**
   * Sets the row editing URL that is invoked when the user clicks the Edit
   * button. Typically, an "Action" column will be created in the table,
   * containing an
   * Edit icon. If this URL is set
   * to null, the column will not appear.
   * @param sUrl the URL to invoke when the Edit button is clicked.
   */
   public void setRowEditUrl(String sUrl)
   {
      sRowEditUrl = sUrl;
   }

   /**
   * Sets the target window for the row editing URL.
   * @param sName name of the target window.
   */
   public void setRowEditTargetWindow(String sName)
   {
      sRowEditTarget = sName;
   }

   /**
   *    Sets the column title of the given attribute.
   *
   *    @param sAttribute       attribute name.
   *    @param sTitle           column title for attribute.
   */
   public void setAttributeTitle(String sAttribute , String sTitle)
   {
      colTitles.put(sAttribute , sTitle);
   }


   /**
   *	Sets whether the control will render the record numbers in the browser.
   * @param bShow <TT>true</TT> to display record number; <TT>false</TT> to
   * suppress record numbers.
   */
   public void setShowRecordNumbers(boolean bShow)
   {
      showRecordNumber = bShow;
   }

   /**
   * Adds an additional column that contains a line of text that represents a URL.
   * The text will be repeated in each of the column's rows.
   * This column will be
   * appended after all of the
   * columns that represent attributes belonging to the RowSet.
   *
   *    @param sTitle   text to use as the column title.
   *    @param sText    text that will be used to represent the URL.
   *    @param sUrl     URL that will be invoked when text is clicked.
   *    @param sTarget  the target for the URL. This is useful when you are using HTML FRAMES.
   */
   public void addTextUrlColumn(String sTitle, String sText, String sUrl , String sTarget)
   {
      extraUrlCols.addElement(new TextColumnUrlInfo(sTitle, sText, sUrl , sTarget));
   }

   /**
   * Adds an additional column that contains a line of text that represents a URL.
   * The text will be repeated in each of the column's rows.
   * This column will be
   * appended after all of the
   * columns that represent attributes belonging to the RowSet.
   *
   *    @param sTitle   text to use as the column title.
   *    @param sText    text that will be used to represent the URL.
   *    @param sUrl     URL that will be invoked when text is clicked.
   */
   public void addTextUrlColumn(String sTitle, String sText, String sUrl)
   {
      addTextUrlColumn(sTitle , sText, sUrl , null);
   }

   /**
   * Adds an additional column with an image-based URL. This image will be
   * repeated in each of the column's rows.
   * This column will be
   * appended after all of the columns that represent attributes belonging to
   * the RowSet.
   *
   *    @param sTitle   text to use as the column title.
   *    @param sImageFile   URL for locating the image to be displayed.
   *    @param sUrl     URL that will be invoked when image is clicked.
   *    @param sTarget  the target for the URL. This is useful when you are using HTML FRAMES.
   */
   public void addImageUrlColumn(String sTitle, String sImageFile, String sUrl , String sTarget)
   {
      extraUrlCols.addElement(new ImageUrlInfo(sTitle, sImageFile, sUrl , sTarget));
   }

   /**
   * Adds an additional column with an image-based URL. This image will be
   * repeated in each of the column's rows.
   * This column will be
   * appended after all of the columns that represent attributes belonging to
   * the RowSet.
   *
   *    @param sTitle   text to use as the column title.
   *    @param sImageFile   URL for locating the image to be displayed.
   *    @param sUrl     URL that will be invoked when text is clicked.
   */
   public void addImageUrlColumn(String sTitle, String sImageFile, String sUrl)
   {
      addImageUrlColumn(sTitle, sImageFile, sUrl , null);
   }

   /**
   *  If you enabled the Row URL, this function sets up the target window for
   * the URL when
   *  the user activates it.
   */
   public void setRowUrlTargetWindow(String sUrl)
   {
      sRowUrlTarget = sUrl;
   }

   /**
   * Returns the name of the window being used as the Row URL target.
   *    @return name of the window used as the Row URL target.
   */
   public String getRowUrlTargetWindow()
   {
      return sRowUrlTarget;
   }

   /**
   * Sets the Row URL to be invoked when the user clicks the row number to
   * the left of each row.
   * An additonal parameter is appended to your URL to pass the row
   * number of the row
   * that was clicked. The <TT>RowSetNavigator</TT> and <TT>NavigatorBar</TT> Data
   * Web Beans process
   * the extra URL parameter to place the RowSet currency on the
   * row represented by this index.
   * @param sUrl Row URL of the
   */
   public void setRowUrl(String sUrl)
   {
      sRowUrl = sUrl;
   }

   /**
   * Returns the current Row URL setting. The value can be null.
   *    @return current Row URL.
   */
   public String getRowUrl()
   {
      return sRowUrl;
   }

   /**
   *  Enables or disables highlighting of the current RowSet's row when the HTML
   *  table is rendered.
   * @param bSet <TT>true</TT> to highlight the current RowSet row; <TT>false</TT>
   *  to not highlight the row.
   */
   public void setShowCurrentRow(boolean bSet)
   {
      bShowCurrentRow = bSet;
   }

   /**
   * Returns whether the current RowSet row is highlighted when the HTML
   *  table is rendered.
   *   @return <TT>true</TT> if the current row is highlighted;
   * <TT>false</TT> otherwise.
   */
   public boolean getShowCurrentRow()
   {
      return bShowCurrentRow;
   }

   /**
   * Sets the number of rows to be displayed by the RowSet browser.
   * Any value you
   * provide will also alter the RowSet's RangeSize. This is important because
   * the RangeSize is the sliding
   * window used to traverse the RowSet. If you set the visible rows to
   * -1 all the rows will be displayed.
   * To see an example of how the RangeSize is manipulated, look at the source
   * code for the NavigatorBar Data Web Bean.
   * All source code to the Web Beans is in <TT>jbohtmlsrc.zip</TT>.
   * @param nRows number of rows to display in the RowSet browser.
   */
   public void setVisibleRows(int nRows)
   {
      nVisibleRows = nRows;
   }

   /**
   * Returns the number of rows displayed (that is, "visible rows") in the RowSet
   * browser.
   * @return number of rows displayed in the RowSet browser.
   */
   public int getVisibleRows()
   {
      return nVisibleRows;
   }

   public void internalInitialize()
      throws Exception
   {
      super.internalInitialize();
   }


   protected void prepareForRendering() throws Exception
   {
      String         tableName = getUniqueName("display");
      String         dataName = getUniqueName("ds");
      String         tcName = "tcell";

      // Setup table WebBean
      table = new  oracle.jdeveloper.jsp.wb.JSTable(tableName);
      table.initialize(page);
      table.setRefName(tableName);
      table.setGrid("both");
      table.setWidthPercent("95");
   
      table.setDataSource(dataName);
   
      table.createTextCell(tcName, null, "false", "left");

      if (showRecordNumber)
      {
         table.addColumn(null, "Rec#", tcName, null, null);
      }
      
      RowSet rs = ds.getRowSet();
      AttributeDef[] dattrs =  getDisplayAttributeDefs();
      for (int attrNo = 0; attrNo < dattrs.length ; attrNo++)
      {
		   if(!shouldDisplayAttribute(dattrs[attrNo]))
					  continue;

		   String sHeader = ds.getAttributeLabel(dattrs[attrNo]);
           
           // see if the user wants a different title
         if (colTitles.get(sHeader) != null)
            sHeader = (String)colTitles.get(sHeader);
         
         table.addColumn(null, sHeader, tcName, null, null);
      }
      
      // add headers for extra columns
      for (int nExtra = 0 ; nExtra < extraUrlCols.size() ; nExtra++)
      {
         TextColumnUrlInfo info = (TextColumnUrlInfo)extraUrlCols.elementAt(nExtra);
         table.addColumn(null, info.getTitle(), tcName, null, null);
      }

      // Setup Data WebBean
      data = new oracle.jdeveloper.jsp.wb.JSTableData(dataName);
      data.initialize(page);

		if (rs.getRangeSize() != nVisibleRows)
		   rs.setRangeSize(nVisibleRows);

      Row[]   drows = rs.getAllRowsInRange();
      Row     currentRow = rs.getCurrentRow();
      String  sValue = null;
      String  sRowKey;

      for (int rowno = 0; rowno < drows.length; rowno++)
      {
         DHTMLArray dataArray = new DHTMLArray();
         
         sRowKey = drows[rowno].getKey().toStringFormat(true);

         if (showRecordNumber)
         {
            Integer RowTag = new Integer(rs.getRangeStart() + rowno + 1);
            dataArray.addElement(new DHTMLData(RowTag.toString(), null, null));
         }

         for (int j = 0; j < dattrs.length; j++)
         {
            if (!shouldDisplayAttribute(dattrs[j]))
               continue;

            sValue = "";

            if (drows[rowno] != null)
            {
               Object obj = drows[rowno].getAttribute(dattrs[j].getIndex());
               if (obj != null)
               {
                  sValue = DHTMLElement.filterDataChar(obj.toString());
               }
            }

            DHTMLData row = new DHTMLData();
            if (bShowCurrentRow && currentRow == drows[rowno])
            {
               row.setText("<font class=TABLECELLSHADED>" + sValue + "</font>");
            }
            else
            {
               row.setText(sValue);
            }

            dataArray.addElement(row);
         }

         for(int nExtra = 0 ; nExtra < extraUrlCols.size() ; nExtra++)
         {
            TextColumnUrlInfo info = (TextColumnUrlInfo)extraUrlCols.elementAt(nExtra);
            String sUrl = fixupUrl(info.sUrl, rs.getName() + EditCurrentRecord.ROW_KEY_PARAM + "=" + sRowKey);

            DHTMLData row = new DHTMLData();

            String sRowExtra = info.getColumnElement(sUrl).getAsString();

            sRowExtra = sRowExtra.replace('"', '\'');
            row.setText(sRowExtra);

            dataArray.addElement(row);
         }

         data.addRow(dataArray);

      }
      // if we don't have any rows, produce an empty row
      if(drows.length <= 0)
      {
         DHTMLArray dataArray = new DHTMLArray();

         DHTMLData row = new DHTMLData();
         row.setText(sValue);

         dataArray.addElement(row);

         for (int j = 0; j < dattrs.length; j++)
         {
            if (!shouldDisplayAttribute(dattrs[j]))
               continue;

            sValue = "";

            row = new DHTMLData();
            row.setText(sValue);

            dataArray.addElement(row);
         }
         data.addRow(dataArray);
      }
   }
   
   /**
    * Renders an HTML table that contains records from the View Object's RowSet.
    * This is the View Object to which the RowSetBrowser object was initialized.
    */
   public void render()  throws Exception
   {
      prepareForRendering();

      // Specify the library here instead of having the WebBean do it because the order is important
      initBeanForJS(WebBean.JSTableConstructLib|WebBean.JSDataConstructLib);
      data.render();
      table.render();
      PrintWriter out = getOut();
      // Need to reset the bottom
      for (int i=0; i < data.numberOfElements() + 3; i++)
      {
         out.print("<BR>");
      }
      releaseApplicationResources();
   }

   public String fixupUrl(String sUrl , String sExtra)
   {
      int     nParamIndex = sUrl.indexOf('?');
      String  sNewUrl = sUrl;

      if (nParamIndex != -1)
      {
         sNewUrl = sUrl + "&" + sExtra;
      }
      else
      {
         sNewUrl = sUrl + "?" + sExtra;
      }
      return sNewUrl;
   }
}


