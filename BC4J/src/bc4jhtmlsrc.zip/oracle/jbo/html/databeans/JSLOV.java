/*
 * @(#)JSLOV.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html.databeans;

import java.util.Hashtable;
import java.util.Vector;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jdeveloper.html.WebBean;
import oracle.jdeveloper.html.DHTMLArray;
import oracle.jdeveloper.html.DHTMLData;
import oracle.jdeveloper.html.DHTMLElement;
import oracle.jdeveloper.jsp.wb.JSTable;
import oracle.jdeveloper.jsp.wb.JSTableData;

public class JSLOV extends oracle.jbo.html.DataWebBeanImpl
{
   int         nVisibleRows = -1;
   String      attrName;
   String      filter = "%";
   Vector      extraUrlCols = new Vector();
   Hashtable   colTitles = new Hashtable();
   JSTable     table;
   JSTableData data;
   
   public JSLOV()
   {
   }

   /**
   * Sets the number of rows to be displayed by the RowSet browser.
   * Any value you
   * provide will also alter the RowSet's RangeSize. This is important because
   * the RangeSize is the sliding
   * window used to traverse the RowSet. If you set the visible rows to
   * -1 all the rows will be displayed.
   * To see an example of how the RangeSize is manipulated, look at the source
   * code for the NavigatorBar Data Web Bean.
   * All source code to the Web Beans is in <TT>jbohtmlsrc.zip</TT>.
   * @param nRows number of rows to display in the RowSet browser.
   */
   public void setVisibleRows(int nRows)
   {
      nVisibleRows = nRows;
   }

   /**
   * Returns the number of rows displayed (that is, "visible rows") in the RowSet
   * browser.
   * @return number of rows displayed in the RowSet browser.
   */
   public int getVisibleRows()
   {
      return nVisibleRows;
   }

   public void setReturnValue(String aName)
   {
      attrName = aName;
   }

   public String getReturnValue()
   {
      return attrName;
   }

   public void setFilter(String fltr)
   {
      filter = fltr;
   }

   public String getFilter()
   {
      return filter;
   }
   
   public void internalInitialize()
      throws Exception
   {
      super.internalInitialize();

      String   dtName = getUniqueName("disp");
      String   dArray = getUniqueName("ds");
      String   tcName = "tcell";
      String   lcName = "lcell";
      String   where  = "";

      // Setup table WebBean
      table = new  oracle.jdeveloper.jsp.wb.JSTable(dtName);
      table.initialize(page);
      table.setRefName(dtName);
      table.setGrid("both");
      table.setWidthPercent("95");

      table.setDataSource(dArray);

      table.createTextCell(tcName, null, "false", "left");
      table.createLinkCell(lcName, null, "false", null, null, null, null);

      RowSet rs = ds.getRowSet();
      AttributeDef[]     dattrs =  getDisplayAttributeDefs();
      for (int attrNo = 0; attrNo < dattrs.length ; attrNo++)
      {
	      if(!shouldDisplayAttribute(dattrs[attrNo]))
			   continue;

			String sHeader = ds.getAttributeLabel(dattrs[attrNo]);

         // see if the user wants a different title
			if (colTitles.get(sHeader) != null)
			   sHeader = (String)colTitles.get(sHeader);

         table.addColumn(null, sHeader, lcName, null, null);
         if (getFilter() != null && getFilter().length() > 0)
         {
            if (where.length() > 0)
            {
               where += " OR ";
            }
            where += dattrs[attrNo].getColumnNameForQuery() + " LIKE '" + getFilter() + "'";
         }
      }

      // add headers for extra columns
      for (int nExtra = 0 ; nExtra < extraUrlCols.size() ; nExtra++)
      {
         TextColumnUrlInfo info = (TextColumnUrlInfo)extraUrlCols.elementAt(nExtra);
         table.addColumn(null, info.getTitle(), tcName, null, null);
      }

      // Setup Data WebBean
      data = new oracle.jdeveloper.jsp.wb.JSTableData(dArray);
      data.initialize(page);

      if (getFilter() == null || getFilter().length() == 0)
      {
         rs.getViewObject().setWhereClause(null);
      }
      else
      {
         rs.getViewObject().setWhereClause(where);
      }
      rs.executeQuery();

      rs.setRangeSize(nVisibleRows);

      Row[]       drows = rs.getAllRowsInRange();
      String      sValue = null;
      String      retValue = null;
      String      sRowKey;

      for (int rowno = 0; rowno < drows.length; rowno++)
      {
         DHTMLArray dataArray = new DHTMLArray();

         sRowKey = drows[rowno].toString();

         retValue = "";
         if (drows[rowno] != null)
         {
            Object obj = drows[rowno].getAttribute(getReturnValue());
            if (obj != null)
            {
               retValue = DHTMLElement.filterDataChar(obj.toString());
            }
         }

         for (int j = 0; j < dattrs.length; j++)
         {
            if (!shouldDisplayAttribute(dattrs[j]))
               continue;

            sValue = getDataValueAt(drows, rowno, dattrs, j);

            DHTMLData row = new DHTMLData();
            row.setText(sValue);
            row.setAction("javascript:void parent.handleOK(\\\"" + retValue + "\\\")");

            dataArray.addElement(row);
         }

         data.addRow(dataArray);
      }

      // if we don't have any rows, produce an empty row
      if (drows.length <= 0)
      {
         DHTMLArray dataArray = new DHTMLArray();

         DHTMLData row = new DHTMLData();
         row.setText(sValue);

         dataArray.addElement(row);

         for (int j = 0; j < dattrs.length; j++)
         {
            if (!shouldDisplayAttribute(dattrs[j]))
               continue;

            sValue = "";

            row = new DHTMLData();
            row.setText(sValue);

            dataArray.addElement(row);
         }
         
         data.addRow(dataArray);
      }
   }

   protected String getDataValueAt(Row[] drows, int row, AttributeDef[] dattrs, int attr)
   {
      String sValue = "";

      if (drows[row] != null)
      {
         Object obj = drows[row].getAttribute(dattrs[attr].getIndex());
         if (obj != null)
         {
            sValue = DHTMLElement.filterDataChar(obj.toString());
         }
      }

      return sValue;
   }

   /**
    * Renders an HTML table that contains records from the View Object's RowSet.
    * This is the View Object to which the RowSetBrowser object was initialized.
    */
   public void render()
      throws Exception
   {
      // Specify the library here instead of having the WebBean do it because the order is important
      initBeanForJS(WebBean.JSTableConstructLib|WebBean.JSDataConstructLib);
      data.render();
      table.render();
      ds.getRowSet().getViewObject().setWhereClause(null);
      releaseApplicationResources();
   }
}


