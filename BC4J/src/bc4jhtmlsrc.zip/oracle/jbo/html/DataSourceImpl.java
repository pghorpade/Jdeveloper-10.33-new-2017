/**
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import java.sql.Types;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;
import oracle.jbo.client.JboUtil;
import oracle.jbo.common.JboTypeMap;

import oracle.jdeveloper.html.DateField;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jdeveloper.html.ReadOnlyField;
import oracle.jdeveloper.html.TextArea;
import oracle.jdeveloper.html.TextField;

public class DataSourceImpl implements DataSource
{
   private HttpServletRequest request;
   private RowSet             rs;
   private String             amId;
   private String             renderersAttributeName;
   private final String       voName;

   public DataSourceImpl(String viewObjectName)
   {
      voName = viewObjectName;
   }

   public DataSourceImpl(HttpServletRequest request, String viewObjectName)
   {
      voName = viewObjectName;
      this.request = request;   
   }

   public boolean isBindingContainerDataSource()
   {
       return false;
   }
    
   public void setRequest(HttpServletRequest request)
   {
      this.request = request;   
   }
   
   public String getViewObjectName()
   {
      return voName;
   }

   public void setApplicationModule(String appName, ApplicationModule amInstance)
   {
      setApplicationModule(appName, amInstance, null, false);   
   }
   
   protected void setRowSet(RowSet  rset)
   {
     rs = rset;
   }
   
   public void setApplicationModule(String appName, ApplicationModule amInstance, String rsName, boolean createRowset)
   {
      this.amId = appName;

      ViewObject vo = amInstance.findViewObject(voName);

      if (vo == null)
      {
         throw new JboException(Res.format(Res.DATASOURCE_CANT_FIND_VO, voName, amInstance.getName()));
      }

      if (rsName != null)
      {
         rs = vo.findRowSet(rsName);
         if (rs == null)
         {
            if (createRowset)
            {
               rs = vo.createRowSet(rsName);
            }

            if (rs == null)
            {
               throw new JboException(Res.format(Res.DATASOURCE_CANT_FIND_RS, rsName, voName));
            }
         }
      }
      else
      {
         rs = vo;
      }
      
      renderersAttributeName = "jbo_" + vo.getDefFullName();
      // Create renderers cache. One cache per vo definition
      if (getAttributeRenderers() == null)
      {
         setAttributeRenderers(renderersAttributeName , new HTMLFieldRenderer[2][vo.getAttributeCount()]);
      }
   }

   

   protected void setAttributeRenderers(String sRenderersAttributeName, HTMLFieldRenderer[][] attributeRenderers)
   {
      renderersAttributeName = sRenderersAttributeName;
      if(request != null)
         request.setAttribute(renderersAttributeName, attributeRenderers);
   }
   
   protected HTMLFieldRenderer[][] getAttributeRenderers()
   {
      if(request == null)
         return null;
         
      return (HTMLFieldRenderer[][]) request.getAttribute(renderersAttributeName);
   }

   /**
    * Return identificator for the ApplicationModule. For the DataWebBean, it is the name of the Application
    * Module, for the data tags, it is the application module id
    *
    */
   public String getApplicationId()
   {
      return amId;
   }

   protected void setApplicationId(String sId)
   {
      amId = sId;  
   }
   
   public ApplicationModule getApplicationModule()
   {
      return getRowSet().getApplicationModule();
   }

   public RowSet getRowSet()
   {
      return rs;
   }

   public LocaleContext getLocaleContext()
   {
     return getApplicationModule().getSession().getLocaleContext();
   }
   
   public String getContextFieldRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef, String renderKey)
   {
      String  sClassRenderer;
      LocaleContext  locale = getLocaleContext();
      
      // Check the attribute property for the renderer class name
      sClassRenderer = (String) attrDef.getProperty(renderKey);

      // Then check the attribute UI hint for the control type but only for the edit case
      if (sClassRenderer == null && HtmlServices.EDIT_RENDERER_KEY.equals(renderKey))
      {
         AttributeHints hints = attrDef.getUIHelper();
         
         if (hints != null)
         {
            int nHeight = hints.getDisplayHeight(locale);
            
            switch (hints.getControlType(locale))
            {
               case AttributeHints.CTLTYPE_EDIT:
                  if(nHeight == 1)
                     sClassRenderer = TextField.class.getName();
                  else
                     sClassRenderer = TextArea.class.getName();
                  break;
   
               case AttributeHints.CTLTYPE_DATE:
                  sClassRenderer = DateField.class.getName();
                  break;
            }
         }
      }
      
      // Check the page and/or the session attribute for the renderer class name
      if (sClassRenderer == null)
      {
         String sDomain = HtmlServices.getRendererKeyFromDomainName(attrDef.getJavaType().getName(), renderKey);

         if (page != null)
         {
            // Try the page context with default scope precedence (page, request, session, application)
            sClassRenderer = (String) page.findAttribute(sDomain);
         }
         if (sClassRenderer == null && session != null)
         {
            // When called from servlet, only the session is available
            sClassRenderer = (String) session.getAttribute(sDomain);
         }
      }

      return sClassRenderer;
   }
   
   public String getFieldRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef, String renderKey)
   {
      String  sClassRenderer;
      
      sClassRenderer = getContextFieldRendererClassName(page, session, attrDef, renderKey);
      
      // If not defined yet, use the default
      if (sClassRenderer == null)
      {
         sClassRenderer = getDefaultFieldRendererClassName(attrDef, renderKey);
      }

      return sClassRenderer;
   }
   
   public String getEditRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef)
   {
      return getFieldRendererClassName(page, session, attrDef, HtmlServices.EDIT_RENDERER_KEY);
   }
   
   public String getDisplayRendererClassName(PageContext page, HttpSession session, AttributeDef attrDef)
   {
      return getFieldRendererClassName(page, session, attrDef, HtmlServices.DISP_RENDERER_KEY);
   }

   public String getDefaultFieldRendererClassName(AttributeDef attrDef, String renderKey)
   {
      if (HtmlServices.EDIT_RENDERER_KEY.equals(renderKey))
      {
         return getDefaultEditRendererClassName(attrDef);
      }
      else
      {
         return getDefaultDisplayRendererClassName(attrDef);
      }
   }
   
   protected boolean isReadOnly(AttributeDef attrDef)
   {
      if (getRowSet() != null && getRowSet().getViewObject() != null)  
         return getRowSet().getViewObject().isReadOnly();
      return attrDef.getUpdateableFlag() == AttributeDef.READONLY;
   }
   
   public String getDefaultEditRendererClassName(AttributeDef attrDef)
   {
      // check if it's read-only, if the view is read-only then every field is read-only
      if (isReadOnly(attrDef))
      {
         return ReadOnlyField.class.getName();
      }
      else if (attrDef.getSQLType() == Types.STRUCT)
      {
         return "oracle.jdeveloper.html.StructField";
      }
      else if (attrDef.getSQLType() == Types.ARRAY)
      {
         return "oracle.jdeveloper.html.ArrayField";
      }
      else if (JboTypeMap.isDateType(attrDef.getSQLType()))
      {
         return DateField.class.getName();
      }
      else if (attrDef.getPrecision() > 30)
      {
         return TextArea.class.getName();
      }
      else
      {
         return TextField.class.getName();
      }
   }
   
   public String getDefaultDisplayRendererClassName(AttributeDef attrDef)
   {
      if (attrDef.getSQLType() == Types.ARRAY)
      {
         return "oracle.jdeveloper.html.DisplayArrayField";
      }
      else
      {
         return ReadOnlyField.class.getName();
      }
   }
   
   public boolean hasFieldRenderer(PageContext page, Row row, AttributeDef attrDef, String renderKey)
   {
      // check for instance-level renderer first
      int index = HtmlServices.EDIT_RENDERER_KEY.equals(renderKey) ? 1 : 0;
      HTMLFieldRenderer rField = getAttributeRenderers()[index][attrDef.getIndex()];
      
      if (rField != null)
      {
         return true;
      }

      String sClassRenderer = getContextFieldRendererClassName(page, page.getSession(), attrDef, renderKey);
      
      // If a class is defined, instanciate it and initialize the renderer
      if (sClassRenderer != null)
      {
         return true;
      }

      return false;
   }
   
   private HTMLFieldRenderer getFieldRenderer(PageContext page, HttpSession session, Row row, AttributeDef attrDef, String renderKey)
   {
      // check for instance-level renderer first
      int index = HtmlServices.EDIT_RENDERER_KEY.equals(renderKey) ? 1 : 0;
      HTMLFieldRenderer rField = getAttributeRenderers()[index][attrDef.getIndex()];
      
      if (rField != null)
      {
         return rField;
      }

      String sClassRenderer = getContextFieldRendererClassName(page, session, attrDef, renderKey);
      
      // If not defined yet, use the default
      if (sClassRenderer == null)
      {
         // If the default has not been overwritten, apply the Updateable rule for the edit render field
         if (index == 1 && row != null && !row.isAttributeUpdateable(attrDef.getIndex()))
         {
            sClassRenderer =  ReadOnlyField.class.getName();
         }
         else
         {
            sClassRenderer = getDefaultFieldRendererClassName(attrDef, renderKey);
         }
      }
      
      // If a class is defined, instanciate it and initialize the renderer
      if (sClassRenderer != null)
      {
         rField = HtmlServices.getFieldRendererFromClassName(sClassRenderer, page);
         
         rField.setDatasource(this);
         rField.setAttributeDef(attrDef);
            
         // Store the new instance of the field renderer in the cache
         getAttributeRenderers()[index][attrDef.getIndex()] = rField;
      }

      return rField;
   }
   
   /**
    * Convenient method with the pageContext without the session to be use by tags
    */
   public HTMLFieldRenderer getEditFieldRenderer(PageContext page, Row row, AttributeDef attrDef)
   {
      return getEditFieldRenderer(page, page.getSession(), row, attrDef);
   }
   
   /**
    * Retrieves the default field renderer for a specified attribute definition
    * (that is, the attribute metadata).
    * <p>
    * @param attrDef an attribute definition.
    * @return default field renderer for the attribute definition.
    */
   public HTMLFieldRenderer getEditFieldRenderer(PageContext page, HttpSession session, Row row, AttributeDef attrDef)
   {
      HTMLFieldRenderer rField;

      rField = getFieldRenderer(page, session, row, attrDef, HtmlServices.EDIT_RENDERER_KEY);

      rField.setValue(null); // Reset value otherwise it will never take the new one
      rField.setPageContext(page);

      return rField;
   }

   public HTMLFieldRenderer getDisplayFieldRenderer(PageContext page, Row row, AttributeDef attrDef)
   {
      return getDisplayFieldRenderer(page, page.getSession(), row, attrDef);
   }
   
   /**
   * Retrieves the default field renderer for a specified attribute definition
   * (that is, the attribute metadata).
   * <p>
   * @param attrDef an attribute definition.
   * @return default field renderer for the attribute definition.
   */
   public HTMLFieldRenderer getDisplayFieldRenderer(PageContext page, HttpSession session, Row row, AttributeDef attrDef)
   {
      HTMLFieldRenderer rField;

      rField = getFieldRenderer(page, session, row, attrDef, HtmlServices.DISP_RENDERER_KEY);
      
      rField.setPageContext(page);
      rField.setValue(null); // Reset value otherwise it will never take the new one
      rField.setDisplayHeight(10);

      return rField;
   }

   // Every setter goes throu here
   public void setFieldRenderer(int nIndex, HTMLFieldRenderer rdr, String renderKey)
   {
      getAttributeRenderers()[HtmlServices.EDIT_RENDERER_KEY.equals(renderKey) ? 1 : 0][nIndex] = rdr;
   }
   
   /**
   **  Assigns an instance-level display field renderer to be used in the DataWebBean
   **/
   public void setDisplayFieldRenderer(AttributeDef attrDef, HTMLFieldRenderer rdr)
   {
      setFieldRenderer(attrDef.getIndex(), rdr, HtmlServices.DISP_RENDERER_KEY);
   }

   /**
   **  Assigns an instance-level edit field renderer to be used in the DataWebBean
   **/
   public void setEditFieldRenderer(AttributeDef attrDef, HTMLFieldRenderer rdr)
   {
      setFieldRenderer(attrDef.getIndex(), rdr, HtmlServices.EDIT_RENDERER_KEY);
   }

   /**
   **  Assigns an instance-level display field renderer to be used in the DataWebBean
   **/
   public void setDisplayFieldRenderer(int nIndex, HTMLFieldRenderer rdr)
   {
      setFieldRenderer(nIndex, rdr, HtmlServices.DISP_RENDERER_KEY);
   }

   /**
   **  Assigns an instance-level edit field renderer to be used in the DataWebBean
   **/
   public void setEditFieldRenderer(int nIndex, HTMLFieldRenderer rdr)
   {
      setFieldRenderer(nIndex, rdr, HtmlServices.EDIT_RENDERER_KEY);
   }

   public boolean shouldDisplayAttribute(AttributeDef attrDef)
   {
      LocaleContext  locale = getLocaleContext();
      return JboUtil.isAttributeDisplayable(attrDef, locale);
   }

   public String getAttributeLabel(String sAttribute)
   {
      return JboUtil.getAttributeLabel(this.getRowSet(), getRowSet().getViewObject().findAttributeDef(sAttribute));
   }
   
   public String getAttributeLabel(AttributeDef aDef)
   {
      return JboUtil.getAttributeLabel(this.getRowSet(), aDef);
   }
   
   /**
   ** @deprecated  Deprecated since 9.0.3.  Instead, use JboUtil.getAttributeLabel(RowSet rs, AttributeDef attrDef).
   **/
   static final public String getAttributeLabel(RowSet rs, AttributeDef aDef)
   {
      return JboUtil.getAttributeLabel(rs, aDef);
   }

   public Row getRowFromKey(String sKey)
   {
      return JboUtil.getRowFromKey(this.getRowSet(), sKey);
   }

   /**
   ** Determines if the view object has any queryable fields
   **/
   public boolean isQueryable()
   {
      boolean        bRet = false;
      AttributeDef   []attributes = getRowSet().getViewObject().getAttributeDefs();

      for(int i = 0; i < attributes.length; i++)
      {
         if(attributes[i].isQueriable())
         {
            bRet = true;
            break;
         }
      }

      return bRet;
   }
   
   public void synchronize()
   {
      getApplicationModule().sync();
   }
}
