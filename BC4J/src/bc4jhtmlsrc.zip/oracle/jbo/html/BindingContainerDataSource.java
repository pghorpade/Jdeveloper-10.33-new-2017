package oracle.jbo.html;

import javax.servlet.http.HttpServletRequest;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.jbo.ApplicationModule;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.uicli.binding.JUControlBinding;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jdeveloper.html.HTMLFieldRenderer;
import oracle.jbo.LocaleContext;
import oracle.jbo.RowSet;

public class BindingContainerDataSource extends DataSourceImpl
{
   DCBindingContainer  _container;
   DCIteratorBinding   _iterator;
   JUControlBinding    _binding;
   
   public BindingContainerDataSource(HttpServletRequest request, 
                              DCBindingContainer container,
                              JUControlBinding binding
               )
   {
      super(null);
      
      setRequest(request);
      
      _container = container;
      _iterator = binding.getIteratorBinding();
      _binding = binding;
      
      if(_iterator == null)
        return;
        
      if(_iterator.getAttributeDefs() != null)
        setAttributeRenderers("jbo_" + _iterator.getName() , new HTMLFieldRenderer[2][_iterator.getAttributeDefs().length]);

      if(_iterator.getDataControl() != null)
         setApplicationId(_iterator.getDataControl().getName());
      else
         setApplicationId(container.getName());
      
      if(_iterator.getRowSetIterator() != null)
        setRowSet(_iterator.getRowSetIterator().getRowSet());
   }

    public boolean isBindingContainerDataSource()
    {
       return true;
    }
    
   public ApplicationModule getApplicationModule()
   {
      if(_binding != null)
         return _binding.getApplicationModule();
      return super.getApplicationModule();
   }
   
   public String getAttributeLabel(String sAttribute)
   {
      if(_binding != null && _binding instanceof JUCtrlValueBinding)
      {
         JUCtrlValueBinding binding = (JUCtrlValueBinding)_binding;
         return (String)binding.getLabels().get(sAttribute);
      }
      return super.getAttributeLabel(sAttribute);
   }
   
   public String getAttributeLabel(AttributeDef aDef)
   {
      if(_binding != null && _binding instanceof JUCtrlValueBinding)
      {
         JUCtrlValueBinding binding = (JUCtrlValueBinding)_binding;
         return (String)binding.getLabels().get(aDef.getName());
      }
      return super.getAttributeLabel(aDef);
   }
   
   protected boolean isReadOnly(AttributeDef attrDef)
   {
      if(_binding != null && _binding instanceof JUCtrlValueBinding)
      {
         JUCtrlValueBinding binding = (JUCtrlValueBinding)_binding;
         if(binding.isAttributeUpdateable(binding.getAttributeIndexOf(attrDef.getName())))
            return false;
         else
            return true;
      }
      return super.isReadOnly(attrDef);
   }
   
   public Row getRowFromKey(String sKey)
   {
      if(_binding != null)
      {
         oracle.jbo.RowIterator rsi = _binding.getIteratorBinding().getNavigatableRowIterator();
         Row rows[] = rsi.findByKey(_binding.getIteratorBinding().createKey(sKey), 1);
         if (rows.length == 1)
         {
            return rows[0];
         }
      }
      return super.getRowFromKey(sKey);
   }
   
   public boolean isQueryable()
   {
      boolean        bRet = false;
      AttributeDef   []attributes = _binding.getIteratorBinding().getAttributeDefs();

      for(int i = 0; i < attributes.length; i++)
      {
         if(attributes[i].isQueriable())
         {
            bRet = true;
            break;
         }
      }

      return bRet;
   }
   public LocaleContext getLocaleContext()
   {
     return _container.getLocaleContext();
   }

   public JUControlBinding getControlBinding()
   {
      return _binding;   
   }
   
   public RowSet getRowSet()
   {
      if(_iterator == null)
        return null;
        
      return _iterator.getRowSetIterator().getRowSet();
   }
   
   public void synchronize()
   {
      if(_container != null)
         _container.refreshControl();
   }
}