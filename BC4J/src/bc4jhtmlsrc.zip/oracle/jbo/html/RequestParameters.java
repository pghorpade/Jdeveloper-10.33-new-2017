/*
 * @(#)RequestParameters.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.html;

import javax.servlet.jsp.PageContext;

public abstract class RequestParameters
{
   protected PageContext pageContext;

   public void setPageContext(PageContext page)
   {
      pageContext = page;
   }
   
   /**
    * This method is implemented differently depending on
    * the type of the request (HttpServletRequest or OrdHttpUploadRequest)
    */
   abstract protected String getParameterFromRequest(String param);

   public String getParameter(String param)
   {
      String value = getParameterFromRequest(param);

      if (value == null && pageContext != null)
      {
         value = pageContext.getRequest().getParameter(param);
      }
      
      return value;
   }
}
