/*
 * @(#)DefaultNumberFormatter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.DefLocaleContext;

/**
 **  Helper class used to format Decimal numbers.
 **
 **  @version SDK
 */
public class DefaultNumberFormatter
    extends Formatter
{
    /**
    **  the Locale we are currently using
    **/
    private LocaleContext _theLocale = new DefLocaleContext();
    private DecimalFormatSymbols mSymbols = new DecimalFormatSymbols(
       _theLocale.getLocale());

    /**
    *  Heleper object to which we delegate all our work
    */
    // JRS Don't cache the DecimalFormat helper.  This Formatter may be
    // shared and the DecimalFormatter cannot handle contention.
    // private DecimalFormat _theDecimalFormatHelper =
    //    new DecimalFormat("", new DecimalFormatSymbols(_theLocale.getLocale()));
    // empty pattern string to start with

    /**
    * Constructor
    */
    public DefaultNumberFormatter()
    {
        
    }

    private DecimalFormat getDecimalFormat()
    {
       return new DecimalFormat("", mSymbols);
    }
 
    /**
    ** format raw data according to the format specified. <P>
    **
    ** Data is formatted per the 'format string' passed as an argument to this
    ** function.
    **
    ** @return formatted string
    ** @param formatString code to define how the raw data should be formatted.
    ** @param rawData  data which needs to be formatted.
    ** @exception FormatErrorException if unable to format the data according
    **            to the format specified.
    */
    public String format(String formatString, Object rawData)
        throws FormatErrorException
    {
        Double formatThis;
        String formattedString = "";
        
        if  ( formatString.compareTo("") == 0)
        {
            formatString = " ";
        }
        DecimalFormat decimalFormat = getDecimalFormat();
        decimalFormat.applyPattern(formatString);
        if (rawData != null)
        {
            if (rawData instanceof Double) 
            {
                formatThis = (Double)rawData;
            }
            else if (rawData instanceof BigDecimal)
            {
                formatThis = new Double( ((BigDecimal)rawData).doubleValue());
            }
            else
            {
                formatThis = new Double(rawData.toString());
            }
	    formattedString = decimalFormat.format(formatThis);
        }
        return(formattedString);
    }

    /**
    **  parse this string according to the format specified.
    **
    ** @return object which represents the string parsed.
    ** @param formatString code to define how the raw data should be parsed.
    ** @param parseThisString data which needs to be parsed.
    ** @exception java.text.ParseException when unable to parse data according
    **            to the format specified.
    */
    public Object parse(String formatString, String parseThisString)
        throws ParseException
    {
        if  ( formatString.compareTo("") == 0)
            formatString = " ";

        DecimalFormat format = getDecimalFormat();
        format.applyPattern(formatString);
        return (format.parse(parseThisString,
                                              new ParsePosition(0)));
    }

    /**
    **  define locale to be used.
    **  Formatter will need to make locale specific formatting if applicable
    **  @param thisLocale locale to be used
    **  @exception UnknownLocaleException if the formatter does'nt support the
    **  specified Locale.
    */
    public void setLocale(LocaleContext thisLocale)
        throws UnknownLocaleException
    {
       if(thisLocale == null)
       {
          return;
       }

       if ( _theLocale != thisLocale)
       {
          _theLocale = thisLocale;
          mSymbols = new DecimalFormatSymbols(_theLocale.getLocale());
       }
    }

    /**
    **  @return Locale currently in use
    */
    public LocaleContext getLocale()
    {
        return _theLocale;
    }

    /**
    **  @return object which represents the string parsed
    **  @param  formatThisString data which needs to be parsed
    **  @param  status parse to start from this position
    */
    public Object parseObject(String formatThisString, ParsePosition status)
    {
        return(getDecimalFormat().parseObject(formatThisString, status ));
    }

    /**
    ** @return formatted string
    ** @param obj object which needs to be formatted
    ** @param toAppendTo appended formatted string here
    ** @param pos additional information about the formatting performed. see 
    ** java.text.FieldPosition for more information
    */
    public StringBuffer format(Object obj, StringBuffer toAppendTo,
                               FieldPosition pos)
    {
        return(getDecimalFormat().format(obj, toAppendTo, pos));
    }

}
