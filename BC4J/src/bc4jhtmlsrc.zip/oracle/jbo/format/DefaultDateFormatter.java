/*
 * @(#)DefaultDateFormatter.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.format;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import oracle.jbo.LocaleContext;
import oracle.jbo.common.DefLocaleContext;
import java.util.Calendar;

/**
 **  Formatter class used to format date values.
 **
 **  @version SDK
 **/
public class DefaultDateFormatter extends Formatter
{
   /**
   *  The locale we are currently using
   */
   private LocaleContext _theLocale = new DefLocaleContext();

   /**
   *  Heleper object to which we delegate all our work
   */
   private SimpleDateFormat _theSimpleDateFormatHelper =
                             new SimpleDateFormat("", _theLocale.getLocale());
                             // empty pattern string to start with

   /**
   * Default format string
   */
   private String _defaultFormatString ; // for people who don't supply a
                                         // format string

   /**
   *  Constructor
   */
   public DefaultDateFormatter()
   {
        _defaultFormatString  = _theSimpleDateFormatHelper.toPattern();
        _theSimpleDateFormatHelper.getCalendar().setLenient(false);
        _theSimpleDateFormatHelper.setLenient(false);
   }

   /**
   ** format raw data according to the format specified. <P>
   **
   ** Data is formatted per the 'format string' passed as an argument to this
   ** function.
   **
   ** @return formatted string
   ** @param formatString code to define how the raw data should be formatted.
   ** @param rawData  data which needs to be formatted.
   ** @exception FormatErrorException if unable to format the data according to
   ** the format specified.
   */

   public String format(String formatString, Object rawData)
             throws FormatErrorException
   {
       _theSimpleDateFormatHelper.setLenient(false);
       _theSimpleDateFormatHelper.applyPattern(formatString);
       if ( rawData instanceof oracle.jbo.domain.Date )
       {
          // zw: aug2005, bug3958528 changed to timestampValue
          return _theSimpleDateFormatHelper.format(((oracle.jbo.domain.Date)rawData).timestampValue());
       }
       else if ( rawData instanceof oracle.jbo.domain.Timestamp)
       {
          Object ts = _convertJboDomainToTimestamp((oracle.jbo.domain.Timestamp)rawData);
          
          return _theSimpleDateFormatHelper.format(ts); 
       }
       else
       {
          return _theSimpleDateFormatHelper.format(rawData);
       }
   }

   /**
   **  parse this string according to the format specified and return an object
   **
   ** @return object which represents the string parsed.
   ** @param formatString code to define how the raw data should be parsed.
   ** @param parseThisString data which needs to be parsed.
   ** @exception java.text.ParseException when unable to parse data according to
   ** the format specified.
   */

        public Object parse(String formatString, String parseThisString)
                throws ParseException
   {
       _theSimpleDateFormatHelper.setLenient(false);
       _theSimpleDateFormatHelper.applyPattern(formatString);

       Object formattedObj =  _theSimpleDateFormatHelper.parse(
              parseThisString, new ParsePosition(0));
       if ( formattedObj != null )
       {
            if (formattedObj instanceof Timestamp)
              return formattedObj;
              
            if (formattedObj instanceof Date)
              return _DateToTimestamp((Date)formattedObj);
       }
       else
           throw new ParseException("parse failed", 0);
           
      return null;
   }

   /**
   **  define locale to be used.
   **  Formatter will need to make locale specific formatting if applicable
   **  @param thisLocale locale to be used
   **  @exception UnknownLocaleException if the formatter does'nt support the
   **  specified Locale.
   */

   public void setLocale(LocaleContext thisLocale)
         throws UnknownLocaleException
   {
        if (_theLocale != thisLocale && thisLocale != null)
        {
           _theSimpleDateFormatHelper.setDateFormatSymbols(new DateFormatSymbols(thisLocale.getLocale()));
           _theSimpleDateFormatHelper.setCalendar(Calendar.getInstance(thisLocale.getLocale()));
           _theLocale = thisLocale;
         }
   }

   /**
   **  @return Locale currently in use
   **/

   public LocaleContext getLocale()
   {
        return _theLocale;
   }

   /**
   **  @return object which represents the string parsed
   **  @param  parseThisString data which needs to be parsed
   **  @param  status parse to start from this position
   **/

   public Object parseObject(String parseThisString, ParsePosition status)
   {
      _theSimpleDateFormatHelper.setLenient(false);
       Object formattedObj =  _theSimpleDateFormatHelper.parseObject
                                  (parseThisString, status );
           
       if ( formattedObj != null )
       {
          if (formattedObj instanceof java.sql.Timestamp)
             return formattedObj;
          
          if (formattedObj instanceof Date)
           return _DateToTimestamp((Date)formattedObj);
       }

       return null;
   }

   /**
   ** @return formatted string
   ** @param obj object which needs to be formatted
   ** @param toAppendTo appended formatted string here
   ** @param pos additional information about the formatting performed. see
   ** java.text.FieldPosition for more information
   **/

   public StringBuffer format(Object obj, StringBuffer toAppendTo,
                       FieldPosition pos)
   {
       _theSimpleDateFormatHelper.setLenient(false);
       if ( obj instanceof oracle.jbo.domain.Date)
       {
          // zw: aug2005, bug3958528 changed to timestampValue
          return _theSimpleDateFormatHelper.format(
                 ((oracle.jbo.domain.Date)obj).timestampValue(),toAppendTo, pos);
       }
       else if ( obj instanceof oracle.jbo.domain.Timestamp)
       {
          Object ts = _convertJboDomainToTimestamp((oracle.jbo.domain.Timestamp)obj);
          
          return _theSimpleDateFormatHelper.format(ts, toAppendTo, pos); 
       }
       else
       {
          return _theSimpleDateFormatHelper.format(obj, toAppendTo, pos);
       }
   }

   private Timestamp _DateToTimestamp(Date dateObj)
   {
      if ( dateObj != null )
      {
         Calendar calendar = _theSimpleDateFormatHelper.getCalendar();
         calendar.setTime(dateObj);
         Timestamp timeStampObject =  new Timestamp(dateObj.getTime());
         return  timeStampObject;
      }
      return null;
   }
   
   private Object _convertJboDomainToTimestamp(oracle.jbo.domain.Timestamp ts)
   {
     try
     {
        return ts.dateValue();
     }
     catch(SQLException exc)
     {
       throw new RuntimeException(exc);
     }
     
   }

   public String getDefaultFormatString()
   {
      return "yyyy-MM-dd";
   }
}
