package oracle.jbo.format;

import oracle.jbo.LocaleContext;
import oracle.jbo.JboException;

import oracle.jbo.common.JBOClass;
import oracle.jbo.common.JboNameUtil;

import java.util.Hashtable;

/**
 * A singleton factory for formatters.
 */
public class FormatterFactory
{
   private static Hashtable mFormatters = new Hashtable(8);

   /**
    * Returns the singleton formatter for the formatter class name that has
    * been specified.  Please note that formatters may be locale sensitive.
    *
    * @param formatterClassName the class name of the formatter.
    * @param locale the locale for which this formatter will be used.
    *
    * @return a singleton formatter instance
    */
   public static Formatter getFormatter(String formatterClassName, LocaleContext locale)
   {
      String localeClassName = JboNameUtil.getLocaleName(
         locale, formatterClassName);

      Formatter formatter = (Formatter)mFormatters.get(localeClassName);

      if (formatter == null)
      {      
         Class     clz = JBOClass.findCustomClass(
            formatterClassName, Formatter.class);

         formatter = (Formatter)JBOClass.newInstance(clz);

         try
         {
            formatter.setLocale(locale);
         }
         catch(Exception e)
         {
            throw new JboException(e);
         }

         mFormatters.put(localeClassName, formatter);
      }
      
      return formatter; 
   }
}
