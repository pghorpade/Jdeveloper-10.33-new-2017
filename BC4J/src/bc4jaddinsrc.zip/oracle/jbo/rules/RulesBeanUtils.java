/*
 * @(#)RulesBeanUtils.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import com.sun.java.util.collections.ArrayList;
import java.util.Iterator;
import java.beans.BeanInfo;
import java.beans.Introspector;
import oracle.jbo.AttrValException;
import oracle.jbo.AttrSetValException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowValException;
import oracle.jbo.ValidationException;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;
import oracle.jbo.mom.xml.DefElement;
import oracle.jbo.mom.xml.JTXMLTags;
import oracle.jbo.rules.JboValidatorInterface;
import oracle.jbo.rules.AbstractValidator;
import oracle.jbo.mom.PropertyNameValueDef;

/**
 * <b>Internal:</b> <em>Applications should not use this class.</em>
 * @since JDevloper 3.0
 */
//class used in generated code to load validation beans in domains.
public class RulesBeanUtils 
{

   static public void loadValidators(DefElement elem, ValidationManager valObj, Class msgBundle)
   {
      ArrayList children = elem.getSimilarChildrenList(JTXMLTags.VALIDATION_BEAN);

      JboValidatorInterface val;
      for ( int i = 0; i < children.size(); i++ )
      {
         val = loadValidationRule((DefElement)children.get(i), msgBundle);
         if (val != null)
         {
            valObj.addValidator(val);
         }
      }
   }
   
   public static JboValidatorInterface loadValidatorBean(DefElement elem)
   {

     JboValidatorInterface val = null;
     try
     { 
        val = createNewValidatorInstance(elem);
     }
     catch (JboException je)
     {
        throw je;
     }
     catch (Exception e)
     {
        throw new JboException(e);
     }
     
     if ( !(val instanceof AbstractValidator) && val != null)
     {
         val = createUserValidator(val);       
     }
     return val;
   }

   //The following method is also being used by kava.
   public static JboValidatorInterface createUserValidator(JboValidatorInterface val)
   {
        //create a user validator to wrap around this
        //user supplied validation bean so that we can
        //pass proper attribute values in case the
        //validator is attached on an entity level and
        //is applied on an attribute i.e., has to validate
        //an attribute value during entity level validation.

        //wow, internal classes are so effective!
        class JboUserValidator extends AbstractValidator
                               implements JboValidatorInterface {
           JboValidatorInterface mBean;
           JboUserValidator( JboValidatorInterface bean )
           {
              mBean = bean;
           }

           public void validate(JboValidatorContext ctx) 
           {
               try
               {
                   mBean.validate(ctx);
               }
               catch (AttrValException ave)
               {
                   throw ave;
               }
               catch (Exception e)
               {
                   RulesBeanUtils.raiseException(getErrorMessageClass(),
                                                 getErrorMsgId(),
                                                 ctx.getSource(),
                                                 ctx.getSourceType(),
                                                 ctx.getSourceFullName(),
                                                 ctx.getAttributeDef(),
                                                 ctx.getNewValue(),
                                                 null, e);
               }
           }

           public boolean validateValue(Object val)
           {
              return false;
           }

           public String getDescription()
           {
              return mBean.getDescription();
           }

           public void setDescription( String description)
           {
              mBean.setDescription(description);
           }

           /*
           public void vetoableChange(PropertyChangeEvent evObj)
           {
              try {
                 mBean.vetoableChange(evObj);
              }
              catch( JboException ve )
              {
                 throw ve;
              }
              catch( Exception e )
              {
                 String errorCode = (evObj.getSource() instanceof Row) ?
                                       CSMessageBundle.EXC_VAL_ENTITY_VALIDATE_FAILED :
                                       CSMessageBundle.EXC_VAL_ATTR_SET_FAILED;

                 RulesBeanUtils.raiseException(CSMessageBundle.class,
                                errorCode,
                                evObj.getSource(),
                                evObj.getPropertyName(),
                                evObj.getNewValue(),
                                null, e);
              }
           }
           */
        }
        return new JboUserValidator(val);       
   }
   
   static private JboValidatorInterface createNewValidatorInstance(DefElement xmlElement) 
           throws Exception
   {
      Class valClass = JBOClass.forName(xmlElement.readString("ValidationBeanClass"));
      JboValidatorInterface val = (JboValidatorInterface)valClass.newInstance();
      BeanInfo beanInfo = Introspector.getBeanInfo(valClass);

      //if DefPersitable load via interface.
      ArrayList v= xmlElement.getChildrenList(JTXMLTags.NAMED_DATA);
      PropertyNameValueDef  jnd;
      if ( (v != null) )
      {

         for ( int i=0; i < v.size(); i++ )
         {
            //create * load named data.
            jnd = new PropertyNameValueDef();
            jnd.loadFromXMLFile((DefElement)v.get(i));

            //use nameddata to set loaded property into bean
            jnd.setBeanProperty(beanInfo, val);
         }
      }
      return val;
   }

   public static void raiseException(
                         Class resBundleClass,
                         String errorCode,
                         Object source,
                         int    objType,
                         String objName,
                         oracle.jbo.AttributeDef attr,
                         Object newVal,
                         String methodName,
                         Exception detail)
   {
      ValidationException valEx;
      if (newVal instanceof Row)
      {
         valEx = new RowValException(resBundleClass,
                                     errorCode, objName,
                                     ((Row) newVal).getKey(), 
                                     null, methodName);
      }
      else
      {
         AttrSetValException jboEx = new AttrSetValException(objType,
                                          resBundleClass,
                                          errorCode,
                                          objName,
                                          attr.getName(),
                                          newVal,
                                          methodName);
         if (source instanceof Row) 
         {
            jboEx.setRowKey(objType, ((Row) source).getKey());
         }
         valEx = jboEx;
      }

      if (oracle.jbo.common.JboResourceBundle.class.isAssignableFrom(resBundleClass)) 
      {
         valEx.setAppendCodes(false);
      }

      if (detail != null)
      {
         valEx.addToDetails(detail);
      }

      throw valEx;
   }

   public static JboValidatorInterface loadValidationRule(DefElement elem, Class errorMessageClz)
   {
      JboValidatorInterface aValidator = null;
      String type = elem.getElementName();
      String rhsType = elem.readString("OperandType");
      boolean bInverse = elem.readBoolean("Inverse");
      String attrName = elem.readString("OnAttribute");

      // Compare Validator Type >, < , == 
      if (JTXMLTags.COMPARE_VALIDATOR.equals(type))
      {
         String rValue = elem.readString("CompareValue");
         String opType = elem.readString("CompareType");
         int oprType = JboCompareValidator.convertOperType(opType);

         if ( rhsType.equals("LITERAL") )
         {
            aValidator = new JboCompareValidator(bInverse, oprType, rValue);
         }
         else if ( rhsType.equals("SQL") )
         {
            throw new java.lang.UnsupportedOperationException("SQL Validator");
            //aValidator = new JboSQLCompareValidator(bInverse, oprType, this, rValue);
         }
         else if ( rhsType.equals("JBO") )
         {
            throw new java.lang.UnsupportedOperationException("VO Validator");
            //aValidator = new JboVOCompareValidator(bInverse, oprType, this, rValue);
         }
      }
      // Range validator < > 
      else if ( JTXMLTags.RANGE_VALIDATOR.equals(type) )
      {
         String minVal = elem.readString("MinValue");
         String maxVal = elem.readString("MaxValue");
         aValidator = new JboRangeValidator(bInverse, minVal, maxVal);
      }
      // List Validator 
      else if ( JTXMLTags.LIST_VALIDATOR.equals(type) )
      {
         if ( rhsType.equals("LITERAL") )
         {
            //valid use of vector till listvalidator has a constructor
            //for arraylist.
            java.util.Vector vec = elem.readStringArray("List");
            if (vec != null)
            {
               aValidator = new JboListValidator(bInverse, vec);
            }            
         }
         else if ( rhsType.equals("SQL") )
         {
            throw new java.lang.UnsupportedOperationException("SQL Validator");
            //aValidator = new JboSQLListValidator(bInverse, this, elem.readString("ListValue"));
         }
         else if ( rhsType.equals("JBO") )
         {
            throw new java.lang.UnsupportedOperationException("VO Validator");
            //aValidator = new JboVOListValidator(bInverse, this, elem.readString("ListValue"));
         }
      }
      else if (JTXMLTags.LENGTH_VALIDATOR.equals(type))
      {
         String opType = elem.readString("CompareType");
         int operType = JboLengthValidator.convertOperType(opType);
         String dType = elem.readString("DataType");
         int dataType = JboLengthValidator.convertDataType(dType);
         String val =   elem.readString("CompareLength");
         aValidator = new JboLengthValidator(bInverse, operType, dataType, val);
      }
      else if ( JTXMLTags.REGEXP_VALIDATOR.equals(type) )
      {
         String pattern = elem.readString("Pattern");
         String flags = elem.readString("Flags");
         aValidator = new JboRegExpValidator(bInverse, pattern, flags);
      }
      else if ( JTXMLTags.VALIDATION_BEAN.equals(type) )
      {
         aValidator = RulesBeanUtils.loadValidatorBean(elem);
      }

      if (aValidator == null) 
      {

         if (Diagnostic.isOn())
         {
            Diagnostic.println("No validator loaded for :"+type);
         }
      }

      rhsType = elem.readString("ResId");
      if (rhsType != null) 
      {
         if (aValidator instanceof AbstractValidator) 
         {
            ((AbstractValidator)aValidator).setErrorMsgId(rhsType);
            ((AbstractValidator)aValidator).setErrorMessageClass(errorMessageClz);
         }
         else
         {
            if (Diagnostic.isOn()) 
            {
               Diagnostic.println("Validation Error message unused :"+rhsType);
            }
         }
      }
      if (aValidator instanceof AbstractValidator) 
      {
        ((AbstractValidator)aValidator).setValidatingAttributeName(attrName);
      }
      return aValidator;
   }

   /**
    * Validate the new value by applying all the validator rules
    * applied to this attribute.
    * @exception ValidationException if an exception occurs during
    * validation of the new value for this attribute.
    */
   public static AttrValException validate(Iterator validators, Row row, JboValidatorContext ev, boolean notDeferred)
   {
      AttrValException ex = validateObject(validators, ev, notDeferred);
      if (ex != null) 
      {
         ex.setRowKey(ev.getSourceType(), row.getKey());
      }
      return ex;
   }


   public static AttrValException validateObject(Iterator validators, JboValidatorContext ev, boolean notDeferred)
   {
      //in client-binding-validation case, we are always in deferred mode
      ArrayList al = null;
      if (notDeferred)
      {
         while (validators.hasNext())
         {
            ((JboValidatorInterface)(validators.next())).validate(ev);
         }
      }
      else
      {
         while (validators.hasNext())
         {
            try
            {
               ((JboValidatorInterface)(validators.next())).validate(ev);
            }
            catch (JboException e)
            {
               if (al == null) 
               {
                  al = new ArrayList(5);
               }
               al.add(e);
            }
         }

         if (al != null) 
         {
            if(al.size() == 1) 
            {
               Object ex = al.get(0);
               if(ex instanceof AttrValException) 
               {
                  return (AttrValException)ex;
               }
            }
            AttrValException jboEx = new AttrValException(
                                       CSMessageBundle.class, 
                                       CSMessageBundle.EXC_DEF_ATTR_VAL_EXCEPTION,
                                       ev.getSourceFullName(), 
                                       ev.getAttributeName(), 
                                       ev.getNewValue(), 
                                       al,
                                       true);
            return jboEx;
         }
      }
      return null;
   }

}
