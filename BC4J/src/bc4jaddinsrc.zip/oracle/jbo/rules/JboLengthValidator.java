/*
 * @(#)JboLengthValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import oracle.jbo.CSMessageBundle;

/**
 * A validator that tests the length of the attribute values by comparing
 * them with a pre-defined length value.
 * <p>
 * The length to be validated is designated as the left-hand operand of a
 * relation operation.  The validator provides the right-hand operand, the
 * comparison datatype and the relation operator.
 * @since Jdeveloper 3.0
 */
public class JboLengthValidator extends JboAbstractValidator
                                 implements JboValidatorInterface 
{
    static public final int EQUALTO = 0;
    static public final int LESSTHAN = 1;
    static public final int GREATERTHAN = 2;
    static public final int LESSTHANEQUALTO = 3;
    static public final int GREATERTHANEQUALTO = 4;
    protected int mOperType;

    static public final int CHARACTER = 0;
    static public final int BYTE = 1;
    protected int mDataType;
    
    protected Object rhsValue;

    protected void initialize(JboValidatorContext evObj)
    {
        super.initialize(evObj);
    }

    /**
     * Creates an uninitialized length validator.
     * <p>
     * The methods <code>setOperType()</code> ,<code>setDataType()</code> and <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     **/
    public JboLengthValidator()
    {
        mbInverse = false;
        setOperType(EQUALTO);
        setDataType(CHARACTER);
        setDefaultDescription(CSMessageBundle.STR_VAL_DESC_LENGTH_VALIDATOR );
    }

    /**
     * Creates an initialized length validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     * @param dataType this validator's comparison datatype;
     * one of the datatype constants defined in this class.
     * @param rhsValue  this validator's right-hand operand,
     * a reference object containing a numeric value.
     **/
    public JboLengthValidator(boolean inverse, int operType, int dataType, Object rhsValue)
    {
        mbInverse = inverse;
        setOperType(operType);
        setDataType(dataType);
        setRhsValue(rhsValue);
        setDefaultDescription( CSMessageBundle.STR_VAL_DESC_LENGTH_VALIDATOR );
    }              

    /**
     * Validate an object by comparing its length with 
     * a pre-defined length value.
     * <p>
     * The length of the <code>value</code> parameter is the left-hand
     * operand of this validator's comparison relation.
     * The operator is set by <code>setOperType()</code>
     * and the right-hand operand is the value set by <code>setRhsValue()</code>.
     * <p>
     * This method is called by <code>AbstractValidator#vetoableChange()</code>.
     *
     * @param value the object whose length is to be validated.
     * @return
     * <code>true</code> if the relation holds, or
     * <code>false</code> if the relation does not hold or
     * if the operator or an operand is invalid or uninitialized.
     */
    public boolean validateValue(Object value)
    {

        if (value == null)
        {
            //a true is returned here since it is possible
            //to set a null value in a database table.
            //validator should not return false for that case
            return true;
        }

        String lValue = value.toString();
        int lValueLength = -1;

        switch(mDataType)
        {
            case CHARACTER:
                lValueLength = lValue.length();
                break;
            case BYTE:
                lValueLength = lValue.getBytes().length;
                break;
            default:
                break;
        }        
        
        int rValueLength = Integer.parseInt(getRhsValue().toString());
        
        if(lValueLength != -1)
        {
            switch(mOperType)
            {
                case EQUALTO:
                    return (lValueLength == rValueLength);
                case LESSTHAN:
                    return (lValueLength < rValueLength);
                case GREATERTHAN:
                    return (lValueLength > rValueLength);
                case LESSTHANEQUALTO:
                    return (lValueLength <= rValueLength);
                case GREATERTHANEQUALTO:
                    return (lValueLength >= rValueLength);
                default:
                    break;
            }
        }
        return false;
    }

    /**
     * Sets this validator's comparison operator.
     * @param typeArg one of the comparison operator constants defined in this class.
     */
    public void setOperType(int typeArg)
    {
        mOperType = typeArg;
    }

    /**
     * Gets this validator's comparison operator.
     * @value the comparison operator previously passed to <code>setOperType</code>.
     */
    public int getOperType()
    {
        return mOperType;
    }

    /**
     * Sets this validator's comparison datatype.
     * @param typeArg one of the datatype constants defined in this class.
     */
    public void setDataType(int typeArg)
    {
        mDataType = typeArg;
    }
     
    /**
     * Gets this validator's comparison datatype.
     * @value the comparison datatype previously passed to <code>setDataType</code>.
     */
    public int getDataType()
    {
        return mDataType;
    }

    /**
     * Sets the right-side operand of this validator's expression.
     * @param rhsValueArg  a reference object containing a numeric value.
     */
    public void setRhsValue(Object rhsValueArg)
    {
        rhsValue = rhsValueArg;
    }

    /**
     * Gets the right-side operand of this validator's expression.
     * @value  the operand previously passed to <code>setRhsValue</code>.
     */
    public Object getRhsValue()
    {
        return rhsValue;
    }

    /**
     * <b>Internal:</b> <em>For debugging purposes only.</em>
     * <p>
     */
    public String toString()
    {
        return new String(getDataTypeString() +
                          " Length Compare( "        //NOTRANS
                          + getOperatorTypeString()
                          + rhsValue.toString()
                          +")");                     //NOTRANS
    }

    /**
     * Interprets a string as one of the comparison operator
     * constants defined in this class.
     * @param typeArg a string, the textual name of a comparison operator.
     * @return a comparison operator constant.  An unrecognizable string defaults to
     * <code>EQUALTO</code>.
     */
    public static int convertOperType(String typeArg)
    {
        switch (typeArg.length())
        {
            case 7:
                return EQUALTO;
            case 8:
                return LESSTHAN;
            case 11:
                return GREATERTHAN;
            case 15:
                return LESSTHANEQUALTO;
            case 18:
                return GREATERTHANEQUALTO;
        }
        
        return EQUALTO;
    }

    /**
     * Interprets a string as one of the comparison datatype
     * constants defined in this class.
     * @param typeArg a string, the textual name of a comparison datatype.
     * @return a comparison datatype constant.  An unrecognizable string defaults to
     * <code>CHARACTER</code>.
     */
    public static int convertDataType(String typeArg)
    {
        switch(typeArg.length())
        {
            case 4:
                return BYTE;
            case 9:
                return CHARACTER;
        }
        
        return CHARACTER;
    }

    /**
     * Converts this validator's comparison operator to its symbolic form.
     * @return a comparison symbol.  If the comparison operator is uninitialized
     * or invalid the null string is returned.
     */
    public String getOperatorTypeString()
    {
        String oper = "";   //NOTRANS

        switch(mOperType)
        {
            case EQUALTO:
                oper = " = ";  //NOTRANS
                break;
            case LESSTHAN:
                oper = " < ";  //NOTRANS
                break;
            case GREATERTHAN:
                oper = " > ";  //NOTRANS
                break;
            case LESSTHANEQUALTO:
                oper = " <= ";  //NOTRANS
                break;
            case GREATERTHANEQUALTO:
                oper = " >= ";  //NOTRANS
                break;
            default: 
                break;
        }
        
        return oper;
    }

    /**
     * Converts this validator's comparison datatype to its string form.
     * @return a datatype string.  If the comparison datatype is uninitialized
     * or invalid the null string is returned.
     */
    private String getDataTypeString()
    {
        String dataType = ""; //NOTRANS

        switch(mDataType)
        {
            case BYTE:
                dataType = " Byte "; //NOTRANS
                break;
            case CHARACTER:
                dataType = " Character "; //NOTRANS
                break;
            default: 
                break;
        }
        
        return dataType;
    }
}
