/*
 * @(#)JboCompareValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.domain.DataCreationException;
import oracle.jbo.domain.DomainInterface;
import oracle.jbo.domain.TypeFactory;

/**
 * A validator that tests literal values by comparing them to a pre-defined value,
 * using a pre-defined relation.
 * <p>
 * The value to be validated is designated as the left-hand operand of a
 * relation operation.  The validator provides the right-hand operand and the
 * relation operator.
 * @since Jdeveloper 3.0
 */
public class JboCompareValidator extends JboAbstractValidator
                                 implements JboValidatorInterface 
{
  static public final int EQUALTO = 0;
  static public final int LESSTHAN = 1;
  static public final int GREATERTHAN = 2;
  static public final int LESSTHANEQUALTO = 3;
  static public final int GREATERTHANEQUALTO = 4;
  protected int    mOperType;
  protected Object mRValue;

  protected void initialize(JboValidatorContext evObj)
  {
     super.initialize(evObj);
     mRValue = convertToJava(mValidatingAttr, mRValue);
  }

  
    /**
     * Creates an uninitialized compare validator.
     * <p>
     * The methods <code>setType()</code> and <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     **/
     public JboCompareValidator()
     {
        mbInverse = false;
        setType(EQUALTO);
        setDefaultDescription( CSMessageBundle.STR_VAL_DESC_COMPARE_VALIDATOR );
     }
     
    /**
     * Creates an partially-initialized compare validator.
     * <p>
     * The method <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     * @param inverse  if <code>true</code> the logic of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     **/
     protected JboCompareValidator(boolean inverse, int operType)
     {
        mbInverse = inverse;
        setType(operType);
        setDefaultDescription( CSMessageBundle.STR_VAL_DESC_COMPARE_VALIDATOR );
     }              

    /**
     * Creates an initialized compare validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     * @param rValue  this validator's right-hand operand,
     * a reference object containing a literal value.
     **/
     public JboCompareValidator(boolean inverse, int operType, Object rValue)
     {
        setType(operType);
        mRValue = rValue;
        mbInverse = inverse;
        setDefaultDescription( CSMessageBundle.STR_VAL_DESC_COMPARE_VALIDATOR );
     }              

     /**
       * after setting the new value, prepare the comparator
       * to be of same type if it is not already so.
       */
     protected void setNewValue(Object newValue) throws Exception
     {
        super.setNewValue(newValue);
     }

     /*
       * Based on the operator type, performs appropriate comparision
       * between the value set on receipt of vetoableChange event
       * and a pre-determined/pre-set right-side operand of the
       * expression.
       */
    /**
      * Validate an object by comparing it with a pre-defined value, using
      * a pre-defined relation.
      * <p>
      * The <code>value</code> parameter is the left-hand operand of this
      * validator's comparison relation.
      * The operator is set by <code>setType()</code>
      * and the right-hand operator is set by <code>setRhsValue()</code>.
      * <p>
      * This method is called by <code>AbstractValidator#vetoableChange()</code>.
      *
      * @param value the object to be validated.
      * @return
      * <code>true</code> if the relation holds, or
      * <code>false</code> if the relation does not hold or
      * if the operator or an operand is invalid or uninitialized.
      */
     public boolean validateValue(Object value)
     {
        if (value == null || value.toString().length() == 0)
        {
           return true;
        }

        //get the left Value.
        Variant lVariant = getVariant(value);

        //get types matched.
        // will there be a case when mRValue is null?
        Object rValue = getRhsValue();

        if( rValue != null )
        {
           Object lValue = value;
           if( lValue != null )
           {
              if( rValue.getClass() != lValue.getClass() )
              {
                 try
                 {
                    rValue = TypeFactory.getInstance(lValue.getClass(), rValue);
                 }
                 catch( DataCreationException ex )
                 {
                    return false;
                 }
              }
              
              //rvalue & lvalue are both of same class.
              switch(mOperType)
              {
                 case EQUALTO:
                    return (lVariant.compareTo(getVariant(rValue)) == 0);
                 case LESSTHAN:
                    return (lVariant.compareTo(getVariant(rValue)) < 0);
                 case GREATERTHAN:
                    return (lVariant.compareTo(getVariant(rValue)) > 0);
                 case LESSTHANEQUALTO:
                    return (lVariant.compareTo(getVariant(rValue)) <= 0);
                 case GREATERTHANEQUALTO:
                    return (lVariant.compareTo(getVariant(rValue)) >= 0);
                 default:
                 break;
              }        
           }
        }
        return false;
     }


     /**
      * Sets this validator's comparison operator.
      * @param type one of the comparison operator constants defined in this class.
       */
     public void setType( int type)
     {
        switch(type)
        {
           case EQUALTO:
           case LESSTHAN:
           case GREATERTHAN:
           case LESSTHANEQUALTO:
           case GREATERTHANEQUALTO:
              mOperType = type;
              break;
           default:
             //error
           break;
        }        
     }
     
      /**
      * Gets this validator's comparison operator.
      * @value the comparison operator previously passed to <code>setType</code>.
       */
    public int getType()
     {
        return mOperType;
     }
     // ComparisionType is one of enumeration of >, <, !=, ==, <=, =>. 

     /**
      * Sets the right-side operand of this validator's expression.
      * @param rhsValue  a reference object containing a literal value.
       */
     public void setRhsValue( Object rhsValue)
     {
        // set the value with which comparision is to be done. 
        mRValue = rhsValue;
     }

     /**
       * Gets the right-side operand of this validator's expression.
       * @value  the operand previously passed to <code>setRhsValue</code>.
       */
     public Object getRhsValue( )
     {
        // set the value with which comparision is to be done. 
        return mRValue;
     }

     /**
       * Based on the objValue's class(AttributeDefImpl) either
       * the variant should get it's data from the Attribute
       * or it is a valid variant data itself.
       * Returns a oracle.jbo.server.util.Variant class which covers all
       * Java datatypes.
       */
     Variant getVariant(Object objValue)
     {
        //return value of the lhs.
        Variant variant = new Variant();
        Object  data = null;
        
        if( objValue instanceof DomainInterface  )
        {
           data = ((DomainInterface)objValue).getData();
        }
        else
        {
           data = objValue;
        }

        //switch on datatype to get proper variant.
        if( data instanceof Number )
        {
           if( data instanceof Integer )
           {
              variant.setInt( ((Integer)data).intValue());
           }
           else
           if( data instanceof Short )
           {
              variant.setShort( ((Short)data).shortValue());
           }
           else
           if( data instanceof Long )
           {
              variant.setLong( ((Long)data).longValue());
           }
           else
           if( data instanceof Float )
           {
              variant.setFloat( ((Float)data).floatValue());
           }
           else
           if( data instanceof Double )
           {
              variant.setDouble( ((Double)data).doubleValue());
           }
           else
           if( data instanceof BigDecimal )
           {
              variant.setBigDecimal( (BigDecimal)data );
           }
           else
           if( data instanceof BigInteger )
           {
              /*variant.setBigInteger( (BigInteger)data );*/
              variant.setLong(((Number)data).longValue());
           }
           else
           if( data instanceof Byte )
           {
              variant.setByte( ((Byte)data).byteValue());
           }
           else
           {
              //just in case.
              variant.setDouble( ((Number)data).doubleValue());
           }
        }
        else 
        if( data instanceof String )
        {
           variant.setString((String)data);
        }
        else 
        if( data instanceof Time )
        {
           variant.setTime( ((Time)data));
        }
        else 
        if( data instanceof Timestamp )
        {
           variant.setTimestamp( ((Timestamp)data));
        }
        else 
        if( data instanceof Date )
        {
           variant.setDate( ((Date)data));
        }
        else
        {
           //dummy
           variant.setObject(data);
        }

        return variant;
     }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
      public String toString()
     {
        return new String("Literal Compare( "
                            + getOperatorTypeString()
                            + mRValue.toString()
                            +")");
    }

     /**
       * Interprets a string as one of the comparison operator
       * constants defined in this class.
       * @param type a string, the textual name of a comparison operator.
       * @return a comparison operator constant.  An unrecognizable string defaults to
       * <code>EQUALTO</code>.
       */
     public static int convertOperType(String type)
     {
        switch ( type.length() )
        {
           case 7:
              return EQUALTO;
           case 8:
              return LESSTHAN;
           case 11:
              return GREATERTHAN;
           case 15:
              return LESSTHANEQUALTO;
           case 18:
              return GREATERTHANEQUALTO;
        }
        return EQUALTO;
     }

     /**
       * Converts this validator's comparison operator to its symbolic form.
       * @return a comparison symbol.  If the comparison operator is uninitialized
       * or invalid the null string is returned.
       */
     public String getOperatorTypeString()
     {
        String oper = "";
        switch(mOperType)
        {
           case EQUALTO:
              oper = " = ";
              break;
           case LESSTHAN:
              oper = " < ";
              break;
           case GREATERTHAN:
              oper = " > ";
              break;
           case LESSTHANEQUALTO:
              oper = " <= ";
              break;
           case GREATERTHANEQUALTO:
              oper = " >= ";
              break;
           default: 
           break;
        }
        return oper;
     }
     
}
