/*
 * @(#)JboPrecisionScaleValidator.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import java.math.BigDecimal;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttrSetValException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.common.StringManager;
import oracle.jbo.domain.LobInterface;
import oracle.jbo.domain.TypeFactory;

/**
 * Implements precision and scale validation for numeric attributes and length validation
 * for string and character attributes.
 *
 * The framework applies this validator to Entity Object attributes whose
 * definitions inlcude XML metadata precision or scale values.
 * <p>
 * <p>This validator is invoked by an Entity Objects's <tt>validate()</tt>
 * method when an attribute with defined precision or scale is modified.
 **/
public class JboPrecisionScaleValidator extends AbstractValidator implements JboValidatorInterface
{
   /*
   * Indicates that no scale validation is to be performed.
   */
   public final static int DEFAULT_SCALE = -127;

   int mPrec = 0;
   int mScale = DEFAULT_SCALE;
   static String DOTCHAR;
   static int DOTCHARLENGTH;
   private static JboPrecisionScaleValidator mSingleton;

   /*
   * This constructor sets the description for this validator from a
   * message bundle. It also sets the character that indicates a decimal
   * point (by default '.') from the message bundle.
   */
   /**
   * Creates a default validator.
   * <p>
   * Use <tt>setPrecision</tt> and <tt>setScale</tt> to configure the validatior.
   */
   public JboPrecisionScaleValidator()
   {
      DOTCHAR = StringManager.getString("oracle.jbo.CSMessageBundle",
                        CSMessageBundle.STR_VAL_SCALE_DECIMAL_CHAR,
                        null,
                        null);;
      DOTCHARLENGTH = DOTCHAR.length();
   }

   public static JboPrecisionScaleValidator getSingleton()
   {
      if (mSingleton == null)
      {
         mSingleton = new JboPrecisionScaleValidator();
      }
      return mSingleton;
   }

   /**
     * Validates an Entity Object by invoking <tt>validateValue()</tt>.
     * @param evObj an event object indicating the Entity Object to be validated.
     * @throws AttrSetValException if validation fails.
     */
   public void validate(JboValidatorContext evObj)
   {
      //initialize to false meaning failure, 
      //just in case validateValue throws.
      boolean bval = false;
      Object src = null;

      try {

         src = evObj.getSource();
         AttributeDef ad = evObj.getAttributeDef();
         if (ad != null)
         {
            bval = validateValue(evObj.getNewValue(), ad.getPrecision(), ad.getScale());
         }
         else
         {
            synchronized (this)
            {
               bval = validateValue(evObj.getNewValue(), mPrec, mScale);
            }
         }
         if (!bval)
         {
            RulesBeanUtils.raiseException(CSMessageBundle.class,
                                    CSMessageBundle.EXC_VAL_PRECISION_VALIDATOR,
                                    src, evObj.getSourceType(), evObj.getSourceFullName(), evObj.getAttributeDef(),
                                    evObj.getNewValue(), null, null);
         }
      }
      catch( JboException  je )
      {
         throw je;
      }
      catch( Exception e )
      {
         RulesBeanUtils.raiseException(CSMessageBundle.class,
                                 CSMessageBundle.EXC_VAL_PRECISION_VALIDATOR,
                                 src, evObj.getSourceType(), evObj.getSourceFullName(), evObj.getAttributeDef(),
                                 evObj.getNewValue(), null, e);
      }
   }

   /**
   * Tests the Entity Object against this validator's precision and scale values.
   * <p>
   * The precision value is the maximum allowed number of digits in a number,
   * or the number of characters in a string.  The scale value, when less than
   * zero, is the minimum number of digits following the decimal point, and when
   * greater than zero, is the minimum number of digits preceeding the decimal point.
   * <p>
   * @param value the Entity Object to be tested.
   * @return <tt>true</tt> if <tt>value</tt> is valid.
   **/
   public static boolean validateValue(Object value, int prec, int scale)
   {
      // invoked by AttributeDefImpl to perform Precision/Scale validation.
      boolean bOK = true;
      String valStr;
      char firstChar;
      BigDecimal maxNum;
      BigDecimal valBd;

      if(value != null)
      {
         //if length is less than/equal to precision
         //do we need to NLS-size this stringlength?
         if( scale == DEFAULT_SCALE )
         {
            if (!(value instanceof LobInterface)) 
            {
               bOK = (prec> 0) ? (value.toString().length() <= prec) : bOK;
            }
            else
            {
               bOK = (prec> 0) ? (((LobInterface)value).getSize() <= prec) : bOK;
            }
         }  
         else
         {
            //check for scale, should come here only for numerics.
            valStr = value.toString().trim();
            if (valStr.length() == 0)
            {
               return bOK;
            }

            //could use this but we'd need 8.1.5 version of oci8
            //NUMBER num = NUMBER.textToPrecisionNumber(valStr, (prec != 0), prec, true, scale, null);
            firstChar = valStr.charAt(0);
            if( firstChar == '+' || firstChar == '-' )
            {
               valStr = valStr.substring(1);
            }

            valBd = (BigDecimal)TypeFactory.getInstance(BigDecimal.class, valStr);
            if( scale < 0 )
            {
               maxNum = new BigDecimal(java.lang.Math.pow((double)10, (double)(-1 * scale )));
               bOK = ( valBd.compareTo(maxNum) < 0 ) && (valStr.length() <= prec + DOTCHARLENGTH );
            }
            else if( scale > 0 )
            {
               maxNum = new BigDecimal(java.lang.Math.pow((double)10, (double)prec-scale));
               bOK = (valStr.indexOf(DOTCHAR) > -1) 
                     ? ((valBd.compareTo(maxNum) < 0) && (valStr.length() - valStr.indexOf(DOTCHAR) - 1 <= scale))
                     : (valBd.compareTo(maxNum) < 0);
            }
            else
            {
               //bOK = ( String.valueOf(valBd.longValue()).length() <= prec );
               bOK = ( String.valueOf(valBd.longValue()).length() <= prec ) && (valBd.scale() == 0);
            }
         }
      }
      return bOK;
   }

   // these methods are provided
   // just in case, this validator is used as a validation bean.    
   /**
   * Gets the precision value.  For strings, "precision" refers to length.
   * @return the precision value.
   **/
   public int getPrecision()
   {
      return mPrec;
   }
   
   /**
   * Gets the scale value. If scale validation is not to be performed
   * this value is <tt>-127</tt>.
   * @value the scale value.
   **/
   public int getScale()
   {
      return mScale;
   }
   
   /**
   * Sets the precision value.  For strings, "precision" refers to length.
   * @param prec the new precision value.
   **/
   public void setPrecision( int prec)
   {
      mPrec = prec;
   }

   /**
   * Sets the scale value. If scale validation is not to be performed
   * this value should be <tt>-127</tt>.
   * @param scale the new scale value.
   **/
   public void setScale( int scale)
   {
      mScale = scale;
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   */
   public String toString()
   {
      return new String("Precision-"+mPrec+"; Scale-"+mScale);
   }


   /**
   * Gets the description of this validator.
   * @return a documentation string.
   **/
   public String getDescription()
   {
      return "";
   }

   /**
   * Sets the description of this validator.
   * @param description a documentation string.
   **/
   public void setDescription( String description)
   {
      //noop.
   }

}
