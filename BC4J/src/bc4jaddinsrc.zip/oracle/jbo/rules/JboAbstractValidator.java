/*
 * @(#)JboAbstractValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import oracle.jbo.JboException;
import oracle.jbo.AttributeDef;
import oracle.jbo.StructureDef;
import oracle.jbo.Row;

/**
 * The superclass for all pre-defined validators.
 * <p>
 * This class implements the basic functionality of storing the value
 * of either an attribute to be validated, or the entity or application module
 * reference on which validation is to be invoked.
 *
 * Subclasses must provide <code>validateValue</code>, which performs the actual
 * validation test.
 *
 * @since Jdeveloper 3.0
 */
abstract public class JboAbstractValidator extends AbstractValidator
{
//   private transient Object mSource;
   protected AttributeDef mValidatingAttr;
   protected String mValidatingAttrName;
   boolean mInit = false;

   protected void initialize(JboValidatorContext evObj)
   {
      if (mValidatingAttr == null)
      {
         if (mValidatingAttrName != null)
         {
            AttributeDef ad = evObj.getAttributeDef();
            if (ad != null && mValidatingAttrName.equals(ad.getName()))
            {
               mValidatingAttr = ad;
            }
            else
            {
               //has to be a row.
               StructureDef def = ((Row)evObj.getSource()).getStructureDef();
               mValidatingAttr = def.findAttributeDef(mValidatingAttrName);
            }
         }
         else
         {
            //default to the attribute on which validator called.
            //this would be the case when OnAttribute is missing.
            mValidatingAttr = evObj.getAttributeDef();
         }
         mInit = true;
      }
   }


   /**
     * Validates an object.
     * <p>
     * Subclasses must implement this method.
     * @param value the object to be validated.
     * @return <code>true</code> if the object is valid.
     * @throws Exception if validation cannot be performed.
    */
   abstract public boolean validateValue(Object value);
   
   public void validate(JboValidatorContext evObj) 
   {

      //initialize to false meaning failure, 
      //just in case validateValue throws.
      boolean bval = false;

      try 
      {

         Object source = evObj.getSource();
         if (!mInit)
         {
            synchronized (this)
            {
               initialize(evObj);
            }
         }

         Object lValue;
         if (mValidatingAttr != null 
             && !mValidatingAttr.getName().equals(evObj.getAttributeName())
             && source instanceof Row)
         {
            
            setNewValue((lValue = ((Row)source).getAttribute(mValidatingAttr.getIndex())));
         }
         else
         {
            setNewValue((lValue = evObj.getNewValue()));
         }

         bval = validateValue(lValue);
         if(mbInverse == bval)
         {
            raiseException(null, evObj);
         }
      }
      catch( JboException ve )
      {
         //thow when,
         //   inverse is true and exception is thrown due to validation failure
         if(mbInverse == bval)
         {
            if (evObj.getSourceType() == JboValidatorContext.TYP_VIEW_OBJECT)
            {
               ve.setNeedsEntityToVOMapping(false);
            }
            throw ve;
         }
      }
      catch( Exception e )
      {
         raiseException(e, evObj);
      }
   }

   void raiseException(Exception e, JboValidatorContext evObj)
   {
      RulesBeanUtils.raiseException(getErrorMessageClass(),
                              getErrorMsgId(),
                              evObj.getSource(),
                              evObj.getSourceType(),
                              evObj.getSourceFullName(),
                              mValidatingAttr,
                              getValueToValidate(evObj),
                              null, e);
   }
   
    /**
      * When the newValue is an Entity, get the attribute's value
      * by using the get<em>Attribute</em> method on the entity. Otherwise,
      * newValue should be a value to compare in this validator.
      * @param newValue either the attribute's value or a value to use to compare
      * in the validator.
      */
   protected void setNewValue(Object newValue) throws Exception
   {
      /*
      if( newValue instanceof Row)
      {
         //get the method of <mMethodName> and get it's value.
         mLValue = ((Row)newValue).getAttribute(mValidatingAttr.getIndex());
      }
      else
      {
         mLValue = newValue;
      }
      */
   }

   protected Object getValueToValidate(JboValidatorContext evObj)
   {
      Object source = evObj.getSource();
      if (mValidatingAttr != null && !mValidatingAttr.getName().equals(evObj.getAttributeName()))
      {
         return ((Row)source).getAttribute(mValidatingAttr.getIndex());
      }
      return evObj.getNewValue();
   }

   public void setValidatingAttributeName(String name)
   {
      mValidatingAttrName = name;
   }

   /**
     * Sets the validating attribute.
     * <p>
     * @param attr an attribute.
     */
   public void setValidatingAttribute( AttributeDef attr )
   {
      mValidatingAttr = attr;
   }

   /**
     * Sets the validating attribute by name.
     * <p>
     * This variant is used when the validator is
     * attached to an entity, rather than to an attribute.
     * @param beanInfo  the entity containing the attribute.
     * @param str an attribute name as a string.
     */
   public void setValidatingAttribute( StructureDef beanInfo, String str )
   {
      mValidatingAttr = beanInfo.findAttributeDef(str);
   }

   public String getValidatingAttributeName()
   {
      return (mValidatingAttr != null) ? mValidatingAttr.getName() : mValidatingAttrName;
   }
}
