package oracle.jbo.rules;

public class JboCustomValidator extends AbstractValidator
                                implements JboValidatorInterface
{
    protected String mName;
    protected String mBeanClass;
    protected JboValidatorInterface mVal;

    public JboCustomValidator(String name, String beanClass, JboValidatorInterface val)
    {
        setName(name);
        setBeanClass(beanClass);
        setBeanInstance(val);
    }
    
    public void setName(String name)
    {
        mName = name;
    }

    public String getName()
    {
        return mName;
    }

    public void setBeanClass(String beanClass)
    {
        mBeanClass = beanClass;
    }
    
    public String getBeanClass()
    {
        return mBeanClass;
    }

    public void setBeanInstance(JboValidatorInterface val)
    {
        mVal = val;
    }

    public JboValidatorInterface getBeanInstance()
    {
        return mVal;
    }

    public void validate(JboValidatorContext ctx) 
    {
        mVal.validate(ctx);
    }

    public boolean validateValue(Object val)
    {
        return false;
    }

    public String getDescription()
    {
        return mVal.getDescription();
    }
    
    public void setDescription(String description)
    {
        mVal.setDescription(description);
    }
}
