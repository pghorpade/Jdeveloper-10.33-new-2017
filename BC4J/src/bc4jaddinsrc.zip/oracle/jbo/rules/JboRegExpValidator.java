/*
 * @(#)JboRegExpValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import oracle.jbo.CSMessageBundle;

/**
 * A validator that tests attribute values by comparing
 * them with a pre-defined regular expression.
 * <p>
 * The value to be validated is designated as the left-hand operand of a
 * relation operation.  The validator provides the right-hand operand
 * @since Jdeveloper 3.0
 */
public class JboRegExpValidator extends JboAbstractValidator
                                 implements JboValidatorInterface 
{
    public static final String REGEX_CASE_INSENSITIVE_TEXT = "CaseInsensitive"; //NOTRANS
    public static final String REGEX_MULTILINE_TEXT = "Multiline";              //NOTRANS
    public static final String REGEX_DOTALL_TEXT = "DotAll";                    //NOTRANS 
    public static final String REGEX_UNICODE_CASE_TEXT = "UnicodeCase";         //NOTRANS  
    public static final String REGEX_CANON_EQ_TEXT = "CanonEq";                 //NOTRANS

    protected String mPattern;
    protected String mFlagValue;

    protected void initialize(JboValidatorContext evObj)
    {
        super.initialize(evObj);
    }

    /**
     * Creates an uninitialized regular expression validator.
     * <p>
     * The method <code>setPattern()</code>
     * must be invoked before validation can be performed.
     **/
    public JboRegExpValidator()
    {
        mbInverse = false;
        setDefaultDescription(CSMessageBundle.STR_VAL_DESC_REGEXP_VALIDATOR );
    }

    /**
     * Creates an initialized regular expression validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * comparison relation is inverted.
     * @param patternArg this validator's right-hand operand,
     * a reference object containing a regular expression.
     * @param flagValueArg  validator's match flags
     **/    
    public JboRegExpValidator(boolean inverse, String patternArg, String flagValueArg)
    {
        mbInverse = inverse;
        setPattern(patternArg);
        setFlagValue(flagValueArg);
        setDefaultDescription( CSMessageBundle.STR_VAL_DESC_COMPARE_VALIDATOR );
    }              

    /**
     * Validate an object by matching it with 
     * a pre-defined regular expression.
     * <p>
     * The <code>value</code> parameter is the left-hand operand
     * of this validator's regular expression comparison relation.
     * The right-hand operand is the value set by <code>setPattern()</code>.
     * <p>
     * This method is called by <code>AbstractValidator#vetoableChange()</code>.
     *
     * @param value the object to be validated.
     * @return
     * <code>true</code> if the relation holds, or
     * <code>false</code> if the relation does not hold or
     * operand is invalid or uninitialized.
     */
    public boolean validateValue(Object value)
    {
        if (value == null)
        {
            //a true is returned here since it is possible
            //to set a null value in a database table.
            //validator should not return false for that case
            return true;
        }

        int flagIntVal = getRegExpFlagInt(getFlagValue());
        Pattern pattern;
        
        if (flagIntVal != 0)
        {
            pattern = Pattern.compile(getPattern(), flagIntVal);
        }
        else 
        {
            pattern = Pattern.compile(getPattern());
        }
        
        Matcher matcher = pattern.matcher(value.toString());
        
        return matcher.matches();
    }

    /**
     * Sets the right-side operand of this validator's expression.
     * @param patternArg  a reference object containing a regular expression.
     */
    public void setPattern(String patternArg)
    {
        mPattern = patternArg;
    }

    /**
     * Gets the right-side operand of this validator's expression.
     * @value the operand previously passed to <code>setPattern</code>.
     */
    public String getPattern()
    {
        return mPattern;
    }

    /**
     * Sets the match flags for the regular expression comparison.
     * @param flagValueArg  a reference object containing String representation
     * of the match flags.
     */
    public void setFlagValue(String flagValueArg)
    {
        mFlagValue = flagValueArg;
    }
     
    /**
     * Gets the match flags for the regular expression comparison.
     * @value the String previously passed to <code>setFlagValue</code>.
     */
    public String getFlagValue()
    {
        return mFlagValue;
    }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
    public String toString()
    {
        return new String(" RegExp Compare( "        //NOTRANS
                          + getPattern()
                          +")");                     //NOTRANS
    }


    /**
     * Gets the computed int value of the regular expression match flags.
     * @value an int value representing the match flags.
     */
    public static int getRegExpFlagInt(String flagStr)
    {
        int returnVal = 0;
        
        if ((flagStr != null) && (flagStr.trim().length() > 0))
        {
            int flag = 0;
            flag |= getKeyValue(flagStr, REGEX_CASE_INSENSITIVE_TEXT, Pattern.CASE_INSENSITIVE);
            flag |= getKeyValue(flagStr, REGEX_MULTILINE_TEXT,        Pattern.MULTILINE);
            flag |= getKeyValue(flagStr, REGEX_DOTALL_TEXT,           Pattern.DOTALL);
            flag |= getKeyValue(flagStr, REGEX_UNICODE_CASE_TEXT,     Pattern.UNICODE_CASE);
            flag |= getKeyValue(flagStr, REGEX_CANON_EQ_TEXT,         Pattern.CANON_EQ);
            returnVal = flag;
        }
        return returnVal;
    }
    
    /**
     * <b>Internal:</b>
     * <p>
     */
    protected static int getKeyValue(String flagValue, String keyString, int keyValue)
    {
        return (flagValue.indexOf(keyString) >= 0) ? keyValue : 0;
    }
}
