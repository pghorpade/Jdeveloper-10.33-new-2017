/*
 * @(#)Variant.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.VariantException;
import oracle.jbo.common.Diagnostic;

public class Variant 
{
  private static final long serialVersionUID = 200L;

  /**
   * Two types of null supported.  Assigned is a null that was
   * explicitly set to null. Unassigned is a null value because it was
   * never assigned.
   */
  // UNASSIGNED_NULL - ASSIGNED_NULL expected to belong to a contiguous range
  //
  public static final int UNASSIGNED_NULL    = 0;
  public static final int ASSIGNED_NULL      = 1;
  public static final int NULL_TYPES         = 1;

  // BYTE - LONG expected to belong to a contiguous range
  //
  public static final int BYTE          = 2;
  public static final int SHORT         = 3;
  public static final int INT           = 4;
  public static final int LONG          = 5;

  // FLOAT - DOUBLE expected to belong to a contiguous range
  //
  public static final int FLOAT         = 6;
  public static final int DOUBLE        = 7;

  public static final int BIGDECIMAL    = 10;

  public static final int BOOLEAN       = 11;

  /** @deprecated use INPUTSTREAM.
  */
  public static final int BINARY_STREAM = 12;
  /** @since JB2.0 same as deprecated BINARY_STREAM.
  */
  public static final int INPUTSTREAM   = 12;

  public static final int DATE          = 13;
  public static final int TIME          = 14;
  public static final int TIMESTAMP     = 15;

  public static final int STRING        = 16;
  public static final int OBJECT        = 17;
  public static final int BYTE_ARRAY    = 18;

  /**
   * Type names
   */
  public static final String AssignedNull_S     = "ASSIGNED_NULL";   //NORES
  public static final String UnassignedNull_S   = "UNASSIGNED_NULL"; //NORES

  public static final String ByteType_S         = "BYTE";         //NORES
  public static final String ShortType_S        = "SHORT";        //NORES
  public static final String IntType_S          = "INT";          //NORES
  public static final String LongType_S         = "LONG";         //NORES

  public static final String FloatType_S        = "FLOAT";        //NORES
  public static final String DoubleType_S       = "DOUBLE";       //NORES

  public static final String BigDecimalType_S   = "BIGDECIMAL";   //NORES

  public static final String BooleanType_S      = "BOOLEAN";      //NORES

  public static final String InputStreamType_S  = "INPUTSTREAM"; //NORES
  public static final String BinaryStreamType_S = "BINARY_STREAM"; //NORES

  public static final String DateType_S         = "DATE";          //NORES
  public static final String TimeType_S         = "TIME";          //NORES
  public static final String TimestampType_S    = "TIMESTAMP";     //NORES

  public static final String ByteArrayType_S    = "BYTE_ARRAY";    //NORES
  public static final String StringType_S       = "STRING";        //NORES
  public static final String ObjectType_S       = "OBJECT";        //NORES
  public static final String UnknownType_S      = "UNKNOWN";       //NORES

  public static final Variant nullVariant = new Variant(UNASSIGNED_NULL);

  public static final int  MaxTypes        = 18;

  /**
   * If this constructor is used, all set operations must be of
   * dataType that the Variant was constructed with.
   */
  public Variant(int dataType) {
    setType = dataType;
  }

  public Variant() {
  }

  public static String typeName(int type) {
    switch (type) {
      case ASSIGNED_NULL:   return AssignedNull_S;
      case UNASSIGNED_NULL: return UnassignedNull_S;

      case BYTE:          return ByteType_S;
      case SHORT:         return ShortType_S;
      case INT:           return IntType_S;
      case LONG:          return LongType_S;

      case FLOAT:         return FloatType_S;
      case DOUBLE:        return DoubleType_S;

      case BIGDECIMAL:    return BigDecimalType_S;

      case BOOLEAN:       return BooleanType_S;

      case INPUTSTREAM:   return InputStreamType_S;

      case DATE:          return DateType_S;
      case TIME:          return TimeType_S;
      case TIMESTAMP:     return TimestampType_S;

      case STRING:        return StringType_S;
      case BYTE_ARRAY:    return ByteArrayType_S;
      case OBJECT:        return ObjectType_S;
      default:            return UnknownType_S;
    }
  }

  public static int typeOf(String typeName) {
    // Put more common ones first.
    //
    if (typeName.equals(StringType_S))       return STRING;
    if (typeName.equals(DateType_S))         return DATE;
    if (typeName.equals(TimeType_S))         return TIME;
    if (typeName.equals(TimestampType_S))    return TIMESTAMP;
    if (typeName.equals(IntType_S))          return INT;
    if (typeName.equals(BigDecimalType_S))   return BIGDECIMAL;

    if (typeName.equals(AssignedNull_S))     return ASSIGNED_NULL;
    if (typeName.equals(UnassignedNull_S))   return UNASSIGNED_NULL;

    if (typeName.equals(ByteType_S))         return BYTE;
    if (typeName.equals(ShortType_S))        return SHORT;
    if (typeName.equals(LongType_S))         return LONG;

    if (typeName.equals(DoubleType_S))       return DOUBLE;
    if (typeName.equals(FloatType_S))        return FLOAT;

    if (typeName.equals(BooleanType_S))      return BOOLEAN;

    if (typeName.equals(BinaryStreamType_S)) return INPUTSTREAM;
    if (typeName.equals(InputStreamType_S))  return INPUTSTREAM;
    if (typeName.equals(ByteArrayType_S))    return BYTE_ARRAY;

    if (typeName.equals(ObjectType_S))       return OBJECT;

    throw new VariantException(CSMessageBundle.EXC_VAR_INVALID_VARIANT_NAME,
                                   new String[] { typeName });
  }

  public static int typeId(String name) {
    for (int i = NULL_TYPES+1; i <= MaxTypes; i++)
      if (name.equals(typeName(i)))
        return i;
    return UNASSIGNED_NULL;
  }

  /**
   * Returns the zime zone offset of the current calender.
   * Used internally by JDeveloper.
   *
   * @return     offset in milliseconds of current timezone.
   * @since      JB2.0
   */
  public static long getTimeZoneOffset() {
    if (!offsetsKnown) {
       //java.sql.Date date = new java.sql.Date(70,0,1); deprecated in jdk.
      java.sql.Date date = new java.sql.Date(0);
      timeZoneOffset = date.getTime();
      offsetsKnown = true;
    }
    return timeZoneOffset;
  }

  // setType is used to enforce type safe set operations.
  // setType never changes.  If setType is set to non zero, type can only be changed
  // to the same type as setType or to one of the null states.
  //
  private int             setType;
  private int             type;

  private boolean         booleanVal;
  private int             intVal;
  private long            longVal;
  private float           floatVal;
  private double          doubleVal;

  private String          stringVal;
  private byte[]          byteArrayVal;
  private BigDecimal      bigDecimalVal;
  private java.sql.Date   dateVal;
  private Time            timeVal;
  private Timestamp       timestampVal;

  private transient Object objectVal;

  private static String               zeroString;
  private static char[]               zeroCharArray;
  private static BigDecimal           zeroBIGDECIMAL;
  private static ByteArrayInputStream zeroBinary;
  private static byte[]               zeroByteArray;
  private static boolean              offsetsKnown;
  private static long                 timeZoneOffset;
//  private static long                 milliSecsPerDay = 24*60*60*1000;

  // TODO. Get this functionality out of Variant!
  //
  public final Object getDisplayValue() {
    switch (type) {
      case ASSIGNED_NULL:
      case UNASSIGNED_NULL:
        return "";
      case OBJECT:
      case INPUTSTREAM:
        return objectVal;
      default: break;           // to make compiler happy
    }
    return toString();
  }

  private boolean setZeroValue(int unexpectedType, int expectedType) {
    if (zeroString == null) {
      zeroString     = "";
      zeroCharArray  = new char[0];
      zeroBIGDECIMAL = new BigDecimal(0);
      zeroByteArray  = new byte[0];
      zeroBinary     = new ByteArrayInputStream(zeroByteArray);
    }

    switch (expectedType) {
      case INT:
      case SHORT:
      case BYTE:
        intVal = 0;
        break;
      case TIMESTAMP:
        setTimestamp(0, 0);
        break;
      case TIME:
        setTime(0);
        break;
      case DATE:
        setDate(0);
        break;
      case LONG:
        longVal = 0;
        break;
      case BOOLEAN:
        booleanVal = false;
        break;
      case FLOAT:
        floatVal = 0;
        break;
      case DOUBLE:
        doubleVal = 0;
        break;
      case STRING:
        stringVal = zeroString;
        break;
      case BIGDECIMAL:
        bigDecimalVal = zeroBIGDECIMAL;
        booleanVal    = false;
        break;
      case OBJECT:
      case INPUTSTREAM:
        objectVal = zeroBinary;
        break;
      case BYTE_ARRAY:
        byteArrayVal = zeroByteArray;
        break;
      default: return false;
    }
    Diagnostic.ASSERT(unexpectedType <= NULL_TYPES);
    // Preserve null type.
    //
    type  = unexpectedType;
    return true;
  }

  private void typeProblem(int unexpectedType, int expectedType) {
    if (unexpectedType <= NULL_TYPES && setZeroValue(unexpectedType, expectedType))
      return;

    throw new VariantException(CSMessageBundle.EXC_VAR_UNEXPECTED_TYPE,
                                     new String[] { typeName(unexpectedType) ,
                                                    typeName(expectedType) });
  }

  public final int getInt() {
    if (type != INT)
      typeProblem(type, INT);
    return intVal;
  }

  public final short getShort() {
    if (type != SHORT)
      typeProblem(type, SHORT);
    return (short)intVal;
  }

  public final byte getByte() {
    if (type != BYTE)
      typeProblem(type, BYTE);
    return (byte)intVal;
  }

  public final long getLong() {
    if (type != LONG)
      typeProblem(type, LONG);
    return longVal;
  }

  public final boolean getBoolean() {
    if (type != BOOLEAN)
      typeProblem(type, BOOLEAN);
    return booleanVal;
  }

  public final double getDouble() {
    if (type != DOUBLE)
      typeProblem(type, DOUBLE);
    return doubleVal;
  }

  public final float getFloat() {
    if (type != FLOAT)
      typeProblem(type, FLOAT);
    return floatVal;
  }

  public final String  getString() {
    if (type != STRING)
      typeProblem(type, STRING);
    return stringVal;
  }

  public final BigDecimal getBigDecimal() {
    if (type != BIGDECIMAL)
      typeProblem(type, BIGDECIMAL);
    if (booleanVal) {
      bigDecimalVal = new BigDecimal(stringVal);
      booleanVal    = false;
    }
    return bigDecimalVal;
  }

  public final java.sql.Date getDate() {
    if (type != DATE)
      typeProblem(type, DATE);
    return dateVal;
  }

  public final Time getTime() {
    if (type != TIME)
      typeProblem(type, TIME);
    return timeVal;
  }

  public final Timestamp getTimestamp() {
    if (type != TIMESTAMP)
      typeProblem(type, TIMESTAMP);
    return timestampVal;
  }

  public final byte[] getByteArray() {
    if (type != BYTE_ARRAY)
      typeProblem(type, BYTE_ARRAY);
    return byteArrayVal;
  }

  public final int getArrayLength() {
    return intVal;
  }

  /** @deprecated  Use getInputStream().
  */
  public final InputStream getBinaryStream() {
    return getInputStream();
  }

  public final InputStream getInputStream() {
    if (type != INPUTSTREAM)
      typeProblem(type, INPUTSTREAM);
    return (InputStream)objectVal;
  }

  public final void setInt(int val) {
    Diagnostic.ASSERT(this != nullVariant);
    if (setType != 0 && setType != INT)
      typeProblem(setType, INT);
    type        = INT;
    intVal      = val;
  }

  public final void setShort(short val) {
    if (setType != 0 && setType != SHORT)
      typeProblem(setType, SHORT);
    type        = SHORT;
    intVal      = val;
  }

  public final void setByte(byte val) {
    if (setType != 0 && setType != BYTE)
      typeProblem(setType, BYTE);
    type        = BYTE;
    intVal      = val;
  }
/*
  public final void setAsInt(int val) {
    switch (type) {
      case BYTE:   setByte((byte)val); return;
      case SHORT:  setShort((short)val); return;
      default:     setInt(val); return;
    }
  }

*/


  public final void setLong(long val) {
    if (setType != 0 && (setType < BYTE || setType > LONG))
      typeProblem(setType, LONG);
    type        = LONG;
    longVal     = val;
  }

  public final void setBoolean(boolean val) {
    if (setType != 0 && setType != BOOLEAN)
      typeProblem(setType, BOOLEAN);
    type        = BOOLEAN;
    booleanVal  = val;
  }


  public final void setDouble(double val) {
    if (setType != 0 && setType != DOUBLE)
      typeProblem(setType, DOUBLE);
    type        = DOUBLE;
    doubleVal   = val;
  }

  public final void setFloat(float val) {
    if (setType != 0 && setType != FLOAT)
      typeProblem(setType, FLOAT);
    type        = FLOAT;
    floatVal    = val;
  }


  /*
  public final void setAsDouble(double val) {
    switch(setType) {
      case FLOAT:     setFloat((float)val);   return;
      case DOUBLE:    setDouble(val);         return;
      default: break;           // to make compiler happy
    }
    typeProblem(setType, DOUBLE);
  }
*/


  public final void setString(String val) {
    if (setType != STRING && setType != 0)
      typeProblem(setType, STRING);
    type      = val == null ? ASSIGNED_NULL : STRING;
    stringVal = val;
  }

  public final void setBigDecimal(BigDecimal val) {
    if (setType != BIGDECIMAL && setType != 0)
      typeProblem(setType, BIGDECIMAL);
    type          = val == null ? ASSIGNED_NULL : BIGDECIMAL;
    bigDecimalVal = val;
    booleanVal    = false;
  }
/*
  public final void setBigDecimal(String val) {
    if (setType != BIGDECIMAL && setType != 0)
      typeProblem(setType, BIGDECIMAL);
    type          = val == null ? ASSIGNED_NULL : BIGDECIMAL;
    bigDecimalVal = null;
    stringVal     = val;
    booleanVal    = true;
  }
*/

  public final void setDate(java.sql.Date val) {
    if (setType != DATE && setType != 0)
      typeProblem(setType, DATE);
    if (val == null) {
      type    = ASSIGNED_NULL;
      dateVal = null;
    } else {
      type = DATE;
      if (dateVal == null)
        dateVal = new Date(val.getTime() /*System.currentTimeMillis()*/);
      else
        dateVal.setTime(val.getTime());
    }
  }

  public final void setTime(Time val) {
    if (setType != TIME && setType != 0)
      typeProblem(setType, TIME);
    if (val == null) {
      type    = ASSIGNED_NULL;
      timeVal = null;
    } else {
      type = TIME;
      if (timeVal == null)
        timeVal = new Time(val.getTime() /*System.currentTimeMillis()*/);
      else
        timeVal.setTime(val.getTime());
    }
  }

  public final void setTimestamp(Timestamp val) {
    if (setType != TIMESTAMP && setType != 0)
      typeProblem(setType, TIMESTAMP);
    if (val == null) {
      type = ASSIGNED_NULL;
      timestampVal = null;
    } else {
      type = TIMESTAMP;
      if (timestampVal == null)
        timestampVal = new Timestamp(val.getTime() /*System.currentTimeMillis()*/);
      else
        timestampVal.setTime(val.getTime());
      timestampVal.setNanos(val.getNanos());
    }
  }

  public final void setDate(long val) {
    if (setType != DATE && setType != 0)
      typeProblem(setType, DATE);
    type = DATE;
    if (dateVal == null)
      dateVal = new Date(System.currentTimeMillis());
    dateVal.setTime(val);
  }

  public final void setTime(long val) {
    if (setType != TIME && setType != 0)
      typeProblem(setType, TIME);
    type = TIME;
    if (timeVal == null)
      timeVal = new Time(System.currentTimeMillis());
    timeVal.setTime(val);
  }

  public final void setTimestamp(long val, int nanos) {
    if (setType != TIMESTAMP && setType != 0)
      typeProblem(setType, TIMESTAMP);
    type = TIMESTAMP;
    if (timestampVal == null)
      timestampVal = new Timestamp(System.currentTimeMillis());
    timestampVal.setTime(val);
    timestampVal.setNanos(nanos);
  }

  public final void setTimestamp(long val) {
    if (setType != TIMESTAMP && setType != 0)
      typeProblem(setType, TIMESTAMP);
    type = TIMESTAMP;
    if (timestampVal == null)
      timestampVal = new Timestamp(System.currentTimeMillis());

    timestampVal.setTime((val/1000)*1000);
    int nanos = (int)((val%1000) * 1000000);
    if (nanos < 0) {
      nanos = 1000000000 + nanos;
      timestampVal.setTime(((val/1000)-1)*1000);
    }
    timestampVal.setNanos(nanos);
  }

  public final void setByteArray(byte[] val, int length) {
    if (setType != BYTE_ARRAY && setType != 0)
      typeProblem(setType, BYTE_ARRAY);
    type         = val == null ? ASSIGNED_NULL : BYTE_ARRAY;
    byteArrayVal = val;
    intVal       = length;
  }

  public final void setArrayLength(int length) {
    intVal = length;
  }

  /** @deprecated  Use setInputStream().
  */
  public final void setBinaryStream(InputStream val) {
    setInputStream(val);
  }

  public final void setInputStream(InputStream val) {
    if (setType != INPUTSTREAM && setType != 0)
      typeProblem(setType, INPUTSTREAM);
    type      = val == null ? ASSIGNED_NULL : INPUTSTREAM;
    objectVal = (Object)val;
  }

  public final void setVariant(Variant value) {
    switch (value.type) {
      case STRING:      setString(value.stringVal); break;

      case BYTE:        setByte((byte)value.intVal); break;
      case SHORT:       setShort((short)value.intVal); break;
      case INT:         setInt(value.intVal); break;
      case BOOLEAN:     setBoolean(value.booleanVal); break;

      case TIMESTAMP:   setTimestamp(value.getTimestamp()); break;
      case DATE:        setDate(value.getDate()); break;
      case TIME:        setTime(value.getTime()); break;
      case LONG:        setLong(value.longVal); break;

      case FLOAT:       setFloat(value.floatVal); break;
      case DOUBLE:      setDouble(value.doubleVal); break;
      case BIGDECIMAL:
//        if (value.booleanVal)
//          setBigDecimal(value.stringVal);
//        else
          setBigDecimal(value.bigDecimalVal);
        break;
      case INPUTSTREAM:  setInputStream((InputStream)value.objectVal); break;
      case BYTE_ARRAY:   setByteArray(value.byteArrayVal, value.intVal); break;
      case OBJECT:       setObject(value.objectVal); break;

      case ASSIGNED_NULL:
      case UNASSIGNED_NULL:
        if (setType != value.type && setType != 0)
          typeProblem(value.type, setType);
        type = value.type;
        break;
      default:
        invalidVariantType(value.type);
//Diagnostic.println("putVariant() Invalid type:  "+value.type);
        break;
    }
  }

  /** @since 2.01
      Set this variant to value.  If value is not the same setType, then an
      attempt is made to convert to the data type of this variant.
  */

  public final void setAsVariant(Variant value) {
    switch (setType) {
      case STRING:            setString(value.stringVal); break;

      case BYTE:              setByte((byte)value.getAsInt()); break;
      case SHORT:             setShort((short)value.getAsInt()); break;
      case INT:               setInt(value.getAsInt()); break;
      case BOOLEAN:           setBoolean(value.getAsBoolean()); break;

      case TIMESTAMP:         setAsTimestamp(value); break;
      case DATE:              setAsDate(value); break;
      case TIME:              setAsTime(value); break;
      case LONG:              setLong(value.getAsLong()); break;

      case FLOAT:             setFloat(value.getAsFloat()); break;
      case DOUBLE:            setDouble(value.getAsDouble()); break;
      case BIGDECIMAL:        setBigDecimal(value.getAsBigDecimal());  break;
      case Variant.UNASSIGNED_NULL: setUnassignedNull(); break;
      case Variant.ASSIGNED_NULL: setAssignedNull(); break;
      default:
        if (setType == 0 || setType == value.type)
          setVariant(value);
        else
          invalidVariantType(value.type);
        break;
    }
  }

  private final void invalidVariantType(int type) {

    throw new VariantException(CSMessageBundle.EXC_VAR_INVALID_VARIANT_TYPE,
                                   new String[] { typeName(type) });
  }

  public final void setObject(Object val) {
    if (setType != OBJECT && setType != 0)
      typeProblem(setType, OBJECT);
    type      = OBJECT;
    objectVal = val;
  }

  public final Object getObject() {
    if (type != OBJECT)
      typeProblem(type, OBJECT);
    return objectVal;
  }

  public final short getAsShort() {
    switch (type) {
      case BYTE:
      case SHORT:
      case INT:        return (short)intVal;
      case BOOLEAN:    return (short)(booleanVal ? 1 : 0);
      case TIME:
      case DATE:
      case TIMESTAMP: return (short)getAsLong();
      case LONG:      return (short)longVal;
      case FLOAT:     return (short)floatVal;
      case DOUBLE:    return (short)doubleVal;
      case BIGDECIMAL:  return (short)getBigDecimal().intValue();
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return 0;
      default: break;           // to make compiler happy
    }
    typeProblem(type, SHORT);
    return 0;
  }

  public final int getAsInt() {
    switch (type) {
      case BYTE:
      case SHORT:
      case INT:     return intVal;
      case BOOLEAN: return booleanVal ? 1 : 0;
      case TIME:
      case DATE:
      case TIMESTAMP: return (int) getAsLong();
      case LONG:    return (int)longVal;
      case FLOAT:   return (int)floatVal;
      case DOUBLE:  return (int)doubleVal;
      case BIGDECIMAL:  return getBigDecimal().intValue();
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return 0;
      default: break;           // to make compiler happy
    }
    typeProblem(type, INT);
    return 0;
  }

  public final long getAsLong() {
    switch (type) {
      case BOOLEAN:    return booleanVal ? 1 : 0;
      case BYTE:
      case SHORT:
      case INT:        return intVal;
      case LONG:       return longVal;
      case FLOAT:      return (long)floatVal;
      case DOUBLE:     return (long)doubleVal;
      case BIGDECIMAL: return getBigDecimal().longValue();
      case TIMESTAMP:  return timestampVal.getTime();
      case TIME:       return timeVal.getTime();
      case DATE:       return dateVal.getTime();
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return 0;
      default: break;           // to make compiler happy
    }
    typeProblem(type, LONG);
    return 0;
  }

  public final double getAsDouble() {
    switch (type) {
      case BYTE:
      case SHORT:
      case INT:        return intVal;
      case LONG:       return longVal;
      case FLOAT:      return (double)floatVal;
      case DOUBLE:     return doubleVal;
      case BIGDECIMAL: return getBigDecimal().doubleValue();
      case TIME:
      case DATE:
      case TIMESTAMP: return (double) getAsLong();
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return 0;
      default: break;           // to make compiler happy
    }
    typeProblem(type, DOUBLE);
    return 0;
  }

  public final float getAsFloat() {
    switch (type) {
      case BYTE:
      case SHORT:
      case INT:        return intVal;
      case LONG:       return longVal;
      case FLOAT:      return floatVal;
      case DOUBLE:     return (float)doubleVal;
      case BIGDECIMAL: return getBigDecimal().floatValue();
      case TIME:
      case DATE:
      case TIMESTAMP: return (float) getAsLong();
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return 0;
      default: break;           // to make compiler happy
    }
    typeProblem(type, FLOAT);
    return 0;
  }

  public final BigDecimal getAsBigDecimal() {
    switch (type) {
      case BYTE:
      case SHORT:
      case INT:     return new BigDecimal(intVal);
      case LONG:    return new BigDecimal(longVal);
      case FLOAT:   return new BigDecimal(floatVal);
//      case DOUBLE:  return new BigDecimal(doubleVal, 4); 
      case DOUBLE:  return new BigDecimal(doubleVal);
      case BIGDECIMAL:  return getBigDecimal();
      case TIME:
      case DATE:
      case TIMESTAMP: return new BigDecimal(getAsLong());
      case Variant.UNASSIGNED_NULL:
      case Variant.ASSIGNED_NULL:
        return new BigDecimal(0);
      default: break;           // to make compiler happy
    }
    typeProblem(type, BIGDECIMAL);
    return null;
  }

  public final boolean getAsBoolean() {
    switch (type) {
      case BOOLEAN: return booleanVal;
      case STRING:  return Boolean.valueOf(stringVal).booleanValue();
      case BYTE:
      case SHORT:
      case INT:     return intVal != 0;
      case LONG:    return longVal != 0;
      case FLOAT:   return floatVal != 0;
      case DOUBLE:  return doubleVal != 0;
      case TIME:
      case DATE:
      case TIMESTAMP: return getAsLong() != 0;
    }
    return false;
  }

  public final void setAsTime(Variant value) {
    switch (value.type) {
      case TIME:        setTime(value.getTime());
                        break;
      case BOOLEAN:
      case BYTE:
      case SHORT:
      case INT:
      case LONG:
      case FLOAT:
      case DOUBLE:
      case BIGDECIMAL:
      case DATE:
      case TIMESTAMP:   setTime(value.getAsLong());
                        return;
      case Variant.UNASSIGNED_NULL:
        setUnassignedNull();
        return;
      case Variant.ASSIGNED_NULL:
        setAssignedNull();
        return;
      default: break;           // to make compiler happy
    }
    typeProblem(type, TIME);
  }

  public final void setAsTimestamp(Variant value) {
    switch (value.type) {
      case TIMESTAMP:   setTimestamp(value.getTimestamp());
                        break;
      case BOOLEAN:
      case BYTE:
      case SHORT:
      case INT:
      case LONG:
      case FLOAT:
      case DOUBLE:
      case BIGDECIMAL:
      case DATE:
      case TIME:        setTimestamp(value.getAsLong(), 0);
                        return;
      case Variant.UNASSIGNED_NULL:
        setUnassignedNull();
        return;
      case Variant.ASSIGNED_NULL:
        setAssignedNull();
        return;
      default: break;           // to make compiler happy
    }
    typeProblem(type, TIMESTAMP);
  }

  public final void setAsDate(Variant value) {
    switch (value.type) {
      case DATE:        setDate(value.getDate());
                        break;
      case BOOLEAN:
      case BYTE:
      case SHORT:
      case INT:
      case LONG:
      case FLOAT:
      case DOUBLE:
      case BIGDECIMAL:
      case TIME:
      case TIMESTAMP:   setDate(value.getAsLong());
                        return;
      case Variant.UNASSIGNED_NULL:
        setUnassignedNull();
        return;
      case Variant.ASSIGNED_NULL:
        setAssignedNull();
        return;
      default: break;           // to make compiler happy
    }
    typeProblem(type, DATE);
  }

  public final void setNull(int nullType) {
    // Test makes sure we set it to something reasonable.
    //
    if (nullType == UNASSIGNED_NULL)
      this.type = UNASSIGNED_NULL;
    else {
      Diagnostic.ASSERT(nullType == ASSIGNED_NULL);
      this.type = ASSIGNED_NULL;
    }
  }

  public final void setAssignedNull() {
    this.type = ASSIGNED_NULL;
  }

  public final void setUnassignedNull() {
    this.type = UNASSIGNED_NULL;
  }

  public final boolean isAssignedNull() {
    return type == ASSIGNED_NULL;
  }

  public final boolean isUnassignedNull() {
    return type == UNASSIGNED_NULL;
  }

  public final boolean isNull() {
    return type <= NULL_TYPES;
  }

  public final int getType() { return type; }
  public final int getSetType() { return setType; }

  public final String toString() {
    switch (type) {
      case ASSIGNED_NULL:
      case UNASSIGNED_NULL:
        return "";
      case INT:
      case BYTE:
      case SHORT:
        return Integer.toString(intVal, 10);
      case FLOAT:
        return Float.toString(floatVal);
      case DOUBLE:
        return Double.toString(doubleVal);
      case LONG:
        return Long.toString(longVal, 10);
      case BIGDECIMAL:
        if (booleanVal)
          return stringVal;
        if (bigDecimalVal == null)
          return "";
        return bigDecimalVal.toString();
      case BOOLEAN:
        return booleanVal ? "true" : "false";           //NORES
      case STRING:
        if (stringVal == null)
          return "";
        return stringVal;
      case DATE:
        return dateVal.toString();
      case TIME:
        return timeVal.toString();
      case TIMESTAMP:
        return timestampVal.toString();
      case BYTE_ARRAY:
        if (byteArrayVal == null)
          return "";
        return new String(byteArrayVal, 0, intVal);
      case OBJECT:
      case INPUTSTREAM:
        if (objectVal == null)
          return "";
        return objectVal.toString();
      default: break;           // to make compiler happy
    }
    Diagnostic.ASSERT(false);
    return "";
  }


  /** @since JB2.0  Returns true if value or value instance changed.  Note that
      will return false for Variants storing different Object reference values
      that may be equal.  Provides high speed test that indicates two variants may
      not be equal.  If true is returned they are equal.  If false is returned,
      they might still be equal.
  */
  public boolean equalsInstance(Variant value2) {
    switch(type) {
      case Variant.INPUTSTREAM:
      case Variant.OBJECT:
        return   type == value2.type && objectVal == value2.objectVal;
    }
    return equals(value2);
  }

  public final boolean equals(Variant value) {
    if (type != value.type) {
      if (type <= NULL_TYPES || value.type <= NULL_TYPES)
        return false;
      typeProblem(value.type, type);
    }

    switch (type) {
      case ASSIGNED_NULL:
      case UNASSIGNED_NULL:
        return value.type == type;
      case INT:
      case BYTE:
      case SHORT:
        return intVal == value.intVal;
      case BOOLEAN:
        return booleanVal == value.booleanVal;
      case FLOAT:
        return floatVal == value.floatVal;
      case DOUBLE:
        return doubleVal == value.doubleVal;
      case TIMESTAMP:
        if (timestampVal.getNanos() != value.getTimestamp().getNanos())
          return false;
        return timestampVal.getTime() == value.getTimestamp().getTime();
      case DATE:
      case TIME:
        return getAsLong() == value.getAsLong();
      case LONG:
        return longVal  == value.longVal;
      case BIGDECIMAL:
//        if (booleanVal && value.booleanVal && stringVal == value.stringVal)
//          return true;
        if (getBigDecimal() == value.getBigDecimal())
          return true;
        //return bigDecimalVal.equals(value.bigDecimalVal);
        return bigDecimalVal.compareTo(value.bigDecimalVal) == 0;
      case STRING:
        if (stringVal == value.stringVal)
          return true;
        return stringVal.equals(value.stringVal);
      case BYTE_ARRAY:
        if (intVal != value.intVal)
          return false;
        if (byteArrayVal == value.byteArrayVal)
          return true;
        int off = 0;
        while (byteArrayVal[off] == value.byteArrayVal[off] && off < intVal)
          ++off;
        return off == intVal;
      case INPUTSTREAM:
        return equals((InputStream)objectVal, (InputStream)value.objectVal);
      case OBJECT:
        if (objectVal == value.objectVal)
          return true;
        return objectVal.equals(value.objectVal);
      default: break;           // to make compiler happy
    }
    Diagnostic.ASSERT(false);
    return false;
  }

  private boolean equals(char[] val1, char[]val2) {
    int len = val1.length;
    if (len != val2.length)
      return false;
    for (int index = 0; index < len; ++index) {
      if (val1[index] != val2[index])
        return false;
    }
    return true;
  }

  private boolean equals(InputStream stream1, InputStream stream2) {
    if (stream1 == stream2)
      return true;
    if (stream1 == null || stream2 == null)
      return false;

    // Cannot compare, so assume not equal.
    //
    if (!stream1.markSupported() || !stream2.markSupported())
      return false;

    try {
      stream1.reset();
      stream2.reset();
      int count = 0;
//      Diagnostic.println("stream1 length: " + stream1.available());
//      Diagnostic.println("stream2 length: " + stream2.available());

      int ch = 0;
      while (ch != -1) {
        ch = stream1.read();
        int ch2 = stream2.read();
        ++count;
        if (ch != ch2){
//          Diagnostic.println(count +" ch:  "+ch+" ch2:  "+ch2);
//          Diagnostic.println("mismatch:  "+stream1+" "+stream2);
          return false;
        }
      }
    }
    catch (IOException ex) {
      Diagnostic.println("IOException hit:");
      Diagnostic.printStackTrace(ex);
      return false;
    }
    return true;
  }

  private final int compareLong(long value1, long value2) {
    if (value1 < value2)
      return -1;
    if (value1 > value2)
      return 1;
    return 0;
  }

  private final int compareDouble(double value1, double value2) {
    if (value1 < value2)
      return -1;
    if (value1 > value2)
      return 1;
    return 0;
  }

  private final int compareFloat(float value1, float value2) {
    if (value1 < value2)
      return -1;
    else if (value1 > value2)
      return 1;
    else
      return 0;
  }

  private final int compareTimestamp(Timestamp timestamp1, Timestamp timestamp2) {
    int comp  = compareLong(timestamp1.getTime(), timestamp2.getTime());
    if (comp == 0)
      return timestamp1.getNanos() - timestamp2.getNanos();
    return comp;
  }

  private final int compareBoolean(boolean bool1, boolean bool2) {
    if (bool1 == bool2)
      return 0;
    if (bool1)
      return 1;
    return -1;
  }

  public int compareTo(Variant value2) {
    if (isNull())
      return  value2.isNull() ? 0 : -1;
    if (value2.isNull())
      return 1;

    switch(type) {
      case Variant.BYTE:
      case Variant.SHORT:
      case Variant.INT:        return intVal - value2.getAsInt();

      case Variant.LONG:       return compareLong(longVal, value2.getAsLong());

      case Variant.FLOAT:      return compareFloat(floatVal, value2.getAsFloat());
      case Variant.DOUBLE:     return compareDouble(doubleVal, value2.getAsDouble());

      case Variant.BIGDECIMAL: return getBigDecimal().compareTo(value2.getAsBigDecimal());

      case Variant.DATE:       return compareLong(dateVal.getTime(), value2.getDate().getTime());
      case Variant.TIME:       return compareLong(timeVal.getTime(), value2.getTime().getTime());
      case Variant.TIMESTAMP:  return compareTimestamp(timestampVal, value2.getTimestamp());

      case Variant.BOOLEAN:    return compareBoolean(booleanVal, value2.getBoolean());

      case Variant.STRING:     return stringVal.compareTo(value2.getString());
      default: break;           // to make compiler happy
    }

    Diagnostic.ASSERT(false);
    return 0;
  }


  /*
  public void add(Variant value2, Variant result) {
    if (value2.isNull() && isNull())
      result.setVariant(this);
    else {
      switch(type) {
        case Variant.BYTE:       result.setByte((byte)(intVal+value2.getAsInt())); break;
        case Variant.SHORT:      result.setShort((short)(intVal+value2.getAsInt())); break;
        case Variant.INT:        result.setInt(intVal+value2.getAsInt()); break;
        case Variant.LONG:       result.setLong(longVal+value2.getAsLong()); break;
        case Variant.DATE:       result.setDate(dateVal.getTime()+value2.getDate().getTime());
        case Variant.TIME:       result.setTime(timeVal.getTime()+value2.getTime().getTime());
        case Variant.FLOAT:      result.setFloat(floatVal+value2.getAsFloat()); break;
        case Variant.DOUBLE:     result.setDouble(doubleVal+value2.getAsDouble()); break;
        case Variant.BIGDECIMAL: result.setBigDecimal(getBigDecimal().add(value2.getAsBigDecimal())); break;
        case Variant.UNASSIGNED_NULL:
        case Variant.ASSIGNED_NULL:   result.setVariant(value2); break;
        default:
          Diagnostic.println("type:  "+type);
          Diagnostic.ASSERT(false);
      }
    }
  }

  public void subtract(Variant value2, Variant result) {
    if (value2.isNull() && isNull())
      result.setVariant(this);
    else {
      switch(type) {
        case Variant.BYTE:
        case Variant.SHORT:
        case Variant.INT:        result.setInt(intVal-value2.getAsInt()); break;
        case Variant.LONG:       result.setLong(longVal-value2.getAsLong()); break;
        case Variant.FLOAT:      result.setFloat(floatVal-value2.getAsFloat()); break;
        case Variant.DOUBLE:     result.setDouble(doubleVal-value2.getAsDouble()); break;
        case Variant.BIGDECIMAL: result.setBigDecimal(getBigDecimal().subtract(value2.getAsBigDecimal())); break;
        case Variant.UNASSIGNED_NULL:
        case Variant.ASSIGNED_NULL:   result.setVariant(value2); break;
        default:
          Diagnostic.ASSERT(false);
      }
    }
  }

  public Object clone() {
    Variant value = new Variant(setType);
    value.setVariant(this);
    return value;
  }
  */
}
