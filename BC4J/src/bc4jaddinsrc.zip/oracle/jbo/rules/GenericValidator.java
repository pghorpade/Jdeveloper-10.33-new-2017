/*
 * @(#)GenericValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

/**
 * Implemented by validators for domain datatypes.
 * <p>
 * @see oracle.jbo.domain
 * @see JboGenericValidator
 * @since JDeveloper 3.0
 */
public interface GenericValidator  extends JboValidatorInterface
{
}
