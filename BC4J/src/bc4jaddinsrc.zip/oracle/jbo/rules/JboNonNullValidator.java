/*
 * @(#)JboNonNullValidator.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import com.sun.java.util.collections.ArrayList;
import oracle.jbo.AttributeDef;
import oracle.jbo.Row;
import oracle.jbo.AttrValException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.common.StringManager;


/**
 * Implements non-null validation for mandatory attributes. This validation rule
 * is applied by the framework to an Entity Object that has the mandatory flag set
 * for any of its an attributes.  The method <tt>isMandatory()</tt> identifies
 * manditory attributes.
 * <p>This validator is invoked by an Entity Objects's <tt>validate()</tt>
 * method to confirm that its mandatory attributes are non-null.
 * If any attribute is <tt>null</tt>, <tt>AttrValException</tt>
 * is thrown. The framework does not perform this validation when
 * an attribute value is changed, but only when its Enitity Object is validated.
 *
 * @see oracle.jbo.server.Entity
 * @see oracle.jbo.server.EntityDefImpl
 * @since JDeveloper 3.0 
 **/
public class JboNonNullValidator implements JboValidatorInterface
{
    transient protected AttributeDef[] mandatoryAttrs;
    protected String mDescription;

    /**
    * Creates a default validator.
    **/
    //public JboNonNullValidator()
    //{
    //   setDefaultDescription( CSMessageBundle.STR_VAL_DESC_MANDATORY_VALIDATOR );
    //}
    
    /**
    * Creates a validator from a list of attribute indices.
     * @param vec a list of indices for attributes to be considered manditory.
     **/
    public JboNonNullValidator(ArrayList vec)
    {
       setDefaultDescription( CSMessageBundle.STR_VAL_DESC_MANDATORY_VALIDATOR );
       mandatoryAttrs = (AttributeDef[])vec.toArray(new AttributeDef[vec.size()]);
    }

    /*
    void setupNonNull (Row entity)
    {
       if (mandatoryAttrs == null)
       {
          ArrayList vec = new ArrayList();
          AttributeDef adi;

          for (int i = 0; i < entity.getAttributeCount(); i++)
          {
             adi = entity.getStructureDef().getAttributeDef(i);
             if (adi.isMandatory())
             {
                vec.add(adi);
             }
          }
          setMandatoryAttrsFromList( vec );
       }
    }
    */
    /**
      * Validates the Entity Object's mandatory attributes.
      * @param evObj an event indicating the attributes to be validatated.
      * @throws JboException if any attributes are found to be <tt>null</tt>.
      */
    public void validate(JboValidatorContext evObj)
    {
       if (mandatoryAttrs != null)
       {
          Row entity = (Row)evObj.getSource();
          ArrayList al = null;
          String valstr = null;
          Object val;
          for (int i = 0; i < mandatoryAttrs.length; i++)
          {
             val = entity.getAttribute(mandatoryAttrs[i].getIndex());
             if (val != null) 
             {
                valstr = val.toString();
                if (valstr != null) 
                {
                   if (valstr.length() == 0) 
                   {
                      val = null;
                   }
                }
             }

             if (val == null) 
             {
                throw new AttrValException(AttrValException.TYP_ATTRIBUTE_LIST_WITH_DEF,
                                           CSMessageBundle.class,
                                           CSMessageBundle.EXC_VAL_ATTR_MANDATORY,
                                           "",
                                           mandatoryAttrs[i].getName());
             }
          }
       }
    }

    /*
    * Returns the validator's description. If
    * the description is null, returns this class name.
    */
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    * <p>
    */
    public String toString()
    {
       if (mDescription == null)
       {
          return new String("JboNonNullValidator");
       }

       return getDescription();
    }


   /**
   * Gets the description of this validator.
   * @return a documentation string.
   **/
   public String getDescription()
   {
      return mDescription;
   }

   /**
   * Sets the description of this validator.
   * @param description a documentation string.
   **/
   public void setDescription( String description)
   {
      mDescription = description;
   }

   void setDefaultDescription(String descId)
   {
      mDescription = StringManager.getString("oracle.jbo.CSMessageBundle",
                         descId,
                         null,
                         null);
   }
}
