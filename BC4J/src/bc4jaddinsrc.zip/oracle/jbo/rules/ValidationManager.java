package oracle.jbo.rules;
import oracle.jbo.rules.JboValidatorInterface;
import java.util.ArrayList;

public interface ValidationManager 
{
   String getName();
   void addValidator(JboValidatorInterface intf);
   ArrayList getValidators();
}
