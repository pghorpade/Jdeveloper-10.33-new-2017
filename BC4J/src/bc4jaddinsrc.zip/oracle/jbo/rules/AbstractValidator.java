/*
 * @(#)AbstractValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.common.StringManager;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.AttributeDef;

/**
 * The superclass for all pre-defined validators.
 * <p>
 * This class implements the basic functionality of storing the value
 * of either an attribute to be validated, or the entity or application module
 * reference on which validation is to be invoked.
 *
 * Subclasses must provide <code>validateValue</code>, which performs the actual
 * validation test.
 *
 * @since Jdeveloper 3.0
 */
abstract public class AbstractValidator
{
   final String MSG_BUNDLE_SUFFIX = "MsgBundle";
   protected boolean mbInverse = false;
   protected String mDescription;
   protected String mMsgId;
   protected Class mErrorMessageClass;
   protected String mValidatingAttrName;

   public void setErrorMessageClass(Class clz)
   {
      mErrorMessageClass = clz;
   }

   public Class getErrorMessageClass()
   {
      return (mErrorMessageClass != null) ? mErrorMessageClass : CSMessageBundle.class;
   }


   public Object convertToJava(AttributeDef attrDef, Object val)
   {
      return TypeFactory.getInstance(attrDef.getJavaType(), val);
   }

   /**
   * Allows the logic of this validator to be inverted.
   * @param bInverse <code>true</code> if the validation result is to be inverted,
   *  and <code>false</code> if the validation result is not to be inverted.
   **/
   public void setInverse( boolean bInverse )
   {
      mbInverse = bInverse;
   }

   /**
   * Reports whether the logic of this validator is inverted.
   * @return <code>true</code> if the validation result is inverted, and
   *   <code>false</code> if the validation result is not inverted.
   **/
   public boolean getInverse( )
   {
      return mbInverse;
   }

   /**
   * Gets the textul description of this validator.
   * @return  a documentation string.
   **/
   public String getDescription()
   {
      return mDescription;
   }

    /**
    * Sets the textul description of this validator using a specified string.
    * @param description  a documentation string.
    **/
   public void setDescription( String description)
   {
      mDescription = description;
   }

    /**
    * Sets the textul description of this validator using locale message code.
    * @param description  a message code.
    **/
   void setDefaultDescription(String descId)
   {
      mDescription = StringManager.getString("oracle.jbo.CSMessageBundle",
                         descId,
                         null,
                         null);
   }

   public String getErrorMsgId()
   {
      return (mMsgId != null) ? mMsgId : CSMessageBundle.EXC_VAL_ATTR_SET_FAILED;
   }

   public void setErrorMsgId(String msgId)
   {
      mMsgId = msgId;
   }

   public void setValidatingAttributeName(String name)
   {
      mValidatingAttrName = name;
   }

   public String getValidatingAttributeName()
   {
      return mValidatingAttrName;
   }


}
