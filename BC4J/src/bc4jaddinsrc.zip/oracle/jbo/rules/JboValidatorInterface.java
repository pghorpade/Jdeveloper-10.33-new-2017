/*
 * @(#)JboValidatorInterface.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

/**
 * The principal interface for validator classes.
 * <p>
 * Validators are subscribers to events related to adding, deleting,
 * or changing attribute values.
 * @since JDeveloper 3.0
 */
/* implementations have to implement. This validator interface
 * is a subclass of VetoableChangeListener, so the implementing
 * classes have to implement that interface too. This facilitates
 * adding the validators to any vetoableChange event for reuse.
 * 
 */
public interface  JboValidatorInterface 
{
   /**
     * Tests the validity of an attribute value.
     * <p>
     * @param ctx the validator context
     */
   abstract public void validate(JboValidatorContext ctx);

   /**
   * Gets the text description of this validator.
   * @return a textual description.
   **/
   abstract public String getDescription();

   /**
   * Sets the text description of this validator.
   * @param description a textual description.
   **/
   abstract public void setDescription( String description);

}                  
