/*
 * @(#)JboValidatorContext.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.rules;

import oracle.jbo.common.MetaObjectBase;
import oracle.jbo.Row;
import oracle.jbo.AttributeDef;

/**
 * A "PropertyChange" event gets delivered whenever a bean changes a "bound"
 * or "constrained" property.  A JboValidatorContext object is sent as an
 * argument to the PropertyChangeListener and VetoableChangeListener methods.
 * <P>
 * Normally JboValidatorContexts are accompanied by the name and the old
 * and new value of the changed property.  If the new value is a builtin
 * type (such as int or boolean) it must be wrapped as the 
 * corresponding java.lang.* Object type (such as Integer or Boolean).
 * <P>
 * Null values may be provided for the old and the new values if their
 * true values are not known.
 * <P>
 * An event source may send a null object as the name to indicate that an
 * arbitrary set of if its properties have changed.  In this case the
 * old and new values should also be null.
 */
public class JboValidatorContext implements MetaObjectBase
{

   private int    sourceType;
   private Object source;
   private String sourceFullName;
   private AttributeDef attributeDef;
   private Object newValue;
   private Object oldValue;

   /**
   * @param source  The bean that fired the event.
   * @param attribute  The property that was changed.
   * @param oldValue  The old value of the property.
   * @param newValue  The new value of the property.
   */
   public JboValidatorContext(int    sourceType,
                              Object source,   
                              String sourceFullName,
                              AttributeDef attribute,
                              Object oldValue, 
                              Object newValue) 
   {
      this.source = source;
      this.sourceType = sourceType;
      this.sourceFullName = sourceFullName;
      this.attributeDef = attribute;
      this.newValue = newValue;
      this.oldValue = oldValue;
   }

   /**
    * AttributeList Object that is being validated.
    */
   public Object getSource()
   {
      return source;
   }

   public Row getAttributeList()
   {
      return (sourceType == TYP_ATTRIBUTE_LIST_WITH_DEF) ? (Row)source : null;
   }

   public Row getSourceRow()
   {
      switch (sourceType)
      {
         case TYP_ENTITY_OBJECT:
         case TYP_ENTITY_ROW:
         case TYP_VIEW_ROW:
            return (Row)source;
         default:
      }
      return null;
   }

   /**
   * @return  The programmatic name of the property that was changed.
   *		May be null if multiple properties have changed.
   */
   public String getAttributeName() 
   {
      return (attributeDef != null) ? attributeDef.getName() : getSourceFullName();
   }

   public AttributeDef getAttributeDef()
   {
      return attributeDef;
   }
   
   /**
   * @return  The new value for the property, expressed as an Object.
   *		May be null if multiple properties have changed.
   */
   public Object getNewValue() 
   {
      return newValue;
   }
   
   /**
   * @return  The old value for the property, expressed as an Object.
   *		May be null if multiple properties have changed.
   */
   public Object getOldValue() 
   {
      return oldValue;
   }

   public String getSourceFullName()
   {
      return sourceFullName;
   }

   public int getSourceType()
   {
      return sourceType;
   }
   
}
