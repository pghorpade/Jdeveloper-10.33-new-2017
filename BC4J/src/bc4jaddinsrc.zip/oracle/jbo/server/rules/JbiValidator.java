/*
 * @(#)JbiValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import oracle.jbo.server.util.VetoableChangeListener;

/**
 * The principal interface for validator classes.
 * <p>
 * Validators are subscribers to events related to adding, deleting,
 * or changing attribute values.
 * @since JDeveloper 3.0
 */
/* implementations have to implement. This validator interface
 * is a subclass of VetoableChangeListener, so the implementing
 * classes have to implement that interface too. This facilitates
 * adding the validators to any vetoableChange event for reuse.
 * 
 */
public interface  JbiValidator extends VetoableChangeListener
{
  /**
    * Tests the validity of an attribute value.
    * <p>
    * @param value  a value.
    * @return <code>true</code> if the value is valid.
    */
  /*
   * Method that gets invoked to ascertain that the validator has
   * validated the changes it listens to in the vetoableChange
   * event.
   **/ 
   //for now throw a simple exception because, domainvalidators also 
   // implement this interface and may not have access to runtime
   // exception classes. We may have to comeup with a common Java Tools
   // base-exception which can be thrown here.
   abstract public boolean validateValue(Object value);

   /**
   * Gets the text description of this validator.
   * @return a textual description.
   **/
   abstract public String getDescription();

   /**
   * Sets the text description of this validator.
   * @param description a textual description.
   **/
   abstract public void setDescription( String description);

}                  
