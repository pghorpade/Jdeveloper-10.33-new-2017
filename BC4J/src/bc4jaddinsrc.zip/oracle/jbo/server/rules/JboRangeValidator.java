/*
 * @(#)JboRangeValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.domain.DomainInterface;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.rules.JbiValidator;
import oracle.jbo.server.util.Variant;

/**
 * A validator that tests if a literal value lies within a pre-defined range.
 * <p>
 * @since Jdeveloper 3.0
 */
/*
 * A jbo validator implementing RangeValidator interface.
 * This validator stores the minimum and maximum values within
 * which an attribute value should lie. Note we can set this
 * up to support range-inclusive, range-exclusive values.
 *
 * @version PUBLIC
 **/
public class JboRangeValidator extends JboBaseValidator 
                               implements JbiValidator
{
    //Ascertains that the newValue is within two literals or attributes. 
    Object m_min;
    Object m_max;
    Object m_owner;
    AttributeDefImpl mLAttr;

    protected void initialize()
    {
       super.initialize();
       m_min = mValidatingAttr.convertToJava(m_min);
       m_max = mValidatingAttr.convertToJava(m_max);
    }
    /**
     * Creates an uninitialized range validator.
     * <p>
     * The methods <code>setMin()</code> and <code>setMax()</code>
     * must be invoked to set the range.
     **/
    public JboRangeValidator()
    {
       mbInverse = false;
       setDefaultDescription(CSMessageBundle.STR_VAL_DESC_LIST_VALIDATOR);
    }

    /**
     * Creates a range validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * comparison relation is inverted.
     * @param minValue the least value of the range.
     * @param maxValue the greatest value of the range.
     **/
    public JboRangeValidator(boolean inverse, Object minValue, Object maxValue)
    {
       mbInverse = inverse;
       setMin(minValue);
       setMax(maxValue);
       setDefaultDescription(CSMessageBundle.STR_VAL_DESC_LIST_VALIDATOR);
    }

    /**
      * after setting the new value, prepare the comparator
      * to be of same type if it is not already so.
      */
    protected void setNewValue(Object newValue) throws Exception
    {
       Object val = newValue; //.setNewValue(newValue);
       if(val != null && m_max.getClass() != val.getClass() )
       {
          m_max = TypeFactory.getInstance(val.getClass(), m_max);
          m_min = TypeFactory.getInstance(val.getClass(), m_min);
       }
    }

    /**
      * Validates that a value is in a pre-defined range.
      * <p>
      * The range is set using the <code>setMin()</code> and
      * <code>setMax()</code> methods.
      * <p>
      * This method is called by <code>JboBaseValidator#vetoableChange()</code>.
      *
      * @param value the object to be validated.
      * @return <code>true</code> if the relation is in the range.
      */
    /*
    * Get the value of the attribute and find a variant matching he
    * value. Variant allows comparision of two values without worrying
    * about their data-types. It'd throw if the data on rhs is non-convertible
    * to the type of value on lhs of the operation.
    * The oracle.jbo.server.util.Variant implementation is used to perform comparision.
    **/
    public boolean validateValue(Object value)
    {
       if (value == null || value.toString().length() == 0)
       {
           return true;
       }

       Variant lVariant = getVariant(value);

       return ((lVariant.compareTo(getVariant(m_max)) <= 0)
               && (lVariant.compareTo(getVariant(m_min)) >= 0));
    }

    /**
    * Sets the minimum value for the range.
    * @param minValue the new minimum value.
    **/
    public void setMin( Object minValue )
    {
       m_min = minValue;
    }
    
    /**
    * Sets the maximum value for the range.
    * @param maxValue the new maximum value.
    **/
    public void setMax( Object maxValue) 
    {
       m_max = maxValue;
    }

    /**
    * Gets the minimum value for the range.
    * @return the minimum value.
    **/
    public Object getMin( )
    {
       return m_min;
    }
    
    /**
    * Gets the maximum value for the range.
    * @return the maximum value.
    **/
    public Object getMax( )
    {
       return m_max;
    }

    /**
    * set the left-side attribute that is to be compared. Also,
    * set the owner of this validator.
    **/
/*
    void setLhs(AttributeDefImpl lValue, AttributeDefImpl owner)
    {
       mLAttr = lValue;
       m_owner  = owner;
    }
*/     
     /**
       * Based on the objValue's class(AttributeDefImpl) either
       * the variant should get it's data from the Attribute
       * or it is a valid variant data itself.
       * Returns a oracle.jbo.server.util.Variant class which covers all
       * Java datatypes.
       */
     Variant getVariant(Object objValue)
     {
        //return value of the lhs.
        Variant variant = new Variant();
        Object  data = null;
        if( objValue instanceof AttributeDefImpl )
        {
           AttributeDefImpl jboAttr = (AttributeDefImpl)objValue;
           //data = jboAttr.getCurrentValue();
           //need to get the actual value of the data here
           //decided at runtime?
           variant.setInt(0);
        }
        else if( objValue instanceof DomainInterface  )
        {
           data = ((DomainInterface)objValue).getData();
        }
        else
        {
           data = objValue;
        }

        //switch on datatype to get proper variant.
        if( data instanceof Number )
        {
           if( data instanceof Integer )
           {
              variant.setInt( ((Integer)data).intValue());
           }
           else
           if( data instanceof Short )
           {
              variant.setShort( ((Short)data).shortValue());
           }
           else
           if( data instanceof Long )
           {
              variant.setLong( ((Long)data).longValue());
           }
           else
           if( data instanceof Float )
           {
              variant.setFloat( ((Float)data).floatValue());
           }
           else
           if( data instanceof Double )
           {
              variant.setDouble( ((Double)data).doubleValue());
           }
           else
           if( data instanceof BigDecimal )
           {
              variant.setBigDecimal( (BigDecimal)data );
           }
           else
           if( data instanceof BigInteger )
           {
              /*variant.setBigInteger( (BigInteger)data );*/
              variant.setLong(((Number)data).longValue());
           }
           else
           if( data instanceof Byte )
           {
              variant.setByte( ((Byte)data).byteValue());
           }
           else
           {
              //just in case.
              variant.setDouble( ((Number)data).doubleValue());
           }
        }
        else 
        if( data instanceof String )
        {
           variant.setString((String)data);
        }
        else 
        if( data instanceof Time )
        {
           variant.setTime( ((Time)data));
        }
        else 
        if( data instanceof Timestamp )
        {
           variant.setTimestamp( ((Timestamp)data));
        }
        else 
        if( data instanceof Date )
        {
           variant.setDate( ((Date)data));
        }
        else
        {
           //dummy
           variant.setObject(data);
        }
        
        return variant;
     }

    /**
    * <b>Internal:</b> <em>For debugging only.</em>
    **/
    public String toString()
    {
       return new String("Range("+m_min.toString()+m_max.toString()+")");
    }

    
}
