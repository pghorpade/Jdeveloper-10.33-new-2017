/*
 * @(#)JboListValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.util.Vector;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.rules.JbiValidator;

/**
 * A validator that tests for the presence of a literal value in a
 * list of pre-defined values.
 * @since Jdeveloper 3.0
 */
/*
 * A jbo Validator Implementation for ListValidator Interface
 * Implements a validator for an attribute value such that if
 * the value exists in a set of "predefined" values, it succeeds
 * else throws.
 *
 * @version PUBLIC
 */
public class JboListValidator extends JboBaseValidator 
                              implements JbiValidator 
{
    //Ascertains that the newValue is one of the given list of values. 
    //These values can be taken from another EO, or a whole new query. 
    AttributeDefImpl mLAttr;
    Vector mList;
    Object mOwner;

/*    public JboListValidator()
    {
       mbInverse = false;
    }
*/    
    /**
     * Creates an uninitialized list validator.
     * <p>
     * Invoke <code>setList()</code> to provide a list of comparison values.
     **/
    public JboListValidator()
    {
       setDefaultDescription( CSMessageBundle.STR_VAL_DESC_LIST_VALIDATOR );
    }

    JboListValidator(boolean bInverse)
    {
       mbInverse = bInverse;
       setDefaultDescription( CSMessageBundle.STR_VAL_DESC_LIST_VALIDATOR );
    }

    /**
     * Creates a list validator.
     * <p>
     * @param inverse  if <code>true</code> the logic of this validator's
     * test is inverted.
     * @param vec a list of comparison values.
     **/
     public JboListValidator(boolean inverse, Vector vec)
    {
       mbInverse = inverse;
       setList(vec);
       setDefaultDescription( CSMessageBundle.STR_VAL_DESC_LIST_VALIDATOR );
    }
    
    /**
      * Validate that an object is present in a list of values.
      * <p>
      * The list of test values is set by <code>setList</code>.
      * <p>
      * This method is called by <code>JboBaseValidator#vetoableChange()</code>.
      *
      * @param value the object to be validated.
      * @return <code>true</code> if <code>value</code> is in this validator's
      * list of values.
      */
    /*
      * if mList is set, compare the mLValue 'operand' with 
      * all values in the list 
      * else, execute the sql and validate the mLValue.
      * ??==>> How can this operation be improved?
      */
    public boolean validateValue(Object value) 
    {
        if (value == null || value.toString().length() == 0)
        {
           return true;
        }

       //note this getList stuff is overridden
       Vector list = getList();
       
       if( list != null )
       {
          Object listVal;
          for( int i = 0; i < list.size(); i++ )
          {
             listVal = list.elementAt(i);
             if(listVal != null && (listVal.toString()).
                          compareTo(value.toString().trim()) == 0 )
             {
                return true;
             }
          }
       }
       return false;
    }

    /**
      * Sets this validator's list of comparison values.
      * @param vec  a list of values.
      */
    public void setList( Vector vec )
    {
       mList = vec;
    }
    
    /**
      * Gets this validator's list of comparison values.
      * @return  a list of values.
      */
    public Vector getList( )
    {
       return mList;
    }
    
    // set the list of values to be compared against. 

     //it has to be an attribute
     /**
     * set the comparator attribute and the owner of this validator.
     **/
/*     void setLhs(AttributeDefImpl lValue, AttributeDefImpl  owner)
     {
        mLAttr = lValue;
        mOwner  = owner;
     }
*/     
    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
     public String toString()
     {
        String str = "List(";
        if( mList != null )
        {
           for( int i = 0; i < mList.size(); i++ )
           {
              str+= mList.elementAt(i).toString();
              str+=" ";
           }
        }
        str += ")";
        return str;
     }

     /**
      * Converts a string representation of values to a vector.
      * <p>
      * @param listVal a string containing values separated by <code>":"</code> characters.
      */
     public static Vector convertToVector(String listVal)
     {
        Vector v = new Vector(8);
        int index = listVal.indexOf(":");
        int bIndex = 0;

        if ( index == -1 )
        {
           v.addElement(listVal);
           return v;
        }
        while ( index != -1 )
        {
           v.addElement(listVal.substring(bIndex, index));
           bIndex = index + 1;
           index = listVal.indexOf(":", bIndex);
        }
        return v;
     }
}
