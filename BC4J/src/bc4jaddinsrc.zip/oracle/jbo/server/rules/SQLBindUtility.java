/*
 * @(#)SQLBindUtility.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.lang.reflect.Method;

//utility class that is created only by itself, however,
//the entry point for the class is the static method processSQL.
class SQLBindUtility
{
   protected SQLBindUtility()
   {
   }
   

   public static String processSQL(Object bo,
                                   String inSQL)
   {
      StringBuffer outSQL = new StringBuffer(100);
      int inIndex = 0;
      int inLen = inSQL.length();
      
      while ( inIndex < inLen )
      {
         if ( inSQL.charAt(inIndex) == '%' )
         {
            int start = inIndex;
            int end = inSQL.indexOf('%', inIndex+1);

            if ( end < -1 )
            {
               end = inSQL.length();
            }

            outSQL.append(getValue(bo, inSQL.substring(start+1, end)));
            inIndex = end+1;
         }
         else
         {
            outSQL.append(inSQL.charAt(inIndex++));
         }
      }

      return outSQL.toString();
   }


   private static String getValue(Object bo,
                                  String varName)
   {
      Class cls = bo.getClass();
      try
      {
         Method mth = cls.getMethod("get"+varName, new Class[0]);
         return "" + mth.invoke(bo, new Class[0]);
      }
      catch( Exception e )
      {
         return "";
      }
   }
}
