/*
 * @(#)JboVOCompareValidator.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.server.Entity;
import oracle.jbo.server.EntityImpl;

/**
 * A validator that tests literal values by comparing them to a database value,
 * using a pre-defined relation.
 * <p>
 * The value to be validated is designated as the left-hand operand of a
 * relation operation.  The validator provides the relation operator and the View Object
 * that accesses the right-hand operand.
 * @since Jdeveloper 3.0
 */
/*
 * A jbo Validator Implementation for CompareValidator Interface
 * This validator gets one of the comparators by executing a SQL.
 * Then it validates the given value by comparing it with the
 * given attribute value using the superclass implementation.
 *
 * @version PUBLIC
 */
public class JboVOCompareValidator extends JboCompareValidator
{
   Object mOwner;
   String mQOAttrName;
   String mQOName;

    /**
     * Creates an uninitialized compare validator.
     * <p>
     * The methods <code>setType()</code> and <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     **/
   public JboVOCompareValidator()
   {
   }

    /**
     * Creates an partially-initialized compare validator.
     * <p>
     * The method <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     * @param inverse  if <code>true</code> the sense of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     **/
   protected JboVOCompareValidator(boolean inverse, int operType)
   {
      super(inverse, operType);
   }

    /**
     * Creates an initialized compare validator.
     * <p>
     * @param inverse  if <code>true</code> the sense of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     * @param owner  the attribute that owns this validator.
     * @param rValue  this validator's right-hand operand;
     * a View Object.
     **/
   public JboVOCompareValidator(boolean inverse, int operType, Object owner, Object rValue)
   {
      super(inverse, operType);
      setOwner(owner);
      setRhsValue(rValue);
   }

     /**
      * Sets the right-side operand of this validator's expression.
      * @param rhsValue  a View Object.
       */
   public void setRhsValue( Object rhsValue)
   {
      mQOName = rhsValue.toString();
      int lastDot = mQOName.lastIndexOf(".");
      
      mQOAttrName = mQOName.substring( lastDot + 1 );
      mQOName = mQOName.substring( 0, lastDot );
   }

     /**
       * Gets the right-side operand of this validator's expression.
       * @return  the first value of the first row of data retrieved by the
       * View Object's SQL statement.
       */
   public Object getRhsValue( )
   {
      if( mSource instanceof Entity )
      {
         ViewObject qref = ((EntityImpl)mSource).getDBTransaction().createViewObject(mQOName);
         Row row = qref.first();
         mRValue = row.getAttribute(mQOAttrName);
         qref.remove();
         //am.removeViewObject("JboVOCompareValidatorUsage");
         return mRValue;
      }
      return super.getRhsValue();
   }

   /**
   * Sets the attribute that owns this validator.
   * @param owner  an attribute.
   **/
   public void setOwner( Object owner )
   {
      mOwner = owner;
   }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
   public String toString()
   {
      return new String("QO Compare( "
                        + getOperatorTypeString()
                        + mRValue.toString()
                        + ")");
   }
}
