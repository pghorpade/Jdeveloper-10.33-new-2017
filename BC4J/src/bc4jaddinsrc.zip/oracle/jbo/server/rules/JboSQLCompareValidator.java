/*
 * @(#)JboSQLCompareValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.SQLStmtException;
import oracle.jbo.server.Entity;
import oracle.jbo.server.EntityImpl;

/*
 * A jbo Validator Implementation for CompareValidator Interface
 * This validator gets one of the comparators by executing a SQL.
 * Then it validates the given value by comparing it with the
 * given attribute value using the superclass implementation.
 *
 * @version PUBLIC
 */
/**
 * A validator that tests literal values by comparing them to a database value,
 * using a pre-defined relation.
 * <p>
 * The value to be validated is designated as the left-hand operand of a
 * relation operation.  The validator provides the relation operator and the SQL
 * statement that retrieves the right-hand operand.
 * @since Jdeveloper 3.0
 */
public class JboSQLCompareValidator extends JboCompareValidator
                                 
{
   Object mOwner;
   String mSQL;

    /**
     * Creates an uninitialized compare validator.
     * <p>
     * The methods <code>setType()</code> and <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     **/
   public JboSQLCompareValidator()
   {
   }

    /**
     * Creates an partially-initialized compare validator.
     * <p>
     * The method <code>setRhsValue()</code>
     * must be invoked before validation can be performed.
     * @param bInverse  if <code>true</code> the sense of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     **/
   protected JboSQLCompareValidator(boolean bInverse, int operType)
   {
      super(bInverse, operType);
   }

    /**
     * Creates an initialized compare validator.
     * <p>
     * @param bInverse  if <code>true</code> the sense of this validator's
     * comparison relation is inverted.
     * @param operType this validator's comparison operator;
     * one of the comparison operator constants defined in this class.
     * @param owner  the attribute that owns this validator.
     * @param rValue  this validator's right-hand operand;
     * an instance of <code>AttributeDefImpl</code>.
     **/
   public JboSQLCompareValidator(boolean bInverse, int operType, Object owner, Object rValue)
   {
      super(bInverse, operType);
      setOwner(owner);
      setRhsValue(rValue);
   }

     /**
      * Sets the right-side operand of this validator's expression.
      * @param rhsValue  a SQL statement.
       */
   public void setRhsValue( Object rhsValue)
   {
      // set the value with which comparision is to be done.
      mSQL = rhsValue.toString();
   }

     /**
       * Gets the right-side operand of this validator's expression.
       * @value  the first attribute of the first row of data retrieved by the
       * SQL statement designated as the right-hand operand.
       */
   public Object getRhsValue()
   {
       String sql = SQLBindUtility.processSQL(mSource, mSQL);

       if( mSource instanceof Entity )
       {
          ResultSet rslt = null;
          PreparedStatement stmt = null;
          try
          {
             stmt = (sql.substring(0,5).equalsIgnoreCase("BEGIN"))
                    ? ((EntityImpl)mSource).getDBTransaction().createCallableStatement(sql, 1)
                    : ((EntityImpl)mSource).getDBTransaction().createPreparedStatement(sql, 1);

             rslt = stmt.executeQuery();
             if (rslt.next()) 
             {
                mRValue = rslt.getObject(1);
                return mRValue;
             }
          }
          catch (Exception ex)
          {
             throw new SQLStmtException(CSMessageBundle.class,
                                        CSMessageBundle.EXC_SQL_EXECUTE_QUERY,
                                        sql, ex);
          }
          finally
          {
             try
             {
                if (rslt != null)
                {
                   rslt.close();
                }
                if (stmt != null)
                {
                   stmt.close();
                }
             }
             catch(SQLException ex)
             {
             }
          }
       }
       return super.getRhsValue();
   }

   /**
   * Sets the attribute that owns this validator.
   * @param owner  an attribute.
   **/
   public void setOwner( Object owner )
   {
      mOwner = owner;
   }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
   public String toString()
   {
      return new String("SQL Compare( "
                        + getOperatorTypeString()
                        + mRValue.toString()
                        + ")");
   }
}
