/*
 * @(#)JboGenericValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Vector;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.common.JBOClass;
import oracle.jbo.domain.DomainInterface;
import oracle.jbo.domain.TypeFactory;
import oracle.jbo.server.ValidationBeanLoader;
import oracle.jbo.server.util.PropertyChangeEvent;
import oracle.jbo.server.util.Variant;

/**
 * A validator for domain attributes.
 * <p>
 * This validator tests whether a domain object lies in a specified range, or is one of a set
 * of specified values.  The object's precision may also be validated.
 * <p>
 * An object will be tested against a list of values if the list is not <code>null</code>.
 * Use <code>setList()</code> to provide the list.  When the list is <code>null</code>
 * (the default), the object is tested instead against the range, which is specified
 * by <code>setMin()</code> and <code>setMax()</code>.
 * <p>
 * Use <code>setPrec()</code> to specify the precision.
 * @see TypeFactory
 * @since Jdeveloper 3.0
 */
public class JboGenericValidator
                                implements GenericValidator, java.io.Serializable
{
    //Ascertains that the newValue is within two literals or attributes.
    Object mOwner;
    Object mMin = null;
    Object mMax = null;
    java.util.Vector mList = null;
    java.util.Vector mVariantList = new Vector(); //mList shud be null initially.
    String mPrec;
    String mScale;
    int mPrecision;
    int mScaleInt;
    boolean mUpdateable = true;
    Class mType = null;
    boolean mbSetup = false;
    boolean mbInSetup = false;
    //DomainInterface mLValue;
    Object mLValue;
    String mDescription;


     /**
      * Creates an uninitialized validator.
      * <p>Use "set" methods to provide validation parameters.
     **/
     public JboGenericValidator()
    {
       mDescription = "Temporary";
    }

    /**
      * Validates that a domain object is within this validators precision and
      * range or set of values.
      * @param value the object to be validated.
      * @return <code>true</code> if the object's precision and value are within specified
      * limits, and the validator is updateable.
     */
    public boolean validateValue(Object value)
    {
       if( !mbSetup )
       {
          if( !mbInSetup )
          {
             //just do this one time.
             mbInSetup = true;
             if( mMin != null )
             {
                mMin = convertType(mMin);
             }
             if( mMax != null )
             {
                mMax = convertType(mMax);
             }
             if( mList != null )
             {
                mList = convertList(mList);
             }
             mbSetup = true;
             mbInSetup = false;
          }             
          else
          {  
             //should come here only in case of convertType() 
             return true;
          }
       }
       
       Variant lVariant = getVariant(value);

       boolean bOK = !(lVariant == null);
       if( ! bOK || ! mUpdateable)
       {
          return false;
       }

       if( mVariantList.size() > 0 )
       {
          //list validation.
          bOK = false;
          for( int i = 0; i < mVariantList.size(); i++ )
          {
             if( lVariant.compareTo((Variant)mVariantList.elementAt(i)) == 0)
             {
                bOK = true;
             }
          }
          if( !bOK )
          {
             return bOK;
          }
       }
       else
       {
          //range validation
          if( mMax != null )
          {
             bOK = (lVariant.compareTo(getVariant(mMax)) < 0);
             if( ! bOK )
             {
                return bOK;
             }
          }
       
          if( mMin != null )
          {
             bOK = (lVariant.compareTo(getVariant(mMin)) > 0);
             if( ! bOK )
             {
                return bOK;
             }
          }
       }
     
       if( (lVariant.toString() !=null) && mPrec != null)
       {
          bOK = lVariant.toString().length() <= mPrecision;
          if( ! bOK )
          {
             System.out.println("Failed - "+lVariant);
             return bOK;
          }
       }

       //test for precision, scale, uniqueness.
       return bOK;
    }

    /**
    * Gets the list of valid values.
    * <p>
    * @return  a vector containing the valid values.
    */
    public java.util.Vector getList()
    {
       if( mList != null )
       {
          return (Vector)mList.clone();
       }
       return null;
    }
    
    /**
    * Gets the minimum bound of the valid range.
    * <p>
    * @return  the least valid value.
    */
    public Object getMin( )
    {
       return mMin;
    }
    
    /**
    * Gets the maximum bound of the valid range.
    * <p>
    * @return  the greatest valid value.
    */
    public Object getMax( )
    {
       return mMax;
    }

    /**
    * Gets the SQL numeric precision.
    * <p>
    * @return a string representation of the number of significant digits.
    */
    public String getPrec()
    {
       return mPrec;
    }
    
    /*
    public String getScale()
    {
       return mScale;
    }
    */
    
    /**
    * Reports whether this validator allows updating.
    * <p>
    * @return
    * <p>  <code>false</code> if {@link #validateValue(java.lang.Object)} is forced
    * to return <code>false</code>, and {@link #vetoableChange(PropertyChangeEvent)} is forced to fail.
    * <p>  <code>true</code> if validation is performed.
    */
    public boolean isUpdateable()
    {
       return mUpdateable;
    }
    
    /**
    * Sets the list of valid values.
    * <p>
    * @param vec  a list containing the new valid values.
    */
    public void setList( java.util.Vector vec )
    {
       mList = vec;
    }

    /**
    * Sets the minimum bound of the valid range.
    * <p>
    * @param minValue  the new least valid value.
    */
    public void setMin( Object minValue )
    {
       mMin = minValue;
    }
    
    /**
    * Sets the maximum bound of the valid range.
    * <p>
    * @param maxValue  the new greatest valid value.
    */
    public void setMax( Object maxValue)
    {
       mMax = maxValue;
    }

    /**
    * Sets the SQL numeric precision.
    * <p>
    * @param prec a string representation of the new number of significant digits.
    */
    public void setPrec( String prec)
    {
       mPrec = prec;
       try
       {
          mPrecision = Integer.valueOf(prec).intValue();
       }
       catch (Exception e)
       {
          mPrecision = -1;
       }
    }

    /*
    public void setScale( String scale)
    {
       mScale = scale;
       try
       {
          mScaleInt = Integer.valueOf(scale).intValue();
       }
       catch (Exception e)
       {
       }
    }
    */

    /**
    * Enables or disables validation.
    * <p>
    * @param val  if <code>false</code>, <code>validateValue()</code> is forced
    * to return <code>false</code>, and <code>vetoableChange()</code> is forced to fail.
    */
    public void setUpdateable( boolean val )
    {
       mUpdateable = val;
    }

    public void setTypeInfo( String type )
    {
       try {
          mType = JBOClass.forName(type);
       }
       catch(ClassNotFoundException cnfe)
       {
          //ignore.
       }
    }
    
   /**
    * <b>Internal:</b> <em>Applications should not use this method.</em>
    */
     public void setLhs(DomainInterface lValue)
     {
        if(!mbInSetup)
        {
            mLValue = lValue;
        }
     }
     
     /**
       * Based on the objValue's class(AttributeDescriptor) either
       * the variant should get it's data from the Attribute
       * or it is a valid variant data itself.
       * Returns a oracle.jbo.server.util.Variant class which covers all
       * Java datatypes.
       */
     Variant getVariant(Object objValue)
     {
        //return value of the lhs.
        Variant variant = new Variant();
        Object  data = null;
        if ( objValue instanceof DomainInterface )
        {
           data = ((DomainInterface)objValue).getData();
        }
        else
        {
           data = objValue;
        }

        //switch on datatype to get proper variant.
        if( data instanceof java.lang.Number )
        {
           if( data instanceof Integer )
           {
              variant.setInt( ((Integer)data).intValue());
           }
           else
           if( data instanceof Short )
           {
              variant.setShort( ((Short)data).shortValue());
           }
           else
           if( data instanceof Long )
           {
              variant.setLong( ((Long)data).longValue());
           }
           else
           if( data instanceof Float )
           {
              variant.setFloat( ((Float)data).floatValue());
           }
           else
           if( data instanceof Double )
           {
              variant.setDouble( ((Double)data).doubleValue());
           }
           else
           if( data instanceof BigDecimal )
           {
              variant.setBigDecimal( (BigDecimal)data );
           }
           else
           if( data instanceof BigInteger )
           {
              /*variant.setBigInteger( (BigInteger)data );*/
              variant.setLong(((java.lang.Number)data).longValue());
           }
           else
           if( data instanceof Byte )
           {
              variant.setByte( ((Byte)data).byteValue());
           }
           else
           {
              //just in case.
              variant.setDouble( ((java.lang.Number)data).doubleValue());
           }
        }
        else 
        if( data instanceof String )
        {
           variant.setString((String)data);
        }
        else 
        if( data instanceof Time )
        {
           variant.setTime( ((Time)data));
        }
        else 
        if( data instanceof Timestamp )
        {
           variant.setTimestamp( ((Timestamp)data));
        }
        else 
        if( data instanceof Date )
        {
           variant.setDate( ((Date)data));
        }
        else
        {
           //dummy
           variant.setObject(data);
        }
        
        return variant;
     }

    /**
      * Generates a Java code fragment that invokes this validator.
      * @return <code>"Range(<em>min</em>, <em>max</em>)"</code>.
      */
     public String toString()
     {
        return "JboGenericValidator";
     }

     private Object convertType( Object obj )
     {
        try {
           if( obj instanceof String && mType != null )
           {
              return TypeFactory.getInstance(mType, (String)obj);
           }
        }
        catch(Exception e)
        {
           //ignore.
        }
        return obj;
     }

     private Vector convertList( Vector vec )
     {
        Vector newVec = new Vector(vec.size());
        mVariantList = new Vector(vec.size());
        Object obj;
        for( int i = 0; i < vec.size(); i++ )
        {
           //get the element from old vec.
           //convert it to proper type.
           //add to new vec.
           obj = convertType(vec.elementAt(i));
           newVec.addElement(obj);
           mVariantList.addElement(getVariant(obj));
        }
        return newVec;
     }

    /**
      * Invokes <code>validateValue()</code> on a value contained in a constrained property.
      * <p>.
      * @param evObj  a <code>PropertyChangeEvent()</code> containing a property
      * to be validated.
      * @throws JboException if validation fails, with <code>CSMessageBundle</code>
      * error code <code>EXC_VAL_ATTR_SET_FAILED</code>.
      */
    public void vetoableChange(PropertyChangeEvent evObj)
                throws JboException
    {
       //do nothing.
       //try
       {
          //TypeFactory.getInstance(mType, evObj.getNewValue());
          mType = evObj.getNewValue().getClass();
          mLValue = (evObj.getNewValue());
          if( !validateValue(mLValue) )
          {
             ValidationBeanLoader.raiseException(CSMessageBundle.class,
                                     CSMessageBundle.EXC_VAL_ATTR_SET_FAILED,
                                     evObj.getSource(),
                                     evObj.getPropertyName(),
                                     mLValue,
                                     null, null);
          }
       }
    }
    
     
    /**
    * Gets the textul description of this validator.
    * @return  a documentation string.
    **/
    public String getDescription()
    {
       return mDescription;
    }

    /**
    * Sets the textul description of this validator.
    * @param description  a documentation string.
    **/
    public void setDescription( String description)
    {
       mDescription = description;
    }
}
