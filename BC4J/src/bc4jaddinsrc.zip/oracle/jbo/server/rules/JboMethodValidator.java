/*
 * @(#)JboMethodValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.beans.MethodDescriptor;
import java.lang.reflect.Method;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.common.StringManager;
import oracle.jbo.server.ApplicationModuleImpl;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.Entity;
import oracle.jbo.server.ValidationBeanLoader;
import oracle.jbo.server.rules.JbiValidator;
import oracle.jbo.server.util.PropertyChangeEvent;

//import oracle.jbo.dt.objects.*;
/*
 * A jbo Validator Implementation for MethodValidator Interface
 * This validator implements the methods adapater where, given a
 * method name, trys to find that method in the object being validated
 * and invokes that method for validation. Note that the validating
 * method has to be public, return boolean
 *
 * @version PUBLIC
 */
/**
 * A validator that tests values by passing them to a validation method.
 * <p>
 * The validation method must be public,
 * take a single <code>Object</code> parameter and return <code>Boolean</code>.
 * @since Jdeveloper 3.0
 */
public class JboMethodValidator  // TODO: Karl - removed temporarily
                                 // Note that smoke.sv01 now fails!
                                 // extends JboBaseValidator
                                 implements JbiValidator
{
    //Passes the newValue to the selected method for validation.
    //This would allow users to add-in their method validations by
    //providing a new method and wiring it up as a method
    //validation on the EO or attribute.
    MethodDescriptor m_method;
    String m_methodName;
    Object m_obj;
    Object m_lValue;
    String mDescription;

     /**
     * Creates a validator without assigning its validation method.
     **/
     public JboMethodValidator()
     {
        m_methodName  = "";
        mDescription = StringManager.getString("oracle.jbo.CSMessageBundle",
                         CSMessageBundle.STR_VAL_DESC_METHOD_VALIDATOR,
                         null,
                         null);
     }

     /**
     * Creates a validator given the name of the validation method.
      * @param methodName  the name of a Java method.  The method must be public,
      * take a single <code>Object</code> parameter and return <code>Boolean</code>.
     **/
     public JboMethodValidator(String methodName, Class entityClz, Class clz)
     {
        m_methodName  = methodName;
        mDescription = StringManager.getString("oracle.jbo.CSMessageBundle",
                         CSMessageBundle.STR_VAL_DESC_METHOD_VALIDATOR,
                         null,
                         null);
        setObjectMethod(entityClz, clz);
     }

    /**
      * Invokes <code>validateValue()</code> on a value contained in a constrained property.
      * <p>
      * @param evObj  a <code>PropertyChangeEvent()</code> containing a property
      * to be validated.
      * @throws JboException if validation fails.
      */
    public void vetoableChange(PropertyChangeEvent evObj)
    {
        //pass on the PropertyChangeEvent object itself.
        //m_lValue = evObj.getNewValue();
        m_lValue = evObj.getNewValue();
        m_obj    = evObj.getSource();
        
        boolean retVal = false;
        Exception retEx = null;
        try 
        {
            retVal = validateValue(m_lValue);
        }
        catch( Exception e )
        {
           retEx = e;
        }
        finally
        {
           //if not an instance of JboException,
           if( ! (retEx instanceof JboException) )
           {
              //see if validateValue returned false or threw
              //some user exception. If user exception,wrap
              //it in a ValidationException appropriately.
              if( retEx != null || retVal == false )
              {
                 String errorCode = (m_lValue instanceof Row) ?
                                       CSMessageBundle.EXC_VAL_METHOD_ON_ROW_FAILED :
                                       CSMessageBundle.EXC_VAL_METHOD_ON_ATTR_SET_FAILED;

                 ValidationBeanLoader.raiseException(CSMessageBundle.class,
                                                     errorCode,
                                                     m_obj,
                                                     evObj.getPropertyName(),
                                                     evObj.getNewValue(),
                                                     getMethodName(),
                                                     retEx);
              }
           }
        }

        //now retEx has to be a validation exception, so its safe
        //to only check for null.
        if( retEx != null )
        {
           throw (JboException)retEx;
        }
    }

    /**
      * Validate an object by passing it to the validation method.
      *
      * @param value the object to be validated.
      * @return <code>false</code> if the validation method cannot be found or
      * if the validation method throws an exception that
      * is not a instance of <code>JboException</code>.
      * Otherwise, pass on the boolean value returned by the validation method.
      * @throws JboException if the validation method throws an instance of
      * <code>JboException</code>.
      */
    public boolean validateValue(Object value) throws JboException
    {
       //note : newvalue here is the eventobject.
       if( m_method != null )
       {
          Object arr[];
          if( isValidatingAttribute() )
          {
             arr = new Object[1];
             arr[0] = value;
          }
          else
          {
             arr = new Object[0];
          }
          try
          {
             Boolean result = (Boolean)m_method.getMethod().invoke(m_obj, arr);
             return result.booleanValue();
          }
          catch( java.lang.reflect.InvocationTargetException ite )
          {
             if( ite.getTargetException() instanceof JboException )
             {
                throw (JboException)ite.getTargetException();
             }
          }
          catch( Exception e )
          {
             //ignore as return false would throw this. However
             //print diagnostic message.
             Diagnostic.println( "MethodValidation:"+e.getMessage());
          }
       }
       //return false by default coz, it means, no method was found
       //for a method validator.
       return false;
    }

    /**
      * set a "custom" method that takes in the eventObject
      * as it's parameter.
      */
    //public void setMethod(Object obj, Method  mth )
    //{
    //   m_method = mth;
    //   m_obj = obj;
    //}

     /**
      * Sets the name of the method invoked by this validator.
      * @param mthName  the name of a Java method.  The method must be public,
      * take a single <code>Object</code> parameter and return <code>Boolean</code>.
      */
   public void setMethodName(String mthName)
    {
       m_methodName = mthName;
    }

    private boolean isValidatingAttribute()
    {
       return !( m_lValue instanceof Entity ||
                m_lValue instanceof ApplicationModuleImpl );
    }

    /**
    * This implementation finds the given method in the given
    * object and stores the Method reference for invocation by
    * validateValue.
    **/
    private void setObjectMethod(Class entityClz, Class attrClaz)
    {
       //find method name in method.
       if( m_method == null )
       {
          try {
             Method mth;
             if(attrClaz!= null)
             {
                //validateATTRIBUTE(ATTRIBUTEDATATYPE)
                mth = JboNameUtil.findMethod( entityClz,
                                              m_methodName, 
                                              new Class[] {attrClaz}, 
                                              null );
             }
             else
             {
                //validateEntity, validateWork
                mth = JboNameUtil.findMethod( entityClz, 
                                              m_methodName, 
                                              new Class[] {}, 
                                              null );
             }
             
             m_method = new MethodDescriptor(mth);
             
          }
          catch (Exception e)
          {
             //return some error.
             e.printStackTrace();
          }
       }
    }

    /**
      * Gets the name of the method invoked by this validator.
      * @return the name of a Java method.
      */
    public String getMethodName()
    {
       return m_methodName;
    }

    /**
      * Gets the method invoked by this validator.
      * @return a <code>method</code> object, a description of a Java method.
      */
    public Method getMethod( )
    {
       if( m_method != null )
       {
          return m_method.getMethod();
       }
       return null;
    }

    /**
      *  Set the Owner attribute of this validator.
      */
    void setLhs(AttributeDefImpl lValue, AttributeDefImpl  owner)
    {
       //nooop
    }

     /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
   /*
      * Generates a Java code fragment that invokes this validator.
      * @return <code>"Method()"</code>.
      */
    public String toString()
    {
       return new String("Method("+")");
    }

    /**
    * Gets the textul description of this validator.
    * @return  a documentation string.
    **/
    public String getDescription()
    {
       return mDescription;
    }

    /**
    * Sets the textul description of this validator.
    * @param description  a documentation string.
    **/
    public void setDescription( String description)
    {
       mDescription = description;
    }
}
