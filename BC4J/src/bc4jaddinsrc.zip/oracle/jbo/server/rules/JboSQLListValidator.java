/*
 * @(#)JboSQLListValidator.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server.rules;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;
import oracle.jbo.SQLStmtException;
import oracle.jbo.server.EntityImpl;

//import oracle.jbo.dt.objects.*;
/**
 * A validator that tests for the presence of a literal value in a
 * list of database values.
 *
 * The list of values is
 * obtained by invoking the validator's SQL query, and then taking the values from the
 * first column of the result.
 * @since Jdeveloper 3.0
 */
/*
 * A jbo Validator Implementation for JboSQLListValidator Interface
 * This class simply provides a list of values to its superclass
 * by executing a SQL statement whenever the LOV is desired.
 *
 * @version PUBLIC
 */
public class JboSQLListValidator extends JboListValidator
{
    String mSQL;

    /**
     * Creates an uninitialized list validator.
     * <p>
     * Invoke <code>setSQL()</code> to provide a list of comparison values.
     **/
    public JboSQLListValidator( )
    {
    }

    /**
     * Creates a list validator.
     * <p>
     * @param bInverse  if <code>true</code> the logic of this validator's
     * test is inverted.
       * @param str  an SQL statement.
     **/
    public JboSQLListValidator( boolean bInverse, Object owner, String str )
    {
       super(bInverse);
       mOwner = owner;
       mSQL = str;
    }

    /**
      * Sets this validator's SQL statement.
      * @param str an SQL statement.
      */
    public void setSQL( String str )
    {
       mSQL = str;
    }

    /**
      * Gets this validator's SQL statement.
      * @return an SQL statement.
      */
    public String getSQL( )
    {
       return mSQL;
    }

    /**
      * Gets this validator's list of values.
      * <p>
      * This method executes the validator's SQL statement and extracts and the
      * first column of the result.
      * @return a vector containing the values from the first column of the result.
      */
    /*
      * get LOV by executing the SQL statement. Note the assumption
      * that the LOV is defined by the first column of the SQL.
      */
    public Vector getList( )
    {
       //execute the SQL and return the list.
       try
       {
          if (mList != null)
          {
             mList.removeAllElements();
             mList = null;
          }
          mList = new Vector();

          String sql = SQLBindUtility.processSQL(mSource, mSQL);

          if(mSource instanceof EntityImpl)
          {
             // populate the choice field with the available tables
             ResultSet rslt = null;
             PreparedStatement stmt = null;
             try
             {
                stmt = (sql.substring(0,5).equalsIgnoreCase("BEGIN"))
                       ? ((EntityImpl)mSource).getDBTransaction().createCallableStatement(sql, 1)
                       : ((EntityImpl)mSource).getDBTransaction().createPreparedStatement(sql, 1);
   
                rslt = stmt.executeQuery();
                while(rslt.next())
                {
                   mList.addElement(rslt.getString(1));
                }
             }
             catch (Exception ex)
             {
                throw new SQLStmtException(CSMessageBundle.class,
                                           CSMessageBundle.EXC_SQL_EXECUTE_QUERY,
                                           sql, ex);
             }
             finally
             {
                try
                {
                   if (rslt != null)
                   {
                      rslt.close();
                   }
                   if (stmt != null)
                   {
                      stmt.close();
                   }
                }
                catch(SQLException ex)
                {
                }
             }

          }

          /*
          if( mSource instanceof Entity )
          {
             ViewObject qref = ((EntityImpl)mSource).getDBTransaction().createViewObjectFromQueryStmt(sql);
             Row row;
             while( qref.hasNext() )
             {
                row = qref.next();
                mList.addElement( row.getAttribute(0) );
             }
             qref.remove();
          }
          */

       }
       catch(JboException e)
       {
          e.printStackTrace();
          throw e;
       }
       //catch(SQLException e)
       //{
       //   e.printStackTrace();
       //}
       return mList;
    }

    /**
    * <b>Internal:</b> <em>For debugging purposes only.</em>
    * <p>
    */
     public String toString()
     {
        return new String("SQL List("+mSQL+")");
     }

}



