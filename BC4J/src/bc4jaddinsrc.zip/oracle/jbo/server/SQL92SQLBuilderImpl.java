/*
 * @(#)SQL92SQLBuilderImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server;

import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboEnvUtil;
import oracle.jbo.common.PropertyConstants;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;

/**
 * SQL92 specific implementation of the <tt>SQLBuilder</tt> interface.
 * @since JDeveloper 3.2
 */
//26Sep01 - KM - added method for registerDefaultDriver which indirects through
//the jbo.sql92.jdbcdriver property
public class SQL92SQLBuilderImpl extends BaseSQLBuilderImpl
{
   /**
    * OLite specific error code for resource busy exception.
    */
   public static final int ERROR_OLITE_RESOURCE_BUSY_AND_NOWAIT_SPECIFIED = -3264;

   /**
    * Oracle specific column name for ROWID.
    */
   protected static final String ORACLE_ROWID_COLUMN = "ROWID";
   
   /**
    * Member to hold the singleton instance.
    */
   protected static SQLBuilder mSQLBuilderInterface=null;

   /**
    * This is a singleton class.
    */
   protected SQL92SQLBuilderImpl()
   {
   }

   /**
    * Gets the singleton instance of this class.
    * @return a <code>SQLBuilder</code> object.
    */
   public static SQLBuilder getInterface()
   {
      if (mSQLBuilderInterface == null)
      {
         mSQLBuilderInterface = (SQLBuilder)(new SQL92SQLBuilderImpl());

         if (Diagnostic.isOn())
         {
            Diagnostic.println(mSQLBuilderInterface.getVersion());
         }
      }
      return mSQLBuilderInterface;
   }

   //--------------------------------------------------------------------------
   // {{ interface SQLBuilder implementation
   //--------------------------------------------------------------------------

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#getVersion()
    */
   public String getVersion()
   {
      return "SQL92 SQLBuilder version 0.0.0.3";
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#getDbType()
    */
   public String getDbType()
   {
      return PropertyConstants.SQL92;
   }

   /**
    * The default type map for a SQL92 database is Oracle. This
    * is overridden in the subclasses.
    * @return <tt>PropertyConstants.ORACLE</tt> constant.
    */
   public String getTypeMapName()
   {
      // By default, we use OracleTypeMap with generic domain implementation
      return PropertyConstants.ORACLE;
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#getPersistManagerClassName()
    */
   public String getPersistManagerClassName()
   {
      return null;
   }

//--------------------------------------------------------------------------
// }} interface SQLBuilder implementation
//--------------------------------------------------------------------------
   
   /* (non-Javadoc)
    * @see oracle.jbo.server.BaseSQLBuilderImpl#getJDBCDriverClassName(java.lang.String)
    */
   protected String getJDBCDriverClassName(String url)
   {        
      String sDriverClassName = JboEnvUtil.getProperty(PropertyConstants.PN_JDBC_DRIVER_CLASS);

      if (!PropertyConstants.JDBC_ODBC_DRIVER_CLASS.equals(sDriverClassName))
      {
         Diagnostic.println("SQL92: using " + sDriverClassName + " jdbc driver class");
      }

      return sDriverClassName;
   }

   /**
    * Returns the lock trailer from the System properties. Subclasses
    * override this method to provide database specific trailer.
    * @return SQL clause to lock a row in the database.
    */
   protected String getSqlVariantLockTrailer()
   {
      // Jbo system property jbo.sql92.LockTrailer 
      // sql server: "WITH (HOLDLOCK)";
      // default: "FOR UPDATE"
      return PropertyMetadata.PN_SQL92_LOCKTRAILER.getProperty(true);
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.BaseSQLBuilderImpl#getDbTimeQuery()
    */
   public String getDbTimeQuery()
   {
      return JboEnvUtil.getProperty(PropertyConstants.PN_DBTIME_QUERY);
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#getDropTableSQL(java.lang.String)
    */
   public String getDropTableSQL(String dbObjectName)
   {
      if (dbObjectName == null) 
      {
         return null;
      }

      return "DROP TABLE " + dbObjectName;
   }

   public boolean isDisplayBindValueUI()
   {
      return true;
   }

   /**
    * Not implemented. Returns null.
    */
   public String getCreateSequenceInsertTriggerSQL(String triggerName, String tableName,  
                                                   String sequenceName, String colName)   
   {
      return null;
   }
   
   /**
    * Not implemented. Returns null.
    */
   public String getCreateSequenceSQL(String sequenceName, int startVal)
   {
      return null;
   }

   /**
    * Not implemented. Returns null.
    */
   public String getDropSequenceSQL(String sequenceName)
   {
      return null;
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#getQueryHitCountSQL(oracle.jbo.RowSet)
    */
   public String getQueryHitCountSQL(RowSet rs)
   {
      ViewObject vo = rs.getViewObject();
      int noUserParams = rs.getWhereClauseParams().length;
      String qry = ((ViewObjectImpl) vo).buildQuery(noUserParams, true /*forRowCount*/);
      
      if (qry == null)
      {
         return null;
      }
      
      String optimizerHint = vo.getQueryOptimizerHint();
      StringBuffer sqlBuffer = new StringBuffer(100);

      if (optimizerHint == null) 
      {
         sqlBuffer.append("SELECT count(1) FROM (");
      }
      else
      {
         sqlBuffer.append("SELECT /*+ ")
                  .append(optimizerHint)
                  .append(" */ count(1) FROM (");
      }
      
      sqlBuffer.append(qry);

      // KM: 19Oct00 - placed a table alias at the end to keep
      // MS SQL*Server happy - it's optional for Oracle
      sqlBuffer.append(") ESTCOUNT");

      return sqlBuffer.toString();
   }
} // class SQL92SQLBuilderImpl
/* end of file */

