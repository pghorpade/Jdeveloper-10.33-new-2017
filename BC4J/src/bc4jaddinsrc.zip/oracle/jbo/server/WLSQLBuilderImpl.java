/*
 * @(#)WLSQLBuilderImpl.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server;

import java.sql.SQLException;
import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JBOClass;

public class WLSQLBuilderImpl extends OLiteSQLBuilderImpl 
{
   private static SQLBuilder mSQLBuilder = null;

   /**
    * This is a singleton class.
    */
   protected WLSQLBuilderImpl()
   {
       super();
   }

   /**
    * Gets the singleton instance of this class.
    * @return a <tt>SQLBuilder</tt> object.
    */
   public static SQLBuilder getInterface()
   {
      if (mSQLBuilder == null)
      {
         mSQLBuilder = new WLSQLBuilderImpl();
      }
      return mSQLBuilder;
   }

   /* (non-Javadoc)
    * @see oracle.jbo.server.SQLBuilder#doRegisterDefaultDriver(java.lang.String)
    */
   public void doRegisterDefaultDriver(String url)
      throws SQLException
   {
      try
      {
         JBOClass.forName("weblogic.jdbc.jts.Driver").newInstance();

         if (Diagnostic.isOn())
         {
            Diagnostic.println(getClass().getName() + ": Registered JDBC driver");
         }
         
         if (JDBCInteract.mDoTrace)
         {
            JDBCInteract.header();
         }
      }
      catch(Exception ex)
      {
         if (Diagnostic.isOn())
         {
            Diagnostic.printStackTrace(ex);
         }
         
         throw new JboException(ex);
      }

   }

} 

