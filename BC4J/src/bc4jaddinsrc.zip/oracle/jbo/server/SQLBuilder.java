/*
 * @(#)SQLBuilder.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.server;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Vector;
import java.util.Properties;
import java.util.Hashtable;
import javax.sql.DataSource;

import oracle.jbo.AttributeDef;
import oracle.jbo.JboException;
import oracle.jbo.RowSet;
import oracle.jbo.Transaction;
import oracle.jbo.domain.DataCreationException;

// import java.sql.CallableStatement;
/**
 * <b>Internal:</b> <em>Applications should not use this interface.</em>
 * <p>
 * <b>Note:</b> This interface is subject to change.
 * <p>
 * This interface is used by View Objects to construct SQL statements
 * that create, retrieve, update and delete table rows based
 * on the state of the cache.
 * @since JDeveloper 3.0
 */
public interface SQLBuilder
{
   // published interface constants
   // TODO: wrap theses in a typesafe constant class
   /**
    * Constant used to specify the DML mode to be INSERT.
    * @see SQLBuilder#doEntityDML(EntityImpl, int, TransactionEvent)
    */
   public static final int    DML_INSERT = 1;
   /**
    * Constant used to specify the DML mode to be UPDATE.
    * @see SQLBuilder#doEntityDML(EntityImpl, int, TransactionEvent)
    */
   public static final int    DML_UPDATE = 2;
   /**
    * Constant used to specify the DML mode to be DELETE.
    * @see SQLBuilder#doEntityDML(EntityImpl, int, TransactionEvent)
    */
   public static final int    DML_DELETE = 3;

   /**
    * Constant used to specify "Unknown" binding style while
    * binding parameters to a statement object.
    * @see SQLBuilder#doStatementSetBindingStyle(Statement, int)
    */
   public static final int    BINDING_STYLE_UNKNOWN = -1;
   
   /**
    * Constant used to specify JDBC binding style while
    * binding parameters to a statement object.
    * @see SQLBuilder#doStatementSetBindingStyle(Statement, int)
    */
   public static final int    BINDING_STYLE_JDBC = 0;

   /**
    * Constant used to specify Oracle binding style while
    * binding parameters to a statement object.
    * @see SQLBuilder#doStatementSetBindingStyle(Statement, int)
    */
   public static final int    BINDING_STYLE_ORACLE = 1;
   
   /**
    * Constant used to specify Oracle Named Parameter binding style 
    * while binding parameters to a statement object.
    * @see SQLBuilder#doStatementSetBindingStyle(Statement, int)
    */
   public static final int    BINDING_STYLE_ORACLE_NAME = 2;

   // Version of the pluggable SQLBuilder Implementation
   /**
    * Gets a string describing the version of this implentation
    * of this interface.
    * @return a <tt>String</tt> containing the version.
    */
   public String getVersion();

   /**
    * Returns a string uniquely identifying this type of
    * SQLBuilder. Examples are: "Oracle", "OLite", "SQL92".
    * @return a String containing the Database type.
    */
   public String getDbType();
   
   /**
   * Returns a list of nested tables in this connection.
   * <p><b>Note:</b> this method is subject to change.
   * @param conn the connection.
   * @return null if the platform doesn't support nested tables.
   */
   public ArrayList getNestedTables(Connection conn) throws SQLException;

   /**
    * Returns a String identifying the preferred type map to use.
    * @return a <tt>String</tt> containing the type map name.
    */
   public String getTypeMapName();

   /**
    * Returns the name of default PersistManager class name.
    * @return a <tt>String</tt> containing the Class name.
    */
   public String getPersistManagerClassName();

   /**
    * Returns a constant identifying the best binding
    * style for this sort of SQL (see the BINDINGSTYLE constants).
    * <p><b>Note:</b> this method is subject to change.
    * @return an <tt>int</tt> value constant.
    */
   public int getDefaultBindingStyle();

   // Driver Methods
   /**
    * Registers the JDBC driver associated with this type of
    * JDBC connection.
    * @param url JDBC Connection url.
    * @throws SQLException
    */
   public void doRegisterDefaultDriver(String url)
      throws SQLException;

   // Entity methods
   /**
    * Performs the appropriate SQL Data Manipulation Language (DML)
    * operations on the database to reflect an update, delete or
    * insert operation on an Entity Object.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param enrt the Entity Object.
    * @param operation  one of <tt>DML_INSERT</tt>, <tt>DML_UPDATE</tt>, or <tt>DML_DELETE</tt>.
    * @param e the transaction.
    */
   public void doEntityDML(EntityImpl enrt,  int operation, TransactionEvent e);

   /**
    * Build a INSERT SQL for the Entity Object skipping non-persistent
    * values. If there are attributes in the Entity Object that need to
    * be fetched after the INSERT succeeds, a <tt>CallableStatement</tt>
    * is created to fetch those values.
    * 
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param cols the columns to be included in the INSERT statement.
    * @param retrCols the Columns whose values need to be fetched after the INSERT succeeds.
    * @param retrKeyCols the Columns that are used as Keys to fetch post-insert values.
    * @param batchMode a flag to indicate if the INSERT statement needs to be optimized
    *                  for batch mode.
    * @return a <tt>StringBuffer</tt> object containing the INSERT statement.
    */
   public StringBuffer buildInsertStatement(EntityImpl entityContext,
                                            AttributeDefImpl[] cols,
                                            AttributeDefImpl[] retrCols,
                                            AttributeDefImpl[] retrKeyCols,
                                            boolean batchMode);

   /**
    * Build a UPDATE SQL for the Entity Object skipping non-persistent
    * values. If there are attributes in the Entity Object that need to
    * be fetched after the UPDATE succeeds, a <tt>CallableStatement</tt>
    * is created to fetch those values.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param cols the columns to be included in the UPDATE statement.
    * @param retrCols the Columns whose values need to be fetched after the UPDATE succeeds.
    * @param retrKeyCols the Columns that are used as Keys to fetch post-update values.
    * @param batchMode a flag to indicate if the UPDATE statement needs to be optimized
    *                  for batch mode.
    * @return a <tt>StringBuffer</tt> object containing the UPDATE statement.
    */
   public StringBuffer buildUpdateStatement(EntityImpl entityContext,
                                            AttributeDefImpl[] cols,
                                            AttributeDefImpl[] retrCols,
                                            AttributeDefImpl[] retrKeyCols,
                                            boolean batchMode);

   /**
    * Build a DELETE SQL for the Entity Object. The row is deleted
    * from the table using the values of the Primary keys defined
    * in the Entity.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @return a <tt>StringBuffer</tt> object containing the UPDATE statement.
    */
   public StringBuffer buildDeleteStatement(EntityImpl entityContext);

   /**
    * Build a list of columns that could be used in a SELECT statement.
    * <p><b>Note:</b> this method is subject to change.
    * @param buffer the <tt>StringBuffer</tt> object to which the SELECT list is appended.
    * @param attrs the list of attribute definitions to be considered for the SELECT list.
    * @param sourceAlias the database object name that contains the attributes.
    */
   public void buildSelectList(StringBuffer buffer, AttributeDef[] attrs, String sourceAlias);

   /**
    * Construct a SQL SELECT statement for the Entity into the
    * designated Buffer.
    *
    * This routine will construct a SQL SELECT statement in the
    * StringBuffer passed.  It does this by appending the various
    * components of the SELECT statement into the buffer area.
    * <p><b>Note:</b> this method is subject to change.
    * @param trans a reference to the transaction object.
    * @param buffer the <tt>StringBuffer</tt> object to which the SELECT statement is appended. 
    * @param sourceName the database object from which the Columns are selected.
    * @param sourceAlias the database object alias.
    * @param attrs the attributes that are selected from the database object.
    * @param withIntoClause a boolean that indicates if an INTO Clause needs to be generated.
    * @param bindingStyle specifies if Oracle, Oracle named parameter or JDBC binding style
    *                     is used in generating the parameter markers for the INTO clause.
    */
   public void buildSelectString(DBTransactionImpl trans,
                                 StringBuffer buffer,
                                 String sourceName,
                                 String sourceAlias,
                                 AttributeDefImpl[] attrs,
                                 boolean withIntoClause,
                                 int bindingStyle);

   /**
    * Binds the entity attribute storage with the parameters in the INSERT
    * statement. 
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param stmt the statement handle executing the INSERT statement.
    * @param cols the columns involved in the INSERT statement.
    * @param retrCols the columns whose values need to be fetched after a
    *                 successful insert.
    * @param retrKeyCols the columns that act as a key to fetch the newly
    *                    inserted values.
    * @param retrList a map containing the references to store the fetched
    *                 values.
    * @param batchMode flag to indicate binding for batchMode.
    * @return index of last bind variable set in this statement.
    * @throws SQLException
    */
   public int bindInsertStatement(EntityImpl entityContext,
                                  PreparedStatement stmt,
                                  AttributeDefImpl[] cols,
                                  AttributeDefImpl[] retrCols,
                                  AttributeDefImpl[] retrKeyCols,
                                  HashMap retrList,
                                  boolean batchMode) throws SQLException;

   /**
    * Binds the entity attribute storage with the parameters in the UPDATE
    * statement.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param stmt the statement handle executing the UPDATE statement.
    * @param cols the columns involved in the UPDATE statement.
    * @param retrCols the columns whose values need to be fetched after a
    *                 successful insert.
    * @param retrKeyCols the columns that act as a key to fetch the newly
    *                    inserted values.
    * @param retrList a map containing the references to store the fetched
    *                 values.
    * @param batchMode flag to indicate binding for batchMode.
    * @return index of last bind variable set in this statement.
    * @throws SQLException
    */
   public int bindUpdateStatement(EntityImpl entityContext,
                                  PreparedStatement stmt,
                                  AttributeDefImpl[] cols,
                                  AttributeDefImpl[] retrCols,
                                  AttributeDefImpl[] retrKeyCols,
                                  HashMap retrList,
                                  boolean batchMode) throws SQLException;

   /**
    * Binds the values in the entity attribute storage with the DELETE 
    * statement.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param stmt the statement handle executing the DELETE statement.
    * @throws SQLException
    */
   public int bindDeleteStatement(EntityImpl entityContext,
                                  PreparedStatement stmt) throws SQLException;

   /**
    * Bind the Primary key values for the designated Statement.
    *
    * This routine will perform the bind operation for each of
    * the Primary Key columns.<p>
    * The presence or absence of the ROWID value determines
    * whether the ROWID will be used for Row access.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the Entity row.
    * @param stmt the statement to bind the columns to.
    * @param rowid the ROWID for the row if known.
    * @param bindIndex the baseline idx for performing the bind operations.
    * @return index of last bind variable set in this statement.
    * @throws SQLException
    */
   public int bindWhereClause(EntityImpl entityContext,
                              PreparedStatement stmt,
                              Object rowid,
                              int bindIndex) throws SQLException;

   /**
    * Bind the Primary key values for the designated Statement.
    *
    * This routine will perform the bind operation for each of
    * the Primary Key columns.<p>
    * The presence or absence of the ROWID value determines
    * whether the ROWID will be used for Row access.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the Entity row.
    * @param stmt the statement to bind the columns to.
    * @param retrKeyCols the Primary Key Cols for the Entity row.
    * @param rowid the ROWID for the row if known.
    * @param bindIndex the baseline idx for performing the bind operations.
    * @return index of last bind variable set in this statement.
    * @throws SQLException
    */
   public int bindWhereClause(EntityImpl entityContext,
                              PreparedStatement stmt,
                              AttributeDefImpl[] retrKeyCols,
                              Object rowid,
                              int bindIndex) throws SQLException;

   /**
    * Perform the appropriate SQL operations to execute a select operation
    * on an Entity Object.
    * <p><b>Note:</b> this method is subject to change.
    * <b>Note:</b> this method is subject to change.
    * @param e the Entity Object.
    * @param lock if <tt>true</tt>, a "SELECT for UPDATE" statement is used.
    */
   public void doEntitySelect(EntityImpl e,  boolean lock);

   /**
    * Performs the equivalent of <tt>setRowPrefetch()</tt> on a statement.<p>
    * @param ps the <tt>Statement</tt> object.
    * @param prefetchSize the fetch size.
    * @throws SQLException
    */
   public void doStatementSetRowPrefetch(Statement ps, int prefetchSize)
      throws SQLException;

   /**
    * Sets the binding style for the statement. <p>
    * @param ps the <tt>Statement</tt> object.
    * @param bindingStyle valid values are BINDING_STYLE_JDBC, BINDING_STYLE_ORACLE, 
    *                     BINDING_STYLE_ORACLE_NAME.
    */
   public void doStatementSetBindingStyle(Statement ps, int bindingStyle);

   /**
    * Sets the binding style to the default value of the database type. For
    * Oracle database it is set to BINDING_STYLE_ORACLE and for non-oracle databases
    * it is set to BINDING_STYLE_JDBC.
    * <p><b>Note:</b> this method is subject to change.
    * @param ps the <tt>Statement</tt> object.
    */
   public void doStatementSetBindingStyleDefault(Statement ps);

   /**
    * Performs the equivalent of <tt>defineColumnType()</tt> on a prepared statement.
    * <p><b>Note:</b> this method is subject to change.
    * @param ps the <tt>PreparedStatement</tt> object.
    * @param colnum the column number.
    * @param sqltype the type of the column.
    * @throws SQLException
    */
   public void doPreparedStatementDefineColumnType(PreparedStatement ps, int colnum, int sqltype)
      throws SQLException;

   /**
    * Defines the column types of the attributes based on the meta-data.
    * <p><b>Note:</b> this method is subject to change.
    * @param ps the <tt>PreparedStatement</tt> object.
    * @param attrs the attribute definitions.
    */
   public void doPreparedStatementDefines(PreparedStatement ps, AttributeDefImpl attrs[]);


   /**
    * Populates the system typemap table with entries appropriate
    * for the JDBC implementation.
    * <p><b>Note:</b> this method is subject to change.
    */
   public void populateJboTypeMapEntries();

   /**
    * Tests if a type is numeric.
    * @param type the type that needs to be checked.
    */
   public boolean isNumericType(int type); //TODO: should be able to make this generic within typemap

   /**
    * Tests if a type is character. <p>
    * @param type the type that needs to be checked.
    */
   public boolean isCharType(int type); //TODO: should be able to make this generic within typemap

   //AttributeDef methods
   /**
    * Loads an object from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param theTypeFactory a custom factory to be used for constructing new instances.
    * @param theElemFactory currently unused.
    * @param theJavaType the Java datatype of the Object to be created.
    * @param attrLoad specifies if the load type is 
    *                 {@link oracle.jbo.server.AttributeDefImpl#ATTR_LOAD_EACH ATTR_LOAD_EACH},
    *                 {@link oracle.jbo.server.AttributeDefImpl#ATTR_LOAD_BULK ATTR_LOAD_BULK} or
    *                 {@link oracle.jbo.server.AttributeDefImpl#ATTR_LOAD_SKIP ATTR_LOAD_SKIP}   
    * @param rs the resultset.
    * @param index the index of the object to be loaded.
    * @param trans the reference to the transaction object used to fetch the resultset.
    * @return a reference to the object loaded.
    * @throws DataCreationException
    */
   public Object doLoadFromResultSet(Object theTypeFactory, Object theElemFactory,
                                     Class theJavaType, byte attrLoad, ResultSet rs,
                                     int index, DBTransactionImpl trans)
      throws DataCreationException;

   /**
    * Loads an array of objects from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param attrs the list of attributes to be loaded.
    * @param attrIndex a particular attribute from the list - Currently unused.
    * @param rs the <tt>ResultSet</tt> containing the objects.
    * @param rsIndex the index of the object in the result set to be loaded.
    * @param trans the reference to the transaction object used to fetch the resultset.
    * @return a reference to the array of objects loaded.
    * @throws DataCreationException
    */
   public Object[] doLoadBulkFromResultSet(AttributeDefImpl[] attrs,
                                           int attrIndex, ResultSet rs,
                                           int rsIndex, DBTransactionImpl trans)
      throws DataCreationException;

   /**
    * Loads an object from a result set.
    * <p>
    * <b>Note:</b> this method is subject to change.
    * @param theTypeFactory a custom factory to be used for constructing new instances.
    * @param theElemFactory currently unused.
    * @param theJavaType the Java datatype of the Object to be created.
    * @param ps the statement reference used to retrieve the Object.
    * @param index  the index of the object in the output list.
    * @param trans the reference to the transaction object used to fetch the resultset.
    * @return a reference to the object loaded.
    * @throws DataCreationException
    */
   public Object doLoadFromStatement(Object theTypeFactory, Object theElemFactory,
                                     Class theJavaType, PreparedStatement ps,
                                     int index, Transaction trans)
      throws DataCreationException;

   /**
    * Issue a SAVEPOINT if possible.
    * <p>
    * @param conn the Connection used to create a savepoint.
    * @param id the id for a savepoint.
    */
   public void setSavepoint(Connection conn, String id)
      throws SQLException;

   /**
    * Rollback to SAVEPOINT if possible.
    * <p>
    * @param conn the Connection used to rollback the savepoint.
    * @param id the id for a savepoint
    */
   public void rollbackToSavepoint(Connection conn, String id)
      throws SQLException;

   /**
    * Release SAVEPOINT if possible.
    * <p>
    * @param conn the Connection used to release the savepoint.
    * @param id the id for a savepoint
    */
   public void releaseSavepoint(Connection conn, String id)
      throws SQLException;

   /**
    * Get the ROWID attribute.
    * <p>
    * The ROWID attribute can be used to gain faster access to the underyling
    * database data.
    * <p>
    * Obtain the value for the ROWID attribute. If this entity doesn't
    * support ROWID attributes, then return NULL. If, for some reason
    * the value of the ROWID attribute isn't present, then return null.
    * <p><b>Note:</b> this method is subject to change.
    * @param e the entity object reference.
    * @return an Object containing the ROWID or null if generate ROWID fails.
    */
   /*
    * TODO: this might not always be possible, so the method needs
    * to throw something identifiable.
    */
   public Object generateRowID(EntityImpl e);

   /**
    * Generates a PK-Based REF for an Entity Object.
    * This is used for an object table. 
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object reference.
    */
   public Object generatePKBasedRef(EntityImpl entityContext);

   /**
    * Generates an object Ref and OID for an Entity Object.
    * This is used for an object table.
    * <p><b>Note:</b> this method is subject to change.
    * @param e the entity object reference.
    */
   public Object[] generateRefAndOID(EntityImpl e);

   /**
    * Check if a given type provides streaming support.
    * <p><b>Note:</b> this method is subject to change.
    * @param sqlTypeId the type to check for streaming support.
    */
   public boolean isStreamType(int sqlTypeId);

   /**
    * Return a list of tables visible in this connection.
    * <p><b>Note:</b> this method is subject to change.
    * @param conn the connection object.
    * @param defaultUserName the user name of the connection. This is will also
    *                        be treated as the schema name for non-oracle databases.
    * @param userName the user name for which the tables need to be listed.
    * @param bTable flag to include Table objects in the list.
    * @param bAlias flag to include Synonyms in the list - Oracle database only.
    * @param bView flag to include View objects in the list.
    * @param bSnap flag to include Materialized View objects in the list.
    * @return an <tt>ArrayList</tt> containing <tt>String</tt> objects.
    * @throws Exception
    */
   public ArrayList getTables(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap)
   throws Exception;

   /**
    * Return a list of tables visible in this connection. Same as 
    * {@link #getTables(Connection, String, String, boolean, boolean, boolean, boolean)
    * getTables(Connection, String, String, boolean, boolean, boolean, boolean)} with
    * an additional parameter to fetch nested tables. Nested tables are fetched only
    * for Oracle database and OLite. 
    * <p><b>Note:</b> this method is subject to change.
    * @param conn the connection object.
    * @param defaultUserName the user name of the connection. This is will also
    *                        be treated as the schema name for non-oracle databases.
    * @param userName the user name for which the tables need to be listed.
    * @param bTable flag to include Table objects in the list.
    * @param bAlias flag to include Synonyms in the list - Oracle database only.
    * @param bView flag to include View objects in the list.
    * @param bSnap flag to include Materialized View objects in the list.
    * @param bIncludeNested flag to include Nested table objects in the list.
    * @return an <tt>ArrayList</tt> containing <tt>String</tt> objects.
    * @throws Exception
    */
  public ArrayList getTables(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap, boolean bIncludeNested)
  throws Exception;

  /**
   * Return a list of tables visible in this connection. Invokes 
   * {@link #getTables(Connection, String, String, boolean, boolean, boolean, boolean)
   * getTables(Connection, String, String, boolean, boolean, boolean, boolean)}.
   * <p><b>Note:</b> this method is subject to change. 
   * @param conn the connection object.
   * @param defaultUserName the user name of the connection. This is will also
   *                        be treated as the schema name for non-oracle databases.
   * @param userName the user name for which the tables need to be listed.
   * @param bTable flag to include Table objects in the list.
   * @param bAlias flag to include Synonyms in the list - Oracle database only.
   * @param bView flag to include View objects in the list.
   * @param bSnap flag to include Materialized View objects in the list.
   * @return a <tt>Vector</tt> containing <tt>String</tt> objects.
   * @throws Exception
   */
   public Vector getTableList(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap)
   throws Exception;
   
   /**
   * Return a list of tables visible in this connection. Invokes 
   * {@link #getTables(Connection, String, String, boolean, boolean, boolean, boolean, boolean)
   * getTables(Connection, String, String, boolean, boolean, boolean, boolean, boolean)}.
   * <p><b>Note:</b> this method is subject to change. 
   * @param conn the connection object.
   * @param defaultUserName the user name of the connection. This is will also
   *                        be treated as the schema name for non-oracle databases.
   * @param userName the user name for which the tables need to be listed.
   * @param bTable flag to include Table objects in the list.
   * @param bAlias flag to include Synonyms in the list - Oracle database only.
   * @param bView flag to include View objects in the list.
   * @param bSnap flag to include Materialized View objects in the list.
   * @param bIncludeNested flag to include Nested table objects in the list.
   * @return a <tt>Vector</tt> containing <tt>String</tt> objects.
   * @throws Exception
   */
  public Vector getTableList(Connection conn, String defaultUserName, String userName, boolean bTable, boolean bAlias, boolean bView, boolean bSnap, boolean bIncludeNested)
  throws Exception;   

   /**
    * Return a list of schemas for this database
    * (note that for Oracle this is synonymous with users) <p>
    * <p><b>Note:</b> this method is subject to change.
    * @return an <tt>ArrayList</tt> containing <tt>String</tt> objects.
    */
   public ArrayList getSchemas(Connection conn)
   throws Exception;

   /**
    * Return a list of schemas for this database
    * (note that for Oracle this is synonymous with users)
    * <p><b>Note:</b> this method is subject to change.
    * @return a <tt>Vector</tt> containing <tt>String</tt> objects.
    */
   public Vector getSchemaList(Connection conn)
   throws Exception;

   /**
    * Return vector with constraint details for this table
    * where each detail is in a String array with this structure:
    * 0  String owner <p>
    * 1  String constraint_name <p>
    * 2  String constraint_type <p>
    * 3  String table_name <p>
    * 4  String search_condition <p>
    * 5  Integer delete_rule (cascade) <p>
    * 6  Integer status (enabled) <p>
    * 7  Integerdeferrable <p>
    * 8  Integer deferred <p>
    * 9  Integer validated <p>
    * 10 String column_name <p>
    * 11 Integer position <p>
    * 12 String fkname<p>
    * 13 String fkother<p>
    * <b>Note:</b> this method is subject to change.
    * @param conn  the connection object.
    * @param catalog the database catalog.
    * @param schema the database schema.
    * @param table the name of the table.
    * @return an <tt>ArrayList</tt> containing an array of <tt>String</tt> objects.
    * @throws SQLException
    */
   public ArrayList getConstraintsList(Connection conn, String catalog, String schema, String table)
   throws SQLException;

   /**
    * Return vector with constraint details for this table. Invokes 
    * {@link #getConstraintsList(Connection, String, String, String) getConstraints(Connection, String, String, String)}.
    * <p><b>Note:</b> this method is subject to change. 
    * @param conn  the connection object.
    * @param catalog the database catalog.
    * @param schema the database schema.
    * @param table the name of the table.
    * @return a <tt>Vector</tt> containing an array of <tt>String</tt> objects.
    * @throws SQLException
    */
   public Vector getConstraints(Connection conn, String catalog, String schema, String table)
   throws SQLException;

   /**
    * Unroll any synonyms that may be present, and get
    * the real objectname.
    * <p><b>Note:</b> this method is subject to change.
    * @param conn  the connection object.
    * @param schema the database schema.
    * @param name the name of the potential synonym.
    * @return a <tt>String</tt> containing the real table name. Note that
    *         even if the argument is a table name it may be altered to enforce
    *         consistent naming convention. For non-Oracle databases the
    *         name is returned unaltered.
    * @throws SQLException
    */
   public String getBaseTable(Connection conn, String schema, String name)
   throws SQLException;

   /**
    * Add quotes to any table name that may need it.
    * <p><b>Note:</b> this method is subject to change.
    * @param tableName the name of the table.
    * @return the quoted table name if needed otherwise returns the table name
    *         unaltered.
    */
   public String checkTableNameForQuotes(String tableName);

   /**
    * Executes the PreparedStatement in batch mode. Implemented for
    * Oracle database only by invoking OraclePreparedStatement.executeBatch.
    * Other database flavors throw an exception.
    * <p><b>Note:</b> this method is subject to change.
    * @param stmt a <tt>PreparedStatement</tt> object.
    * @throws SQLException
    */
   public void executeBatch(PreparedStatement stmt)
   throws SQLException;

   /**
    * Performs a JNDI lookup for the datasource.
    * Supported for Oracle database only.
    * <p><b>Note:</b> this method is subject to change.
    * @param nsUrl the provider URL.
    * @param nsUser the username to connect to the provider.
    * @param nsPasswd the password to connect to the provider. 
    * @param dataSourceName the name of the datasource.
    * @return a <tt>DataSource</tt> definition object if lookup is successful,
    *         null otherwise.
    * @throws JboException
    */
   public DataSource lookupDataSource(String nsUrl,
                                      String nsUser,
                                      String nsPasswd,
                                      String dataSourceName) throws JboException;

   /**
    * Checks if the <tt>DataSource</tt> is JTA-enabled.
    * <p><b>Note:</b> this method is subject to change.
    * @param ds the <tt>DataSource</tt> object.
    * @return <tt>true</tt> if the data source is JTA-enabled,
    *         <tt>false</tt> otherwise.
    */
   public boolean isDataSourceJTABased(DataSource ds) ;

   /**
    * Returns a <tt>ViewCriteriaAdapter</tt> for the <tt>SQLBuilder</tt>
    * object. <tt>ViewCriteriaAdapter</tt> is used in creating 
    * WHERE clause based on a set of criteria for a <tt>ViewObject</tt>.
    * <p><b>Note:</b> this method is subject to change.
    * @return a <tt>ViewCriteriaAdapter</tt> instance.
    */
   public ViewCriteriaAdapter getViewCriteriaAdapter();

   /**
    * Returns the current time from the Database.
    * @param conn the connection object. 
    * @return a <tt>Timestamp</tt> containing the Database time.
    */ 
   public Timestamp getCurrentDbTime(Connection conn);

   /**
    * Returns a SQL statement that creates a trigger that 
    * updates a column with the value from a sequence
    * upon the creation of a new row.<p>
    * Supported for Oracle database only.
    * <p><b>Note:</b> this method is subject to change.
    * @param triggerName the name of the trigger.
    * @param tableName the name of the table for which the trigger is created.
    * @param sequenceName the name of the sequence.
    * @param colName the name of the column to which the value of the sequence
    *        is copied to.
    * @return the SQL statement as a <tt>String</tt> object.
    */
   public abstract String getCreateSequenceInsertTriggerSQL(String triggerName, String tableName,
                                                            String sequenceName, String colName);

   /**
    * Returns a SQL statement that creates a Sequence with
    * an initial value specified in the argument.
    * <p><b>Note:</b> this method is subject to change.
    * @param sequenceName name of the Sequence.
    * @param startVal the initial value of the Sequence.
    * @return the SQL statement as a <tt>String</tt> object.
    */
   public abstract String getCreateSequenceSQL(String sequenceName, int startVal);

   /**
    * Returns a SQL statement that drops a specified Sequence.
    * <p><b>Note:</b> this method is subject to change.
    * @param sequenceName name of the Sequence.
    * @return the SQL statement as a <tt>String</tt> object.
    */
   public abstract String getDropSequenceSQL(String sequenceName);

   /**
    * Returns a SQL statement that drops a specified table.
    * For Oracle database it also deletes the constraints for the table.
    * <p><b>Note:</b> this method is subject to change.
    * @param dbObjectName name of the Table.
    * @return the SQL statement as a <tt>String</tt> object.
    */
   public String getDropTableSQL(String dbObjectName);

   /**
    * For Oracle database the test SQL wizards provide
    * additional functionality to bind the parameters with
    * test values. For other databases this functionality
    * is not supported.
    * @return true for Oracle, false for all other databases.
    */
   public boolean isDisplayBindValueUI();

   /**
    * Refreshes the entity after an update on the database.
    * The refresh depends entirely on, the attributes which were modified. If no    
    * UNIQUE/PRIMARY KEY attribute was set in the application, or they are 
    * modified in a database trigger then the refresh may not be able to find 
    * the required row. In this situation RowNotFoundException will be thrown.
    * If there is good reason behind not setting any of the KEY attributes, 
    * then, in a custom SQLBuilder, this method should be overriden.
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the Entity row.
    * @param operation SQL Operation
    * @param columns Columns to be selected.
    * @param keyCols Key columns to appear be to used to refresh, which appear in WHERE clause.
    */
   public void doRefreshSQL(EntityImpl entityContext, int operation, AttributeDefImpl[] columns, AttributeDefImpl[] keyCols);

   /**
    * Checks if the database supports the Returning clause.
    * @return true for Oracle database and false otherwise.
    */
   public boolean supportsReturningClause();

   /**
    * Returns a SQL statement to estimate the number of
    * rows effected by the query using the rowset
    * values.
    * <p><b>Note:</b> this method is subject to change.
    * @param rs the <tt>RowSet</tt> object.
    * @return the SQL statement as a <tt>String</tt> object.
    */
   public String getQueryHitCountSQL(RowSet rs);

   /**
    * Checks if the database supports "rownum" identifier. Used for
    * fetching rows in the specified range.
    * <p><b>Note:</b> this method is subject to change.
    * @return true for Oracle database and false otherwise.
    */
   public boolean supportsRowNumQuery();

   /**
    * Detects if a connection is alive.
    * @param conn the connection object. 
    * @return true if the connection is active, false otherwise.
    */
   public boolean isConnectionAlive(Connection conn);

   /**
    * Binds the entity attribute storage with the parameters in the INSERT
    * statement. 
    * <p><b>Note:</b> this method is subject to change.
    * @return index of last bind variable set in this statement.
    * @throws SQLException
    */

   /**
    * Creates a WHERE clause containing the Primary Key columns passed to the method. 
    * <p><b>Note:</b> this method is subject to change.
    * @param entityContext the entity object.
    * @param buffer the <tt>StringBuffer</tt> object to which the WHERE clause is appended.
    * @param keyCols the key attributes.
    * @param rowid a rowid object if present.
    */
   public void buildWhereClause(EntityImpl entityContext, StringBuffer buffer, AttributeDefImpl[] keyCols, Object rowid);

   /**
    * This method is used to convert the Java type to a JDBC type so that
    * it could be used to bind as a parameter for SQL execution.
    * <p><b>Note:</b> this method is subject to change.
    * @param value the object that needs to be converted.
    * @return the JDBC type.
    */
   public Object convertValueToStorageType(Object value);

   /**
    * Populates the properties with known security attributes found
    * in the environment. Used for Oracle JDBC connectivity only. 
    * The values are copied into the <tt>Properties</tt> from
    * the Session's environment.
    * <p><b>Note:</b> this method is subject to change.
    * @param info the properties object to which the values are copied to.
    * @param env the environment object to lookup the security attributes.
    */
   public void jdbcClientSideSecurity(Properties info, Hashtable env);

   /**
    * Compare the cacheValue with fetchedValue and if they are equal return true
    * This API is used when comparing cached entity with a faulted in entity.
    * Signature modified since 9.0.5.1 to allow for Entity context to be available
    * during compare so that Applications could perform custom comparision logic
    * based on either settings in the Entity or any other context available via the
    * entity.
    * <p><b>Note:</b> this method is subject to change.
    * @param entity the entity object.
    * @param ad the attribute definition of the value being compared.
    * @param cacheValue the cached value.
    * @param fetchedValue the new fetched value.
    * @return true if the values are same, false otherwise.
    */
   public boolean compareFetchedValue(EntityImpl entity, AttributeDefImpl ad, Object cacheValue, Object fetchedValue);

   /**
    * Bind parameter values for a SQL execution.
    * <p><b>Note:</b> this method is subject to change.
    * @param bindingStyle specifies if Oracle, Oracle named parameter or JDBC binding style
    *                     is used.
    * @param params the list of parameters.
    * @param stmt the statement to be executed.
    * @throws SQLException
    */
   public void bindParametersForStmt(int bindingStyle, Object params[], PreparedStatement stmt)
      throws SQLException;

   /**
    * Handle SQL exceptions by wrapping into {@link oracle.jbo.SQLStmtException SQLStmtException}
    * or {@link oracle.jbo.JboException JboException}.
    * <p><b>Note:</b> this method is subject to change.
    * @param errorCode the SQL execution errorcode.
    * @param sqlEx the <tt>Exception</tt> object.
    * @param params the query parameters.
    */
   public void processException(String errorCode, Exception sqlEx, Object[] params);

   /**
    * Returns false only for types where raw-bytes may be used to create the desired
    * attribute values while fetching data from jdbc. Most subclasses will return
    * true for this method.
    */
   public boolean invalidDatumFactoryUsage(String colType, int id, Class clz);

   
   /**
    * Return the maximum length of a table name for the 
    * Database connection. 
    * @param conn the Database connection object
    * @return a non-zero integer if the table name length can be determined,
    *         zero otherwise.
    */
   public int getMaxTableNameLength(Connection conn);
   
   
   /**
    * Checks if the JDBC driver supports new line character
    * in SQL statements. Over-ridden by DB2SQLBuilderImpl to
    * return false when using DB2 Universal Driver (Type IV).
    * @param conn
    * @return true if the driver supports a new line character
    */
   public boolean isNewLineAllowedInSQL(Connection conn);
   
} // interface SQLBuilder
