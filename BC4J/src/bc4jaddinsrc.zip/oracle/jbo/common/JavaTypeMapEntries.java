/*
 * @(#)JavaTypeMapEntries.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.common;

import oracle.jbo.common.JboTypeMap;

/**
 * Populates TypeMap Entries for BC4J Designtime and Runtime
 * to map a Database column type to a java-class type and also to jdbc-sqltype and id.
 * The entries should be:
 *    COLUMN_TYPE       - column type in the database
 *    JAVA_CLASS_NAME   - Java class which should store in-memory data from the given column-type
 *    JDBC_SQL_TYPE     - Name of the jdbc sql type id that the subsequent integer-entry represents.
 *    JDBC_SQL_TYPE_ID  - Integer value from java.sql.Types or a corresponding Types list in jdbc.
 *    DISPLAY_LENGTH    - Default size for various String/Character types.
 *
 * @since JDeveloper 3.2
 */
public class JavaTypeMapEntries extends JboTypeMapEntries
{
   public JavaTypeMapEntries()
   {

   /* from the Olite documentation
   Java Datatypes                                SQL Datatype
   ------------------------------------------------------------------------------
   byte[], byte[][], Byte[]                       BINARY, RAW, VARBINARY
   boolean, Boolean                               BIT
   String, String[]                               CHAR, VARCHAR, VARCHAR2
   short, short[], short[][], Short, Short[]      SMALLINT
   int, int[], int[][], Integer, Integer[]        INT
   float, float[], float[][], Float, Float[]      REAL
   double, double[], double[][], Double, Double[] DOUBLE, NUMBER (without precision)
   BigDecimal, BigDecimal[]                       NUMBER(n)
   java.sql.Date, java.sql.Date[]                 DATE
   java.sql.Time, java.sql.Time[]                 TIME
   java.sql.Timestamp, java.sql.Timestamp[]       TIMESTAMP
   java.sql.Connection                            Default JDBC connection to database
   oracle.lite.jac.POLJACConnection               Default JAC connection to database
   oracle.lite.jac.POLPersistantCapable           JAC instance of the object
   ------------------------------------------------------------------------------
   */
      //             COLUMN_TYPE         JAVA_CLASS_NAME             JDBC_SQL_TYPE     JDBC_SQL_TYPE_ID,         DISPLAY_LENGTH, NUMERIC_TYPE);
      //             ------------------------------------------------------------------------------------------------------------------------
      new JboTypeMap("CHAR",             "java.lang.String",         "VARCHAR",        java.sql.Types.VARCHAR,   null,           JboTypeMap.CHAR); 
      new JboTypeMap("BIGINT",           "java.math.BigDecimal",     "NUMERIC",        java.sql.Types.NUMERIC,   null,           JboTypeMap.NUMBER);
      new JboTypeMap("BIT",              "java.lang.Boolean",        "BIT",            java.sql.Types.BIT,       null,           JboTypeMap.NUMBER); 
      new JboTypeMap("DATE",             "java.sql.Date",            "DATE",           java.sql.Types.DATE,      null,           JboTypeMap.DATE); 
      new JboTypeMap("DECIMAL",          "java.math.BigDecimal",     "DECIMAL",        java.sql.Types.DECIMAL,   null,           JboTypeMap.NUMBER); 
      new JboTypeMap("DOUBLE PRECISION", "java.math.BigDecimal",     "DOUBLE",         java.sql.Types.DOUBLE,    null,           JboTypeMap.NUMBER); 
      new JboTypeMap("DOUBLE",           "java.math.BigDecimal",     "DOUBLE",         java.sql.Types.DOUBLE,    null,           JboTypeMap.NUMBER); 
      new JboTypeMap("FLOAT",            "java.lang.Float",          "FLOAT",          java.sql.Types.FLOAT,     null,           JboTypeMap.NUMBER); 
      new JboTypeMap("INTEGER",          "java.lang.Integer",        "INTEGER",        java.sql.Types.INTEGER,   null,           JboTypeMap.NUMBER); 
      new JboTypeMap("INT",    /*MS*/    "java.lang.Integer",        "INTEGER",        java.sql.Types.INTEGER,   null,           JboTypeMap.NUMBER);  
      new JboTypeMap("NUMBER",           "java.math.BigDecimal",     "NUMERIC",        java.sql.Types.NUMERIC,   null,           JboTypeMap.NUMBER); 
      new JboTypeMap("NUMERIC",          "java.math.BigDecimal",     "NUMERIC",        java.sql.Types.NUMERIC,   null,           JboTypeMap.NUMBER); 
      new JboTypeMap("REAL",             "java.math.BigDecimal",     "REAL",           java.sql.Types.REAL,      null,           JboTypeMap.NUMBER); 
      new JboTypeMap("ROWID",            "java.lang.String",         "VARCHAR",        java.sql.Types.VARCHAR,   null,           JboTypeMap.CHAR); 
      new JboTypeMap("SMALLINT",         "java.lang.Integer",        "SMALLINT",       java.sql.Types.SMALLINT,  null,           JboTypeMap.NUMBER); 
      new JboTypeMap("TIMESTAMP",        "java.sql.Timestamp",       "TIMESTAMP",      java.sql.Types.TIMESTAMP, null,           JboTypeMap.DATE); 
      new JboTypeMap("DATETIME", /*MS*/  "java.sql.Timestamp",       "TIMESTAMP",      java.sql.Types.TIMESTAMP, null,           JboTypeMap.DATE);
      new JboTypeMap("TIME",             "java.sql.Time",            "TIME",           java.sql.Types.TIME,      null ); 
      new JboTypeMap("TINYINT",          "java.lang.Integer",        "TINYINT",        java.sql.Types.TINYINT,   null,           JboTypeMap.NUMBER); 
      new JboTypeMap("VARCHAR",          "java.lang.String",         "VARCHAR",        java.sql.Types.VARCHAR,   null,           JboTypeMap.CHAR); 
      new JboTypeMap("VARCHAR2",         "java.lang.String",         "VARCHAR",        java.sql.Types.VARCHAR,   null,           JboTypeMap.CHAR); 
      new JboTypeMap("DATE",             "java.util.Date",           "DATE",           java.sql.Types.DATE,      null,           JboTypeMap.DATE); 
      new JboTypeMap("NUMBER",           "java.lang.Long",           "NUMERIC",        java.sql.Types.NUMERIC,   null,           JboTypeMap.NUMBER); 
      //TODO java.sql.types.LONGVARCHAR, BINARY, VARBINARY, LONGVARBINARY, NULL
      //             ------------------------------------------------------------------------------------------------------------------------
   }
}
