/*
 * @(#)NullValue.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.io.PrintWriter;
import java.sql.Types;
import java.util.Hashtable;
import oracle.jbo.Transaction;
import oracle.jbo.common.JboTypeMap;
import oracle.jbo.common.UnknownSQLTypeException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * Provides a means of creating and serializing null Domain objects.
 *
 * <p>The zero-parameter constructors for each Domain type produce default objects,
 * rather than null objects.  Use the constructors for this class to produce
 * typed null Domain objects.
 * @since JDeveloper 3.0
 */
public class NullValue implements DomainInterface,
                       XMLDomainWriter,
                       java.io.Serializable
{
   static final long serialVersionUID = 6384347001003884267L;
   static final String STR_NULL="null";
   private int mSQLTypeId;
   private static final String XMLSIG = "%null%|";

  /**
    * Creates a default null Domain object, of type <code>VARCHAR</code>.
    */
   public NullValue()
   {
      mSQLTypeId = Types.VARCHAR;
   }

  /**
    * Creates a null value for a specified Domain type.
    *
    * @param sqlTypeId an integer representing a JDBC type.
    * @see "java.sql.TYPES"
    */
   public NullValue(int sqlTypeId)
   {
      //     KM: 2001-10-01 - fix for SQL*Server which doesn't like
      // column identifiers with value zero - zero seems to be used by AssociationDefImpl
      // as a "default" value
      if (sqlTypeId!=0)
      {
         mSQLTypeId = sqlTypeId;
      }
      else
      {
          mSQLTypeId = Types.VARCHAR;
      }
   }
   
  /**
    * Creates a null value for a specified Domain type.
    *
    * @param sqlType an string representing a JDBC type.
    * @see oracle.jbo.common.JboTypeMap
    */
   public NullValue(String sqlType)
   {
      // See the getXMLContentNode implementation below, also bug5191597
      // "UnknownSQLTypeException on activation with null-valued named bind var"

      if( sqlType != null && sqlType.startsWith(XMLSIG) )
         mSQLTypeId = Integer.parseInt( sqlType.substring(XMLSIG.length()), 10 );
      else
         mSQLTypeId = JboTypeMap.sqlTypeToSQLTypeId(sqlType);

      if (mSQLTypeId == Types.NULL)
      {
         throw new UnknownSQLTypeException(sqlType);
      }
   }

  /**
    * Converts <code>this</code> to a JDBC type ID.
    *
    * @value an integer representing a JDBC type.
    * @see "java.sql.TYPES"
    */
   public int getSQLTypeId()
   {
      return mSQLTypeId;
   }
   
  /**
    * Converts <code>this</code> to string naming a JDBC type.
    *
    * @value a string representing a JDBC type.
    * @see oracle.jbo.common.JboTypeMap
    */
   public String getSQLType()
   {
      return JboTypeMap.sqlTypeIdToSQLType(mSQLTypeId);
   }
  
  /**
    *  <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p> Converts <code>this</code> to a JDBC object.
    *
    * @value <code>null</code>.
    */
   public Object getData()
   {
      return null;
   }

     /**
    *  <b>Internal:</b> <em>Applications should not invoke this method.</em>
    * <p>
    */
   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
   }

  /**
    * For testing purposes only: converts <code>this</code> to a string.
    *
    * @value <code>null</code>.
    */
   public String toString()
   {
      return STR_NULL;
   }

   /**
    * Generates a hashcode for NullValue.
    *
    * @return the hashcode.
    */
   public int hashCode()
   {
      return -47;
   }
   
  /**
    * Tests <code>this</code> for equality with another object.
    *
    * @param obj  an arbitrary <code>Object</code>.
    * @return <code>true</code> if the parameter is either <code>null</code>,
    * or a <code>NullValue</code> of the same Domain type as <code>this</code>.
    */
   public boolean equals(Object obj)
   {
      if (obj == null)
      {
         return true;
      }

      if (obj instanceof NullValue)
      {
         NullValue nullVal = (NullValue) obj;

         if (nullVal.getSQLTypeId() == getSQLTypeId())
         {
            return true;
         }
      }

      return false;
   }

   /**
   * Prints the DTD info for this domain in the given print writer.
   * Returns the DTD string to be added to this domain's container
   * entity/domain.
   * <p> The <tt>allDefs</tt> hashtable contains predefined XML definitions and
   * is passed by whatever calls this method.
   * <p>
   * @param allDefs a hashtable of predefined XML definitions passed from whatever
   * calls this method.
   * @param pw print writer into which the defnition is being printed.
   * @param bContainees if <tt>true</tt>, prints definitions of contained objects.
   **/
   public String printXMLDefinition(java.util.Hashtable allDefs, java.io.PrintWriter pw, 
                                    boolean bContainees)
   {
      return "#PCDATA";
   }

  /**
  * Creates the xml node in the given xml document for this domain's data.
  * @param xmlDoc name of the XML document in which the node should be created.
  **/
  public Node getXMLContentNode(Document xmlDoc)
  {
     return xmlDoc.createCDATASection( XMLSIG+mSQLTypeId );
  }

  /**
   * Creates the xml node in the given xml document for this domain's data in hex format of the byte[]
   * representation of the data.
   * @param xmlDoc name of the XML document in which the node should be created.
   **/
   public Node getSerializedDomainXML(Document xmlDoc)
   {
      //for now render as String. If we find that this leads to NLS issues, we should
      //revert back to the RepConversion solution.
      return xmlDoc.createTextNode(toString());
      //return xmlDoc.createTextNode(oracle.jbo.common.RepConversion.bArray2String(getBytes()));
   }

   /**
   * <b>Internal:</b> <em>Applications should not use this method.</em>
   */
   public static XMLDomainReaderFactory getXMLDomainFactory(Class attrClass) 
   {
      class facClass implements XMLDomainReaderFactory, XMLDomainFactory
      {
         public DomainInterface createDomainFromXMLElement(org.w3c.dom.Element attrElem)
         {
            try
            {
               Node valNode = (Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     if (STR_NULL.equals(attrValue))
                     {
                        return new NullValue();
                     }
                     //get the properly typed-attribute value 
                     return new NullValue(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
         
         public Object createDomainFromSerializedXML(org.w3c.dom.Element attrElem)
         {
            try
            {
               Node valNode = (Node)attrElem.getFirstChild();
               if( valNode != null)
               {
                  String attrValue = valNode.getNodeValue();
                  if (attrValue != null)
                  {
                     if (STR_NULL.equals(attrValue))
                     {
                        return new NullValue();
                     }
                     return new NullValue(attrValue);
                  }
               }
            }
            catch (oracle.jbo.JboException e)
            {
               throw e;
            }
            catch (Exception e)
            {
               //throw new jbo exception here.
               throw new oracle.jbo.JboException(e);
            }
            return null;
         }
      }
      
      return new facClass();
   }

}
