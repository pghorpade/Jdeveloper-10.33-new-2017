/*
 * @(#)TypeConvMapEntry.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.JboTypeMap;

public class TypeConvMapEntry
{
   public static final byte TYPED_CTOR   = 0;
   public static final byte STRING_CTOR  = 1;
   public static final byte TYP_VALUE_OF = 2;
   public static final byte STR_VALUE_OF = 3;
   public static final byte TYPED_VALUE_MTH = 4;

   public static final byte STATIC_CONV  = 5;

   static final Object emptyObjs[] = new Object[]{};

   Object mMethod;
   byte   mEntryType;
   int    mOpId = -1;

   protected TypeConvMapEntry()
   {
   }

   public TypeConvMapEntry(byte typ, Method mth)
   {
      mEntryType = typ;
      mMethod = mth;
   }


   public TypeConvMapEntry(byte typ, Constructor mth)
   {
      mEntryType = typ;
      mMethod = mth;
   }


   public TypeConvMapEntry(int opId)
   {
      mEntryType = STATIC_CONV;
      mOpId = opId;
   }

   
   protected Object convert(Class toClass, Class valClass, Object val)
      throws Exception
   {
      Object methodArgs[] = new Object[1];

      switch(mEntryType)
      {
         case TYPED_CTOR:
            methodArgs[0] = val;
            return ((Constructor) mMethod).newInstance(methodArgs);

         case STRING_CTOR:
            methodArgs[0] = val.toString();
            return ((Constructor) mMethod).newInstance(methodArgs);

         case TYP_VALUE_OF:
            methodArgs[0] = val;
            return ((Method) mMethod).invoke(null, methodArgs);

         case STR_VALUE_OF:
            methodArgs[0] = val.toString();
            return ((Method) mMethod).invoke(null, methodArgs);

         case TYPED_VALUE_MTH:
            return ((Method) mMethod).invoke(val, emptyObjs);

         case STATIC_CONV:
            return JboTypeMap.convertValue(toClass, valClass, val, mOpId);
            
         default:
            Diagnostic.ASSERT(false, "Unknown TypeConvMapEntry type: " + mEntryType);
            return null;
      }
   }
}
