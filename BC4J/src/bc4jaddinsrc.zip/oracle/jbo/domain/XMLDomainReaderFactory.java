/*
 * @(#)XMLDomainFactory.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

/**
 * Each domain that can read xml, needs to implement getXMLDomainFactory()
 * method and return an instance of this interface for an attribute
 * def to invoke the domain to create an instance for a given xml-node.
 *
 * @since JDevloper 4.0
 */
public interface XMLDomainReaderFactory extends XMLValueFactory
{
   /*
   * Create a domain instance by reading the xml-data out of
   * the given xml-node.
   **/
   Object createDomainFromSerializedXML(org.w3c.dom.Element element);
}

