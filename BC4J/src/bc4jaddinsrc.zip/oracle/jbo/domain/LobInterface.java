/*
 * @(#)LobInterface.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;


/**
 * Provides methods to save data to, and extract data from,
 * LOB domain classes. These methods are implemented by all LOB-based
 * domain classes: {@link oracle.jbo.domain.BlobDomain BlobDomain},
 * {@link oracle.jbo.domain.BFileDomain BFileDomain}, and
 * {@link oracle.jbo.domain.ClobDomain ClobDomain}.
 *
 * <p>Domain classes encapsulate Oracle SQL datatypes.
 * Domain objects can be converted to the standard JDBC data types.
 *
 * @see TypeFactory
 * @see "JboDomainValidator"
 * @since JDevloper 3.0
 */
public interface LobInterface extends 
                                 BlobDomainInterface, 
                                 MutableDomainInterface
{

   /**
   * Synchronize the streams from an older version of this object so that
   * this version works with the opened streams (if any).
   **/
   void syncServerLob(LobInterface oldObject);

   /**
   * Synchronize client-side data from the given lob
   **/
   void syncClientLob(LobInterface oldObject);

   /**
   * Returns the reference to owner of this domain (could be the row
   * that this domain instance belongs to.)
   **/
   DomainOwnerInterface getOwner();

   /*
   * Returns the size of the data.
   */
   long getSize();

   String getRemoteIdString();

   /*
   * If this domain is set into a domain-owner, get the attributeindex
   * at which this domain was set.
   */
   int getOwnerAttributeIndex();
}
