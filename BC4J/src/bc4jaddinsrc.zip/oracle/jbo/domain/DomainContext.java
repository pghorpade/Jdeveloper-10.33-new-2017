/*
 * @(#)DomainContext.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

//internal
public final class DomainContext 
{
   static final public String RELATIVE_INDEX   = "0";
   static final public String ELEMENT_FACTORY  = "1";
   static final public String VARRAY_ELEMENT   = "2";
   static final public String CLIENT_DOMAIN    = "3";
   static final public String ELEMENT_SQL_NAME = "4";
   static final public String ELEMENT_TYPE     = "5";
}
