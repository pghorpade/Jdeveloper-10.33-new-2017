/*
 * @(#)DomainValidationException.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.CSMessageBundle;
import oracle.jbo.JboException;

/**
 * Indicates that a Domain object cannot be
 * created because validation has failed.
 *
 * <p>This exception is included for future use, and is not used in
 * JDevloper 3.0.
 *@since JDevloper 3.0
 */
/*
 * This exception is thrown when an object of a domain type fails to
 * create due to failures in validation
 *
 * @version PUBLIC
 * @see TypeFactory
 * @see JboDomainValidator
 */
public class DomainValidationException extends JboException {
   static final long serialVersionUID = -142780779143945782L;

  public DomainValidationException(String className)
  {
     super( CSMessageBundle.class,
            CSMessageBundle.EXC_VAL_DOMAIN_FAILED,
            (Object[]) null);
     Object arr[] = new Object[1];
     arr[0] = className;
     setErrorParameters(arr);
  }
}
