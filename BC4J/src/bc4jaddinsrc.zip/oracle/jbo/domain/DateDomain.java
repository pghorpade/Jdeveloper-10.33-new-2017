/*
 * @(#)DateDomain.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.sql.Date;
import java.sql.Timestamp;
import oracle.jbo.Transaction;

// ---------------------------------------------------
// ---    jbo generated file.
// ---    Business object: DateDomain
// ---------------------------------------------------
/**
 * @deprecated This class has been superceeded by <code>Date</code>.
 * <p>An encapsulation of Oracle SQL <code>DATE</code> objects as
 * immutable Domain objects.
 *
 * @see oracle.jbo.domain.Date
 * @since JDevloper 2.0
 */
public class DateDomain implements oracle.jbo.domain.DomainInterface, java.io.Serializable {
   static final long serialVersionUID = -8090406157415712829L;


  private Object mData = new NullValue();
  
  public DateDomain() {
  }

  
  public DateDomain(Date val) throws DomainValidationException {
    mData = new Date(val.getTime());
  }

  public DateDomain(Timestamp val) throws DomainValidationException {
    mData = Timestamp.valueOf(val.toString());
  }

  
  public DateDomain(String obj) throws DomainValidationException {

    //check if timestamp string, if so, store timestamp,
    //else store date.
    Date dateObj;
    Timestamp tsObj;
    try
    {
      obj = obj.trim(); 
      if( obj.length() > 0 )
      {
         mData = Date.valueOf(obj);
      }
    }
    catch(Exception e)
    {
       //must be a timestamp string.
       mData = Timestamp.valueOf(obj);
    }
  }

  public Object getData() {
    if( mData instanceof Timestamp )
    {
       Timestamp ts = (Timestamp) mData;
       if( ts.getHours() == 0 && ts.getMinutes() == 0
           && ts.getSeconds() == 0 && ts.getNanos() == 0 )
       {
          mData = new Date(ts.getYear(), ts.getMonth(), ts.getDate());
       }
    }
    return mData;
  }

  public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx) {
  }

  public String toString() {
    if (getData() != null) {
      return    mData.toString();
    }
    return "<null>";
  }

  public boolean equals(Object obj) {
    if (obj instanceof DomainInterface) {
      if (mData != null) {
        return getData().equals(((DomainInterface)obj).getData());
      }
      return ((DomainInterface)obj).getData() == null;
    }
    return false;
  }
  
   public int hashCode()
   {
      return getData().hashCode();
   }
}



 
