/*
 * @(#)DataCreationException.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.AttrValException;
import oracle.jbo.CSMessageBundle;
import oracle.jbo.ViewObject;

/**
 * Indicates that a Domain object could not be created.
 *
 * @since JDevloper 3.0
 */
public class DataCreationException
   extends AttrValException
{
   static final long serialVersionUID = -6379105704477707979L;
  public DataCreationException(String className,
                               Object val,
                               Exception ex)
  {
     super(CSMessageBundle.class,
           CSMessageBundle.EXC_DATA_CREATION_FROM_VALUE,
           (Object[]) null);

     Object arr[] = new Object[2];
     arr[0] = className;
     arr[1] = val;
     setErrorParameters(arr);
     if( ex != null )
     {
        addToDetails(ex);
     }
  }
  
  public DataCreationException(String className,
                               String message,
                               Exception ex)
  {
     super(CSMessageBundle.class,
           CSMessageBundle.EXC_DATA_CREATION_WITH_MSG,
           (Object[]) null);

     Object arr[] = new Object[2];
     arr[0] = className;
     arr[1] = message;
     setErrorParameters(arr);
     if( ex != null )
     {
        addToDetails(ex);
     }
  }

  public DataCreationException(String className,
                               Exception ex)
  {
     super(CSMessageBundle.class,
           CSMessageBundle.EXC_DATA_CREATION,
           (Object[]) null);

     Object arr[] = new Object[1];
     arr[0] = className;
     setErrorParameters(arr);
     if( ex != null )
     {
        addToDetails(ex);
     }
  }

  public DataCreationException(Class bundleClass,
                               String errorCode,
                               Object[] params,
                               Exception ex)
  {
     super(bundleClass, errorCode, params);

     if (ex != null)
     {
        addToDetails(ex);
     }
  }

  public void setAttrInfo(int objType, String objFullName, String attrName, Object attrValue)
  {
     init (objType, objFullName, attrName);
     mAttrValue = attrValue;
  }

  protected void setMappedParameters(ViewObject vo, String[] attrNames)
  {
     //do nothing as my exception message do not contain VO/Entity specific info.
     //so no exception params to map.
  }

} // class DataCreationException
