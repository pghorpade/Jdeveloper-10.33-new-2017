/*
 * @(#)DomainAttributeDef.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import com.sun.java.util.collections.HashMap;
import java.util.Hashtable;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.AttributeList;
import oracle.jbo.LocaleContext;
import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.Transaction;

import oracle.jbo.common.AttributeDefHelper;
import oracle.jbo.common.JboNameUtil;
import oracle.jbo.format.Formatter;

import java.text.ParseException;


public class DomainAttributeDef implements AttributeDef, AttributeHints
{
   String mName;
   String mColumnName;
   int mIndex;
   Class mJavaType;
   int mSQLType;
   String mSQLTypeName;
   int mScale;
   int mPrecision;
   boolean mIsMandatory;
   String mRefObjDefName;
   boolean mControlHintsFetched = false;
   Hashtable mProperties;
   

   public DomainAttributeDef(String name, String columnName, int index, 
                      Class javaType, int sqlType, String sqlTypeName,
                      int scale, int precision, boolean isMandatory)
   {
      mName = name;
      mColumnName = columnName;
      mIndex = index;
      mJavaType = javaType;
      mSQLType = sqlType;
      mSQLTypeName = sqlTypeName;
      mScale = scale;
      mPrecision = precision;
      mIsMandatory = isMandatory;
   }
   
   public DomainAttributeDef(String name, String columnName, int index, 
                      Class javaType, int sqlType, String sqlTypeName,
                      int scale, int precision, boolean isMandatory, 
                      String entityDefName)
   {
      this(name, columnName, index, javaType, sqlType,
                         sqlTypeName, scale, precision, isMandatory);
      mRefObjDefName = entityDefName;
   }
   
   
   /**
    * Gets the attribute kind.
    *
    * @return one of the <code>ATTR</code> constants defined for this class.
    */
   public byte getAttributeKind()
   {
      return ATTR_PERSISTENT;
   }


   /**
    * Gets the name of the attribute.
    *
    * @return the name of the attribute.
    */
   public String getName()
   {
      return mName;
   }
   

   /**
    * Gets the name of the database column the attribute represents.
    *
    * @return the name of the column.
    */
   public String getColumnName()
   {
      return mColumnName;
   }


   public String getColumnNameForQuery()
   {
      return getColumnName();
   }


   /**
    * Gets the index of the attribute in the context of a <code>StoreInfo</code>
    * instance.
    *
    * @return the index of the attribute row's definition object.
    */
   public int getIndex()
   {
      return mIndex;
   }
   
   public String getSQLTypeName()
   {
      return mSQLTypeName;
   }
   

   /**
    * Gets the Java class of the object stored for this attribute definition.
    *
    * @return the class of the attribute.
    */
   public Class getJavaType()
   {
      return mJavaType;
   }
   

   /**
    * Gets the JDBC type of the attribute.
    *
    * @return the JDBC type.
    * @see java.sql.Types
    */
   public int getSQLType()
   {
      return mSQLType;
   }
   

   /**
    * Get the scale value of a numeric attribute.
    * @return the scale value for this attribute, if applicable. 
    */
   public int getScale()
   {
      return mScale;
   }
   

   /**
    * Gets the precision of a numeric or string attribute.
    * <p>
    * 'Precision' for a string is the maximum length.
    *
    * @return the precision value for this attribute. 
    */
   public int getPrecision()
   {
      return mPrecision;
   }
   

   public boolean isSelected()
   {
      return false;
   }


   /**
    * Tests if an attribute is queriable.
    * <p>
    * Queriable attributes are those that
    * may have a filter condition for the WHERE clause
    * If this method returns false, the attribute will
    * not be used in constructing the WHERE clause
    * of SQL statements to fetch data.
    *
    * @return <code>true</code> if this attribute is queriable.
    */
   public boolean isQueriable()
   {
      return false;
   }


   /**
    * Tests if an attribute can be modified.
    *
    * @return <code>READONLY</code>, <code>UPDATEABLE</code>, or <code>UPDATEABLE_WHILE_NEW</code>.
    */
   public byte getUpdateableFlag()
   {
      return UPDATEABLE;
   }


   /**
    * Tests if an attribute is a Primary Key.
    *
    * @return <code>true</code> if this is either a Primary Key attribute or
    * part of the attributes that constitute the Primary Key for a given row.
    */
   public boolean isPrimaryKey()
   {
      return false;
   }
   

   /**
    * Tests if an attribute does not allow null values.
    * @return <code>true</code> if this attribute cannot store a null value
    **/
   public boolean isMandatory()
   {
      return mIsMandatory;
   }
   
   
   /**
    * Retrieves the specified property, if it exists.
    * @return the named property.
    */
   public Object getProperty(String hintName)
   {
      return null;
   }
   

   public Object refreshProperty(String hintName)
   {
      return getProperty(hintName);
   }


   public String getReferencedObjectDefName()
   {
      return mRefObjDefName;
   }


   /**
    * Gets the table of properties.
    * @return a hashtable of properties.
    */
   public Hashtable getProperties()
   {
      return mProperties;
   }


   /**
   * @deprecated since 9.0.2 use the other getXMLContentNode() .
   **/
   static public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc, 
                                                    Object attrValue,
                                                    boolean isCData)
   {
      return getXMLContentNode(xmlDoc, attrValue, isCData, false);
   }
   
   static public org.w3c.dom.Node getXMLContentNode(org.w3c.dom.Document xmlDoc, 
                                                    Object attrValue,
                                                    boolean isCData,
                                                    boolean serialize)
   {
      if (attrValue != null)
      {
         if (serialize && attrValue instanceof XMLDomainWriter) 
         {
            return ((XMLDomainWriter)attrValue).getSerializedDomainXML(xmlDoc);
         }
         if (attrValue instanceof XMLDomainInterface)
         {
            return ((XMLDomainInterface)attrValue).getXMLContentNode(xmlDoc);
         }
         
         //for attribute values that cannot be represented by toString(), how about
         //a from/toXML() method that lets the domain implement it's rendering.
         //Likewise for dtd, we may need an extra method.
         
         return (isCData) 
                ? xmlDoc.createCDATASection(attrValue.toString())
                : xmlDoc.createTextNode(attrValue.toString());
      }

      return null;
   }


   //method to print any attribute def into xml definition.
   //used in AttributeDefImpl and Struct classes.
   static public String printAttrXMLDefinition(AttributeList row, 
                                               String attrTag,
                                               AttributeDef ad,
                                               java.util.Hashtable allDefs, 
                                               java.io.PrintWriter pw, 
                                               boolean bContainees)
   {
      if (allDefs.get(attrTag) == null) 
      {
         Object sValue = row.getAttribute(ad.getIndex());
         String elemStr = "#PCDATA";

         if (sValue instanceof XMLDomainInterface)
         {
            elemStr = ((XMLDomainInterface)sValue).printXMLDefinition(allDefs, pw, bContainees);
         }
         pw.println((new StringBuffer("<!ELEMENT ")
                         .append(attrTag)
                         .append(" (")
                         .append(elemStr)
                         .append(")>"))
                         .toString()
                    );
         allDefs.put(attrTag, attrTag);
      }

      if (!(ad.isPrimaryKey() || ad.isMandatory()))
      {
         attrTag = attrTag + "?";
      }
      return attrTag;
   }

   /**
   * Returns an an instance of the refernced row, given the attribute
   * definition object.
   *
   * The referenced row is returned as an {@link oracle.jbo.Row} object.
   * @param ad the attribute's attribute definition object.
   * @return the row corredsponding to the attribute definition object.
   * @see oracle.jbo.Row
   *
   */
   Row getReferencedObject(Object refDomain, Transaction trans)
   {
      oracle.jbo.server.EntityDefImpl ed = oracle.jbo.server.EntityDefImpl.findDefObject(getReferencedObjectDefName());
      if (ed != null)
      {
         oracle.jbo.server.AttributeListImpl al = new oracle.jbo.server.AttributeListImpl();
         al.setAttribute("REF$", refDomain);
         return ed.findByPrimaryKey((oracle.jbo.server.DBTransaction)trans, ed.createKey(al));
      }
      return null;
   }

   /**
    * Return null;
    */
   public Class getElemType()
   {
      return null;
   }

   /**
    * Return -1;
    */
   public int getElemSQLType()
   {
      return java.sql.Types.NULL;
   }

   /**
   ** return the AttributeHints interface implemented by this class
   **/
   public AttributeHints getUIHelper()
   {
      return this;
   }

// Attribute hints implementation
   public String  getLocaleName(LocaleContext locale, String sName)
   {
      return JboNameUtil.getLocaleName(locale , sName);
   }


   //for internal use only.
   String getControlHint(LocaleContext locale, String sName)
   {
      if (sName == null) 
      {
         return null;
      }

      if (!mControlHintsFetched) 
      {
         mControlHintsFetched = true;
         if (mProperties == null) 
         {
            oracle.jbo.common.Diagnostic.println("No Properties thus far! trying to fetch properties for:"+getName());
            return null;
         }
      }

      if (mProperties == null)
      {
         return null;
      }
      String prop = (String)mProperties.get(getLocaleName(locale, sName));

      if(prop == null)
        prop = (String)mProperties.get(sName);
        
      if (prop == null) 
      {
         HashMap map = (HashMap)mProperties.get("__bc4j_res__");
         if (map != null) 
         {
            String resName = (new StringBuffer(getName())).append("_").append(sName).toString();
            prop = (String)map.get(resName);
         }
      }
      return prop;
   }

   //for internal use only.
   void setControlHints(Hashtable props)
   {
      mProperties = props;
      mControlHintsFetched = true;
   }

  /**
   ** Retrieves the label to be used in any attribute prompts
   **/
   public String getLabel(LocaleContext locale)
   {
      String sLabel = getControlHint(locale, ATTRIBUTE_LABEL);
      if(sLabel == null)
      {
           // use the attribute name
         sLabel = getName();
      }
      return sLabel;
   }

   /**
   **  Retrives the tooltip text to be used for this attribute
   **/
   public String getTooltip(LocaleContext locale)
   {
      return getControlHint(locale, ATTRIBUTE_TOOLTIP);
   }

   /**
   **    Retrieves the displya hint that dictates whether this
   **  attributr should be visible or not. The two possible values
   **  are:
   **    ATTRIBUTE_DISPLAY_HINT_DISPLAY  = "Display";
   **    ATTRIBUTE_DISPLAY_HINT_HIDE     = "Hide";
   **/
   public String getDisplayHint(LocaleContext locale)
   {
      String sDisplayHint = getControlHint(locale, ATTRIBUTE_DISPLAY_HINT);
      if(sDisplayHint == null)
         sDisplayHint = ATTRIBUTE_DISPLAY_HINT_DISPLAY;

      return sDisplayHint;
   }

   /**
   **    Returns the preferred control type for this attribute
   **/
   public int getControlType(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_TYPE);

      if (sValue != null)
         return Integer.parseInt(sValue);

      // no hint is setup, return the default and let the client runtime or designtime decide
      // which control to use
      return CTLTYPE_DEFAULT;
   }

   /**
   **    Returns the display width for this attribute
   **/
   public int getDisplayWidth(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_DISPLAYWIDTH);

      if(sValue != null)
         return Integer.parseInt(sValue);

      return getPrecision();
   }

  /**
   **    Returns the display width for this attribute
   **/
   public int getDisplayHeight(LocaleContext locale)
   {
      String sValue = getControlHint(locale, ATTRIBUTE_CTL_DISPLAYHEIGHT);

      if(sValue != null)
         return Integer.parseInt(sValue);

      return 1;
   }

   /**
   ** Return defaulted hint value
   **/
   public String getHint(LocaleContext locale, String sHintName)
   {
      if (sHintName.equals(ATTRIBUTE_LABEL))
      {
         return getLabel(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_TOOLTIP))
      {
         return getTooltip(locale);
      }
      else if (sHintName.equals(ATTRIBUTE_CTL_DISPLAYWIDTH))
      {
         return Integer.toString(getDisplayWidth(locale));
      }
      else
      {
         return getControlHint(locale, sHintName);
      }
   }

   /**
   ** Return non-defaulted hint value
   **/
   public String getHintValue(LocaleContext locale, String sHintName)
   {
      return getControlHint(locale, sHintName);
   }

   // formatting support
   public String getFormat(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      return getControlHint(locale, AttributeHints.FMT_FORMAT);
   }

   public Formatter getFormatter(LocaleContext locale)
   {
      if(!hasFormatInformation(locale))
      {
         return null;
      }

      String   sFormatter = getFormatterClassName(locale);
      String   sFormat = getFormat(locale);

      try
      {
         Class cls = Class.forName(sFormatter);

         Formatter formatter = (Formatter)cls.newInstance();

         return formatter;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public boolean hasFormatInformation(LocaleContext locale)
   {
      String   sFormatter = getControlHint(locale, AttributeHints.FMT_FORMATTER);

      if(sFormatter == null || sFormatter.equals(""))
         return false;

      return true;
   }

   public String getFormattedAttribute(AttributeList attrList, LocaleContext locale)
   {
      Object   aValue = attrList.getAttribute(getIndex());

      if(aValue == null)
          return null;

      if(aValue.equals(""))
         return "";
      
      if(!hasFormatInformation(locale))
      {
         return aValue.toString();
      }

      try
      {
         Formatter   formatter = getFormatter(locale);
         String      sFormat = getFormat(locale);

         formatter.setLocale(locale);

         String sRet = formatter.format(sFormat, aValue);

         return sRet;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public Object parseFormattedAttribute(String sValue, LocaleContext locale)
   {
       if(sValue == null)
           return null;

       if(sValue.equals(""))
            return "";

      if(!hasFormatInformation(locale))
      {
         return sValue;
      }

      try
      {
         Formatter formatter = getFormatter(locale);
         String    sFormat = getFormat(locale);

         formatter.setLocale(locale);

         Object newValue = formatter.parse(sFormat, sValue);

          // if the parser failed, just return the initial value
         if(newValue == null)
          return sValue;

         return newValue;
      }
      catch(ParseException parseEx)
      {
          return sValue;
      }
      catch(Exception ex)
      {
         throw new JboException(ex);
      }
   }

   public boolean displayInShortForm(LocaleContext locale)
   {
      String    sFormType = getControlHint(locale, AttributeHints.ATTRIBUTE_CTL_FORMTYPE);

      if(sFormType == null)
         return false;
         
      if(sFormType.equals(AttributeHints.ATTRIBUTE_FORM_TYPE_SHORT))
         return true;

      return false;
   }

      /**
   ** returns the formatter object stored in the ui hints
   **/
   public String getFormatterClassName(LocaleContext locale)
   {
      return getControlHint(locale, AttributeHints.FMT_FORMATTER);
   }

}
