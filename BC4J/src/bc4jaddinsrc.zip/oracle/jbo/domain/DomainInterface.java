/*
 * @(#)DomainInterface.java
 *
 * Copyright 1998-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import oracle.jbo.Transaction;

/**
 * 
 * Implemented by domain classes to save data to, and extract data from,
 * a domain class.
 *
 * <p>Domain classes extend or encapsulate Oracle SQL datatypes.
 * Domain objects can be converted to the standard JDBC data types.
 *
 * @see TypeFactory
 * @since JDevloper 3.0
 */
public interface DomainInterface {


  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
   * <p>
   * Returns the value in the format that is acceptable to the database.
   * <p>For domain classes based on <code>oracle.sql.*</code> classes,
   * this method returns a <code>Datum</code> object.
   * For domains based on <code>java.lang</code> types such as <code>String</code>,
   * the value-holder object that is passed to JDBC is returned.
   * @return a formatted value object.
   */
  Object getData();

  /**
  * <b>Internal:</b> <em>Applications should not use this method.</em>
  */

  //ctx is an object array with following elements in 3.2.2
  //   AttributeIndex wrt. to the domain owner
  //   ElementFactory for VARRAYs
  void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx);
}
