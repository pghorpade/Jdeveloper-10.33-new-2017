/*
 * @(#)SQLValue.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.domain;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import oracle.jbo.ApplicationModule;
import oracle.jbo.JboException;
import oracle.jbo.Transaction;
import oracle.jbo.common.JBOClass;
// import oracle.jbo.common.JboEnvUtil;

public class SQLValue implements DomainInterface, Serializable
{
   static final long serialVersionUID = 3218652266170712346L;

   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   public static final String SQLVAL_IMPL_CLIENT = "oracle.jbo.client.remote.SQLValueImpl";

   /**
   * <b>Internal:</b> <em>Applications should not use this field.</em>
   */
   public static final String SQLVAL_IMPL_SERVER = "oracle.jbo.server.SQLValueImpl";

   private Object mVal = null;

   /**
   * Constructs a SQLValue object.
   */
   public SQLValue()
   {
   }


   /**
   * Constructs a SQLValue object, given an Application Module instance.
   * @param stmt
   * @param am an instance of the Application Module where the SQLValue will be used.
   */
   public SQLValue(String stmt, ApplicationModule am)
   {
      Class implCls;

      try
      {
         // if (JboEnvUtil.isClient(am.getSession().getEnvironment()))
         if (am.getSession().isClient())
         {
            implCls = Class.forName(SQLVAL_IMPL_CLIENT);
         }
         else
         {
            implCls = JBOClass.forName(SQLVAL_IMPL_SERVER);
         }

         Constructor cons = implCls.getConstructor(new Class[] { String.class, ApplicationModule.class });
         DomainInterface impl = (DomainInterface) cons.newInstance(new Object[] { stmt, am });

         mVal = impl.getData();
      }
      catch(Exception ex)
      {
         Throwable th = ex;

         if (th instanceof InvocationTargetException)
         {
            th = ((InvocationTargetException) th).getTargetException();
         }

         if (th instanceof JboException)
         {
            throw (JboException) th;
         }

         throw new JboException(th);
      }
   }


   public Object getData()
   {
      return mVal;
   }


   public void setContext(DomainOwnerInterface owner, Transaction trans, Object ctx)
   {
   }

   /**
   * For testing purposes only: converts <tt>this</tt>
   *  to a textual representation.
   */
   public String toString()
   {
      return getData().toString();
   }


   /**
   * Tests <tt>this</tt> for equality with another object.
   *
   * @param other an arbitrary <tt>Object</tt>.
   * @return <tt>true</tt> if conversion was successful and the
   * converted argument is identical to <tt>this</tt>.
   */
   public boolean equals(Object other)
   {
      return getData().equals(other);
   }


  /**
  * Computes a hash code for <tt>this</tt>.
  * @return an integer hashcode for <tt>this</tt>.
  */
   public int hashCode()
   {
      return getData().hashCode();
   }


   private void writeObject(java.io.ObjectOutputStream out)
      throws java.io.IOException
   {
      out.writeInt(((Integer) getData()).intValue());
   }


   private void readObject(java.io.ObjectInputStream in)
      throws java.io.IOException, ClassNotFoundException
   {
      mVal = new Integer(in.readInt());
   }
}
