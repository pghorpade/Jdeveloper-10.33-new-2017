/*
 * @(#)VOTreeNode.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;
import oracle.jbo.ComponentObject;
import oracle.jbo.VariableManager;
import oracle.jbo.Variable;
import oracle.jbo.jbotester.properties.ViewObjectBean;

public final class VOTreeNode extends ObjTreeNode
{
   private ApplicationModule am;
   private String            name;
   private ViewObject        vo;
   private static ImageIcon  icon; // shared by all instance of this class

   public VOTreeNode(ViewObject viewObject)
   {
      this(viewObject.getApplicationModule(), viewObject);
   }
   
   public VOTreeNode(ApplicationModule appMod, ViewObject viewObject)
   {
      this(appMod, viewObject.getName());

      vo = viewObject;
   }

   public VOTreeNode(ApplicationModule appMod, String voName)
   {
      super(voName);

      name = voName;
      am = appMod;

      if (icon == null)
      {
         icon = JboTesterUtil.getIcon("NodeVOU.gif");
      }
   }

   public String getName()
   {
      return name;
   }

   public String getFullName()
   {
      if (vo != null)
      {
         return vo.getFullName();
      }
      else
      {
         return (am.getFullName() + "." + name);
      }
   }

   public int getType()
   {
      return VIEW_OBJECT;
   }

   public Object getData()
   {
      return getViewObject();
   }

   protected ViewObject getViewObject()
   {
      if (vo == null)
      {
         vo = am.findViewObject(name);
      }

      return vo;
   }

   public void setData(Object data)
   {
      vo = (ViewObject) data;
   }

   public ImageIcon getIcon()
   {
      return icon;
   }

   public void showForm()
   {
      String fullName = getFullName();

      ResultWindow rw = ResultWindow.getResultWindow();
      if (rw.getTab(fullName) == null)
      {
         MainFrame.getInstance().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
         try
         {
            rw.addTab(new SimpleForm(MainFrame.getInstance(), this, getViewObject()), fullName);
         }
         catch(Throwable t)
         {
            ErrorHandler.displayError(MainFrame.getInstance(), t);
         }
         MainFrame.getInstance().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
      }
      else
      {
         rw.showTab(fullName);
      }
   }
   
   public String getStatus()
   {
      StringBuffer status = new StringBuffer();

      status.append(Res.getString(Res.TREE_STATUS_LINE_NAME));

      if (vo != null)
      {
         status.append(vo.getFullName());
         status.append(Res.getString(Res.TREE_STATUS_LINE_DEFINITION));
         status.append(vo.getDefFullName());

         // Select the form matching
//Should not active the window
//          ResultWindow.getResultWindow().showTab(am.getName() + "." + name);
      }
      else
      {
         status.append(name);
      }

      return status.toString();
   }

   public void handleEvent(ActionEvent e)
   {
      if (e.getActionCommand().equals(JboTesterUtil.stripMnemonic(Res.getString(Res.TREE_MENU_FIND))))
      {
         JboTesterUtil.createViewCriteria(MainFrame.getInstance(), vo);
      }
      else if (e.getActionCommand().equals(JboTesterUtil.stripMnemonic(Res.getString(Res.TREE_MENU_EXECUTE))))
      {
         vo.executeQuery();
      }
      else if (JboTesterUtil.stripMnemonic(Res.getString(Res.TREE_MENU_BIND_VARIABLES))
         .equals(e.getActionCommand()))
      {
         JboTesterUtil.editBindParameters(MainFrame.getInstance(), vo);
      }
   }

   public JPopupMenu getMenu()
   {
      return createVOVLMenu(vo);
   }

   public void remove()
   {
      // Get the AM instance if not removed yet
      if (vo == null)
      {
         getViewObject();
      }
      
      if (vo != null)
      {
         // Remove the associated form panel
         JPanel form = ResultWindow.getResultWindow().removeTab(getFullName());
         if (form != null)
         {
            ((SimpleForm) form).setIterator(null);
            if (form instanceof MDForm)
            {
               ((MDForm) form).setDetailRowSetIterator(null);
            }
         }

         vo.remove(); // Remove the vo instance from the Application Module
         vo = null;
      }

      super.remove(); // That will remove the child
   }

   public void showProperties()
   {
      // Get the vo instance if not there yet
      getData();

      ViewObjectBean voBean = new ViewObjectBean(vo, isFormDisplayed(vo));
      showPropertyDialog(voBean, voBean.getBeanInfo(), Res.TREE_voProperties);
   }

   protected boolean isBindParameterActionEnabled(ComponentObject cObj)
   {
      return JboTesterUtil.hasBindParameters(cObj != null
         ? (ViewObject)cObj : getViewObject());
   }
}
