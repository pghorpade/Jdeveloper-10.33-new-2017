/*
 * @(#)JTDialog.java
 * 
 * Copyright 1999-2005 by Oracle Corporation, 500 Oracle Parkway, Redwood
 * Shores, California, 94065, U.S.A. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Oracle
 * Corporation.
 */
package oracle.jbo.jbotester;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.KeyStroke;

/**
 * JTDialog is the base class for all dialogs in the jbotester package. It adds
 * basic functionality to the swing JDialog, such as Help and keyboard actions.
 */
abstract public class JTDialog extends JDialog
{
  private final class CancelAction extends AbstractAction
  { 
    public CancelAction()
    {
      super(JboTesterUtil.stripMnemonic(Res.getString(Res.DIALOG_CANCEL_BUTTON)));
    }
    
    /**
     * The cancel action will be performed when ESC is pressed.
     * Derived classes may link this action to a button as well.
     * @param e ActionEvent
     */ 
    public void actionPerformed(ActionEvent e)
    {
      cancel();
      close();
    }
  }
  private final class HelpAction extends AbstractAction
  {
    public HelpAction()
    {
      super(JboTesterUtil.stripMnemonic(Res.getString(Res.DIALOG_HELP_BUTTON)));
    }

    /**
     * The help action will be performed when F1/HELP is pressed.
     * Derived classes may link this action to a button as well.
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e)
    {
      doHelp();
    }
  }
  public static final String     CANCEL_ACTION = "cancel";
  private String                 helpLocation;
  private boolean                isRegisteredToHelp;
  protected final CancelAction   cancelAction  = new CancelAction();
  protected final AbstractAction helpAction    = new HelpAction();
  protected final Frame                parent;


  /**
   * @param parent MainFrame
   * @param title the resource ID for the title
   */
  protected JTDialog(Frame parent, int title)
  {
    this(parent, Res.getString(title));
  }
  
  /**
   * @param parent MainFrame
   * @param title the parsed string for the title
   */
  protected JTDialog(Frame parent, String title)
  {
    super(parent, title, true);
    this.parent = parent;
    this.registerKeyboardActions();
    this.setHelpLocation(HelpManager.getHelpTopic(this));
  }

  public void close()
  {
    if (isRegisteredToHelp)
    {
      oracle.bali.ewt.util.WindowUtils.unregisterWindow(this);
      isRegisteredToHelp = false;
    }
    this.setVisible(false);
    this.dispose();
  }

  /**
   * @return the URL specifying the help location for this dialog.
   */
  public String getHelpLocation()
  {
    return helpLocation;
  }

  /**
   * @param help the URL specifying the help location for this dialog.
   */
  public void setHelpLocation(String help)
  {
    helpLocation = help;
  }

  public void show()
  {
    this.pack();
    this.setLocationRelativeTo(parent);
    super.show();
  }

  private final void registerKeyboardActions()
  {
    JComponent c = getRootPane();
    // register an action listener for f1
    c.registerKeyboardAction(helpAction, KeyStroke.getKeyStroke(KeyEvent.VK_F1,
        0), JComponent.WHEN_IN_FOCUSED_WINDOW);
    c.registerKeyboardAction(helpAction, KeyStroke.getKeyStroke(
        KeyEvent.VK_HELP, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
    // register an action listener for Esc
    c.registerKeyboardAction(cancelAction, CANCEL_ACTION, KeyStroke
            .getKeyStroke(KeyEvent.VK_ESCAPE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW);
  }

  protected void cancel()
  {
    //override if specific cancel handling is needed
  }
  
  protected void save()
  {
    //override if specific save logic is needed
  }

  protected void doHelp()
  {
    if (parent instanceof MainFrame)
    {
      if (!isRegisteredToHelp)
      {
        isRegisteredToHelp = true;
        oracle.bali.ewt.util.WindowUtils.registerWindow(this);
      }
      ((MainFrame) parent).helpMe(helpLocation);
    }
  }
}
