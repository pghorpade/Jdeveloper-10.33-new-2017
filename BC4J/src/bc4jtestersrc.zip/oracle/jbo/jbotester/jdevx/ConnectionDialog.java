/*
 * @(#)ConnectionDialog.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.jdevx;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Hashtable;
import javax.swing.DefaultComboBoxModel;
import oracle.jbo.client.Configuration;
import oracle.jbo.client.JboCMUtils;
import oracle.jbo.jbotester.ConfigMode;
import oracle.jbo.jbotester.ConnectionDialogBase;
import oracle.jbo.jbotester.ErrorHandler;
import oracle.jdeveloper.cm.ConnectionDescriptor;
import oracle.jdeveloper.cm.ConnectionManager;

public final class ConnectionDialog extends ConnectionDialogBase
{
   public ConnectionDialog(Frame frame, Hashtable cmdParams, Configuration configMgr, ConfigMode mode, ActionListener help, int flags)
   {
      super(frame, cmdParams, configMgr, mode, help, flags);
   }

   static public void launchConnectDialog(Frame frame, Hashtable cmdParams)
   {
      Configuration configMgr = new Configuration();
      try
      {
         // To fill the configuration combobox at the top of the tester, set
         // the path of the package containing the configuration file.
         configMgr.loadFromFile(Configuration.buildConfigurationFileName("J:\\myprojects\\package1"));
      }
      catch (Exception e)
      {
         configMgr = null;
      }

      ConnectionDialog dlg;

      int flags = CONNECT;
      if (configMgr != null)
      {
         flags = flags | SHOW_NAME;
         dlg = new ConnectionDialog(frame, cmdParams, configMgr, ConfigMode.RUN, null, flags);
      }
      else
      {
         dlg = new ConnectionDialog(frame, cmdParams, null, ConfigMode.RUN, null, flags);
      }

      dlg.show();
   }


   protected void connTypeCombo_actionPerformed(ActionEvent e)
   {
      ConnectionDescriptor cd = null;
      String usr = "?";
      String url = "?";

      try
      {
         String connectionName = (String) connTypeCombo.getSelectedItem();
         if (connectionName != null && connectionName.length() > 0)
         {
            cd = ConnectionManager.getInstance().getConnectionDescriptor(connectionName);
            if (cd != null)
            {
               usr = cd.getUsername();

               url = JboCMUtils.getJdbcUrl(cd);
            }
         }
      }
      catch (Exception ex)
      {
         ErrorHandler.displayError(parent, ex);
      }

      // Change the default jndi path when the connection changes
      String oldUser = userNameField.getText();
      if (oldUser != null && usr != null && oldUser.compareTo(usr) != 0)
      {
         userNameField.setText(usr);
      }

      urlField.setText(url);
   }

   protected void updateConnectionParams(Hashtable params, String connectionName)
      throws IOException
   {
      ConnectionDescriptor cd = ConnectionManager.getInstance().getConnectionDescriptor(connectionName);

      String ct = cd.getConnectionType();
      if (ConnectionDescriptor.CONN_ORACLE_JSERVER.compareTo(ct) == 0)
      {
         params.put(Configuration.JDBC_CONNECTION_NAME, connectionName);
//don't need that         params.put(Configuration.IIOP_CONNECTION_NAME, connectionName);
         params.remove(Configuration.HTTP_CONNECTION_NAME);
      }
      else if (ConnectionDescriptor.LEGACY_TYPE_JDBC.compareTo(ct) == 0 || 
               ConnectionDescriptor.CONN_ORACLE_LITE.compareTo(ct) == 0 ||
               ConnectionDescriptor.CONN_OTHER_JDBC.compareTo(ct) == 0)
      {
         params.put(Configuration.JDBC_CONNECTION_NAME, connectionName);
         params.remove(Configuration.IIOP_CONNECTION_NAME);
         params.remove(Configuration.HTTP_CONNECTION_NAME);
      }
      else if (ConnectionDescriptor.LEGACY_TYPE_IIOP.compareTo(ct) == 0)
      {
         params.put(Configuration.IIOP_CONNECTION_NAME, connectionName);
         params.remove(Configuration.HTTP_CONNECTION_NAME);
      }
      else if ("HTTP".compareTo(ct) == 0)
      {
         params.put(Configuration.HTTP_CONNECTION_NAME, connectionName);
         params.remove(Configuration.JDBC_CONNECTION_NAME);
         params.remove(Configuration.IIOP_CONNECTION_NAME);
      }
   }

   protected void updateConnectionCombo(int orbType)
   {
//      String newSelection = previousConnection;
      if (connTypeCombo.getItemCount() > 0)
      {
//         previousConnection = (String) connTypeCombo.getSelectedItem();
         connTypeCombo.removeAllItems();
      }

      try
      {
         String connections[] = ConnectionManager.getInstance().getConnectionNamesForClass(ConnectionDescriptor.CLASS_DATABASE);

         mainConnPanel.repaint();

         connTypeCombo.setModel(new DefaultComboBoxModel(connections));

/*         if (newSelection != null)
         {
            connTypeCombo.setSelectedItem(newSelection);
         }
         else */
         if (connTypeCombo.getItemCount() > 0)
         {
            connTypeCombo.setSelectedIndex(0);
         }
      }
      catch (Exception ex)
      {
         ErrorHandler.displayError(parent, ex);
      }
   }
}
