/*
 * @(#)ConnectionInfo.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.util.Hashtable;

import oracle.jbo.ApplicationModule;
import oracle.jbo.JboContext;
import oracle.jbo.ConnectionModeConstants;
import oracle.jbo.JboException;
import oracle.jbo.DMLException;

import oracle.jbo.client.Configuration;

import oracle.jbo.common.PropertyMetadata;

import java.awt.Component;

import javax.swing.JOptionPane;

import javax.naming.NoPermissionException;


public final class ConnectionInfo
{
   // public constants
   public static final String ORB_GATEKEEPER_IOR   = "ORBgatekeeperIOR";

   private static ApplicationModule mRootAppModule;
   private static boolean           mIsConnected;
   private static Hashtable         env;

   public static boolean isConnected()
   {
      return mIsConnected;
   }

   public static void setConnected(boolean connected)
   {
      mIsConnected = connected;
   }

   public static ApplicationModule getRootAppModule()
   {
      return mRootAppModule;
   }

   public static void setRootAppModule(ApplicationModule rootAppMod)
   {
      mRootAppModule = rootAppMod;
   }

   public static String getConnectionTitle()
   {
      int      resString = Res.CONNECT_INFO_NOT_CONNECTED;
      String   deployPlatform = null;

      if (!mIsConnected || getEnv() == null || (deployPlatform  = (String) getEnv().get(PropertyMetadata.DEPLOY_PLATFORM.getName())) == null)
      {
         resString = Res.CONNECT_INFO_NOT_CONNECTED;
      }
      else if (deployPlatform.equals(JboContext.PLATFORM_LOCAL))
      {
         resString = Res.CONNECT_INFO_LOCAL;
      }
      else if (deployPlatform.equals(JboContext.PLATFORM_VB))
      {
         switch (getConnectionMode(getEnv()))
         {
            case ConnectionModeConstants.COLOCATE:
               resString = Res.CONNECT_INFO_VB_COLOCATE;
               break;

            case ConnectionModeConstants.USE_BIND:
               resString = Res.CONNECT_INFO_VB_USE_BIND;
               break;

            case ConnectionModeConstants.REMOTE:
               resString = Res.CONNECT_INFO_VB_REMOTE;
               break;
         }
      }
      else if (deployPlatform.equals(JboContext.PLATFORM_WLS))
      {
         resString = Res.CONNECT_INFO_WL;
      }
      else if (deployPlatform.equals(JboContext.PLATFORM_EJB_IAS))
      {
         resString = Res.CONNECT_INFO_IAS;
      }

      return Res.getString(resString);
   }

   public static void setEnv(Hashtable connectionEnv)
   {
      env = connectionEnv;
   }

   public static Hashtable getEnv()
   {
      return env;
   }

   public static boolean useApplicationModule(Component parent, Configuration config, String configName)
   {
      ApplicationModule appMod = null;
      boolean correctPassword = false;
      
      do
      {
         if (!correctPassword)
         {
            TesterEnvInfoProvider prov = new TesterEnvInfoProvider(parent);
         
            correctPassword = true;

            try
            {
               appMod = config.createRootApplicationModuleFromConfig(
                  configName, prov);


               if (Configuration.APPLICATION_TYPE_VALUE_PACKAGE.equals(
                  appMod.getSession().getEnvironment()
                  .get(Configuration.APPLICATION_TYPE_PROPERTY)))
               {
                  appMod.getSession().loadPackage((String)appMod
                     .getSession()
                     .getEnvironment()
                     .get(Configuration.APPLICATION_NAME_PROPERTY));
               }
            }
            catch (JboException je)
            {
               Object[] details = je.getDetails();

               if (details != null
                  && details.length > 0
                  && (details[0] instanceof NoPermissionException
                     || details[0] instanceof DMLException))
               {
                  // This is when 8i or ejb failed to connect due to wrong
                  // credentials
                  ErrorHandler.displayError(
                     JOptionPane.getFrameForComponent(parent)
                     , (Exception)details[0]);

                  correctPassword = false;
               }
               else if (details != null && details.length > 0)
               {
                  // find the base detail exception
                  Object detail = je;
                     
                  while (details != null && details.length > 0)
                  {
                     detail = details[0];
                     if (details[0] instanceof CancelException)
                     {
                     /**
                      * all kinds of bad things happened because the user didn't provide
                      * a password, and didn't want to do so either (cancel was pressed)
                      * so ignore everything and quit.
                      */
                       return false;
                     }
                     if (details[0] instanceof JboException)
                     {
                        details = ((JboException)details[0]).getDetails();
                     }
                     else
                     {
                        break;
                     }
                  }

                  if ((detail != null)
                     && (detail instanceof javax.naming.NamingException))
                  {
                     Hashtable env = config.getConfiguration(configName);
                     if (Configuration.isEmbeddedConfig(env)
                        && JboContext.PLATFORM_EJB_IAS.equals(
                           env.get(JboContext.DEPLOY_PLATFORM)))
                     {
                        je = new JboException(Res.getString(Res.ERROR_EMBEDDED_SERVER_NOT_STARTED));
                        je.addToDetails(detail);
                     }
                  }   
               }

               if (correctPassword)
               {
                  throw je;
               }
            }
         }
      } while (!correctPassword);

      setConnected(true);
      setRootAppModule(appMod);

      return true;
   }

   public static void releaseApplicationModule()
   {
      ApplicationModule appMod = getRootAppModule();
      if (appMod != null)
      {
         Configuration.releaseRootApplicationModule(appMod, true);
         ConnectionInfo.setRootAppModule(null);
         ConnectionInfo.setConnected(false);
      }
   }

   public static int getConnectionMode(Hashtable env)
   {
      String modeStr = (String) env.get(PropertyMetadata.CONNECTION_MODE.getName());

      if (modeStr == null)
      {
         return ConnectionModeConstants.COLOCATE;
      }

      return Integer.parseInt(modeStr);
   }


}
