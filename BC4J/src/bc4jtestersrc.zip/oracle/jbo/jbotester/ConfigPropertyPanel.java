/* $Header: ConfigPropertyPanel.java 22-jun-2005.14:41:32 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    ConfigPropertyPanel is the panel used to maintain BC4J configuration 
    properties.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     06/22/05 - rvangri_connectiondialogbase_20050622
    rvangri     06/22/05 - Creation
 */

/**
 *  @version $Header: ConfigPropertyPanel.java 22-jun-2005.14:41:32 rvangri Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import oracle.jbo.common.PropertyMetadata;
import com.sun.java.util.collections.ArrayList;
import com.sun.java.util.collections.Collections;

public class ConfigPropertyPanel extends JPanel
{
  private final class PropConfPanelButtonActionListener implements
  ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      Property[] properties = getProperties();
      String cmd = event.getActionCommand();
      if (cmd.equals(ADD_ACTION))
      {
        addPropButton.setEnabled(false);
        if (tableView.isEditing()
            && !tableView.getCellEditor().stopCellEditing())
        {
          return;
        }
        addPropButton.setEnabled(true);
        Property[] tmp = new Property[properties.length + 1];
        System.arraycopy(properties, 0, tmp, 0, properties.length);
        properties = tmp;
        int newPos = properties.length - 1;
        properties[newPos] = new Property("", "", null, false, true, true, true);
        dataModel.setProperties(properties);
        dataModel.fireTableDataChanged();
        tableView.setRowSelectionInterval(newPos, newPos);
        tableView.scrollRectToVisible(tableView.getCellRect(newPos, 0, false));
        tableView.editCellAt(newPos, 0);
        tableView.clearSelection();
        tableView.changeSelection(newPos, 0, false, false);
        tableView.requestFocus();
      } else if (cmd.equals(DEL_ACTION))
      {
        int sel = tableView.getSelectedRow();
        if (sel >= 0)
        {
          Property pi = properties[sel];
          if (pi != null)
          {
            if (pi.canRemove && !pi.readOnly)
            {
              propToDelete.add(pi.key);
              Property[] tmp = new Property[properties.length - 1];
              System.arraycopy(properties, 0, tmp, 0, sel);
              System.arraycopy(properties, sel + 1, tmp, sel, properties.length
                  - sel - 1);
              properties = tmp;
              dataModel.setProperties(properties);
            } else if (!pi.canRemove)
            {
              // Reset to default value
              PropertyMetadata propMD = PropertyMetadata.findProperty(pi.key);
              if (propMD != null)
              {
                pi.value = propMD.getDefault();
                pi.isModified = true;
              }
            }
            tableView.clearSelection();
            dataModel.fireTableDataChanged();
          }
        }
      }
    }
  }
  // Overwrite cell renderer to draw disabled cell
  private final class PropConfTableCellRenderer extends
  DefaultTableCellRenderer
  {
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column)
    {
      Property[] properties = getProperties();
      Property pi = properties[row];
      if (!isSelected)
      {
        Color bkgndCol;
        if (pi != null && (!pi.isNew || column == 2)
            && (column == 2 || column == 0 || pi.readOnly))
        {
          bkgndCol = UIManager.getColor("Label.background");
        } else
        {
          bkgndCol = table.getBackground();
        }
        setBackground(bkgndCol);
      }
      setToolTipText(pi.desc);
      super.getTableCellRendererComponent(table, value, isSelected, hasFocus,
          row, column);
      return this;
    }
  }
  private final class PropConfTableSelectionListener implements
  ListSelectionListener
  {
    public void valueChanged(ListSelectionEvent e)
    {
      Property[] properties = getProperties();
      ListSelectionModel lsm = (ListSelectionModel) e.getSource();
      int row = lsm.getMinSelectionIndex();
      if (lsm.isSelectionEmpty() || row >= properties.length)
      {
        descLabel.setText("");
      } else
      {
        Property pi = properties[lsm.getMinSelectionIndex()];
        int buttonTextId = Res.CONFIG_PROP_PANEL_DEL;
        boolean enable = true;
        if (pi != null)
        {
          enable = !pi.readOnly;
          if (!pi.canRemove)
          {
            buttonTextId = Res.CONFIG_PROP_PANEL_RESET;
            // Reset to default value
            PropertyMetadata propMD = PropertyMetadata.findProperty(pi.key);
            enable = (propMD != null && !pi.value.equalsIgnoreCase(propMD
                .getDefault()));
          }
          descLabel.setText(pi.desc);
        }
        removePropButton.setText(JboTesterUtil.stripMnemonic(buttonTextId));
        int mnemonic = JboTesterUtil.getMnemonicKeyCode(buttonTextId);
        if (mnemonic != 0)
        {
          removePropButton.setMnemonic(mnemonic);
        }
        removePropButton.setEnabled(enable);
        if (!addPropButton.isEnabled())
        {
          addPropButton.setEnabled(true);
        }
      }
    }
  }
  private static final String ADD_ACTION   = "add";
  private static final String DEL_ACTION   = "del";
  private JButton             addPropButton;
  private PropertyTableModel  dataModel;
  private final JLabel        descLabel    = new JLabel();
  private ArrayList           propToDelete = new ArrayList();
  private JButton             removePropButton;
  private JTable              tableView;
  
  public ConfigPropertyPanel(Frame parent, Property[] properties)
  {
    this.setLayout(new BorderLayout());
    // Create a model of the data.
    dataModel = new PropertyTableModel(properties);
    // Create the table
    tableView = new JTable(dataModel);
    ToolTipManager.sharedInstance().registerComponent(tableView);
    tableView.setDefaultRenderer(String.class, new PropConfTableCellRenderer());
    tableView.setDefaultEditor(String.class,
        new PropertyTableCellEditor(parent));
    // Listen to the selection change to update the hint (descLabel)
    ListSelectionModel selectModel = tableView.getSelectionModel();
    selectModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    selectModel.addListSelectionListener(new PropConfTableSelectionListener());
    // PreferedSize need to be smaller than the outside frame to size everything
    // correctly. (200,100) should be small enought
    tableView.setPreferredScrollableViewportSize(new Dimension(200, 100));
    this.add(new JScrollPane(tableView), BorderLayout.CENTER);
    PropConfPanelButtonActionListener buttonAction = new PropConfPanelButtonActionListener();
    int maxWidth = 0;
    addPropButton = new JButton(JboTesterUtil
        .stripMnemonic(Res.CONFIG_PROP_PANEL_ADD));
    int mnemonic = JboTesterUtil.getMnemonicKeyCode(Res.CONFIG_PROP_PANEL_ADD);
    if (mnemonic != 0)
    {
      addPropButton.setMnemonic(mnemonic);
    }
    addPropButton.setActionCommand(ADD_ACTION);
    addPropButton.addActionListener(buttonAction);
    maxWidth = Math.max(maxWidth, addPropButton.getMinimumSize().width);
    removePropButton = new JButton(JboTesterUtil
        .stripMnemonic(Res.CONFIG_PROP_PANEL_DEL));
    mnemonic = JboTesterUtil.getMnemonicKeyCode(Res.CONFIG_PROP_PANEL_DEL);
    if (mnemonic != 0)
    {
      removePropButton.setMnemonic(mnemonic);
    }
    removePropButton.setActionCommand(DEL_ACTION);
    removePropButton.addActionListener(buttonAction);
    maxWidth = Math.max(maxWidth, removePropButton.getMinimumSize().width);
    // Temporary button to get the max size for NLS
    JButton resetPropButton = new JButton(JboTesterUtil
        .stripMnemonic(Res.CONFIG_PROP_PANEL_RESET));
    maxWidth = Math.max(maxWidth, resetPropButton.getMinimumSize().width);
    Dimension d = new Dimension(maxWidth, addPropButton.getMinimumSize().height);
    addPropButton.setPreferredSize(d);
    addPropButton.setMinimumSize(d);
    removePropButton.setPreferredSize(d);
    removePropButton.setMinimumSize(d);
    JLabel sortInfoLabel = new JLabel(Res.getString(Res.SORT_HELP_TEXT));
    JPanel mSouthPanel = new JPanel(new GridBagLayout());
    GridBagLayout gbl = (GridBagLayout) mSouthPanel.getLayout();
    GridBagConstraints gbc = new GridBagConstraints();
    mSouthPanel.setBorder(BorderFactory.createEmptyBorder(5, 8, 5, 0));
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.weightx = 1.0;
    gbc.insets = new Insets(0, 0, 0, 8);
    gbc.anchor = GridBagConstraints.WEST;
    gbl.setConstraints(descLabel, gbc);
    mSouthPanel.add(descLabel);
    gbc.gridx = 1;
    gbc.fill = GridBagConstraints.NONE;
    gbc.weightx = 0.0;
    gbc.anchor = GridBagConstraints.NORTHEAST;
    gbl.setConstraints(addPropButton, gbc);
    mSouthPanel.add(addPropButton);
    gbc.gridx = 2;
    gbc.fill = GridBagConstraints.NONE;
    gbc.weightx = 0.0;
    gbl.setConstraints(removePropButton, gbc);
    mSouthPanel.add(removePropButton);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.weightx = 1.0;
    gbc.insets = new Insets(0, 0, 0, 8);
    gbc.anchor = GridBagConstraints.WEST;
    gbl.setConstraints(sortInfoLabel, gbc);
    mSouthPanel.add(sortInfoLabel);
    this.add(mSouthPanel, BorderLayout.SOUTH);
    registerAcceleratorForSorting(this);
  }
  
  public boolean canExit()
  {
    if (tableView.isEditing())
    {
      if (!tableView.getCellEditor().stopCellEditing())
      {
        return false;
      }
    }
    return true;
  }
    
  private final ArrayList createArrayListFromArray(Property[] p)
  {
    ArrayList list = new ArrayList(10);
    if (p != null)
    {
      for (int i = 0; i < p.length; i++)
      {
        list.add(p[i]);
      }
    }
    return list;
  }
  
  public Property[] getProperties()
  {
    return dataModel.getProperties();
  }
  
  public void setProperties(Property[] properties)
  {
    dataModel.setProperties(properties);
  }
  
  public final void refresh()
  {
    dataModel.fireTableDataChanged();
  }
  
  private final void registerAcceleratorForSorting(JPanel p)
  {
    ActionListener sortAction = new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        if (tableView.isEditing())
          tableView.getCellEditor().stopCellEditing();
        sort();
        refresh();
      }
    };
    // short cut for sorting is F9 key
    KeyStroke sortKey = KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0);
    p.registerKeyboardAction(sortAction, sortKey,
        JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
  }
  
  public void removeDeletedParameters(Hashtable params)
  {
    if(params!=null)
    {
      for (int i = 0; i < propToDelete.size(); i++)
      {
        params.remove(propToDelete.get(i));
      }
    }
  }
  
  // sort the properties
  // based on key attribute
  public final void sort()
  {
    ArrayList list = createArrayListFromArray(dataModel.getProperties());
    Collections.sort(list);
    dataModel.setProperties((Property[]) list
        .toArray(new Property[list.size()]));
  }
}
