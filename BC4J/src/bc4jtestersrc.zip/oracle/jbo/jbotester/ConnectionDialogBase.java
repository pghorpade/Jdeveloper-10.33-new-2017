/*
 * @(#)ConnectionDialogBase.java
 * 
 * Copyright 2000-2002 by Oracle Corporation, 500 Oracle Parkway, Redwood
 * Shores, California, 94065, U.S.A. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Oracle
 * Corporation.
 */
package oracle.jbo.jbotester;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.ButtonModel;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.jbo.JboContext;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.PropertyMetadata;
import com.sun.java.util.collections.ArrayList;
import com.sun.java.util.collections.HashMap;

abstract public class ConnectionDialogBase extends GenericDialog implements
    ChangeListener
{
  public static final int        CONNECT             = 2;
  public static final int        IS_EJB_PACKAGE      = 4;
  public static final int        SHOW_NAME           = 1;
  public static final String[]   tabNames            = new String[]
                                                     { "AppModule", "Pooling",
      "Property"                                    };
  private static final int       APPMODULE_STR       = 1;
  private static final Hashtable defaultConParam     = new Hashtable(10);
  private static final int       IAS                 = 2;
  private static final int       JDBC_DS_PANEL       = 1;
  private static final int       JDBC_URL_PANEL      = 0;
  private static final String[]  jdbcPanelNames      =
                                                     { "jdbcUrlPanel",
      "jdbcDsPanel"                                 };
  private static final int       LOCAL               = 0;
  private static final HashMap   notInPropertyParam  = new HashMap(20);
  private static final int       PACKAGE_STR         = 0;
  private static final String[]  platforms           = new String[]
                                                     {
      JboContext.PLATFORM_LOCAL, JboContext.PLATFORM_VB,
      JboContext.PLATFORM_EJB_IAS, JboContext.PLATFORM_WLS };
  private static final int       VB                  = 1;
  private static final int       WL                  = 3;
  static
  {
    defaultConParam.put(Configuration.BC4J_CONFIG_NAME, "Configuration1");
    defaultConParam.put(PropertyMetadata.DEPLOY_PLATFORM.getName(),
        PropertyMetadata.DEPLOY_PLATFORM.getDefault());
    defaultConParam.put(Configuration.APPLICATION_NAME_PROPERTY,
        "package1.Package1Module");
    // Parameters that shouldn't be displayed in the Properties tab
    notInPropertyParam.put(Configuration.BC4J_CONFIG_NAME,
        Configuration.BC4J_CONFIG_NAME);
    notInPropertyParam.put(Configuration.APPLICATION_NAME_PROPERTY,
        Configuration.APPLICATION_NAME_PROPERTY);
    notInPropertyParam.put(Configuration.APPLICATION_TYPE_PROPERTY,
        Configuration.APPLICATION_TYPE_PROPERTY);
    notInPropertyParam.put(Configuration.JDBC_CONNECTION_NAME,
        Configuration.JDBC_CONNECTION_NAME);
    notInPropertyParam.put(Configuration.JDBC_DS_NAME,
        Configuration.JDBC_DS_NAME);
    notInPropertyParam.put(PropertyMetadata.DEPLOY_PLATFORM.getName(),
        PropertyMetadata.DEPLOY_PLATFORM.getName());
    notInPropertyParam.put(PropertyMetadata.HOST_NAME.getName(),
        PropertyMetadata.HOST_NAME.getName());
    notInPropertyParam.put(PropertyMetadata.APPLICATION_PATH.getName(),
        PropertyMetadata.APPLICATION_PATH.getName());
    notInPropertyParam.put(PropertyMetadata.CONNECTION_MODE.getName(),
        PropertyMetadata.CONNECTION_MODE.getName());
    notInPropertyParam.put(PropertyMetadata.CONNECTION_PORT.getName(),
        PropertyMetadata.CONNECTION_PORT.getName());
    notInPropertyParam.put(JboTesterUtil.EJB_CLIENT_JARS,
        JboTesterUtil.EJB_CLIENT_JARS);
    notInPropertyParam.put(PropertyMetadata.DEPLOY_PLATFORM.getName(),
        PropertyMetadata.DEPLOY_PLATFORM.getName());
    notInPropertyParam.put(Configuration.APPSERVER_CONNECTION_NAME,
        Configuration.APPSERVER_CONNECTION_NAME);
    notInPropertyParam
        .put(Configuration.IS_INTERNAL, Configuration.IS_INTERNAL);
    notInPropertyParam.put(Configuration.CONFIGURATION_NAME,
        Configuration.CONFIGURATION_NAME);
    notInPropertyParam.put(
        PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getName(),
        PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getName(),
        PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD
        .getName(), PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getName());
    notInPropertyParam.put(
        PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getName(),
        PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getName());
    notInPropertyParam.put(
        PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getName(),
        PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE,
        PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL
        .getName(), PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL
        .getName());
    notInPropertyParam.put(PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getName(),
        PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getName(),
        PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE
        .getName(), PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE
        .getName(), PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE,
        PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getName());
    notInPropertyParam.put(
        PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getName(),
        PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_DO_FAILOVER.getName(),
        PropertyMetadata.ENV_DO_FAILOVER.getName());
    notInPropertyParam.put(
        PropertyMetadata.ENV_DO_CONNECTION_POOLING.getName(),
        PropertyMetadata.ENV_DO_CONNECTION_POOLING.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS
        .getName(), PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS
        .getName());
    notInPropertyParam.put(
        PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getName(),
        PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getName());
    notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getName(),
        PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getName());
    // notInPropertyParam.put(PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getName(),
    // PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getName());
  }
  private JPanel                 appConTypePanel;                                                      // top
                                                                                                       // panel
  private final JComboBox        appTypeCombo        = new JComboBox(
                                                         new String[]
                                                         {
      Res.getString(Res.PACKAGE_STR), Res.getString(Res.APPMODULE_STR) });
  private final JComboBox        bc4jConNameCombo    = new JComboBox();
  private final JTextField       bc4jConNameField    = new JTextField();
  private CardLayout             cardLayout;
  private final Hashtable        cmdParams;
  private final Configuration    configMgr;
  private final TitledBorder     connBorder          = BorderFactory
                                                         .createTitledBorder("");
  private final boolean          connectWhenDone;
  private final JCheckBox        connRequiredCheck   = new JCheckBox(
                                                         Res
                                                             .getString(Res.JDBC_CONNECTION_REQUIRED));
  private Hashtable              currentParams;
  private int                    currentTabIndex;
  private final JComboBox        dbConnTypeCombo     = new JComboBox(
                                                         new String[]
                                                         {
      Res.getString(Res.JDBC_URL_CONNECTION_TYPE),
      Res.getString(Res.JDBC_DS_CONNECTION_TYPE)        });
  private JTextField             dsNameField         = new JTextField();
  private IASPanel               iasPanel;
  private final boolean          isEJBPackage;
  private JPanel                 jdbcConnPanel       = new JPanel();
  private final ConfigMode       mode;
  private PoolParameterPanel     mPoolParameterPanel = null;
  private int                    mPropertiesTabIndex = 1;
  private String                 oldConName          = "";
  private final JComboBox        orbTypeCombo        = new JComboBox();
  private final Hashtable        origCmdParams;                                                        // do
                                                                                                       // not
                                                                                                       // mutate.
  private final JTextField       packageField        = new JTextField();
  private ConfigPropertyPanel    propConfPanel;
  private final boolean          showNamedConnections;
  private String[]               uniqueNames         = null;
  private WLPanel                wlPanel;
  protected final JComboBox      connTypeCombo       = new JComboBox();
  protected JPanel               mainConnPanel       = new JPanel();                                   // middle
                                                                                                       // panel
  protected final JTextArea      urlField            = new JTextArea();
  protected final JLabel         userNameField       = new JLabel();

  public ConnectionDialogBase(Frame frame, Hashtable cmdParams,
      Configuration configMgr, ConfigMode mode, ActionListener help, int flags)
  {
    super(frame, mode != ConfigMode.RUN ? Res
        .getString(Res.CONFIG_DIALOG_TITLE) : Res.format(Res.TESTER_TITLE, Res
        .getString(Res.CONNECT_DIALOG_TITLE)), new JPanel(new GridBagLayout()),
        OK_CANCEL_HELP_OPTION, mode != ConfigMode.RUN ? null : Res
            .getString(Res.CONNECT_DIALOG_DEFBUTTON));
    if (cmdParams.get(Configuration.BC4J_CONFIG_NAMES) != null)
    {
      this.uniqueNames = (String[]) cmdParams
          .get(Configuration.BC4J_CONFIG_NAMES);
      cmdParams.remove(Configuration.BC4J_CONFIG_NAMES);
    }
    this.cmdParams = cmdParams;
    this.origCmdParams = (Hashtable) cmdParams.clone();
    this.configMgr = configMgr;
    this.oldConName = (String) cmdParams.get(Configuration.BC4J_CONFIG_NAME);
    connectWhenDone = ((flags & CONNECT) > 0);
    showNamedConnections = ((flags & SHOW_NAME) > 0);
    isEJBPackage = ((flags & IS_EJB_PACKAGE) > 0);
    this.mode = mode;
    if (isEditing())
    {
      mPropertiesTabIndex = 2;
    }
    setHelpActionListener(help);
    propConfPanel = new ConfigPropertyPanel(parent, new Property[0]);
    if (cmdParams != null)
    {
      ArrayList props = new ArrayList();
      // Initialize the properties table with all properties that
      // have been defined as cmdParams and are not specified in the
      // notInPropertyParam map.
      for (Enumeration e = cmdParams.keys(); e.hasMoreElements();)
      {
        String key = (String) e.nextElement();
        if (notInPropertyParam.get(key) == null)
        {
          PropertyMetadata propMD = PropertyMetadata.findProperty(key);
          Property pi = new Property(key, (String) cmdParams.get(key),
              (propMD != null) ? propMD.getDescription() : key, false, false,
              true, (propMD == null));
          props.add(pi);
        }
      }
      setProperties((Property[]) props.toArray(new Property[props.size()]));
    }
    try
    {
      jbInit();
      initConfigName();
      initAppInfo(cmdParams);
      if (!this.isEditing() && this.bc4jConNameCombo.getItemCount() > 1)
      {
        this.bc4jConNameCombo.setSelectedIndex(1);
      }
    } catch (Exception ex)
    {
      ErrorHandler.displayError(parent, ex);
    }
  }

  public final void actionPerformed(ActionEvent event)
  {
    String cmd = event.getActionCommand();
    if (cmd.equals(OK_ACTION))
    {
      exitCmd = cmd;
      connectAction();
    } else
    {
      super.actionPerformed(event);
    }
  }

  // Overwrite doHelp implementation from GenericDialog
  public final void doHelp()
  {
    if (getHelpActionListener() != null)
    {
      String tabName = null;
      if (currentTabIndex == 0 || isEditing())
      {
        tabName = tabNames[currentTabIndex];
      } else
      {
        tabName = tabNames[2];
      }
      getHelpActionListener().actionPerformed(
          new ActionEvent(this, ActionEvent.ACTION_PERFORMED, tabName));
    } else
    {
      super.doHelp();
    }
  }

  public final Hashtable getParams()
  {
    return cmdParams;
  }

  public void setDeployPlatform(String mode)
  {
    for (int i = 0; i < platforms.length; i++)
    {
      if (platforms[i].equals(mode))
      {
        orbTypeCombo.setSelectedIndex(i);
        break;
      }
    }
  }

  // ChangeListener implementation
  public final void stateChanged(ChangeEvent e)
  {
    if (e.getSource() instanceof JTabbedPane)
    {
      JTabbedPane tp = (JTabbedPane) e.getSource();
      currentTabIndex = tp.getSelectedIndex();
      if (currentTabIndex == mPropertiesTabIndex)
      {
        populatePropertiesTable();
      }
      if (mPoolParameterPanel != null)
      {
        mPoolParameterPanel.setConnCapacitiesEditable(!useDataSource());
      }
    }
  }

  private final void addToPanel(JPanel panel, JComponent combo, JPanel subPanel)
  {
    GridBagLayout gbl = new GridBagLayout();
    panel.setLayout(gbl);
    GridBagConstraints gbc = new GridBagConstraints();
    panel.setAlignmentY(Component.TOP_ALIGNMENT);
    gbc.fill = GridBagConstraints.NONE;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.insets = new Insets(0, 3, 0, 0);
    gbc.anchor = GridBagConstraints.NORTHWEST;
    gbl.setConstraints(combo, gbc);
    panel.add(combo);
    gbc.gridx = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.weighty = 0.0;
    gbc.weightx = 1.0;
    gbl.setConstraints(subPanel, gbc);
    panel.add(subPanel);
  }

  private final void bc4jConNameCombo_actionPerformed(ActionEvent e)
  {
    try
    {
      String conName = (String) bc4jConNameCombo.getSelectedItem();
      Hashtable conParam = defaultConParam;
      if (conName != null && conName.length() > 0)
      {
        if (conName.equals(Res.getString(Res.bc4jConDefaultName)))
        {
          conParam = cmdParams;
        } else
        {
          if (configMgr != null)
          {
            conParam = configMgr.getConfiguration(conName);
            // Run time configuration add these properties we don't want.
            conParam.remove(PropertyMetadata.INITIAL_CONTEXT_FACTORY.getName());
            conParam.remove(Configuration.DB_CONNECTION_PROPERTY);
            conParam.remove(Configuration.DB_USERNAME_PROPERTY);
            conParam.remove(Configuration.DB_PASSWORD_PROPERTY);
            // Remove any new or modified properties.
            this.setProperties(new Property[0]);
          }
        }
      }
      initAppInfo(conParam);
      populatePropertiesTable();
    } catch (Exception ex)
    {
      Diagnostic.printStackTrace(ex);
    }
  }

  private final JPanel buildAppTypePanel()
  {
    GridBagLayout gblApp = new GridBagLayout();
    JPanel panel = new JPanel(gblApp);
    GridBagConstraints gbcApp = new GridBagConstraints();
    JLabel packageLabel = JboTesterUtil.createLabel(Res.packageLabel,
        packageField);
    panel.setAlignmentY(Component.TOP_ALIGNMENT);
    //debug panel.setBorder(BorderFactory.createLineBorder(Color.black));
    gbcApp.fill = GridBagConstraints.NONE;
    gbcApp.gridx = 0;
    gbcApp.gridy = 0;
    gbcApp.insets = new Insets(0, 10, 10, 0);
    gbcApp.anchor = GridBagConstraints.NORTHWEST;
    gblApp.setConstraints(packageLabel, gbcApp);
    panel.add(packageLabel);
    gbcApp.gridx = 1;
    gbcApp.fill = GridBagConstraints.HORIZONTAL;
    gbcApp.weighty = 0.0;
    gbcApp.weightx = 1.0;
    gblApp.setConstraints(packageField, gbcApp);
    panel.add(packageField);
    return panel;
  }

  private final JPanel buildConnPanel()
  {
    GridBagLayout gblConn = new GridBagLayout();
    JPanel connPanel = new JPanel(gblConn);
    GridBagConstraints gbcConn = new GridBagConstraints();
    JLabel userNameLabel = new JLabel(JboTesterUtil
        .stripMnemonic(Res.CONNECT_DIALOG_USERNAME_LABEL));
    JLabel urlLabel = new JLabel(Res.getString(Res.CONNECT_DIALOG_URL_LABEL));
    JLabel connNameLabel = JboTesterUtil.createLabel(
        Res.CONNECT_DIALOG_CON_NAME_LABEL, connTypeCombo);
    connPanel.setAlignmentY(Component.TOP_ALIGNMENT);
    //debug connPanel.setBorder(BorderFactory.createLineBorder(Color.black));
    urlField.setEditable(false);
    urlField.setRows(2);
    urlField.setEnabled(false);
    urlField.setLineWrap(true);
    urlField.setFont(urlLabel.getFont());
    urlField.setMinimumSize(new Dimension(250, 50));
    urlField.setBackground(urlLabel.getBackground());
    urlField.setForeground(urlLabel.getForeground());
    urlField.setToolTipText(urlField.getText());
    gbcConn.fill = GridBagConstraints.HORIZONTAL;
    gbcConn.gridx = 0;
    gbcConn.gridy = 0;
    gbcConn.insets = new Insets(0, 10, 10, 0);
    gbcConn.anchor = GridBagConstraints.NORTH;
    connPanel.add(connNameLabel, gbcConn);
    gbcConn.gridx = 1;
    gbcConn.anchor = GridBagConstraints.NORTHWEST;
    gbcConn.gridwidth = GridBagConstraints.REMAINDER;
    connPanel.add(connTypeCombo, gbcConn);
    gbcConn.gridx = 0;
    gbcConn.gridy = 1;
    gbcConn.anchor = GridBagConstraints.NORTH;
    gblConn.setConstraints(userNameLabel, gbcConn);
    connPanel.add(userNameLabel);
    gbcConn.anchor = GridBagConstraints.NORTHWEST;
    gbcConn.gridx = 1;
    gbcConn.gridwidth = GridBagConstraints.REMAINDER;
    gbcConn.weightx = 1.0;
    gblConn.setConstraints(userNameField, gbcConn);
    connPanel.add(userNameField);
    gbcConn.anchor = GridBagConstraints.NORTHWEST;
    gbcConn.gridx = 0;
    gbcConn.gridy = 2;
    gbcConn.gridwidth = 1;
    gbcConn.weightx = 0.0;
    gblConn.setConstraints(urlLabel, gbcConn);
    connPanel.add(urlLabel);
    gbcConn.anchor = GridBagConstraints.NORTHEAST;
    gbcConn.gridx = 1;
    gbcConn.weightx = 1.0;
    gbcConn.gridwidth = GridBagConstraints.REMAINDER;
    gblConn.setConstraints(urlField, gbcConn);
    connPanel.add(urlField);
    return connPanel;
  }

  private final JPanel buildDataSourcePanel()
  {
    GridBagLayout gblConn = new GridBagLayout();
    JPanel connPanel = new JPanel(gblConn);
    GridBagConstraints gbcConn = new GridBagConstraints();
    JLabel dsNameLabel = JboTesterUtil.createLabel(
        Res.CONNECT_DIALOG_DSNAME_LABEL, dsNameField);
    connPanel.setAlignmentY(Component.TOP_ALIGNMENT);
    gbcConn.fill = GridBagConstraints.HORIZONTAL;
    gbcConn.gridx = 0;
    gbcConn.gridy = 0;
    gbcConn.gridwidth = 1;
    gbcConn.insets = new Insets(0, 10, 10, 0);
    gbcConn.anchor = GridBagConstraints.NORTHWEST;
    connPanel.add(dsNameLabel, gbcConn);
    gbcConn.anchor = GridBagConstraints.NORTHEAST;
    gbcConn.gridx = 1;
    gbcConn.gridwidth = GridBagConstraints.REMAINDER;
    gbcConn.weightx = 1.0;
    connPanel.add(dsNameField, gbcConn);
    JboTesterUtil.addSpacerPanel(connPanel, 0, 1);
    return connPanel;
  }

  private final void buildJdbcConnectionPanel()
  {
    JPanel jdbcUrlPanel = new JPanel();
    jdbcUrlPanel = buildConnPanel();
    JPanel jdbcDsPanel = buildDataSourcePanel();
    jdbcConnPanel.setLayout(new CardLayout());
    jdbcConnPanel.add(jdbcUrlPanel, jdbcPanelNames[JDBC_URL_PANEL]);
    jdbcConnPanel.add(jdbcDsPanel, jdbcPanelNames[JDBC_DS_PANEL]);
    dbConnTypeCombo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        dbConnType_actionPerformed(e);
      }
    });
    GridBagLayout gbl = new GridBagLayout();
    mainConnPanel.setLayout(gbl);
    GridBagConstraints gbc = new GridBagConstraints();
    mainConnPanel.setAlignmentY(Component.TOP_ALIGNMENT);
    gbc.fill = GridBagConstraints.NONE;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.insets = new Insets(0, 3, 10, 0);
    gbc.anchor = GridBagConstraints.NORTHWEST;
    if (isEJBPackage && isEditing())
    {
      gbl.setConstraints(connRequiredCheck, gbc);
      mainConnPanel.add(connRequiredCheck);
      gbc.gridy++;
    }
    gbc.fill = GridBagConstraints.NONE;
    gbc.gridx = 0;
    gbc.gridwidth = 1;
    gbc.insets = new Insets(0, 3, 0, 0);
    gbc.anchor = GridBagConstraints.NORTHWEST;
    gbl.setConstraints(dbConnTypeCombo, gbc);
    mainConnPanel.add(dbConnTypeCombo);
    gbc.gridx = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.weighty = 0.0;
    gbc.weightx = 1.0;
    gbl.setConstraints(jdbcConnPanel, gbc);
    mainConnPanel.add(jdbcConnPanel);
  }

  private final JPanel buildNamePanel()
  {
    GridBagLayout gblApp = new GridBagLayout();
    JPanel panel = new JPanel(gblApp);
    panel.setMinimumSize(new Dimension(400, 40));
    GridBagConstraints gbcApp = new GridBagConstraints();
    JComponent comp;
    if (isEditing())
    {
      comp = bc4jConNameField;
      JboTesterUtil.removeKeyBindingCompatibility(bc4jConNameField);
      bc4jConNameCombo.setVisible(false);
    } else
    {
      comp = bc4jConNameCombo;
      bc4jConNameField.setVisible(false);
    }
    JLabel label = JboTesterUtil.createLabel(Res.bc4jConNameLabel, comp);
    panel.setAlignmentY(Component.TOP_ALIGNMENT);
    //debug panel.setBorder(BorderFactory.createLineBorder(Color.black));
    gbcApp.fill = GridBagConstraints.NONE;
    gbcApp.gridx = 0;
    gbcApp.gridy = 0;
    gbcApp.insets = new Insets(0, 10, 10, 0);
    gbcApp.anchor = GridBagConstraints.NORTHWEST;
    gblApp.setConstraints(label, gbcApp);
    panel.add(label);
    gbcApp.gridx = 1;
    gbcApp.fill = GridBagConstraints.HORIZONTAL;
    gbcApp.weighty = 0.0;
    gbcApp.weightx = 1.0;
    gblApp.setConstraints(comp, gbcApp);
    panel.add(comp);
    return panel;
  }

  private final void connectAction()
  {
    if (!propConfPanel.canExit())
    {
      return;
    }
    cmdParams.clear();
    String conName = getConfigName();
    // Populate the command parameters with persisted configuration
    // parameters, when a persistent configuration name has been specified.
    // A persistent configuration name may not have been specified if the
    // user had selected default from project.
    boolean isVirtualConfig = Res.getString(Res.bc4jConDefaultName).equals(
        conName);
    // If the configuration name has been specified and it is not a virtual
    // configuration
    if (conName != null && conName.length() > 0 && !isVirtualConfig
        && configMgr != null)
    {
      if (!mode.equals(ConfigMode.NEW))
      {
        if (isEditing())
        {
          if (conName.equals(oldConName))
            configMgr
                .getConfiguration(conName, cmdParams, false /* resolveConn */);
          else
          {
            configMgr
                .getConfiguration(oldConName, cmdParams, false /* resolveConn */);
            cmdParams.put(Configuration.BC4J_CONFIG_NAME, conName);
          }
        } else
        {
          configMgr
              .getConfiguration(conName, cmdParams, false /* resolveConn */);
        }
      }
    } else if (isVirtualConfig)
    {
      // Add back the embedded configuration parameter. If the user has not
      // selected a persistent configuration (default from project) then it
      // may have been removed from the cmdParams member. It is necessary
      // to add the parameter here
      String isEmbeddedConfig = null;
      if ((cmdParams.get(Configuration.IS_INTERNAL) == null)
          && (null != (isEmbeddedConfig = (String) origCmdParams
              .get(Configuration.IS_INTERNAL))))
      {
        cmdParams.put(Configuration.IS_INTERNAL, isEmbeddedConfig);
      }
    }
    // Now, populate the command parameters with the values of the parameters
    // specified in the panels.
    if (!getParamFromPanel(cmdParams, true))
    {
      return;
    }
    // Now, populate the command parameters with the values of the parameters
    // specified in the properties table.
    Property[] properties = this.getProperties();
    for (int i = 0; i < properties.length; i++)
    {
      Property pi = properties[i];
      if (pi != null)
      {
        if (pi.isNew || pi.isModified)
        {
          if (pi.key != null && pi.key.length() > 0)
          {
            if (pi.value != null)
            {
              cmdParams.put(pi.key, pi.value);
              // Remove the property if the value is the same as the
              // default
              PropertyMetadata propMD = PropertyMetadata.findProperty(pi.key);
              // zw: aug2005: Bug 4186279 : the lenth() check should
              // be an '||' instead. Otherwise we never remove the
              // value when it reverts to the default.
               
              if (propMD != null
                  && (pi.value.equalsIgnoreCase(propMD.getDefault())
                  ||  pi.value.length() == 0)
                  )
              {
                cmdParams.remove(pi.key);
              }
            } else
            {
              cmdParams.remove(pi.key);
            }
          }
        }
      }
    }
    propConfPanel.removeDeletedParameters(cmdParams);
    if (isEditing())
    {
      // This property is only used in the context of the tester
      // for launching the client. We don't this saved in the .xcfg file
      cmdParams.remove(JboTesterUtil.EJB_CLIENT_JARS);
    } else
    {
      cmdParams.put(PropertyMetadata.INITIAL_CONTEXT_FACTORY.getName(),
          PropertyMetadata.INITIAL_CONTEXT_FACTORY.getDefault());
      configMgr.initializeFromConnectionName(cmdParams);
    }
    if (connectWhenDone)
    {
      boolean bRet = false;
      setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      try
      {
        bRet = ConnectionInfo.useApplicationModule(this, configMgr, conName);
      } catch (Throwable t)
      {
        ErrorHandler.displayError(parent, t);
      }
      // Reset cursor no matter what
      setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
      if (!bRet)
      {
        return;
      }
    }
    close();
  }

  private final void connRequired_actionPerformed(ActionEvent e)
  {
    ButtonModel model = connRequiredCheck.getModel();
    setJdbcConnectionPanelEnabled(model.isSelected());
  }

  private final JPanel createAMConfPanel()
  {
    JPanel AMConfPanel = new JPanel(new GridBagLayout());
    GridBagLayout gbl = (GridBagLayout) AMConfPanel.getLayout();
    GridBagConstraints gbc = new GridBagConstraints();
    Border compEmp = BorderFactory.createEmptyBorder(5, 5, 0, 5);
    wlPanel = new WLPanel(parent);
    iasPanel = new IASPanel(parent);
    cardLayout = new CardLayout();
    appConTypePanel = new JPanel(cardLayout);
    appConTypePanel.add(new PlatformPanel(), platforms[LOCAL]);
    appConTypePanel.add(new VBPanel(parent), platforms[VB]);
    appConTypePanel.add(iasPanel, platforms[IAS]);
    appConTypePanel.add(wlPanel, platforms[WL]);
    String panelName = Res.getString(Res.CONNECT_DIALOG_SERVER_TYPE);
    orbTypeCombo.setEnabled(isNewConfig());
    orbTypeCombo.setModel(createPlatformComboModel());
    orbTypeCombo.getAccessibleContext().setAccessibleName(panelName);
    orbTypeCombo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        orbTypeCombo_actionPerformed(e);
      }
    });
    // Combo sizing here
    int maxComboWidth = Math.max(appTypeCombo.getMinimumSize().width,
        orbTypeCombo.getMinimumSize().width);
    maxComboWidth = Math.max(maxComboWidth,
        dbConnTypeCombo.getMinimumSize().width);
    Dimension comboDim = new Dimension(maxComboWidth, appTypeCombo
        .getMinimumSize().height);
    appTypeCombo.setPreferredSize(comboDim);
    orbTypeCombo.setPreferredSize(comboDim);
    dbConnTypeCombo.setPreferredSize(comboDim);
    // Server type panel
    JPanel serverTypePanel = new JPanel();
    serverTypePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory
        .createTitledBorder(panelName), compEmp));
    addToPanel(serverTypePanel, orbTypeCombo, appConTypePanel);
    gbc.gridx = 0;
    //      gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.NORTH;
    //      gbc.gridheight = GridBagConstraints.NONE;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.insets = new Insets(5, 5, 0, 5);
    gbl.setConstraints(serverTypePanel, gbc);
    AMConfPanel.add(serverTypePanel);
    // Connection type panel
    mainConnPanel.setBorder(BorderFactory.createCompoundBorder(connBorder,
        compEmp));
    connTypeCombo.setEditable(false);
    connTypeCombo.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        connTypeCombo_actionPerformed(e);
      }
    });
    panelName = Res.getString(Res.CONNECT_DIALOG_CON_TYPE);
    connBorder.setTitle(panelName);
    dbConnTypeCombo.getAccessibleContext().setAccessibleName(panelName);
    initdbConnTypeCombo(LOCAL);
    buildJdbcConnectionPanel();
    gbl.setConstraints(mainConnPanel, gbc);
    AMConfPanel.add(mainConnPanel);
    // Application type panel
    //rvgrins start initial changes to remove package testing
    JPanel appTypePanel = new JPanel();
    //2460907 panelName = Res.getString(Res.ApplicationTypeStr);
    panelName = Res.getString(Res.APPMODULE_STR);//2460907
    appTypePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory
        .createTitledBorder(panelName), compEmp));
    appTypeCombo.getAccessibleContext().setAccessibleName(panelName);
    if (isEditing())
    {
      addToPanel(appTypePanel, new JLabel(Res.getString(Res.APPMODULE_STR)),
          buildAppTypePanel());
    } else
    {
      appTypeCombo.setEditable(false);
      addToPanel(appTypePanel, appTypeCombo, buildAppTypePanel());
    }
    JboTesterUtil.removeKeyBindingCompatibility(packageField);
    if (isEditing())
    {
      packageField.setEnabled(false);
      //appTypeCombo.setVisible(false);
      //appTypeCombo.setEnabled(false);
    }
    /*
     * rvgrins 2460907 20050608 removing test package functionality altogether
     * the next two lines used to be conditional in the if(isEditing()) check
     * above Wait till the release after 10.1.3 to remove the underlying stuff,
     * as it is now still easy to revert
     */
    appTypeCombo.setVisible(false);
    appTypeCombo.setEnabled(false);
    //rvgrins end initial changes to remove package testing
    gbc.insets = new Insets(5, 5, 5, 5);
    gbl.setConstraints(appTypePanel, gbc);
    AMConfPanel.add(appTypePanel);
    return AMConfPanel;
  }

  private ComboBoxModel createPlatformComboModel()
  {
    if (mode != ConfigMode.NEW)
    {
      return new DefaultComboBoxModel(new String[]
      { Res.getString(Res.CONNECT_INFO_LOCAL),
          Res.getString(Res.CONNECT_INFO_VB),
          Res.getString(Res.CONNECT_INFO_IAS),
          Res.getString(Res.CONNECT_INFO_WL) });
    } else
    {
      return new DefaultComboBoxModel(new String[]
      { Res.getString(Res.CONNECT_INFO_LOCAL) });
    }
  }

  private final void dbConnType_actionPerformed(ActionEvent e)
  {
    int panelType = JDBC_URL_PANEL;
    int panel = dbConnTypeCombo.getSelectedIndex();
    if (panel != -1)
    {
      panelType = panel;
    }
    showJdbcPanel(panelType);
  }

  private String getConfigName()
  {
    String configName = null;
    if (!isEditing())
    {
      configName = (String) bc4jConNameCombo.getSelectedItem();
    } else
    {
      configName = bc4jConNameField.getText();
    }
    return configName;
  }

  private final boolean getParamFromPanel(Hashtable params, boolean showError)
  {
    // This method is invoked by both connectAction and
    // populatePropertiesTable. In the former case it is used to populate
    // the cmdParams member with the properties that have been defined in
    // the panels (connect and scalability). When invoked by
    // populatePropertiesTable it is used to populate the currentParams
    // member with the properties that have been defined in the panels.
    String packageName = packageField.getText();
    if ((packageName == null) || (packageName.length() <= 0))
    {
      if (showError)
      {
        ErrorHandler.displayError(parent, Res
            .getString(Res.CONNECT_DIALOG_PACKAGE_ERROR));
        return false;
      }
    } else
    {
      params.put(Configuration.APPLICATION_NAME_PROPERTY, packageName);
    }
    Object appType;
    if (isEditing())
    {
      appType = Configuration.APPLICATION_TYPE_VALUE_APPMODULE;
      String configName = bc4jConNameField.getText();
      boolean bConfigNameValid = true;
      String errorMsg = null;
      if (isConfigNameHasInvalidChars(configName))
      {
        bConfigNameValid = false;
        errorMsg = Res.getString(Res.ERROR_CONFIG_NAME_WITH_DOTS);
      }
      if (isConfigNameEmpty(configName))
      {
        bConfigNameValid = false;
        errorMsg = Res.getString(Res.ERROR_CONFIG_NAME_EMPTY);
      }
      if (!isConfigNameUnique(configName))
      {
        bConfigNameValid = false;
        errorMsg = Res.getString(Res.ERROR_CONFIG_NAME_DUPLICATE);
      }
      if (bConfigNameValid)
      {
        params.put(Configuration.BC4J_CONFIG_NAME, configName);
      } else
      {
        if (showError)
        {
          ErrorHandler.displayError(parent, errorMsg);
          bc4jConNameField.selectAll();
          bc4jConNameField.requestFocus();
          return false;
        }
      }
    } // isEditing()
    else
    {
      appType = (appTypeCombo.getSelectedIndex() == PACKAGE_STR) ? Configuration.APPLICATION_TYPE_VALUE_PACKAGE
          : Configuration.APPLICATION_TYPE_VALUE_APPMODULE;
      if (showNamedConnections)
      {
        Object configName = bc4jConNameCombo.getSelectedItem();
        if (configName != null)
        {
          params.put(Configuration.BC4J_CONFIG_NAME, configName);
        }
      }
    }
    // For simplicity reason, we add the apptype property only if needed. The
    // default is appModule is the value of this property is null
    if (appType == Configuration.APPLICATION_TYPE_VALUE_PACKAGE)
    {
      params.put(Configuration.APPLICATION_TYPE_PROPERTY, appType);
    } else
    {
      params.remove(Configuration.APPLICATION_TYPE_PROPERTY);
    }
    int orbType = orbTypeCombo.getSelectedIndex();
    params.put(PropertyMetadata.DEPLOY_PLATFORM.getName(), platforms[orbType]);
    if (!validateAndUpdateConnectionParams(params, showError))
    {
      return false;
    }
    if (mPoolParameterPanel != null)
    {
      if (!mPoolParameterPanel.validateAndUpdateScalabilityParams(params,
          showError))
      {
        return false;
      } else
      {
        Property[] properties = this.getProperties();
        HashMap props = new HashMap(properties.length);
        for (int i = 0; i < properties.length; i++)
        {
          Property pi = properties[i];
          props.put(pi.key, pi);
        }
        // This logic updates the property value if it was passed in to the
        // dialog
        // a user property. If it was not passed into the dialog as a user
        // property
        // then it adds the property to the command parameter list if it is
        // not default and removes the property from the command parameter list
        // if it is default. Used by all scalability parameters (non-mandatory).
        for (int i = 0; i < PoolParameterPanel.POOL_PARAMETER_METADATA.length; i++)
        {
          Object paramName = PoolParameterPanel.POOL_PARAMETER_METADATA[i]
              .getName();
          Property pi = (Property) props.get(paramName);
          String value = (String) cmdParams.get(paramName);
          if ((pi != null) && (pi.isModified) && !pi.value.equals(value))
          {
            // Already modified in props. Update the props value.
            pi.value = value;
          }
        }
      }
    }
    // Remove any platform panels properties. If the configuration represents
    // an embedded configuration then leave the host name and connection port
    // alone.
    if (!isEmbeddedConfig(getConfigName()))
    {
      params.remove(PropertyMetadata.HOST_NAME.getName());
      params.remove(PropertyMetadata.CONNECTION_PORT.getName());
    } else
    {
      // ensure that the HOST_NAME and CONNECTION_PORT are set. if
      // the parent is a session facade bean then a named application
      // connection will not exist and it is necessary to fault in the
      // HOST_NAME and the CONNECTION_PORT from the original command params.
      String hostName = null;
      if ((params.get(PropertyMetadata.HOST_NAME.getName()) == null)
          && (null != (hostName = (String) origCmdParams
              .get(PropertyMetadata.HOST_NAME.getName()))))
      {
        params.put(PropertyMetadata.HOST_NAME.getName(), hostName);
      }
      String connPort = null;
      if ((params.get(PropertyMetadata.CONNECTION_PORT.getName()) == null)
          && (null != (connPort = (String) origCmdParams
              .get(PropertyMetadata.CONNECTION_PORT.getName()))))
      {
        params.put(PropertyMetadata.CONNECTION_PORT.getName(), connPort);
      }
    }
    params.remove(PropertyMetadata.APPLICATION_PATH.getName());
    params.remove(ConnectionInfo.ORB_GATEKEEPER_IOR);
    params.remove(PropertyMetadata.CONNECTION_MODE.getName());
    params.remove(JboTesterUtil.EJB_CLIENT_JARS);
    // Get the value from the platform panels
    PlatformPanel panel = (PlatformPanel) appConTypePanel.getComponent(orbType);
    if (!panel.getParams(params, showError))
    {
      return false;
    }
    return true;
  }

  private Property[] getProperties()
  {
    return this.propConfPanel.getProperties();
  }

  private final void initAppInfo(Hashtable params)
  {
    if (params == null)
    {
      params = defaultConParam;
    } else
    {
      // Use invidual default value if property is missing
      if (params.get(PropertyMetadata.DEPLOY_PLATFORM.getName()) == null)
      {
        params.put(PropertyMetadata.DEPLOY_PLATFORM.getName(), defaultConParam
            .get(PropertyMetadata.DEPLOY_PLATFORM.getName()));
      }
      if (params.get(Configuration.APPLICATION_NAME_PROPERTY) == null)
      {
        params.put(Configuration.APPLICATION_NAME_PROPERTY, defaultConParam
            .get(Configuration.APPLICATION_NAME_PROPERTY));
      }
    }
    currentParams = (Hashtable) params.clone();
    if (isEditing())
    {
      bc4jConNameField.setText((String) params
          .get(Configuration.BC4J_CONFIG_NAME));
      if (isEmbeddedConfig(getConfigName()))
      {
        bc4jConNameField.setEditable(false);
      } else
      {
        bc4jConNameField.setEditable(true);
      }
    }
    String platform = (String) params.get(PropertyMetadata.DEPLOY_PLATFORM
        .getName());
    setDeployPlatform(platform);
    initJdbcPanel(platform, params);
    if (mPoolParameterPanel != null)
    {
      mPoolParameterPanel.setPoolParameters(params);
    }
    //if (platform.equals(JboContext.PLATFORM_EJB_IAS))
    //{
    //   dbConnTypeCombo.setSelectedIndex(JDBC_DS_PANEL);
    //}
    if (!isEditing())
    {
      String str = (String) params.get(Configuration.APPLICATION_TYPE_PROPERTY);
      if (str == null
          || str.equals(Configuration.APPLICATION_TYPE_VALUE_APPMODULE))
      {
        appTypeCombo.setSelectedIndex(APPMODULE_STR);
      }
    }
    String appName = (String) params
        .get(Configuration.APPLICATION_NAME_PROPERTY);
    packageField.setText(appName);
  }

  private final void initConfigName()
  {
    // Fill the name connection
    if (showNamedConnections)
    {
      if (!isEditing())
      {
        String[] nameConfigList = null;
        try
        {
          if (configMgr != null)
          {
            nameConfigList = configMgr.getConfigurationNameList((String)cmdParams.get(Configuration.APPLICATION_NAME_PROPERTY));
          }
        } catch (Exception e)
        {
        }
        if (nameConfigList == null)
        {
          nameConfigList = new String[0];
        }
        String[] completeList = new String[nameConfigList.length + 1];
        completeList[0] = Res.getString(Res.bc4jConDefaultName);
        System.arraycopy(nameConfigList, 0, completeList, 1,
            nameConfigList.length);
        bc4jConNameCombo.setModel(new DefaultComboBoxModel(completeList));
      }
    }
  }

  private final void initdbConnTypeCombo(int orbType)
  {
    updateConnectionCombo(orbType);
  }

  private final void initJdbcPanel(String platform, Hashtable params)
  {
    String connectionName = null;
    String dsConnectionName = null;
    int selection = JDBC_URL_PANEL;
    // Set connection string here
    if (platform.equals(JboContext.PLATFORM_VB)
        || platform.equals(JboContext.PLATFORM_LOCAL)
        || platform.equals(JboContext.PLATFORM_WLS)
        || platform.equals(JboContext.PLATFORM_EJB_IAS))
    {
      connectionName = (String) params.get(Configuration.JDBC_CONNECTION_NAME);
      dsConnectionName = (String) params.get(Configuration.JDBC_DS_NAME);
    }
    connRequiredCheck.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        connRequired_actionPerformed(e);
      }
    });
    if (dsConnectionName != null)
    {
      selection = JDBC_DS_PANEL;
      connRequiredCheck.getModel().setSelected(true);
      setJdbcConnectionPanelEnabled(true);
      dsNameField.setText(dsConnectionName);
    } else if (connectionName != null)
    {
      connTypeCombo.setSelectedItem(connectionName);
      connRequiredCheck.getModel().setSelected(true);
      setJdbcConnectionPanelEnabled(true);
    } else
    {
      connRequiredCheck.getModel().setSelected(!isEJBPackage);
      setJdbcConnectionPanelEnabled(!isEJBPackage);
    }
    dbConnTypeCombo.setSelectedIndex(selection);
  }

  private final boolean isConfigNameEmpty(String configName)
  {
    if (configName.length() == 0)
    {
      return true;
    }
    return false;
  }

  private final boolean isConfigNameHasInvalidChars(String name)
  {
    if (name.indexOf('.') != -1)
    {
      return true;
    }
    return false;
  }

  private final boolean isConfigNameUnique(String newConfigName)
  {
    if (this.uniqueNames != null && !newConfigName.equals(this.oldConName))
    {
      for (int i = 0; i < this.uniqueNames.length; i++)
      {
        if (this.uniqueNames[i].equalsIgnoreCase(newConfigName))
          return false;
      }
    }
    return true;
  }

  private final boolean isEditing()
  {
    return mode == ConfigMode.NEW || mode == ConfigMode.EDIT;
  }

  private final boolean isEmbeddedConfig(String configName)
  {
    boolean isEmbedded = false;
    boolean isVirtualConfig = (configName != null && configName.length() > 0 && Res
        .getString(Res.bc4jConDefaultName).equals(configName));
    if (!isVirtualConfig && (configMgr != null))
    {
      isEmbedded = configMgr.isEmbeddedConfig(configName);
    } else if (isVirtualConfig && Configuration.isEmbeddedConfig(origCmdParams))
    {
      isEmbedded = true;
    }
    return isEmbedded;
  }

  private final boolean isNewConfig()
  {
    return mode == ConfigMode.NEW;
  }

  private final void jbInit()
  {
    setHelpLocation("f1_bcbctconnect_html");
    JPanel appConPanel = getMainPanel();
    GridBagLayout gbl = (GridBagLayout) appConPanel.getLayout();
    GridBagConstraints gbc = new GridBagConstraints();
    // Border top, bottom
    appConPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
    // Default constraint use by both panel
    gbc.gridx = 0;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.weightx = 1.0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    // Name panel
    if (showNamedConnections)
    {
      JPanel namePanel = buildNamePanel();
      gbc.insets = new Insets(5, 5, 0, 15);
      gbl.setConstraints(namePanel, gbc);
      appConPanel.add(namePanel);
      if (!isEditing())
      {
        bc4jConNameCombo.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
            bc4jConNameCombo_actionPerformed(e);
          }
        });
      }
    }
    // Create the tab panel
    JTabbedPane tabPanel = new JTabbedPane();
    tabPanel.addChangeListener(this);
    // Add the three tabs
    tabPanel.addTab(Res.getString(Res.CONNECT_DIALOG_APPMODULETAB),
        createAMConfPanel());
    if (isEditing())
    {
      mPoolParameterPanel = new PoolParameterPanel(parent, cmdParams);
      tabPanel.addTab(Res.getString(Res.CONNECT_DIALOG_SCALABILITYTAB),
          mPoolParameterPanel);
    }
    tabPanel.addTab(Res.getString(Res.CONNECT_DIALOG_PROPERTIESTAB),
        propConfPanel);
    gbc.insets = new Insets(0, 5, 0, 5);
    gbl.setConstraints(tabPanel, gbc);
    appConPanel.add(tabPanel);
  }

  private final void orbTypeCombo_actionPerformed(ActionEvent e)
  {
    int orbType = orbTypeCombo.getSelectedIndex();
    cardLayout.show(appConTypePanel, platforms[orbType]);
    currentParams.put(PropertyMetadata.DEPLOY_PLATFORM.getName(),
        platforms[orbType]);
    PlatformPanel panel = (PlatformPanel) appConTypePanel.getComponent(orbType);
    panel.setParams(currentParams);
    initdbConnTypeCombo(orbType);
  }

  private final void populatePropertiesTable()
  {
    getParamFromPanel(currentParams, false);
    // Make sure currentParams is up to date.
    removeDeletedParameters();
    ArrayList props = new ArrayList(50);
    HashMap exist = new HashMap(10);
    // Populate the properties table with the properties that are already in
    // the properties table and that are modified/new.
    Property[] properties = this.getProperties();
    for (int i = 0; i < properties.length; i++)
    {
      Property pi = properties[i];
      if (pi != null && (pi.isNew || pi.isModified) && pi.key != null
          && pi.key.length() > 0)
      {
        props.add(pi);
        exist.put(pi.key, pi.value);
      }
    }
    // Populate the properties table with the all properties that are
    // defined in the PropertyMetadata.
    for (Enumeration e = PropertyMetadata.elements(); e.hasMoreElements();)
    {
      String key;
      String val;
      String desc;
      boolean readOnly = false;
      PropertyMetadata propMD = (PropertyMetadata) e.nextElement();
      key = propMD.getName();
      // Already in props
      if (exist.get(key) != null)
      {
        continue;
      }
      if (propMD == PropertyMetadata.DEPLOY_PLATFORM
          || propMD == PropertyMetadata.CONNECTION_MODE
          || propMD == PropertyMetadata.HOST_NAME
          || propMD == PropertyMetadata.CONNECTION_PORT
          || propMD == PropertyMetadata.APPLICATION_PATH
          || propMD == PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE
          || propMD == PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE
          || propMD == PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD
          || propMD == PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE
          || propMD == PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE
          || propMD == PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE
          || propMD == PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL
          || propMD == PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE
          || propMD == PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE
          || propMD == PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE
          || propMD == PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE
          || propMD == PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE
          || propMD == PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL
          || propMD == PropertyMetadata.ENV_DO_FAILOVER
          || propMD == PropertyMetadata.ENV_DO_CONNECTION_POOLING
          || propMD == PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS
          || propMD == PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE
          || propMD == PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING
      // || propMD == PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE
          
      )
      {
        readOnly = true;
      }
      val = (String) currentParams.get(key);
      //desc = propMD.pDescription;
      desc = propMD.getDescription();
      if (val == null)
      {
        val = propMD.getDefault();
      }
      Property pi = new Property(key, val, desc, readOnly, false, false, false);
      props.add(pi);
    }
    // Populate the properties table with the current parameters (retrieved
    // via getParamFromPanel above).
    int i = 0;
    for (Enumeration e = currentParams.keys(); e.hasMoreElements();)
    {
      String key = (String) e.nextElement();
      boolean readOnly = false;
      // Already in props
      if (exist.get(key) != null)
      {
        continue;
      }
      // Don't show this one
      if (key.compareTo(Configuration.DB_CONNECTION_PROPERTY) == 0
          || key.compareTo(Configuration.BC4J_CONFIG_NAME) == 0
          || key.compareTo(Configuration.IS_INTERNAL) == 0
          || key.compareTo(Configuration.CONFIGURATION_NAME) == 0)
      {
        continue;
      }
      // If it is in the metadata list, it means it has been dealt with
      // by the loop above.
      PropertyMetadata propMD = PropertyMetadata.findProperty(key);
      if (propMD != null)
      {
        continue;
      }
      if (key.compareTo(Configuration.APPLICATION_NAME_PROPERTY) == 0
          || key.compareTo(Configuration.APPLICATION_TYPE_PROPERTY) == 0
          || key.compareTo(JboTesterUtil.EJB_CLIENT_JARS) == 0
          || key.compareTo(Configuration.JDBC_CONNECTION_NAME) == 0)
      {
        readOnly = true;
      }
      Property pi = new Property(key, (String) currentParams.get(key), key,
          readOnly, false, false, true);
      props.add(i++, pi);
    }
    properties = (Property[]) props.toArray(new Property[props.size()]);
    propConfPanel.setProperties(properties);
    propConfPanel.sort();
    propConfPanel.refresh();
  }

  private void removeDeletedParameters()
  {
    propConfPanel.removeDeletedParameters(currentParams);
  }

  private final void setJdbcConnectionPanelEnabled(boolean isEnabled)
  {
    dsNameField.setEnabled(isEnabled);
    connTypeCombo.setEnabled(isEnabled);
    dbConnTypeCombo.setEnabled(isEnabled);
    userNameField.setEnabled(isEnabled);
    urlField.setEnabled(isEnabled);
  }

  private void setProperties(Property[] properties)
  {
    this.propConfPanel.setProperties(properties);
  }

  private final void showJdbcPanel(int panelType)
  {
    String panelName = jdbcPanelNames[panelType];
    CardLayout layout = (CardLayout) jdbcConnPanel.getLayout();
    layout.show(jdbcConnPanel, panelName);
  }

  private final boolean useDataSource()
  {
    return (dbConnTypeCombo.getSelectedIndex() == JDBC_DS_PANEL);
  }

  private final boolean validateAndUpdateConnectionParams(Hashtable params,
      boolean showError)
  {
    boolean retVal = true;
    try
    {
      // 2716254 remove all existing connection parameters before adding them
      // back.
      params.remove(Configuration.JDBC_DS_NAME);
      params.remove(Configuration.JDBC_CONNECTION_NAME);
      params.remove(Configuration.IIOP_CONNECTION_NAME);
      params.remove(Configuration.HTTP_CONNECTION_NAME);
      boolean isConnectionRequired = connRequiredCheck.getModel().isSelected();
      if (useDataSource())
      {
        String dsName = dsNameField.getText();
        if (dsName == null || dsName.length() <= 0)
        {
          if (showError && isConnectionRequired)
          {
            ErrorHandler.displayError(parent, Res
                .getString(Res.CONNECT_DIALOG_CON_NAME_ERROR));
            return false;
          }
        } else if (isConnectionRequired)
        {
          params.put(Configuration.JDBC_DS_NAME, dsName);
        }
      } else
      {
        String connectionName = (String) connTypeCombo.getSelectedItem();
        if (connectionName == null || connectionName.length() <= 0)
        {
          if (showError && isConnectionRequired)
          {
            ErrorHandler.displayError(parent, Res
                .getString(Res.CONNECT_DIALOG_CON_NAME_ERROR));
            return false;
          }
        } else if (isConnectionRequired)
        {
          updateConnectionParams(params, connectionName);
        }
        retVal = true;
      }
    } catch (Exception ex)
    {
      if (showError)
      {
        ErrorHandler.displayError(parent, ex);
      }
      return false;
    }
    return retVal;
  }

  abstract protected void connTypeCombo_actionPerformed(ActionEvent e);

  abstract protected void updateConnectionCombo(int orbType);

  abstract protected void updateConnectionParams(Hashtable params,
      String connectionName) throws IOException;
}
