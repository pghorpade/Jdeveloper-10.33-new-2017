/*
 * @(#)JBOControlMouseAdapter.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import oracle.jbo.AttributeDef;

abstract class JBOControlMouseAdapter implements MouseListener
{
   private final MainFrame    mainFrame;

   JBOControlMouseAdapter(MainFrame parentFrame)
   {
      super();

      mainFrame = parentFrame;
   }

   public void mouseClicked(MouseEvent e)
   {
   }

   public void mousePressed(MouseEvent e)
   {
      if (e.getModifiers() != MouseEvent.META_MASK)
      {
         // Only on a Right Mouse Click
         return;
      }

      AttDefDialog attrDlg = getAttrDefDialog(getAttributeDef(e), mainFrame);

      Point p = e.getComponent().getLocationOnScreen();
      attrDlg.setLocation(p.x + e.getX(), p.y + e.getY());
      attrDlg.setVisible(true);
      attrDlg.show();
      // For jdk1.2, need to set the focus to the window
      attrDlg.requestFocus();

      mainFrame.setPopup(attrDlg);
   }

   public void mouseReleased(MouseEvent e)
   {
/*
      if ( mDlg != null )
      {
         mDlg.setVisible(false);
      }
*/
   }

   public void mouseEntered(MouseEvent e)
   {
   }

   public void mouseExited(MouseEvent e)
   {
   }

   abstract public AttDefDialog getAttrDefDialog(AttributeDef attrDef, MainFrame parentFrame);

   abstract public AttributeDef getAttributeDef(MouseEvent e);

}

