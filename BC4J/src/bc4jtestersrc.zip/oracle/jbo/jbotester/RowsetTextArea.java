/*
 * @(#)RowsetTextArea.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.text.Keymap;
import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;

public final class RowsetTextArea extends JTextArea implements JBOField
{
   private final JBOFieldHelper jboField;
   private final LocaleContext locale;
   private final JScrollPane areaScrollPane;
   private Color enabledColor;
   
   public RowsetTextArea(AttributeDef attDef, LocaleContext locale)
   {
      jboField = new JBOFieldHelper(attDef, this);
      this.locale = locale;
      
      setLineWrap(true);
      setWrapStyleWord(true);
      this.enabledColor = this.getBackground();
      
      areaScrollPane = new JScrollPane(this);
      
      // Map the "Esc" ket to a cancel action
      KeyStroke cancel = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
      Keymap map =  getKeymap();
      if (map.getAction(cancel) != JBOFieldHelper.CancelAction)
      {
         map.addActionForKeyStroke(cancel, JBOFieldHelper.CancelAction);
      }
      
      jboField.init();
   }

   public JComponent getJComponent()
   {
      return this;
   }

   public LocaleContext getLocaleContext()
   {
      return locale;
   }
   
   public JComponent getScrollPane()
   {
      return areaScrollPane;
   }
   
   public Object getControlValue()
   {
      return getText();
   }

   public void setControlValue(Object value)
   {
      setText((value != null) ? value.toString() : "");
   }

   public void setRow(Row newRowBinding, RowSetIterator iter)
   {
      jboField.setRow(newRowBinding, iter);
   }

   public AttributeDef getAttributeDef()
   {
      return jboField.getAttributeDef();
   }
   
   public Object getDataValue()
   {
      return jboField.getDataValue();
   }

   public boolean setDataValue(Object value)
   {
      return jboField.setDataValue(value);
   }

   public boolean applyEdit()
   {
      return jboField.applyEdit();
   }

   public boolean applyEditAndValidate()
   {
      return jboField.applyEditAndValidate();
   }

   public void refresh()
   {
      jboField.refresh();
   }
   
   public void setEnabled(boolean enabled)
   {
     super.setEnabled(enabled);
     this.setBackground(enabled?this.enabledColor:this.getParent().getBackground());
   }
}




