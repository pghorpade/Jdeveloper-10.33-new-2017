/*
 * @(#)WLPanel.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.PropertyMetadata;
import oracle.jdeveloper.cm.ConnectionDescriptor;
import oracle.jdeveloper.cm.ConnectionManager;
import oracle.jdeveloper.cm.Weblogic6ConnectionType;
import oracle.jdeveloper.cm.Weblogic7ConnectionType;

public final class WLPanel extends PlatformPanel
{
   private final static String WEBLOGIC_JAR = ConnectionDescriptor.OC4J_HOME;
   private final JComboBox appServerConnectionCombo = new JComboBox();
   private final JTextField jndiPathField = new JTextField();

   public WLPanel(Frame parentFrame)
   {
      super(new GridBagLayout());

      parent = parentFrame;

      JLabel appServerConnectionLabel = JboTesterUtil.createLabel(Res.WL_PANEL_SERVER, appServerConnectionCombo);
      JLabel jndiPathLabel = JboTesterUtil.createLabel(Res.PANEL_JNDI_PATH, jndiPathField);

      GridBagLayout gbl          = (GridBagLayout) getLayout();
      GridBagConstraints gbc     = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbc.weighty = 0.0;
      gbc.insets = new Insets(0, 10, 10, 0);
      gbc.anchor = GridBagConstraints.EAST;
      gbl.setConstraints(appServerConnectionLabel, gbc);
      add(appServerConnectionLabel);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(appServerConnectionCombo, gbc);
      add(appServerConnectionCombo);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = 0.0;
      gbl.setConstraints(jndiPathLabel, gbc);
      add(jndiPathLabel);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.weightx = 1.0;
      gbl.setConstraints(jndiPathField, gbc);
      add(jndiPathField);

   }

   // Initialize fields given the hashtable of values
   public void setParams(Hashtable params)
   {
      String appServerConnectionName = (String)params.get(Configuration.APPSERVER_CONNECTION_NAME);
      initAppServerConnectionCombo(appServerConnectionName);

      String value = (String) params.get(PropertyMetadata.APPLICATION_PATH.getName());
      if (value == null)
      {
         value = "";
      }
      jndiPathField.setText(value);
   }
   
   public boolean getParams(Hashtable params, boolean showError)
   {
      String jndiPath = jndiPathField.getText();
      boolean isValid = false;
      
      String appServerConnectionName = (String)appServerConnectionCombo.getSelectedItem();
      if(appServerConnectionName != null)
      {
         appServerConnectionName = appServerConnectionName.trim();
         if (appServerConnectionName.length() > 0)
         {
            params.put(Configuration.APPSERVER_CONNECTION_NAME, appServerConnectionName);
            isValid = true;
         }
      }

      if (!isValid)
      {
         if (showError)
         {
            ErrorHandler.displayError(parent, Res.getString(Res.APPSERVER_CONNECTION_ERROR));
         }
         return false;
      }

      // Get the weblogic client jar name from the
      // connection
      addEjbClientJars(params, showError);

      if (jndiPath != null)
      {
         jndiPath = jndiPath.trim();
         if (jndiPath.length() > 0)
         {
            params.put(PropertyMetadata.APPLICATION_PATH.getName(), jndiPath);
         }
      }
      return true;
   }


   private void initAppServerConnectionCombo(String connectionName)
   {
      String names[] = getConnectionNames(new String[] {
                            Weblogic6ConnectionType.CONN_WEBLOGIC_6,
                            Weblogic7ConnectionType.CONN_WEBLOGIC_7});
      DefaultComboBoxModel model = new DefaultComboBoxModel(names);
      appServerConnectionCombo.setModel(model);
      if(connectionName != null)
      {
         model.setSelectedItem(connectionName);
      }
   }

   private void addEjbClientJars(Hashtable params, boolean showErrors)
   {
      String connectionName = (String)appServerConnectionCombo.getSelectedItem();
      if(connectionName != null)
      {
         try
         {
            ConnectionManager cm = ConnectionManager.getInstance();
            ConnectionDescriptor cd = cm.getConnectionDescriptor(connectionName);
            String weblogicJar = cd.getProperty(WEBLOGIC_JAR);
            boolean foundJar = false;
            if(weblogicJar != null)
            {
               foundJar = new File(weblogicJar).exists();
            }
            if(foundJar)
            {
               params.put(JboTesterUtil.EJB_CLIENT_JARS,weblogicJar);
            }
            else if(showErrors)
            {
               ErrorHandler.displayError(parent, 
                                         Res.format(Res.ERROR_INVALID_WEBLOGIC_JAR,
                                                    connectionName));
            }
         }
         catch(Exception ex)
         {
            if(showErrors)
            {
               ErrorHandler.displayError(parent, ex);
            }
         }
      }
   }

   private String[] getConnectionNames(String connTypes[])
   {

      ConnectionManager cm = ConnectionManager.getInstance();
      String connNames[] = null;
      for(int i = 0 ; i < connTypes.length ; i++)
      {
         if(connTypes[i] != null)
         {
            try
            {
               String names[] = cm.getConnectionNames(connTypes[i]);
               if(connNames == null)
               {
                  connNames = new String[names.length];
                  System.arraycopy(names, 0,  connNames, 0,  names.length);
               }
               else
               {
                  String s[] = new String[connNames.length + names.length];
                  System.arraycopy(connNames,0, s, 0, connNames.length);
                  System.arraycopy(names, 0, s, connNames.length, names.length);
                  connNames = s;
               }
            }
            catch(IOException ex)
            {
               ErrorHandler.displayError(parent, ex);
            }
         }
      }
      if(connNames == null)
      {
         connNames = new String[] {null};
      }
      return connNames;
   }
}
