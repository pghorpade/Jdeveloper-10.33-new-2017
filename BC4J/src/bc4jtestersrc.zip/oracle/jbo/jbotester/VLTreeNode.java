/*
 * @(#)VLTreeNode.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewLink;
import oracle.jbo.AttributeDef;
import oracle.jbo.jbotester.properties.ViewLinkBean;

public final class VLTreeNode extends ObjTreeNode
{
   private ApplicationModule am;
   private String            name;
   private ViewLink          vl;
   private static ImageIcon  icon; // shared by all instance of this class

   public VLTreeNode(ViewLink viewLink)
   {
      this(viewLink.getSource().getApplicationModule(), viewLink);
   }
   
   public VLTreeNode(ApplicationModule appMod, ViewLink viewLink)
   {
      this(appMod, viewLink.getName());

      vl = viewLink;
   }
   
   public VLTreeNode(ApplicationModule appMod, String vlName)
   {
      super(vlName);

      name = vlName;
      am = appMod;
      
      if (icon == null)
      {
         icon = JboTesterUtil.getIcon("NodeVLU.gif");
      }
   }

   public String getName()
   {
      return name;
   }

   public String getFullName()
   {
      if (vl != null)
      {
         return vl.getFullName();
      }
      else
      {
         return (am.getFullName() + "." + name);
      }
   }

   public int getType()
   {
      return VIEW_LINK;
   }

   public Object getData()
   {
      if (vl == null)
      {
         vl = am.findViewLink(name);
      }
      
      return vl;
   }

   public void setData(Object data)
   {
      vl = (ViewLink) data;
   }

   public ImageIcon getIcon()
   {
      return icon;
   }

   public void showForm()
   {
      String fullName = getFullName();

      ResultWindow rw = ResultWindow.getResultWindow();
      if (rw.getTab(fullName) == null)
      {
         MainFrame.getInstance().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
         try
         {
            SimpleForm f;

            // Get the vl instance if not there yet
            getData();

            // Detect if it is a self join with an accessor
            boolean bIsTree = false;

            if (vl.getSource().getDefName().equals(vl.getDestination().getDefName()))
            {
               // Temporary fix around problem when there are two accessor on the ViewLink.
               // findViewLinkAccessor should return an array and we should look for the accessor of 
               // type ATTR_ASSOCIATED_ROWITERATOR.
               AttributeDef accessorDef = vl.getSource().findViewLinkAccessor(vl);

               if (accessorDef != null && accessorDef.getAttributeKind() == AttributeDef.ATTR_ASSOCIATED_ROWITERATOR)
               {
                  bIsTree = true;
               }
            }

            if (bIsTree)
            {
               f = new TreeForm(MainFrame.getInstance(), this, vl);
            }
            else
            {
               f = new MDForm(MainFrame.getInstance(), this, vl.getSource(), vl.getDestination());
            }

            rw.addTab(f, fullName);
            MainFrame.getInstance().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
         }
         catch(Throwable t)
         {
            ErrorHandler.displayError(MainFrame.getInstance(), t);
         }
      }
      else
      {
         rw.showTab(fullName);
      }
   }
   
   public String getStatus()
   {
      StringBuffer status = new StringBuffer();

      status.append(Res.getString(Res.TREE_STATUS_LINE_NAME));

      if (vl != null)
      {
         status.append(vl.getFullName());
         status.append(Res.getString(Res.TREE_STATUS_LINE_DEFINITION));
         status.append(vl.getDefFullName());

         // Select the form matching
//Should not active the window
//       ResultWindow.getResultWindow().showTab(am.getName() + "." + name);
      }
      else
      {
         status.append(name);
      }

      return status.toString();
   }

   public void handleEvent(ActionEvent e)
   {
      if (e.getActionCommand().equals(JboTesterUtil.stripMnemonic(Res.getString(Res.TREE_MENU_FIND))))
      {
         JboTesterUtil.createViewCriteria(MainFrame.getInstance(), vl.getSource());
      }
      else if (e.getActionCommand().equals(JboTesterUtil.stripMnemonic(Res.getString(Res.TREE_MENU_EXECUTE))))
      {
         vl.getSource().executeQuery();
         vl.getDestination().executeQuery();
      }
   }

   public JPopupMenu getMenu()
   {
      return createVOVLMenu(vl);
   }

   public void remove()
   {
      if (vl == null)
      {
         vl = am.findViewLink(name);
      }
      
      if (vl != null)
      {
         JPanel form = ResultWindow.getResultWindow().removeTab(getFullName());
         if (form != null)
         {
            ((SimpleForm) form).setIterator(null);
            if (form instanceof MDForm)
            {
               ((MDForm) form).setDetailRowSetIterator(null);
            }
         }

         vl.remove();
         vl = null;
      }

      super.remove();
   }

   public void showProperties()
   {
      ViewLinkBean vlBean = new ViewLinkBean(vl);
      showPropertyDialog(vlBean, vlBean.getBeanInfo(), Res.TREE_vlProperties);
   }
}
