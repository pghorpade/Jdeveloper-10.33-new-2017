/*
 * @(#)VODialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;

public final class VODialog extends GenericDialog
{
   static final int FROM_VIEW_DEF      = 0;
   static final int FROM_QUERY_CLAUSES = 1;
   static final int FROM_SQL_STMT      = 2;

   private final ApplicationModule  mAppModule;
   private final CardLayout         cardLayout;
   private final JPanel             controlPanel;

   private final JComboBox    voTypeCombo = new JComboBox(new String[]{ Res.getString(Res.VO_DIALOG_FROM_VIEW_DEF),
                                                                        Res.getString(Res.VO_DIALOG_FROM_QUERY_CLAUSE),
                                                                        Res.getString(Res.VO_DIALOG_FROM_SQL_STMT) });

   private final JComboBox    vdCombo     = new JComboBox();
   private final JTextArea    sqlField    = new JTextArea(5, 40);

   private final JTextField   voField1    = new JTextField();
   private final JTextField   voField2    = new JTextField();
   private final JTextField   voField3    = new JTextField();
   private final JComboBox    edCombo     = new JComboBox();
   private final JTextField   selField    = new JTextField();
   private final JTextField   fromField   = new JTextField();
   private final JTextField   whereField  = new JTextField();
   private final JTextField   orderField  = new JTextField();

   private ViewObject mViewObject;

   private boolean vdInitialized;
   private boolean edInitialized;

   public VODialog(JFrame frame, ApplicationModule appMod)
   {
      super(frame, Res.getString(Res.VO_DIALOG_TITLE), new JPanel(new CardLayout()), OK_CANCEL_HELP_OPTION, Res.getString(Res.DIALOG_CREATE_BUTTON));

      mAppModule = appMod;

      setHelpLocation("f1_bcbctcreatevo_html");

      edCombo.setEditable(true);
      vdCombo.setEditable(true);

      voTypeCombo.addActionListener(new java.awt.event.ActionListener()
                                    {
                                       public void actionPerformed(ActionEvent e)
                                       {
                                          voTypeCombo_actionPerformed(e);
                                       }
                                    });

      JLabel voType = JboTesterUtil.createLabel(Res.VO_DIALOG_CREATION_TYPE, voTypeCombo);

      GridBagLayout gbl      = new GridBagLayout();
      JPanel voTypePanel     = new JPanel(gbl);
      GridBagConstraints gbc = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(10, 5, 5, 5);
      gbl.setConstraints(voType, gbc);
      voTypePanel.add(voType);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(voTypeCombo, gbc);
      voTypePanel.add(voTypeCombo);

      getContentPane().add(voTypePanel, BorderLayout.NORTH);

      controlPanel = getMainPanel();
      controlPanel.setBorder(BorderFactory.createCompoundBorder(
                              BorderFactory.createEmptyBorder(5, 5, 5, 5),
                              new SoftBevelBorder(BevelBorder.LOWERED)));
      cardLayout = (CardLayout) controlPanel.getLayout();

      controlPanel.add(createVDPanel(),  Integer.toString(FROM_VIEW_DEF));
      controlPanel.add(createQCPanel(),  Integer.toString(FROM_QUERY_CLAUSES));
      controlPanel.add(createSQLPanel(), Integer.toString(FROM_SQL_STMT));

      initViewDefCombo();
   }

   void voTypeCombo_actionPerformed(ActionEvent e)
   {
      String panelName = Integer.toString(voTypeCombo.getSelectedIndex());

      switch (voTypeCombo.getSelectedIndex())
      {
         case FROM_VIEW_DEF:
            initViewDefCombo();
            cardLayout.show(controlPanel, panelName);
            break;

         case FROM_QUERY_CLAUSES:
            initEntityDefCombo();
            cardLayout.show(controlPanel, panelName);
            break;

         case FROM_SQL_STMT:
            cardLayout.show(controlPanel, panelName);
            break;
      }
   }

   private JPanel createVDPanel()
   {
      GridBagLayout gbl       = new GridBagLayout();
      JPanel vdPanel          = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();
      JLabel voName           = JboTesterUtil.createLabel(Res.VO_DIALOG_VO_NAME, voField1);
      JLabel vdName           = JboTesterUtil.createLabel(Res.VO_DIALOG_DEFINITION, vdCombo);
      
      vdPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

      JboTesterUtil.removeKeyBindingCompatibility(voField1);
      setInitialFocusComponent(voField1);

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(5, 5, 5, 5);
      gbl.setConstraints(voName, gbc);
      vdPanel.add(voName);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(voField1, gbc);
      vdPanel.add(voField1);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(vdName, gbc);
      vdPanel.add(vdName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 1;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(vdCombo, gbc);
      vdPanel.add(vdCombo);

      return vdPanel;
   }

   private JPanel createQCPanel()
   {
      GridBagLayout gbl       = new GridBagLayout();
      JPanel qcPanel          = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();
      JLabel voName           = JboTesterUtil.createLabel(Res.VO_DIALOG_VO_NAME, voField2);
      JLabel eoName           = JboTesterUtil.createLabel(Res.VO_DIALOG_ENTITY_NAME, edCombo);
      JLabel selClause        = JboTesterUtil.createLabel(Res.VO_DIALOG_SQL_SELECT, selField);
      JLabel fromClause       = JboTesterUtil.createLabel(Res.VO_DIALOG_SQL_FROM, fromField);
      JLabel whereClause      = JboTesterUtil.createLabel(Res.VO_DIALOG_SQL_WHERE, whereField);
      JLabel orderClause      = JboTesterUtil.createLabel(Res.VO_DIALOG_SQL_ORDERBY, orderField);

      selClause.setHorizontalAlignment(SwingConstants.RIGHT);
      fromClause.setHorizontalAlignment(SwingConstants.RIGHT);
      whereClause.setHorizontalAlignment(SwingConstants.RIGHT);
      orderClause.setHorizontalAlignment(SwingConstants.RIGHT);

      qcPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

      JboTesterUtil.removeKeyBindingCompatibility(voField2);

      int ypos = 1;

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(5, 5, 5, 5);
      gbl.setConstraints(voName, gbc);
      qcPanel.add(voName);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(voField2, gbc);
      qcPanel.add(voField2);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(eoName, gbc);
      qcPanel.add(eoName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(edCombo, gbc);
      qcPanel.add(edCombo);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(selClause, gbc);
      qcPanel.add(selClause);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(selField, gbc);
      qcPanel.add(selField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(fromClause, gbc);
      qcPanel.add(fromClause);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(fromField, gbc);
      qcPanel.add(fromField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(whereClause, gbc);
      qcPanel.add(whereClause);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(whereField, gbc);
      qcPanel.add(whereField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(orderClause, gbc);
      qcPanel.add(orderClause);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(orderField, gbc);
      qcPanel.add(orderField);

      return qcPanel;
   }

   private JPanel createSQLPanel()
   {
      GridBagLayout gbl       = new GridBagLayout();
      JPanel sqlPanel         = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();
      JLabel voName           = JboTesterUtil.createLabel(Res.VO_DIALOG_VO_NAME, voField3);
      JLabel sqlName          = JboTesterUtil.createLabel(Res.VO_DIALOG_SQL_STMT, sqlField);

      sqlPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

      JboTesterUtil.removeKeyBindingCompatibility(voField3);

      JScrollPane areaScrollPane = new JScrollPane(sqlField);
      sqlField.setLineWrap(true);
      sqlField.setWrapStyleWord(true);

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(5, 5, 5, 5);
      gbl.setConstraints(voName, gbc);
      sqlPanel.add(voName);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(voField3, gbc);
      sqlPanel.add(voField3);

      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(sqlName, gbc);
      sqlPanel.add(sqlName);

      gbc.fill = GridBagConstraints.BOTH;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 1;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.gridheight = GridBagConstraints.REMAINDER;
      gbl.setConstraints(areaScrollPane, gbc);
      sqlPanel.add(areaScrollPane);

      return sqlPanel;
   }

   void createViewObject()
   {
      try
      {
         boolean voCreated = true;
         switch (voTypeCombo.getSelectedIndex())
         {
            case FROM_VIEW_DEF:
               voCreated = createVOFromDef();
               break;

            case FROM_QUERY_CLAUSES:
               voCreated = createVOFromQueryClauses();
               break;

            case FROM_SQL_STMT:
               voCreated = createVOFromSQLStmt();
               break;
         }
         if(voCreated)
         {
            close();
         }
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(parent, e);
      }
   }

   private boolean createVOFromDef()
   {
      String viewDefName = (String)vdCombo.getSelectedItem();
      if(viewDefName.length() <= 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.VO_DIALOG_DEFINITION_ERROR));
         return false;
      }
      mViewObject = mAppModule.createViewObject(voField1.getText(),viewDefName);
      return true;
   }

   private boolean createVOFromQueryClauses()
   {
      String eoName = (String)edCombo.getSelectedItem();
      if(eoName.length() <= 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.VO_DIALOG_ENTITY_ERROR));
         return false;
      }

      String selClause = selField.getText();
      if(selClause.length() <= 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.VO_DIALOG_SELECT_ERROR));
         return false;
      }

      String fromClause = fromField.getText();
      if(fromClause.length() <= 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.VO_DIALOG_FROM_ERROR));
         return false;
      }

      mViewObject = mAppModule.createViewObjectFromQueryClauses(voField2.getText(),
                                                                eoName,
                                                                selClause,
                                                                fromClause,
                                                                whereField.getText(),
                                                                orderField.getText());
      //Bug #2942665
      // getAttributeDefs will verify primary keys when it initialize the view attributes
      try
      {
         mViewObject.getAttributeDefs();
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(parent, e);
         mViewObject.remove();
         mViewObject = null;
         return false;
      }
      return true;
   }

   private boolean createVOFromSQLStmt()
   {
      String sqlStmt = sqlField.getText();

      sqlStmt.trim();
      if (sqlStmt.length() <= 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.VO_DIALOG_SQL_ERROR));
         return false;
      }

      mViewObject = mAppModule.createViewObjectFromQueryStmt(voField3.getText(), sqlStmt);
      return true;
   }

   public ViewObject getViewObject()
   {
      return mViewObject;
   }

   private void initViewDefCombo()
   {
      if(vdInitialized == true)
      {
         return ;
      }
      String vdNames[] = mAppModule.getSession().getAllViewDefNames();
      if((vdNames == null) || (vdNames.length <= 0))
      {
         return ;
      }
      for(int i=0; i < vdNames.length; i++)
      {
         vdCombo.addItem(vdNames[i]);
      }
      vdInitialized = true;
   }

   private void initEntityDefCombo()
   {
      if(edInitialized == true)
      {
         return ;
      }
      String edNames[] = mAppModule.getSession().getAllEntityDefNames();
      if((edNames == null) || (edNames.length <= 0))
      {
         return ;
      }
      for(int i=0; i < edNames.length; i++)
      {
         edCombo.addItem(edNames[i]);
      }
      edInitialized = true;
   }


   public void actionPerformed(ActionEvent event)
   {
      String cmd = event.getActionCommand();

      if (cmd.equals(OK_ACTION))
      {
         createViewObject();
      }
      else
      {
         super.actionPerformed(event);
      }
   }

}
