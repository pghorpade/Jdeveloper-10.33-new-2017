/*
 * @(#)VCDialog.java
 * 
 * Copyright 1999-2002 by Oracle Corporation, 500 Oracle Parkway, Redwood
 * Shores, California, 94065, U.S.A. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Oracle
 * Corporation.
 */
package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import oracle.jbo.AttributeDef;
import oracle.jbo.StructureDef;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.ViewObject;
import com.sun.java.util.collections.ArrayList;

public class VCDialog extends JTDialog
{
  private static JButton createButton(int resourceID)
  {
    String label = Res.getString(resourceID);
    return new JButton(JboTesterUtil.stripMnemonic(label));
  }
  private JButton      addButt            = createButton(Res.VC_DIALOG_OR_BUTTON);
  AttributeDef[]       attribs            = null;
  private JPanel       buttonPanel        = new JPanel();
  private JButton      cancelButt         = createButton(Res.DIALOG_CANCEL_BUTTON);
  private JButton      createButt         = createButton(Res.VC_DIALOG_FIND_BUTTON);
  private JButton      helpButt           = createButton(Res.DIALOG_HELP_BUTTON);
  private boolean      isVCExecuted       = true;
  private ArrayList    mColumnNames       = null;
  private ArrayList    mFields            = null;
  private String       mMnemonics         = "";
  private ViewCriteria mOriginalVC        = null;
  private String       mReservedMnemonics = "";
  private ViewCriteria mViewCriteria      = null;
  private ViewObject   mViewObject        = null;
  private JButton      removeAllButt      = createButton(Res.VC_DIALOG_REMOVEALL_BUTTON);
  private JButton      removeButt         = createButton(Res.VC_DIALOG_REMOVE_BUTTON);
  private JTabbedPane  tabPane            = new JTabbedPane();
  private int          vcRowCounter       = 0;

  private static String titleFirstTab = Res.getString(Res.VC_DIALOG_CRITERIA_TAB);

  private final KeyListener keyListener = new KeyListener()
  {
    public void keyTyped(KeyEvent e)
    {
      if(e.getSource() instanceof JTextField)
      {
        if(((JTextField)e.getSource()).getText()!=null)
        {
          setEnabledRemoveButtons(true);
        }
      }
    }
    public void keyReleased(KeyEvent e){}
    public void keyPressed(KeyEvent e){}
  };

  public VCDialog(MainFrame frame, ViewObject vo)
  {
    super(frame, Res.VC_DIALOG_TITLE);
    mViewObject = vo;
    try
    {
      jbInit();
    } catch (Exception e)
    {
      ErrorHandler.displayError(parent, e);
    }
  }

  private void addViewCriteriaRows()
  {
    // Browse All Tabs and add View Criteria Rows
    String str;
    ViewCriteriaRow vr = null;
    ArrayList columnNames;
    ArrayList fields;
    mViewCriteria.removeAllElements();
    int count = tabPane.getTabCount();
    for (int j = 0; j < count; j++)
    {
      columnNames = (ArrayList) mColumnNames.get(j);
      fields = (ArrayList) mFields.get(j);
      for (int i = 0; i < fields.size(); i++)
      {
        str = ((JTextField) fields.get(i)).getText();
        if ((str == null) || (str.length() <= 0))
        {
          continue;
        }
        if (vr == null)
        {
          vr = mViewCriteria.createViewCriteriaRow();
        }
        vr.setAttribute((String) columnNames.get(i), str);
      }
      if (vr != null)
      {
        mViewCriteria.addElement(vr);
        vr = null;
      }
    }
  }

  protected void cancel()
  {
    if (!isVCExecuted)
    {
      try
      {
        mViewObject.applyViewCriteria(mOriginalVC);
        mViewObject.executeQuery();
      } catch (Exception ex)
      {
        // Just Ignore
      }
    }
  }

  private void createViewCriteria()
  {
    try
    {
      addViewCriteriaRows();
      mViewObject.applyViewCriteria(mViewCriteria);
      mViewObject.executeQuery();
      ((MainFrame)this.parent).showTab(mViewObject.getFullName());
      close();
    } catch (Exception e)
    {
      ErrorHandler.displayError(parent, e);
      isVCExecuted = false;
    }
  }

  private void createViewCriteriaRow(boolean cleanup)
  {
    if (cleanup)
    {
      tabPane.removeAll();
      mColumnNames = new ArrayList();
      mFields = new ArrayList();
      vcRowCounter = 0;
      this.setEnabledRemoveButtons(false);
    }
    this.mMnemonics = this.mReservedMnemonics;
    String title;
    if (vcRowCounter++ == 0)
    {
      title = titleFirstTab;
    } else
    {
      title = Res.getString(Res.VC_DIALOG_OR_TAB);
    }
    GridBagLayout gbl = new GridBagLayout();
    JPanel mPanel = new JPanel(gbl);
    GridBagConstraints gbc = new GridBagConstraints();
    mPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
    int ypos = 0;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(5, 5, 10, 5);
    ArrayList columnNames = new ArrayList();
    ArrayList fields = new ArrayList();
    mColumnNames.add(columnNames);
    mFields.add(fields);
    gbc.anchor = GridBagConstraints.WEST;
    gbc.gridx = 0;
    gbc.gridy = ypos++;
    gbc.weightx = 1.0;
    gbc.gridwidth = 2;
    JLabel label = new JLabel(Res.getString(Res.VC_DIALOG_HINT_LABEL));
    gbl.setConstraints(label, gbc);
    mPanel.add(label);
    gbc.insets = new Insets(5, 5, 0, 5);
    for (int i = 0; i < attribs.length; i++)
    {
      label = new JLabel(attribs[i].getName() + ":");
      JTextField textField = new JTextField();
      textField.addKeyListener(keyListener);
      columnNames.add(attribs[i].getName());
      fields.add(textField);
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = ypos;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(label, gbc);
      mPanel.add(label);
      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 1;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(textField, gbc);
      mPanel.add(textField);
      this.setMnemonic(label, textField);
    }
    JTScrollPane scroller = new JTScrollPane(mPanel);
    tabPane.add(title, scroller);
    tabPane.setSelectedComponent(scroller);
  }

  private char getMnemonic(String label)
  {
    //if we encounter a mnemonic already in use, we move along and try the next
    //character. at the end of the string, we just give up...
    for (int i = 0; i < label.length(); i++)
    {
      String proposedMnemonic = label.substring(i, i + 1).toUpperCase();
      if (mMnemonics.indexOf(proposedMnemonic) < 0)
      {
        char mnemonic = label.charAt(i);
        if (mnemonic >= 'A' && mnemonic <= 'z')
        {
          this.mMnemonics += proposedMnemonic;
          return mnemonic;
        }
      }
    }
    return ' ';
  }

  private void initButton(JButton button, ActionListener actionListener)
  {
    buttonPanel.add(button);
    button.addActionListener(actionListener);
    this.setMnemonic(button);
  }

  private void initViewCriteria()
  {
    mViewCriteria = mViewObject.getViewCriteria();
    // Save the Criteria in case of problem with the new one.
    if (mViewCriteria != null)
    {
      mOriginalVC = (ViewCriteria) mViewCriteria.clone();
    } else
    {
      mOriginalVC = (ViewCriteria) mViewObject.createViewCriteria().clone();
    }
    // Initialize Attribute Defs
    StructureDef rsinfo = mViewObject.getViewObject();
    AttributeDef[] attrs = rsinfo.getAttributeDefs();
    ArrayList v = new ArrayList();
    for (int i = 0; i < attrs.length; i++)
    {
      if (attrs[i].isQueriable())
      {
        v.add(attrs[i]);
      }
    }
    attribs = (AttributeDef[]) v.toArray(new AttributeDef[v.size()]);
    if ((mViewCriteria == null) || (mViewCriteria.size() == 0))
    {
      // No existing View Criteria
      createViewCriteriaRow(true);
      mViewCriteria = mViewObject.createViewCriteria();
      return;
    }
    ViewCriteriaRow vr = null;
    Enumeration en = mViewCriteria.elements();
    boolean first = true;
    //      int count = 0;
    ArrayList fields = null;
    ArrayList columnNames = null;
    int index;
    while (en.hasMoreElements())
    {
      createViewCriteriaRow(first);
      if (first)
      {
        first = false;
      }
      index = tabPane.getSelectedIndex();
      columnNames = (ArrayList) mColumnNames.get(index);
      fields = (ArrayList) mFields.get(index);
      vr = (ViewCriteriaRow) en.nextElement();
      //         count = vr.getAttributeCount();
      for (int i = 0; i < columnNames.size(); i++)
      {
        ((JTextField) fields.get(i)).setText((String) vr
            .getAttribute((String) columnNames.get(i)));
        //          this.setLabel(fields,i,(String)vr.getAttribute((String)columnNames.get(i)));
      }
    }
    this.setEnabledRemoveButtons(!first);

    // Just Reset the Criteria, so that we don't accidentally add the VC rows
    // twice
    mViewCriteria = mViewObject.createViewCriteria();
  }

  private void jbInit() throws Exception
  {
    this.initButton(createButt, new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        createViewCriteria();
      }
    });
    this.initButton(addButt, new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        createViewCriteriaRow(false);
        setEnabledRemoveButtons(true);
      }
    });
    this.initButton(removeButt, new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        removeCurrentVCRow();
        removeAllButt.setEnabled(tabPane.getTabCount()>1);
      }
    });
    this.initButton(removeAllButt, new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        createViewCriteriaRow(true);
      }
    });
    this.initButton(cancelButt, this.cancelAction);
    this.setHelpLocation("f1_bcbctviewcriteria_html");
    this.initButton(helpButt,this.helpAction); 

    getContentPane().add(tabPane, BorderLayout.CENTER);
    getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    this.mReservedMnemonics = this.mMnemonics;
    initViewCriteria();
  }

  private void removeCurrentVCRow()
  {
    // If this is the last row, recreate the first one.
    if (tabPane.getTabCount() <= 1)
    {
      createViewCriteriaRow(true);
    } else
    {
      int index = tabPane.getSelectedIndex();
      tabPane.removeTabAt(index);
      if (mColumnNames != null)
      {
        mColumnNames.remove(index);
      }
      if (mFields != null)
      {
        mFields.remove(index);
      }
      //in case we removed the 'Criteria', we want the (new) first tab not to show 'OR'
      tabPane.setTitleAt(0,titleFirstTab);
    }
  }

  private void setEnabledRemoveButtons(boolean enabled)
  {
    removeButt.setEnabled(enabled);
    removeAllButt.setEnabled(enabled && tabPane.getTabCount()>1);
  }

  private void setMnemonic(JButton button)
  {
    button.setMnemonic(this.getMnemonic(button.getText()));
  }

  private void setMnemonic(JLabel label, JTextField field)
  {
    label.setDisplayedMnemonic(this.getMnemonic(label.getText()));
    label.setLabelFor(field);
  }
}
