/*
 * @(#)TesterBeanInfo.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import java.beans.BeanDescriptor;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * This class implements an Tester beaninfo.
 *
 * @version PUBLIC
 */
public class TesterBeanInfo extends SimpleBeanInfo
{
   private Class              mInstanceClass = null;
   private PropertyDescriptor mProps[]       = null;

   public TesterBeanInfo(Class instanceClass, PropertyDescriptor[] pds)
   {
      mInstanceClass = instanceClass;
      mProps = pds;
   }

   public PropertyDescriptor[] getPropertyDescriptors()
   {
      return mProps;
   }


   public BeanDescriptor getBeanDescriptor()
   {
     return new BeanDescriptor(mInstanceClass);
   }
}

