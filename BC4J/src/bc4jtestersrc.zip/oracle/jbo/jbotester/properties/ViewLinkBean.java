/*
 * @(#)ViewLinkBean.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import com.sun.java.util.collections.ArrayList;
import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.util.Enumeration;
import java.util.Hashtable;
import oracle.jbo.ViewLink;

public class ViewLinkBean
{
   private ViewLink mViewLink = null;
   protected String hintName;

   public ViewLinkBean(ViewLink ViewLink)
   {
      mViewLink = ViewLink;
   }

   /**
    * Retrieve the class name.
    * @return name of the class
    */
   public String getDefName()
   {
     return mViewLink.getDefName();
   }

   public String getDefFullName()
   {
     return mViewLink.getDefFullName();
   }

   public String getName()
   {
     return mViewLink.getName();
   }

   public String getFullName()
   {
      return mViewLink.getFullName();
   }

   public String getSource()
   {
      return mViewLink.getSource().getFullName();
   }

   public String getDestination()
   {
      return mViewLink.getDestination().getFullName();
   }

   public Object getProperty()
   {
      Object obj = mViewLink.getProperty(hintName);

      if (obj instanceof String)
      {
         return (String) obj;
      }
      else
      {
         try
         {
            return obj.toString();
         }
         catch (Throwable t)
         {
            return "?";
         }
      }
   }

   public void setProperty(Object name)
   {
      // Since the user properties are readonly, use the setproperty to pass the hintName
      hintName = (String) name;
   }

   public BeanInfo getBeanInfo()
   {
      Class thisClass = this.getClass();
      try
      {
         ArrayList properties = new ArrayList();

         properties.add(new PropertyDescriptor("ComponentObject.Name", thisClass, "getName", null));
         properties.add(new PropertyDescriptor("ComponentObject.FullName", thisClass, "getFullName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefName", thisClass, "getDefName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefFullName", thisClass, "getDefFullName", null));
         properties.add(new PropertyDescriptor("ViewLink.SourceViewObject", thisClass, "getSource", null));
         properties.add(new PropertyDescriptor("ViewLink.DestinationViewObject", thisClass, "getDestination", null));

         Hashtable props = mViewLink.getProperties();
         if (props != null)
         {
            for (Enumeration enumKeys = props.keys(); enumKeys.hasMoreElements(); )
            {
               Object key = enumKeys.nextElement();

               properties.add(new PropertyDescriptor("Prop." + key.toString(), thisClass, "getProperty", "setProperty"));
            }
         }

         PropertyDescriptor[] list = (PropertyDescriptor[]) properties.toArray(new PropertyDescriptor[properties.size()]);

         return new TesterBeanInfo(thisClass, list);
      }
      catch (Exception e)
      {
         e.printStackTrace();
         return new TesterBeanInfo(thisClass, new PropertyDescriptor[0]);
      }
   }
}

