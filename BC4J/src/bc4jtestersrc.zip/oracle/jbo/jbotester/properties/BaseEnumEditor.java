/*
 * @(#)BaseEnumEditor.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyEditorSupport;
import javax.swing.JComboBox;

/**
 * This class implements an example validation property editor
 *
 */
abstract public class BaseEnumEditor extends PropertyEditorSupport
{
  class ActualEnumEditor extends JComboBox implements ItemListener
  {
      BaseEnumEditor host;

      ActualEnumEditor(BaseEnumEditor host) {
        super();
        this.host = host;
        String[] tags = host.getTags();
        for( int i = 0; i < tags.length; i++ )
        {
           addItem(tags[i]);
        }
        super.setSelectedIndex((new Integer(host.getAsText())).intValue());
        super.addItemListener(this);
      }
  
      //notification that an attribute or set of attributes changed. 
      public void itemStateChanged(ItemEvent ev) 
      {
         if( ev.getStateChange() == ItemEvent.SELECTED )
         {
            host.firePropertyChange();
            host.setValue(getSelectedItem());
         }
      }
  }
  
  private ActualEnumEditor editor;

  public String getJavaInitializationString() {
     return getEnumName()+ "." + getAsText().toUpperCase();
  }
  
  public Component getCustomEditor() {
    if (editor == null)
    {
       editor = new ActualEnumEditor(this);
    }
    return editor;
  }
  
  public boolean supportsCustomEditor() {
    return true;
  }

  public boolean isPaintable() {
    return ( editor != null );
  }

  public void paintValue(java.awt.Graphics gfx, java.awt.Rectangle box) {
     
     editor.paint(gfx);
  }
  
  public void setValue(Object o) 
  {
     if( o instanceof Integer )
     {
        int val = ((Integer)o).intValue();
        if( val > -1 && val < getTags().length )
        {
           super.setValue(o);
        }
     }
     else
     {
        setAsText(o.toString());
     }
  }

  public void setAsText(String txt)
  {
     String[] tags = getTags();
     for( int i = 0; i < tags.length; i++ )
     {
        if( tags[i].equals(txt) )
        {
           super.setValue(new Integer(i));
           return;
        }
     }
  }

  public String getAsText()
  {
     Object val = getValue();
     if( val instanceof Integer )
     {
        return val.toString();
     }
     return null;
  }

  abstract public String[] getTags();

  abstract protected String getEnumName();
}

