/*
 * @(#)PropertyPanel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.jbotester.properties;

import com.sun.java.util.collections.ArrayList;
import java.awt.Component;
import java.awt.Frame;
import java.awt.GridLayout;
import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.jbotester.ErrorHandler;

/**
 * @version INTERNAL
 */
public class PropertyPanel extends JPanel
{
  //innner classes
  private class myButton extends JButton
  {
    PropertyEditor pe;
    Object         value;
  } //myButton
  
  private class myCellEditor extends DefaultCellEditor
  {
    public myCellEditor()
    {
      super(new JTextField());
      textBox = (JTextField) getComponent();
    }

    public Object getCellEditorValue()
    {
      if (editorComponent instanceof JComboBox)
      {
        return ((JComboBox) editorComponent).getSelectedItem();
      }
      if (editorComponent instanceof myButton)
      {
        return button.value;
      }
      return super.getCellEditorValue();
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
        boolean isSelected, int row, int column)
    {
      if (isSelected && column == 1)
      {
        if (mProps[row].pe != null)
        {
          PropertyEditor pe = mProps[row].pe;
          if (pe.supportsCustomEditor())
          {
            try
            {
              Method getter = mProps[row].pd.getReadMethod();
              value = getter.invoke(mEditObject, args);
              pe.setValue(value);
              if (pe.getCustomEditor() != null && pe.isPaintable())
              {
                editorComponent = (JComponent) pe.getCustomEditor();
              } else
              {
                button.pe = pe;
                button.setText(mProps[row].pd.getDisplayName());
                editorComponent = button;
              }
              return editorComponent;
            } catch (Exception e)
            {
            }
          } else if (pe.getTags() != null)
          {
            comboRemoveAllItems(comboBox);
            String arr[] = pe.getTags();
            for (int i = 0; i < arr.length; i++)
            {
              comboBox.addItem(arr[i]);
            }
            editorComponent = comboBox;
            return editorComponent;
          }
        }
      }
      editorComponent = textBox;
      Component com = super.getTableCellEditorComponent(table, value,
          isSelected, row, column);
      com.setEnabled(!mProps[row].readonly);
      return com;
    }
  } //myCellEditor
  
  private class myProperty
  {
    boolean            isSet    = false;
    Object             oldValue = null;
    PropertyDescriptor pd;
    PropertyEditor     pe;
    boolean            readonly;
    boolean            userProperty;
    Object             value    = null;

    myProperty(PropertyDescriptor desc)
    {
      pd = desc;
      userProperty = pd.getDisplayName().startsWith("Prop.");
      readonly = (userProperty || pd.getWriteMethod() == null);
      //try to get property editor from the descriptor first.
      Class cls = desc.getPropertyEditorClass();
      if (cls != null)
      {
        try
        {
          pe = (PropertyEditor) cls.newInstance();
        } catch (Exception e)
        {
          //ignore
        }
      }
      //last resort or if no property editor registered with descriptor
      if (pe == null)
      {
        pe = PropertyEditorManager.findEditor(pd.getPropertyType());
      }
    }

    public void set(Object value)
    {
      try
      {
        if (!this.isSet)
        {
          this.oldValue = this.pd.getReadMethod().invoke(mEditObject, args);
          this.isSet = true;
        }
        this.value = value;
        setArgs[0] = value;
        this.pd.getWriteMethod().invoke(mEditObject, setArgs);
      } catch (Exception e)
      {
      }
    }
  } //myProperty
  
  // Overwrite cell renderer to draw disabled cell
  private class PropertyTableCellRenderer extends DefaultTableCellRenderer
  {
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column)
    {
      super.getTableCellRendererComponent(table, value, isSelected, hasFocus,
          row, column);
      if (!isSelected)
      {
        if (column == 1 && mProps[row].readonly)
        {
          setBackground(UIManager.getColor("Label.background"));
        } else
        {
          setBackground(table.getBackground());
        }
      }
      return this;
    }
  }//PropertyTableCellRenderer
  
  public static final String[] columNames =
                                          {
      Res.getString(Res.PROP_PANEL_PROPERTY),
      Res.getString(Res.PROP_PANEL_VALUE) };

  static public void comboRemoveAllItems(JComboBox combo)
  {
    int count = combo.getItemCount();
    if (count > 0)
    {
      combo.removeAllItems();
    }
  }
  
  final Object args[]    = new Object[0];
  myButton     button    = new myButton();
  JComboBox    comboBox  = new JComboBox();
  BeanInfo     mBI;
  Object       mEditObject;
  Frame        mFrame;
  myProperty   mProps[];
  final Object setArgs[] = new Object[1];
  JScrollPane  tablePanel;
  JTable       tableView;
  JTextField   textBox   = new JTextField();

  public PropertyPanel(Frame frame, Object bean, BeanInfo bi)
  {
    try
    {
      int i;
      mFrame = frame;
      mEditObject = bean;
      PropertyDescriptor pds[] = bi.getPropertyDescriptors();
      ArrayList vec = new ArrayList();
      for (i = 0; i < pds.length; i++)
      {
        if (pds[i].getReadMethod() != null)
        {
          vec.add(pds[i]);
        }
      }
      mProps = new myProperty[vec.size()];
      for (i = 0; i < vec.size(); i++)
      {
        mProps[i] = new myProperty((PropertyDescriptor) vec.get(i));
      }
      tablePanel = getPane();
      jbInit();
    } catch (Exception e)
    {
      ErrorHandler.displayError(mFrame, e);
    }
  }

  public void cancel()
  {
    this.close();
    for (int i = 0; i < mProps.length; i++)
    {
      if (mProps[i].isSet)
      {
        mProps[i].set(mProps[i].oldValue);
      }
    }
  }

  public void close()
  {
    if (tableView.isEditing())
    {
      tableView.getCellEditor().stopCellEditing();
    }
  }

  public JScrollPane getPane() throws Exception
  {
    final Object[][] data = new Object[mProps.length][columNames.length];
    final boolean[] canedit = new boolean[mProps.length];
    for (int i = 0; i < mProps.length; i++)
    {
      try
      {
        String displayName = mProps[i].pd.getDisplayName();
        if (mProps[i].userProperty)
        {
          displayName = displayName.substring(displayName.indexOf('.') + 1);
          setArgs[0] = displayName;
          mProps[i].pd.getWriteMethod().invoke(mEditObject, setArgs);
        }
        data[i][0] = displayName;
        data[i][1] = mProps[i].pd.getReadMethod().invoke(mEditObject, args);
        canedit[i] = !(mProps[i].readonly);
      } catch (InvocationTargetException ite)
      {
        //ignore.
        data[i][1] = null;
      }
    }
    final PropertyPanel myPanel = this;
    // Create a model of the data.
    TableModel dataModel = new AbstractTableModel()
    {
      public Class getColumnClass(int c)
      {
        return String.class;
      }

      // These methods always need to be implemented.
      public int getColumnCount()
      {
        return columNames.length;
      }

      // The default implementations of these methods in
      // AbstractTableModel would work, but we can refine them.
      public String getColumnName(int column)
      {
        return columNames[column];
      }

      public int getRowCount()
      {
        return data.length;
      }

      public Object getValueAt(int row, int col)
      {
        return data[row][col];
      }

      public boolean isCellEditable(int row, int col)
      {
        return (col > 0 && canedit[row]);
      }

      public void setValueAt(Object aValue, int row, int column)
      {
        data[row][column] = aValue;
        myPanel.storeCellValue(aValue, row);
      }
    };
    // Create the table
    tableView = new JTable(dataModel);
    tableView.setDefaultRenderer(String.class, new PropertyTableCellRenderer());
    TableColumn colorColumn = tableView.getColumn(Res
        .getString(Res.PROP_PANEL_VALUE));
    colorColumn.setCellEditor(new myCellEditor());
    // Finish setting up the table.
    JScrollPane scrollpane = new JScrollPane(tableView);
    scrollpane.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
    return scrollpane;
  }

  public void jbInit() throws Exception
  {
    this.setLayout(new GridLayout());
    this.add(tablePanel, null);
  }

  private void storeCellValue(Object value, int row)
  {
    try
    {
      if (mProps[row].pe != null)
      {
        PropertyEditor pe = mProps[row].pe;
        if (pe.supportsCustomEditor())
        {
          if (!pe.isPaintable())
          {
            pe.setValue(button.value);
          }
        } else if (pe.getTags() != null)
        {
          pe.setAsText((String) comboBox.getSelectedItem());
        } else
        {
          pe.setAsText(textBox.getText());
        }
        value = pe.getValue();
      }
      //if no editor, let the value be what's passed in.
      mProps[row].set(value);
    } catch (Exception e)
    {
      ErrorHandler.displayError(mFrame, e);
    }
  }

  void dump()
  {
    DebugDiagnostic.println("*** Changed Properties ***");
    for (int i = 0; i < mProps.length; i++)
    {
      if (mProps[i].value != null)
      {
        DebugDiagnostic.println(mProps[i].pd.getDisplayName() + ":"
            + mProps[i].value);
        DebugDiagnostic.println(mProps[i].pd.getDisplayName() + ":"
            + mProps[i].pe.getAsText());
      }
    }
  }
}
