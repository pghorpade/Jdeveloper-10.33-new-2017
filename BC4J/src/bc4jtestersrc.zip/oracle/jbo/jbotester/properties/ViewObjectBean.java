/*
 * @(#)ViewObjectBean.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import com.sun.java.util.collections.ArrayList;
import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.util.Enumeration;
import java.util.Hashtable;
import oracle.jbo.ViewObject;

public class ViewObjectBean
{
   private ViewObject mViewObject = null;
   private boolean isfetched;
   protected String hintName;

   public ViewObjectBean(ViewObject viewObject, boolean fetched)
   {
      mViewObject = viewObject;
      isfetched = fetched;
   }

   /**
    * Retrieve the class name.
    * @return name of the class
    */
   public String getDefName()
   {
     return mViewObject.getDefName();
   }

   public String getDefFullName()
   {
     return mViewObject.getDefFullName();
   }

   public String getName()
   {
     return mViewObject.getName();
   }

   public String getFullName()
   {
      return mViewObject.getFullName();
   }

/*********
   public void setActive(boolean state)
   {
      mViewObject.setActive(state);
   }

   public boolean isActive()
   {
      return mViewObject.isActive();
   }
*********/

   public int getFetchedRowCount()
   {
      return mViewObject.getFetchedRowCount();
   }

   public long getEstimatedRowCount()
   {
      // We do not want to call GetRowCount() because that fetches every single
      // row from database. For differences between getRowCount() and
      // getEstimatedRowCount() see JBO product documentation.
      return mViewObject.getEstimatedRowCount();
   }

   public int getCurrentRowIndex()
   {
      return mViewObject.getCurrentRowIndex();
   }

   public String getCurrentRowSlot()
   {
      switch (mViewObject.getCurrentRowSlot())
      {
         case ViewObject.SLOT_VALID:
            return new String("SLOT_VALID");

         case ViewObject.SLOT_DELETED:
            return new String("SLOT_DELETED");

         case ViewObject.SLOT_BEFORE_FIRST:
            return new String("SLOT_BEFORE_FIRST");

         case ViewObject.SLOT_BEYOND_LAST:
            return new String("SLOT_BEYOND_LAST");
      }

      return "???";
   }

   public void setRangeSize(int size)
   {
      mViewObject.setRangeSize(size);
   }

   public int getRangeSize()
   {
      return mViewObject.getRangeSize();
   }

   public int getRangeStart()
   {
      return mViewObject.getRangeStart();
   }

   public void setRangeStart(int start)
   {
      mViewObject.setRangeStart(start);
   }

   public int getRowCountInRange()
   {
      return mViewObject.getRowCountInRange();
   }

   public boolean isRangeAtBottom()
   {
      return mViewObject.isRangeAtBottom();
   }

   public boolean isRangeAtTop()
   {
      return mViewObject.isRangeAtTop();
   }

   public int getAttributeCount()
   {
      return mViewObject.getAttributeCount();
   }

   public boolean isForwardOnly()
   {
      return mViewObject.isForwardOnly();
   }

   // public int getMaxSize()
   // {
   //    return mViewObject.getMaxSize();
   // }

   public boolean isReadOnly()
   {
      return mViewObject.isReadOnly();
   }

   public Object getProperty()
   {
      Object obj = mViewObject.getProperty(hintName);

      if (obj instanceof String)
      {
         return (String) obj;
      }
      else
      {
         try
         {
            return obj.toString();
         }
         catch (Throwable t)
         {
            return "?";
         }
      }
   }

   public void setProperty(Object name)
   {
      // Since the user properties are readonly, use the setproperty to pass the hintName
      hintName = (String) name;
   }

   public BeanInfo getBeanInfo()
   {
      Class thisClass = this.getClass();
      try
      {
         ArrayList properties = new ArrayList();

         properties.add(new PropertyDescriptor("ComponentObject.Name", thisClass, "getName", null));
         properties.add(new PropertyDescriptor("ComponentObject.FullName", thisClass, "getFullName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefName", thisClass, "getDefName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefFullName", thisClass, "getDefFullName", null));
         if (isfetched)
         {
            properties.add(new PropertyDescriptor("RowIterator.FetchedRowCount", thisClass, "getFetchedRowCount", null));
            properties.add(new PropertyDescriptor("RowIterator.CurrentRowIndex", thisClass, "getCurrentRowIndex", null));
            properties.add(new PropertyDescriptor("RowIterator.CurrentRowSlot", thisClass, "getCurrentRowSlot", null));
            properties.add(new PropertyDescriptor("RowIterator.RangeSize", thisClass, "getRangeSize", "setRangeSize"));
            properties.add(new PropertyDescriptor("RowIterator.RangeStart", thisClass, "getRangeStart", "setRangeStart"));
            properties.add(new PropertyDescriptor("RowIterator.RowCountInRange", thisClass, "getRowCountInRange", null));
            properties.add(new PropertyDescriptor("RowIterator.isRangeAtBottom", thisClass, "isRangeAtBottom", null));
            properties.add(new PropertyDescriptor("RowIterator.isRangeAtTop", thisClass, "isRangeAtTop", null));
         }
         properties.add(new PropertyDescriptor("StructureDef.AttributeCount", thisClass, "getAttributeCount", null));
         if (isfetched)
         {
            properties.add(new PropertyDescriptor("Rowset.EstimatedRowCount", thisClass, "getEstimatedRowCount", null));
         }
         properties.add(new PropertyDescriptor("Rowset.isForwardOnly", thisClass, "isForwardOnly", null));
         properties.add(new PropertyDescriptor("ViewObject.isReadOnly", thisClass, "isReadOnly", null));

         Hashtable props = mViewObject.getProperties();
         if (props != null)
         {
            for (Enumeration enumKeys = props.keys(); enumKeys.hasMoreElements(); )
            {
               Object key = enumKeys.nextElement();

               properties.add(new PropertyDescriptor("Prop." + key.toString(), thisClass, "getProperty", "setProperty"));
            }
         }

         PropertyDescriptor[] list = (PropertyDescriptor[]) properties.toArray(new PropertyDescriptor[properties.size()]);

         return new TesterBeanInfo(thisClass, list);
      }
      catch (Exception e)
      {
         e.printStackTrace();
         return new TesterBeanInfo(thisClass, new PropertyDescriptor[0]);
      }
   }

}

