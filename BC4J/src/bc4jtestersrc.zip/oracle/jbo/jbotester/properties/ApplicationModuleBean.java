/*
 * @(#)ApplicationModuleBean.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.properties;

import com.sun.java.util.collections.ArrayList;
import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.util.Enumeration;
import java.util.Hashtable;
import oracle.jbo.ApplicationModule;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.common.DiagnosticFactory;
import oracle.jbo.jbotester.properties.BaseEnumEditor;

public class ApplicationModuleBean
{
   private ApplicationModule mAppModule = null;
   protected String hintName;

   public ApplicationModuleBean(ApplicationModule appModule)
   {
      mAppModule = appModule;
   }

   /**
    * Gets the version as major.minor.patch.bldNum
    *
    * @return The version.
    */
   public String getVersion()
   {
      return mAppModule.getSession().getVersion();
   }

   /**
    * Retrieve the class name.
    * @return name of the class
    */
   public String getDefName()
   {
     return mAppModule.getDefName();
   }

   public String getDefFullName()
   {
     return mAppModule.getDefFullName();
   }

   /**
    * Retrieve the name of the particular instance of an object (instance name)
    * @return name of the object
    */
   public String getName()
   {
     return mAppModule.getName();
   }

   public String getFullName()
   {
      return mAppModule.getFullName();
   }

   public void setLockingMode(int mode)
   {
      mAppModule.getTransaction().setLockingMode(mode);
   }

   public int getLockingMode()
   {
      return mAppModule.getTransaction().getLockingMode();
   }

   public void setSyncMode(int mode)
   {
      mAppModule.setSyncMode(mode);
   }

   public int getSyncMode()
   {
      return mAppModule.getSyncMode();
   }

   public boolean isDirty()
   {
      return mAppModule.getTransaction().isDirty();
   }

   public String getLocale()
   {
      return mAppModule.getSession().getLocale().toString();
   }

   public String getDebugOutput()
   {
      String output = DiagnosticFactory.getProperty(DiagnosticFactory.PN_DEBUG_TYPE);

      if (output == null)
      {
         return "";
      }

      return output;
  }

   public void setDebugOutput(String output)
   {
      DiagnosticFactory.setProperty(DiagnosticFactory.PN_DEBUG_TYPE, output);
      Diagnostic.init("Tester: debug output changed");
   }

   public int getDebugThreshold()
   {
      String threshold = DiagnosticFactory.getProperty(DiagnosticFactory.PN_TRACE_THRESHOLD);

      if (threshold == null)
      {
         return -1;
      }

      return Integer.parseInt(threshold);
   }

   public void setDebugThreshold(int threshold)
   {
      DiagnosticFactory.setProperty(DiagnosticFactory.PN_TRACE_THRESHOLD, new Integer(threshold).toString());
      Diagnostic.init("Tester: threshold changed");
   }

   public String getShowFunction()
   {
      String show =  DiagnosticFactory.getProperty(DiagnosticFactory.PN_SHOW_FUNCTION);

      if (show == null)
      {
         return "false";
      }

      return show;
   }

   public void setShowFunction(String show)
   {
      DiagnosticFactory.setProperty(DiagnosticFactory.PN_SHOW_FUNCTION, show);
      Diagnostic.init("Tester: showfunction changed");
   }

   public Object getProperty()
   {
      Object obj = mAppModule.getProperty(hintName);

      if (obj instanceof String)
      {
         return obj;
      }
      else
      {
         try
         {
            return obj.toString();
         }
         catch (Throwable t)
         {
            return "?";
         }
      }
   }

   public void setProperty(Object name)
   {
      // Since the user properties are readonly, use the setproperty to pass the hintName
      hintName = (String) name;
   }

   public BeanInfo getBeanInfo()
   {
      Class thisClass = this.getClass();
      try
      {
         PropertyDescriptor pd ;
         ArrayList properties = new ArrayList();

         properties.add(new PropertyDescriptor("ComponentObject.Name", thisClass, "getName", null));
         properties.add( new PropertyDescriptor("ComponentObject.FullName", thisClass, "getFullName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefName", thisClass, "getDefName", null));
         properties.add(new PropertyDescriptor("ComponentObject.DefFullName", thisClass, "getDefFullName", null));
         properties.add(new PropertyDescriptor("Session.Version", thisClass, "getVersion", null));
         properties.add(new PropertyDescriptor("Session.Locale", thisClass, "getLocale", null));

         pd = new PropertyDescriptor("Transaction.LockMode", thisClass, "getLockingMode", "setLockingMode");
         pd.setPropertyEditorClass(LockModeEditor.class);
         properties.add(pd);
         properties.add(new PropertyDescriptor("Transaction.isDirty", thisClass, "isDirty", null));

         pd = new PropertyDescriptor("ApplicationModule.SyncMode", thisClass, "getSyncMode", "setSyncMode");
         pd.setPropertyEditorClass(SyncModeEditor.class);
         properties.add(pd);

         pd = new PropertyDescriptor("jbo.debugoutput", thisClass, "getDebugOutput", "setDebugOutput");
         properties.add(pd);

         pd = new PropertyDescriptor("jbo.logging.trace.threshold", thisClass, "getDebugThreshold", "setDebugThreshold");
         properties.add(pd);

         pd = new PropertyDescriptor("jbo.logging.show.function", thisClass, "getShowFunction", "setShowFunction");
         properties.add(pd);

         Hashtable props = mAppModule.getProperties();
         if (props != null)
         {
            for (Enumeration enumKeys = props.keys(); enumKeys.hasMoreElements(); )
            {
               Object key = enumKeys.nextElement();

               properties.add(new PropertyDescriptor("Prop." + key.toString(), thisClass, "getProperty", "setProperty"));
            }
         }

         PropertyDescriptor[] list = (PropertyDescriptor[]) properties.toArray(new PropertyDescriptor[properties.size()]);

         return new TesterBeanInfo(thisClass, list);
      }
      catch (Exception e)
      {
         e.printStackTrace();
         return new TesterBeanInfo(thisClass, new PropertyDescriptor[0]);
      }

   }

}

class LockModeEditor extends BaseEnumEditor
{
   private final String[] tags = { "0 - LOCKING_NONE",       // 0
                                   "1 - LOCK_PESSIMISTIC",   // 1
                                   "2 - LOCK_OPTIMISTIC"     // 2
                                  };

   protected String getEnumName()
   {
      return "Locking Mode";
   }

   //abstract method needs to be overwritten
   public String[] getTags()
   {
      return tags;
   }
}

class SyncModeEditor extends BaseEnumEditor
{
   private final String[] tags = { "0 - SYNC_LAZY",
                                   "1 - SYNC_IMMEDIATE"
                                  };

   protected String getEnumName()
   {
      return "Locking Mode";
   }

   //abstract method needs to be overwritten
   public String[] getTags()
   {
      return tags;
   }
}



