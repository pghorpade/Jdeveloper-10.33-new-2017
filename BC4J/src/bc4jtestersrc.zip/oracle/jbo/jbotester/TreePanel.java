/*
 * @(#)TreePanel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import oracle.jbo.DeleteEvent;
import oracle.jbo.InsertEvent;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.common.DebugDiagnostic;

public final class TreePanel extends JScrollPane implements JBOControl
{
   private final JTree              tree;
   private JBOTreeModel             model;
   private String                   accessor;
   private RowSetPanel              rowSetPanel;
   private RowSetIterator           iter;

   public TreePanel(MainFrame parent)
   {
      super();

      tree = new JTree(new DefaultMutableTreeNode(Res.getString(Res.TREE_PANEL_EMPTY_NODE)));
      tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
      tree.setLargeModel(true);
      tree.addTreeExpansionListener(new JBOTreeExpansionListener());
      tree.addTreeSelectionListener(new JBOTreeSelectionListener());

      setViewportView(tree);
   }

   public void setRowSetPanel(RowSetPanel rsPanel)
   {
      rowSetPanel = rsPanel;
   }

   public void setAccessorName(String attrName)
   {
      accessor = attrName;
   }

   public void setIterator(RowSetIterator iterator)
   {
      if (iter == iterator)
      {
         return;
      }

      if (iter != null)
      {
         iter.removeListener(this);
      }

      iter = iterator;
      if (iter == null)
      {
         return;
      }

      if (iter.getRowSet().getViewObject().isReadOnly())
      {
         DebugDiagnostic.println("RowSetPanel.setRowSet(): ***** RS is Read Only! *****");
      }

      iter.addListener(this);

      changeModelTo(iter.getCurrentRow());
   }

   public RowSetIterator getIterator()
   {
      return iter;
   }

   // RowsetListener
   public void rangeRefreshed(RangeRefreshEvent event)
   {
   }

   public void rangeScrolled(ScrollEvent event)
   {
   }

   public void rowUpdated(UpdateEvent event)
   {
   }

   public void navigated(NavigationEvent event)
   {
      changeModelTo(event.getRow());
   }

   public void rowDeleted(DeleteEvent event)
   {
   }

   public void rowInserted(InsertEvent event)
   {
   }

   private void changeModelTo(Row row)
   {
      model = new JBOTreeModel(row, accessor);
      tree.setModel(model);
      // Expand first level
      TreePath first = tree.getPathForRow(0);
      if (((JBOTreeNode)first.getLastPathComponent()).getAllowsChildren())
      {
         tree.fireTreeExpanded(first);
      }
      // Select first item.
      tree.setSelectionPath(first);
   }

   private final class JBOTreeExpansionListener implements TreeExpansionListener
   {
      // Expansion listener
      public void treeExpanded(TreeExpansionEvent e)
      {
         JBOTreeNode node = (JBOTreeNode) e.getPath().getLastPathComponent();

         if (node.expand())
         {
            int countChildren = node.getChildCount();
            int[] newIdx = new int[countChildren];

            // Model listen to all rowsets.
//$$$not yet            node.getChildren().addListener(this);

            for (int i = 0; i < countChildren; i++)
            {
               newIdx[i] = i;
            }
            model.nodesWereInserted(node, newIdx);
         }
      }

      public void treeCollapsed(TreeExpansionEvent e)
      {
      }
   }

   private final class JBOTreeSelectionListener implements TreeSelectionListener
   {
      public void valueChanged(TreeSelectionEvent e)
      {
         if (rowSetPanel != null)
         {
            MutableTreeNode node = (MutableTreeNode) e.getPath().getLastPathComponent();

            if (node instanceof JBOTreeNode)
            {
               rowSetPanel.refreshAll(((JBOTreeNode) node).getRow());
            }
         }
      }
   }
}
