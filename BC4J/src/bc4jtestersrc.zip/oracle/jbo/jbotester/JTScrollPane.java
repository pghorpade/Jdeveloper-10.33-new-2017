/*
 * @(#)JTScrollPane.java
 *
 * Copyright 2005 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
 
package oracle.jbo.jbotester;

import java.awt.Component;

import javax.swing.JScrollPane;

public class JTScrollPane extends JScrollPane
{
  private final static int DEFAULT_WHEEL_SCROLL_RATIO = 10;
  /**
   * @param view the view that should be displayed on the scroll pane
   */
  public JTScrollPane(Component view)
  {
    super(view);
    /*
     * rvgrins 06/06/2005 bug-3157984
     * Introducing the default scroll ratio to ensure that tester panels
     * get a reasonable default scroll ratio
     */
    this.getVerticalScrollBar().setUnitIncrement(DEFAULT_WHEEL_SCROLL_RATIO);
  }
}