/*
 * @(#)MDForm.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;

public final class MDForm extends SimpleForm
{
   private final NavBar detailToolBar;
   private final JPanel detailPanel = new JPanel();
   final JTable detailTable = new JTable();

   private final JScrollPane detailScroll = new JScrollPane(detailTable);
   private final JSplitPane  splitter = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

   public MDForm(MainFrame frame, ObjTreeNode objNode)
   {
      this(frame, objNode, null, null);
   }

   public MDForm(MainFrame frame, ObjTreeNode objNode, ViewObject masterVO, ViewObject detailVO)
   {
      super(frame, objNode, masterVO);
      
      detailTable.getTableHeader().addMouseListener(new MouseListener()
      {
        public void mouseClicked(MouseEvent e){}
        public void mouseEntered(MouseEvent e){}
        public void mouseExited(MouseEvent e){}
        public void mousePressed(MouseEvent e)
        {
          if(detailTable.getCellEditor()!=null)
          {
            detailTable.getCellEditor().stopCellEditing();
          }
        }
        public void mouseReleased(MouseEvent e){}
      });

      // Remove the scroll panel from the SimpleForm to put it in the splitter
      remove(scroller);
      scroller.setBorder(BorderFactory.createEmptyBorder());
      add(splitter, BorderLayout.CENTER);
      splitter.setTopComponent(scroller);

      detailTable.setPreferredScrollableViewportSize(new Dimension(400, 100));
      detailPanel.setLayout(new BorderLayout());
      detailPanel.setBorder(BorderFactory.createEmptyBorder());

      detailToolBar = new NavBar(frame, true);
      detailScroll.setBorder(BorderFactory.createEmptyBorder());
      detailPanel.add(detailToolBar, BorderLayout.NORTH);
      detailPanel.add(detailScroll, BorderLayout.CENTER);

      splitter.setBottomComponent(detailPanel);
      splitter.setResizeWeight(0.5);
      setDetailRowSetIterator(detailVO);
   }

   public void setDetailRowSetIterator(RowSetIterator detail)
   {
      detailToolBar.setIterator(detail);
      if (detail != null)
      {
         detailToolBar.setMyParent(this);
         new JBOTableModel(getMainFrame(), detailTable, detailScroll, detail);
      }
      else if (detailTable != null)
      {
         ((JBOTableModel) detailTable.getModel()).setIterator(null);
      }
   }

   public RowSetIterator getDetailRowSetIterator()
   {
      if (detailTable != null)
      {
         return ((JBOTableModel) detailTable.getModel()).getIterator();
      }
      
      return null;
   }

}





