/*
 * @(#)VLDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewLink;
import oracle.jbo.ViewObject;

public final class VLDialog extends GenericDialog
{
   static final int FROM_VIEW_LINK_DEF    = 0;
   static final int FROM_ENTITY_ASSOC_DEF = 1;

   private final ApplicationModule  mAppModule;
   private final CardLayout         cardLayout;
   private final JPanel             controlPanel;

   private final JComboBox vlTypeCombo = new JComboBox(new String[]{ Res.getString(Res.VL_DIALOG_VL_DEF),
                                                                     Res.getString(Res.VL_DIALOG_EA_DEF) } );

   private final JComboBox  masCombo = new JComboBox();
   private final JComboBox  detCombo = new JComboBox();
   private final JComboBox  masCombo1 = new JComboBox();
   private final JComboBox  detCombo1 = new JComboBox();

   private final JTextField vlField  = new JTextField();
   private final JTextField vlField1  = new JTextField();

   private final JComboBox  vldCombo  = new JComboBox();
   private final JComboBox  eadCombo  = new JComboBox();

   private ViewLink mViewLink;
   
   private String viewLinkName;
   private ViewObject masterViewObject;
   private ViewObject detailViewObject;

   public VLDialog(MainFrame frame, ApplicationModule appMod)
   {
      super(frame, Res.getString(Res.VL_DIALOG_TITLE), new JPanel(new CardLayout()), OK_CANCEL_HELP_OPTION, Res.getString(Res.DIALOG_CREATE_BUTTON));

      mAppModule = appMod;

      setHelpLocation("f1_bcbctcreatevl_html");

      vlTypeCombo.addActionListener(new ActionListener()
                                    {
                                       public void actionPerformed(ActionEvent e)
                                       {
                                          vlTypeCombo_actionPerformed(e);
                                       }
                                    });

      
      vldCombo.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          vldCombo_actionPerformed(e);
        }
      }
      );
      
      JLabel vlType = JboTesterUtil.createLabel(Res.VL_DIALOG_CREATION_TYPE, vlTypeCombo);
      
      GridBagLayout gbl      = new GridBagLayout();
      JPanel vlTypePanel     = new JPanel(gbl);
      GridBagConstraints gbc = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(10, 5, 5, 5);
      gbl.setConstraints(vlType, gbc);
      vlTypePanel.add(vlType);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(vlTypeCombo, gbc);
      vlTypePanel.add(vlTypeCombo);

      getContentPane().add(vlTypePanel, BorderLayout.NORTH);

      controlPanel = getMainPanel();
      controlPanel.setBorder(BorderFactory.createCompoundBorder(
                              BorderFactory.createEmptyBorder(5, 5, 5, 5),
                              new SoftBevelBorder(BevelBorder.LOWERED)));
      cardLayout = (CardLayout) controlPanel.getLayout();

      controlPanel.add(createVLPanel(),  Integer.toString(FROM_VIEW_LINK_DEF));
      controlPanel.add(createEAPanel(),  Integer.toString(FROM_ENTITY_ASSOC_DEF));

     initViewObjectCombos();
     initViewLinkDefCombo();
     initEntityAssocDefCombo();
   }

   void vlTypeCombo_actionPerformed(ActionEvent e)
   {
      cardLayout.show(controlPanel, Integer.toString(vlTypeCombo.getSelectedIndex()));
   }

   private JPanel createVLPanel()
   {
      GridBagLayout gbl      = new GridBagLayout();
      JPanel vlPanel         = new JPanel(gbl);
      GridBagConstraints gbc = new GridBagConstraints();
      JLabel vlName1         = JboTesterUtil.createLabel(Res.VL_DIALOG_VL_NAME, vlField);
      JLabel vldName         = JboTesterUtil.createLabel(Res.VL_DIALOG_DEFINITION, vldCombo);
      JLabel masVOName       = JboTesterUtil.createLabel(Res.VL_DIALOG_MASTER_VO, masCombo);
      JLabel detVOName       = JboTesterUtil.createLabel(Res.VL_DIALOG_DETAIL_VO, detCombo);

      vlPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

      JboTesterUtil.removeKeyBindingCompatibility(vlField);
      setInitialFocusComponent(vlField);

      int ypos = 1;

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(5, 5, 5, 5);
      gbl.setConstraints(vlName1, gbc);
      vlPanel.add(vlName1);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(vlField, gbc);
      vlPanel.add(vlField);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(vldName, gbc);
      vlPanel.add(vldName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(vldCombo, gbc);
      vlPanel.add(vldCombo);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(masVOName, gbc);
      vlPanel.add(masVOName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(masCombo, gbc);
      vlPanel.add(masCombo);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(detVOName, gbc);
      vlPanel.add(detVOName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(detCombo, gbc);
      vlPanel.add(detCombo);

      return vlPanel;
   }

   private JPanel createEAPanel()
   {
      GridBagLayout gbl       = new GridBagLayout();
      JPanel eaPanel          = new JPanel(gbl);
      GridBagConstraints gbc  = new GridBagConstraints();
      JLabel vlName2          = JboTesterUtil.createLabel(Res.VL_DIALOG_VL_NAME, vlField1);
      JLabel eadName          = JboTesterUtil.createLabel(Res.VL_DIALOG_ENTITY_ASSOC, eadCombo);
      JLabel masVOName1       = JboTesterUtil.createLabel(Res.VL_DIALOG_MASTER_VO, masCombo1);
      JLabel detVOName1       = JboTesterUtil.createLabel(Res.VL_DIALOG_DETAIL_VO, detCombo1);

      eaPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

      JboTesterUtil.removeKeyBindingCompatibility(vlField1);

      int ypos = 1;

      gbc.fill = GridBagConstraints.HORIZONTAL;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbc.insets = new Insets(5, 5, 5, 5);
      gbl.setConstraints(vlName2, gbc);
      eaPanel.add(vlName2);

      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(vlField1, gbc);
      eaPanel.add(vlField1);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(eadName, gbc);
      eaPanel.add(eadName);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(eadCombo, gbc);
      eaPanel.add(eadCombo);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(masVOName1, gbc);
      eaPanel.add(masVOName1);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos++;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(masCombo1, gbc);
      eaPanel.add(masCombo1);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;
      gbc.gridy = GridBagConstraints.RELATIVE;
      gbc.weightx = 0.0;
      gbc.gridwidth = 1;
      gbl.setConstraints(detVOName1, gbc);
      eaPanel.add(detVOName1);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = GridBagConstraints.RELATIVE;
      gbc.gridy = ypos;
      gbc.weightx = 1.0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbl.setConstraints(detCombo1, gbc);
      eaPanel.add(detCombo1);

      return eaPanel;
   }

   void createViewLink()
   {
      try
      {
         boolean exit = true;

         switch (vlTypeCombo.getSelectedIndex())
         {
            case FROM_VIEW_LINK_DEF:
               exit = createVLFromDef();
               break;

            case FROM_ENTITY_ASSOC_DEF:
               exit = createVLFromEADef();
               break;
         }

         if (exit)
         {
            close();
         }
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(parent, e);
      }
   }

  private boolean checkString(String string, int resID)
  {
    if(string==null||string.length()<=0)
    {
      ErrorHandler.displayError(parent, Res.getString(resID));
      return false;      
    }
    return true;
  }

  private boolean readFields(JTextField textField, JComboBox masterCombo, JComboBox detailCombo)
  {
    viewLinkName = textField.getText();
    String masterVO = (String)masterCombo.getSelectedItem();
    String detailVO = (String)detailCombo.getSelectedItem();

    if(checkString(viewLinkName,Res.VL_DIALOG_VL_NAME_ERROR) &&
       checkString(masterVO,Res.VL_DIALOG_MASTER_VO_NAME_ERROR) &&
       checkString(detailVO,Res.VL_DIALOG_DETAIL_VO_NAME_ERROR)
    )
    {
      masterViewObject = mAppModule.findViewObject(masterVO);
      detailViewObject = mAppModule.findViewObject(detailVO);
      return true;
    }
    return false;
  }

   private boolean createVLFromDef()
   {
      if(readFields(vlField,masCombo,detCombo))
      {
        String viewLinkDefName = (String)vldCombo.getSelectedItem();
        if(checkString(viewLinkDefName,Res.VL_DIALOG_VL_DEFINITION_ERROR))
        {     
          mViewLink = mAppModule.createViewLink(viewLinkName,
                                                         viewLinkDefName,
                                                         masterViewObject,
                                                         detailViewObject);
  
          return true;
        }
      }
      return false;
   }

   private boolean createVLFromEADef()
   {
    if(readFields(vlField1,masCombo1,detCombo1))
    {
      String eaDefName = (String)eadCombo.getSelectedItem();
      if(checkString(eaDefName,Res.VL_DIALOG_ENTITY_ASSOC_ERROR))
      {
        mViewLink = mAppModule.createViewLinkFromEntityAssocName(viewLinkName,
                                                                 eaDefName,
                                                                 masterViewObject,
                                                                 detailViewObject);
  
        return true;
      }
    }
    return false;
   }

   public ViewLink getViewLink()
   {
      return mViewLink;
   }
   
  private void initCombo(JComboBox combo, String[] items)
  {
    if((items!=null && items.length>0))
    {
      for(int i=0;i<items.length;i++)
      {
        combo.addItem(items[i]);
      }
    }
  }

  private void initViewLinkDefCombo()
  {
    initCombo(vldCombo,mAppModule.getSession().getAllViewLinkDefNames());
  }

  private void initEntityAssocDefCombo()
  {
    initCombo(eadCombo,mAppModule.getSession().getAllEntityAssociationDefNames());
  }

  private void initViewObjectCombos()
  {
    String voNames[] = mAppModule.getViewObjectNames();
    initCombo(masCombo,voNames);
    initCombo(masCombo1,voNames);
    initCombo(detCombo,voNames);
    initCombo(detCombo1,voNames);
  }
      
  private void vldCombo_actionPerformed(ActionEvent e)
  {
   try
   {
     String vld = vldCombo.getSelectedItem().toString();
     String[] vls = mAppModule.getViewLinkNames();
     for(int i=0;i<vls.length;i++)
     {
       ViewLink vl = mAppModule.findViewLink(vls[i]);
       if(vld.equals(vl.getDefFullName()))
       {
         ViewObject src = vl.getSource();
         ViewObject dest = vl.getDestination();
         String master = src.getName();
         String detail = dest.getName();
         masCombo.setSelectedItem(master);
         detCombo.setSelectedItem(detail);
         break;
       }
     }
   }
   catch (Exception ex)
   {
     //well, we tried to be nice and set defaults...
   }
  }

   public void actionPerformed(ActionEvent event)
   {
      String cmd = event.getActionCommand();

      if (cmd.equals(OK_ACTION))
      {
         createViewLink();
      }
      else
      {
         super.actionPerformed(event);
      }
   }
}
