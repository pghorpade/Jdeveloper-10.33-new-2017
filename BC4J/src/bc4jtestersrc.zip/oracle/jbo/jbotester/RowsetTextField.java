/*
 * @(#)RowsetTextField.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.event.KeyEvent;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.Keymap;
import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;

public final class RowsetTextField extends JTextField implements JBOField
{
   private final JBOFieldHelper jboField;
   private final LocaleContext locale;

   public RowsetTextField(int col, AttributeDef attDef, LocaleContext locale)
   {
      super(col);
      
      jboField = new JBOFieldHelper(attDef, this);
      this.locale = locale;

      addActionListener(JBOFieldHelper.UpdateActionListener);
      
      // Map the "Esc" ket to a cancel action
      KeyStroke cancel = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
      Keymap map =  getKeymap();
      if (map.getAction(cancel) != JBOFieldHelper.CancelAction)
      {
         map.addActionForKeyStroke(cancel, JBOFieldHelper.CancelAction);
      }

      jboField.init();
   }

   //
   // JBOField implementation
   //
   public JComponent getJComponent()
   {
      return this;
   }

   public LocaleContext getLocaleContext()
   {
      return locale;
   }
   
   public Object getControlValue()
   {
      return getText();
   }

   public void setControlValue(Object value)
   {
      setText((value != null) ? value.toString() : "");
   }

   public void setRow(Row newRowBinding, RowSetIterator iter)
   {
 //     if(newRowBinding!=null && !newRowBinding.isDead())
 //     {
        jboField.setRow(newRowBinding, iter);
 //     }
 //     else 
 //     {
 //       jboField.setRow(null,iter);    
 //     }
   }

   public AttributeDef getAttributeDef()
   {
      return jboField.getAttributeDef();
   }
   
   public Object getDataValue()
   {
      return jboField.getDataValue();
   }

   public boolean setDataValue(Object value)
   {
      return jboField.setDataValue(value);
   }

   public boolean applyEdit()
   {
      return jboField.applyEdit();
   }

   public boolean applyEditAndValidate()
   {
      return jboField.applyEditAndValidate();
   }

   public void refresh()
   {
      jboField.refresh();
   }
}





