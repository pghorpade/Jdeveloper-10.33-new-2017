/*
 * @(#)VariableDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */
package oracle.jbo.jbotester;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.Variable;
import oracle.jbo.VariableValueManager;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.NullValue;
import javax.swing.BoxLayout;
import oracle.jbo.format.Formatter;

public class VariableDialog extends GenericDialog
{
    /**
   * This class holds the variables as displayed in the JList
   */
    private class BindVariable {
        private Variable variable;
        private String label;

        public BindVariable(Variable variable, LocaleContext locale) {
            this.variable = variable;

            AttributeHints UIHelper = variable.getUIHelper();
            if (UIHelper == null ||
                (this.label = UIHelper.getLabel(locale)) == null) {
                label = variable.getName();
            }
        }

        public String getName() {
            return this.variable.getName();
        }

        /**
       * get a label to display for the variable (called by JList)
       * if no label is defined for the variable, the name is used
       * @return the label
       */
        public String toString() {
            return this.label;
        }
    }

  private JPanel               detailPanel;
  private GridBagConstraints   gbc;
  private HashMap              mTmpVarValues    = new HashMap(4);
  private JTextField           mVarDefaultField = new JTextField();
  private VariableValueManager mVariableManager = null;
  private JList                mVarList;
  private String               mVarName         = null;
  private JTextField           mVarNameField    = new JTextField();
  private JTextField           mVarTypeField    = new JTextField();
  private JTextField           mVarValueField   = new JTextField();
  private ViewObject           mViewObject      = null;
  private LocaleContext        mLocale          = null;
  private boolean              canClose         = true;

  private int minLength = 23; //makes the entire window large enough to show the buttons

  public VariableDialog(MainFrame frame, ViewObject vo)
  {
    super(frame, Res.getString(Res.LABEL_BIND_VARIABLES),new JPanel(),OK_CANCEL_HELP_OPTION);
    mViewObject = vo;
    mLocale = vo.getRowSet().getApplicationModule().getSession().getLocaleContext();
    mVariableManager = mViewObject.getVariableManager();
    try
    {
      jbInit();
    } catch (Exception e)
    {
      ErrorHandler.displayError(parent, e);
    }
    setHelpLocation("f1_bcbbindvariables_html");
  }

  protected void cancel()
  {
    canClose = true;
  }

  public void close()
  {
    if(canClose){
      super.close();
    }
  }

  protected void save()
  {
    canClose = true;
    updateTmpVarValue();
    Iterator keys = mTmpVarValues.keySet().iterator();
    try
    {
    while (keys.hasNext())
    {
      String varName = (String) keys.next();
      Variable var = mVariableManager.findVariable(varName);
      if(var!=null && var.getUpdateableFlag()!=AttributeDef.READONLY){
        Object varValue = mTmpVarValues.get(varName);
        mViewObject.setNamedWhereClauseParam(varName, varValue);
        // JRS Must set the variable value on the VO level variable
        // manager to preserve it.  The above will only set the variable
        // value on the RowSet level variable manager.  Cannot access
        // the RowSet variable manager from the client tier.
        mVariableManager.setVariableValue(varName, varValue);
      }
    }
    mViewObject.executeQuery();
    }
    catch (Throwable e)
    {
      //bug-4438632 remove this once the DT part has been fixed...
      canClose = false;
      ErrorHandler.displayError(parent, e);
    }
  }

  private JPanel buildDetailPanel()
  {
    detailPanel = new JPanel(new GridBagLayout());
    detailPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory
        .createLineBorder(Color.BLACK), Res
        .getString(Res.VARIABLE_DIALOG_DETAIL_TITLE)));
    gbc = new GridBagConstraints();
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.insets = new Insets(0, 0, 5, 5);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1.0;
    this.createField(mVarNameField, Res.VARIABLE_DIALOG_NAME);
    this.createField(mVarTypeField, Res.VARIABLE_DIALOG_TYPE);
    this.createField(mVarDefaultField, Res.VARIABLE_DIALOG_DEFAULT);
    this.createField(mVarValueField, Res.VARIABLE_DIALOG_VALUE);
    mVarValueField.setEditable(true);
    mVarValueField.setFocusable(true);
    final VariableDialog dialog = this;
    mVarValueField.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ev)
      {
        updateTmpVarValue();
        dialog.actionPerformed(new ActionEvent(ev.getSource(),ev.getID(),dialog.OK_ACTION));
      }
    });
    mVarValueField.addFocusListener(new FocusAdapter(){
      public void focusLost(FocusEvent f){
        if(mVarName != null) {
          Variable var = mVariableManager.findVariable(mVarName);
          setText(var,mVarValueField,mVarValueField.getText());
        }
      }
    });
    return detailPanel;
  }

  private JPanel buildMasterPanel()
  {
    JPanel masterPanel = new JPanel(new GridBagLayout());
    JLabel label = new JLabel(Res.getString(Res.VARIABLE_DIALOG_MASTER_TITLE));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.anchor = GridBagConstraints.SOUTHWEST;
    masterPanel.add(label, gbc);
    Variable[] vars = mVariableManager
        .getVariablesOfKind(Variable.VAR_KIND_WHERE_CLAUSE_PARAM);
    BindVariable[] variables = new BindVariable[vars.length];
    for (int i = 0; i < variables.length; i++)
    {
      variables[i] = new BindVariable(vars[i],mLocale);
    }
    mVarList = new JList(variables);
    mVarList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    mVarList.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent ev)
      {
        if(!ev.getValueIsAdjusting() && ((JList)ev.getSource()).getSelectedIndices().length==1){
          updateDetailPanel((BindVariable) ((JList) ev.getSource()).getSelectedValue());
        }
      }
    });
    JScrollPane scroller = new JScrollPane(mVarList);
    scroller.setBorder(BorderFactory.createLoweredBevelBorder());
    gbc.gridy = 1;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    masterPanel.add(scroller, gbc);
    return masterPanel;
  }

  private void createField(JTextField field, int resID)
  {
    field.setEditable(false);
    field.setFocusable(false);
    int size = field.getFont().getSize();
    field.setPreferredSize(new Dimension(minLength*size*2/3,size*2));
    gbc.gridx = 0;
    gbc.weightx = 0;
    JLabel label = JboTesterUtil.createLabel(resID, field);
    detailPanel.add(label, gbc);
    gbc.gridx = 1;
    gbc.weightx = 1;
    detailPanel.add(field, gbc);
    gbc.gridy++;
  }

  private void determineMinLength()
  {
    Variable[] variables = mVariableManager.getVariables();
    for(int i=0;i<variables.length;i++)
    {
      Variable variable = variables[i];
      minLength = Math.max(variable.getName().length(),minLength);
      if(variable.getJavaType()!=null)
      {
        minLength = Math.max(variable.getJavaType().getName().length(),minLength);
      }
      if(variable.getDefaultValue()!=null)
      {
        minLength = Math.max(variable.getDefaultValue().toString().length(),minLength);
      }
      Object value = mVariableManager.getVariableValue(variable);
      if(value!=null)
      {
        minLength = Math.max(value.toString().length(),minLength);
      }
    }    
  }

  private Object getVariableValue(String varName)
  {
    Object value = mTmpVarValues.get(varName);
    if (value == null)
      value = mVariableManager.getVariableValue(varName);
    if (value == null)
      value = mVariableManager.findVariable(varName).getDefaultValue();
    return value;
  }

  private void jbInit() throws Exception
  {
    determineMinLength();
    mainPanel.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.insets = new Insets(5, 5, 5, 5);
    mainPanel.add(buildMasterPanel(), gbc);
    gbc.gridy = 1;
    gbc.weighty = 0.0;
    mainPanel.add(buildDetailPanel(), gbc);
    mVarList.setSelectedIndex(0);
  }

  private void updateDetailPanel(BindVariable variable)
  {
    // update the old tmp variable info
    String varName = variable.getName();
    updateTmpVarValue();
    mVarName = varName;
    Variable var = mVariableManager.findVariable(varName);
    mVarNameField.setText(var.getName());
    Class javatype = var.getJavaType();
    mVarTypeField.setText(javatype==null?"":javatype.getName());
    Object defaultValue = var.getDefaultValue();
    setText(var,mVarDefaultField,defaultValue);
    Object value = getVariableValue(varName);
    setText(var,mVarValueField,value);
    AttributeHints UIHelper = var.getUIHelper();
    mVarValueField.setToolTipText(UIHelper==null?"":UIHelper.getTooltip(mLocale));
    mVarValueField.setEditable(var.getUpdateableFlag()!=AttributeDef.READONLY);
  }

    private void setText(Variable var, JTextField textField, Object value) {
        AttributeHints UIHelper;
        Formatter formatter;
        if (value != null && (UIHelper = var.getUIHelper()) != null &&
            (formatter = UIHelper.getFormatter(mLocale)) != null) {
            try {
                String format = formatter.getDefaultFormatString();
                value = formatter.format(format, value);
            } catch (Throwable t) {
                ;                
            }
        }
        textField.setText(value==null?"":value.toString());
    }

    private String getText(Variable var, JTextField textField) {
        AttributeHints UIHelper;
        Formatter formatter;
        String value = textField.getText();
        if (value != null && (UIHelper = var.getUIHelper()) != null &&
            (formatter = UIHelper.getFormatter(mLocale)) != null) {
            try {
                value = formatter.parseObject(value).toString();
            } catch (ParseException e) {
                value = textField.getText();
            }
        }
        return value;
    }

  private void updateTmpVarValue()
  {
    // this will be fired once during init when we are selecting the first
    // variable in the list.
    if (mVarName != null)
    {
      Variable var = mVariableManager.findVariable(mVarName);
      Object textValue = getText(var,mVarValueField);
      if (textValue == null)
        textValue = new NullValue();
      mTmpVarValues.put(mVarName, textValue);
    }
  }
}
