/*
 * @(#)JBOFieldHelper.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import oracle.jbo.AttributeDef;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;

public class JBOFieldHelper implements JBOField
{
   private final AttributeDef attrDef;
   private final JBOField controlField;
   protected Row             row;
   protected RowSetIterator  rowIter;
   protected boolean         inRefresh;

   static public final ActionListener UpdateActionListener = new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            Object source = e.getSource();
            if (source instanceof JBOField)
            {
               JBOField input = (JBOField) source;
               input.applyEdit();
            }
         }
      };

   static public final Action CancelAction = new AbstractAction()
      {
         public void actionPerformed(ActionEvent e)
         {
            Object source = e.getSource();
            if (source instanceof JBOField)
            {
               JBOField input = (JBOField) source;
               input.refresh();
            }
         }
      };
   
   
   public JBOFieldHelper(AttributeDef attDef, JBOField jboField)
   {
      this.attrDef = attDef;
      this.controlField = jboField;
   }

   protected void init()
   {
      getJComponent().addFocusListener(new DefaultJBOFocusListener());
   }
   
   public void setRow(Row newRowBinding, RowSetIterator iter)
   {
      row = newRowBinding;
      rowIter = iter;

      getJComponent().setEnabled((row != null) && !row.isDead() && row.isAttributeUpdateable(attrDef.getIndex()));
      refresh();
   }

   public AttributeDef getAttributeDef()
   {
      return attrDef;
   }
   
   public Object getDataValue()
   {
      try
      {
         if (row != null)
         {
            return JboTesterUtil.getData(row, attrDef, getLocaleContext());
         }
      }
      catch(Exception e)
      {
         // ErrorHandler.displayError(((RowSetPanel) getJComponent().getParent()).mainFrame, e, rowIter.getRowSet().getViewObject());
         // KM: bug 2749379 & 2978459
         ErrorHandler.displayError(getRowSetPanel(getJComponent()).mainFrame, e, rowIter.getRowSet().getViewObject());
      }

      return null;
   }

   public boolean setDataValue(Object value)
   {
      try
      {
         if (row != null)
         {
            JboTesterUtil.setData(row, attrDef, getLocaleContext(), value);
            return true;
         }
      }
      catch(Exception e)
      {
         SwingUtilities.invokeLater(new DelayedError(e, rowIter.getRowSet().getViewObject()));
      }

      return false;
   }
      
   /**
    * searches the containership hierarchy for a RowSetPanel, returns
    * null if not found
    */
   public static RowSetPanel getRowSetPanel(JComponent j)
   {
      JComponent jParent = (JComponent) j.getParent();
      
      if (jParent == null)
      {
        return null;
      }
      
      if (jParent instanceof RowSetPanel)
      {
        return (RowSetPanel) jParent;
      }
      
      return getRowSetPanel(jParent);
   }


   // No-op for the helper class
   public Object getControlValue()
   {
      return controlField.getControlValue();
   }

   // No-op for the helper class
   public void setControlValue(Object value)
   {
      controlField.setControlValue(value);
   }

   // No-op for the helper class
   public JComponent getJComponent()
   {
      return controlField.getJComponent();
   }

   public LocaleContext getLocaleContext()
   {
      return controlField.getLocaleContext();
   }
   
   public boolean applyEdit()
   {
      if (!inRefresh && row != null)
      {
         return setDataValue(getControlValue());
      }

      return true;
   }

   public boolean applyEditAndValidate()
   {
      // isTemporary is to take care of exception dialog grabbing the focus
      if (inRefresh)
      {
         return true;
      }

      Object cVal = getControlValue();
      Object dVal = getDataValue();

      // If value is the same, don't do anything
      if (cVal == dVal)
      {
         return true;
      }

      // Here "" is the definiton of a null value
      String cStr = (cVal == null) ? "" : cVal.toString();
      String dStr = (dVal == null) ? "" : dVal.toString();

      boolean valid = true;
      if (cStr.compareTo(dStr) != 0)
      {
         valid = applyEdit();
         if (!valid)
         {
            SwingUtilities.invokeLater(new DelayedFocus(getJComponent()));
         }
      }

      return valid;
   }

   public void refresh()
   {
      inRefresh = true;
      setControlValue(getDataValue());
      inRefresh = false;
   }

   class DefaultJBOFocusListener extends FocusAdapter
   {
      public void focusGained(FocusEvent e)
      {
         if (!e.isTemporary())
         {
         }
      }

      public void focusLost(FocusEvent event)
      {      
         // isTemporary is to take care of exception dialog grabbing the focus
         if (inRefresh || event.isTemporary())
         {
            return;
         }
         
         Object o = event.getOppositeComponent();
         if(o!=null && o instanceof JButton)
         {
           JButton b = (JButton)o;

           //bug 4523956
           //Mac OS doesn't seem to mark events as temporary
           //so we have to check if we are getting here from the exception dialog
           Container c = b.getParent();
           while(c!=null && !(c instanceof JDialog))
           {
             c = c.getParent();
           }
           if(c!=null && c instanceof ErrorHandler)
           {
             return;
           }

           //the only action flagged with "isDelayedValidation" is Rollback
           //we don't want to keep telling the user the data is wrong if the user
           //wants to dismiss it.
            Action action = b.getAction();
            if(action!=null && action instanceof AbstractJboAction)
            {
              if(((AbstractJboAction)action).isDelayedValidation())
              {
                return;
              }
            }
         }
         applyEditAndValidate();
      }
   }
   
   class DelayedError implements Runnable
   {
      Exception ex;
      ViewObject vo;

      public DelayedError(Exception e, ViewObject viewObject)
      {
         ex = e;
         vo = viewObject;
      }

      public void run()
      {
         if (ex != null)
         {
            ErrorHandler.displayError(JOptionPane.getFrameForComponent(getJComponent()), ex, vo);
         }
      }
   }
}

class DelayedFocus implements Runnable
{
   JComponent toFocus;

   public DelayedFocus(JComponent comp)
   {
      toFocus = comp;
   }

   public void run()
   {
      if (toFocus != null)
      {
         toFocus.requestFocus();
      }
   }
}
