/*
 * @(#)AMTreeNode.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import oracle.jbo.ApplicationModule;
import oracle.jbo.jbotester.properties.ApplicationModuleBean;

public final class AMTreeNode extends ObjTreeNode
{
   ApplicationModule am;
   static ImageIcon icon; // shared by all instance of this class

   public AMTreeNode(ApplicationModule amParam)
   {
      super(amParam.getName());

      am = amParam;

      if (icon == null)
      {
         icon = JboTesterUtil.getIcon("NodeAMU.gif");
      }
   }

   public String getName()
   {
      return am.getName();
   }

   public String getFullName()
   {
      return am.getFullName();
   }
   
   public int getType()
   {
      return APP_MODULE;
   }

   public Object getData()
   {
      return am;
   }

   public void setData(Object data)
   {
      am = (ApplicationModule) data;
   }

   public ImageIcon getIcon()
   {
      return icon;
   }

   public void remove()
   {
      // Root Application module cannot be removed.
      if (isRoot())
      {
         ErrorHandler.displayError(MainFrame.getInstance(), Res.getString(Res.TREE_CANNOT_REMOVE_AM_ERROR));
         return;
      }

      super.remove(); // That will remove the children first
      am.remove();
      am = null;
   }

   public JPopupMenu getMenu()
   {
      if (popupMenu == null)
      {
         popupMenu = new JPopupMenu();

         JMenu subMenu = MainFrame.createMenu(Res.MAIN_MENU_CREATE);
         subMenu.add(createAMAction);
         subMenu.add(createVOAction);
         subMenu.add(createVLAction);
         popupMenu.add(subMenu);
   
         if (removeAction == null)
         {
            removeAction = new RemoveAction();
         }
         popupMenu.add(removeAction);
         popupMenu.addSeparator();
         popupMenu.add(new PropertiesAction());
      }

      removeAction.setEnabled(!isRoot());

      return popupMenu;
   }

   public String getStatus()
   {
      if (am == null)
      {
         return " ";
      }

      StringBuffer status = new StringBuffer();

      status.append(Res.getString(Res.TREE_STATUS_LINE_NAME));
      status.append(am.getFullName());
      status.append(Res.getString(Res.TREE_STATUS_LINE_DEFINITION));
      status.append(am.getDefFullName());

      return status.toString();
   }

   public void showProperties()
   {
      ApplicationModuleBean appModBean = new ApplicationModuleBean(am);
      showPropertyDialog(appModBean, appModBean.getBeanInfo(), Res.TREE_amProperties);
   }
}
