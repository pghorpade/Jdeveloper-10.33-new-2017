/*
 * @(#)JboTesterUtil.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.ArrayList;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;

import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.KeyEvent;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.sql.Types;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.Keymap;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.LocaleContext;
import oracle.jbo.Row;
import oracle.jbo.RowSet;
import oracle.jbo.ViewObject;
import oracle.jbo.VariableManager;
import oracle.jbo.Variable;
import oracle.jbo.XMLInterface;
import oracle.jbo.client.JboUtil;
import oracle.jbo.common.DebugDiagnostic;
import oracle.jbo.domain.Array;
import oracle.xml.parser.v2.XMLElement;

public final class JboTesterUtil
{
   public static final String EJB_CLIENT_JARS   = "EjbClientJars";
   public static final String IMAGELOC          = "images/";

   public static void centerWindow(Window window)
   {
      Dimension size = window.getSize();
      if ((size.width == 0) || (size.height == 0))
         return;
  
      // Now, make sure it's onscreen
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  
      // Grrr... this doesn't actually work on the Mac, where the screen
      // doesn't necessarily start at 0,0
      int x = (screenSize.width - size.width) / 2;
      if (x < 0)
         x = 0;
  
      int y = (screenSize.height - size.height) / 2;
      if (y < 0)
         y = 0;
  
      window.setLocation(x, y);
   }

   public static String getDataAsXML(ViewObject vo)
   {
      XMLElement elem = (XMLElement) vo.writeXML(10, XMLInterface.XML_OPT_ALL_ROWS|XMLInterface.XML_OPT_ASSOC_CONSISTENT);
      ByteArrayOutputStream outStream = new ByteArrayOutputStream();
      String retStr;
      
      String enc = "UTF-8"; //System.getProperty("file.encoding");
      
      try
      {
         elem.print(outStream,enc);
         retStr = outStream.toString(enc);
         outStream.close();
      }
      catch (Exception e)
      {
         ErrorHandler.displayError(null, e);
         retStr = new String();
      }

      return retStr;
   }

   public static AttributeDef[] getDisplayableAttributes(RowSet rs)
   {
      AttributeDef attrs[] = rs.getViewObject().getAttributeDefs();
      LocaleContext locale = rs.getApplicationModule().getSession().getLocaleContext();
      
      ArrayList v = new ArrayList(attrs.length);
      
      for (int i = 0; i < attrs.length; i++ )
      {
         if (!JboUtil.isAttributeDisplayable(attrs[i], locale))
         {
            continue;
         }

         v.add(attrs[i]);
      }

      // If nothing has been removed, simply return the original array
      if (v.size() == attrs.length)
      {
         return attrs;
      }

      return (AttributeDef[]) v.toArray(new AttributeDef[v.size()]);
   }

   public static ImageIcon getIcon(String iconName)
   {
      ImageIcon icon = null;

      try
      {
         // Don't add local path to absolute path
         if (!iconName.startsWith("/"))
         {
            iconName = IMAGELOC + iconName;
         }
         URL img = JboTesterUtil.class.getResource(iconName);
         icon = new ImageIcon(img);
      }
      catch(Exception e)
      {
         // Any Exceptions. Just Ignore
         DebugDiagnostic.println("Warning: Can not load Jbo Tester Specific Icons");
      }

      return icon;
   }

   public static void removeKeyBindingCompatibility(JTextField tf)
   {
      KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
      Keymap map =  tf.getKeymap();
      map.removeKeyStrokeBinding(enter);
   }

   public static void createViewCriteria(MainFrame parent, ViewObject vo)
   {
      VCDialog vcDlg = new VCDialog(parent, vo);
      if (vcDlg.attribs == null || vcDlg.attribs.length == 0)
      {
         ErrorHandler.displayError(parent, Res.getString(Res.CREATE_VO_ERROR));
         return;
      }

      vcDlg.show();
   }

   public static void editBindParameters(MainFrame parent, ViewObject vo)
   {
      VariableDialog bindDlg = new VariableDialog(parent, vo);
      bindDlg.show();
   }

   public static boolean hasBindParameters(ViewObject vo)
   {
      vo.ensureVariableManager();
      VariableManager vMgr = vo.getVariableManager();

      if (vMgr != null)
      {
         Variable[] vars = vMgr.getVariablesOfKind(
            Variable.VAR_KIND_WHERE_CLAUSE_PARAM);

         if (vars != null && vars.length > 0)
         {
            return true;
         }
      }

      return false;
   }

   public static void setData(Row row, AttributeDef attrDef, LocaleContext locale, Object value)
   {
      AttributeHints hints = attrDef.getUIHelper();
      if (hints.hasFormatInformation(locale))
      { 
         // parse the formatted string
         value = hints.parseFormattedAttribute((String) value , locale);
      }
   
      row.setAttribute(attrDef.getIndex(), value);
   }
   
   public static Object getData(Row row, AttributeDef attrDef, LocaleContext locale)
   {
      AttributeHints hints = attrDef.getUIHelper();
      if (hints.hasFormatInformation(locale))
      {
         //format the attribute
         return hints.getFormattedAttribute(row, locale);
      }
      else
      {
         Object obj = row.getAttribute(attrDef.getIndex());

         if (attrDef.getSQLType() == Types.ARRAY)
         {
            Array array = (Array) obj;
            Object[] objArray = null;
            int size = 0;
            if (array != null)
            {
               objArray = array.getArray();
            }
            if (objArray != null)
            {
               size = objArray.length;
            }
            StringBuffer buf = new StringBuffer();
            buf.append('[');
            for (int i = 0; i < size; i++)
            {
               buf.append(objArray[i]);
               buf.append(',');
            }
            // Remove last comma
            if (size > 0)
            {
               // buf.deleteCharAt(buf.length()-1);
               buf.setLength(buf.length() - 1);
            }
            buf.append(']');
            return buf;
         }
         else
         {
            return obj;
         }
      }
     
   }

  public static void setMnemonic(JButton button, int resId)
  {
    int mnemonic  = JboTesterUtil.getMnemonicKeyCode(resId);
    if (mnemonic != 0)
    {
       button.setMnemonic(mnemonic);
    }
  }

   public static String stripMnemonic(int resId)
   {
      return stripMnemonic(Res.getString(resId));
   }
   
   public static String stripMnemonic(String string)
   {
      return oracle.bali.share.nls.StringUtils.stripMnemonic(string);
   }

   public static int getMnemonicKeyCode(int resId)
   {
      return getMnemonicKeyCode(Res.getString(resId));
   }

   /**
    * Returns the key code for the mnemonic in the string.  Returns
    * VK_UNDEFINED if the string does not contain a mnemonic.
    */
   public static int getMnemonicKeyCode(String string)
   {
      return oracle.bali.share.nls.StringUtils.getMnemonicKeyCode(string);
   }


    /**
     * Instantiates a new JButton
     * The text is taken from the resource ID, and the mnemonic is assigned
     * if specified in the resource string.
     * @param buttonResId the resource ID
     * @return the new JButton
     */
    public static JButton createButton(int buttonResId)
    {
      return createButton(Res.getString(buttonResId));
    }
    
    /**
     * Instantiates a new JButton
     * The specified text is used at the label text
     * The mnemonic is assigned if specified in the text.
     * @param buttonLabel 
     * @return the new JButton
     */
    public static JButton createButton(String buttonLabel)
    {
      JButton button = new JButton(stripMnemonic(buttonLabel));
      int mnemonic = getMnemonicKeyCode(buttonLabel);
      if(mnemonic !=0)
      {
        button.setMnemonic(mnemonic);
      }
      return button;  
    }
    
    public static JCheckBox createCheckBox(int checkBoxLabelID)
    {
      return createCheckBox(Res.getString(checkBoxLabelID));
    }
    
    /**
     * Create a checkbox with the specified label
     * Assign a mnemonic if the label has a mnemonic key specified
     * @param checkBoxLabel 
     * @return the new CheckBox
     */
    public static JCheckBox createCheckBox(String checkBoxLabel)
    {
      JCheckBox checkBox = new JCheckBox(stripMnemonic(checkBoxLabel));
      int mnemonic = getMnemonicKeyCode(checkBoxLabel);
      if (mnemonic != 0)
      {
        checkBox.setMnemonic(mnemonic);
      }
      return checkBox;
    }
    
   public static JLabel createLabel(int labelResId, Component labelFor)
   {
      JLabel label = new JLabel(stripMnemonic(labelResId));

      int mnemonic  = getMnemonicKeyCode(labelResId);
      if (mnemonic != 0)
      {
         label.setDisplayedMnemonic(mnemonic);
         label.setLabelFor(labelFor);
      }

      return label;
   }

   static public void addSpacerPanel(JPanel panel, int x, int y)
   {
      JPanel spacerPanel = new JPanel();
      GridBagConstraints gbc = new GridBagConstraints();

      gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridheight = 1;
      gbc.gridwidth = 1;
      gbc.anchor = GridBagConstraints.NORTH;
      gbc.fill = GridBagConstraints.VERTICAL;
      gbc.weighty = 3;
      gbc.insets = new Insets(0, 0, 0, 0);
      panel.add(spacerPanel, gbc);

   }

}
