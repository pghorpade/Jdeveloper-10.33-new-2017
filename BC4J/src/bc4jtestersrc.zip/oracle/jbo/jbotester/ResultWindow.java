/*
 * @(#)ResultWindow.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;
import oracle.jbo.RowSetIterator;
import oracle.jbo.common.DebugDiagnostic;

public final class ResultWindow implements ChangeListener
{
   private static ResultWindow resultWindow = null;

   private final JTabbedPane     tabPane;
   private final Hashtable       mWins = new Hashtable(20);
   private String                selectedTabName;
   private transient ChangeEvent changeEvent;
   private EventListenerList listenerList = new EventListenerList();
   
   private boolean isDocking = false;
   public boolean isDocking()
   {
     return isDocking;
   }

   public ResultWindow()
   {
      tabPane = new JTabbedPane();
      tabPane.addChangeListener(this);
   }

   public void addChangeListener(ChangeListener l)
   {
      listenerList.add(ChangeListener.class, l);
   }

   public void removeChangeListener(ChangeListener l)
   {
      listenerList.remove(ChangeListener.class, l);
   }

   public JTabbedPane getTabbedPane()
   {
      return tabPane;
   }

   public void addTab(JPanel panel, String tabName)
   {
      int index = tabPane.indexOfTab(tabName);
      if (index == -1)
      {
         tabPane.addTab(tabName, panel);
      }

      showTab(tabName);
   }

  /**
   * addToWindow is used to show the data window and navigation bar in a separate window
   * In this case, the navigation bar is floating, and assumed to be on the spot
   * where the new window should reside.
   * @param container the window with the navigation bar
   * @param panel the data panel
   */
  public void addToWindow(JPanel container, JPanel panel)
  {
  /*
   * Note. the method name is a bit misleading. We're not adding to the floating
   * window with the navbar. Instead we're creating a new window, putting it on the 
   * spot where the navbar just was
   */
    int index = tabPane.indexOfComponent(panel);
    if (index == -1)
    {
      return;
    }
    String title = tabPane.getTitleAt(index);
    tabPane.removeTabAt(index);
    ResultFrame frame = new ResultFrame(this, panel, title);
    mWins.put(title, frame);
    frame.getContentPane().add(container.getComponent(0), BorderLayout.NORTH);
    frame.getContentPane().add(panel.getComponent(0), BorderLayout.CENTER);
    frame.setLocation(container.getRootPane().getParent().getLocationOnScreen());
    frame.pack();
    frame.setVisible(true);
    container.getRootPane().getParent().setVisible(false);
  }
  
  
  /**
   * displayInWindow is used to show the data window and navigation bar in a separate window
   * @param panel the Panel containing both data and navigation bar
   */
  public void displayInWindow(JPanel panel)
  {
    int index = tabPane.indexOfComponent(panel);
    if (index == -1)
    {
      return;
    }
    String title = tabPane.getTitleAt(index);
    tabPane.removeTabAt(index);
    ResultFrame frame = new ResultFrame(this, panel, title);
    mWins.put(title, frame);
    frame.getContentPane().add(panel.getComponent(0), BorderLayout.NORTH);
    frame.getContentPane().add(panel.getComponent(0), BorderLayout.CENTER);
    frame.setLocationRelativeTo(MainFrame.getInstance());
    frame.pack();
    frame.setVisible(true);
  }
   
   public static ResultWindow getResultWindow()
   {
      return resultWindow;
   }

   public static ResultWindow createResultWindow()
   {
      if(resultWindow == null)
      {
         resultWindow = new ResultWindow();
      }
      return resultWindow;
   }

   // Return the panel associated with 'title' whereever
   // the panel is floating or in a tab
   public JPanel getTab(String title)
   {
      JPanel panel = null;
      if (title == null)
      {
         return null;
      }

      int index = tabPane.indexOfTab(title);
      if (index == -1)
      {
         ResultFrame frame = (ResultFrame)mWins.get(title);
         if (frame != null)
         {
            panel =  frame.mPanel;
         }
      }
      else
      {
         panel = (JPanel)tabPane.getComponentAt(index);
      }

      return panel;
   }

   public JPanel getSelectedTab()
   {
      return getTab(selectedTabName);
   }

   public void showTab(String name)
   {
      int index = tabPane.indexOfTab(name);
      if (index != -1)
      {
         tabPane.setSelectedIndex(index);
      }
      else
      {
         JDialog dispFrame = (JDialog) mWins.get(name);
         if (dispFrame != null)
         {
            dispFrame.toFront();
         }
      }
   }

   public JPanel removeTab(String name)
   {
      JPanel panel = null;

      int index = tabPane.indexOfTab(name);
      if (index != -1)
      {
         panel = (JPanel) tabPane.getComponentAt(index);
         tabPane.removeTabAt(index);
      }
      else
      {
         ResultFrame frame = (ResultFrame)mWins.get(name);
         if (frame != null)
         {
            panel = frame.mPanel;
            frame.dispose();
            mWins.remove(name);
         }
      }

      return panel;
   }

   public void replaceTab(ResultFrame frame)
   {
      JPanel panel = frame.mPanel;

      panel.add(frame.getContentPane().getComponent(0), BorderLayout.NORTH);
      panel.add(frame.getContentPane().getComponent(0), BorderLayout.CENTER);

      addTab(panel, frame.getTitle());
      mWins.remove(frame.getTitle());
      this.isDocking = true;
      this.fireStateChange();
     this.isDocking = false;
   }

   public void removeAllTabs()
   {
      mWins.clear();
      tabPane.removeAll();
   }

   public void refreshAfterActivate()
   {
      // Refresh all the tabs
      int tabCount = tabPane.getTabCount();
      for (int i = 0; i < tabCount; i++)
      {
         refreshFormAfterActivate((SimpleForm)tabPane.getComponentAt(i));
      }

      // Then all the floating windows
      for (Enumeration e = mWins.elements(); e.hasMoreElements(); )
      {
         ResultFrame frame = (ResultFrame) e.nextElement();
         if (frame != null)
         {
            refreshFormAfterActivate((SimpleForm)frame.mPanel);
         }
      }
   }

   void refreshFormAfterActivate(SimpleForm form)
   {
      RowSetIterator iter;

      if (form instanceof MDForm) 
      {
         iter = ((MDForm) form).getDetailRowSetIterator();
      }
      else
      {
         iter = form.getIterator();
      }

      //this should call activateIteratorState() which would
      //end up in sending out proper events for UIs.
      iter.getCurrentRow();
   }

   public void refreshAll(boolean resetCurrency)
   {
      // Refresh all the tabs
      int tabCount = tabPane.getTabCount();
      for (int i = 0; i < tabCount; i++)
      {
         refreshForm(tabPane.getComponentAt(i), resetCurrency);
      }

      // Then all the floating windows
      for (Enumeration e = mWins.elements(); e.hasMoreElements(); )
      {
         ResultFrame frame = (ResultFrame) e.nextElement();
         if (frame != null)
         {
            refreshForm(frame.mPanel, resetCurrency);
         }
      }
   }

   private void refreshForm(Component form, boolean resetCurrency)
   {
      RowSetIterator iter = null;

      if (form == null)
      {
         return;
      }

      if (resetCurrency)
      {
         // if it is a for with a detail set, reset the detail.
         if (form instanceof MDForm)
         {
            iter = ((MDForm) form).getDetailRowSetIterator();
      
            if (iter != null)
            {
               iter.first();
            }
         }
         
         
         // Reset the top level iterator
         iter = ((SimpleForm) form).getIterator();
   
         if (iter != null)
         {
            iter.first();
         }
      }
      else
      {
         SimpleForm sForm = ((SimpleForm) form);
         sForm.refreshAll();
      }
   }

   private void fireStateChange()
   {
      Object[] listeners = listenerList.getListenerList();

      // Process the listeners last to first, notifying
      // those that are interested in this event
      for (int i = listeners.length-2; i >= 0; i -= 2)
      {
         if (listeners[i] == ChangeListener.class)
         {
            // Lazily create the event:
            if (changeEvent == null)
            {
               changeEvent = new ChangeEvent(this);
            }

            ((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
         }
      }
   }

   void tabIsSelected(String tabName)
   {
      selectedTabName = tabName;
      fireStateChange();
   }

   // ChangeListener implementation
   public void stateChanged(ChangeEvent e)
   {
      if (e.getSource() instanceof JTabbedPane)
      {
         JTabbedPane tp = (JTabbedPane) e.getSource();

         int index = tp.getSelectedIndex();
         if (index != -1)
         {
            tabIsSelected(tp.getTitleAt(index));
         }
      }
   }
}

final class ResultFrame extends JDialog
{
   ResultWindow mResultWindow = null;
   JPanel       mPanel = null;

   ResultFrame(ResultWindow rw, JPanel panel, String title)
   {
      super(MainFrame.getInstance(), title);

      mResultWindow = rw;
      mPanel = panel;

      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            DebugDiagnostic.println("In Window Closing");
            mResultWindow.replaceTab(ResultFrame.this);
         }

         public void windowActivated(WindowEvent e)
         {
            mResultWindow.tabIsSelected(getTitle());
         }
      });
   }
}
