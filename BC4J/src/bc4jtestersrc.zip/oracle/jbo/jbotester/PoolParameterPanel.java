/*
 * @(#)PoolParameterPanel.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import com.sun.java.util.collections.ArrayList;

import java.awt.Component;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.BoxLayout;
import javax.swing.Box;

import oracle.jbo.client.Configuration;
import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;

import oracle.bali.ewt.spinBox.NumericSpinBox;
import oracle.bali.ewt.spinBox.SpinBuddy;

import oracle.jbo.jbotester.load.Controller;

public class PoolParameterPanel extends JPanel
{
   private static final int MAX_POOL_SIZE = 5000;
   private static final int MIN_POOL_SIZE = 0;

   private Hashtable       mParams;

   private static final String TRUE = "true";
   private static final String FALSE = "false";

   private final NumericSpinBox poolInitSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox poolMaxSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox poolRefSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox poolMinAvailSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox poolMaxAvailSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox poolMaxInactiveAgeSpin = new NumericSpinBox(0, 60*60*24);
   private final NumericSpinBox poolMonitorSleepIntervalSpin = new NumericSpinBox(0, 60*60*24);

   // connection pool
   private final NumericSpinBox connPoolInitSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox connPoolMaxSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox connPoolMinAvailSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox connPoolMaxAvailSizeSpin = new NumericSpinBox(MIN_POOL_SIZE, MAX_POOL_SIZE);
   private final NumericSpinBox connPoolMaxInactiveAgeSpin = new NumericSpinBox(0, 60*60*24);
   private final NumericSpinBox connPoolMonitorSleepIntervalSpin = new NumericSpinBox(0, 60*60*24);

   private final NumericSpinBox[] connCapacitySpins = new NumericSpinBox[]{
      connPoolInitSizeSpin
      , connPoolMaxSizeSpin
      , connPoolMinAvailSizeSpin
      , connPoolMaxAvailSizeSpin
      , connPoolMaxInactiveAgeSpin
      , connPoolMonitorSleepIntervalSpin
   };

  private final JCheckBox    poolDoFailoverCheck = JboTesterUtil.createCheckBox(Res.POOL_DO_FAILOVER_LABEL);
  private final JCheckBox    poolDoConnectionPoolingCheck = JboTesterUtil.createCheckBox(Res.POOL_DO_CONN_POOLING_LABEL);
  private final JCheckBox    poolDynamicJdbcCredentialsCheck = JboTesterUtil.createCheckBox(Res.POOL_DYNAMIC_JDBC_LABEL);
  private final JCheckBox    poolResetNonTxnStateCheck = JboTesterUtil.createCheckBox(Res.POOL_RESET_NON_TXN_LABEL);
  private final JCheckBox    poolDoAMPoolingCheck = JboTesterUtil.createCheckBox(Res.POOL_DO_AM_POOLING_LABEL);
  private final JCheckBox    poolIsUseExclusiveCheck = JboTesterUtil.createCheckBox(Res.POOL_IS_USE_EXCLUSIVE_LABEL);

   private final JButton      mResetButton = JboTesterUtil.createButton(Res.BUTTON_RESET);
   private final JButton      mApplyButton = JboTesterUtil.createButton(Res.BUTTON_APPLY);

   // this should really be managed by MOM
   static PropertyMetadata[] POOL_PARAMETER_METADATA = new PropertyMetadata[]{
      PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE
      , PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE
      , PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD
      , PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE
      , PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE
      , PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE
      , PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL
      , PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE
      , PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE
      , PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE
      , PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE
      , PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE
      , PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL
      , PropertyMetadata.ENV_DO_FAILOVER
      , PropertyMetadata.ENV_DO_CONNECTION_POOLING
      , PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS
      , PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE
      , PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING
      , PropertyMetadata.ENV_AMPOOL_COOKIE_FACTORY_CLASS_NAME
      };
      // , PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE};

   private final Frame mParentFrame;
   private Controller mController = null;

   private boolean mIsStandalone = false;

   public PoolParameterPanel(Frame parentFrame, Controller controller)
   {
      mParentFrame = parentFrame;

      mController = controller;
      mParams = (Hashtable)mController.getApplicationPool(true).getEnvironment().clone();

      mIsStandalone = true;
      
      init();
      
   }
   
   public PoolParameterPanel(Frame parentFrame, Hashtable params)
   {
      mParentFrame = parentFrame;
      mParams = params;

      init();
   }

   void setPoolParameters(Hashtable params)
   {
      mParams = params;
      updatePanelUI();
   }

   private final void init()
   {
      GridBagLayout gbl = new GridBagLayout();
      GridBagConstraints gbc = new GridBagConstraints();
      setLayout(gbl);

      // ApplicationPool capacity panel
      JPanel capacityPanel = buildCapacityPanel();
      String panelName = Res.getString(Res.CAPACITY_STR);

      capacityPanel.setBorder(BorderFactory.createCompoundBorder(
         BorderFactory.createTitledBorder(panelName)
         , BorderFactory.createEmptyBorder(5, 5, 0, 5)));


      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.NORTH;
//      gbc.gridheight = GridBagConstraints.NONE;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(5, 5, 5, 5);

      gbl.setConstraints(capacityPanel, gbc);
      add(capacityPanel);

      capacityPanel = buildConnCapacityPanel();
      panelName = Res.getString(Res.CONNECTION_POOL_CAPACITY_STR);
      capacityPanel.setBorder(BorderFactory.createCompoundBorder(
         BorderFactory.createTitledBorder(panelName)
         , BorderFactory.createEmptyBorder(5, 5, 0, 5)));

      gbc.gridx = 1;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.NORTH;
//      gbc.gridheight = GridBagConstraints.NONE;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(5, 5, 5, 5);

      gbl.setConstraints(capacityPanel, gbc);
      add(capacityPanel);

      // Failover panel
      JPanel failoverPanel = buildFailoverPanel();
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 2;
      gbc.anchor = GridBagConstraints.NORTH;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      gbl.setConstraints(failoverPanel, gbc);
      add(failoverPanel);

      gbc.gridx = 1;
      gbc.gridy = 2;
      gbc.anchor = GridBagConstraints.SOUTHEAST;
      gbc.weightx = 1.0;
      gbc.weighty = 0.0;
      gbc.fill = GridBagConstraints.NONE;
      gbc.insets = new Insets(5, 5, 5, 5);

      JPanel panel = buildButtonsBar();
      gbl.setConstraints(panel, gbc);
      add(panel);
      
      
//      gbl.setConstraints(resetButton, gbc);
//      add(resetButton);

      updatePanelUI();
   }

   private JPanel buildButtonsBar()
   {
      int maxWidth = 0;
      ArrayList buttons = new ArrayList();

      JPanel panel = new JPanel();
      panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
      panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0));
      
      buttons.add(mResetButton);
      maxWidth = Math.max(maxWidth, mResetButton.getMinimumSize().width);
      mResetButton.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            resetPanelUI();
         }
      });

      if (mIsStandalone)
      {
         buttons.add(mApplyButton);
         maxWidth = Math.max(maxWidth, mApplyButton.getMinimumSize().width);
         mApplyButton.setEnabled(true);
         mApplyButton.setDefaultCapable(true);
         mApplyButton.addActionListener(
            new ActionListener()
            {
               public void actionPerformed(ActionEvent ev)
               {
                  apply();
               }
            });
      }

      Dimension   d = new Dimension(maxWidth, mApplyButton.getMinimumSize().height);
      Dimension   spacing = new Dimension(8, 0);
      JButton     b;

      for (int i = 0; i < buttons.size(); i++)
      {
         b = (JButton) buttons.get(i);
         b.setPreferredSize(d);

         if (i == 0)
         {
            panel.add(Box.createHorizontalGlue());
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
         else
         {
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
      }
      
      return panel;      
   }

   private void apply()
   {
      if(validateAndUpdateScalabilityParams(true))
      {
         // use the fact that hashtable is already synchronized and that pool
         // will give us the environment by referenced.
         Hashtable env = mController.getApplicationPool(true).getEnvironment();

         for (int i=0; i < POOL_PARAMETER_METADATA.length; i++)
         {
            String paramName = POOL_PARAMETER_METADATA[i].getName();
            Object param = mParams.get(paramName);
            if (param != null)
            {
               env.put(paramName, param);
            }
            else
            {
               // restore the default.
               env.remove(paramName);
            }
         }
      }
   }

   final void resetPanelUI()
   {
      int poolInitSizeDef = Integer.valueOf(PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getDefault()).intValue();
      poolInitSizeDef = (poolInitSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : poolInitSizeDef);
      poolInitSizeSpin.setIntValue(
         poolInitSizeDef < MAX_POOL_SIZE ? poolInitSizeDef : MAX_POOL_SIZE);

      int poolMaxSizeDef = Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getDefault()).intValue();
      poolMaxSizeDef = (poolMaxSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : poolMaxSizeDef);
      poolMaxSizeSpin.setIntValue(
         poolMaxSizeDef < MAX_POOL_SIZE ? poolMaxSizeDef : MAX_POOL_SIZE);

      int poolRefSizeDef = Integer.valueOf(PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getDefault()).intValue();
      poolRefSizeDef = (poolRefSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : poolRefSizeDef);
      poolRefSizeSpin.setIntValue(
         poolRefSizeDef < MAX_POOL_SIZE ? poolRefSizeDef : MAX_POOL_SIZE);

      int poolMinAvailSizeDef = Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getDefault()).intValue();
      poolMinAvailSizeDef = (poolMinAvailSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : poolMinAvailSizeDef);
      poolMinAvailSizeSpin.setIntValue(
         poolMinAvailSizeDef < MAX_POOL_SIZE ? poolMinAvailSizeDef : MAX_POOL_SIZE);

      int poolMaxAvailSizeDef = Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getDefault()).intValue();
      poolMaxAvailSizeDef = (poolMaxAvailSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : poolMaxAvailSizeDef);
      poolMaxAvailSizeSpin.setIntValue(
         poolMaxAvailSizeDef < MAX_POOL_SIZE ? poolMaxAvailSizeDef : MAX_POOL_SIZE);

      // convert the inactive age default to seconds
      int maxInactiveAgeMS = Integer.parseInt(PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getDefault()) / 1000;
      maxInactiveAgeMS = (maxInactiveAgeMS < MIN_POOL_SIZE ? MIN_POOL_SIZE : maxInactiveAgeMS);
      poolMaxInactiveAgeSpin.setIntValue(
         maxInactiveAgeMS < MAX_POOL_SIZE ? maxInactiveAgeMS : MAX_POOL_SIZE);

      int sleepIntervalMS = Integer.parseInt(PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL.getDefault()) / 1000;
      sleepIntervalMS = (sleepIntervalMS < MIN_POOL_SIZE ? MIN_POOL_SIZE : sleepIntervalMS);
      poolMonitorSleepIntervalSpin.setIntValue(
         sleepIntervalMS < MAX_POOL_SIZE ? sleepIntervalMS : MAX_POOL_SIZE);

      // connection pool
      int connPoolInitSizeDef = Integer.valueOf(PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getDefault()).intValue();
      connPoolInitSizeDef = (connPoolInitSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : connPoolInitSizeDef);
      connPoolInitSizeSpin.setIntValue(
         connPoolInitSizeDef < MAX_POOL_SIZE ? connPoolInitSizeDef : MAX_POOL_SIZE);

      int connPoolMaxSizeSpinDef = Integer.valueOf(PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getDefault()).intValue();
      connPoolMaxSizeSpinDef = (connPoolMaxSizeSpinDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : connPoolMaxSizeSpinDef);
      connPoolMaxSizeSpin.setIntValue(
         connPoolMaxSizeSpinDef < MAX_POOL_SIZE ? connPoolMaxSizeSpinDef : MAX_POOL_SIZE);

      int connPoolMinAvailSizeDef = Integer.valueOf(PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getDefault()).intValue();
      connPoolMinAvailSizeDef = (connPoolMinAvailSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : connPoolMinAvailSizeDef);
      connPoolMinAvailSizeSpin.setIntValue(
         connPoolMinAvailSizeDef < MAX_POOL_SIZE ? connPoolMinAvailSizeDef : MAX_POOL_SIZE);

      int connPoolMaxAvailSizeDef = Integer.valueOf(PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getDefault()).intValue();
      connPoolMaxAvailSizeDef = (connPoolMaxAvailSizeDef < MIN_POOL_SIZE ? MIN_POOL_SIZE : connPoolMaxAvailSizeDef);
      connPoolMaxAvailSizeSpin.setIntValue(
         connPoolMaxAvailSizeDef < MAX_POOL_SIZE ? connPoolMaxAvailSizeDef : MAX_POOL_SIZE);

      // convert the inactive age default to seconds
      maxInactiveAgeMS = Integer.parseInt(PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getDefault()) / 1000;
      maxInactiveAgeMS = (maxInactiveAgeMS < MIN_POOL_SIZE ? MIN_POOL_SIZE : maxInactiveAgeMS);
      connPoolMaxInactiveAgeSpin.setIntValue(
         maxInactiveAgeMS < MAX_POOL_SIZE ? maxInactiveAgeMS : MAX_POOL_SIZE);

      sleepIntervalMS = Integer.parseInt(PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getDefault()) / 1000;
      sleepIntervalMS = (sleepIntervalMS < MIN_POOL_SIZE ? MIN_POOL_SIZE : sleepIntervalMS);
      connPoolMonitorSleepIntervalSpin.setIntValue(
         sleepIntervalMS < MAX_POOL_SIZE ? sleepIntervalMS : MAX_POOL_SIZE);

      poolDoFailoverCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_DO_FAILOVER.getDefault()));

      poolDoConnectionPoolingCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_DO_CONNECTION_POOLING.getDefault()));

      poolDynamicJdbcCredentialsCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getDefault()));

      poolResetNonTxnStateCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getDefault()));

      poolDoAMPoolingCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getDefault()));
      setAMPoolingEnabled(poolDoAMPoolingCheck.getModel().isSelected());

      poolIsUseExclusiveCheck.setSelected(
         TRUE.equals(PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getDefault()));
      setUseExclusive(poolIsUseExclusiveCheck.getModel().isSelected());

   }

   private final JPanel buildFailoverPanel()
   {
      JPanel               failoverPanel = new JPanel(new GridBagLayout());
      GridBagLayout        gbl = (GridBagLayout) failoverPanel.getLayout();
      GridBagConstraints   gbc = new GridBagConstraints();

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolDoFailoverCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_DO_FAILOVER.getName());
      gbl.setConstraints(poolDoFailoverCheck, gbc);
      failoverPanel.add(poolDoFailoverCheck);

      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolDoConnectionPoolingCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_DO_CONNECTION_POOLING.getName());
      gbl.setConstraints(poolDoConnectionPoolingCheck, gbc);
      failoverPanel.add(poolDoConnectionPoolingCheck);

      gbc.gridx = 0;
      gbc.gridy = 2;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolDynamicJdbcCredentialsCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getName());
      gbl.setConstraints(poolDynamicJdbcCredentialsCheck, gbc);
      failoverPanel.add(poolDynamicJdbcCredentialsCheck);

      gbc.gridx = 0;
      gbc.gridy = 3;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolResetNonTxnStateCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getName());
      gbl.setConstraints(poolResetNonTxnStateCheck, gbc);
      failoverPanel.add(poolResetNonTxnStateCheck);

      gbc.gridx = 0;
      gbc.gridy = 4;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolIsUseExclusiveCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getName());

      poolIsUseExclusiveCheck.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               setUseExclusive(((JCheckBox)ev.getSource()).getModel().isSelected());
            }
         }
      );

      // JRS Removed.  Bug 3087149.
      // gbl.setConstraints(poolIsUseExclusiveCheck, gbc);
      // failoverPanel.add(poolIsUseExclusiveCheck);

      gbc.gridx = 0;
      gbc.gridy = 4;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      poolDoAMPoolingCheck.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getName());

      poolDoAMPoolingCheck.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               setAMPoolingEnabled(((JCheckBox)ev.getSource()).getModel().isSelected());
            }
         }
      );

      gbl.setConstraints(poolDoAMPoolingCheck, gbc);
      failoverPanel.add(poolDoAMPoolingCheck);

      gbc.gridx = 0;
      gbc.gridy = 5;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.weightx = 1.0;
      gbc.weighty = 1.0;
      gbc.fill = GridBagConstraints.BOTH;
      gbc.insets = new Insets(2, 5, 5, 5);

      return failoverPanel;
   }


   final void setAMPoolingEnabled(boolean isEnabled)
   {
      // JRS Don't disable -- to complicated to explain
      // why some of these don't make sense when the pooling
      // is disabled.  It is hard to explain to people that the pool
      // is still being used even though the AM will be removed immediately
      // upon release.
//      for (int i=0; i < amPoolCapacitySpins.length; i++)
//      {
//         amPoolCapacitySpins[i].setEnabled(isEnabled);
//     }
//
//      poolDoFailoverCheck.setEnabled(isEnabled);
//      poolDoConnectionPoolingCheck.setEnabled(isEnabled);
//      poolDynamicJdbcCredentialsCheck.setEnabled(isEnabled);
//      poolResetNonTxnStateCheck.setEnabled(isEnabled);

      if (!isEnabled)
      {
         poolIsUseExclusiveCheck.setSelected(true);
      }

      poolIsUseExclusiveCheck.setEnabled(isEnabled);
   }

   final void setUseExclusive(boolean isEnabled)
   {
      if (!isEnabled)
      {
         poolDoFailoverCheck.setSelected(false);
         poolDoConnectionPoolingCheck.setSelected(false);
         poolDynamicJdbcCredentialsCheck.setSelected(false);
         poolResetNonTxnStateCheck.setSelected(false);
      }

      poolDoFailoverCheck.setEnabled(isEnabled);
      poolDoConnectionPoolingCheck.setEnabled(isEnabled);
      poolDynamicJdbcCredentialsCheck.setEnabled(isEnabled);
      poolResetNonTxnStateCheck.setEnabled(isEnabled);
   }


   final void setConnCapacitiesEditable(boolean isEditable)
   {
      for (int i=0; i < connCapacitySpins.length; i++)
      {
         connCapacitySpins[i].setEnabled(isEditable);
      }
   }

   private final void buildCapacityRow(
      JPanel panel
      , GridBagConstraints gbcApp
      , GridBagLayout gblApp
      , int labelKey
      , PropertyMetadata propMD
      , NumericSpinBox spin)
   {
      JLabel label = JboTesterUtil.createLabel(labelKey, spin);
      label.setToolTipText(Res.getString(Res.CORRESPONDS_TO) + " " + propMD.getName());

      panel.setAlignmentY(Component.TOP_ALIGNMENT);
//debug      panel.setBorder(BorderFactory.createLineBorder(Color.black));

      gbcApp.gridx = 0;
      gbcApp.fill = GridBagConstraints.NONE;
      gbcApp.weightx = 0.0;
      gbcApp.weighty = 0.0;
      gbcApp.insets = new Insets(2, 0, 0, 0);

      gblApp.setConstraints(label, gbcApp);
      panel.add(label);

      gbcApp.anchor = GridBagConstraints.NORTHWEST;
      gbcApp.gridx++;
      gbcApp.fill = GridBagConstraints.HORIZONTAL;
      gbcApp.weightx = 1.0;
      gbcApp.weighty = 0.0;
      gbcApp.insets = new Insets(2, 5, 0, 0);

      SpinBuddy buddy = spin.getSpinBuddy();
      if (buddy instanceof JTextField)
      {
         ((JTextField)buddy).setHorizontalAlignment(SwingConstants.RIGHT);
      }

      gblApp.setConstraints(spin, gbcApp);
      panel.add(spin);

      gbcApp.gridy++;
   }

   private final JPanel buildCapacityPanel()
   {
      GridBagLayout        gblApp   = new GridBagLayout();
      JPanel               panel    = new JPanel(gblApp);
      GridBagConstraints   gbcApp   = new GridBagConstraints();

      // shared contrainst settings:
      gbcApp.anchor = GridBagConstraints.NORTHWEST;
      gbcApp.gridx = 0;
      gbcApp.gridy = 0;

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.INIT_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE
         , poolInitSizeSpin);

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE
         , poolMaxSizeSpin);

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.REF_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD
         , poolRefSizeSpin);

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MIN_AVAIL_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE
         , poolMinAvailSizeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_AVAIL_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE
         , poolMaxAvailSizeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_POOL_INACTIVE_AGE_LABEL
         , PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE
         , poolMaxInactiveAgeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.POOL_MONITOR_SLEEP_INTERVAL_LABEL
         , PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL
         , poolMonitorSleepIntervalSpin);

      return panel;
   }

   private final JPanel buildConnCapacityPanel()
   {
      GridBagLayout        gblApp   = new GridBagLayout();
      JPanel               panel    = new JPanel(gblApp);
      GridBagConstraints   gbcApp   = new GridBagConstraints();

      // shared contrainst settings:
      gbcApp.gridx = 0;
      gbcApp.gridy = 0;
      gbcApp.anchor = GridBagConstraints.NORTHWEST;

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.INIT_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE
         , connPoolInitSizeSpin);

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE
         , connPoolMaxSizeSpin);

      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MIN_AVAIL_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE
         , connPoolMinAvailSizeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_AVAIL_POOL_SIZE_LABEL
         , PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE
         , connPoolMaxAvailSizeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.MAX_POOL_INACTIVE_AGE_LABEL
         , PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE
         , connPoolMaxInactiveAgeSpin);


      buildCapacityRow(
         panel
         , gbcApp
         , gblApp
         , Res.POOL_MONITOR_SLEEP_INTERVAL_LABEL
         , PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL
         , connPoolMonitorSleepIntervalSpin);


      // add a space holder
      JLabel label = new JLabel(" ");
      gblApp.setConstraints(label, gbcApp);
      panel.add(label);


      return panel;
   }

   final boolean validateAndUpdateScalabilityParams(boolean showError)
   {
      return validateAndUpdateScalabilityParams(mParams, showError);
   }

   final boolean validateAndUpdateScalabilityParams(Hashtable params, boolean showError)
   {
      // This flavor is intended to update the currentParams Hashtable in
      // ConnectionDialogBase.  A standalone poolParameterPanel should
      // also invoke this with the mParams member.
      try
      {
         int poolInitSize = poolInitSizeSpin.getIntValue();

         if (poolInitSize == MAX_POOL_SIZE)
         {
            poolInitSize = Integer.MAX_VALUE;
         }
         int poolMaxSize = poolMaxSizeSpin.getIntValue();

         if (poolMaxSize == MAX_POOL_SIZE)
         {
            poolMaxSize = Integer.MAX_VALUE;
         }
         int poolRefSize = poolRefSizeSpin.getIntValue();

         if (poolRefSize == MAX_POOL_SIZE)
         {
            poolRefSize = Integer.MAX_VALUE;
         }
         int poolMinAvailSize = poolMinAvailSizeSpin.getIntValue();

         if (poolMinAvailSize == MAX_POOL_SIZE)
         {
            poolMinAvailSize = Integer.MAX_VALUE;
         }
         int poolMaxAvailSize = poolMaxAvailSizeSpin.getIntValue();

         if (poolMaxAvailSize == MAX_POOL_SIZE)
         {
            poolMaxAvailSize = Integer.MAX_VALUE;
         }

         String poolMaxInactiveAge = null;
         int maxInactiveAgeS = poolMaxInactiveAgeSpin.getIntValue();

         if (maxInactiveAgeS > (Integer.MAX_VALUE / 1000))
         {
            poolMaxInactiveAge = String.valueOf(Integer.MAX_VALUE);
         }
         else
         {
            poolMaxInactiveAge = String.valueOf(maxInactiveAgeS*1000);
         }

         String poolMonitorSleepInterval = null;
         int sleepIntervalS = poolMonitorSleepIntervalSpin.getIntValue();
         if (sleepIntervalS > (Integer.MAX_VALUE / 1000))
         {
            poolMonitorSleepInterval = String.valueOf(Integer.MAX_VALUE);
         }
         else
         {
            poolMonitorSleepInterval = String.valueOf(sleepIntervalS*1000);
         }

         // connection parameters
         int connPoolInitSize = connPoolInitSizeSpin.getIntValue();

         if (connPoolInitSize == MAX_POOL_SIZE)
         {
            connPoolInitSize = Integer.MAX_VALUE;
         }

         int connPoolMaxSize = connPoolMaxSizeSpin.getIntValue();

         if (connPoolMaxSize == MAX_POOL_SIZE)
         {
            connPoolMaxSize = Integer.MAX_VALUE;
         }

         int connPoolMinAvailSize = connPoolMinAvailSizeSpin.getIntValue();

         if (connPoolMinAvailSize == MAX_POOL_SIZE)
         {
            connPoolMinAvailSize = Integer.MAX_VALUE;
         }

         int connPoolMaxAvailSize = connPoolMaxAvailSizeSpin.getIntValue();

         if (connPoolMaxAvailSize == MAX_POOL_SIZE)
         {
            connPoolMaxAvailSize = Integer.MAX_VALUE;
         }

         String connPoolMaxInactiveAge = null;
         maxInactiveAgeS = connPoolMaxInactiveAgeSpin.getIntValue();

         if (maxInactiveAgeS > (Integer.MAX_VALUE / 1000))
         {
            connPoolMaxInactiveAge = String.valueOf(Integer.MAX_VALUE);
         }
         else
         {
            connPoolMaxInactiveAge = String.valueOf(maxInactiveAgeS*1000);
         }

         String connPoolMonitorSleepInterval = null;
         sleepIntervalS = connPoolMonitorSleepIntervalSpin.getIntValue();
         if (sleepIntervalS > (Integer.MAX_VALUE / 1000))
         {
            connPoolMonitorSleepInterval = String.valueOf(Integer.MAX_VALUE);
         }
         else
         {
            connPoolMonitorSleepInterval = String.valueOf(sleepIntervalS*1000);
         }

         String poolDoFailover = (poolDoFailoverCheck.isSelected() ? TRUE : FALSE);
         String poolDoConnectionPooling = (poolDoConnectionPoolingCheck.isSelected() ? TRUE : FALSE);
         String poolDynamicJdbcCredentials = (poolDynamicJdbcCredentialsCheck.isSelected() ? TRUE : FALSE);
         String poolResetNonTxnState = (poolResetNonTxnStateCheck.isSelected() ? TRUE : FALSE);
         String poolDoAMPooling = (poolDoAMPoolingCheck.isSelected() ? TRUE : FALSE);
         String poolIsUseExclusive = (poolIsUseExclusiveCheck.isSelected() ? TRUE : FALSE);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getName()
            , String.valueOf(poolInitSize)
            , PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getName()
            , String.valueOf(poolMaxSize)
            , PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getName()
            , String.valueOf(poolRefSize)
            , PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getName()
            , String.valueOf(poolMinAvailSize)
            , PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getName()
            , String.valueOf(poolMaxAvailSize)
            , PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getName()
            , poolMaxInactiveAge
            , PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL.getName()
            , poolMonitorSleepInterval
            , PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL.getDefault()
            , params);

         // connection pool
         updateScalabilityParam(
            PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getName()
            , String.valueOf(connPoolInitSize)
            , PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getName()
            , String.valueOf(connPoolMaxSize)
            , PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getName()
            , String.valueOf(connPoolMinAvailSize)
            , PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getName()
            , String.valueOf(connPoolMaxAvailSize)
            , PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getName()
            , connPoolMaxInactiveAge
            , PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getName()
            , connPoolMonitorSleepInterval
            , PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_DO_FAILOVER.getName()
            , poolDoFailover
            , PropertyMetadata.ENV_DO_FAILOVER.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_DO_CONNECTION_POOLING.getName()
            , poolDoConnectionPooling
            , PropertyMetadata.ENV_DO_CONNECTION_POOLING.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getName()
            , poolDynamicJdbcCredentials
            , PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getName()
            , poolResetNonTxnState
            , PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getName()
            , poolDoAMPooling
            , PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getDefault()
            , params);

         updateScalabilityParam(
            PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getName()
            , poolIsUseExclusive
            , PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getDefault()
            , params);
      }
      catch (Exception ex)
      {
         if (showError)
         {
            ErrorHandler.displayError(mParentFrame, ex);
         }
         return false;
      }
      return true;
   }

   private void updateScalabilityParam(String name, String value, String def, Hashtable params)
   {
      if (!def.equals(value))
      {
         params.put(name, value);
      }
      else
      {
         params.remove(name);
      }
   }

   final void updatePanelUI()
   {
      String poolInitSize = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getName());
      String poolMaxSize = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getName());
      String poolRefSize = (String)mParams.get(PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getName());

      String poolMinAvailSize = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getName());
      String poolMaxAvailSize = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getName());
      String poolMaxInactiveAge = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getName());
      String poolMonitorSleepInterval = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL.getName());

      // connection parameters
      String connPoolInitSize = (String)mParams.get(PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getName());
      String connPoolMaxSize = (String)mParams.get(PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getName());

      String connPoolMinAvailSize = (String)mParams.get(PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getName());
      String connPoolMaxAvailSize = (String)mParams.get(PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getName());
      String connPoolMaxInactiveAge = (String)mParams.get(PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getName());
      String connPoolMonitorSleepInterval = (String)mParams.get(PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getName());

      String poolDoFailover = (String)mParams.get(PropertyMetadata.ENV_DO_FAILOVER.getName());
      String poolDoConnectionPooling = (String)mParams.get(PropertyMetadata.ENV_DO_CONNECTION_POOLING.getName());
      String poolDynamicJdbcCredentials = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getName());
      String poolResetNonTxnState = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getName());
      String poolDoAMPooling = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getName());
      String poolIsUseExclusive = (String)mParams.get(PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getName());

      int poolInitSizeInt = (poolInitSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_AMPOOL_INIT_POOL_SIZE.getDefault()).intValue()
         : Integer.valueOf(poolInitSize).intValue());

      poolInitSizeSpin.setIntValue(poolInitSizeInt < MAX_POOL_SIZE ? poolInitSizeInt : MAX_POOL_SIZE);

      int poolMaxSizeInt = (poolMaxSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MAX_POOL_SIZE.getDefault()).intValue()
         : Integer.valueOf(poolMaxSize).intValue());

      poolMaxSizeSpin.setIntValue(poolMaxSizeInt < MAX_POOL_SIZE ? poolMaxSizeInt : MAX_POOL_SIZE);

      int poolRefSizeInt = (poolRefSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_POOL_RECYCLE_THRESHOLD.getDefault()).intValue()
         : Integer.valueOf(poolRefSize).intValue());

      poolRefSizeSpin.setIntValue(poolRefSizeInt < MAX_POOL_SIZE ? poolRefSizeInt : MAX_POOL_SIZE);

      int poolMinAvailSizeInt = (poolMinAvailSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MIN_AVAIL_SIZE.getDefault()).intValue()
         : Integer.valueOf(poolMinAvailSize).intValue());

      poolMinAvailSizeSpin.setIntValue(poolMinAvailSizeInt < MAX_POOL_SIZE ? poolMinAvailSizeInt : MAX_POOL_SIZE);

      int poolMaxAvailSizeInt = (poolMaxAvailSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_AMPOOL_MAX_AVAIL_SIZE.getDefault()).intValue()
         : Integer.valueOf(poolMaxAvailSize).intValue());

      poolMaxAvailSizeSpin.setIntValue(poolMaxAvailSizeInt < MAX_POOL_SIZE ? poolMaxAvailSizeInt : MAX_POOL_SIZE);

      int inactiveAgeMS = Integer.parseInt(poolMaxInactiveAge == null
         ? PropertyMetadata.ENV_AMPOOL_MAX_INACTIVE_AGE.getDefault() : poolMaxInactiveAge);
      poolMaxInactiveAgeSpin.setIntValue(inactiveAgeMS / 1000);

      int sleepIntervalMS = Integer.parseInt(poolMonitorSleepInterval == null
         ? PropertyMetadata.ENV_AMPOOL_MONITOR_SLEEP_INTERVAL.getDefault() : poolMonitorSleepInterval);
      poolMonitorSleepIntervalSpin.setIntValue(sleepIntervalMS / 1000);

      // connection pool
      int connPoolInitSizeInt = (connPoolInitSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_INIT_JDBC_POOL_SIZE.getDefault()).intValue()
         : Integer.valueOf(connPoolInitSize).intValue());

      connPoolInitSizeSpin.setIntValue(connPoolInitSizeInt < MAX_POOL_SIZE ? connPoolInitSizeInt : MAX_POOL_SIZE);

      int connPoolMaxSizeInt = (connPoolMaxSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_MAX_JDBC_POOL_SIZE.getDefault()).intValue()
         : Integer.valueOf(connPoolMaxSize).intValue());

      connPoolMaxSizeSpin.setIntValue(connPoolMaxSizeInt < MAX_POOL_SIZE ? connPoolMaxSizeInt : MAX_POOL_SIZE);

      int connPoolMinAvailSizeInt = (connPoolMinAvailSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_JDBC_POOL_MIN_AVAIL_SIZE.getDefault()).intValue()
         : Integer.valueOf(connPoolMinAvailSize).intValue());

      connPoolMinAvailSizeSpin.setIntValue(connPoolMinAvailSizeInt < MAX_POOL_SIZE ? connPoolMinAvailSizeInt : MAX_POOL_SIZE);

      int connPoolMaxAvailSizeInt = (connPoolMaxAvailSize == null
         ? Integer.valueOf(PropertyMetadata.ENV_JDBC_POOL_MAX_AVAIL_SIZE.getDefault()).intValue()
         : Integer.valueOf(connPoolMaxAvailSize).intValue());

      connPoolMaxAvailSizeSpin.setIntValue(connPoolMaxAvailSizeInt < MAX_POOL_SIZE ? connPoolMaxAvailSizeInt : MAX_POOL_SIZE);

      int connInactiveAgeMS = Integer.parseInt(connPoolMaxInactiveAge == null
         ? PropertyMetadata.ENV_JDBC_POOL_MAX_INACTIVE_AGE.getDefault() : connPoolMaxInactiveAge);
      connPoolMaxInactiveAgeSpin.setIntValue(connInactiveAgeMS / 1000);

      int connSleepIntervalMS = Integer.parseInt(connPoolMonitorSleepInterval == null
         ? PropertyMetadata.ENV_JDBC_POOL_MONITOR_SLEEP_INTERVAL.getDefault() : connPoolMonitorSleepInterval);
      connPoolMonitorSleepIntervalSpin.setIntValue(connSleepIntervalMS / 1000);

      poolDoFailoverCheck.setSelected(
         poolDoFailover == null
         ? TRUE.equals(PropertyMetadata.ENV_DO_FAILOVER.getDefault())
         : TRUE.equals(poolDoFailover));

      poolDoConnectionPoolingCheck.setSelected(
         poolDoConnectionPooling == null
         ? TRUE.equals(PropertyMetadata.ENV_DO_CONNECTION_POOLING.getDefault())
         : TRUE.equals(poolDoConnectionPooling));

      poolDynamicJdbcCredentialsCheck.setSelected(
         poolDynamicJdbcCredentials == null
         ? TRUE.equals(PropertyMetadata.ENV_AMPOOL_DYNAMIC_JDBC_CREDENTIALS.getDefault())
         : TRUE.equals(poolDynamicJdbcCredentials));

      poolResetNonTxnStateCheck.setSelected(
         poolResetNonTxnState == null
         ? TRUE.equals(PropertyMetadata.ENV_AMPOOL_RESET_NON_TRANSACTIONAL_STATE.getDefault())
         : TRUE.equals(poolResetNonTxnState));

      poolDoAMPoolingCheck.setSelected(
         poolDoAMPooling == null
         ? TRUE.equals(PropertyMetadata.ENV_AMPOOL_DO_AM_POOLING.getDefault())
         : TRUE.equals(poolDoAMPooling));
      setAMPoolingEnabled(poolDoAMPoolingCheck.getModel().isSelected());

      poolIsUseExclusiveCheck.setSelected(
         poolIsUseExclusive == null
         ? TRUE.equals(PropertyMetadata.ENV_AMPOOL_IS_USE_EXCLUSIVE.getDefault())
         : TRUE.equals(poolIsUseExclusive));
      setUseExclusive(poolIsUseExclusiveCheck.getModel().isSelected());

      setConnCapacitiesEditable(!useDataSource());
   }

   private final boolean useDataSource()
   {
      return (mParams.get(Configuration.JDBC_DS_NAME) != null);
   }

}

