/*
 * @(#)TreeForm.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import oracle.jbo.AttributeDef;
import oracle.jbo.ViewLink;
import oracle.jbo.ViewObject;

public final class TreeForm extends SimpleForm
{
   private final JSplitPane  splitter       = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
   private final JSplitPane  treeSplitter   = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
   private final TreePanel   treeView;
   private final JScrollPane rowSetView;
   private final RowSetPanel rowSetPanel;

   public TreeForm(MainFrame frame, ObjTreeNode objNode)
   {
      this(frame, objNode, null);
   }

   public TreeForm(MainFrame frame, ObjTreeNode objNode, ViewLink vl)
   {
      super(frame, objNode, (vl == null) ? null : vl.getSource());

      // Remove the scroll panel from the SimpleForm to put it in the splitter
      remove(scroller);
      scroller.setBorder(BorderFactory.createEmptyBorder());
      add(splitter, BorderLayout.CENTER);
      splitter.setTopComponent(scroller);
      splitter.setBottomComponent(treeSplitter);

      treeView = new TreePanel(frame);
      treeView.setBorder(BorderFactory.createEmptyBorder());

      rowSetPanel = new RowSetPanel(frame);
      rowSetPanel.setBorder(BorderFactory.createEmptyBorder());
      rowSetView = new JScrollPane(rowSetPanel);
      rowSetView.setBorder(BorderFactory.createEmptyBorder());

      ViewObject masterVO =  vl.getSource();

      rowSetPanel.setIterator(masterVO);  // For attribute def only
      rowSetPanel.setIterator(null);      // Remove the values

      treeView.setRowSetPanel(rowSetPanel);

      AttributeDef accessorDef = masterVO.findViewLinkAccessor(vl);
      if (accessorDef != null)
      {
         treeView.setAccessorName(accessorDef.getName());
         treeView.setIterator(masterVO);
      }

      treeSplitter.setTopComponent(treeView);
      treeSplitter.setBottomComponent(rowSetView);

//         treeSplitter.setOneTouchExpandable(true);
//         treeSplitter.setDividerLocation(0.45);
   }
}





