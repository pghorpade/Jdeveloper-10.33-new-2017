/*
 * @(#)BaseTree.java
 * 
 * Copyright 1999-2002 by Oracle Corporation, 500 Oracle Parkway, Redwood
 * Shores, California, 94065, U.S.A. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Oracle
 * Corporation.
 */
package oracle.jbo.jbotester;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import oracle.bali.ewt.util.MenuUtils;
import oracle.jbo.ApplicationModule;
import oracle.jbo.JboExceptionHandler;
import oracle.jbo.JboWarning;
import oracle.jbo.ViewLink;
import oracle.jbo.ViewObject;
import com.sun.java.util.collections.ArrayList;
import com.sun.java.util.collections.HashMap;

public final class BaseTree extends JScrollPane implements ChangeListener,
JboExceptionHandler
{
  private final class ContextMenuAction extends AbstractAction
  {
    public ContextMenuAction()
    {
      super("ctxMenu");
    }
    
    public void actionPerformed(ActionEvent e)
    {
      ObjTreeNode node = getSelection();
      if (node != null)
      {
        JPopupMenu menu = node.getMenu();
        if (menu != null)
        {
          MenuUtils.showPopupMenu(menu, (Component) e.getSource(), 10, 10);
        }
      }
    }
  }

  private final class KeyEnterAction extends AbstractAction
  {
    public KeyEnterAction()
    {
      super("keyEnterAction");
    }
    
    public void actionPerformed(ActionEvent e)
    {
      processEnterKey();
    }
  }
  // Listeners definitons
  private class TesterTreeCellRenderer extends DefaultTreeCellRenderer
  {
    public TesterTreeCellRenderer()
    {
      super();
    }
    
    public Component getTreeCellRendererComponent(JTree tree, Object value,
        boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
    {
      super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row,
          hasFocus);
      try
      {
        ObjTreeNode node = (ObjTreeNode) value;
        if (node != null)
        {
          ImageIcon icon = node.getIcon();
          if (icon != null)
          {
            setIcon(icon);
          }
        } else
        {
          if (leaf)
          {
            setIcon(getDefaultOpenIcon());
          }
        }
      }
      // Mostly to catch class cast exception when the tree is being
      // initialize. Also if anything goes wrong it is better to get
      // the default icon than an exception...
      catch (Exception ex)
      {
      }
      return this;
    }
  }
  private final class TreeMouseListener implements MouseListener
  {
    public void mouseClicked(MouseEvent e)
    {
      processTreeMouseClicked(e);
    }
    
    public void mouseEntered(MouseEvent e)
    {
    }
    
    public void mouseExited(MouseEvent e)
    {
    }
    
    public void mousePressed(MouseEvent e)
    {
      checkIsPopupTrigger(e);
    }
    
    public void mouseReleased(MouseEvent e)
    {
      checkIsPopupTrigger(e);
    }
    
    private void checkIsPopupTrigger(MouseEvent e)
    {
      if (e.isPopupTrigger())
      {
        ObjTreeNode loc = hitTest(e);
        if (loc != null)
        {
          JPopupMenu menu = loc.getMenu();
          if (menu != null)
          {
            Point p = e.getPoint();
            TreePath path = tree.getPathForLocation(p.x, p.y);
            tree.setSelectionPath(path);
            MenuUtils.showPopupMenu(menu, tree, p.x, p.y);
          }
        }
      }
    }
  }
  private final TesterTreeCellRenderer cellRenderer   = new TesterTreeCellRenderer();
  private final Action                 ctxMenuAction  = new ContextMenuAction();
  private final Action                 keyEnterAction = new KeyEnterAction();
  // Aggregate the tree control
  private final JTree                  tree;
  
  public BaseTree()
  {
    super();
    tree = new JTree(new DefaultMutableTreeNode("AM"));
    tree.setEditable(false);
    tree.setAutoscrolls(true);
    // Double click should only show the object not expand the node.
    // By setting it to 5 we make sure it never happen.
    tree.setToggleClickCount(5);
    tree.addMouseListener(new TreeMouseListener());
    tree.addTreeSelectionListener(new TreeSelectionListener()
        {
      public void valueChanged(TreeSelectionEvent e)
      {
        nodeSelected(e);
      }
        });
    ResultWindow.getResultWindow().addChangeListener(this);
    registerKeyboardAction(ctxMenuAction, KeyStroke.getKeyStroke(
        KeyEvent.VK_F10, ActionEvent.SHIFT_MASK),
        JComponent.WHEN_IN_FOCUSED_WINDOW);
    registerKeyboardAction(keyEnterAction, KeyStroke.getKeyStroke(
        KeyEvent.VK_ENTER, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
    setViewportView(tree);
  }
  
  public ObjTreeNode addChild(DefaultMutableTreeNode parent, ObjTreeNode child)
  {
    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
    if (parent == null)
    {
      parent = (DefaultMutableTreeNode) model.getRoot();
    }
    model.insertNodeInto(child, parent, parent.getChildCount());
    //      tree.scrollPathToVisible(new TreePath(child.getPath()));
    return child;
  }
  
  public void clearAll()
  {
    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
    if (model != null)
    {
      DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
      if (root != null)
      {
        root.removeAllChildren();
        model.reload();
      }
    }
  }
  
  public void createDynViewObject()
  {
    ObjTreeNode selTreeNode = getSelection();
    if (selTreeNode == null)
    {
      return;
    }
    ObjTreeNode parentAM = selTreeNode.getParentOfType(ObjTreeNode.APP_MODULE);
    if (parentAM == null)
    {
      return;
    }
    VODialog vod = new VODialog(MainFrame.getInstance(),
        (ApplicationModule) parentAM.getData());
    vod.show();
    ViewObject vo = vod.getViewObject();
    if (vo == null)
    {
      return;
    }
    VOTreeNode child = new VOTreeNode(vo);
    // $$$ Need to add the vo before the first nested AM
    addChild(parentAM, child);
    tree.makeVisible(new TreePath(child.getPath()));
  }
  
  public void finishedProcessingPiggyback(Exception[] exArr)
  {
  }
  
  public Object getSelectedObject()
  {
    ObjTreeNode node = getSelection();
    if (node == null)
    {
      return null;
    }
    return node.getData();
  }
  
  /*
   * private void expandNode(ObjTreeNode node) { tree.fireTreeExpanded(new
   * TreePath(node.getPath())); }
   */
  //
  // JboExceptionHandler interface implementation
  //
  public void handleException(Exception ex, boolean lastEntryInPiggyback)
  {
    ErrorHandler.displayError(MainFrame.getInstance(), ex);
  }
  
  public void handleWarning(JboWarning warn)
  {
    ErrorHandler.displayError(MainFrame.getInstance(), warn.getMessage());
  }
  
  public ObjTreeNode insertChild(DefaultMutableTreeNode parent,
      ObjTreeNode child, int index)
  {
    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
    if (parent == null)
    {
      parent = (DefaultMutableTreeNode) model.getRoot();
    }
    model.insertNodeInto(child, parent, index);
    //      tree.scrollPathToVisible(new TreePath(child.getPath()));
    return child;
  }
  
  public void nodeSelected(TreeSelectionEvent e)
  {
    ObjTreeNode node = (ObjTreeNode) e.getPath().getLastPathComponent();
    MainFrame.getInstance().getStatusLine().setText(node.getStatus());
  }
  
  public void reload(TreeNode node)
  {
    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
    model.reload(node);
  }
  
  public void removeFromParent(DefaultMutableTreeNode node)
  {
    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
    model.removeNodeFromParent(node);
  }
  
  public void setAppModule(ApplicationModule appMod)
  {
    // Can't do it before nodes are ObjTreeNodes
    tree.setCellRenderer(cellRenderer);
    appMod.setExceptionHandler(this);
    // Create the root node (root application module)
    AMTreeNode rootNode = new AMTreeNode(appMod);
    tree.setModel(new DefaultTreeModel(rootNode));
    // Build the tree of under it
    createAppModuleChildren(rootNode);
    selectNode(rootNode);
    requestFocus();
  }
  
  // ChangeListener implementation
  public void stateChanged(ChangeEvent e)
  {
    if (e.getSource() instanceof ResultWindow)
    {
      ResultWindow rw = (ResultWindow) e.getSource();
      SimpleForm f = (SimpleForm) rw.getSelectedTab();
      if (f != null)
      {
        selectNode(f.getTreeNode());
      }
    }
  }
  
  private void createAppModuleChildren(AMTreeNode amNode)
  {
    ApplicationModule appMod = (ApplicationModule) amNode.getData();
    String[] voNames = appMod.getViewObjectNames(true, true);
    Arrays.sort(voNames);
    HashMap nodes = new HashMap();
    ArrayList leaves = new ArrayList();
    for (int i = 0; i < voNames.length; i++)
    {
      // If the node is already in the tree, don't need to add it.
      if (nodes.containsKey(voNames[i]))
      {
        continue;
      }
      // Recurse into building the link tree
      descendViewObject(voNames[i], appMod, amNode, nodes, leaves);
    }
    for (int i = 0; i < leaves.size(); i++)
    {
      tree.makeVisible(new TreePath(((ObjTreeNode) leaves.get(i)).getPath()));
    }
    String[] amNames = appMod.getApplicationModuleNames(true, true);
    for (int i = 0; i < amNames.length; i++)
    {
      ApplicationModule nestedAppMod = appMod.findApplicationModule(amNames[i]);
      if (nestedAppMod != null)
      {
        AMTreeNode child = new AMTreeNode(nestedAppMod);
        addChild(amNode, child);
        //            amNode.add(child);
        // Recurse into appModules
        createAppModuleChildren(child);
      }
    }
  }
  
  private VOTreeNode descendViewObject(String voName, ApplicationModule appMod,
      ObjTreeNode parent, HashMap nodes, ArrayList leaves)
  {
    VOTreeNode voNode = new VOTreeNode(appMod, voName);
    boolean isLeaf = true;
    String[] vlNames = appMod.getViewLinkNames(true, true);
    for (int j = 0; j < vlNames.length; j++)
    {
      ViewLink vl = appMod.findViewLink(vlNames[j]);
      // Is there a link with a source matching this vo?
      if (voName.equals(vl.getSource().getName()))
      {
        isLeaf = false;
        VLTreeNode vlNode = new VLTreeNode(appMod, vl);
        voNode.add(vlNode);
        String voDestName = vl.getDestination().getName();
        VOTreeNode voDestNode = (VOTreeNode) nodes.get(voDestName);
        if (voDestNode == null)
        {
          voDestNode = descendViewObject(voDestName, appMod, vlNode, nodes,
              leaves);
        } else
        {
          // For multiple master the same destination node is
          // going to appear multiple time. Don't recurse because the detail
          // tree
          // does not need to be repeated for the second master.
          if (((ObjTreeNode) voDestNode.getParent()).getType() == ObjTreeNode.VIEW_LINK)
          {
            voDestNode = new VOTreeNode(appMod, vl.getDestination());
          } else
          {
            // This is the case where the destination VO has
            // already been treated and is currently dangling on the root.
            parent = (ObjTreeNode) voDestNode.getParent();
            // Don't need parent.remove(voDestNode) because it is
            // done by the vlNode.add() (by virtue of insert)
          }
          vlNode.add(voDestNode);
          leaves.add(voDestNode);
        }
      }
    }
    parent.add(voNode);
    if (isLeaf)
    {
      leaves.add(voNode);
    }
    nodes.put(voName, voNode);
    return voNode;
  }
  
  private ObjTreeNode getSelection()
  {
    TreePath currentSelection = tree.getSelectionPath();
    if (currentSelection != null)
    {
      return (ObjTreeNode) (currentSelection.getLastPathComponent());
    }
    return null;
  }
  
  private ObjTreeNode hitTest(MouseEvent e)
  {
    Point p = e.getPoint();
    int selRow = tree.getRowForLocation(p.x, p.y);
    TreePath path = tree.getPathForLocation(p.x, p.y);
    if (selRow != -1)
    {
      return (ObjTreeNode) path.getLastPathComponent();
    }
    return null;
  }
  
  private void processEnterKey()
  {
    ObjTreeNode node = this.getSelection();
    if (node != null)
    {
      node.showForm();
    }
  }
  
  private void processTreeMouseClicked(MouseEvent e)
  {
    // Double click only
    if (e.getClickCount() == 1)
    {
      return;
    }
    // Need to be on a node
    ObjTreeNode loc = hitTest(e);
    if (loc == null)
    {
      return;
    }
    loc.showForm();
  }
  
  private void selectNode(ObjTreeNode node)
  {
    tree.setSelectionPath(new TreePath(node.getPath()));
  }
  
  void createApplicationModule()
  {
    ObjTreeNode selTreeNode = getSelection();
    if (selTreeNode == null)
    {
      return;
    }
    createApplicationModule(selTreeNode);
  }
  
  void createApplicationModule(ObjTreeNode selTreeNode)
  {
    ObjTreeNode parentAM = selTreeNode.getParentOfType(ObjTreeNode.APP_MODULE);
    if (parentAM == null)
    {
      return;
    }
    AMDialog amd = new AMDialog(MainFrame.getInstance(),
        (ApplicationModule) parentAM.getData());
    amd.show();
    ApplicationModule childAppMod = amd.getApplicationModule();
    if (childAppMod == null)
    {
      return;
    }
    AMTreeNode node = new AMTreeNode(childAppMod);
    addChild(parentAM, node);
    tree.makeVisible(new TreePath(node.getPath()));
    createAppModuleChildren(node);
  }
  
  void createDynViewLink()
  {
    ObjTreeNode selTreeNode = getSelection();
    if (selTreeNode == null)
    {
      return;
    }
    ObjTreeNode parentAM = selTreeNode.getParentOfType(ObjTreeNode.APP_MODULE);
    if (parentAM == null)
    {
      return;
    }
    ApplicationModule am = (ApplicationModule) parentAM.getData();
    if (am.getViewObjectNames().length <= 1)
    {
      ErrorHandler.displayError(MainFrame.getInstance(), Res
          .getString(Res.TREE_CREATE_VL_ERROR));
      return;
    }
    VLDialog vld = new VLDialog(MainFrame.getInstance(), am);
    vld.show();
    ViewLink vl = vld.getViewLink();
    if (vl == null)
    {
      return;
    }
    VLTreeNode child = new VLTreeNode(vl);
    //Retrieve the destination VO node for this link node
    VOTreeNode voDestNode = (VOTreeNode) parentAM.getChildOfName(vl
        .getDestination().getName());
    removeFromParent(voDestNode);
    child.add(voDestNode);
    // Retrieve the parent VO node for this link node
    VOTreeNode voSrcNode = (VOTreeNode) parentAM.getChildOfName(vl.getSource()
        .getName());
    // $$$ Need to add the vo before the first nested AM
    addChild(voSrcNode, child);
    tree.makeVisible(new TreePath(voSrcNode.getPath()));
    tree.makeVisible(new TreePath(child.getPath()));
    tree.makeVisible(new TreePath(voDestNode.getPath()));
  }
}
