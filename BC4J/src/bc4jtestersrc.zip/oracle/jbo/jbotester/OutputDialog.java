/*
 * @(#)OutputDialog.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;
import oracle.jbo.common.ResourceUtils;

public class OutputDialog extends JDialog
{
   MainFrame mainFrame;

   private JPanel mPanel      = new JPanel();
   private JPanel buttonPanel = new JPanel();
   private JButton saveButt   = new JButton();
   private JButton closeButt  = new JButton();
   private JPanel  textAreaPanel = new JPanel();
   private JTextArea textArea = new JTextArea();
   private FileFilter fileFilter = null;
   private String fileName = "";

   public OutputDialog(MainFrame parent, String title, boolean modal)
   {
      super(parent, title, modal);
      
      mainFrame = parent;

      try
      {
         jbInit();
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(mainFrame, e);
      }
   }
   private void jbInit() throws Exception
   {
      mPanel.setPreferredSize(new Dimension(450, 350));
      mPanel.setMinimumSize(new Dimension(200, 100));
      mPanel.setLayout(new BorderLayout());

      // Make Sure to Disable Save Button in the Applet Mode.
      textAreaPanel.setLayout(new BorderLayout());

      // KM: 06Aug04 - grepping about I find this stuff in common to help here bug3684579
      ResourceUtils.resButton(saveButt, Res.getString(Res.OUTPUT_DIALOG_SAVE_BUTTON));
      ResourceUtils.resButton(closeButt, Res.getString(Res.DIALOG_CLOSE_BUTTON));
            
      buttonPanel.add(saveButt);
      saveButt.addActionListener( new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            saveData();
         }
      });

      buttonPanel.add(closeButt);
      closeButt.addActionListener( new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            setVisible(false);
            dispose();
         }
      });
      
      textAreaPanel.add(textArea, BorderLayout.CENTER);
      textArea.setEditable(false);
      mPanel.add(
         new JScrollPane(  textAreaPanel,
                           JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                           JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS),
         BorderLayout.CENTER);
      mPanel.add(buttonPanel, BorderLayout.SOUTH);
      getContentPane().add(mPanel);
   }

   private void saveData()
   {
      try
      {
         JFileChooser filer = new JFileChooser();
         if(this.fileFilter!=null)
         {
           filer.setSelectedFile(new File(this.fileName));           
           filer.addChoosableFileFilter(this.fileFilter);
         }
         if (filer.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
         {
            FileOutputStream fos = new FileOutputStream(filer.getSelectedFile());
            fos.write(textArea.getText().getBytes());
            fos.close();
         }
      }
      catch(Exception e)
      {
         ErrorHandler.displayError(mainFrame, e);
      }
   }

   public void setFileFilter(FileFilter fileFilter)
   {
     this.fileFilter = fileFilter;
   }
   
   public void setFileName(String fileName)
   {
     this.fileName = fileName;
   }
   
   public void setText(String text)
   {
      textArea.setText(text);
      this.setSize(this.getSize().width+1, this.getSize().height+1);
      mPanel.revalidate();
   }
}

