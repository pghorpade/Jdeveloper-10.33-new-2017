/* $Header: Property.java 22-jun-2005.14:41:33 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
   A Property contains the data for a single BC4J configuration property
   for editing purposes. It contains the actual name/value as well
   as description (tooltip) and modification identifiers

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     06/22/05 - rvangri_connectiondialogbase_20050622
    rvangri     06/22/05 - Creation
 */

/**
 *  @version $Header: Property.java 22-jun-2005.14:41:33 rvangri Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
package oracle.jbo.jbotester;

import com.sun.java.util.collections.Comparable;

public final class Property implements Comparable
{
  boolean canRemove;
  String  desc;
  boolean isModified;
  boolean isNew;
  String  key;
  boolean readOnly;
  String  value;
  
  public Property(String k, String v, String d, boolean ro, boolean n,
      boolean m, boolean c)
  {
    key = k;
    value = v;
    desc = d;
    readOnly = ro;
    isNew = n;
    isModified = m;
    canRemove = c;
  }
  
  // Comparable interface
  /**
   * Compares this object with the specified object for order. Returns a
   * negative integer, zero, or a positive integer as this object is less than,
   * equal to, or greater than the specified object.
   *  
   */
  public int compareTo(Object o)
  {
    if (o instanceof Property)
    {
      Property other = (Property) o;
      String otherKey = other.key;
      // ignore case
      return key.toLowerCase().compareTo(otherKey.toLowerCase());
    }
    return -1; // we dont know, it's certainly not equal
  }
}
