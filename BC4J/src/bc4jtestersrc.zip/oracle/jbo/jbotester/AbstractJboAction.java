/*
 * @(#)AbstractJboAction.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;

abstract class AbstractJboAction extends AbstractAction
{
  private boolean isDelayedValidation = false;
  
   //Constructor without icon
   public AbstractJboAction(String name)
   {
      super(JboTesterUtil.stripMnemonic(name));
      init(name, -1);
   }

   //Constructor with icon
   public AbstractJboAction(String name, int index, int tooltipResId)
   {
      super(JboTesterUtil.stripMnemonic(name), JboTesterUtil.getIcon(NavBar.images[index][0]));
      init(name, tooltipResId);
   }

  /**
   * This flag determines if we should wait with performing validations until 
   * the action command has been executed.
   * @return true if validation should be postponed
   */
  public boolean isDelayedValidation()
  {
  //used in JBOFieldHelper on the lost focus event. 
  //if we leave a field, we need to validate.
  //but if we leave to execute 'rollback', then validate is not needed
  //in fact, if we have invalid data, we can only rollback without performing validation
    return this.isDelayedValidation;
  }

  protected void setDelayedValidation()
  {
    this.isDelayedValidation = true;
  }
  
   private void init(String name, int tooltipResId)
   {
      int mnemonic  = JboTesterUtil.getMnemonicKeyCode(name);
      if (mnemonic != 0)
      {
         putValue(Action.MNEMONIC_KEY, new Integer(mnemonic));
      }
      
      if (tooltipResId >=0)
      {
         putValue(Action.SHORT_DESCRIPTION, Res.getString(tooltipResId));
      }
   }
   
   abstract void doAction(ActionEvent e);
   abstract MainFrame getMainFrame();

   public void actionPerformed(ActionEvent e)
   {
      if (ErrorHandler.isUp())
      {
         return;
      }

      try
      {
         doAction(e);
      }
      catch(Exception ex)
      {
         ErrorHandler.displayError(getMainFrame(), ex);
      }
   }
}

