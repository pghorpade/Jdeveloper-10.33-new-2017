/*
 * @(#)ChattySecurityManager.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.io.FileDescriptor;
import java.net.InetAddress;

public class ChattySecurityManager extends SecurityManager
{

   private static final boolean ALLOW_ALL=false;

   public ChattySecurityManager()
   {
      System.out.println("Constructed Securitymanager " + System.getProperty("java.version"));
   }
   // From Java in a nutshell v1.1 p140
   static private String[] allowedProps =
      {
        "java.version",             // Documented as allowed properties
        "java.class.version",
        "java.vendor",
        "java.vendor.url",
        "os.name",
        "os.version",
        "os.arch",
        "file.separator",
        "path.separator",
        "line.separator",
        //-----------------
        //"awt.appletWarning",
        //"awt.font.dialog",
        //"awt.image.incrementaldraw",
        //"awt.image.redrawrate",
        //----------
        //"java.home",
        "user.home",
        "user.language",
        "user.region",
        "user.timezone",
        "user.name",
        //"oracle.xml.parser.debugmode",
        "file.encoding.pkg",
        "file.encoding",
        "impl.prefix",
        "socksProxyHost",
        "java.protocol.handler.pkgs",
        "jdbc.drivers",
        //"swing.auxiliarylaf",
        //"swing.defaultlaf",
        //"swing.installedlafs",
        //"swing.plaf.multiplexinglaf",
        // -------------- JDK 1.2 needed
        //"content.types.temp.file.template",
        //"content.types.user.table",
        //"user.mailcap",
        //"hotjava.home",
        //"sun.net.inetaddr.ttl",
        //"debug" // this is fixed: JDK 1.1.8 bug in BitSet
        "fooeybarrrrrr"
       };
   public void checkPropertyAccess(String key)
   {
      checkPropertyAccess(key, "");
   }

   public void checkPropertyAccess(String key, String def)
   {
      if (ALLOW_ALL)
      {
         t("ALLOW_ALL ok PropertyAccess",key, def);
         return;
      }

      if (key.startsWith("awt") || key.startsWith("sun") || key.startsWith("java"))
      {
         //t("allowing PropertyAccess",key, def);
         return;
      }

      for (int i=0;i < allowedProps.length; i++)
      {
          if (key.equals(allowedProps[i]))
          {
             //t("allowing PropertyAccess",key,def);
             return;
          }
      }

      t("denying PropertyAccess",key,def);
      throw new SecurityException("propertyAccess '" + key + "' denied");
      //return;
   }

   public void checkCreateClassLoader() { t("CreateClassLoader");}
   public void checkAccess(Thread g) { t("Access", g);}
   public void checkAccess(ThreadGroup g) { t("Access", g);}
   public void checkExit(int status) { t("Exit");}
   public void checkExec(String cmd) { t("Exec",cmd);}
   public void checkLink(String lib) { t("Link",lib);}
   public void checkRead(FileDescriptor fd) { t("Read",fd);}
   public void checkRead(String file) { t("Read", file);}
   public void checkRead(String file, Object context) { t("Read",file);}
   public void checkWrite(FileDescriptor fd) { t("Write",fd);}
   public void checkWrite(String file) { t("Write",file);}
   public void checkDelete(String file) { t("Delete",file);}
   public void checkConnect(String host, int port) { t("Connect",host, new Integer(port));}
   public void checkConnect(String host, int port, Object context) { t("Connect",host,new Integer(port));}
   public void checkListen(int port) { t("Listen",new Integer(port));}
   public void checkAccept(String host, int port) { t("");}
   public void checkMulticast(InetAddress maddr) { t("Multicast", maddr);}
   /**
   * @deprecated
   */
  public void checkMulticast(InetAddress maddr, byte ttl)
  {
    t("Multicast", maddr, new Byte(ttl));
  }
   public void checkPropertiesAccess() { t("PropertiesAccess");}
   public boolean checkTopLevelWindow(Object window) { return true; }
   public void checkPrintJobAccess() { t("PrintJobAccess");}
   public void checkSystemClipboardAccess() { t("SystemClipboardAccess");}
   public void checkAwtEventQueueAccess() { t("AwtEventQueueAccess");}
   public void checkPackageAccess(String pkg) { t("PackageAccess", pkg);}
   public void checkPackageDefinition(String pkg) { t("PackageDefinition", pkg);}
   public void checkSetFactory() { t("SetFactory");}
   public void checkMemberAccess(Class clazz, int which) { t("MemberAccess", clazz, new Integer(which));}
   public void checkSecurityAccess(String provider) { t("SecurityAccess", provider);}

   private void t(String method)
   {
      t(method,"");
   }
   private static void t(String method, String message)
   {
      System.out.println("check" + method + ": " + message );
   }
   private static void t(String method, Object p1)
   {
      t(method, p1.toString());
   }

   private static void t(String method, Object p1, Object p2)
   {
      t(method, p1.toString() + "," + p2.toString());
   }

}

