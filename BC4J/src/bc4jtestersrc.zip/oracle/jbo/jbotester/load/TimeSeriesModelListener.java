package oracle.jbo.jbotester.load;

public interface TimeSeriesModelListener 
{
   public void modelChanged();
}
