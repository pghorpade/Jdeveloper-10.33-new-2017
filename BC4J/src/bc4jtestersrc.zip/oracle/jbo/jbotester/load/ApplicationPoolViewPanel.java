package oracle.jbo.jbotester.load;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Component;

import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.Statistics;

public class ApplicationPoolViewPanel extends JPanel
{
   private Controller mController;

   private JLabel mNumOfAMCreationsLabel = new JLabel("0");
   private JLabel mNumOfAMRemovalsLabel = new JLabel("0");
   private JLabel mNumOfAMActivationsLabel = new JLabel("0");
   private JLabel mNumOfAMPassivationsLabel = new JLabel("0");
   private JLabel mNumOfAMCheckoutsLabel = new JLabel("0");
   private JLabel mNumOfAMCheckinsLabel = new JLabel("0");
   private JLabel mNumOfRefAMReuseLabel = new JLabel("0");
   private JLabel mNumOfRefAMRecycleLabel = new JLabel("0");
   private JLabel mNumOfUnrefAMRecycleLabel = new JLabel("0");
   private JLabel mNumOfAMsLabel = new JLabel("0");
   private JLabel mMaxNumOfAMsLabel = new JLabel("0");
   private JLabel mAvgNumOfAMsLabel = new JLabel("0");
   private JLabel mNumOfAvailAMsLabel = new JLabel("0");
   private JLabel mNumOfRefAMsLabel = new JLabel("0");
   private JLabel mNumOfRefAMs10Label = new JLabel("0");
   private JLabel mNumOfRefAMs5Label = new JLabel("0");
   private JLabel mNumOfRefAMs1Label = new JLabel("0");
   private JLabel mNumOfRefAMs0Label = new JLabel("0");
   private JLabel mNumOfAMs10Label = new JLabel("0");
   private JLabel mNumOfAMs5Label = new JLabel("0");
   private JLabel mNumOfAMs1Label = new JLabel("0");
   private JLabel mNumOfAMs0Label = new JLabel("0");
   private JLabel mNumOfSessionsLabel = new JLabel("0");
   private JLabel mAvgNumOfSessionsLabel = new JLabel("0");
   private JLabel mNumOfSessions10Label = new JLabel("0");
   private JLabel mNumOfSessions5Label = new JLabel("0");
   private JLabel mNumOfSessions1Label = new JLabel("0");
   private JLabel mNumOfSessions0Label = new JLabel("0");

   public ApplicationPoolViewPanel(Controller controller)
   {
      super();

      mController = controller;

      init();
   }

   void init()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      setLayout(layout);

//      setBorder(BorderFactory.createTitledBorder("ApplicationPool Statistics"));
         
      // shared contrainst settings:
      constraints.gridx = 0;
      constraints.gridy = 0;
      setAlignmentY(Component.TOP_ALIGNMENT);

      JLabel label = new JLabel("ApplicationModule lifetime statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of ApplicationModule creations:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMCreationsLabel);

      label = new JLabel("Number of ApplicationModule removals:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMRemovalsLabel);

      label = new JLabel("ApplicationModule state management statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of state activations:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMActivationsLabel);

      label = new JLabel("Number of state passivations:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMPassivationsLabel);


      label = new JLabel("ApplicationPool use statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of pool uses:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMCheckoutsLabel);

      label = new JLabel("Number of pool releases:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMCheckinsLabel);

      label = new JLabel("Number of referenced ApplicationModules that were reused:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMReuseLabel);

      label = new JLabel("Number of referenced ApplicationModules that were recycled:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMRecycleLabel);
      
      label = new JLabel("Number of unreferenced ApplicationModules that were recycled:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfUnrefAMRecycleLabel);

      label = new JLabel("ApplicationModule statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of ApplicationModules in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMsLabel);

      label = new JLabel("Maximum number of ApplicationModules in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mMaxNumOfAMsLabel);

      label = new JLabel("Average number of ApplicationModules in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mAvgNumOfAMsLabel);

      label = new JLabel("Number of available ApplicationModules in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAvailAMsLabel);

      label = new JLabel("Number of referenced ApplicationModules in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMsLabel);

      label = new JLabel("ApplicationModule age statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of referenced instances unused for >10 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMs10Label);

      label = new JLabel("Number of referenced instances unused for >5 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMs5Label);

      label = new JLabel("Number of referenced instances unused for >1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMs1Label);

      label = new JLabel("Number of referenced instances used during last 1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfRefAMs0Label);

      label = new JLabel("Number of instances unused for >10 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMs10Label);

      label = new JLabel("Number of instances unused for >5 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMs5Label);

      label = new JLabel("Number of instances unused for >1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMs1Label);

      label = new JLabel("Number of instances used during last 1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAMs0Label);

      label = new JLabel("Session statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of sessions registered with the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfSessionsLabel);

      label = new JLabel("Average number of sessions referencing state:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mAvgNumOfSessionsLabel);

      label = new JLabel("Session age statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of sessions inactive for >10 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfSessions10Label);

      label = new JLabel("Number of sessions inactive for >5 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfSessions5Label);

      label = new JLabel("Number of sessions inactive for >1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfSessions1Label);

      label = new JLabel("Number of sessions active during last 1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfSessions0Label);
   }

   void resetPanelUI()
   {
      mNumOfAMCreationsLabel.setText("0");
      mNumOfAMRemovalsLabel.setText("0");
      mNumOfAMActivationsLabel.setText("0");
      mNumOfAMPassivationsLabel.setText("0");
      mNumOfAMCheckoutsLabel.setText("0");
      mNumOfAMCheckinsLabel.setText("0");
      mNumOfRefAMReuseLabel.setText("0");
      mNumOfRefAMRecycleLabel.setText("0");
      mNumOfUnrefAMRecycleLabel.setText("0");
      mNumOfAMsLabel.setText("0");
      mMaxNumOfAMsLabel.setText("0");
      mAvgNumOfAMsLabel.setText("0");
      mNumOfAvailAMsLabel.setText("0");
      mNumOfRefAMsLabel.setText("0");
      mNumOfRefAMs10Label.setText("0");
      mNumOfRefAMs5Label.setText("0");
      mNumOfRefAMs1Label.setText("0");
      mNumOfRefAMs0Label.setText("0");
      mNumOfAMs10Label.setText("0");
      mNumOfAMs5Label.setText("0");
      mNumOfAMs1Label.setText("0");
      mNumOfAMs0Label.setText("0");
      mNumOfSessionsLabel.setText("0");
      mAvgNumOfSessionsLabel.setText("0");
      mNumOfSessions10Label.setText("0");
      mNumOfSessions5Label.setText("0");
      mNumOfSessions1Label.setText("0");
      mNumOfSessions0Label.setText("0");
   }

   void updatePanelUI()
   {
      ApplicationPool pool = mController.getApplicationPool(false);
      if (pool != null)
      {
         Statistics stats = pool.getStatistics();
      
         mNumOfAMCreationsLabel.setText(new Long(stats.mNumOfInstanceCreations).toString());
         mNumOfAMRemovalsLabel.setText(new Long(stats.mNumOfInstanceRemovals).toString());
         mNumOfAMActivationsLabel.setText(new Long(stats.mNumOfStateActivations).toString());
         mNumOfAMPassivationsLabel.setText(new Long(stats.mNumOfStatePassivations).toString());
         mNumOfAMCheckoutsLabel.setText(new Long(stats.mNumOfCheckouts).toString());
         mNumOfAMCheckinsLabel.setText(new Long(stats.mNumOfCheckins).toString());
         mNumOfRefAMReuseLabel.setText(new Long(stats.mNumOfInstancesReused).toString());
         mNumOfRefAMRecycleLabel.setText(new Long(stats.mNumOfReferencedInstancesRecycled).toString());
         mNumOfUnrefAMRecycleLabel.setText(new Long(stats.mNumOfUnreferencedInstancesRecycled).toString());
         mNumOfAMsLabel.setText(new Integer(stats.mResourceCount).toString());
         mMaxNumOfAMsLabel.setText(new Long(stats.mMaxNumOfInstances).toString());
         mAvgNumOfAMsLabel.setText(new Long(stats.mAvgNumOfInstances).toString());
         mNumOfAvailAMsLabel.setText(new Integer(stats.mAvailableResourceCount).toString());
         mNumOfRefAMsLabel.setText(new Integer(stats.mReferencedApplicationModules).toString());
         mNumOfRefAMs10Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[3]).toString());
         mNumOfRefAMs5Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[2]).toString());
         mNumOfRefAMs1Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[1]).toString());
         mNumOfRefAMs0Label.setText(new Integer(stats.mRefInstanceAgeHistogram.mBuckets[0]).toString());
         mNumOfAMs10Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[3]).toString());
         mNumOfAMs5Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[2]).toString());
         mNumOfAMs1Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[1]).toString());
         mNumOfAMs0Label.setText(new Integer(stats.mUnrefInstanceAgeHistogram.mBuckets[0]).toString());
         mNumOfSessionsLabel.setText(new Integer(stats.mNumOfSessions).toString());
         mAvgNumOfSessionsLabel.setText(new Long(stats.mAvgNumOfSessionsReferencingState).toString());
         mNumOfSessions10Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[3]).toString());
         mNumOfSessions5Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[2]).toString());
         mNumOfSessions1Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[1]).toString());
         mNumOfSessions0Label.setText(new Integer(stats.mSessionAgeHistogram.mBuckets[0]).toString());
      }
   }

   void close()
   {
      mController = null;
   }
}
