package oracle.jbo.jbotester.load;

public class TaskThread extends Thread
{
   private TaskQueue mTaskQueue;
   
   TaskThread(TaskQueue taskQueue)
   {
      mTaskQueue = taskQueue;
   }

   public void run()
   {
      TaskThreadPool pool = (TaskThreadPool)TaskThreadPoolManager
         .getInstance()
         .getResourcePool(TaskThreadPoolManager.SINGLETON_POOL_NAME);
         
      while(!mTaskQueue.isClosing())
      {
         Task task = mTaskQueue.dequeue();

         if (task != null)
         {
            task.run();
         }
      }

      pool.notifyThreadCompleted();
   }
}