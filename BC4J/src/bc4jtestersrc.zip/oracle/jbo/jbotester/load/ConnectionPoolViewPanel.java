package oracle.jbo.jbotester.load;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Component;

import java.util.Enumeration;

import oracle.jbo.pool.ResourcePoolStatistics;
import oracle.jbo.pool.ResourcePoolManager;
import oracle.jbo.pool.ResourcePool;

import oracle.jbo.server.ConnectionPoolManagerFactory;
import oracle.jbo.server.ConnectionPoolManager;

public class ConnectionPoolViewPanel extends JPanel
{
//   private Controller mController;

   private JLabel mNumOfConnCreationsLabel = new JLabel("0");
   private JLabel mNumOfConnRemovalsLabel = new JLabel("0");
   private JLabel mNumOfConnCheckoutsLabel = new JLabel("0");
   private JLabel mNumOfConnCheckinsLabel = new JLabel("0");
   private JLabel mNumOfConnsLabel = new JLabel("0");
   private JLabel mMaxNumOfConnsLabel = new JLabel("0");
   private JLabel mAvgNumOfConnsLabel = new JLabel("0");
   private JLabel mNumOfAvailConnsLabel = new JLabel("0");
   private JLabel mNumOfConns10Label = new JLabel("0");
   private JLabel mNumOfConns5Label = new JLabel("0");
   private JLabel mNumOfConns1Label = new JLabel("0");
   private JLabel mNumOfConns0Label = new JLabel("0");

   public ConnectionPoolViewPanel(Controller controller)
   {
      super();

//      mController = controller;

      init();
   }

   void init()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      setLayout(layout);

//      setBorder(BorderFactory.createTitledBorder("ConnectionPool Statistics"));
         
      // shared contrainst settings:
      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      setAlignmentY(Component.TOP_ALIGNMENT);

      JLabel label = new JLabel("Connection lifetime statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of Connection creations:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConnCreationsLabel);

      label = new JLabel("Number of Connection removals:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConnRemovalsLabel);

      label = new JLabel("ConnectionPool use statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of Connection uses:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConnCheckoutsLabel);

      label = new JLabel("Number of Connection releases:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConnCheckinsLabel);

      label = new JLabel("Connection statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of Connections in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConnsLabel);

      label = new JLabel("Maximum number of Connections in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mMaxNumOfConnsLabel);

      label = new JLabel("Average number of Connections in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mAvgNumOfConnsLabel);

      label = new JLabel("Number of available Connections in the pool:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfAvailConnsLabel);

      label = new JLabel("Connection age statistics");
      UIHelper.buildPoolHeaderRow(
         this
         , constraints
         , layout
         , label);

      label = new JLabel("Number of Connections unused for >10 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConns10Label);

      label = new JLabel("Number of Connections unused for >5 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConns5Label);

      label = new JLabel("Number of Connections unused for >1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConns1Label);

      label = new JLabel("Number of Connections used during last 1 min:");
      UIHelper.buildPoolRow(
         this
         , constraints
         , layout
         , label
         , mNumOfConns0Label);
   }

   void resetPanelUI()
   {
      mNumOfConnCreationsLabel.setText("0");
      mNumOfConnRemovalsLabel.setText("0");
      mNumOfConnCheckoutsLabel.setText("0");
      mNumOfConnCheckinsLabel.setText("0");
      mNumOfConnsLabel.setText("0");
      mMaxNumOfConnsLabel.setText("0");
      mAvgNumOfConnsLabel.setText("0");
      mNumOfAvailConnsLabel.setText("0");
      mNumOfConns10Label.setText("0");
      mNumOfConns5Label.setText("0");
      mNumOfConns1Label.setText("0");
      mNumOfConns0Label.setText("0");
   }

   void updatePanelUI()
   {
      ResourcePoolStatistics connPoolStats = null;

      ConnectionPoolManager mgr = null;
      if (ConnectionPoolManagerFactory.isInitialized())
      {
         mgr = ConnectionPoolManagerFactory.getConnectionPoolManager();
      }

      if (mgr instanceof ResourcePoolManager)
      {
         Enumeration pools = ((ResourcePoolManager)mgr).getResourcePools();

         while (pools.hasMoreElements())
         {
            ResourcePool connPool = (ResourcePool)pools.nextElement();
            if (connPoolStats == null)
            {
               connPoolStats = connPool.getResourcePoolStatistics();
            }
            else
            {
               connPoolStats.add(connPool.getResourcePoolStatistics());
            }
         }

         mNumOfConnCreationsLabel.setText(new Long(connPoolStats.mNumOfInstanceCreations).toString());
         mNumOfConnRemovalsLabel.setText(new Long(connPoolStats.mNumOfInstanceRemovals).toString());
         mNumOfConnCheckoutsLabel.setText(new Long(connPoolStats.mNumOfCheckouts).toString());
         mNumOfConnCheckinsLabel.setText(new Long(connPoolStats.mNumOfCheckins).toString());
         mNumOfConnsLabel.setText(new Integer(connPoolStats.mResourceCount).toString());
         mMaxNumOfConnsLabel.setText(new Long(connPoolStats.mMaxNumOfInstances).toString());
         mAvgNumOfConnsLabel.setText(new Long(connPoolStats.mAvgNumOfInstances).toString());
         mNumOfAvailConnsLabel.setText(new Integer(connPoolStats.mAvailableResourceCount).toString());
         mNumOfConns10Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[3]).toString());
         mNumOfConns5Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[2]).toString());
         mNumOfConns1Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[1]).toString());
         mNumOfConns0Label.setText(new Integer(connPoolStats.mResourceAgeHistogram.mBuckets[0]).toString());
      }
   }

   void close()
   {
//      mController = null;
   }
}
