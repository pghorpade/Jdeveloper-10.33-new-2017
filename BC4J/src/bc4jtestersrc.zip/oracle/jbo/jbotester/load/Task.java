package oracle.jbo.jbotester.load;

import oracle.jbo.common.ampool.SessionCookie;

import oracle.jbo.ApplicationModule;

import oracle.jbo.common.PropertyMetadata;
import oracle.jbo.common.PropertyConstants;

import oracle.jbo.JboException;

public abstract class Task implements Runnable
{
   private Session mSession;
   
   void initialize(Session session)
   {
      mSession = session;
   }
   
   public void run()
   {
      long beginTime = System.currentTimeMillis();

      SessionCookie sessionCookie = mSession.getSessionCookie();
      try
      {
         ApplicationModule appModule = sessionCookie.useApplicationModule();

         // what to do with this thing?
         doTask(appModule);
      }
      catch (Throwable t)
      {
         t.printStackTrace();
      }
      finally
      {
         int releaseFlags = -1;
         String releaseMode = PropertyMetadata.AM_RELEASE_MODE.getDefault();
         String cookieReleaseMode =
            (String)sessionCookie.getEnvironment(PropertyMetadata.AM_RELEASE_MODE.getName());

         if (cookieReleaseMode != null)
         {
            releaseMode = cookieReleaseMode;
         }

         if (PropertyConstants.AM_RELEASE_RESERVED.equals(releaseMode))
         {
            releaseFlags = SessionCookie.RESERVED_MANAGED_RELEASE_MODE;
         }
         else if (PropertyConstants.AM_RELEASE_STATEFUL.equals(releaseMode))
         {
            releaseFlags = SessionCookie.SHARED_MANAGED_RELEASE_MODE;
         }
         else if (PropertyConstants.AM_RELEASE_STATELESS.equals(releaseMode))
         {
            releaseFlags = SessionCookie.SHARED_UNMANAGED_RELEASE_MODE;
         }
         else
         {
            sessionCookie.releaseApplicationModule(SessionCookie.SHARED_UNMANAGED_RELEASE_MODE);
            
            throw new JboException("Illegal releaseMode:  " + releaseMode);
         }

         sessionCookie.releaseApplicationModule(releaseFlags);
      }

      long endTime = System.currentTimeMillis();

      reset();

      mSession.transitionState(Session.STATE_SCHEDULED, endTime - beginTime);
   }

   public void destroy()
   {
      mSession = null;
   }

   public void reset()
   {
   }

   public abstract void doTask(ApplicationModule appModule);
}
