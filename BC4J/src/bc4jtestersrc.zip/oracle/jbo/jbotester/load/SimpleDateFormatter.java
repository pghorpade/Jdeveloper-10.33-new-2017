/* $Header: SimpleDateFormatter.java 05-nov-2005.09:58:19 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    wrapper around SimpleDateFormat to display elapsed times

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051023 from 
                           main 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051024 from 
                           main 
    rvangri     11/05/05 - XbranchMerge rvangri_javadoc-cleanup_20051024 from 
                           main 
    rvangri     07/08/05 - rvangri_compiler_warnings_20050708
    rvangri     07/08/05 - Creation
 */

/**
 *  @version $Header: SimpleDateFormatter.java 05-nov-2005.09:58:19 rvangri Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
package oracle.jbo.jbotester.load;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * Wrapper around SimpleDateFormat.
 * This class handles the time zone offset to format elapsed times.
 */
public class SimpleDateFormatter
{
  private Calendar calendar = Calendar.getInstance();
  private TimeZone timeZone = TimeZone.getDefault();
  private SimpleDateFormat simpleDateFormat;
  
  /**
   * @param pattern the pattern to display ("HH:mm:ss")
   * @see java.text.SimpleDateFormat#SimpleDateFormat(String)
   */
  public SimpleDateFormatter(String pattern)
  {
    simpleDateFormat = new SimpleDateFormat(pattern);
    calendar.set(Calendar.ZONE_OFFSET, timeZone.getRawOffset());
  }
  
  /**
   * @param date the elapsed time
   * @return the formatted string
   */
  public String format(long date)
  {
    return this.format(new Date(date));
  }
  
  /**
   * @param date the elapsed time as date
   * @return the formatted string
   */
  public String format(Date date)
  {
    calendar.setTime(date);
    calendar.set(calendar.DST_OFFSET, timeZone.getOffset(date.getTime()));
    return simpleDateFormat.format(calendar.getTime());
  }
}
