package oracle.jbo.jbotester.load;

import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;

public class DefaultTask extends Task
{
   public DefaultTask()
   {
   }

   public void doTask(ApplicationModule appModule)
   {
      String[] voNames = appModule.getViewObjectNames();

      for (int i=0; i < voNames.length; i++)
      {
         ViewObject vo = appModule.findViewObject(voNames[i]);
         vo.first();
      }
   }
}