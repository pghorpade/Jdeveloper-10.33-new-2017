/*
 * @(#)SimulationParametersPanel.java
 *
 * Copyright 2000-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester.load;

import com.sun.java.util.collections.ArrayList;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.Box;

import oracle.bali.ewt.spinBox.NumericSpinBox;

import oracle.jbo.jbotester.load.Controller;

import oracle.jbo.jbotester.JboTesterUtil;

public class SimulationParametersPanel extends JPanel
{
   private NumericSpinBox mNumOfSessionsSpin = new NumericSpinBox(0, 1000);
   private NumericSpinBox mNumOfIterationsSpin = new NumericSpinBox(-1, 1000);
   private NumericSpinBox mTestDurationSpin = new NumericSpinBox(0, 60*60*24);
   private NumericSpinBox mThinkTimeSpin = new NumericSpinBox(0, 5*60);
   private JTextField mTaskClassNameText = new JTextField();

   private final JButton      mResetButton = new JButton("Reset");
   private final JButton      mApplyButton = new JButton("Apply");

   private Controller mController = null;

   public SimulationParametersPanel(Controller controller)
   {
      mController = controller;
      init();
   }
   
   private final void init()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      setLayout(layout);

      // shared contrainst settings:
      constraints.gridx = 0;
      constraints.gridy = 0;

      JLabel numOfSessionsLabel = new JLabel("Number of sessions:  ");
         
      UIHelper.buildSpinBoxRow(
         this
         , constraints
         , layout
         , numOfSessionsLabel
         , mNumOfSessionsSpin);

      JLabel numOfIterationsLabel = new JLabel("Number of iterations per session:  ");

      UIHelper.buildSpinBoxRow(
         this
         , constraints
         , layout
         , numOfIterationsLabel
         , mNumOfIterationsSpin);

      JLabel durationLabel = new JLabel("Duration of simulation(s):  ");

      UIHelper.buildSpinBoxRow(
         this
         , constraints
         , layout
         , durationLabel
         , mTestDurationSpin);

      JLabel thinkTimeLabel = new JLabel("Think time per iteration(s):  ");

      UIHelper.buildSpinBoxRow(
         this
         , constraints
         , layout
         , thinkTimeLabel
         , mThinkTimeSpin);

      JLabel taskClassNameLabel = new JLabel("Task class name:  ");

      constraints.gridwidth=2;
      UIHelper.buildRow(
         this
         , constraints
         , layout
         , taskClassNameLabel
         , mTaskClassNameText);

      constraints.gridwidth=3;      
      constraints.anchor = GridBagConstraints.SOUTHEAST;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;
      constraints.fill = GridBagConstraints.NONE;
      constraints.insets = new Insets(5, 5, 5, 5);

      JPanel panel = buildButtonsBar();
      layout.setConstraints(panel, constraints);
      add(panel);

      updatePanelUI();
   }

   private JPanel buildButtonsBar()
   {
      int maxWidth = 0;
      ArrayList buttons = new ArrayList();

      JPanel panel = new JPanel();
      panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
      panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0));
      
      buttons.add(mResetButton);
      maxWidth = Math.max(maxWidth, mResetButton.getMinimumSize().width);
      mResetButton.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            reset();
         }
      });

      String buttonTextId = "Reset";
      mResetButton.setText(JboTesterUtil.stripMnemonic(buttonTextId));

      int mnemonic  = JboTesterUtil.getMnemonicKeyCode(buttonTextId);
      if (mnemonic != 0)
      {
         mResetButton.setMnemonic(mnemonic);
      }

/*
      buttons.add(mCancelButton);
      maxWidth = Math.max(maxWidth, mCancelButton.getMinimumSize().width);
      mCancelButton.setEnabled(false);
      mCancelButton.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               cancel();
            }
         });
*/
      buttons.add(mApplyButton);
      maxWidth = Math.max(maxWidth, mApplyButton.getMinimumSize().width);
      mApplyButton.setEnabled(true);
      mApplyButton.setDefaultCapable(true);
      mApplyButton.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent ev)
            {
               apply();
            }
         });

      Dimension   d = new Dimension(maxWidth, mApplyButton.getMinimumSize().height);
      Dimension   spacing = new Dimension(8, 0);
      JButton     b;

      for (int i = 0; i < buttons.size(); i++)
      {
         b = (JButton) buttons.get(i);
         b.setPreferredSize(d);

         if (i == 0)
         {
            panel.add(Box.createHorizontalGlue());
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
         else
         {
            panel.add(b);
            panel.add(Box.createRigidArea(spacing));
         }
      }
      
      return panel;      
   }

   private void apply()
   {
      mController.setNumOfSessions(mNumOfSessionsSpin.getIntValue());
      mController.setNumOfIterations(mNumOfIterationsSpin.getIntValue());
      mController.setDuration(mTestDurationSpin.getIntValue() * 1000);
      mController.setThinkTime(mThinkTimeSpin.getIntValue() * 1000);
      mController.setTaskClassName(mTaskClassNameText.getText());
   }
   
   private void reset()
   {
      mController.resetParameters();
      resetPanelUI();
   }

   final void resetPanelUI()
   {
      mNumOfSessionsSpin.setIntValue(mController.getNumOfSessions());
      mNumOfIterationsSpin.setIntValue(mController.getNumOfIterations());
      mTestDurationSpin.setIntValue(mController.getDuration() / 1000);
      mThinkTimeSpin.setIntValue(mController.getThinkTime() / 1000);
      mTaskClassNameText.setText(mController.getTaskClassName());
   }

   final void updatePanelUI()
   {
      resetPanelUI();
   }
}

