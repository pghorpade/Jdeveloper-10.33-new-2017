package oracle.jbo.jbotester.load;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.BorderFactory;

import java.util.Date;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Dimension;

import java.awt.Graphics;

import javax.swing.border.BevelBorder;

import java.text.SimpleDateFormat;

public class TimeSeriesGraph extends JPanel implements TimeSeriesModelListener
{
   SimpleDateFormatter mDateFormatter = new SimpleDateFormatter("mm:ss");
   SimpleDateFormatter mLongDateFormatter = new SimpleDateFormatter("HH:mm:ss");

   private static int TIME_SEGMENT_LENGTH = 5;

   private static Color GRID_LINE_COLOR = new Color(27, 96, 6);

   private TimeSeriesModel mModel;
   
   private final StripGraph mStripGraph = new StripGraph();
   
   private JLabel mMinValueLabel = new JLabel("0.0");
   private JLabel mMaxValueLabel = new JLabel("0.0");
   private JLabel mAvgValueLabel = new JLabel("0.0");
   
   private JLabel mNewestTimeLabel = new JLabel("00:00");
   private JLabel mOldestTimeLabel = new JLabel(" ");
   
   public TimeSeriesGraph()
   {
      this(new TimeSeriesModel());
   }

   public TimeSeriesGraph(TimeSeriesModel model)
   {
      super();

      setModel(model);
      init();
   }

   void init()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();
      setLayout(layout);

      setBorder(BorderFactory.createTitledBorder("Data History"));

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.gridwidth=2;
      constraints.weighty=1;
      constraints.weightx=1;
      constraints.fill=GridBagConstraints.BOTH;
      constraints.insets=new Insets(5, 5, 2, 5);

      JPanel panel = new JPanel(new java.awt.CardLayout());
      panel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
      panel.add("StripGraph", mStripGraph);
      add(panel, constraints);
      
      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 1;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(0, 5, 0, 5);

      mOldestTimeLabel.setHorizontalAlignment(JLabel.LEFT);
      add(mOldestTimeLabel, constraints);

      constraints.anchor = GridBagConstraints.NORTHEAST;
      constraints.gridx = 1;
      constraints.gridy = 1;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(0, 5, 0, 5);

      mNewestTimeLabel.setHorizontalAlignment(JLabel.RIGHT);
      add(mNewestTimeLabel, constraints);

      constraints.anchor = GridBagConstraints.NORTHWEST;
      constraints.gridx = 0;
      constraints.gridy = 2;
      constraints.gridwidth=2;
      constraints.weighty=0;
      constraints.weightx=0;
      constraints.fill=GridBagConstraints.HORIZONTAL;
      constraints.insets=new Insets(2, 5, 0, 5);

      panel = buildSummaryStatisticsPanel();
      add(panel, constraints);
   }
   
   private JPanel buildSummaryStatisticsPanel()
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();

      JPanel panel = new JPanel(layout);
      Dimension dim = panel.getPreferredSize();
      dim.setSize(dim.getWidth(), 25);
      panel.setPreferredSize(dim);

      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;

      panel.add(buildSummaryStatisticPanel(new JLabel("Max:"), mMaxValueLabel), constraints);

      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 1;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;

      panel.add(buildSummaryStatisticPanel(new JLabel("Min:"), mMinValueLabel), constraints);

      constraints.anchor = GridBagConstraints.WEST;
      constraints.gridx = 2;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;

      panel.add(buildSummaryStatisticPanel(new JLabel("Avg:"), mAvgValueLabel), constraints);

      return panel;      
      
   }
   
   private JPanel buildSummaryStatisticPanel(JLabel statisticLabel, JLabel statisticValue)
   {
      GridBagLayout layout   = new GridBagLayout();
      GridBagConstraints   constraints   = new GridBagConstraints();

      JPanel panel = new JPanel(layout);
   
      // shared contrainst settings:
      constraints.anchor = GridBagConstraints.EAST;
      constraints.gridx = 0;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.HORIZONTAL;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;
      //constraints.insets=new Insets(2,5,0,0);
      

      statisticLabel.setHorizontalAlignment(JLabel.RIGHT);
      panel.add(statisticLabel, constraints);

      constraints.anchor = GridBagConstraints.EAST;
      constraints.gridx = 1;
      constraints.gridy = 0;
      constraints.fill = GridBagConstraints.NONE;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;

      statisticValue.setHorizontalAlignment(JLabel.RIGHT);
      statisticValue.setPreferredSize(new Dimension(50, (int)statisticValue.getPreferredSize().getHeight()));
      statisticValue.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
      panel.add(statisticValue, constraints);
      
      return panel;
      
   }

   public TimeSeriesModel getModel()
   {
      return mModel;
   }

   private void setModelInternal(TimeSeriesModel model)
   {
      mStripGraph.setModel(model);

      if (mModel != null)
      {
         mModel.removeModelListener(this);
      }
      model.addModelListener(this);

      mModel = model;
      repaint();
   }
   
   public void setModel(TimeSeriesModel model)
   {
      setModel(model, null);
   }
   public void setModel(TimeSeriesModel model, String title)
   {
      if (mModel != null)
      {
         synchronized(mModel.getSyncLock())
         {
            if (title != null)
            {
               setTitle(title);
            }
            setModelInternal(model);
         }
      }
      else
      {
         setModelInternal(model);
      }
   }
   
   
   public void setTitle(String title)
   {
      setBorder(BorderFactory.createTitledBorder(title));
   }
   
   public void reset()
   {
      if (mModel != null)
      {
         mModel.reset();
         mStripGraph.repaint();
      }
   }


   public void modelChanged()
   {
      if (mModel != null && mModel.getSampleSizeDelta() > 2)
      {
         float dataMax = (float)Math.round(mModel.getDataMax() * 10d) / 10f;
         float dataMin = (float)Math.round(mModel.getDataMin() * 10d) / 10f;
         float dataAvg = (float)Math.round(mModel.getDataAvg() * 10d) / 10f;
         
         mMaxValueLabel.setText(new Float(dataMax).toString());
         mMinValueLabel.setText(new Float(dataMin).toString());
         mAvgValueLabel.setText(new Float(dataAvg).toString());

         long lastUpdateTime = mModel.getLastUpdateTime();
         long firstUpdateTime = mModel.getFirstUpdateTime();
         long elapsedTime = lastUpdateTime - firstUpdateTime;

         SimpleDateFormatter dateFormatter = (elapsedTime > 1000 * 60 * 60 ? mLongDateFormatter : mDateFormatter);
         Date date = new Date(lastUpdateTime - firstUpdateTime);
      
         mNewestTimeLabel.setText(dateFormatter.format(date));
         
         if (mModel.getSampleSize() == mModel.getMaxSampleSize())
         {
            long oldestTime = elapsedTime - mModel.getTotalTime();
            dateFormatter = (oldestTime  > 1000 * 60 * 60 ? mLongDateFormatter : mDateFormatter);
            date = new Date(oldestTime);
            
            mOldestTimeLabel.setText(dateFormatter.format(date));
         }
         else
         {
            mOldestTimeLabel.setText(" ");
         }

         mStripGraph.repaint();
      }
      
   }
   
   class StripGraph extends JPanel
   {
      private int[] mXCoordinates;
      private int[] mYCoordinates;

      public StripGraph()
      {
         init();         
      }
      
      void setModel(TimeSeriesModel model)
      {
         int maxSampleSize = model.getMaxSampleSize();
         mXCoordinates = new int[maxSampleSize];
         mYCoordinates = new int[maxSampleSize];
      }
      
      private void init()
      {
         setDoubleBuffered(true);
         setBackground(Color.BLACK);
      }

      private void drawGrid(Graphics g,  int leftShift)
      {
         g.setColor(GRID_LINE_COLOR);
         Rectangle bounds = g.getClipBounds();
   
         double width = bounds.getWidth();
         double height = bounds.getHeight();
   
   //      int interval = (int)Math.ceil(width / NUM_OF_VERTICAL_GRID_LINES);
   
         // draw the vertical lines
         int currentXPos = (TIME_SEGMENT_LENGTH - (leftShift % TIME_SEGMENT_LENGTH));
         
         while (currentXPos < width)
         {
            g.drawLine(currentXPos, 0, currentXPos, (int)height); 
            currentXPos += TIME_SEGMENT_LENGTH;
         }
   
         // draw the horizontal lines
         int currentYPos = 0;
         while (currentYPos < height)
         {
            g.drawLine(0, currentYPos, (int)width, currentYPos); 
            currentYPos += TIME_SEGMENT_LENGTH;
         }
         
      }
   
      private void drawSeriesLine(Graphics g, int[] xCoordinates, int[] yCoordinates, int numOfPoints)
      {
         g.setColor(Color.GREEN);
   
         // the translated points have the x origin at mXCoordinates[0]
         for (int i=(xCoordinates.length - numOfPoints); i < xCoordinates.length - 1; i++)
         {
            g.drawLine(xCoordinates[i], yCoordinates[i], xCoordinates[i+1], yCoordinates[i+1]);
         }
      }
   
      public void update(Graphics g)
      {
         // prevent update from wiping the graph.  we are going to redraw anyway.
         paint(g);
      }
   
      public void paint(Graphics g)
      {
         synchronized(mModel.getSyncLock())
         {
            super.paint(g);
   
            Rectangle bounds = g.getClipBounds();
            double width = bounds.getWidth();
            double height = bounds.getHeight();
   
            int sampleSizeDelta = mModel.getSampleSizeDelta();
            int numOfPoints = mModel.translate(mXCoordinates, mYCoordinates, width, height);
   
            int leftShift = mXCoordinates[mXCoordinates.length - 1]
               - mXCoordinates[mXCoordinates.length - 1 - sampleSizeDelta];
               
            drawGrid(g, leftShift);
            drawSeriesLine(g, mXCoordinates, mYCoordinates, numOfPoints);
         }
      }
   }
}
