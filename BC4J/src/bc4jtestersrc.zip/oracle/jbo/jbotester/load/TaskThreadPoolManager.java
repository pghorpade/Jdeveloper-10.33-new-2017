package oracle.jbo.jbotester.load;

import oracle.jbo.pool.ResourcePoolManager;

public class TaskThreadPoolManager extends ResourcePoolManager
{
   public static final String SINGLETON_POOL_NAME = "x";

   private static Object mStaticLock = new Object();
   private static TaskThreadPoolManager mInstance = null;
   
   private TaskThreadPoolManager()
   {
   }

   public static final TaskThreadPoolManager getInstance()
   {
      if (mInstance == null)
      {
         synchronized(mStaticLock)
         {
            if (mInstance == null)
            {
               mInstance = new TaskThreadPoolManager();

               mInstance.addResourcePool(SINGLETON_POOL_NAME, new TaskThreadPool());
            }
         }
      }

      return mInstance;
   }
}