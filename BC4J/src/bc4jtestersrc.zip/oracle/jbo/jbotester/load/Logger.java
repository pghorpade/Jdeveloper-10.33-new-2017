package oracle.jbo.jbotester.load;

import java.io.PrintWriter;

public class Logger implements StateChangeListener, Cloneable
{
   private final Object mLock = new Object();

   private Statistics mStatistics = new Statistics();
   
   private float mStepTotalDuration = 0;
   private float mStepNumOfIterations = 0;
   
   public Logger()
   {
   }

   Statistics getStatistics()
   {
      Statistics statistics = null;
      synchronized(mLock)
      {
         computeAverages();

         statistics = (Statistics)mStatistics.clone();         
      }

      return statistics;
   }

   public void stateChanged(StateChangedEvent ev)
   {
      switch(ev.getNewState())
      {
         case Session.STATE_SCHEDULED:
         {
            if (ev.getOldState() == Session.STATE_RUNNING)
            {
               synchronized(mLock)
               {
                  float responseTime = ev.getStateChangeInterval();
                  mStatistics.mMaxResponseTime = Math.max(mStatistics.mMaxResponseTime, responseTime);
                  mStatistics.mMinResponseTime = Math.min(mStatistics.mMinResponseTime, responseTime);
                  mStepTotalDuration += responseTime;
                  mStepNumOfIterations++;
                  if (mStepNumOfIterations % 1000 == 0)
                  {
                     // compute the averages.  lets prevent the aggregate from getting
                     // too big.
                     computeAverages();
                  }
               }
            }
            break;
         }
         case Session.STATE_INITIALIZED:
         {
            synchronized(mLock)
            {
               mStatistics.mNumOfSessions++;
            }

            break;
         }
      }
   }

   private void computeAverages()
   {
      synchronized(mLock)
      {
         mStepTotalDuration += (mStatistics.mAvgResponseTime * mStatistics.mNumOfIterations);
         mStatistics.mNumOfIterations += mStepNumOfIterations;

         if (mStatistics.mNumOfIterations > 0)
         {
            mStatistics.mAvgResponseTime = mStepTotalDuration / mStatistics.mNumOfIterations;
         }
         
         mStepTotalDuration = 0;
         mStepNumOfIterations = 0;
      }
   }

   public void dumpStatistics(PrintWriter pw)
   {
      Statistics statistics = getStatistics();

      pw.println("Printing statistics...");
      pw.println("Average task completion time(ms):  " + statistics.mAvgResponseTime);
      pw.println("Total number of sessions started:  " + statistics.mNumOfSessions);
      pw.println("Total number of tasks completed:  " + statistics.mNumOfIterations);
   }
}
