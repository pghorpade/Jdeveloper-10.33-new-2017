/*
 * @(#)RowSetPanel.java
 *
 * Copyright 1999-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Types;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import oracle.jbo.AttributeDef;
import oracle.jbo.AttributeHints;
import oracle.jbo.DeleteEvent;
import oracle.jbo.domain.Date;
import oracle.jbo.InsertEvent;
import oracle.jbo.LocaleContext;
import oracle.jbo.NavigationEvent;
import oracle.jbo.RangeRefreshEvent;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.ScrollEvent;
import oracle.jbo.UpdateEvent;
import oracle.jbo.common.DebugDiagnostic;

public final class RowSetPanel extends JPanel implements JBOControl
{
  //bug 4500417, see GridBagLayout.MAXGRIDSIZE
  //column/row size are limited, so if we have more
  //than MAXGRIDSIZE fields, we need to break into multiple columns
  //Once somebody defines a VO with 512 * 256 fields, we're in trouble...
   private static final int MAXGRIDSIZE = 512;

   private RowSetIterator  iter;
   private JBOField        fields[];
   protected final MainFrame mainFrame;
   private ArrayList      enabledControls = new ArrayList();

   public RowSetPanel(MainFrame frame)
   {
      super(new GridBagLayout());

      mainFrame = frame;
   }

   public void setIterator(RowSetIterator iterator)
   {
      if (iter == iterator)
      {
         return;
      }

      if (iter != null)
      {
         iter.removeListener(this);
      }

      iter = iterator;
      if (iter == null)
      {
         return;
      }
      
      final ViewObject vo = iter.getRowSet().getViewObject();
      if (vo.isReadOnly())
      {
         DebugDiagnostic.println("RowSetPanel.setRowSet(): ***** RS is Read Only! *****");
      }

      iter.addListener(this);

      AttributeDef[] attrDefs = JboTesterUtil.getDisplayableAttributes(iter.getRowSet());
      DebugDiagnostic.println("Number of attribs :" + attrDefs.length);

      fields = new JBOField[attrDefs.length];

      removeAll();

      //setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

      GridBagConstraints gbc = new GridBagConstraints();
      int ypos=0;
      gbc.insets = new Insets(0, 5, 0, 5);
      
      JComponent firstComponent = null;
      JComponent lastComponent = null;
      Font font = null;
      LocaleContext locale = iter.getRowSet().getApplicationModule().getSession().getLocaleContext();
      
      
      for (int i = 0; i < attrDefs.length; i++)
      {
         AttributeDef attrDef = attrDefs[i];
         AttributeHints hints = attrDef.getUIHelper();
             
         JLabel label = new JLabel(hints.getLabel(locale) + ":");
         label.setEnabled(attrDef.getUpdateableFlag() != AttributeDef.READONLY);
         label.addMouseListener(new LabelMouseAdapter(attrDef));

         JComponent control;
         JBOField field;

         int height = hints.getDisplayHeight(locale);
         int width = ((hints.getDisplayWidth(locale) * 3) + 1) / 2;
         int controlType = hints.getControlType(locale);
         String tooltipText = hints.getTooltip(locale);

         if (width <=0)
         {
            if(attrDef.getJavaType().equals(Date.class))
            {
              width = 15;
            }
            else
            {
              width = 10;
            }
         }

         // For very long field we use TextArea
         if (width > 50 && controlType == AttributeHints.CTLTYPE_DEFAULT && height == 1)
         {
            height = 3;
            width = 50;
         }

         if (height > 1)
         {
            RowsetTextArea textArea = new RowsetTextArea(attrDef, locale);
            ((JTextArea)textArea.getJComponent()).setColumns(width);
            ((JTextArea)textArea.getJComponent()).setRows(height);
            if (tooltipText != null)
            {
               textArea.getJComponent().setToolTipText(tooltipText);
            }

            if (font != null)
            {
               font = (new JTextField()).getFont();
            }

            ((JTextArea)textArea.getJComponent()).setFont(font);

            control = textArea.getScrollPane();
            field = textArea;
         }
         else
         {
            field = new RowsetTextField(width, attrDef, locale);
            control = field.getJComponent();
            font = ((JTextField)control).getFont();
            if (tooltipText != null)
            {
               control.setToolTipText(tooltipText);
            }
         }
         
         fields[i] = field;
         field.getJComponent().setEnabled(attrDef.getUpdateableFlag() != AttributeDef.READONLY);
         label.setLabelFor(field.getJComponent());

         if (firstComponent == null)
         {
            firstComponent = field.getJComponent();
         }
         lastComponent = field.getJComponent();

         gbc.fill = GridBagConstraints.NONE;
         gbc.anchor = GridBagConstraints.EAST;
         gbc.gridx = Math.round(i/MAXGRIDSIZE)*2;
         gbc.gridy = ypos++ - (MAXGRIDSIZE * gbc.gridx/2);
         gbc.gridwidth = 1;
         gbc.weightx = 0.0;
//         gbc.weighty = 0.0;
         //gbl.setConstraints(label, gbc);
         add(label, gbc);

        if(attrDefs.length<MAXGRIDSIZE)
        {
          if (attrDef.getSQLType() == Types.STRUCT)
          {
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
          }
          else
          {
            gbc.fill = GridBagConstraints.NONE;
            gbc.gridwidth = GridBagConstraints.RELATIVE;
          }
        }         
         
         gbc.anchor = GridBagConstraints.WEST;
         gbc.gridx = GridBagConstraints.RELATIVE;
//         gbc.weightx = 1.0;
//         gbc.weighty = 1.0;
         //gbl.setConstraints(control, gbc);
         add(control, gbc);
         
         if(label.isEnabled())
         {
           this.enabledControls.add(label);
           this.enabledControls.add(field);
         }
      }

      // Circle the focus loop
/*      if (firstComponent != null && firstComponent != lastComponent)
      {
         lastComponent.setNextFocusableComponent(firstComponent);
      }
*/
      if(!iter.hasNext())
      {
        this.setControlsEnabled(false);
      }

      refreshAll(iter.getCurrentRow());
   }
   
   public RowSetIterator getIterator()
   {
      return iter;
   }

   // RowsetListener
   public void rangeRefreshed(RangeRefreshEvent event)
   {
      if (event.getRowCountInRange() == 0)
      {
         RowIterator rsi = (RowIterator) event.getSource();
         // Propagate empty detail to nested details Bug 1782878
         if (rsi.getCurrentRowSlot() == RowIterator.SLOT_BEFORE_FIRST)
         {
            rsi.first();
         }
         refreshAll(rsi.getCurrentRow());
      }
   }

   public void rangeScrolled(ScrollEvent event)
   {
   }

   public void rowUpdated(UpdateEvent event)
   {
      if (fields == null)
      {
         return;
      }

      if (event.getRow() == ((RowIterator) event.getSource()).getCurrentRow())
      {
         int[] attrIndexes = event.getChangedAttrIndices();

         if (attrIndexes == null)
         {
            refreshAll(event.getRow());
         }
         else
         {
            // Since the set of displayable attribute might be different
            // than the set of attributes in the row, need to map...
            for (int i = 0; i < attrIndexes.length; i++)
            {
               for (int j = 0; j < fields.length; j++)
               {
                  JBOField f = fields[j];
                  if (f.getAttributeDef().getIndex() == attrIndexes[i])
                  {
                     f.setRow(event.getRow(), getIterator());
                     break;
                  }
               }
            }
         }
      }
   }

   public void navigated(NavigationEvent event)
   {
      refreshAll(event.getRow());
   }

   public void rowDeleted(DeleteEvent event)
   {
      SwingUtilities.invokeLater(new Runnable()
      {
         public void run()
         {
            try
            {
               // Move the currency on next available row.
               // Need to check it the currency has not been move already by an other view
               // on the same iterator...(Master view, Master+Detail view)
               if (iter.getCurrentRowSlot() == RowIterator.SLOT_DELETED)
               {
                  if (iter.hasNext())
                  {
                     iter.next();
                  }
                  else if (iter.hasPrevious())
                  {
                     iter.previous();
                  }
                  else
                  {
                     refreshAll(null);
                  }
               }
            }
            catch (Exception e)
            {
               ErrorHandler.displayError(mainFrame, e);
            }
         }
      });
      
      if(!iter.hasNext()&& !iter.hasPrevious())
      {
        this.setControlsEnabled(false);
      }
   }

   public void rowInserted(InsertEvent event)
   {
    this.setControlsEnabled(true);
   }

   public void refreshAll(Row row)
   {
      if (fields == null)
      {
         return;
      }

      try
      {
         for (int i = 0; i < fields.length; i++)
         {
            fields[i].setRow(row, getIterator());
         }
      }
      catch(NoSuchElementException ex)
      {

      }
      catch(Exception e)
      {
         ErrorHandler.displayError(mainFrame, e);
      }
   }

   boolean applyEditsAndValidate()
   {
      if(iter.getCurrentRowSlot() == RowIterator.SLOT_DELETED || iter.getCurrentRow() == null || iter.getCurrentRow().isDead())
      {
        return true;
      }
      boolean valid = true;
      for (int i=0; i < fields.length; i++)
      {
         valid = fields[i].applyEditAndValidate();
         if (!valid)
         {
            break;
         }
      } 
      return valid;
   }
   
   private void setControlsEnabled(boolean enabled)
   {
      for(int i=0;i<this.enabledControls.size();i++)
      {
        ((JComponent)this.enabledControls.get(i)).setEnabled(enabled);
      }
   }

   final class LabelMouseAdapter extends JBOControlMouseAdapter
   {
      private AttributeDef attrDef;
      private AttDefDialog mDlg;

      LabelMouseAdapter(AttributeDef attDef)
      {
         super(mainFrame);

         this.attrDef = attDef;
      }

      public AttributeDef getAttributeDef(MouseEvent e)
      {
         return attrDef;
      }

      public AttDefDialog getAttrDefDialog(AttributeDef attrDef, MainFrame parentFrame)
      {
         if (mDlg == null)
         {
            mDlg = new AttDefDialog(attrDef, parentFrame);
         }

         return mDlg;
      }
   }
}



