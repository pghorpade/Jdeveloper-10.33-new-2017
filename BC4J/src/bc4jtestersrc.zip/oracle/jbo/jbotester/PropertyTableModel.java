/* $Header: PropertyTableModel.java 22-jun-2005.14:41:33 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
   PropertyTableModel contains the data for a property collection.
   The table contains 2 columns, key and value.

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     06/22/05 - rvangri_connectiondialogbase_20050622
    rvangri     06/22/05 - Creation
 */

/**
 *  @version $Header: PropertyTableModel.java 22-jun-2005.14:41:33 rvangri Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
package oracle.jbo.jbotester;

import javax.swing.table.AbstractTableModel;
import oracle.jbo.jbotester.properties.PropertyPanel;

public class PropertyTableModel extends AbstractTableModel
{
  private Property[] properties;

  public PropertyTableModel(Property[] properties)
  {
    this.properties = properties;
  }

  public Class getColumnClass(int col)
  {
    return String.class;
  }

  // These methods always need to be implemented.
  public int getColumnCount()
  {
    return 2;
  }

  public String getColumnName(int column)
  {
    return PropertyPanel.columNames[column];
  }

  public Property[] getProperties()
  {
    return this.properties;
  }

  public int getRowCount()
  {
    return properties.length;
  }

  public Object getValueAt(int row, int col)
  {
    Property pi = properties[row];
    if (pi != null)
    {
      switch (col)
      {
      case 0:
        return pi.key;
      case 1:
        return pi.value;
      default:
        break;
      }
    }
    return "";
  }

  public boolean isCellEditable(int row, int col)
  {
    Property pi = properties[row];
    boolean bRet = false;
    if (pi != null)
    {
      if (pi.isNew)
      {
        bRet = true;
      } else if (col == 1)
      {
        bRet = !pi.readOnly;
      }
    }
    return bRet;
  }

  public void setProperties(Property[] properties)
  {
    this.properties = properties;
  }

  public void setValueAt(Object aValue, int row, int col)
  {
    Property pi;
    if (row < properties.length && (pi = properties[row]) != null)
    {
      if (col == 0)
      {
        pi.key = aValue.toString();
        pi.desc = pi.key;
      } else
      {
        pi.value = aValue.toString();
        pi.isModified = true;
      }
    }
  }
}
