/* $Header: PropertyTableCellEditor.java 22-jun-2005.14:41:33 rvangri Exp $ */

/* Copyright (c) 2005, Oracle. All rights reserved.  */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    rvangri     06/22/05 - rvangri_connectiondialogbase_20050622
    rvangri     06/22/05 - Creation
 */

/**
 *  @version $Header: PropertyTableCellEditor.java 22-jun-2005.14:41:33 rvangri Exp $
 *  @author  rvangri 
 *  @since   10.1.3
 */
package oracle.jbo.jbotester;

import java.awt.Component;
import java.awt.Frame;
import javax.swing.DefaultCellEditor;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class PropertyTableCellEditor extends DefaultCellEditor
{
  boolean bValidate = false;
  int     currentRow;
  Frame   parent;
  JTable  table;
  
  PropertyTableCellEditor(Frame parent)
  {
    this(parent, new JTextField());
  }
  
  PropertyTableCellEditor(Frame parent, JTextField textField)
  {
    super(textField);
    this.parent = parent;
  }
  
private static boolean isValidXMLElementName(String name)
  {
    try
    {
      oracle.xml.util.XMLUtil.validateName(name);
    } catch (oracle.xml.parser.v2.XMLDOMException exc)
    {
      return false;
    }
    return true;
  }  
  
  
  public Component getTableCellEditorComponent(JTable table, Object value,
      boolean isSelected, int row, int column)
  {
    this.bValidate = ((column == 0) ? true : false);
    this.currentRow = row;
    this.table = table;
    
    return super.getTableCellEditorComponent(table, value, isSelected, row,
        column);        
  }
  
  public boolean stopCellEditing()
  {
    boolean valid = true;
    Object cellValue = getCellEditorValue();
    if (this.bValidate && this.currentRow < table.getRowCount())
    {
      if ((cellValue == null) || (isEmpty(cellValue)))
      {
        JOptionPane
        .showMessageDialog(parent, Res
            .getString(Res.ERR_PROPERTY_NAME_EMPTY), Res
            .getString(Res.ERROR_DIALOG_TITLE_ERROR),
            JOptionPane.ERROR_MESSAGE);
        valid = false;
      }
      if (valid
          && (!isValidXMLElementName(cellValue.toString())))
      {
        JOptionPane
        .showMessageDialog(parent, Res
            .getString(Res.ERR_INVALID_PROPERTY_NAME), Res
            .getString(Res.ERROR_DIALOG_TITLE_ERROR),
            JOptionPane.ERROR_MESSAGE);
        Component editor = getComponent();
        if (editor instanceof JTextField)
        {
          JTextField tf = (JTextField) editor;
          tf.setText("");
        }
        valid = false;
      }
      if ((cellValue != null) && !isUniqueKey(cellValue.toString()))
      {
        JOptionPane
        .showMessageDialog(parent, Res
            .getString(Res.ERR_DUPLICATE_PROPERTY_NAME), Res
            .getString(Res.ERROR_DIALOG_TITLE_ERROR),
            JOptionPane.ERROR_MESSAGE);
        valid = false;
      }
    }
    if (!valid)
    {
      table.setEditingColumn(0);
      table.setEditingRow(currentRow);
      table.clearSelection();
      table.requestFocus();
      table.changeSelection(currentRow, 0, false, false);
      return false;
    }
    return super.stopCellEditing();
  }
  
  private boolean isUniqueKey(String key)
  {
    for (int i = 0; i < table.getRowCount(); i++)
    {
      if (i != currentRow
          && table.getValueAt(i, 0).toString().equalsIgnoreCase(key))
      {
        return false;
      }
    }
    return true;
  }
  
  boolean isEmpty(Object cellValue)
  {
    String cv = cellValue.toString();
    int len = cv.length();
    if (len == 0)
      return true;
    for (int i = 0; i < len; i++)
    {
      char c = cv.charAt(i);
      if (c != ' ')
        return false;
    }
    return true;
  }
}

