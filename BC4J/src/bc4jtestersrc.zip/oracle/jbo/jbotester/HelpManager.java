/*
 * @(#)HelpManager.java
 *
 * Copyright 2001-2002 by Oracle Corporation,
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Oracle Corporation.
 */

package oracle.jbo.jbotester;

import java.util.HashMap;
import java.net.URL;
import oracle.help.Help;
import oracle.help.library.helpset.HelpSet;
import oracle.jbo.common.Diagnostic;

public final class HelpManager
{
  private final static String BROWSER = "f1_bcbctbrowser_html";
  private final static String PROPERTY_DIALOG = "f1_bcbctproperties_html";  
  private final static String VIEW_CRITERIA = "f1_bcbctviewcriteria_html";
  
  private final static HashMap helpTopics = new HashMap();
  
  static
  {
    helpTopics.put(oracle.jbo.jbotester.properties.PropertyDialog.class,PROPERTY_DIALOG);
    helpTopics.put(oracle.jbo.jbotester.VCDialog.class,VIEW_CRITERIA);
  }
   
  public static String getHelpTopic(Object helpRequester)
  {
    String helpTopic = null;
    Class clazz = helpRequester.getClass();
    while (helpTopic == null && clazz.getSuperclass() != null)
    {
      helpTopic = (String)helpTopics.get(clazz);
      clazz = clazz.getSuperclass();
    }
    return helpTopic == null ? BROWSER : helpTopic;
  } 
   
   private final Help help;

   public HelpManager(String helpUrlStr)
   {
      try
      {
         URL helpUrl = new URL(helpUrlStr);
      
         help = new Help();
         Diagnostic.println("Loading HelpBook: " + helpUrl);
         help.addBook(new HelpSet(helpUrl));
      }
      catch (java.net.MalformedURLException ex)
      {
         throw new RuntimeException(Res.getString(Res.ERROR_CANT_FIND_HELP));
      }
      catch (oracle.help.library.helpset.HelpSetParseException ex)
      {
         throw new RuntimeException(ex.toString());
      }
   }
   
   public void helpMe(String topicID)
   {
/*      if (topicID == null)
      {
         //_help.showTopic( null, HelpTopics.CS_DEFAULT );
         Diagnostic.println("Showing navigator window");
         help.showNavigatorWindow();
      }
      else
      {
         help.showTopic(null, topicID);
      }*/
      help.showTopic(null,topicID==null?BROWSER:topicID);
   }

}
