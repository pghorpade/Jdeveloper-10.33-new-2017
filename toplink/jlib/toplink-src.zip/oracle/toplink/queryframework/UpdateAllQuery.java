// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.queryframework;

import java.util.*;

import oracle.toplink.exceptions.*;
import oracle.toplink.expressions.*;
import oracle.toplink.internal.descriptors.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.internal.queryframework.ExpressionQueryMechanism;
import oracle.toplink.sessions.Record;

/**
 * PUBLIC:
 * A Query Class used to perform a bulk update using TopLink's expression framework.
 * This class is provided to help optimize performance. It can be used in place 
 * of reading in all the objects to be changed and issuing single updates per 
 * instance. With this approach a single SQL UPDATE statement can be issued and 
 * then, based on the Expression provided, any objects in the cache that are 
 * effected by the update can be invalidated. 
 * <p>
 * Notes: <ul>
 * <li>By default, if a UOW is being used, this query will be deferred until the UOW commits.
 * <li>UpdateAllQuery does not support foreign key updates 
 * unless the relationship is 1-1 (without back pointers.)</ul>
 * <p> 
 * <b>Example of Usage:</b> Adding an area code. <br>
 * <code> 
 * UpdateAllQuery updateQuery = new UpdateAllQuery(Employee.class);   <br>
 * updateQuery.setSelectionCriteria(eb.get("areaCode").isNull());     <br>
 * updateQuery.addUpdate(eb.get("areaCode"), "613");                  <br>
 * </code> 
 * 
 * @author Guy Pelletier
 * @date March 1, 2004
 */
public class UpdateAllQuery extends ModifyQuery {

	/** 
     * Cache usage flag indicating that the cache is valid. */
    public static final int NO_CACHE = 0;
    
    /** 
     * Cache usage flag indicating that there are objects in the cache which are invalid. 
     * This is the default value when an update all query is instantiated. */
    public static final int INVALIDATE_CACHE = 1;
    
    private   Class   m_referenceClass;
    protected HashMap m_updateClauses;
    private int m_cacheUsage = INVALIDATE_CACHE;

    //Provide a default builder so that it's easier to be consistent
    protected ExpressionBuilder m_builder;
    //Indicates whether execution should be deferred in UOW 
    private boolean shouldDeferExecutionInUOW;

    /**
     * PUBLIC:
     * Constructs a default update all query.
     */
    public UpdateAllQuery() {
        m_updateClauses = new HashMap();
        shouldDeferExecutionInUOW = true;
    }

    /**
     * PUBLIC:
     * Constructs an update all query for the Class type specified.
     * @param referenceClass Class
     */
    public UpdateAllQuery(Class referenceClass) {
        this();
        setReferenceClass(referenceClass);
    }

    /**
     * PUBLIC:
     * Constructs an update all query for the specified Class type and selection criteria.
     * @param referenceClass Class type to be considered
     * @param selectionCriteria Expression
     */
    public UpdateAllQuery(Class referenceClass, Expression selectionCriteria) {
        this();
        setReferenceClass(referenceClass);
        setSelectionCriteria(selectionCriteria);
    }

    /**
     * PUBLIC:
     * Constructs an update all query for the Class type specified and the given 
     * ExpressionBuilder. This builder must be used for all associated expressions
     * used with the query.<br>
     * @param referenceClass Class type to be considered
     * @param builder ExpressionBuilder
     */
    public UpdateAllQuery(Class referenceClass, ExpressionBuilder builder) {
        setReferenceClass(referenceClass);
        setExpressionBuilder(builder);
    }

    /**
     * PUBLIC:
     * Adds the update (SET) clause to the query.
     * @param field Expression Object level representation of a database query 'where' clause
     * @param value Object, the new value
     */
    public void addUpdate(Expression field, Object value) {
        addUpdate(field, field.getBuilder().value(value));
    }

    /**
     * PUBLIC:
     * Adds the update (SET) clause to the query. 
     * @param attributeName String, the name of the attribute
     * @param value Object, the new value
     */
    public void addUpdate(String attributeName, Object value) {
        addUpdate(getExpressionBuilder().get(attributeName), getExpressionBuilder().value(value));
    }

    /**
     * PUBLIC:
     * Adds the update (SET) clause to the query. This method ensures that
     * the builder has the session and reference class set for both given Expressions.
     * @param field Expression, representation of a database query 'where' clause that describes the field
     * @param value Expression, representation of a database query 'where' clause that describes the new value
     */
    public void addUpdate(Expression field, Expression value) {
    	//bug4658449 - add null check to avoid NPE
        if (value == null) { 
            addUpdate(field, (Object) null); 
        } else { 
        	value.getBuilder().setSession(getSession());
        	field.getBuilder().setSession(getSession());
        	value.getBuilder().setQueryClass(getReferenceClass());
        	field.getBuilder().setQueryClass(getReferenceClass());

        	m_updateClauses.put(field, value);
        }
    }

    /**
     * INTERNAL
     * Used to give the subclasses opportunity to copy aspects of the cloned query
     * to the original query.  The clones of all the UpdateAllQueries will be added to 
     * updateAllQueries for validation.
     */
    protected void clonedQueryExecutionComplete(DatabaseQuery query, Session session) {
        super.clonedQueryExecutionComplete(query, session);
        
        if (session.isUnitOfWork()) {
            ((UnitOfWork)session).storeUpdateAllQuery(query);
        }
    }

    /**
     * INTERNAL:
     * Overrides query execution where Session is a UnitOfWork.
     * <p>
     * If there are objects in the cache, returns the results of the cache lookup.
     *
     * @param unitOfWork - the session in which the receiver will be executed.
     * @param translationRow - the arguments
     * @exception  DatabaseException - an error has occurred on the database.
     * @exception  OptimisticLockException - an error has occurred using the optimistic lock feature.
     * @return An object, the result of executing the query.
     */
    public Object executeInUnitOfWork(UnitOfWork unitOfWork, DatabaseRow translationRow) 
    throws DatabaseException, OptimisticLockException {
        if (unitOfWork.isNestedUnitOfWork()) {
            throw ValidationException.nestedUOWNotSupportedForUpdateAllQuery();
        }
        
        //Bug4607551  
        //If deferred, add the original query with a translation row to the deferredUpdateAllQueries for execution. 
        //No action for non-deferred.  
        //Later on the clones of all the UpdateAllQuery's will be added to updateAllQueries for validation.
        if(shouldDeferExecutionInUOW()) {
            unitOfWork.storeDeferredUpdateAllQuery(this, translationRow);
            return null;
        } else {
            return super.executeInUnitOfWork(unitOfWork, translationRow);
        }
    }

    /**
     * INTERNAL:
     * Issues the SQL to the database and then merge into the cache.
     * If we are withing a UoW, the merge to the cache must not be done until
     * the UoW merges into the parent. The UoW will trigger the merge to occur
     * at the correct time and will ensure the cache setting is set to none at
     * that time.
     */
    public Object executeDatabaseQuery() throws DatabaseException {
        Integer rowsChanged = getQueryMechanism().updateAll();// fire the SQL to the database
        mergeChangesIntoSharedCache();
        return rowsChanged;
    }

    /**
     * PUBLIC:
     * Returns the cache usage for this update all query.
     * @return int - UpdateAllQuery.NO_CACHE or UpdateAllQuery.INVALIDATE_CACHE depending on 
     * whether the cache is currently valid
     */
    public int getCacheUsage() {
        return m_cacheUsage;
    }

    /**
     * PUBLIC:
     * Returns the expression builder which should be used for this update all query.
     * Note: This expression builder should be used to build all expressions used by
     * this query. If a builder does not yet exist, this method will initialize one.
     * @return ExpressionBuilder, used to create Expressions
     */
    public ExpressionBuilder getExpressionBuilder() {
        if (m_builder == null) {
            initializeBuilder();
        }
        return m_builder;
    }

    /**
     * PUBLIC:
     * Returns the reference Class type for this update all query.
     * @return Class under consideration with this query
     */
    public Class getReferenceClass() {
        return m_referenceClass;
    }

    /**
     * INTERNAL:
     * Returns the reference class for a query
     * Note: Although the API is designed to avoid classpath dependancies for the MW, since the object
     * is specified at runtime, this will not be an issue.
     */
    public String getReferenceClassName() {
        return getReferenceClass().getName();
    }

    /**
     * INTERNAL:
     * Returns the updates stored for an update all query
     */
    public HashMap getUpdateClauses() {
        return m_updateClauses;
    }

    /**
     * INTERNAL:
     * Initializes the expression builder which should be used for this query. If
     * there is a where clause, use its expression builder, otherwise
     * generate one and cache it. This helps avoid unnecessary rebuilds.
     */
    protected void initializeBuilder() {
        // Check for a selection criteria on the ExpressionQueryMechanism and and 
        // grab its builder.
        ExpressionBuilder eqmBuilder = ((ExpressionQueryMechanism)getQueryMechanism()).getExpressionBuilder();

        // If no selection criteria is set (hence no builder), then we need to
        // dig a little deeper
        if (eqmBuilder == null) {
            // Check for update statements
            if (m_updateClauses.isEmpty()) {
                // Create a new builder and hope the user doesn't use a different one
                // The user should really set the expressionBuilder on the Query to
                // avoid all this guessing. 
                m_builder = new ExpressionBuilder(getReferenceClass());
            } else {
                // Grab the builder that was used to build the first update clause
                Iterator i = m_updateClauses.keySet().iterator();
                Expression field = (Expression)i.next();
                m_builder = field.getBuilder();
            }
        } else {
            m_builder = eqmBuilder;
        }

        m_builder.setSession(getSession());
    }

    /**
     * INTERNAL:
     * Invalidates the cache, that is, those objects in the cache that were affected
     * by the query.
     */
    protected void invalidateCache() {
        if (getSelectionCriteria() == null) {
            //Invalidate the whole class since the user did not specify a where clause
            getSession().getIdentityMapAccessor().invalidateClass(getReferenceClass());
        } else {
            //Invalidate only those objects in the cache that match the selection criteria
            //Bug:4293920, expression parameters were not passed in
            oracle.toplink.sessions.IdentityMapAccessor identityMapAccessor = getSession().getIdentityMapAccessor();
            Vector collectionToInvalidate = identityMapAccessor.getAllFromIdentityMap(getSelectionCriteria(), getSelectionCriteria().getBuilder().getQueryClass(), (Record)getTranslationRow(),new InMemoryQueryIndirectionPolicy());
            identityMapAccessor.invalidateObjects(collectionToInvalidate);
        }
    }

    /**
     * INTERNAL:
     * Returns true if this is an update all query.
     */
    public boolean isUpdateAllQuery() {
        return true;
    }

    /**
     * INTERNAL:
     * After execution we need to merge the changes into the shared cache
     */
    public void mergeChangesIntoSharedCache() {
        if (shouldInvalidateCache()) {
            invalidateCache();
        }
    }

    /**
     * INTERNAL:
     */
    protected void prepare() throws QueryException {
        super.prepare();// will tell the query mechanism to prepare itself as well.

        Class referenceClass = getReferenceClass();

        // Check the reference class, must be set
        if (referenceClass == null) {
            throw QueryException.referenceClassMissing(this);
        }

        // Check the descriptor is set, if not try to get it from the session
        if (getDescriptor() == null) {
            Descriptor desc = getSession().getDescriptor(referenceClass);

            if (desc == null) {
                throw QueryException.descriptorIsMissing(referenceClass, this);
            }

            setDescriptor(desc);
        }

        Descriptor descriptor = getDescriptor();

        // Check the descriptor for an aggregate
        if (descriptor.isAggregateDescriptor()) {
            throw QueryException.aggregateObjectCannotBeDeletedOrWritten(descriptor, this);
        }

        // Inheritance with multiple tables
        if (descriptor.hasInheritance() && (descriptor.getTables().size() > 1)) {
            throw QueryException.inheritanceWithMultipleTablesNotSupported();
        }

        // Check that the update statement is set. That is the bare minimum,
        // the user can execute this query without a selection criteria though.
        if (getUpdateClauses().isEmpty()) {
            throw QueryException.updateStatementsNotSpecified();
        }

        // Add a statement to update the optimistic locking field if their is one.
        OptimisticLockingPolicy policy = descriptor.getOptimisticLockingPolicy();

        if (policy != null) {
            ExpressionBuilder eb = getExpressionBuilder();
            Expression writeLockUpdateExpression = policy.getWriteLockUpdateExpression(eb);

            if (writeLockUpdateExpression != null) {
                Expression writeLock = eb.getField(policy.getWriteLockField().getName());
                addUpdate(writeLock, writeLockUpdateExpression);
            }
        }

        getQueryMechanism().prepareUpdateAll();
    }

    /**
     * PUBLIC:
     * Sets the level of cache support for this query.
     * @param cacheUsage int value, UpdateAllQuery.NO_CACHE or UpdateAllQuery.INVALIDATE_CACHE
     */
    public void setCacheUsage(int cacheUsage) {
        m_cacheUsage = cacheUsage;
    }

    /**
     * PUBLIC:
     * Sets the expression builder which should be used for this update all query.
     * This expression builder should be used to build all expressions used by
     * this query.
     * @param builder ExpressionBuilder
     */
    public void setExpressionBuilder(ExpressionBuilder builder) {
        m_builder = builder;
    }

    /**
     * PUBLIC:
     * Sets the reference class for this update all query.
     * @param referenceClass Class
     */
    public void setReferenceClass(Class referenceClass) {
        if (this.m_referenceClass != referenceClass) {
            setIsPrepared(false);
        }
        m_referenceClass = referenceClass;
    }

    /**
     * PUBLIC:
     * Sets a flag indicating whether the execution of the update all query should be deferred 
     * until the UOW commits.
     * @param shouldDeferExecutionInUOW boolean - set to true if execution in UOW is to be deferred
     */
    public void setShouldDeferExecutionInUOW(boolean shouldDeferExecutionInUOW) {
        this.shouldDeferExecutionInUOW = shouldDeferExecutionInUOW;
    }
    
    /**
     * PUBLIC:
     * Returns a boolean indicating whether the query's execution is deferred in a UOW until it commits.
     * @return boolean - true if execution in UOW is being deferred
     */
    public boolean shouldDeferExecutionInUOW() {
        return shouldDeferExecutionInUOW;
    }
    
    /**
     * INTERNAL:
     */
    protected boolean shouldInvalidateCache() {
        return m_cacheUsage == INVALIDATE_CACHE;
    }
}