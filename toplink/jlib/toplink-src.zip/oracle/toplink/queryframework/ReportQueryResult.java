// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.queryframework;

import java.io.*;
import java.util.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.internal.helper.*;
import oracle.toplink.internal.queryframework.*;
import oracle.toplink.mappings.*;
import oracle.toplink.mappings.foundation.AbstractDirectMapping;
import oracle.toplink.publicinterface.DatabaseRow;
import oracle.toplink.sessions.Session;

/**
 * <b>Purpose</b>: A single row (type) result for a ReportQuery<p>
 *
 * <b>Description</b>: Represents a single row of attribute values (converted using mapping) for
 * a ReportQuery. The attributes can be from various objects.
 *
 * <b>Responsibilities</b>:<ul>
 * <li> Converted field values into object attribute values.
 * <li> Provide acces to values by index or item name
 * </ul>
 *
 * @author Doug Clarke
 * @since TOPLink/Java 2.0
 */
public class ReportQueryResult implements Serializable, Map {

    /** Item names to lookup result values */
    protected Vector names;

    /** Actual converted attribute values */
    protected Vector results;

    /** PK values if the retrievPKs flag was set on the ReportQuery. These can be used to get the actual object */
    protected Vector primaryKeyValues;

    /**
     * INTERNAL:
     * Used to create test results
     */
    public ReportQueryResult(Vector results, Vector primaryKeyValues) {
        this.results = results;
        this.primaryKeyValues = primaryKeyValues;
    }

    public ReportQueryResult(ReportQuery query, DatabaseRow row) {
        super();
        this.names = query.getNames();
        buildResult(query, row);
    }

    /**
     * INTERNAL:
     * Create an array of attribute values (converted from raw field values using the mapping).
     */
    protected void buildResult(ReportQuery query, DatabaseRow row) {
        int numberOfPrimaryKeyFields = 0;
        Vector results = new Vector(query.getItems().size());

        if (query.shouldRetrievePrimaryKeys()) {
            numberOfPrimaryKeyFields = query.getDescriptor().getPrimaryKeyFields().size();
            setPrimaryKeyValues(query.getDescriptor().getObjectBuilder().extractPrimaryKeyFromRow(row, query.getSession()));
            // For bug 3115576 this is only used for EXISTS subselects so no result is needed.
        } else if (query.shouldRetrieveFirstPrimaryKey()) {
            numberOfPrimaryKeyFields = 1;
        }

        // CR 4240
        // rowIndex is seperate as there may be place holders in the query that are not in the
        // result set. So we can not compare the index to row size as there may be less
        // objects in the row then there will be in the result set.
        int rowIndex = 0;
        for (int index = 0; index < query.getItems().size(); index++) {
            ReportItem item = (ReportItem)query.getItems().elementAt(index);
            DatabaseMapping mapping = item.getMapping();
            Object value = null;

            if (!item.isPlaceHolder()) {
                // CR 4240 compare against the rowIndex not the resultset index
                if ((rowIndex + numberOfPrimaryKeyFields) >= row.size()) {
                    throw QueryException.reportQueryResultSizeMismatch(rowIndex + numberOfPrimaryKeyFields, row.size());
                }
                value = row.getValues().elementAt(rowIndex + numberOfPrimaryKeyFields);
                ++rowIndex;
            }
            if (mapping != null) {
                value = ((AbstractDirectMapping)mapping).getAttributeValue(value, query.getSession());
            }
            results.addElement(value);
        }

        setResults(results);
    }

    /**
     * PUBLIC:
     * Clear the contents of the result.
     */
    public void clear() {
        this.names = new Vector();
        this.results = new Vector();
    }

    /**
     * PUBLIC:
     * Check if the value is contained in the result.
     */
    public boolean contains(Object value) {
        return containsValue(value);
    }

    /**
     * PUBLIC:
     * Check if the key is contained in the result.
     */
    public boolean containsKey(Object key) {
        return getNames().contains(key);
    }

    /**
     * PUBLIC:
     * Check if the value is contained in the result.
     */
    public boolean containsValue(Object value) {
        return getResults().contains(value);
    }

    /**
     * PUBLIC:
     * Return an enumeration of the result values.
     */
    public Enumeration elements() {
        return getResults().elements();
    }

    /**
     * PUBLIC:
     * Returns a set of the keys.
     */
    public Set entrySet() {
        // bug 2669127
        // implemented this method exactly the same way as DatabaseRow.entrySet()
        int size = this.size();
        Map tempMap = new HashMap(size);
        for (int i = 0; i < size; i++) {
            tempMap.put(this.getNames().elementAt(i), this.getResults().elementAt(i));
        }
        return tempMap.entrySet();
    }

    /**
     * PUBLIC:
     * Compare if the two results are equal.
     */
    public boolean equals(Object anObject) {
        if (anObject instanceof ReportQueryResult) {
            return equals((ReportQueryResult)anObject);
        }

        return false;
    }

    /**
     * INTERNAL:
     * Used in testing to compare if results are correct.
     */
    public boolean equals(ReportQueryResult result) {
        if (this == result) {
            return true;
        }
        if (!Helper.compareOrderedVectors(getResults(), result.getResults())) {
            return false;
        }

        // Compare PKs
        if (getPrimaryKeyValues() != null) {
            if (result.getPrimaryKeyValues() == null) {
                return false;
            }
            return Helper.compareOrderedVectors(getPrimaryKeyValues(), result.getPrimaryKeyValues());
        }

        return true;
    }

    /**
     * PUBLIC:
     * Return the value for given item name.
     */
    public Object get(Object name) {
        if (name instanceof String) {
            return get((String)name);
        }

        return null;
    }

    /**
     * PUBLIC:
     * Return the value for given item name.
     */
    public Object get(String name) {
        int index = getNames().indexOf(name);
        if (index == -1) {
            return null;
        }

        return getResults().elementAt(index);
    }

    /**
     * PUBLIC:
     * Return the indexed value from result.
     */
    public Object getByIndex(int index) {
        return getResults().elementAt(index);
    }

    /**
     * PUBLIC:
     * Return the names of report items, provided to ReportQuery.
     */
    public Vector getNames() {
        return names;
    }

    /**
     * PUBLIC:
     * Return the PKs for the corresponding object or null if not requested.
     */
    public Vector getPrimaryKeyValues() {
        return primaryKeyValues;
    }

    /**
     * PUBLIC:
     * Return the results.
     */
    public Vector getResults() {
        return results;
    }

    /**
     * PUBLIC:
     * Return if the result is empty.
     */
    public boolean isEmpty() {
        return getNames().isEmpty();
    }

    /**
     * PUBLIC:
     * Return an enumeration of the result names.
     */
    public Enumeration keys() {
        return getNames().elements();
    }

    /**
     * PUBLIC:
     * Returns a set of the keys.
     */
    public Set keySet() {
        return new HashSet(getNames());
    }

    /**
     * ADVANCED:
     * Set the value for given item name.
     */
    public Object put(Object name, Object value) {
        int index = getNames().indexOf(name);
        if (index == -1) {
            getNames().addElement(name);
            getResults().addElement(value);
            return null;
        }

        Object oldValue = getResults().elementAt(index);
        getResults().setElementAt(value, index);
        return oldValue;
    }

    /**
     * PUBLIC:
     * Add all of the elements.
     */
    public void putAll(Map map) {
        Iterator entriesIterator = map.entrySet().iterator();
        while (entriesIterator.hasNext()) {
            Map.Entry entry = (Map.Entry)entriesIterator.next();
            put(entry.getKey(), entry.getValue());
        }
    }

    /**
     * PUBLIC:
     * If the PKs were retrieved with the attributes then this method can be used to read the real object from the database.
     */
    public Object readObject(Class javaClass, Session session) {
        if (getPrimaryKeyValues() == null) {
            throw QueryException.reportQueryResultWithoutPKs(this);
        }

        ReadObjectQuery query = new ReadObjectQuery(javaClass);
        query.setSelectionKey(getPrimaryKeyValues());

        return session.executeQuery(query);
    }

    /**
     * INTERNAL:
     * Remove the name key and value from the result.
     */
    public Object remove(Object name) {
        int index = getNames().indexOf(name);
        if (index >= 0) {
            getNames().removeElementAt(index);
            Object value = getResults().elementAt(index);
            getResults().removeElementAt(index);
            return value;
        }
        return null;
    }

    protected void setNames(Vector names) {
        this.names = names;
    }

    /**
     * INTERNAL:
     * Set the PK values for the result row's object.
     */
    protected void setPrimaryKeyValues(Vector primaryKeyValues) {
        this.primaryKeyValues = primaryKeyValues;
    }

    /**
     * INTERNAL:
     * Set the results.
     */
    public void setResults(Vector results) {
        this.results = results;
    }

    /**
     * PUBLIC:
     * Return the number of name/value pairs in the result.
     */
    public int size() {
        return getNames().size();
    }

    public String toString() {
        java.io.StringWriter writer = new java.io.StringWriter();
        writer.write("ReportQueryResult(");
        for (int index = 0; index < getResults().size(); index++) {
            writer.write(String.valueOf(getResults().elementAt(index)));
            if (index < (getResults().size() - 1)) {
                writer.write(", ");
            }
        }
        writer.write(")");
        return writer.toString();
    }

    /**
     * PUBLIC:
     * Returns an collection of the values.
     */
    public Collection values() {
        return getResults();
    }
}