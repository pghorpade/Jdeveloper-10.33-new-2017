// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.queryframework;

/**
 * <p><b>Purpose</b>: The fetch group tracker interface provides a set of APIs which
 * the domain object must implement, in order to take advantage of the TopLink fetch group
 * performance enhancement feature.
 *
 * @see oracle.toplink.queryframework.FetchGroup
 *
 * @author King Wang
 * @since TopLink 10.1.3
 */
public interface FetchGroupTracker {

    /**
     * Return the fetch group being tracked
     */
    FetchGroup getFetchGroup();

    /**
     * Set a fetch group to be tracked.
     */
    void setFetchGroup(FetchGroup group);

    /**
     * Return true if the attribute is in the fetch group being tracked.
     */
    boolean isAttributeFetched(String attribute);

    /**
     * Reset all attributes of the tracked object to the unfetched state with initial default values.
     */
    void resetFetchGroup();

    /**
     * Return true if the fecth group attributes should be refreshed
     */
    boolean shouldRefreshFetchGroup();

    /**
     * Set true if the fecth group attributes should be refreshed
     */
    void setShouldRefreshFetchGroup(boolean shouldRefreshFetchGroup);
}