// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.queryframework;

import java.util.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.internal.helper.*;
import oracle.toplink.descriptors.DescriptorEvent;

/**
 * <p><b>Purpose</b>:
 * Query used to delete a collection of objects
 *
 * <p><b>Responsibilities</b>:
 * <ul>
 * <li> Stores & retrieves the objects to delete.
 * <li> Store the where clause used for the deletion.
 * </ul>
 *
 * @author Yvon Lavoie
 * @since TOPLink/Java 1.0
 */
public class DeleteAllQuery extends ModifyQuery {

    /* Class of the objects being deleted. */
    protected Class referenceClass;
    protected String referenceClassName;

    /* Vector containing objects to be deleted, these should be removed from the identity map after deletion. */
    protected Vector objects;

    /**
         * INTERNAL:
         * This method has to be broken.  If commit manager is not active either
         * an exception should be thrown (ObjectLevelModify case), or a transaction
         * should be started early and execute on parent if remote (dataModify case).
         * A modify query is NEVER executed on the parent, unless remote session.
         * @param unitOfWork
         * @param translationRow
         * @return
         * @throws oracle.toplink.exceptions.DatabaseException
         * @throws oracle.toplink.exceptions.OptimisticLockException
         */
    public Object executeInUnitOfWork(UnitOfWork unitOfWork, DatabaseRow translationRow) throws DatabaseException, OptimisticLockException {
        if (unitOfWork.isAfterWriteChangesButBeforeCommit()) {
            throw ValidationException.illegalOperationForUnitOfWorkLifecycle(unitOfWork.getLifecycle(), "executeQuery(DeleteAllQuery)");
        }

        // This must be broken, see comment.
        if (!unitOfWork.getCommitManager().isActive()) {
            return unitOfWork.getParent().executeQuery(this, translationRow);
        }
        return super.executeInUnitOfWork(unitOfWork, translationRow);
    }

    /**
     * INTERNAL:
     * Perform the work to delete a collection of objects.
     * This skips the optimistic lock check and should not called for objects using locking.
     * @exception  DatabaseException - an error has occurred on the database.
     * @return vector - the objects being deleted.
     */
    public Object executeDatabaseQuery() throws DatabaseException {
        // CR# 4286
        if ((getObjects() == null) || (getObjects().size() == 0)) {
            return getObjects();
        }

        // Optimistic lock check not required because objects are deleted individually in that case.
        try {
            getSession().beginTransaction();

            // Need to run pre-delete selector if available.
            // PERF: Avoid events if no listeners.
            if (getDescriptor().getEventManager().hasAnyEventListeners()) {
                for (Enumeration deletedObjectsEnum = getObjects().elements();
                         deletedObjectsEnum.hasMoreElements();) {
                    DescriptorEvent event = new DescriptorEvent(deletedObjectsEnum.nextElement());
                    event.setEventCode(DescriptorEventManager.PreDeleteEvent);
                    event.setSession(getSession());
                    event.setQuery(this);
                    getDescriptor().getEventManager().executeEvent(event);
                }
            }

            getQueryMechanism().deleteAll();

            if ((getDescriptor().getHistoryPolicy() != null) && getDescriptor().getHistoryPolicy().shouldHandleWrites()) {
                getDescriptor().getHistoryPolicy().postDelete(this);
            }

            // Need to run post-delete selector if available.
            // PERF: Avoid events if no listeners.
            if (getDescriptor().getEventManager().hasAnyEventListeners()) {
                for (Enumeration deletedObjectsEnum = getObjects().elements();
                         deletedObjectsEnum.hasMoreElements();) {
                    DescriptorEvent event = new DescriptorEvent(deletedObjectsEnum.nextElement());
                    event.setEventCode(DescriptorEventManager.PostDeleteEvent);
                    event.setSession(getSession());
                    event.setQuery(this);
                    getDescriptor().getEventManager().executeEvent(event);
                }
            }

            if (shouldMaintainCache()) {
                // remove from the cache.
                for (Enumeration objectsEnum = getObjects().elements();
                         objectsEnum.hasMoreElements();) {
                    Object deleted = objectsEnum.nextElement();
                    if (getSession().isUnitOfWork()) {
                        //BUG #2612169: Unwrap is needed
                        deleted = getDescriptor().getObjectBuilder().unwrapObject(deleted, getSession());
                        ((UnitOfWork)getSession()).addObjectDeletedDuringCommit(deleted);
                    } else {
                        getSession().getIdentityMapAccessor().removeFromIdentityMap(deleted);
                    }
                }
            }

            getSession().commitTransaction();

            return getObjects();
        } catch (RuntimeException exception) {
            getSession().rollbackTransaction();
            throw exception;
        }
    }

    /**
     * INTERNAL:
     * Delete all queries are executed specially to avoid cloning and ensure preparing.
     */
    public void executeDeleteAll(Session session, DatabaseRow translationRow, Vector objects) throws DatabaseException {
        this.checkPrepare(session, translationRow);
        DeleteAllQuery queryToExecute = (DeleteAllQuery)clone();

        // Then prapared for the single execution.
        queryToExecute.setTranslationRow(translationRow);
        queryToExecute.setSession(session);
        queryToExecute.setObjects(objects);
        queryToExecute.prepareForExecution();
        queryToExecute.executeDatabaseQuery();
    }

    /**
     * PUBLIC:
     * Return the objects that are to be deleted
     */
    public Vector getObjects() {
        return objects;
    }

    /**
     * INTERNAL:
     * Return the name of the reference class of the query.
     * Used by the Mappign Workbench to avoid classpath dependancies
     */
    public String getReferenceClassName() {
        if ((referenceClassName == null) && (referenceClass != null)) {
            referenceClassName = referenceClass.getName();
        }
        return referenceClassName;
    }

    /**
     * PUBLIC:
     * Return the reference class of the query.
     */
    public Class getReferenceClass() {
        return referenceClass;
    }

    /**
     * INTERNAL:
     * Prepare the receiver for execution in a session.
     */
    protected void prepare() throws QueryException {
        super.prepare();

        if (getReferenceClass() == null) {
            throw QueryException.referenceClassMissing(this);
        }

        if (getDescriptor() == null) {
            Descriptor referenceDescriptor = getSession().getDescriptor(getReferenceClass());
            if (referenceDescriptor == null) {
                throw QueryException.descriptorIsMissing(getReferenceClass(), this);
            }
            setDescriptor(referenceDescriptor);
        }

        if (getDescriptor().isAggregateDescriptor()) {
            throw QueryException.aggregateObjectCannotBeDeletedOrWritten(getDescriptor(), this);
        }

        getQueryMechanism().prepareDeleteAll();
    }

    /**
     * PUBLIC (REQUIRED):
     * Set the objects to be deleted.
     * Also REQUIRED is a selection criteria or SQL string that performs the deletion of the objects.
     * This does not generate the SQL call from the deleted objects.
     * #setObject() should not be called.
     */
    public void setObjects(Vector objectCollection) {
        objects = objectCollection;
    }

    /**
     * PUBLIC (REQUIRED):
     * Set the reference class for the query
     */
    public void setReferenceClass(Class aClass) {
        referenceClass = aClass;
    }

    /**
     * INTERNAL:
     * Set the class name of the reference class of this query.
     * Used by the Mapping Workbench to avoid classpath dependancies.
     */
    public void setReferenceClassName(String className) {
        referenceClassName = className;
    }
}