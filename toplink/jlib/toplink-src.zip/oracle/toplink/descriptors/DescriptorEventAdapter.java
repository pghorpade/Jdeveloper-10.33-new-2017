// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.descriptors;


/**
 * <p><b>Purpose</b>: Provides an empty implementation of DescriptorEventListener.
 * Users who do not require the full DescritorEventListener API can subclass this class
 * and implement only the methods required.
 *
 * @see DescriptorEventManager
 * @see DescriptorEvent
 */
public class DescriptorEventAdapter implements DescriptorEventListener, oracle.toplink.publicinterface.DescriptorEventListener {
    public void aboutToInsert(DescriptorEvent event) {
        aboutToInsert((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void aboutToUpdate(DescriptorEvent event) {
        aboutToUpdate((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void aboutToDelete(DescriptorEvent event) {
        aboutToDelete((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postBuild(DescriptorEvent event) {
        postBuild((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postClone(DescriptorEvent event) {
        postClone((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postDelete(DescriptorEvent event) {
        postDelete((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postInsert(DescriptorEvent event) {
        postInsert((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postMerge(DescriptorEvent event) {
        postMerge((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postRefresh(DescriptorEvent event) {
        postRefresh((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postUpdate(DescriptorEvent event) {
        postUpdate((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void postWrite(DescriptorEvent event) {
        postWrite((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void prePersist(DescriptorEvent event) {
        prePersist((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void preDelete(DescriptorEvent event) {
        preDelete((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void preRemove(DescriptorEvent event){
        preRemove((oracle.toplink.publicinterface.DescriptorEvent)event);
    }
    
    public void preInsert(DescriptorEvent event) {
        preInsert((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void preUpdate(DescriptorEvent event) {
        preUpdate((oracle.toplink.publicinterface.DescriptorEvent)event);
    }
    
    public void preUpdateWithChanges(DescriptorEvent event) {
        preUpdateWithChanges((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void preWrite(DescriptorEvent event) {
        preWrite((oracle.toplink.publicinterface.DescriptorEvent)event);
    }

    public void aboutToInsert(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void aboutToUpdate(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void aboutToDelete(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postBuild(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postClone(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postDelete(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postInsert(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postMerge(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postRefresh(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postUpdate(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void postWrite(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void prePersist(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void preDelete(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void preInsert(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void preRemove(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void preUpdate(oracle.toplink.publicinterface.DescriptorEvent event) {
    }
    
    public void preUpdateWithChanges(oracle.toplink.publicinterface.DescriptorEvent event) {
    }

    public void preWrite(oracle.toplink.publicinterface.DescriptorEvent event) {
    }
}