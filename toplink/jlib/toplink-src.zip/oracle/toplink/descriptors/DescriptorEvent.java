// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.descriptors;

import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.internal.sessions.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.queryframework.*;
import oracle.toplink.sessions.Record;

/**
 * <p><b>Purpose</b>: Encapsulate the information provided with descriptor events.
 * This is used as the argument to any event raised by the descriptor.
 * Events can be registered for, through two methods, the first is by providing a method
 * to be called on the object that a paticular operation is being performed on.
 * The second is by registering an event listener to be notified when any event occurs
 * for that descriptor.  The second method is more similar to the java beans event model
 * and requires the registered listener to implement the DescriptorEventListener interface.
 *
 * @see DescriptorEventManager
 * @see DescriptorEventListener
 * @see DescriptorEventAdapter
 */
public class DescriptorEvent extends oracle.toplink.publicinterface.DescriptorEvent {

    /**
     * INTERNAL:
     * Most events are trigger from queries, so this is a helper method.
     */
    public DescriptorEvent(int eventCode, ObjectLevelModifyQuery query) {
        super(eventCode, query);
    }

    /**
     * INTERNAL:
     * All events require a source object.
     */
    public DescriptorEvent(Object sourceObject) {
        super(sourceObject);
    }

    /**
     * PUBLIC:
     * Re-populate the database row with the values from the source object based upon the
     * attribute's mapping. Provided as a helper method for modifying the row during event
     * handling.
     */
    public void applyAttributeValuesIntoRow(String attributeName) {
        super.applyAttributeValuesIntoRow(attributeName);
    }

    /**
     * PUBLIC:
     * Returns the Object changeSet if available
     */
    public ObjectChangeSet getChangeSet() {
        return super.getChangeSet();
    }

    /**
     * PUBLIC:
     * The source descriptor of the event.
     */
    public ClassDescriptor getClassDescriptor() {
		Descriptor desc = getDescriptor();
		if (desc instanceof ClassDescriptor) {
			return (ClassDescriptor)desc;
		} else {
			throw ValidationException.cannotCastToClass(desc, desc.getClass(), ClassDescriptor.class);
		}
    }

    /**
     * PUBLIC:
     * The code of the descriptor event being raised.
     * This is an integer constant value from DescriptorEventManager.
     */
    public int getEventCode() {
        return super.getEventCode();
    }

    /**
     * PUBLIC:
     * Synonym for source.
     */
    public Object getObject() {
        return super.getObject();
    }

    /**
     * PUBLIC:
     * The source object represents the object the event is being raised on,
     * some events also require a second object, for example the original object in a postClone.
     *
     * @see #getSource()
     */
    public Object getOriginalObject() {
        return super.getOriginalObject();
    }

    /**
     * PUBLIC:
     * The query causing the event.
     */
    public DatabaseQuery getQuery() {
        return super.getQuery();
    }

    /**
     * PUBLIC:
     * Optionally a database row may be provided on some events, (such as aboutToUpdate).
     */
    public Record getRecord() {
        return super.getRow();
    }

    /**
     * PUBLIC:
     * The session in which the event is raised.
     */
    public Session getSession() {
        return super.getSession();
    }

    /**
     * ADVANCED:
     * Use this method when updating object attribute values, with unmapped objects Integer, String or others. in events to ensure that all
     * required objects are updated.  TopLink will automaticaly update all objects and changesets
     * envolved.  TopLink will update the field, in the row, to have the new value for the field
     * that this mapping maps to.
     */
    public void updateAttributeWithObject(String attributeName, Object value) {
        super.updateAttributeWithObject(attributeName, value);
    }

    /**
     * ADVANCED:
     * Use this method when updating object attribute values, with unmapped objects Integer, String or others. in events to ensure that all
     * required objects are updated.  TopLink will automaticaly update all objects and changesets
     * envolved.  TopLink will update the field, in the row, to have the new value for the field
     * that this mapping maps to.
     */
    public void updateAttributeAddObjectToCollection(String attributeName, Object mapKey, Object value) {
        super.updateAttributeAddObjectToCollection(attributeName, mapKey, value);
    }

    /**
     * ADVANCED:
     * Use this method when updating object attribute values, with unmapped objects Integer, String or others. in events to ensure that all
     * required objects are updated.  TopLink will automaticaly update all objects and changesets
     * envolved.  TopLink will update the field, in the row, to have the new value for the field
     * that this mapping maps to.
     */
    public void updateAttributeRemoveObjectFromCollection(String attributeName, Object mapKey, Object value) {
        super.updateAttributeRemoveObjectFromCollection(attributeName, mapKey, value);
    }
}