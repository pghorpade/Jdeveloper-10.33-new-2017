// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.descriptors;

import java.util.*;

/**
 * <p><b>Purpose</b>: The event manager allows for a descriptor to specify that an object should
 * be notified when a TopLink event occurs.  It also determines how the object will be notified.
 * To specify an event a method name can be registered to be called on the object when the event
 * occurs.  Events can be used to extend the TopLink reading and writing behavior.
 * <p>
 * These events include:
 * <ul>
 * <li> pre/postWrite - occurs when an object is written (occurs even if no changes to the object).
 * <li> pre/postInsert - occurs when an object is inserted.
 * <li> pre/postUpdate - occurs when an object is updated (occurs even if no changes to the object).
 * <li> pre/postDeleted - occurs when an object is deleted.
 * <li> postBuild/postRefresh - occurs after a object has been built/refreshed from its database row.
 * <li> aboutTo/Insert/Update - occurs when an object is about to be inserted/update allows for row modification.
 * <li> postClone - occurs when an object is registered/cloned in a unit of work.
 * <li> postMerge - occurs when an object is merged with its original in a unit of work.
 * </ul>
 *
 * @see ClassDescriptor
 */
public class DescriptorEventManager extends oracle.toplink.publicinterface.DescriptorEventManager {

    /**
     * INTERNAL:
     * Returns a new DescriptorEventManager for the specified Descriptor.
     */
    public DescriptorEventManager() {
        super();
    }

    /**
     * PUBLIC:
     * Listener objects can be registered with the event manager to be notified when an event
     * occurs on any instance of the descriptor's class.
     */
    public void addListener(DescriptorEventListener listener) {
        super.addListener(listener);
    }

    /**
     * PUBLIC:
     * Returns the Listener objects that have been added.
     *
     * @see #addListener(DescriptorEventListener)
     */
    public Vector getEventListeners() {
        return super.getEventListeners();
    }

    /**
     * PUBLIC:
     * The name of the method called when an object is inserted.
     */
    public String getAboutToInsertSelector() {
        return (String)getEventSelectors().elementAt(AboutToInsertEvent);
    }

    /**
     * PUBLIC:
     * The name of the method called when an object is updated.
     */
    public String getAboutToUpdateSelector() {
        return (String)getEventSelectors().elementAt(AboutToUpdateEvent);
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is built.
     */
    public String getPostBuildSelector() {
        return super.getPostBuildSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is cloned.
     */
    public String getPostCloneSelector() {
        return super.getPostCloneSelector();
    }

    /**
     * PUBLIC:
     *  The name of the method called after an object is deleted.
     */
    public String getPostDeleteSelector() {
        return super.getPostDeleteSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is inserted.
     */
    public String getPostInsertSelector() {
        return super.getPostInsertSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is merged.
     */
    public String getPostMergeSelector() {
        return super.getPostMergeSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is refreshed.
     */
    public String getPostRefreshSelector() {
        return super.getPostRefreshSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is updated.
     */
    public String getPostUpdateSelector() {
        return super.getPostUpdateSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called after an object is written.
     */
    public String getPostWriteSelector() {
        return super.getPostWriteSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called before an object is deleted.
     */
    public String getPreDeleteSelector() {
        return super.getPreDeleteSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called before an object is inserted.
     */
    public String getPreInsertSelector() {
        return super.getPreInsertSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called before an object is updated.
     */
    public String getPreUpdateSelector() {
        return super.getPreUpdateSelector();
    }

    /**
     * PUBLIC:
     * The name of the method called before an object is written.
     */
    public String getPreWriteSelector() {
        return super.getPreWriteSelector();
    }

    /**
     * PUBLIC:
     * Remove a event listener.
     */
    public void removeListener(DescriptorEventListener listener) {
        super.removeListener(listener);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called when an object's row it about to be inserted.
     * This uses the optional event argument of the DatabaseRow.
     * This is different from pre/postInsert because it occurs after the row has already been built.
     * This event can be used to modify the row before insert, such as adding a user inserted by.
     */
    public void setAboutToInsertSelector(String aboutToInsertSelector) {
        super.setAboutToInsertSelector(aboutToInsertSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called when an object's row it about to be updated.
     * This uses the optional event argument of the DatabaseRow.
     * This is different from pre/postUpdate because it occurs after the row has already been built,
     * and it ONLY called if the update is required (changed within a unit of work), as the other occur ALWAYS.
     * This event can be used to modify the row before insert, such as adding a user inserted by.
     */
    public void setAboutToUpdateSelector(String aboutToUpdateSelector) {
        super.setAboutToUpdateSelector(aboutToUpdateSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been built from the database.
     * This uses the optional event argument of the DatabaseRow.
     * This event can be used to correctly initialize an object's non-persistent attributes or to
     * perform complex optimizations or mappings.
     * This event is called whenever an object is built.
     */
    public void setPostBuildSelector(String postBuildSelector) {
        super.setPostBuildSelector(postBuildSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been cloned into a unit of work.
     * This uses the optional event argument of the orignial object (the source object it the clone).
     * This event can be used to correctly initialize an object's non-persistent attributes.
     */
    public void setPostCloneSelector(String postCloneSelector) {
        super.setPostCloneSelector(postCloneSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been deleted from the database.
     * This event can notify/remove any dependents on the object.
     */
    public void setPostDeleteSelector(String postDeleteSelector) {
        super.setPostDeleteSelector(postDeleteSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been inserted into the database.
     * This event can be used to notify any dependent on the object, or to update information not accessible
     * until the object has been inserted.
     */
    public void setPostInsertSelector(String postInsertSelector) {
        super.setPostInsertSelector(postInsertSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been merge from a unit of work.
     * This uses the optional event argument of the orignial object which is the object being merged from,
     * the source object is the object being merged into.
     * This event can be used to correctly initialize an object's non-persistent attributes.
     */
    public void setPostMergeSelector(String postMergeSelector) {
        super.setPostMergeSelector(postMergeSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been refreshed from the database.
     * This uses the optional event argument of the DatabaseRow.
     * This event can be used to correctly initialize an object's non-persistent attributes or to
     * perform complex optimizations or mappings.
     * This event is only called on refreshes of existing objects.
     */
    public void setPostRefreshSelector(String postRefreshSelector) {
        super.setPostRefreshSelector(postRefreshSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been updated into the database.
     */
    public void setPostUpdateSelector(String postUpdateSelector) {
        super.setPostUpdateSelector(postUpdateSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that has just been written to the database.
     * This event is raised on any registered object in a unit of work, even if it has not changed,
     * refer to the "aboutToUpdate" selector if it is required for the event to be raised only when the object
     * has been changed.
     * This will be called on all inserts and updates, after the "postInsert/Update" event has been raised.
     * This event can be used to notify any dependent on the object.
     */
    public void setPostWriteSelector(String postWriteSelector) {
        super.setPostWriteSelector(postWriteSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that is going to be deleted from the database.
     * This event can notify/remove any dependents on the object.
     */
    public void setPreDeleteSelector(String preDeleteSelector) {
        super.setPreDeleteSelector(preDeleteSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that is going to be inserted into the database.
     * This event can be used to notify any dependent on the object or acquire the object's id through a
     * custom mechanism.
     */
    public void setPreInsertSelector(String preInsertSelector) {
        super.setPreInsertSelector(preInsertSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that is going to be updated into the database.
     * This event is raised on any registered object in a unit of work, even if it has not changed,
     * refer to the "aboutToUpdate" selector if it is required for the event to be raised only when the object
     * has been changed.
     * This event can be used to notify any dependent on the object.
     */
    public void setPreUpdateSelector(String preUpdateSelector) {
        super.setPreUpdateSelector(preUpdateSelector);
    }

    /**
     * PUBLIC:
     * A method can be registered to be called on a object that is going to be written to the database.
     * This event is raised on any registered object in a unit of work, even if it has not changed,
     * refer to the "aboutToUpdate" selector if it is required for the event to be raised only when the object
     * has been changed.
     * This will be called on all inserts and updates, before the "preInsert/Update" event has been raised.
     * This event can be used to notify any dependent on the object.
     */
    public void setPreWriteSelector(String preWriteSelector) {
        super.setPreWriteSelector(preWriteSelector);
    }
}