// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.descriptors.changetracking;

import oracle.toplink.internal.sessions.ObjectChangeSet;
import oracle.toplink.queryframework.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.internal.descriptors.*;
import oracle.toplink.internal.sessions.MergeManager;
import oracle.toplink.publicinterface.Descriptor;
import oracle.toplink.mappings.*;
import oracle.toplink.descriptors.DescriptorEvent;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.publicinterface.Session;
import oracle.toplink.publicinterface.UnitOfWork;
import oracle.toplink.internal.helper.IdentityHashtable;
import java.util.*;

/**
 * PUBLIC:
 * A DeferredChangeDetectionPolicy defers all change detection to the UnitOfWork's
 * change detection process.  Essentially, the calculateChanges() method will run
 * for all objects in a UnitOfWork.  This is the default ObjectChangePolicy
 * 
 * @author Tom Ware
 */
public class DeferredChangeDetectionPolicy implements ObjectChangePolicy, java.io.Serializable {

    /**
     * INTERNAL:
     * calculateChanges creates a change set for a particular object.  In DeferredChangeDetectionPolicy
     * all mappings will be compared against a backup copy of the object.
     * @return oracle.toplink.changesets.ObjectChangeSet an object change set describing
     * the changes to this object
     * @param java.lang.Object clone the Object to compute a change set for
     * @param java.lang.Object backUp the old version of the object to use for comparison
     * @param oracle.toplink.internal.sessions.UnitOfWorkChangeSet the change set to add changes to
     * @param Session the current session
     * @param Descriptor the descriptor for this object
     */
    public ObjectChangeSet calculateChanges(Object clone, Object backUp, oracle.toplink.internal.sessions.UnitOfWorkChangeSet changeSet, Session session, Descriptor descriptor) {
        boolean isNew = ((backUp == null) || ((((UnitOfWork)session).isObjectNew(clone)) && (!descriptor.isAggregateDescriptor())));

        if (!session.usesOldCommit()) {
            // PERF: Provide EJB life-cycle callbacks without using events.
            if (descriptor.hasCMPPolicy()) {
                descriptor.getCMPPolicy().invokeEJBStore(clone, session);
            }
        
            // PERF: Avoid events if no listeners.
            if (descriptor.getEventManager().hasAnyEventListeners()) {
                // The query is built for compatability to old event mechanism.
                WriteObjectQuery writeQuery = new WriteObjectQuery(clone.getClass());
                writeQuery.setObject(clone);
                writeQuery.setBackupClone(backUp);
                writeQuery.setSession(session);
                writeQuery.setDescriptor(descriptor);

                descriptor.getEventManager().executeEvent(new DescriptorEvent(DescriptorEventManager.PreWriteEvent, writeQuery));

                if (isNew) {
                    descriptor.getEventManager().executeEvent(new DescriptorEvent(DescriptorEventManager.PreInsertEvent, writeQuery));
                } else {
                    descriptor.getEventManager().executeEvent(new DescriptorEvent(DescriptorEventManager.PreUpdateEvent, writeQuery));
                }
            }
        }
        
        ObjectChangeSet changes = createObjectChangeSet(clone, backUp, changeSet, isNew, session, descriptor);
        //Check if the user set the PK to null and throw an exception (bug# 4569755)
        if(changes.getPrimaryKeys() == null && !isNew && !changes.isAggregate()) {
            if(!(((UnitOfWork)session).isNestedUnitOfWork()) || (((UnitOfWork)session).isNestedUnitOfWork() && !((UnitOfWork)((UnitOfWork)session).getParent()).isObjectNew(backUp))) {
                throw ValidationException.nullPrimaryKeyInUnitOfWorkClone();
            }
        }

        // if forceUpdate or optimistic read locking is on, mark changeSet.  This is to force it
        // to be stored and used for writing out SQL later on
        if ((descriptor.getCMPPolicy() != null) && (descriptor.getCMPPolicy().getForceUpdate())) {
            changes.setHasCmpPolicyForcedUpdate(true);
        }
        if (!changes.hasForcedChangesFromCascadeLocking()) {
            changes.setShouldModifyVersionField((Boolean)((UnitOfWork)session).getOptimisticReadLockObjects().get(clone));
        }
        if (changes.hasChanges() || changes.hasForcedChanges()) {
            return changes;
        }
        return null;
    }

    /**
     * INTERNAL:
     * This is a place holder for reseting the listener on one of the subclasses
     */
    public void clearChanges(Object object, UnitOfWork uow, Descriptor descriptor) {
    }

    /**
     * INTERNAL:
     * Create ObjectChangeSet
     */
    public ObjectChangeSet createObjectChangeSet(Object clone, Object backUp, oracle.toplink.internal.sessions.UnitOfWorkChangeSet changeSet, boolean isNew, Session session, Descriptor descriptor) {
        return this.createObjectChangeSetThroughComparison(clone, backUp, changeSet, isNew, session, descriptor);
    }

    /**
     * INTERNAL:
     * Create ObjectChangeSet
     */
    public ObjectChangeSet createObjectChangeSetThroughComparison(Object clone, Object backUp, oracle.toplink.internal.sessions.UnitOfWorkChangeSet changeSet, boolean isNew, Session session, Descriptor descriptor) {
        ObjectBuilder builder = descriptor.getObjectBuilder();
        ObjectChangeSet changes = builder.createObjectChangeSet(clone, changeSet, isNew, session);

        // The following code deals with reads that force changes to the flag associated with optimistic locking.
        if (descriptor.usesOptimisticLocking() && changes.getPrimaryKeys() != null) {
            changes.setInitialWriteLockValue(descriptor.getOptimisticLockingPolicy().getWriteLockValue(clone, changes.getPrimaryKeys(), session));
        }

        // PERF: Avoid synchronized enumerator as is concurrency bottleneck.
        Vector mappings = descriptor.getMappings();
        for (int index = 0; index < mappings.size(); index++) {
            DatabaseMapping mapping = (DatabaseMapping)mappings.get(index);
            changes.addChange(mapping.compareForChange(clone, backUp, changes, session));
        }

        return changes;
    }

    /**
     * INTERNAL:
     * This method is used to dissable changetracking temporarily
     */
    public void dissableEventProcessing(Object changeTracker){
        //no-op
    }

    /**
     * INTERNAL:
     * This method is used to enable changetracking temporarily
     */
    public void enableEventProcessing(Object changeTracker){
        //no-op
    }
    
    /**
     * INTERNAL:
     * Return true if the Object should be compared, false otherwise.  In DeferredChangeDetectionPolicy,
     * true is always returned since always allow the UnitOfWork to calculate changes.
     * @param java.lang.Object object - the object that will be compared
     * @param oracle.toplink.publicinterface.UnitOfWork unitOfWork - the active unitOfWork
     * @param oracle.toplink.publicinterface.Descriptor descriptor - the descriptor for the current object
     */
    public boolean shouldCompareForChange(Object object, UnitOfWork unitOfWork, Descriptor descriptor) {
        return true;
    }

    /**
     * INTERNAL:
     * Build back up clone.  Used if clone is new because listener should not be set.
     */
    public Object buildBackupClone(Object clone, ObjectBuilder builder, UnitOfWork uow) {
        return builder.buildBackupClone(clone, uow);
    }

    /**
     * INTERNAL:
     * Assign Changelistner to an aggregate object
     */
    public void setAggregateChangeListener(Object parent, Object aggregate, UnitOfWork uow, Descriptor descriptor, String mappingAttribute){
        //no-op
    }
    
    /**
     * INTERNAL:
     * Set ChangeListener for the clone
     */
    public void setChangeListener(Object clone, UnitOfWork uow, Descriptor descriptor) {
        //no-op
    }

    /**
     * INTERNAL:
     * Set the ObjectChangeSet on the Listener, initially used for aggregate support
     */
    public void setChangeSetOnListener(ObjectChangeSet objectChangeSet, Object clone){
        //no-op
    }
    
    /**
     * INTERNAL:
     * Clear changes in the ChangeListener of the clone
     */
    public void updateWithChanges(Object clone, ObjectChangeSet objectChangeSet, UnitOfWork uow, Descriptor descriptor) {
        if (objectChangeSet == null) {
            return;
        }
        Object backupClone = uow.getCloneMapping().get(clone);
        if (backupClone != null) {
            MergeManager mergeManager = new MergeManager(uow);
            mergeManager.setCascadePolicy(MergeManager.NO_CASCADE);
            descriptor.getObjectBuilder().mergeChangesIntoObject(backupClone, objectChangeSet, clone, mergeManager);
        }
        clearChanges(clone, uow, descriptor);
    }

    /**
     * INTERNAL:
     * This may cause a property change event to be raised to a listner in the case that a listener exists.
     * If there is no listener then this call is a no-op
     */
    public void raiseInternalPropertyChangeEvent(Object source, String propertyName, Object oldValue, Object newValue){
        //no-op
    }

    /**
     * INTERNAL:
     * This method is used to revert an object within the unit of work
     * @param cloneMapping may not be the same as whats in the uow
     */
    public void revertChanges(Object clone, Descriptor descriptor, UnitOfWork uow, IdentityHashtable cloneMapping) {
        cloneMapping.put(clone, buildBackupClone(clone, descriptor.getObjectBuilder(), uow));
        clearChanges(clone, uow, descriptor);
    }

    /**
     * INTERNAL:
     * initialize the Policy
     */
    public void initialize(Session session, Descriptor descriptor) {
        //do nothing
    }

    /**
     * Used to track instances of the change policies without doing an instance of check
     */
    public boolean isDeferredChangeDetectionPolicy(){
        return true;
    }

    /**
     * Used to track instances of the change policies without doing an instance of check
     */
    public boolean isObjectChangeTrackingPolicy(){
        return false;
    }

    /**
     * Used to track instances of the change policies without doing an instance of check
     */
    public boolean isAttributeChangeTrackingPolicy(){
        return false;
    }
}