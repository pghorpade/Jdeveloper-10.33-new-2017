// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.descriptors;

import java.io.*;
import java.util.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.queryframework.*;

/**
 * <b>Purpose</b>: Allows for a descriptor's implemented interfaces to be configured.
 * Generally Interface Descriptors are used for 1 of 2 reasons:<p>
 *      a. Interface descriptors can be used to query across a set of classes that do not share a table.<br>
 *      b. As a target of a variable one to one mapping.
 *
 * @since TopLink for Java 2.0
 */
public class InterfacePolicy implements Serializable {
    protected Vector parentInterfaces;
    protected Vector parentInterfaceNames;
    protected Vector parentDescriptors;
    protected Vector childDescriptors;
    protected Descriptor descriptor;
    protected Class implementorDescriptor;
    protected String implementorDescriptorClassName;

    /**
     * INTERNAL:
     * Create a new policy.
     * Only descriptor involved in interface should have a policy.
     */
    public InterfacePolicy() {
        this.childDescriptors = oracle.toplink.internal.helper.NonSynchronizedVector.newInstance();
        this.parentInterfaces = oracle.toplink.internal.helper.NonSynchronizedVector.newInstance(2);
        this.parentInterfaceNames = oracle.toplink.internal.helper.NonSynchronizedVector.newInstance(2);
        this.parentDescriptors = oracle.toplink.internal.helper.NonSynchronizedVector.newInstance(2);
    }

    /**
     * INTERNAL:
     * Create a new policy.
     * Only descriptor involved in interface should have a policy.
     */
    public InterfacePolicy(Descriptor descriptor) {
        this();
        this.descriptor = descriptor;
    }

    /**
     * INTERNAL:
     * Add child descriptor to the parent descriptor.
     */
    public void addChildDescriptor(Descriptor childDescriptor) {
        getChildDescriptors().addElement(childDescriptor);
    }

    /**
     * INTERNAL:
     * Add parent descriptor.
     */
    public void addParentDescriptor(Descriptor parentDescriptor) {
        getParentDescriptors().addElement(parentDescriptor);
    }

    /**
     * PUBLIC:
     * Add the parent Interface class.
     *
     * This method should be called once for each parent Interface of the Descriptor.
     */
    public void addParentInterface(Class parentInterface) {
        getParentInterfaces().addElement(parentInterface);
    }

    public void addParentInterfaceName(String parentInterfaceName) {
        getParentInterfaceNames().addElement(parentInterfaceName);
    }

    /**
     * INTERNAL:
     * Return all the child descriptors.
     */
    public Vector getChildDescriptors() {
        return childDescriptors;
    }

    protected Descriptor getDescriptor() {
        return descriptor;
    }

    /**
     * INTERNAL:
     * Returns the implementor descriptor class.
     */
    public Class getImplementorDescriptor() {
        return implementorDescriptor;
    }

    /**
     * INTERNAL:
     * Returns the implementor descriptor class name.
     */
    public String getImplementorDescriptorClassName() {
        if ((implementorDescriptorClassName == null) && (implementorDescriptor != null)) {
            implementorDescriptorClassName = implementorDescriptor.getName();
        }
        return implementorDescriptorClassName;
    }

    /**
     * INTERNAL:
     * Return all the parent descriptors.
     */
    public Vector getParentDescriptors() {
        return parentDescriptors;
    }

    /**
     * INTERNAL:
     * Return the vector of parent interfaces.
     */
    public Vector getParentInterfaces() {
        return parentInterfaces;
    }

    public Vector getParentInterfaceNames() {
        if (parentInterfaceNames.isEmpty() && !parentInterfaces.isEmpty()) {
            for (int i = 0; i < parentInterfaces.size(); i++) {
                parentInterfaceNames.addElement(((Class)parentInterfaces.elementAt(i)).getName());
            }
        }
        return parentInterfaceNames;
    }

    /**
     * INTERNAL:
     * Set the vector to store parent interfaces.
     */
    public void initialize(Session session) {
    }

    /**
     * INTERNAL:
     * Check if it is a child descriptor.
     */
    public boolean isInterfaceChildDescriptor() {
        return ((!(parentInterfaces == null) && !parentInterfaces.isEmpty()) ||
            (!(parentInterfaceNames == null) && !parentInterfaceNames.isEmpty()));
    }

    /**
     * INTERNAL:
     * Select all objects for an interface descriptor.
     * This is accomplished by selecting for all of the concrete classes and then merging the objects.
     *
     * @return Vector containing all objects.
     * @exception DatabaseException - an error has occurred on the database.
     */
    public Object selectAllObjectsUsingMultipleTableSubclassRead(ReadAllQuery query) throws DatabaseException {
        oracle.toplink.internal.queryframework.ContainerPolicy containerPolicy = query.getContainerPolicy();
        Object objects = containerPolicy.containerInstance(1);

        for (Enumeration childDescriptors = getChildDescriptors().elements();
                 childDescriptors.hasMoreElements();) {
            ReadAllQuery concreteQuery = (ReadAllQuery)query.clone();
            Descriptor descriptor = (Descriptor)childDescriptors.nextElement();
            Class javaClass = descriptor.getJavaClass();
            concreteQuery.setReferenceClass(javaClass);
            concreteQuery.setDescriptor(descriptor);

            objects = containerPolicy.concatenateContainers(objects, query.getSession().executeQuery(concreteQuery));
        }

        return objects;
    }

    /**
     * INTERNAL:
     * Select one object of any concrete subclass.
     */
    public Object selectOneObjectUsingMultipleTableSubclassRead(ReadObjectQuery query) throws DatabaseException, QueryException {
        Object object = null;
        for (Enumeration childDescriptors = getChildDescriptors().elements();
                 childDescriptors.hasMoreElements() && (object == null);) {
            ReadObjectQuery concreteQuery = (ReadObjectQuery)query.clone();
            Descriptor descriptor = (Descriptor)childDescriptors.nextElement();
            Class javaClass = descriptor.getJavaClass();
            concreteQuery.setReferenceClass(javaClass);
            concreteQuery.setDescriptor(descriptor);
            object = query.getSession().executeQuery(concreteQuery);
        }

        return object;
    }

    /**
     * INTERNAL:
     * Set the descriptor.
     */
    public void setDescriptor(Descriptor descriptor) {
        this.descriptor = descriptor;
    }

    /**
     * INTERNAL:
     * Sets the implementor descriptor class.
     */
    public void setImplementorDescriptor(Class implementorDescriptor) {
        this.implementorDescriptor = implementorDescriptor;
    }

    /**
     * INTERNAL:
     * Sets the implementor descriptor class name.
     */
    public void setImplementorDescriptorClassName(String implementorDescriptorClassName) {
        this.implementorDescriptorClassName = implementorDescriptorClassName;
    }

    /**
     * Set the Vector to store parent interfaces.
     */
    public void setParentInterfaces(Vector parentInterfaces) {
        this.parentInterfaces = parentInterfaces;
    }

    public void setParentInterfaceNames(Vector parentInterfaceNames) {
        this.parentInterfaceNames = parentInterfaceNames;
    }

    /**
     * INTERNAL:
     * Returns true if this descriptor should be ignored and the implenting
     * descriptor should be used instead.
     */
    public boolean usesImplementorDescriptor() {
        return (implementorDescriptor != null);
    }
}
