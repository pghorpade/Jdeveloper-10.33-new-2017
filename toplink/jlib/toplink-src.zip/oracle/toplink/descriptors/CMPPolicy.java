// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.descriptors;

import oracle.toplink.publicinterface.Session;
import oracle.toplink.publicinterface.Descriptor;
import oracle.toplink.exceptions.DescriptorException;
import oracle.toplink.queryframework.UpdateObjectQuery;
import oracle.toplink.internal.descriptors.CMPLifeCycleListener;
import oracle.toplink.internal.helper.FalseUndefinedTrue;

/**
 * <p>
 * <b>Description</b>: Place holder for CMP specific information.  This class can be set on the Descriptor.
 *
 * @see oracle.toplink.descriptors.PessimisticLockingPolicy
 *
 * @since TopLink 10.1.3
 */
public class CMPPolicy implements java.io.Serializable {
    // SPECJ: Temporary global optimization flag, use to disable uow merge.
    public static boolean OPTIMIZE_PESSIMISTIC_CMP = false;
    
    protected int forceUpdate;
    protected int updateAllFields;

    /** Allow the bean to always be locked as it enters a new transaction. */
    protected PessimisticLockingPolicy pessimisticLockingPolicy;

    /** Allows for the CMP life-cycle events to be intercepted from core by the CMP integration. */
    protected CMPLifeCycleListener lifeCycleListener;

    /** Class originally mapped, before anything was generated. */
    protected Class mappedClass;
    protected Descriptor descriptor;

    /** The object deferral level.  This controlls when objects changes will be sent to the Database. */
    protected int modificationDeferralLevel = ALL_MODIFICATIONS;

    /** defer no changes */
    public static final int NONE = 0;

    /** defer updates */
    public static final int UPDATE_MODIFICATIONS = 1;

    /** defer all modifications, inserts and deletes included (default) */
    public static final int ALL_MODIFICATIONS = 2;

    /** This setting will allow customers to control when Toplink will issue the insert SQL for CMP beans. */
    protected int nonDeferredCreateTime = UNDEFINED;

    /** undefined if it is non-deferred issue sql at create */
    public static final int UNDEFINED = 0;

    /** issue SQL after ejbCreate but before ejbPostCreate */
    public static final int AFTER_EJBCREATE = 1;

    /** issue SQL after ejbPostCreate */
    public static final int AFTER_EJBPOSTCREATE = 2;

    public CMPPolicy() {
        this.forceUpdate = FalseUndefinedTrue.Undefined;
        this.updateAllFields = FalseUndefinedTrue.Undefined;
    }

    /**
     * INTERNAL:
     * Notify that the insert operation has occured, allow a sequence primary key to be reset.
     */
    public void postInsert(Object bean, Session session) {
        if (getLifeCycleListener() != null) {
            getLifeCycleListener().postInsert(bean, session);
        }
    }

    /**
     * INTERNAL:
     * Allow the ejbLoad life-cycle callback to be called.
     */
    public void invokeEJBLoad(Object bean, Session session) {
        if (getLifeCycleListener() != null) {
            getLifeCycleListener().invokeEJBLoad(bean, session);
        }
    }

    /**
     * INTERNAL:
     * Allow the ejbStore life-cycle callback to be called.
     */
    public void invokeEJBStore(Object bean, Session session) {
        if (getLifeCycleListener() != null) {
            getLifeCycleListener().invokeEJBStore(bean, session);
        }
    }

    /**
     * INTERNAL:
     * Return the CMP life-cycle listener, used to intercept events from core by CMP integration.
     */
    public CMPLifeCycleListener getLifeCycleListener() {
        return this.lifeCycleListener;
    }

    /**
     * INTERNAL:
     * Set the CMP life-cycle listener, used to intercept events from core by CMP integration.
     * This should be set by the CMP integration during deployment.
     */
    public void setLifeCycleListener(CMPLifeCycleListener lifeCycleListener) {
        this.lifeCycleListener = lifeCycleListener;
    }

    /**
     * ADVANCED:
     * This setting is only available for CMP beans that are not being deferred.
     * Using it will allow TopLink to  determine if the INSERT SQL should be sent to
     * the database before or after the postCreate call.
     */
    public int getNonDeferredCreateTime() {
        return this.nonDeferredCreateTime;
    }

    /**
     * PUBLIC:
     * Return the policy for bean pessimistic locking
     * @see #oracle.toplink.descriptors.PessimisticLockingPolicy
     */
    public PessimisticLockingPolicy getPessimisticLockingPolicy() {
        return pessimisticLockingPolicy;
    }

    /**
     * ADVANCED:
     * This can be set to control when changes to objects are submitted to the database
     * This is only applicable to TopLink's CMP implementation and not available within
     * the core.
     */
    public void setDeferModificationsUntilCommit(int deferralLevel) {
        this.modificationDeferralLevel = deferralLevel;
    }

    /**
     * PUBLIC:
     * Define the mapped class. This is the class which was originally mapped in the MW
     *
     * @param Class newMappedClass
     */
    public void setMappedClass(Class newMappedClass) {
        mappedClass = newMappedClass;
    }

    /**
     * PUBLIC:
     * Answer the mapped class. This is the class which was originally mapped in the MW
     *
     */
    public Class getMappedClass() {
        return mappedClass;
    }

    /**
     * ADVANCED:
     * This setting is only available for CMP beans that are not being deferred.
     * Using it will allow TopLink to  determine if the INSERT SQL should be sent to
     * the database before or after the postCreate call.
     */
    public void setNonDeferredCreateTime(int createTime) {
        this.nonDeferredCreateTime = createTime;
    }

    /**
     * PUBLIC:
     * Configure bean pessimistic locking
     *
     * @param PessimisticLockingPolicy policy
     * @see #oracle.toplink.descriptors.PessimisticLockingPolicy
     */
    public void setPessimisticLockingPolicy(PessimisticLockingPolicy policy) {
        pessimisticLockingPolicy = policy;
    }

    /**
     * PUBLIC:
     * Return true if bean pessimistic locking is configured
     */
    public boolean hasPessimisticLockingPolicy() {
        return pessimisticLockingPolicy != null;
    }

    /**
     * ADVANCED:
     * This can be used to control when changes to objects are submitted to the database
     * This is only applicable to TopLink's CMP implementation and not available within
     * the core.
     */
    public int getDeferModificationsUntilCommit() {
        return this.modificationDeferralLevel;
    }

    /**
     * ADVANCED:
     * Return true if descriptor is set to always update all registered objects of this type
     */
    public boolean getForceUpdate() {
        // default to false
        return (this.forceUpdate == FalseUndefinedTrue.True);
    }

    /**
     * ADVANCED:
     * Configure whether TopLink should always update all registered objects of
     * this type.  NOTE: if set to true, then updateAllFields must also be set
     * to true
     *
     * @param boolean shouldForceUpdate
     */
    public void setForceUpdate(boolean shouldForceUpdate) {
        if (shouldForceUpdate) {
            this.forceUpdate = FalseUndefinedTrue.True;
        } else {
            this.forceUpdate = FalseUndefinedTrue.False;
        }
    }

    /**
     * ADVANCED:
     * Return true if descriptor is set to update all fields for an object of this
     * type when an update occurs.
     */
    public boolean getUpdateAllFields() {
        // default to false
        return (this.updateAllFields == FalseUndefinedTrue.True);
    }

    /**
     * ADVANCED:
     * Configure whether TopLink should update all fields for an object of this
     * type when an update occurs.
     *
     * @param boolean shouldUpdatAllFields
     */
    public void setUpdateAllFields(boolean shouldUpdatAllFields) {
        if (shouldUpdatAllFields) {
            this.updateAllFields = FalseUndefinedTrue.True;
        } else {
            this.updateAllFields = FalseUndefinedTrue.False;
        }
    }

    /**
     * INTERNAL:
     * return internal tri-state value so we can decide whether to inherit or not at init time.
     */
    public int internalGetForceUpdate() {
        return this.forceUpdate;
    }

    /**
     * INTERNAL:
     * return internal tri-state value so we can decide whether to inherit or not at init time.
     */
    public int internalGetUpdateAllFields() {
        return this.updateAllFields;
    }

    /**
     * INTERNAL:
     * internal method to set the tri-state value. This is done in InheritancePolicy at init time.
     */
    public void internalSetForceUpdate(int newForceUpdateValue) {
        this.forceUpdate = newForceUpdateValue;
    }

    /**
     * INTERNAL:
     * internal method to set the tri-state value. This is done in InheritancePolicy at init time.
     */
    public void internalSetUpdateAllFields(int newUpdateAllFieldsValue) {
        this.updateAllFields = newUpdateAllFieldsValue;
    }

    /**
     * INTERNAL:
     * Initialize the CMPPolicy settings.
     */
    public void initialize(Descriptor descriptor, Session session) throws DescriptorException {
        // updateAllFields is true so set custom query in DescriptorQueryManager
        // to force full SQL.  Don't overwrite a user defined query
        if (this.getUpdateAllFields() && !descriptor.getQueryManager().hasUpdateQuery()) {
            descriptor.getQueryManager().setUpdateQuery(new UpdateObjectQuery());
        }

        // make sure updateAllFields is set if forceUpdate is true
        if (this.getForceUpdate() && !this.getUpdateAllFields()) {
            throw DescriptorException.updateAllFieldsNotSet(descriptor);
        }
    }

    /**
     * INTERNAL:
     * @return Returns the owningDescriptor.
     */
    public Descriptor getDescriptor() {
        return descriptor;
    }

    /**
     * INTERNAL:
     * @param owningDescriptor The owningDescriptor to set.
     */
    public void setDescriptor(Descriptor owningDescriptor) {
        this.descriptor = owningDescriptor;
    }
    
    /**
     * INTERNAL:
     * Return if this policy is for CMP3.
     */
    public boolean isCMP3Policy() {
        return false;
    }
}