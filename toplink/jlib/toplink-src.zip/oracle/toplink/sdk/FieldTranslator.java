// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.sdk;

import java.io.*;
import oracle.toplink.publicinterface.*;

/**
 * This interface defines a mechanism for translating the field names in a
 * <code>DatabaseRow</code> from those defined in the data store to
 * those expected by the appropriate <code>Descriptor</code>(s)
 * and vice versa.
 *
 * @author Big Country
 * @since TOPLink/Java 3.0
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.eis}
 */
public interface FieldTranslator extends Serializable {

    /**
     * Translate and return the specified database row that was
     * read from the data store.
     */
    DatabaseRow translateForRead(DatabaseRow row);

    /**
     * Translate and return the specified database row that will
     * be written to the data store.
     */
    DatabaseRow translateForWrite(DatabaseRow row);
}