// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.sequencing;

import java.util.Vector;
import java.io.StringWriter;
import oracle.toplink.publicinterface.*;
import oracle.toplink.queryframework.*;
import oracle.toplink.internal.databaseaccess.Accessor;

/**
 * <p>
 * <b>Purpose</b>:
 * <p>
 */
public class TableSequence extends QuerySequence {

    /** Hold the name of the sequence table */
    protected String tableName = "SEQUENCE";

    /** Hold the name of the column in the sequence table which specifies the sequence numeric value */
    protected String counterFieldName = "SEQ_COUNT";

    /** Hold the name of the column in the sequence table which specifies the sequence name */
    protected String nameFieldName = "SEQ_NAME";
    protected String qualifier = "";

    public TableSequence() {
        super(false, true);
    }

    public TableSequence(String name) {
        super(name, false, true);
    }

    public TableSequence(String name, int size) {
        super(name, size, false, true);
    }

    public TableSequence(String name, String tableName) {
        this(name);
        setTableName(tableName);
    }

    public TableSequence(String name, String tableName, String nameFieldName, String counterFieldName) {
        this(name);
        setTableName(tableName);
        setNameFieldName(nameFieldName);
        setCounterFieldName(counterFieldName);
    }

    public TableSequence(String name, int size, String tableName) {
        this(name, size);
        setTableName(tableName);
    }

    public TableSequence(String name, int size, String tableName, String nameFieldName, String counterFieldName) {
        this(name, size);
        setTableName(tableName);
        setNameFieldName(nameFieldName);
        setCounterFieldName(counterFieldName);
    }

    public boolean equals(Object obj) {
        if (obj instanceof TableSequence) {
            TableSequence other = (TableSequence)obj;
            if (equalNameAndSize(this, other)) {
                return getTableName().equals(other.getTableName()) && getCounterFieldName().equals(other.getCounterFieldName()) && getNameFieldName().equals(other.getNameFieldName());
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public String getCounterFieldName() {
        return counterFieldName;
    }

    public void setCounterFieldName(String name) {
        counterFieldName = name;
    }

    public String getNameFieldName() {
        return nameFieldName;
    }

    public void setNameFieldName(String name) {
        nameFieldName = name;
    }

    public String getTableName() {
        return tableName;
    }

    public String getQualifiedTableName() {
        if (qualifier.equals("")) {
            return getTableName();
        } else {
            return qualifier + "." + getTableName();
        }
    }

    public void setTableName(String name) {
        tableName = name;
    }

    protected ValueReadQuery buildSelectQuery() {
        ValueReadQuery query = new ValueReadQuery();
        query.addArgument(getNameFieldName());
        StringWriter writer = new StringWriter();
        writer.write("SELECT " + getCounterFieldName());
        writer.write(" FROM " + getQualifiedTableName());
        writer.write(" WHERE " + getNameFieldName());
        writer.write(" = #" + getNameFieldName());
        query.setSQLString(writer.toString());

        return query;
    }

    protected DataModifyQuery buildUpdateQuery() {
        DataModifyQuery query = new DataModifyQuery();
        query.addArgument(getNameFieldName());
        query.addArgument("PREALLOC_SIZE");
        StringWriter writer = new StringWriter();
        writer.write("UPDATE " + getQualifiedTableName());
        writer.write(" SET " + getCounterFieldName());
        writer.write(" = " + getCounterFieldName());
        writer.write(" + #PREALLOC_SIZE");
        writer.write(" WHERE " + getNameFieldName() + " = #" + getNameFieldName());
        query.setSQLString(writer.toString());

        return query;
    }

    /**
    * INTERNAL:
    */
    public void onConnect() {
        super.onConnect();
        qualifier = getDatasourcePlatform().getTableQualifier();
    }

    /**
    * INTERNAL:
    */
    public void onDisconnect() {
        qualifier = "";
        super.onDisconnect();
    }
}