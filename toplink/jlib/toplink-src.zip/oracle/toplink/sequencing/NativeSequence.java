// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.sequencing;

import oracle.toplink.queryframework.*;
import oracle.toplink.internal.databaseaccess.DatabasePlatform;
import oracle.toplink.internal.helper.Helper;
import oracle.toplink.exceptions.ValidationException;

/**
 * <p>
 * <b>Purpose</b>:
 * <p>
 */
public class NativeSequence extends QuerySequence {
    public NativeSequence() {
        super();
        setShouldSkipUpdate(true);
    }

    public NativeSequence(String name) {
        super(name);
        setShouldSkipUpdate(true);
    }

    public NativeSequence(String name, int size) {
        super(name, size);
        setShouldSkipUpdate(true);
    }

    public boolean equals(Object obj) {
        if (obj instanceof NativeSequence) {
            return equalNameAndSize(this, (NativeSequence)obj);
        } else {
            return false;
        }
    }

    /**
    * INTERNAL:
    */
    protected ValueReadQuery buildSelectQuery() {
        return ((DatabasePlatform)getDatasourcePlatform()).buildSelectQueryForNativeSequence();
    }

    /**
    * INTERNAL:
    */
    protected ValueReadQuery buildSelectQuery(String seqName, Integer size) {
        return ((DatabasePlatform)getDatasourcePlatform()).buildSelectQueryForNativeSequence(seqName, size);
    }

    /**
    * INTERNAL:
    */
    public void onConnect() {
        DatabasePlatform dbPlatform = null;
        try {
            dbPlatform = (DatabasePlatform)getDatasourcePlatform();
        } catch (ClassCastException ex) {
            if (getSelectQuery() == null) {
                throw ValidationException.platformDoesNotSupportSequence(getName(), Helper.getShortClassName(getDatasourcePlatform()), Helper.getShortClassName(this));
            }
        }
        if (!dbPlatform.supportsNativeSequenceNumbers() && (getSelectQuery() == null)) {
            throw ValidationException.platformDoesNotSupportSequence(getName(), Helper.getShortClassName(getDatasourcePlatform()), Helper.getShortClassName(this));
        }
        super.onConnect();
        if (dbPlatform != null) {
            setShouldAcquireValueAfterInsert(dbPlatform.shouldNativeSequenceAcquireValueAfterInsert());
            setShouldUseTransaction(dbPlatform.shouldNativeSequenceUseTransaction());
        }
    }

    /**
    * INTERNAL:
    */
    public void onDisconnect() {
        setShouldAcquireValueAfterInsert(false);
        setShouldUseTransaction(false);
        super.onDisconnect();
    }
}