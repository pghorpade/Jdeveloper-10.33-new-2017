// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database.oracle;


/**
 * This class can be used to define the dataType with an ObjectTypeConverter
 * to have TopLink bind the object string value as an NCLOB Oracle type.
 */
public class NClob extends oracle.toplink.oraclespecific.NClob {
}