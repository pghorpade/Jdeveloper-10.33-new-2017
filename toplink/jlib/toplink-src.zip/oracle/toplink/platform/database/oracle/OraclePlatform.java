// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database.oracle;


/**
 *    <p><b>Purpose</b>: Provides Oracle specific behaviour.
 *    <p><b>Responsibilities</b>:<ul>
 *    <li> Native SQL for byte[], Date, Time, & Timestamp.
 *    <li> Native sequencing named sequences.
 *    </ul>
 *
 * @since TOPLink/Java 1.0
 */
public class OraclePlatform extends oracle.toplink.internal.databaseaccess.OraclePlatform {
}