// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;

import java.io.*;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.queryframework.ValueReadQuery;


/**
 * <p><b>Purpose</b>: Provides DB2 specific behaviour.
 * <p><b>Responsibilities</b>:<ul>
 * <li> Native SQL for byte[], Date, Time, & Timestamp.
 * <li> Support for table qualified names.
 * </ul>
 *
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class DB2Platform extends oracle.toplink.internal.databaseaccess.DB2Platform {

    /**
     * INTERNAL:
     * Build the identity query for native sequencing.
     */
    public ValueReadQuery buildSelectQueryForNativeSequence() {
        ValueReadQuery selectQuery = new ValueReadQuery();
        StringWriter writer = new StringWriter();
        writer.write("VALUES IDENTITY_VAL_LOCAL()");
        selectQuery.setSQLString(writer.toString());
        return selectQuery;
    }

    /**
     * INTERNAL:
     * Append the receiver's field 'identity' constraint clause to a writer
     */
    public void printFieldIdentityClause(Writer writer) throws ValidationException {
        try {
            writer.write(" GENERATED ALWAYS AS IDENTITY");
        } catch (IOException ioException) {
            throw ValidationException.fileError(ioException);
        }
    }

    /**
     * INTERNAL:
     * If native sequencing is being used on DB2 then the values must be
     * retrieved after the insert.
     * This method is to be used *ONLY* by sequencing classes
     */
    public boolean shouldNativeSequenceAcquireValueAfterInsert() {
        return true;
    }

    /**
     * Return true if the receiver uses host sequence numbers, generated on the database.
     * DB2 does through AS IDENTITY field types.
     */
    public boolean supportsNativeSequenceNumbers() {
        return true;
    }

}
