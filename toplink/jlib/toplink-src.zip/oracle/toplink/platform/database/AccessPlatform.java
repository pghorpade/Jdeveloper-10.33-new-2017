// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;


/**
 * <p><b>Purpose</b>: Provides Microsoft Access specific behaviour.
 *
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class AccessPlatform extends oracle.toplink.internal.databaseaccess.AccessPlatform {
}