// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;


/**
 * <p><b>Purpose</b>: Provides SQL Server specific behaviour.
 * <p><b>Responsibilities</b>:<ul>
 * <li> Native SQL for byte[], Date, Time, & Timestamp.
 * </ul>
 *
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class SQLServerPlatform extends oracle.toplink.internal.databaseaccess.SQLServerPlatform {
}