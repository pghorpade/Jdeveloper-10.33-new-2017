// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;


/**
 *    <B>Purpose</B>: Provides DB2 Mainframe specific behaviour.<P>
 *    <B>Responsibilities</B>:
 *        <UL>
 *            <LI>Specialized CONCAT syntax
 *        </UL>
 *
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class DB2MainframePlatform extends oracle.toplink.internal.databaseaccess.DB2MainframePlatform {
}