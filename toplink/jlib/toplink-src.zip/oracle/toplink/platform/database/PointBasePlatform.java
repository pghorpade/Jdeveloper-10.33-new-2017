// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;

/**
 * Support the Pointbase database.
 * 
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class PointBasePlatform extends oracle.toplink.internal.databaseaccess.PointBasePlatform {
}