// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.database;


/**
 * <p><b>Purpose</b>: Provides SQL Anywhere specific behaviour.
 * <p> For the most part this is the same as Sybase, the outer join syntax is suppose to be different.
 *
 * @since OracleAS TopLink 10<i>g</i> (10.1.3)
 */
public class SQLAnyWherePlatform extends oracle.toplink.internal.databaseaccess.SQLAnyWherePlatform {
}