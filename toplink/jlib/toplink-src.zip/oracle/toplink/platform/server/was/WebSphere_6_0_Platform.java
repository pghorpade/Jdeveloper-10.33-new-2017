// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.platform.server.was;

import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.transaction.was.*;

/**
 * PUBLIC:
 *
 * This is the concrete subclass responsible for representing WebSphere 
 * 6.0-specific server behaviour.
 *
 * This platform has:
 * - No JMX MBean runtime services
 *
 * This platform overrides:
 *
 * getExternalTransactionControllerClass(): to use an WebSphere 6.0-specific 
 * controller class
 */
public class WebSphere_6_0_Platform extends WebSpherePlatform {
    /**
     * INTERNAL:
     * Default Constructor: All behaviour for the default constructor is inherited
     */
    public WebSphere_6_0_Platform(DatabaseSession newDatabaseSession) {
        super(newDatabaseSession);
    }

    /**
     * INTERNAL: getExternalTransactionControllerClass(): Answer the class of 
     * external transaction controller to use for WebSphere_6_0. This is 
     * read-only.
     *
     * @return Class externalTransactionControllerClass
     *
     * @see oracle.toplink.transaction.JTATransactionController
     * @see ServerPlatformBase.isJTAEnabled()
     * @see ServerPlatformBase.disableJTA()
     * @see ServerPlatformBase.initializeExternalTransactionController()
     */
    public Class getExternalTransactionControllerClass() {
    	if (externalTransactionControllerClass == null){
    		externalTransactionControllerClass = WebSphereTransactionController_6_0.class;
    	}
        return externalTransactionControllerClass;
    }
}
