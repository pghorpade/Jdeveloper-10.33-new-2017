// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.server.oc4j;

import java.util.logging.*;
import oracle.dms.instrument.ExecutionContext;
import oracle.toplink.logging.*;

public class OjdlLog extends JavaLog {

    /**
     * INTERNAL:
     * <p>
     * Internally log a message
     * </p><p>
     * @param entry SessionLogEntry that holds all the information for a TopLink logging event
     * @param javaLevel the message level
     * @param logger the Logger for the message
     * </p>
     */
    protected void internalLog(SessionLogEntry entry, Level javaLevel, Logger logger) {
        ExecutionContext.get().setAttribute("TopLinkSessionType", sessionType);
        ExecutionContext.get().setAttribute("TopLinkSessionHashcode", sessionHashCode);
        ExecutionContext.get().setAttribute("TopLinkConnectionHashcode", String.valueOf(System.identityHashCode(entry.getConnection())));

        if (entry.hasException()) {
            logger.log(javaLevel, null, entry.getException());
            return;
        }

        if (entry.shouldTranslate()) {
            String bundleName;
            if (entry.getLevel() > FINE) {
                bundleName = LOGGING_LOCALIZATION_STRING;
            } else {
                bundleName = TRACE_LOCALIZATION_STRING;
            }
            logger.logrb(javaLevel, null, null, bundleName, entry.getMessage(), entry.getParameters());
        } else {
            logger.log(javaLevel, entry.getMessage(), entry.getParameters());
        }
    }
}