// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.platform.server.oc4j;

import com.evermind.server.ejb.AbstractEJBHome;
import com.evermind.server.ejb.EJBContainer;
import com.evermind.server.ejb.MessageDrivenHome;
import com.evermind.server.http.HttpApplication;
import javax.management.ObjectName;
import javax.management.MalformedObjectNameException;
import oracle.toplink.sessions.DatabaseSession;
import oracle.toplink.services.oc4j.Oc4jRuntimeServices;
import oracle.oc4j.admin.jmx.server.Oc4jMBeanServerFactory;
import oracle.oc4j.admin.jmx.server.mbeans.model.ModelMBeanFactory;
import oracle.oc4j.admin.management.mbeans.Constant;
import com.evermind.server.ContextContainer;
import com.evermind.server.OC4JServer;
import com.evermind.server.ThreadState;
import com.evermind.server.ApplicationServer;

import oracle.j2ee.connector.proxy.AbstractProxy;

/**
 * PUBLIC: This is the concrete subclass responsible for representing Oc4j
 * version 10.1.3 specific behaviour.
 */
public class Oc4j_10_1_3_Platform extends Oc4jPlatform {
    public String baseObjectName;

    /**
     * INTERNAL:
     * Default Constructor: All behaviour for the default constructor is inherited
     */
    public Oc4j_10_1_3_Platform(DatabaseSession newDatabaseSession) {
        super(newDatabaseSession);
    }

    /**
       *  INTERNAL:
       *  getObjectName(): Answer the ObjectName identifying the MBean providing runtime
     *  services for the given session
     *
     *  format:
     *  "oc4j:name=mySessionName,j2eeType=TopLinkSession,J2EEServer=" + Constant.OC4JJ2eeServerName +
     *  ",J2EEApplication=myApplicationName,EJBModule=myEjbModuleName.jar"
     *
     *  @return ObjectName objectName: the JSR-77 ObjectName to associate with Oc4jRuntimeServices
       */
    protected ObjectName getObjectName() throws MalformedObjectNameException, javax.naming.NamingException, InstantiationException {
        //BUG 3867367: (NPE during logout (getContextContainer() is null)...cache the objectName)
        return new javax.management.ObjectName("oc4j" + getBaseObjectName());
    }

    /**
     * INTERNAL: getRegistrationName(): Return the name used to register Oc4jRuntimeServices in OC4J.
     *
     * @return String
     */
    public String getBaseObjectName() throws javax.naming.NamingException {
        if (baseObjectName == null) {
            //BUG 4002127: Check for colon in session name, enclose in "'s
            String mySessionName = getDatabaseSession().getName();
            boolean sessionNameHasAColon = mySessionName.indexOf(":") != -1;
            if (sessionNameHasAColon) {
                mySessionName = "\"" + mySessionName + "\"";
            }

            String moduleName = getModuleName();

            //If there is no module name, then we're using POJO. EJBModule is not required. 
            if (moduleName == null) {
                baseObjectName = ":name=" + mySessionName + ",j2eeType=TopLinkSession" + ",J2EEServer=" + Constant.OC4JJ2eeServerName + ",J2EEApplication=" + com.evermind.server.ThreadState.getCurrentState().getContextContainer().getApplication().getName();
            } else {
                baseObjectName = ":name=" + mySessionName + ",j2eeType=TopLinkSession" + ",J2EEServer=" + Constant.OC4JJ2eeServerName + ",J2EEApplication=" + com.evermind.server.ThreadState.getCurrentState().getContextContainer().getApplication().getName() + "," + getModuleType() + "=" + moduleName;
            }
        }
        return baseObjectName;
    }

    /**
     * INTERNAL: getServerLog(): Return the correct ServerLog for this platform
     *
     * Return a OjdlLog
     *
     * @return oracle.toplink.logging.SessionLog
     */
    public oracle.toplink.logging.SessionLog getServerLog() {
        return new OjdlLog();
    }

    /**
     * INTERNAL: serverSpecificRegisterMBean(): Talk to the Oc4jMBeanServerFactory, and
     * register Oc4jRuntimeServices against the ObjectName for it.
     *
     * @return void
     * @see getObjectName()
     * @see registerMBean()
     */
    public void serverSpecificRegisterMBean() {
        try {
            javax.management.ObjectName objectName = getObjectName();
            Oc4jRuntimeServices services = new Oc4jRuntimeServices((oracle.toplink.internal.sessions.DatabaseSessionImpl)getDatabaseSession(), getBaseObjectName());
            Oc4jMBeanServerFactory.registerMBean(ModelMBeanFactory.getModelMBean(services), objectName);
        } catch (Exception generalException) {
            //need better exception handling i.e. a specific exception for this
            generalException.printStackTrace();
        }
    }

    /**
     * INTERNAL: serverSpecificUnregisterMBean(): Talk to the Oc4jMBeanServerFactory, and
     * unregister Oc4jRuntimeServices from the ObjectName.
     *
     * ObjectName format: Unregister the JMX MBean that was providing runtime services for my
     * databaseSession.
     *
     * @return void
     * @see getObjectName()
     * @see registerMBean()
     */
    public void serverSpecificUnregisterMBean() {
        try {
            Oc4jMBeanServerFactory.unregisterMBean(getObjectName());
        } catch (Exception generalException) {
            //need better exception handling i.e. a specific exception for this
            generalException.printStackTrace();
        }
    }

    /**
       *  INTERNAL:
       *  getModuleName(): Answer the name of the module pre-set in ProjectDeployment.deployEJB()
       *  If we are using POJO, then return "unknown".
       */
    public String getModuleName() {
        String cmpModuleName = (String)this.getDatabaseSession().getProperty("oc4j.moduleName");
        if (cmpModuleName != null) {
            return ObjectName.quote(cmpModuleName);
        } else {
            ContextContainer ctxContainer = ThreadState.getCurrentState().contextContainer;
            if (ctxContainer instanceof HttpApplication) {
                return ((HttpApplication)ctxContainer).getName();
            } else if (ctxContainer instanceof AbstractEJBHome) {
                return EJBContainer.getEJBModuleName(((AbstractEJBHome)ctxContainer).getEJBPackage().getModule());
            } else if (ctxContainer instanceof MessageDrivenHome) {
                return EJBContainer.getEJBModuleName(((MessageDrivenHome)ctxContainer).getEJBPackage().getDeployment().getModule());
            }
            return null;
        }
    }

    /**
     *  INTERNAL:
     *  getModuleType(): Answer the type of the module toplink is deployed in.  If moduleName
     *  is preset in the properties, we know it's cmp so, an EJBModule.  Otherwise, look at the
     *  ThreadState's contextContainer to try and figure it out.  Default to EJBModule
     */
    private String getModuleType() {
        if (ThreadState.getCurrentState().contextContainer instanceof HttpApplication) {
            return "WebModule";
        }
        return "EJBModule";
    }

    /**
    * PUBLIC: getServerNameAndVersion(): Talk to the Oc4j class library, and get the server name
    * and version
    *
    * @return String serverNameAndVersion
    */
    public String getServerNameAndVersion() {
        return OC4JServer.INFO;
    }

    /**
     * INTERNAL: launchContainerRunnable(Runnable runnable): Use the container library to
     * start the provided Runnable.
     *
     * @param Runnable runnable: the instance of runnable to be "started"
     * @return void
     */
    public void launchContainerRunnable(Runnable runnable) {
        ApplicationServer.getInstance().getConnectionThreadPool().launch(new Oc4jRunnable(runnable));
    }

    /**
     *  INTERNAL:
     *  Inner help class for launching OC4J specific thread.
     *  This is workaround to handle JNDI lookup issue for lauching TopLink thread.
     *  It will be removed when container provide the api to launch thread associate with ContextContainer.
     */
    public class Oc4jRunnable implements Runnable {
        ContextContainer context;
        Runnable runnableObject;

        public Oc4jRunnable(Runnable aRunnableable) {
            context = ThreadState.getCurrentState().contextContainer;
            runnableObject = aRunnableable;
        }

        /**
         * INTERNAL:
         * set contextContainer to the thread to be launched
         * callback run() method on the thread to be launched
         */
        public void run() {
            ThreadState.getCurrentState().contextContainer = context;
            this.runnableObject.run();
        }
    }
    
    /**
     * INTERNAL:  This method is used to unwrap the oracle connection wrapped by
     * the application server.  TopLink needs this unwrapped connection for certain
     * Oracle Specific support. (ie TIMESTAMPTZ)
     */
    public java.sql.Connection unwrapOracleConnection(java.sql.Connection connection){
    //Bug#5032693  AbstractProxy instead of
        // ((oracle.jdbc.internal.OracleConnection)connection).getPhysicalConnection();
        // to eliminate dependency on Oracle jdbc
        if(connection instanceof AbstractProxy) {
            AbstractProxy proxy = (AbstractProxy)connection;
            return (java.sql.Connection)proxy.oc4j_getTarget();
        } else {
            return connection;
        }
    }
}