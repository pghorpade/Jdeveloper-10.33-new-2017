// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.server.oc4j;

import com.evermind.server.OC4JServer;
import oracle.toplink.sessions.DatabaseSession;

/**
 * PUBLIC: This is the concrete subclass responsible for representing Oc4j
 * version 9.0.3 specific behaviour.
 */
public class Oc4j_9_0_3_Platform extends Oc4jPlatform {

    /**
     * INTERNAL:
     * Default Constructor: All behaviour for the default constructor is inherited
     */
    public Oc4j_9_0_3_Platform(DatabaseSession newDatabaseSession) {
        super(newDatabaseSession);
    }

    /**
    * PUBLIC: getServerNameAndVersion(): Talk to the Oc4j class library, and get the server name
    * and version
    *
    * @return String serverNameAndVersion
    */
    public String getServerNameAndVersion() {
        return OC4JServer.INFO;
    }
}