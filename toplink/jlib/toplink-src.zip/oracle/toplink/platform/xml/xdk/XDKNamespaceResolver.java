// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.xml.xdk;

import oracle.toplink.platform.xml.XMLNamespaceResolver;
import oracle.xml.parser.v2.NSResolver;

public class XDKNamespaceResolver implements NSResolver {
    private XMLNamespaceResolver xmlNamespaceResolver;

    public XDKNamespaceResolver(XMLNamespaceResolver xmlNamespaceResolver) {
        super();
        this.xmlNamespaceResolver = xmlNamespaceResolver;
    }

    public String resolveNamespacePrefix(String namespacePrefix) {
        return xmlNamespaceResolver.resolveNamespacePrefix(namespacePrefix);
    }
}