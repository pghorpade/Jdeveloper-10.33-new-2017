// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.platform.xml;

public interface XMLNamespaceResolver {
    public String resolveNamespacePrefix(String prefix);
}