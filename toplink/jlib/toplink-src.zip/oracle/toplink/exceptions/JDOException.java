// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.exceptions;

import oracle.toplink.exceptions.i18n.ExceptionMessageGenerator;

/**
 * JDO exception class.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).
 */
public class JDOException extends TopLinkException {
    public static final int OBJECT_IS_NOT_TRANSACTIONAL = 16001;
    public static final int ARGUMENT_OBJECT_IS_NOT_JDO_OBJECTID = 16002;
    public static final int OBJECT_FOR_ID_DOES_NOT_EXIST = 16003;
    public static final int TRANSACTIONAL_READ_WITHOUT_ACTIVE_TRANSACTION = 16004;
    public static final int TRANSACTION_IS_ALREADY_ACTIVE = 16005;
    public static final int TRANSACTION_IS_NOT_ACTIVE = 16006;

    public JDOException(String message) {
        super(message);
    }

    protected JDOException(String message, Exception internalException) {
        super(message, internalException);
    }

    public static JDOException objectIsNotTransactional(Object object) {
        Object[] args = { object };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, OBJECT_IS_NOT_TRANSACTIONAL, args));
        jdoException.setErrorCode(OBJECT_IS_NOT_TRANSACTIONAL);
        return jdoException;
    }

    public static JDOException argumentObjectIsNotJDOObjectId(Object object) {
        Object[] args = { object };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, ARGUMENT_OBJECT_IS_NOT_JDO_OBJECTID, args));
        jdoException.setErrorCode(ARGUMENT_OBJECT_IS_NOT_JDO_OBJECTID);
        return jdoException;
    }

    public static JDOException objectForIdDoesNotExist(Object object) {
        Object[] args = { object };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, OBJECT_FOR_ID_DOES_NOT_EXIST, args));
        jdoException.setErrorCode(OBJECT_FOR_ID_DOES_NOT_EXIST);
        return jdoException;
    }

    public static JDOException transactionalReadWithoutActiveTransaction() {
        Object[] args = {  };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, TRANSACTIONAL_READ_WITHOUT_ACTIVE_TRANSACTION, args));
        jdoException.setErrorCode(TRANSACTIONAL_READ_WITHOUT_ACTIVE_TRANSACTION);
        return jdoException;
    }

    public static JDOException transactionIsAlreadyActive() {
        Object[] args = {  };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, TRANSACTION_IS_ALREADY_ACTIVE, args));
        jdoException.setErrorCode(TRANSACTION_IS_ALREADY_ACTIVE);
        return jdoException;
    }

    public static JDOException transactionIsNotActive() {
        Object[] args = {  };

        JDOException jdoException = new JDOException(ExceptionMessageGenerator.buildMessage(JDOException.class, TRANSACTION_IS_NOT_ACTIVE, args));
        jdoException.setErrorCode(TRANSACTION_IS_NOT_ACTIVE);
        return jdoException;
    }
}