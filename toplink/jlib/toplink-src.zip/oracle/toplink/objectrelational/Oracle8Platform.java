// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.objectrelational;


/**
 * <p><b>Purpose:</b>
 * Supports printing of new Oracle 8 data types, Oracle JDBC specific.
 * Use oracle.toplink.oraclespecific.Oracle8Platform instead.
 * @deprecated.  Replaced by
 *         {@link oracle.toplink.platform.database.oracle.Oracle8Platform}
 */
public class Oracle8Platform extends oracle.toplink.oraclespecific.Oracle8Platform {
}