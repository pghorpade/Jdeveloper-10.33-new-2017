// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.objectrelational;

import java.util.*;

import java.sql.*;

import oracle.toplink.internal.helper.*;
import oracle.toplink.internal.expressions.*;
import oracle.toplink.internal.databaseaccess.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.mappings.DatabaseMapping;
import oracle.toplink.queryframework.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.descriptors.RelationalDescriptor;
import oracle.toplink.sessions.DatabaseRecord;

/**
 * <p><b>Purpose:</b>
 * Differenciates object-relational descriptors from normal relational descriptors.
 * The object-relational descriptor describes a type not a table, (although there
 * is normally a table associated with the type, unless it is aggregate).
 */
public class ObjectRelationalDescriptor extends RelationalDescriptor {
    protected String structureName;
    protected Vector orderedFields;

    public ObjectRelationalDescriptor() {
        this.orderedFields = oracle.toplink.internal.helper.NonSynchronizedVector.newInstance();
    }

    /**
     * PUBLIC:
     * Order the fields in a specific
     * Add the field ordering, this will order the fields in the order this method is called.
     * @param fieldName the name of the field to add ordering on.
     */
    public void addFieldOrdering(String fieldName) {
        getOrderedFields().addElement(new DatabaseField(fieldName));
    }

    /**
     * INTERNAL:
     * Extract the direct values from the specified field value.
     * Return them in a vector.
     * The field value better be an Array.
     */
    public Vector buildDirectValuesFromFieldValue(Object fieldValue) throws DatabaseException {
        Object[] fields = null;
        try {
            fields = (Object[])((Array)fieldValue).getArray();
        } catch (java.sql.SQLException ex) {
            throw DatabaseException.sqlException(ex);
        }

        // fix for ora 8.1.4a bug, check for null.
        if (fields == null) {
            return null;
        }

        return Helper.vectorFromArray(fields);
    }

    /**
     * INTERNAL:
     * Build the appropriate field value for the specified
     * set of direct values.
     * The database better be expecting an ARRAY.
     */
    public Object buildFieldValueFromDirectValues(Vector directValues, String elementDataTypeName, Session session) throws DatabaseException {
        Object[] fields = Helper.arrayFromVector(directValues);
        try {
            return session.getPlatform().createArray(elementDataTypeName, fields, session);
        } catch (java.sql.SQLException ex) {
            throw DatabaseException.sqlException(ex);
        }
    }

    /**
     * INTERNAL:
     * Build and return the field value from the specified nested database row.
     * The database better be expecting a Struct.
     */
    public Object buildFieldValueFromNestedRow(DatabaseRow nestedRow, Session session) throws DatabaseException {
        return this.buildStructureFromRow(nestedRow, session);
    }

    /**
     * INTERNAL:
     * Build and return the appropriate field value for the specified
     * set of nested rows.
     * The database better be expecting an ARRAY.
     * It looks like we can ignore inheritance here....
     */
    public Object buildFieldValueFromNestedRows(Vector nestedRows, String structureName, Session session) throws DatabaseException {
        Object[] fields = new Object[nestedRows.size()];
        int i = 0;
        for (Enumeration stream = nestedRows.elements(); stream.hasMoreElements();) {
            DatabaseRow nestedRow = (DatabaseRow)stream.nextElement();
            fields[i++] = this.buildStructureFromRow(nestedRow, session);
        }

        try {
            return session.getPlatform().createArray(structureName, fields, session);
        } catch (java.sql.SQLException exception) {
            throw DatabaseException.sqlException(exception);
        }
    }

    /**
     * INTERNAL:
     * Build and return the nested database row from the specified field value.
     * The field value better be an Struct.
     */
    public DatabaseRow buildNestedRowFromFieldValue(Object fieldValue) throws DatabaseException {
        return this.buildRowFromStructure((Struct)fieldValue);
    }

    /**
     * INTERNAL:
     * Build and return the nested rows from the specified field value.
     * The field value better be an ARRAY.
     */
    public Vector buildNestedRowsFromFieldValue(Object fieldValue, Session session) throws DatabaseException {
        Object[] structs = null;
        try {
            structs = (Object[])((Array)fieldValue).getArray();
        } catch (java.sql.SQLException ex) {
            throw DatabaseException.sqlException(ex);
        }

        // fix for ora 8.1.4a bug, check for null.
        if (structs == null) {
            return null;
        }

        Vector nestedRows = new Vector(structs.length);
        for (int i = 0; i < structs.length; i++) {
            Struct struct = (Struct)structs[i];
            if (struct == null) {
                return null;
            }
            nestedRows.addElement(this.buildRowFromStructure(struct));
        }
        return nestedRows;
    }

    /**
     * INTERNAL:
     * Build a row representation from the ADT strcuture field array.
     * TopLink will then build the object from the row.
     */
    public DatabaseRow buildRowFromStructure(Struct structure) throws DatabaseException {
        DatabaseRow row = new DatabaseRecord();
        Object[] attributes;
        try {
            attributes = structure.getAttributes();
        } catch (java.sql.SQLException exception) {
            throw DatabaseException.sqlException(exception);
        }
        for (int index = 0; index < getOrderedFields().size(); index++) {
            DatabaseField field = (DatabaseField)getOrderedFields().elementAt(index);
            row.put(field, attributes[index]);
        }

        return row;
    }

    /**
     * INTERNAL:
     * Build a ADT structure from the row data.
     */
    public Struct buildStructureFromRow(DatabaseRow row, Session session) throws DatabaseException {
        Object[] fields = new Object[getOrderedFields().size()];
        for (int index = 0; index < getOrderedFields().size(); index++) {
            DatabaseField field = (DatabaseField)getOrderedFields().elementAt(index);
            fields[index] = row.get(field);
        }
        Struct structure;
        try {
            structure = session.getPlatform().createStruct(getStructureName(), fields, session);
        } catch (java.sql.SQLException exception) {
            throw DatabaseException.sqlException(exception);
        }

        return structure;
    }

    /**
     * INTERNAL:
     * Aggregates use a dummy table as default.
     */
    protected DatabaseTable extractDefaultTable() {
        if (isAggregateDescriptor()) {
            return new DatabaseTable();
        }

        return super.extractDefaultTable();
    }

    /**
     * INTERNAL:
     * Return the field order.
     */
    public Vector getOrderedFields() {
        return orderedFields;
    }

    /**
     * INTERNAL:
     * Get the ref for the object.
     * This is required for use by Refs, there might be a better way to do it when objID are supported.
     * (i.e. getting it from the object or identity map).
     */
    public Ref getRef(Object object, Session session) {
        SQLSelectStatement statement = new SQLSelectStatement();
        statement.addTable((DatabaseTable)getTables().firstElement());// Assumed only one for obj-rel descriptors.
        statement.getFields().addElement(new oracle.toplink.expressions.ExpressionBuilder().ref());
        statement.setWhereClause(getObjectBuilder().buildPrimaryKeyExpressionFromObject(object, session));
        statement.setRequiresAliases(true);
        statement.normalize(session, this);

        ValueReadQuery valueQuery = new ValueReadQuery();
        valueQuery.setSQLStatement(statement);

        Ref ref = (Ref)session.executeQuery(valueQuery);

        return ref;
    }

    /**
     * PUBLIC:
     * Return the name of the structure.
     * This is the name of the user defined data type as defined on the database.
     */
    public String getStructureName() {
        return structureName;
    }

    /**
     * INTERNAL:
     * Aggregates obj-rel are initialized normally as no cloning is required.
     */
    public boolean requiresInitialization() {
        return true;
    }

    protected void validateMappingType(DatabaseMapping mapping) {
        //do nothing
    }

    /**
     * INTERNAL:
     * Set the field order.
     */
    public void setOrderedFields(Vector orderedFields) {
        this.orderedFields = orderedFields;
    }

    /**
     * PUBLIC:
     * Set the name of the structure.
     * This is the name of the user defined data type as defined on the database.
     */
    public void setStructureName(String structureName) {
        this.structureName = structureName;
    }
}