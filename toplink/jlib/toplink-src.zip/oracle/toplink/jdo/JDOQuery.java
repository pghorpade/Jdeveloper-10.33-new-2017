// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

import javax.jdo.*;
import oracle.toplink.queryframework.*;
import java.util.*;
import oracle.toplink.internal.databaseaccess.DatabaseCall;
import oracle.toplink.sessions.*;
import oracle.toplink.expressions.*;
import oracle.toplink.exceptions.JDOException;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.exceptions.TopLinkException;

/**
 * PROTOTYPE:
 * JDO wrapper for a TopLink query.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview.
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */
public class JDOQuery implements Query {
    protected JDOPersistenceManager manager;
    protected DatabaseQuery query;

    /**
     * JDOQuery constructor comment.
     */
    public JDOQuery(JDOPersistenceManager manager) {
        this.query = new ReadAllQuery();
        this.manager = manager;
    }

    /**
     * Verify the elements of the query and provide a hint to the query to
     * prepare and optimize an execution plan.
     */
    public void compile() {
    }

    /**
     * Set the import statements to be used to identify the fully qualified name of
     * variables or parameters.  Parameters and unbound variables might
     * come from a different class from the candidate class, and the names
     * need to be declared in an import statement to eliminate ambiguity.
     * Import statements are specified as a String with semicolon-separated
     * statements.
     * <P>The String parameter to this method follows the syntax of the
     * import statement of the Java language.
     * @param imports import statements separated by semicolons.
     */
    public void declareImports(String arg1) {
    }

    /**
     * Declare the list of parameters query execution.
     *
     * The parameter declaration is a String containing one or more query
     * parameter declarations separated with commas. Each parameter named
     * in the parameter declaration must be bound to a value when
     * the query is executed.
     * <P>The String parameter to this method follows the syntax for formal
     * parameters in the Java language.
     * @param parameters the list of parameters separated by commas.
     */
    public void declareParameters(String parameters) {
        String aParameter = new String();
        char aChar;

        for (int i = 0; i < parameters.length(); i++) {
            aChar = parameters.charAt(i);

            if (aChar == ',') {
                getQuery().addArgument(aParameter.trim());
                aParameter = new String();
            } else {
                aParameter += aChar;
            }
        }

        //this adds the last parameter (or single parameter)
        if (aParameter.trim().length() > 0) {
            getQuery().addArgument(aParameter.trim());
        }
    }

    /**
     * Declare the unbound variables to be used in the query. Variables
     * might be used in the filter, and these variables must be declared
     * with their type. The unbound variable declaration is a String
     * containing one or more unbound variable declarations separated
     * with semicolons. It follows the syntax for local variables in
     * the Java language.
     * @param variables the variables separated by semicolons.
     */
    public void declareVariables(String arg1) {
    }

    /**
     * Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     */
    public Object execute() {
        return internalExecute(null);
    }

    /**
     * Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     */
    public Object execute(Object arg1) {
        Vector arguments = new Vector(1);
        arguments.addElement(arg1);
        return this.internalExecute(arguments);
    }

    /**
     * Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     * @param p2 the value of the second parameter declared.
     */
    public Object execute(Object arg1, Object arg2) {
        Vector arguments = new Vector(1);
        arguments.addElement(arg1);
        arguments.addElement(arg2);
        return this.internalExecute(arguments);
    }

    /**
     * Execute the query and return the filtered Collection.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param p1 the value of the first parameter declared.
     * @param p2 the value of the second parameter declared.
     * @param p3 the value of the third parameter declared.
     */
    public Object execute(Object arg1, Object arg2, Object arg3) {
        Vector arguments = new Vector(1);
        arguments.addElement(arg1);
        arguments.addElement(arg2);
        arguments.addElement(arg3);
        return this.internalExecute(arguments);
    }

    /**
     * Execute the query and return the filtered Collection.
     *
     * <P>The execution of the query obtains the values of the parameters and
     * matches them against the declared parameters in order.  The names
     * of the declared parameters are ignored.  The type of
     * the declared parameters must match the type of the passed parameters,
     * except that the passed parameters might need to be unwrapped to get
     * their primitive values.
     *
     * <P>The filter, import, declared parameters, declared variables, and
     * ordering statements are verified for consistency.
     *
     * <P>Each element in the candidate Collection is examined to see that it
     * is assignment compatible to the Class of the query.  It is then evaluated
     * by the boolean expression of the filter.  The element passes the filter
     * if there exist unique values for all variables for which the filter
     * expression evaluates to true.
     * @return the filtered Collection.
     * @param parameters the Object array with all of the parameters.
     */
    public Object executeWithArray(java.lang.Object[] arg1) {
        Vector arguments = new Vector(arg1.length);
        for (int index = 0; index < arg1.length; index++) {
            arguments.addElement(arg1[index]);
        }
        return internalExecute(arguments);
    }

    /**
     * Get the ignoreCache option setting.
     * @return the ignoreCache option setting.
     * @see #setIgnoreCache
     */
    public boolean getIgnoreCache() {
        return getQuery().shouldMaintainCache();
    }

    /**
     * Get the PersistenceManager associated with this Query.
     *
     * <P>If this Query was restored from a serialized form, it has no
     * PersistenceManager, and this method returns null.
     * @return the PersistenceManager associated with this Query.
     */
    public PersistenceManager getPersistenceManager() {
        return manager;
    }

    /**
     * Set the candidate Extent to query.
     * @param pcs the Candidate Extent.
     */
    public void setCandidates(Extent arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setCandidates").getMessage());
    }

    /**
     * Set the class of the candidate instances of the query.
     * <P>The class specifies the class
     * of the candidates of the query.  Elements of the candidate collection
     * that are of the specified class are filtered before being
     * put into the result Collection.
     *
     * @param cls the Class of the candidate instances.
     */
    public void setClass(Class queryClass) {
        ((ObjectLevelReadQuery)getQuery()).setReferenceClass(queryClass);
    }

    /**
     * JDO-QL is not currently supported.
     * This API currently only allows for an SQL filter.
     * TopLink expressions, query by example objects, store-procedure calls can also be used as filters.
     * <p>
     * JDO:
     * Set the filter for the query.
     *
     * <P>The filter specification is a String containing a boolean
     * expression that is to be evaluated for each of the instances
     * in the candidate collection. If the filter is not specified,
     * then it defaults to "true", which has the effect of filtering
     * the input Collection only for class type.
     * <P>An element of the candidate collection is returned in the result if:
     * <ul><li>it is assignment compatible to the candidate Class of the Query; and
     * <li>for all variables there exists a value for which the filter
     * expression evaluates to true.
     * </ul>
     * <P>The user may denote uniqueness in the filter expression by
     * explicitly declaring an expression (for example, e1 != e2).
     * <P>Rules for constructing valid expressions follow the Java
     * language, except for these differences:
     * <ul>
     * <li>Equality and ordering comparisons between primitives and instances
     * of wrapper classes are valid.
     * <li>Equality and ordering comparisons of Date fields and Date
     * parameters are valid.
     * <li>White space (non-printing characters space, tab, carriage
     * return, and line feed) is a separator and is otherwise ignored.
     * <li>The assignment operators =, +=, etc. and pre- and post-increment
     * and -decrement are not supported. Therefore, there are no side
     * effects from evaluation of any expressions.
     * <li>Methods, including object construction, are not supported, except
     * for Collection.contains(Object o), Collection.isEmpty(),
     * String.startsWith (String s), and String.endsWith (String e).
     * Implementations might choose to support non-mutating method
     * calls as non-standard extensions.
     * <li>Navigation through a null-valued field, which would throw
     * NullPointerException, is treated as if the filter expression
     * returned false for the evaluation of the current set of variable
     * values. Other values for variables might still qualify the candidate
     * instance for inclusion in the result set.
     * <li>Navigation through multi-valued fields (Collection types) is
     * specified using a variable declaration and the
     * Collection.contains(Object o) method.
     * </ul>
     * <P>Identifiers in the expression are considered to be in the name
     * space of the specified class, with the addition of declared imports,
     * parameters and variables. As in the Java language, this is a reserved
     * word which means the element of the collection being evaluated.
     * <P>Navigation through single-valued fields is specified by the Java
     * language syntax of field_name.field_name....field_name.
     * <P>A JDO implementation is allowed to reorder the filter expression
     * for optimization purposes.
     * @param filter the query filter.
     */
    public void setFilter(String arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setFilter(String arg1)").getMessage());
    }

    /**
     * Sets maintainCache in the TopLink query, if set this will by-pass the cache.
     * <p>
     * JDO:
     * Set the ignoreCache option.  The default value for this option was
     * set by the PersistenceManagerFactory or the PersistenceManager used
     * to create this Query.
     *
     * The ignoreCache option setting specifies whether the query should execute
     * entirely in the back end, instead of in the cache.  If this flag is set
     * to true, an implementation might be able to optimize the query
     * execution by ignoring changed values in the cache.  For optimistic
     * transactions, this can dramatically improve query response times.
     * @param ignoreCache the setting of the ignoreCache option.
     */
    public void setIgnoreCache(boolean shouldMaintainCache) {
        getQuery().setShouldMaintainCache(shouldMaintainCache);
    }

    /**
     * The JDO order clause is not currently supported.
     * Adds the attribute to be ordered by.
     * JDO:
     * Set the ordering specification for the result Collection.  The
     * ordering specification is a String containing one or more ordering
     * declarations separated by commas.
     *
     * <P>Each ordering declaration is the name of the field on which
     * to order the results followed by one of the following words:
     * "ascending" or "descending".
     *
     *<P>The field must be declared in the candidate class or must be
     * a navigation expression starting with a field in the candidate class.
     *
     *<P>Valid field types are primitive types except boolean; wrapper types
     * except Boolean; BigDecimal; BigInteger; String; and Date.
     * @param ordering the ordering specification.
     */
    public void setOrdering(String attribute) {
        ((ReadAllQuery)getQuery()).addAscendingOrdering(attribute);
    }

    /**
     * PUBLIC:
     * Set the query to lock, this will also turn refreshCache on.
     */
    public void acquireLocks() {
        ((ObjectLevelReadQuery)getQuery()).acquireLocks();
    }

    /**
     * PUBLIC:
     * Set the query to lock without waiting (blocking), this will also turn refreshCache on.
     */
    public void acquireLocksWithoutWaiting() {
        ((ObjectLevelReadQuery)getQuery()).acquireLocksWithoutWaiting();
    }

    /**
     * PUBLIC:
     * Add the argument named argumentName.
     * This will cause the translation of references of argumentName in the receiver's expression,
     * with the value of the argument as supplied to the query in order from executeQuery()
     */
    public void addArgument(String argumentName) {
        getQuery().addArgument(argumentName);
    }

    /**
     * PUBLIC:
     * Order the query results by the object's attribute or query key name.
     */
    public void addAscendingOrdering(String queryKeyName) {
        addOrdering(getExpressionBuilder().get(queryKeyName).ascending());
    }

    /**
     * PUBLIC:
     * Add the attribute from the reference class to be included in the result.
     * EXAMPLE: reportQuery.addAttribute("firstName");
     */
    public void addAttribute(String itemName) {
        addItem(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the attribute to be included in the result.
     * EXAMPLE: reportQuery.addAttribute("city", expBuilder.get("address").get("city"));
     */
    public void addAttribute(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression);
    }

    /**
     * PUBLIC:
     * Add the average value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addAverage("salary");
     */
    public void addAverage(String itemName) {
        addAverage(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the average value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addAverage("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addAverage(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.average());
    }

    /**
     * PUBLIC:
     * Specify the foreign-reference mapped attribute to be optimized in this query.
     * The query will execute normally, however when any of the batched parts is accessed,
     * the parts will all be read in a single query,
     * this allows all of the data required for the parts to be read in a single query instead of (n) queries.
     * This should be used when the application knows that it requires the part for all of the objects being read.
     * This can be used for one-to-one, one-to-many, many-to-many and direct collection mappings.
     *
     * The use of the expression allows for nested batch reading to be expressed.
     * <p>Example: query.addBatchReadAttribute("phoneNumbers")
     *
     * @see #addBatchReadAttribute(Expression)
     * @see ObjectLevelReadQuery#addJoinedAttribute(String)
     */
    public void addBatchReadAttribute(String attributeName) {
        ((ReadAllQuery)getQuery()).addBatchReadAttribute(attributeName);
    }

    /**
     * PUBLIC:
     * Specify the foreign-reference mapped attribute to be optimized in this query.
     * The query will execute normally, however when any of the batched parts is accessed,
     * the parts will all be read in a single query,
     * this allows all of the data required for the parts to be read in a single query instead of (n) queries.
     * This should be used when the application knows that it requires the part for all of the objects being read.
     * This can be used for one-to-one, one-to-many, many-to-many and direct collection mappings.
     *
     * The use of the expression allows for nested batch reading to be expressed.
     * <p>Example: query.addBatchReadAttribute(query.getExpressionBuilder().get("policies").get("claims"))
     *
     * @see ObjectLevelReadQuery#addJoinedAttribute(String)
     */
    public void addBatchReadAttribute(Expression attributeExpression) {
        ((ReadAllQuery)getQuery()).addBatchReadAttribute(attributeExpression);
    }

    /**
     * PUBLIC:
     * Add the count of the size of the result to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addCount();
     */
    public void addCount() {
        addCount("COUNT", getExpressionBuilder());
    }

    /**
     * PUBLIC:
     * Add the count of the size of the result to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addCount("id");
     */
    public void addCount(String itemName) {
        addCount(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the count of the size of the result to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addCount("id", expBuilder.get("id"));
     */
    public void addCount(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.count());
    }

    /**
    * PUBLIC:
     * Order the query results by the object's attribute or query key name.
     */
    public void addDescendingOrdering(String queryKeyName) {
        addOrdering(getExpressionBuilder().get(queryKeyName).descending());
    }

    /**
     * PUBLIC:
     * Add the attribute to the group by expressions.
     * This will group the result set on that attribute and is normally used in conjunction with aggregation functions.
     * Example: reportQuery.addGrouping("lastName")
     */
    public void addGrouping(String attributeName) {
        addGrouping(getExpressionBuilder().get(attributeName));
    }

    /**
     * PUBLIC:
     * Add the attribute expression to the group by expressions.
     * This will group the result set on that attribute and is normally used in conjunction with aggregation functions.
     * Example: reportQuery.addGrouping(expBuilder.get("address").get("country"))
     */
    public void addGrouping(Expression expression) {
        ((ReportQuery)getQuery()).addGrouping(expression);
    }

    /**
     * ADVANCED:
     * Add the expression value to be included in the result.
     * EXAMPLE: reportQuery.addItem("name", expBuilder.get("firstName").toUpperCase());
     */
    public void addItem(String itemName, Expression attributeExpression) {
        ((ReportQuery)getQuery()).addItem(itemName, attributeExpression);
    }

    /**
     * PUBLIC:
     * Specify the one-to-one mapped attribute to be optimized in this query.
     * The query will join the object(s) being read with the one-to-one attribute,
     * this allows all of the data required for the object(s) to be read in a single query instead of (n) queries.
     * This should be used when the application knows that it requires the part for all of the objects being read.
     * This can be used only for one-to-one mappings where the target is not the same class as the source,
     * either directly or through inheritance.  Also two joins cannot be done to the same class.
     *
     * <p>Note: This cannot be used for objects where it is possible not to have a part,
     * as these objects will be ommited from the result set,
     * unless an outer join is used through passing and expression using "getAllowingNull".
     *
     * <p>Example: query.addJoinedAttribute("address")
     *
     * @see #addJoinedAttribute(Expression)
     * @see ReadAllQuery#addBatchReadAttribute(Expression)
     */
    public void addJoinedAttribute(String attributeName) {
        addJoinedAttribute(getExpressionBuilder().get(attributeName));
    }

    /**
     * PUBLIC:
     * Specify the one-to-one mapped attribute to be optimized in this query.
     * The query will join the object(s) being read with the one-to-one attribute,
     * this allows all of the data required for the object(s) to be read in a single query instead of (n) queries.
     * This should be used when the application knows that it requires the part for all of the objects being read.
     * This can be used only for one-to-one mappings where the target is not the same class as the source,
     * either directly or through inheritance.  Also two joins cannot be done to the same class.
     *
     * <p>Note: This cannot be used for objects where it is possible not to have a part,
     * as these objects will be ommited from the result set,
     * unless an outer join is used through passing and expression using "getAllowingNull".
     *
     * <p>Example: query.addJoinedAttribute(query.getExpressionBuilder().get("teamLeader").get("address"))
     *
     * @see ReadAllQuery#addBatchReadAttribute(String)
     */
    public void addJoinedAttribute(Expression attributeExpression) {
        ((ObjectLevelReadQuery)getQuery()).addJoinedAttribute(attributeExpression);
    }

    /**
     * PUBLIC:
     * Add the maximum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addMaximum("salary");
     */
    public void addMaximum(String itemName) {
        addMaximum(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the maximum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addMaximum("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addMaximum(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.maximum());
    }

    /**
     * PUBLIC:
     * Add the minimum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addMinimum("salary");
     */
    public void addMinimum(String itemName) {
        addMinimum(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the minimum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addMinimum("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addMinimum(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.minimum());
    }

    /**
     * PUBLIC:
     * Add the ordering expression.  This allows for ordering across relationships or functions.
     * Example: readAllQuery.addOrdering(expBuilder.get("address").get("city").toUpperCase().descending())
     */
    public void addOrdering(Expression orderingExpression) {
        ((ReadAllQuery)getQuery()).addOrdering(orderingExpression);
    }

    /**
     * PUBLIC:
     * Specify that only a subset of the class' attributes be selected in this query.
     * This allows for the query to be optimized through selecting less data.
     * Partial objects will be returned from the query, where the unspecified attributes will be left null.
     * The primary key will always be selected to allow re-querying of the whole object.
     * Note: Because the object is not fully it cannot be cached, and cannot be editted.
     *
     * Example: query.addPartialAttribute("firstName")
     */
    public void addPartialAttribute(String attributeName) {
        addPartialAttribute(getExpressionBuilder().get(attributeName));
    }

    /**
     * PUBLIC:
     * Specify that only a subset of the class' attributes be selected in this query.
     * This allows for the query to be optimized through selecting less data.
     * Partial objects will be returned from the query, where the unspecified attributes will be left null.
     * The primary key will always be selected to allow re-querying of the whole object.
     * Note: Because the object is not fully it cannot be cached, and cannot be editted.
     *
     * Example: query.addPartialAttribute(query.getExpressionBuilder().get("address").get("city"))
     */
    public void addPartialAttribute(Expression attributeExpression) {
        ((ObjectLevelReadQuery)getQuery()).addPartialAttribute(attributeExpression);
    }

    /**
     * PUBLIC:
     * Add the standard deviation value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addStandardDeviation("salary");
     */
    public void addStandardDeviation(String itemName) {
        addStandardDeviation(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the standard deviation value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addStandardDeviation("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addStandardDeviation(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.standardDeviation());
    }

    /**
     * PUBLIC:
     * Add the sum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addSum("salary");
     */
    public void addSum(String itemName) {
        addSum(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the sum value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addSum("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addSum(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.sum());
    }

    /**
     * PUBLIC:
     * Add the variance value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addVariance("salary");
     */
    public void addVariance(String itemName) {
        addVariance(itemName, getExpressionBuilder().get(itemName));
    }

    /**
     * PUBLIC:
     * Add the variance value of the attribute to be included in the result.
     * Aggregation functions can be used with a group by, or on the entire result set.
     * EXAMPLE: reportQuery.addVariance("managerSalary", expBuilder.get("manager").get("salary"));
     */
    public void addVariance(String itemName, Expression attributeExpression) {
        addItem(itemName, attributeExpression.variance());
    }

    /**
     * PUBLIC:
     * Reset the TOPLink query to be a new ReadAllQuery.
     */
    public void asReadAllQuery() {
        setQuery(new ReadAllQuery(getQuery().getReferenceClass(), new ExpressionBuilder()));
    }

    /**
     * PUBLIC:
     * Reset the TOPLink query to be a new ReadObjectQuery.
     */
    public void asReadObjectQuery() {
        setQuery(new ReadObjectQuery(getQuery().getReferenceClass(), new ExpressionBuilder()));
    }

    /**
     * PUBLIC:
     * Reset the TOPLink query to be a new ReportQuery.
     */
    public void asReportQuery() {
        setQuery(new ReportQuery(getQuery().getReferenceClass(), new ExpressionBuilder()));
    }

    /**
     * Bind all arguments to any SQL statement.
     */
    public void bindAllParameters() {
        setShouldBindAllParameters(true);
    }

    /**
     * Cache the prepared statements, this requires full parameter binding as well.
     */
    public void cacheStatement() {
        setShouldCacheStatement(true);
    }

    /**
     * PUBLIC:
     * Cascade the query and its properties on the queries object(s) and all objects related to the queries object(s).
     * This includes private and independent relationships, but not read-only relationships.
     * This will still stop on uninstantiated indirection objects except for deletion.
     * Great caution should be used in using the property as the query may effect a large number of objects.
     * This policy is used by the unit of work to ensure persistence by reachability.
     */
    public void cascadeAllParts() {
        getQuery().cascadeAllParts();
    }

    /**
     * PUBLIC:
     * Cascade the query and its properties on the queries object(s)
     * and all privately owned objects related to the queries object(s).
     * This is the default for write and delete queries.
     * This policy should normally be used for refreshing, otherwise you could refresh half of any object.
     */
    public void cascadePrivateParts() {
        getQuery().cascadePrivateParts();
    }

    /**
     * PUBLIC:
     * The cache will be checked only if the query contains exactly the primary key.
     * Queries can be configured to use the cache at several levels.
     * Other caching option are available.
     * @see #setCacheUsage(int)
     */
    public void checkCacheByExactPrimaryKey() {
        ((ReadObjectQuery)getQuery()).checkCacheByExactPrimaryKey();
    }

    /**
     * PUBLIC:
     * This is the default, the cache will be checked only if the query contains the primary key.
     * Queries can be configured to use the cache at several levels.
     * Other caching option are available.
     * @see #setCacheUsage(int)
     */
    public void checkCacheByPrimaryKey() {
        ((ReadObjectQuery)getQuery()).checkCacheByPrimaryKey();
    }

    /**
     * PUBLIC:
     * The cache will checked completely, if the object is not found null will be returned or an error if the query is too complex.
     * Queries can be configured to use the cache at several levels.
     * Other caching option are available.
     * @see #setCacheUsage(int)
     */
    public void checkCacheOnly() {
        ((ObjectLevelReadQuery)getQuery()).checkCacheOnly();
    }

    /**
     * PUBLIC:
     * The cache will be checked completely, then if the object is not found or the query too complex the database will be queried.
     * Queries can be configured to use the cache at several levels.
     * Other caching option are available.
     * @see #setCacheUsage(int)
     */
    public void checkCacheThenDatabase() {
        ((ReadObjectQuery)getQuery()).checkCacheThenDatabase();
    }

    /**
     * Close a query result and release any resources associated with it.  The
     * parameter is the return from execute(...) and might have iterators open on it.
     * Iterators associated with the query result are invalidated: they return false
     * to hasNext() and throw NoSuchElementException to next().
     * @param queryResult the result of execute(...) on this Query instance.
     */
    public void close(Object queryResult) {
        if (queryResult instanceof Cursor) {
            ((Cursor)queryResult).close();
        }
    }

    /**
     * Close all query results associated with this Query instance, and release all
     * resources associated with them.  The query results might have iterators open
     * on them.  Iterators associated with the query results are invalidated:
     * they return false to hasNext() and throw NoSuchElementException to next().
     */
    public void closeAll() {
    }

    /**
    * PUBLIC:
    * The cache will checked completely, if the object is not found the database will be queried,
    * and the database result will be verified with what is in the cache and/or unit of work including new objects.
    * This can lead to poor performance so it is recomended that only the database be queried in most cases.
    * Queries can be configured to use the cache at several levels.
    * Other caching option are available.
    * @see #setCacheUsage(int)
    */
    public void conformResultsInUnitOfWork() {
        ((ObjectLevelReadQuery)getQuery()).conformResultsInUnitOfWork();
    }

    /**
     * PUBLIC:
     * Set the query not to lock.
     */
    public void dontAcquireLocks() {
        ((ObjectLevelReadQuery)getQuery()).dontAcquireLocks();
    }

    /**
     * Do not Bind all arguments to any SQL statement.
     */
    public void dontBindAllParameters() {
        setShouldBindAllParameters(false);
    }

    /**
     * Dont cache the prepared statements, this requires full parameter binding as well.
     */
    public void dontCacheStatement() {
        setShouldCacheStatement(false);
    }

    /**
     * PUBLIC:
     * Do not cascade the query and its properties on the queries object(s) relationships.
     * This does not effect the queries private parts but only the object(s) direct row-level attributes.
     * This is the default for read queries and can be used in writting if it is known that only
     * row-level attributes changed, or to resolve circular foreign key dependencies.
     */
    public void dontCascadeParts() {
        getQuery().dontCascadeParts();
    }

    /**
     * PUBLIC:
     * This can be used to explicitly disable the cache hit.
     * The cache hit may not be desired in some cases, such as
     * stored procedures that accept the primary key but do not query on it.
     */
    public void dontCheckCache() {
        ((ObjectLevelReadQuery)getQuery()).dontCheckCache();
    }

    /**
     * PUBLIC:
     * Set for the identity map (cache) to be ignored completely.
     * The cache check will be skipped and the result will not be put into the identity map.
     * This can be used to retreive the exact state of an object on the database.
     * By default the identity map is always maintained.
     */
    public void dontMaintainCache() {
        setShouldMaintainCache(false);
    }

    /**
     * PUBLIC:
     * When unset means perform read normally and dont do refresh.
     */
    public void dontRefreshIdentityMapResult() {
        setShouldRefreshIdentityMapResult(false);
    }

    /**
     * PUBLIC:
     * When unset means perform read normally and dont do refresh.
     */
    public void dontRefreshRemoteIdentityMapResult() {
        ((ObjectLevelReadQuery)getQuery()).dontRefreshRemoteIdentityMapResult();
    }

    /**
     * ADVANCED:
     * If a distinct has been set the DISTINCT clause will be printed.
     * This is used internally by TopLink for batch reading but may also be
     * used directly for advanced queries or report queries.
     */
    public void dontUseDistinct() {
        ((ObjectLevelReadQuery)getQuery()).dontUseDistinct();
    }

    /**
     * Execute the query and return the filtered Collection.  The query
     * is executed with the parameters set by the Map values.  Each Map entry
     * consists of a key which is the name of the parameter in the
     * declareParameters method, and a value which is the value used in
     * the execute method.  The keys in the Map and the declared parameters
     * must exactly match or a JDOUserException is thrown.
     * @return the filtered Collection.
     * @see #executeWithArray(Object[] parameters)
     * @param parameters the Map containing all of the parameters.
     */
    public Object executeWithMap(Map arg1) {
        Vector arguments = new Vector(getQuery().getArguments().size());

        Object anArgument;
        for (int index = 0; index < getQuery().getArguments().size(); index++) {
            anArgument = arg1.get(getQuery().getArguments().elementAt(index));
            arguments.addElement(anArgument);
        }

        return internalExecute(arguments);
    }

    /**
     * ADVANCED:
     * Return the call for this query.
     * This call contains the SQL and argument list.
     * @see prepareCall(Session, DatabaseRow);
     */
    public DatabaseCall getCall() {
        return getQuery().getCall();
    }

    /**
     * PUBLIC:
     * This method returns the current example object.  The "example" object is an actual domain object, provided
     * by the client, from which an expression is generated.
     * This expression is used for a query of all objects from the same class, that match the attribute values of
     * the "example" object.
     */
    public Object getExampleObject() {
        return ((ObjectLevelReadQuery)getQuery()).getExampleObject();
    }

    /**
     * Return the query's expression builder.
     */
    public ExpressionBuilder getExpressionBuilder() {
        return ((ObjectLevelReadQuery)getQuery()).getExpressionBuilder();
    }

    /**
     * Return the associated TopLink query.
     * This is normally a ReadAllQuery.
     */
    public DatabaseQuery getQuery() {
        return query;
    }

    /**
     * PUBLIC:
     * Return the number of seconds the driver will wait for a Statement to execute to the given number of seconds.
     */
    public int getQueryTimeout() {
        return getQuery().getQueryTimeout();
    }

    /**
     * Return the associated TopLink ReadAllQuery.
     */
    public ReadAllQuery getReadAllQuery() {
        return (ReadAllQuery)getQuery();
    }

    /**
     * Return the associated TopLink ReadObjectQuery.
     */
    public ReadObjectQuery getReadObjectQuery() {
        return (ReadObjectQuery)getQuery();
    }

    /**
     * PUBLIC:
     * Return the domain class associated with this query.
     * By default this is null, but should be overridden in subclasses.
     */
    public Class getReferenceClass() {
        return null;
    }

    /**
     * Return the associated TopLink ReportQuery.
     */
    public ReportQuery getReportQuery() {
        return (ReportQuery)getQuery();
    }

    /**
     * PUBLIC:
     * Return the selection criteria of the query.
     * This should only be used with expression queries, null will be returned for others.
     */
    public Expression getSelectionCriteria() {
        return getQuery().getSelectionCriteria();
    }

    /* INTERNAL:
     *
     */
    protected Object internalExecute(Vector arguments) {
        Session session;

        if (manager.currentTransaction().getNontransactionalRead()) {
            session = manager.getSession();
        } else {
            if (!manager.currentTransaction().isActive()) {
                throw new JDODataStoreException(JDOException.transactionalReadWithoutActiveTransaction().getMessage());
            }
            session = ((JDOTransaction)manager.currentTransaction()).getUnitOfWork();
        }
        try {
            if (arguments == null) {
                return session.executeQuery(getQuery());
            } else {
                return session.executeQuery(getQuery(), arguments);
            }
        } catch (TopLinkException e) {
            throw new JDOUserException(e.getMessage());
        }
    }

    /**
     * PUBLIC:
     * Set for the identity map (cache) to be maintained.
     * This is the default.
     */
    public void maintainCache() {
        setShouldMaintainCache(true);
    }

    /**
     * PUBLIC:
     * Refresh the attributes of the object(s) resulting from the query.
     * If cascading is used the private parts of the objects will also be refreshed.
     */
    public void refreshIdentityMapResult() {
        setShouldRefreshIdentityMapResult(true);
    }

    /**
     * PUBLIC:
     * Used to define a store procedure or SQL query.
     */
    public void setCall(Call call) {
        getQuery().setCall(call);
    }

    /**
     * Set the candidate Collection to query.
     * @param pcs the Candidate collection.
     */
    public void setCandidates(Collection arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setCandidates").getMessage());
    }

    /**
     * Set the filter to an EJBQL string.
     * Refer to document for EJBQL support
     */
    public void setEJBQLString(String ejbqlString) {
        getQuery().setEJBQLString(ejbqlString);
    }

    /**
     * Set the filter to a TopLink expression.
     */
    public void setFilter(Expression selectionCriteria) {
        getQuery().setSelectionCriteria(selectionCriteria);
    }

    /**
     * Set the associated TopLink query.
     */
    public void setQuery(DatabaseQuery newQuery) {
        query = newQuery;
    }

    /**
     * Set the filter based on the query by example object.
     */
    public void setQueryByExampleFilter(Object exampleObject) {
        ((ObjectLevelReadQuery)getQuery()).setExampleObject(exampleObject);
    }

    /**
     * PUBLIC:
     * Policy, an instance of oracle.toplink.queryframework.QueryByExamplePolicy, is a useful tool to
     * customising the query when Query By Example is used.
     * The pollicy will control what attributes should, or should not be included in the query.
     * When dealing with nulls, using specail operations (notEqual, lessThan, like, etc.)
     * for comparison, or chosing to include certain attributes at all times, it is useful to modify
     * the policy accordingly.
     */
    public void setQueryByExamplePolicy(QueryByExamplePolicy newPolicy) {
        ((ObjectLevelReadQuery)getQuery()).setQueryByExamplePolicy(newPolicy);
    }

    /**
     * PUBLIC:
     * Set the number of seconds the driver will wait for a Statement to execute to the given number of seconds.
     * If the limit is exceeded, a DatabaseException is thrown.
     * queryTimeout - the new query timeout limit in seconds; zero means unlimited (by default)
     */
    public void setQueryTimeout(int queryTimeout) {
        getQuery().setQueryTimeout(queryTimeout);
    }

    /**
     * Bind all arguments to any SQL statement.
     */
    public void setShouldBindAllParameters(boolean shouldBindAllParameters) {
        getQuery().setShouldBindAllParameters(shouldBindAllParameters);
    }

    /**
     * Cache the prepared statements, this requires full parameter binding as well.
     */
    public void setShouldCacheStatement(boolean shouldCacheStatement) {
        getQuery().setShouldCacheStatement(shouldCacheStatement);
    }

    /**
     * PUBLIC:
     * Set if the identity map (cache) should be used or not.
     * If not the cache check will be skipped and the result will not be put into the identity map.
     * By default the identity map is always maintained.
     */
    public void setShouldMaintainCache(boolean shouldMaintainCache) {
        getQuery().setShouldMaintainCache(shouldMaintainCache);
    }

    /**
     * PUBLIC:
     * Set if the attributes of the object(s) resulting from the query should be refreshed.
     * If cascading is used the private parts of the objects will also be refreshed.
     */
    public void setShouldRefreshIdentityMapResult(boolean shouldRefreshIdentityMapResult) {
        ((ObjectLevelReadQuery)getQuery()).setShouldRefreshIdentityMapResult(shouldRefreshIdentityMapResult);
    }

    /**
     * PUBLIC:
     * To any user of this object. Set the SQL string of the query.
     * This method should only be used when dealing with user defined SQL strings.
     * If arguments are required in the string they will be preceeded by "#" then the argument name.
     */
    public void setSQLString(String sqlString) {
        setCall(new SQLCall(sqlString));
    }

    /**
     * Bind all arguments to any SQL statement.
     */
    public boolean shouldBindAllParameters() {
        return getQuery().shouldBindAllParameters();
    }

    /**
     * Cache the prepared statements, this requires full parameter binding as well.
     */
    public boolean shouldCacheStatement() {
        return getQuery().shouldCacheStatement();
    }

    /**
     * PUBLIC:
     * Flag used to determine if all parts should be cascaded
     */
    public boolean shouldCascadeAllParts() {
        return getQuery().shouldCascadeAllParts();
    }

    /**
     * PUBLIC:
     * Flag used to determine if any parts should be cascaded
     */
    public boolean shouldCascadeParts() {
        return getQuery().shouldCascadeParts();
    }

    /**
     * PUBLIC:
     * Flag used to determine if any private parts should be cascaded
     */
    public boolean shouldCascadePrivateParts() {
        return getQuery().shouldCascadePrivateParts();
    }

    /**
     * PUBLIC:
     * Return if the identity map (cache) should be used or not.
     * If not the cache check will be skipped and the result will not be put into the identity map.
     * By default the identity map is always maintained.
     */
    public boolean shouldMaintainCache() {
        return getQuery().shouldMaintainCache();
    }

    /**
     * PUBLIC:
     * Set to a boolean. When set means refresh the instance
     * variables of referenceObject from the database.
     */
    public boolean shouldRefreshIdentityMapResult() {
        return ((ObjectLevelReadQuery)getQuery()).shouldRefreshIdentityMapResult();
    }

    /**
     * PUBLIC:
     * Configure the mapping to use an instance of the specified container class
     * to hold the target objects.
     * <p>jdk1.2.x: The container class must implement (directly or indirectly) the Collection interface.
     * <p>jdk1.1.x: The container class must be a subclass of Vector.
     */
    public void useCollectionClass(Class concreteClass) {
        ((ReadAllQuery)getQuery()).useCollectionClass(concreteClass);
    }

    /**
     * PUBLIC:
     * Use a CursoredStream as the result collection.
     * The initial read size is 10 and page size is 5.
     */
    public void useCursoredStream() {
        useCursoredStream(10, 5);
    }

    /**
     * PUBLIC:
     * Use a CursoredStream as the result collection.
     * @param initialReadSize the initial number of objects to read
     * @param pageSize the number of objects to read when more objects
     * are needed from the database
     */
    public void useCursoredStream(int initialReadSize, int pageSize) {
        ((ReadAllQuery)getQuery()).useCursoredStream(initialReadSize, pageSize);
    }

    /**
     * PUBLIC:
     * Use a CursoredStream as the result collection.
     * @param initialReadSize the initial number of objects to read
     * @param pageSize the number of objects to read when more objects
     * are needed from the database
     * @param sizeQuery a query that will return the size of the result set;
     * this must be set if an expression is not used (i.e. custom SQL)
     */
    public void useCursoredStream(int initialReadSize, int pageSize, ValueReadQuery sizeQuery) {
        ((ReadAllQuery)getQuery()).useCursoredStream(initialReadSize, pageSize, sizeQuery);
    }

    /**
     * ADVANCED:
     * If a distinct has been set the DISTINCT clause will be printed.
     * This is used internally by TopLink for batch reading but may also be
     * used directly for advanced queries or report queries.
     */
    public void useDistinct() {
        ((ObjectLevelReadQuery)getQuery()).useDistinct();
    }

    /**
     * PUBLIC:
     * Configure the query to use an instance of the specified container class
     * to hold the result objects. The key used to index the value in the Map
     * is the value returned by a call to the specified zero-argument method.
     * The method must be implemented by the class (or a superclass) of the
     * value to be inserted into the Map.
     * <p>jdk1.2.x: The container class must implement (directly or indirectly) the Map interface.
     * <p>jdk1.1.x: The container class must be a subclass of Hashtable.
     * <p>The referenceClass must set before calling this method.
     */
    public void useMapClass(Class concreteClass, String methodName) {
        ((ReadAllQuery)getQuery()).useMapClass(concreteClass, methodName);
    }

    /**
     * PUBLIC:
     * Use a ScrollableCursor as the result collection.
     */
    public void useScrollableCursor() {
        useScrollableCursor(10);
    }

    /**
     * PUBLIC:
     * Use a ScrollableCursor as the result collection.
     * @param pageSize the number of elements to be read into a the cursor
     * when more elements are needed from the database.
     */
    public void useScrollableCursor(int pageSize) {
        ((ReadAllQuery)getQuery()).useScrollableCursor(pageSize);
    }
}