// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

import java.util.*;
import javax.jdo.*;

import oracle.toplink.queryframework.*;
import oracle.toplink.sessions.*;
import oracle.toplink.expressions.*;
import oracle.toplink.exceptions.JDOException;
import oracle.toplink.exceptions.ValidationException;

/**
 * PUBLIC:<p>
 * TopLink persistence manager for the JDO specification.
 * This supports JDO through the TopLink API,
 * Supported are the basic JDO interfaces but does not require implementation of PersistenceCapable,
 * byte-code enhancers or any other of that internal JDO reference implementation related aspects.
 * JDO wrapper for a TopLink session.
 * JDO:<p>
 * PersistenceManager is the primary interface for JDO-aware application
 * components.  It is the factory for Query and Transaction instances,
 * and contains methods to manage the life cycle of PersistenceCapable
 * instances.
 *
 * <P>A PersistenceManager is obtained from the
 * {@link PersistenceManagerFactory}
 * (recommended) or by construction.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview. 
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */
 
public class JDOPersistenceManager implements PersistenceManager {
	
	protected Session session;
	//protected boolean ignoreCache;
	//protected Object userObject;
    protected JDOTransaction currentTransaction;	
    protected JDOPersistenceManagerFactory factory;	
    //protected boolean multithreaded;	
    protected boolean nontransactionalRead;	
    
/**
 * Create a new persistence manager from the session and factory.
 */
public JDOPersistenceManager(JDOPersistenceManagerFactory factory, Session session) {
	this.factory = factory;
	this.session = session;
	//this.multithreaded = factory.getMultithreaded();
	//this.ignoreCache = factory.getIgnoreCache();
	this.nontransactionalRead = factory.getNontransactionalRead();
	
	this.currentTransaction = new JDOTransaction(this);	
}    
	
/**
 * Close the persistence manager's session.  For database session this will logout from the database.
 * For a client session this will just release the client session's resources.<p>
 * JDO:<p>
 * Close this PersistenceManager so that no further requests may be 
 * made on it.  A PersistenceManager instance can be used 
 * only until it is closed.
 *
 * <P>Closing a PersistenceManager might release it to the pool of available
 * PersistenceManagers, or might be garbage collected, at the option of
 * the JDO implementation.  Before being used again to satisfy a
 * getPersistenceManager request, the default values for options will
 * be restored to their values as specified in the PersistenceManagerFactory.
 *
 * <P>This method closes the PersistenceManager.
 */
public void close() {
	if (getUnitOfWork() != null) {
		getUnitOfWork().release();
	}
	getSession().release();
}

/**
 * Return the Transaction instance associated with a PersistenceManager.
 * There is one Transaction instance associated with each PersistenceManager
 * instance.  The Transaction instance supports options as well as
 * transaction completion requests.
 * @return the Transaction associated with this
 * PersistenceManager.
 */

public Transaction currentTransaction() {
	return currentTransaction;
}

/**
 * Delete the persistent instance from the data store.
 * This method must be called in an active transaction.
 * The data store object will be removed at commit.
 * Unlike makePersistent, which makes the closure of the instance persistent,
 * the closure of the instance is not deleted from the data store.
 * This method has no effect if the instance is already deleted in the
 * current transaction.
 * This method throws JDOUserException if the instance is transient or 
 * is managed by another PersistenceManager.
 *
 * @param pc a persistent instance
 */
public void deletePersistent(Object object) {
    
    if( getUnitOfWork() != null
        && !((oracle.toplink.publicinterface.UnitOfWork) getUnitOfWork()).isObjectRegistered(object)){
        throw new JDOUserException(JDOException.objectIsNotTransactional(object).getMessage());
    }
    
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	getUnitOfWork().deleteObject(object);
	if (autoCommit) {
		currentTransaction().commit();
	}
}



/**
 * Remove the instance from the TopLink cache.  This should only be called if the application is sure that it no longer references the object.
 * When used with a DatabaseSession this will remove the object from the cache,
 * when used with a ClientSession it will have no effect as the ClientSession shares the ServerSession's cache.
 * JDO:<p>
 * Mark an instance as no longer needed in the cache.
 * Eviction is normally done automatically by the PersistenceManager
 * at transaction completion.  This method allows the application to
 * explicitly provide a hint to the PersistenceManager that the instance
 * is no longer needed in the cache.
 * @param pc the instance to evict from the cache.
 */
public void evict(Object object) {
	getSession().removeFromIdentityMap(object);
}

/**
 * The PersistenceManager manages a collection of instances in the data
 * store based on the class of the instances.  This method returns a
 * Extent of instances in the data store that might be iterated or
 * given to a Query.  The Extent itself might not reference any 
 * instances, but only hold the class name and an
 * indicator whether subclasses are included in the Extent.
 * <P>Note that the Extent might be very large.
 * @param persistenceCapableClass Class of instances
 * @param subclasses whether to include instances of subclasses
 * @return an Extent of the specified Class
 * @see Query
 */
public Extent getExtent(Class queryClass, boolean readSubclasses) {
	return new JDOExtent(this, queryClass, readSubclasses);
}
/**
 * Get the ignoreCache setting for queries.
 *
 * <P>IgnoreCache set to true specifies that for all Query instances created by this
 * PersistenceManager, the default is the cache should be ignored for queries.
 * @return the ignoreCache setting.
 */

public boolean getIgnoreCache() {
	return false;
}

/**
 * This method locates a persistent instance in the cache of instances
 * managed by this PersistenceManager.  The getObjectById method attempts 
 * to find an instance in the cache with the specified JDO identity. 
 * The oid parameter object might have been returned by an earlier call 
 * to getObjectId or getTransactionalObjectId, or might have been 
 * constructed by the application. 
 * <P>If the PersistenceManager is unable to resolve the oid parameter 
 * to an ObjectId instance, then it throws a JDOUserException.
 * <P>If the validate flag is false, and there is already an instance in the
 * cache with the same jdo identity as the oid parameter, then this method
 * returns it. There is no change made to the state of the returned
 * instance.
 * <P>If there is not an instance already in the cache with the same JDO
 * identity as the oid parameter, then this method creates an instance
 * with the specified JDO identity and returns it. If there is no
 * transaction in progress, the returned instance will be hollow or
 * persistent-nontransactional, at the choice of the implementation.
 * <P>If there is a transaction in progress, the returned instance will
 * be hollow, persistent-nontransactional, or persistent-clean, at the
 * choice of the implementation.
 * <P>It is an implementation decision whether to access the data store,
 * if required to determine the exact class. This will be the case of
 * inheritance, where multiple PersistenceCapable classes share the
 * same Object Id class.
 * <P>If the validate flag is false, and the instance does not exist in
 * the data store, then this method might not fail. It is an
 * implementation choice whether to fail immediately with a
 * JDODatastoreException.But a subsequent access of the fields of the
 * instance will throw a JDODatastoreException if the instance does not
 * exist at that time. Further, if a relationship is established to this
 * instance, then the transaction in which the association was made will
 * fail.
 * <P>If the validate flag is true, and there is already a transactional
 * instance in the cache with the same jdo identity as the oid parameter,
 * then this method returns it. There is no change made to the state of
 * the returned instance.
 * <P>If there is an instance already in the cache with the same jdo
 * identity as the oid parameter, but the instance is not transactional,
 * then it must be verified in the data store. If the instance does not
 * exist in the datastore, then a JDODatastoreException is thrown.
 * <P>If there is not an instance already in the cache with the same JDO
 * identity as the oid parameter, then this method creates an instance
 * with the specified jdo identity, verifies that it exists in the data
 * store, and returns it. If there is no transaction in progress, the
 * returned instance will be hollow or persistent-nontransactional,
 * at the choice of the implementation.
 * <P>If there is a data store transaction in progress, the returned
 * instance will be persistent-clean.
 * If there is an optimistic transaction in progress, the returned
 * instance will be persistent-nontransactional.
 * @see #getObjectId(Object pc)
 * @see #getTransactionalObjectId(Object pc)
 * @return the PersistenceCapable instance with the specified
 * ObjectId
 * @param oid an ObjectId
 * @param validate if the existence of the instance is to be validated
 */
public Object getObjectById(Object object, boolean validate) {
    if(!(object instanceof JDOObjectId)) {
	    throw new JDOUserException(JDOException.argumentObjectIsNotJDOObjectId(object).getMessage());
	}
	JDOObjectId id = (JDOObjectId) object;
	ReadObjectQuery query = new ReadObjectQuery(id.getObjectClass());
	query.setSelectionKey(id.getKey());
	
	Object result = getUnitOfWork().executeQuery(query);
	if(result == null) {
		throw new JDODataStoreException(JDOException.objectForIdDoesNotExist(object).getMessage());
	}
	return result;
}
/**
 * The ObjectId returned by this method represents the JDO identity of
 * the instance.  The ObjectId is a copy (clone) of the internal state
 * of the instance, and changing it does not affect the JDO identity of
 * the instance.  
 * <P>The getObjectId method returns an ObjectId instance that represents
 * the object identity of the specified JDO instance. The identity is
 * guaranteed to be unique only in the context of the JDO
 * PersistenceManager that created the identity, and only for two types
 * of JDO Identity: those that are managed by the application, and
 * those that are managed by the data store.
 * <P>If the object identity is being changed in the transaction, by the
 * application modifying one or more of the application key fields,
 * then this method returns the identity as of the beginning of the
 * transaction. The value returned by getObjectId will be different
 * following afterCompletion processing for successful transactions.
 * <P>Within a transaction, the ObjectId returned will compare equal to
 * the ObjectId returned by only one among all JDO instances associated
 * with the PersistenceManager regardless of the type of ObjectId.
 * <P>The ObjectId does not necessarily contain any internal state of the
 * instance, nor is it necessarily an instance of the class used to
 * manage identity internally. Therefore, if the application makes a
 * change to the ObjectId instance returned by this method, there is
 * no effect on the instance from which the ObjectId was obtained.
 * <P>The getObjectById method can be used between instances of
 * PersistenceManager of different JDO vendors only for instances of
 * persistence capable classes using application-managed (primary key)
 * JDO identity. If it is used for instances of classes using datastore
 * identity, the method might succeed, but there are no guarantees that
 * the parameter and return instances are related in any way.
 * @see #getTransactionalObjectId(Object pc)
 * @see #getObjectById(Object oid, boolean validate)
 * @param pc the PersistenceCapable instance
 * @return the ObjectId of the instance
 */
public Object getObjectId(Object object) {
	JDOObjectId id = new JDOObjectId();
	id.setObjectClass(object.getClass());
	id.setKey(getSession().keyFromObject(object));
	
	return id;
}
/**
 * Return the Class that implements the JDO Identity for the
 * specified PersistenceCapable Class.  The application can use the
 * returned Class to construct a JDO Identity instance for
 * application identity PersistenceCapable classes.  This JDO Identity
 * instance can then be used to get an instance of the
 * PersistenceCapable class for use in the application.
 *
 * <P>In order for the application to construct an instance of the ObjectId class
 * it needs to know the class being used by the JDO implementation.
 * @param cls the PersistenceCapable Class
 * @return the Class of the ObjectId of the parameter
 * @see #getObjectById
 */
public Class getObjectIdClass(Class objectClass) {
	//Don't use ClassConstants because jdo is no longer in TopLink jar
	return JDOObjectId.class;
}
/**
 * This method returns the PersistenceManagerFactory used to create
 * this PersistenceManager.  
 * @return the PersistenceManagerFactory that created
 * this PersistenceManager
 */
public PersistenceManagerFactory getPersistenceManagerFactory() {
	return factory;
}




/**
 * The application can manage the PersistenceManager instances
 * more easily by having an application object associated with each
 * PersistenceManager instance.
 * @return the user object associated with this PersistenceManager
 * @see #setUserObject
 */
public Object getUserObject() {
	return null;
}
/**
 * A PersistenceManager instance can be used until it is closed.
 * @return true if this PersistenceManager has been closed
 * @see #close()
 */
public boolean isClosed() {
	return getSession().isConnected();
}

/**
 * NOT REQUIRED:<p>
 * Not required.
 * <p>JDO:<p>
 * Make an instance non-transactional after commit.
 *
 * <P>Normally, at transaction completion, instances are evicted from the
 * cache.  This method allows an application to identify an instance as
 * not being evicted from the cache at transaction completion.  Instead,
 * the instance remains in the cache with nontransactional state.
 *
 * @param pc the instance to make nontransactional.
 */
public void makeNontransactional(Object arg1) {
}


/**
 * Make the transient instance persistent in this PersistenceManager.
 * This method must be called in an active transaction.
 * The PersistenceManager assigns an ObjectId to the instance and
 * transitions it to persistent-new.
 * The instance will be managed in the Extent associated with its Class.
 * The instance will be put into the data store at commit.
 * The closure of instances of PersistenceCapable classes
 * reachable from persistent
 * fields will be made persistent at commit.  [This is known as 
 * persistence by reachability.]
 * @param pc a transient instance of a Class that implements
 * PersistenceCapable
 */
public void makePersistent(Object object) {
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	getUnitOfWork().registerNewObject(object);
	if (autoCommit) {
		currentTransaction().commit();
	}
}


/**
 * Make an instance subject to transactional boundaries.
 *
 * <P>Transient instances normally do not observe transaction boundaries.
 * This method makes transient instances sensitive to transaction completion.
 * If an instance is modified in a transaction, and the transaction rolls back,
 * the state of the instance is restored to the state before the first change
 * in the transaction.
 *
 * <P>For persistent instances read in optimistic transactions, this method
 * allows the application to make the state of the instance part of the
 * transactional state.  At transaction commit, the state of the instance in
 * cache is compared to the state of the instance in the data store.  If they
 * are not the same, then an exception is thrown.
 * @param pc the instance to make transactional.
 */
public void makeTransactional(Object object) {
	getUnitOfWork().registerObject(object);
}


/**
 * NOT REQUIRED:
 * This is not required.
 * <p>JDO:<p>
 * Make an instance transient, removing it from management by this
 * PersistenceManager.
 *
 * <P>The instance loses its JDO identity and it is no longer associated
 * with any PersistenceManager.  The state of fields is preserved unchanged.
 * @param pc the instance to make transient.
 */
public void makeTransient(Object object) {}


/**
 * Create a new Query with no elements.
 * @return the new Query.
 */
public Query newQuery() {
	return new JDOQuery(this);
}
/** 
 * Create a new Query specifying the Class of the candidate instances.
 * @param cls the Class of the candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass) {
	JDOQuery query = new JDOQuery(this);
	query.setClass(queryClass);

	return query;
}
/**
 * Create a new Query with the Class of the candidate instances and Filter.
 * @param cls the Class of results
 * @param filter the filter for candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass, String filter) {
	Query query = newQuery(queryClass);
	query.setFilter(filter);
	return query;
}


/**
 * Create a new Query with the Class of the candidate instances and 
 * candidate Extent.
 * @param cls the Class of results
 * @param cln the Extent of candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass, Extent arg2) {
	return newQuery(queryClass);
}
/**
 * Create a new Query with the Class of the candidate instances,
 * candidate Extent, and filter.
 * @param cls the Class of results
 * @param cln the Extent of candidate instances
 * @param filter the filter for candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass, Extent extent, String filter) {
	Query query = newQuery(queryClass);
	query.setCandidates(extent);
	query.setFilter(filter);
	return query;
}
/**
 * Create a new Query using elements from another Query.  The other Query
 * must have been created by the same JDO implementation.  It might be active
 * in a different PersistenceManager or might have been serialized and
 * restored.
 * <P>All of the settings of the other Query are copied to this Query,
 * except for the candidate Collection or Extent.
 * @return the new Query
 * @param compiled another Query from the same JDO implementation
 */
public Query newQuery(Object query) {
	return (Query) query;
}
/**
 * NOT REQUIRED:<p>
 * This is one of those strange JDO implementation aspects that were added to the specification.
 * We do not require this, nor do we endose its usage.
 * JDO:<p>
 * Create a new instance of a Second Class Object which tracks changes made
 * to itself and notifies its owning instance.  The types supported include
 * java.util.Date and java.util.Locale.  Implementations might also support
 * java.sql.Date, java.sql.Time, and java.sql.Timestamp.  The effect of 
 * this method on the owner is to mark the field dirty, which might
 * cause a state change in the owner.
 * @param type the Class of the instance to be instantiated
 * @param owner the First Class Object instance to notify on changes
 * @param fieldName the name of the field in the owner
 * @return the new instance
 */
public Object newSCOInstance(Class arg1, Object arg2, String arg3) {
	return null;
}


/**
 * Refresh the state of the instance from the data store.
 *
 * <P>In an optimistic transaction, the state of instances in the cache
 * might not match the state in the data store.  This method is used to
 * reload the state of the instance from the data store so that a subsequent
 * commit is more likely to succeed.
 * <P>Outside a transaction, this method will refresh nontransactional state.
 * @param pc the instance to refresh.
 */
public void refresh(Object object) {
	if (getUnitOfWork() == null) {
		getSession().refreshObject(object);
	} else {
		getUnitOfWork().refreshObject(object);
	}
}

/**
 * Set the ignoreCache parameter for queries.
 *
 * <P>IgnoreCache set to true specifies that for all Query instances created by this
 * PersistenceManager, the default is the cache should be ignored for queries.
 * @param flag the ignoreCache setting.
 */
public void setIgnoreCache(boolean ignoreCache) {
	throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setIgnoreCache").getMessage());
}


/**
 * The application can manage the PersistenceManager instances
 * more easily by having an application object associated with each
 * PersistenceManager instance.
 * @param o the user instance to be remembered by the PersistenceManager
 * @see #getUserObject
 */
 
public void setUserObject(Object userObject) {
	throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setUserObject").getMessage());
}

/**
 * Returns a String that represents the value of this object.
 * @return a string representation of the receiver
 */
public String toString() {
	// Insert code to print the receiver here.
	// This implementation forwards the message to super. You may replace or supplement this.
	return "JDO:" + getSession().toString();
}
/**
 * Delete an array of instances from the data store.
 * @param pcs a Collection of persistent instances
 * @see #deletePersistent(Object pc)
 */
public void deletePersistentAll(java.lang.Object[] objects) {
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	for (int index = 0; index < objects.length; index++) {
		deletePersistent(objects[index]);
	}
	if (autoCommit) {
		currentTransaction().commit();
	}
}
/**
 * Delete a Collection of instances from the data store.
 * @param pcs a Collection of persistent instances
 * @see #deletePersistent(Object pc)
 */
public void deletePersistentAll(Collection objects) {
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	for (Iterator iterator = objects.iterator(); iterator.hasNext(); ) {
		deletePersistent(iterator.next());
	}
	if (autoCommit) {
		currentTransaction().commit();
	}
}
/**
 * Initialize the cache.  This should only be called if the application is sure that it no longer reference any of the objects.
 * When used with a DatabaseSession this will clear the cache, when used with a ClientSession it will have no effect as the ClientSession shares
 * the ServerSession's cache.
 * JDO:<p>
 * Mark all persistent-nontransactional instances as no longer needed 
 * in the cache.  It transitions
 * all persistent-nontransactional instances to hollow.  Transactional
 * instances are subject to eviction based on the RetainValues setting.
 * @see #evict(Object pc)
 */
public void evictAll() {
	getSession().initializeIdentityMaps();
}
/**
 * Mark an array of instances as no longer needed in the cache.
 * @see #evict(Object pc)
 * @param pcs the array of instances to evict from the cache.
 */
public void evictAll(Object[] objects) {
	for (int index = 0; index < objects.length; index++) {
		evict(objects[index]);
	}
}
/**
 * Mark a Collection of instances as no longer needed in the cache.
 * @see #evict(Object pc)
 * @param pcs the Collection of instance to evict from the cache.
 */
public void evictAll(Collection objects) {
	for (Iterator iterator = objects.iterator(); iterator.hasNext(); ) {
		evict(iterator.next());
	}
}
/**
 * Return the associated session or unit of work if within a transaction.
 */
public Session getActiveSession() {
	if (getUnitOfWork() != null) {
		return getUnitOfWork();
	} else {
		return getSession();
	}
}
/**
 * Get the current Multithreaded flag for this PersistenceManager.  
 * @see #setMultithreaded
 * @return the Multithreaded setting.
 */
public boolean getMultithreaded() {
	return false;
}
/**  
 * When the nontransactional read flag is set to false the PersistenceManager has a single TopLink UnitOfWork
 * associated with it.  All objects are accessed in the context of this unit of work to preserve clone identity.
 * When the nontransactional read flag is set to true, the PersistenceManager only acquires a unit of work on the begin of the transaction
 * and objects that are to be changed must be first reigstered into the transaction context through re-querying them, or through the getObjectById
 * This enables read to occur on the shared object cache, without the overhead of cloning and change tracking,
 * it also allows for nested units of work to be supported.
 * <p>
 * JDO:
 * Get the default NontransactionalRead setting for all PersistenceManager instances
 * obtained from this factory.
 *
 * @return the default NontransactionalRead setting.
 */
public boolean getNontransactionalRead () {
	return nontransactionalRead;
}   /**
 * Return the associated session.
 */
public Session getSession() {
	return session;
}
/**
 * The ObjectId returned by this method represents the JDO identity of
 * the instance.  The ObjectId is a copy (clone) of the internal state
 * of the instance, and changing it does not affect the JDO identity of
 * the instance.
 * <P>If the object identity is being changed in the transaction, by the
 * application modifying one or more of the application key fields,
 * then this method returns the current identity in the transaction.
 * <P>If there is no transaction in progress, or if none of the key fields
 * is being modified, then this method will return the same value as
 * getObjectId.
 * @see #getObjectId(Object pc)
 * @see #getObjectById(Object oid, boolean validate)
 * @param pc a PersistenceCapable instance
 * @return the ObjectId of the instance
 */
public Object getTransactionalObjectId(Object object) {
	return getObjectId(object);
}

/**
 * PUBLIC:
 * <P>This is TOPLink helper method that return the transactional object 
 * of the JDO instance. Changes made the the transactional object 
 * is persisted when the current transaction commit.
 *
 * <P>The method is equivalent to manager.getObjectById(manager.getTransactionalObjectId(object), true);
 * @return the transactional representation of the JDO instance
 */
public Object getTransactionalObject(Object object) {
	return getObjectById(getTransactionalObjectId(object), true);
}

/**
 * Return the active unit of work.
 */
public UnitOfWork getUnitOfWork() {
	return this.currentTransaction.getUnitOfWork();
}
/**
 * NOT REQUIRED:<p>
 * Not required.
 * <p>JDO:<p>
 * Make an array of instances non-transactional after commit.
 *
 * @param pcs the array of instances to make nontransactional.
 * @see #makeNontransactional(Object pc)
 */
public void makeNontransactionalAll(Object[] arg1) {}
/**
 * NOT REQUIRED:<p>
 * Not required.
 * <p>JDO:<p>
 * Make a Collection of instances non-transactional after commit.
 *
 * @param pcs the Collection of instances to make nontransactional.
 * @see #makeNontransactional(Object pc)
 */
public void makeNontransactionalAll(Collection arg1) {}
/**
 * Make an array of instances persistent.
 * @param pcs an array of transient instances
 * @see #makePersistent(Object pc)
 */
public void makePersistentAll(Object[] objects) {
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	for (int index = 0; index < objects.length; index++) {
		makePersistent(objects[index]);
	}
	if (autoCommit) {
		currentTransaction().commit();
	}
}
/**
 * Make a Collection of instances persistent.
 * @param pcs a Collection of transient instances
 * @see #makePersistent(Object pc)
 */
public void makePersistentAll(Collection objects) {
	boolean autoCommit = false;
	if (! currentTransaction().isActive()) {
		currentTransaction().begin();
		autoCommit = true;
	}
	for (Iterator iterator = objects.iterator(); iterator.hasNext(); ) {
		makePersistent(iterator.next());
	}
	if (autoCommit) {
		currentTransaction().commit();
	}
}
/**
 * Make an array of instances subject to transactional boundaries.
 * @param pcs the array of instances to make transactional.
 * @see #makeTransactional(Object pc)
 */
public void makeTransactionalAll(Object[] objects) {
	for (int index = 0; index < objects.length; index++) {
		makeTransactional(objects[index]);
	}
}
/**
 * Make a Collection of instances subject to transactional boundaries.
 * @param pcs the Collection of instances to make transactional.
 * @see #makeTransactional(Object pc)
 */
public void makeTransactionalAll(Collection objects) {
	for (Iterator iterator = objects.iterator(); iterator.hasNext(); ) {
		makeTransactional(iterator.next());
	}
}
/**
 * NOT REQUIRED:
 * This is not required.
 * <p>JDO:<p>
 * Make an array of instances transient, removing them from management by this
 * PersistenceManager.
 *
 * <P>The instances lose their JDO identity and they are no longer associated
 * with any PersistenceManager.  The state of fields is preserved unchanged.
 * @param pcs the instances to make transient.
 */
public void makeTransientAll(Object[] arg1) {}
/**
 * NOT REQUIRED:
 * This is not required.
 * <p>JDO:<p>
 * Make a Collection of instances transient, removing them from management by this
 * PersistenceManager.
 *
 * <P>The instances lose their JDO identity and they are no longer associated
 * with any PersistenceManager.  The state of fields is preserved unchanged.
 * @param pcs the instances to make transient.
 */ 
public void makeTransientAll(Collection arg1) {}
 /**
 * NOT REQUIRED:<p>
 * This is one of those strange JDO implementation aspects that were added to the specification.
 * We do not require this, nor do we endose its usage.
 * <p>JDO:<p>
 * Create a new instance of a Collection which tracks changes made
 * to itself and notifies its owning instance.  The types supported must
 * include java.util.Collection, java.util.Set, and java.util.HashSet.
 * The effect of 
 * this method on the owner is to mark the field dirty, which might
 * cause a state change in the owner.
 * Implementations may also support other types.
 * @see #newSCOInstance
 * @param initialContents the Collection containing the elements to be
 * copied into the new Colleciton; may be null.
 * @param type the Class or Interface of the instance to be instantiated;
 * must not be null.
 * @param owner the First Class Object instance to notify on changes;
 * must not be null.
 * @param fieldName the name of the field in the owner; must not be null.
 * @param elementType the element type assignment compatible with all
 * added elements; must not be null (use Object if instances of any class
 * are acceptable).
 * @param allowNulls whether nulls are permitted as elements.
 * @param initialCapacity the initial size of the Collection; must be
 * non-negative.
 * @param loadFactor loadFactor for the Collection type, if that type uses
 * a load factor.  If so, loadFactor must be greater than 0.  Otherwise,
 * may be null.
 * @throws IllegalArgumentException if any of the restrictions noted in
 * the parameters is not met.
 * @return the new instance
 */
public Collection newCollectionInstance (Class type, Object owner, String fieldName,
	  Class elementType, boolean allowNulls, Integer initialCapacity, Float loadFactor,
	  Collection initialContents) throws IllegalArgumentException {
	return new Vector(initialCapacity.intValue());
}
/**
 * NOT REQUIRED:<p>
 * This is one of those strange JDO implementation aspects that were added to the specification.
 * We do not require this, nor do we endose its usage.
 * <p>JDO:<p>
 * Create a new instance of a Collection which tracks changes made
 * to itself and notifies its owning instance.  The effect of 
 * this method on the owner is to mark the field dirty, which might
 * cause a state change in the owner.
 * @see #newSCOInstance
 * @return the new instance
 * @param allowNulls whether nulls are allowed as keys or values
 * @param type the Class or Interface of the instance to be instantiated;
 * must not be null
 * @param owner the First Class Object instance to notify on changes; must
 * not be null
 * @param fieldName the name of the field in the owner; must not be null
 * @param keyType the type of the key; must not be null
 * @param valueType the type of the value; must not be null
 * @param initialCapacity the initial capacity for the new Map; must be
 * non-negative.
 * @param loadFactor the load factor for the new Map; must be positive
 * @param initialContents the initial contents of the new Map; may be null
 * @throws IllegalArgumentException if any of the restrictions noted in
 * the parameters is not met.
 */
public Map newMapInstance (Class type, Object owner, String fieldName,
  Class keyType, Class valueType, boolean allowNulls, 
  Integer initialCapacity, Float loadFactor, 
  Map initialContents) throws IllegalArgumentException {
	  return new HashMap(initialCapacity.intValue());
}
/**
 * Create a new Query with the Class of the candidate instances and 
 * candidate Collection.
 * @param cls the Class of results
 * @param cln the Collection of candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass, Collection collection) {
	Query query = newQuery(queryClass);
	query.setCandidates(collection);
	return query;
}
/**
 * Create a new Query with the Class of the candidate instances, 
 * candidate Collection, and filter.
 * @param cls the Class of candidate instances
 * @param cln the Collection of candidate instances
 * @param filter the filter for candidate instances
 * @return the new Query
 */
public Query newQuery(Class queryClass, Collection collection, String filter) {
	Query query = newQuery(queryClass);
	query.setCandidates(collection);
	query.setFilter(filter);
	return query;
}
/**
 * Create a new Query with the Class of the candidate instances and 
 * filter expression.
 * @return the new Query
 */
public Query newQuery(Class queryClass, Expression expression) {
	JDOQuery query = (JDOQuery) newQuery(queryClass);
	query.setFilter(expression);
	return query;
}
/**
 * Create a new Query using the specified language.
 * @param language the language of the query parameter
 * @param query the query, which is of a form determined by the language
 * @return the new Query
 */   
public Query newQuery(String language, Object query) {
	return newQuery();
}
/**
 * PUBLIC:
 * Read all of the instances of the class from the database.
 * This operation can be customized through using a ReadAllQuery,
 * or through also passing in a selection criteria.
 *
 * @see ReadAllQuery
 * @see #readAllObjects(Class, Expression)
 */

public Vector readAllObjects(Class domainClass)
{
	return getSession().readAllObjects(domainClass);
}
/**
 * PUBLIC:
 * Read all of the instances of the class from the database matching the given expression.
 * This operation can be customized through using a ReadAllQuery.
 *
 * @see ReadAllQuery
 */

public Vector readAllObjects(Class domainClass, Expression expression)
{
	return getSession().readAllObjects(domainClass, expression);
}
/**
 * PUBLIC:
 * Read the first instance of the class from the database matching the given expression.
 * This operation can be customized through using a ReadObjectQuery.
 *
 * @see ReadObjectQuery
 */
 
public Object readObject(Class domainClass, Expression expression)
{
	return getSession().readObject(domainClass, expression);
}
/**
 * Refresh the state of all applicable instances from the data store.
 * <P>If called with an active transaction, all transactional instances
 * will be refreshed.  If called outside an active transaction, all
 * nontransactional instances will be refreshed.
 * @see #refresh(Object pc)
 */
public void refreshAll() {
	if (getUnitOfWork() != null) {
		getUnitOfWork().revertAndResume();
	}
}
/**
 * Refresh the state of an array of instances from the data store.
 *
 * @see #refresh(Object pc)
 * @param pcs the array of instances to refresh.
 */
public void refreshAll(Object[] objects) {
	for (int index = 0; index < objects.length; index++) {
		refresh(objects[index]);
	}
}
/**
 * Refresh the state of a Collection of instances from the data store.
 *
 * @see #refresh(Object pc)
 * @param pcs the Collection of instances to refresh.
 */
public void refreshAll(Collection objects) {
	for (Iterator iterator = objects.iterator(); iterator.hasNext(); ) {
		refresh(iterator.next());
	}
}
/**
 * Set the Multithreaded flag for this PersistenceManager.  Applications
 * that use multiple threads to invoke methods or access fields from 
 * instances managed by this PersistenceManager must set this flag to true.
 * Instances managed by this PersistenceManager include persistent or
 * transactional instances of PersistenceCapable classes, as well as 
 * helper instances such as Query, Transaction, or Extent.
 *
 * @param flag the Multithreaded setting.
 */
public void setMultithreaded(boolean multithreaded) {
	throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setMultithreaded").getMessage());
}
/**  
 * PUBLIC:
 * By default the nontransactional read flag is set to false.  When the nontransactional read flag is set to false the PersistenceManager 
 * has a single TopLink UnitOfWork associated with it.  All objects are accessed in the context of this unit of work to preserve 
 * clone identity.  When the nontransactional read flag is set to true, the PersistenceManager only acquires a unit of work on the begin 
 * of the transaction and objects that are to be changed must be first reigstered into the transaction context through re-querying them, 
 * or through the getObjectById.  This enables read to occur on the shared object cache, without the overhead of cloning and change tracking,
 * it also allows for nested units of work to be supported.
 * 
 * CAUTION: when the nontransactional read flad is set to true, the current UnitOfWork is released if it is active.  The application should
 * decide to commit the current transaction before calling this method.
 * <p>
 * JDO:
 * Set the default NontransactionalRead setting for all PersistenceManager instances
 * obtained from this factory.  
 *
 * @param flag the default NontransactionalRead setting.
 */
public void setNontransactionalRead (boolean nontransactionalRead) {
	  this.nontransactionalRead = nontransactionalRead;
	if ((! nontransactionalRead) && (! currentTransaction().isActive())) {
		currentTransaction().begin();
	}
}  /**
 * Set the associated session.
 */
public void setSession(Session session) {
	this.session = session;
}}

