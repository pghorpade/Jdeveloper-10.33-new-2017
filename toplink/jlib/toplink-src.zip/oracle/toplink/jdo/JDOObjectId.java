// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

import java.util.*;
/**
 * PUBLIC:<p>
 * JDO wrapper for a primary key.
 * Contains a vector of the object primary key values, and the object's class.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview. 
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */
 
public class JDOObjectId {
    protected Vector key;	
    protected Class objectClass;
	
    /**
    * Create a new object id.
    */
    public JDOObjectId() {
    	super();
    }
	
	public boolean equals(Object oid) {
		if (this == oid){
			return true;
		}
		if (! (oid instanceof JDOObjectId)) {
			return false;
		}	
	    return getObjectClass().equals(((JDOObjectId) oid).getObjectClass()) && getKey().equals(((JDOObjectId) oid).getKey());
	}
	
	public java.util.Vector getKey() {
	    return key;
	}
	
	public java.lang.Class getObjectClass() {
	    return objectClass;
	}
	
	public int hashCode() {
	if (getKey() == null) {
		return 0;
	}
	    return getKey().hashCode();
	}
	
	public void setKey(java.util.Vector newKey) {
	    key = newKey;
	}
	    
	public void setObjectClass(java.lang.Class newObjectClass) {
	    objectClass = newObjectClass;
	}
	public String toString(){
	    return "JDObjectId: " + getKey();
	}
}

