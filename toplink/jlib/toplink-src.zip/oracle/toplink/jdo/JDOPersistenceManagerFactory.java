// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

//CR3881 change import to import session.xml Session Manager
import oracle.toplink.tools.sessionmanagement.SessionManager;
import oracle.toplink.sessions.*;
import oracle.toplink.exceptions.ValidationException;
import java.util.*;
import javax.jdo.*;

/**
 * PUBLIC:
 * TopLink persistence manager for the JDO specification.
 * This supports JDO through the TopLink API,
 * Supported are the basic JDO interfaces but not required or implemented are the PersistenceCapable implementation,
 * byte-code enhancers or any other internal JDO reference implementation related aspects.
 * JDO wrapper for a TopLink session manager.
 * <p>
 * The factory allows for a persistence manager to be acquire through two methods,
 * <P>- a TopLink Project is provided to the factory and a persistence manager on a DatabaseSession is returned (this should only be used in two-tier)
 * <p>- a session-name is provided to the factory (or default name is used)
 * and the TopLink SessionManager is used to access a defined ServerSession from the TopLink Session.xml file.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview. 
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */

public class JDOPersistenceManagerFactory implements PersistenceManagerFactory {
    
//protected boolean ignoreCache;	
//protected boolean multithreaded;	
protected boolean nontransactionalRead;	
protected Project project;	
protected Properties properties;	
protected String sessionName;   
protected Session session;

/**
 * Create a new factory, by default this will connect through the TopLink SessionManager to the default session.
 */
public JDOPersistenceManagerFactory() {
	this.sessionName = "default";
	//this.ignoreCache = false;
	this.nontransactionalRead = false;
    //this.multithreaded = true;	
	this.properties = new Properties();
}
	
/**
 * Create a new factory that will use the session-name to lookup the persistence manager's TopLink session
 * through the TopLink SessionManager.
 */
public JDOPersistenceManagerFactory(String sessionName) {
	//this.ignoreCache = false;
	this.nontransactionalRead = false;
    //this.multithreaded = true;	
	this.properties = new Properties();
	this.sessionName = sessionName;
}
/**
 * Create a new factory that will use the project to create the persistence manager's TopLink session instance.
 * A DatabaseSession will be created and this mechanism should only be used for 2-tier applications.
 */
public JDOPersistenceManagerFactory(Project project) {
	//this.ignoreCache = false;
	this.nontransactionalRead = false;
    //this.multithreaded = true;	
	this.properties = new Properties();    
	this.project = project;
} 

/**
 * Create a new factory that will use TopLink session instance.
 * The session can be a DatabseSession or a ServerSession
 */
public JDOPersistenceManagerFactory(Session topLinkSession) {
	//this.ignoreCache = false;
	this.nontransactionalRead = false;
    //this.multithreaded = true;	
	this.properties = new Properties();    
	this.session = topLinkSession;
} 
  /** Get the driver name for the data store connection.
   * @return the driver name for the data store connection.
   */
  public String getConnectionDriverName () {
	  if (getProject() == null) {
		  return null;
	  } else {
		  return getProject().getLogin().getDriverClassName();
	  }
  }     
  /** Get the data store connection factory.
   * @return the data store connection factory.
   */
  public Object getConnectionFactory () {
	  return null;
  }        
  /** Get the name for the data store connection factory.
   * @return the name of the data store connection factory.
   */
  public String getConnectionFactoryName () {
	  return null;
  }        
  /** Get the URL for the data store connection.
   * @return the URL for the data store connection.
   */
  public String getConnectionURL () {
	  if (getProject() == null) {
		  return null;
	  } else {
		  return getProject().getLogin().getConnectionString();
	  }
  }        
  /** Get the user name for the data store connection.
   * @return the user name for the data store connection.
   */
  public String getConnectionUserName () {
	  if (getProject() == null) {
		  return null;
	  } else {
		  return getProject().getLogin().getUserName();
	  }
  }          
  /** Get the default IgnoreCache setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default IngoreCache setting.
   */
  public boolean getIgnoreCache () {
	  return false;
  }     
/**  
 * When the nontransactional read flag is set to false the PersistenceManager has a single TopLink UnitOfWork
 * associated with it.  All objects are accessed in the context of this unit of work to preserve clone identity.
 * When the nontransactional read flag is set to true, the PersistenceManager only acquires a unit of work on the begin of the transaction
 * and objects that are to be changed must be first reigstered into the transaction context through re-querying them, or through the getObjectById
 * This enables read to occur on the shared object cache, without the overhead of cloning and change tracking,
 * it also allows for nested units of work to be supported.
 * <p>
 * JDO:
 * Get the default NontransactionalRead setting for all PersistenceManager instances
 * obtained from this factory.
 *
 * @return the default NontransactionalRead setting.
 */
public boolean getNontransactionalRead () {
	return nontransactionalRead;
}   
  /** Get the default NontransactionalWrite setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default NontransactionalWrite setting.
   */
  public boolean getNontransactionalWrite () {
	return false;
  }       
  /** Get the default Optimistic setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @return the default Optimistic setting.
   */
  public boolean getOptimistic() {
	return false;
  }     
/**
 * Get an instance of PersistenceManager from this factory.  The instance has
 * default values for options.
 *
 * <P>After the first use of getPersistenceManager, no "set" methods will
 * succeed.
 *
 * @return a PersistenceManager instance with default options.
 */
public PersistenceManager getPersistenceManager() {
	JDOPersistenceManager manager = null;
	if(session != null){
	    if(!session.isConnected()){
	        ((DatabaseSession) session).login();
	    }
	    manager = new JDOPersistenceManager(this, session);
	    
	} else if(project != null) {
		DatabaseSession databaseSession = project.createDatabaseSession();
		databaseSession.login();
		manager = new JDOPersistenceManager(this, databaseSession);
	}else {
		manager = new JDOPersistenceManager(this, SessionManager.getManager().getSession(sessionName));
	}
	
	return manager;
}

  /** Get the default RetainValues setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @return the default RetainValues setting.
   */
  public boolean getRetainValues () {
	  return false;
  }    
  /** PUBLIC:
   *  Set the driver name for the data store connection.
   *  This method is only in effect when the factory is instantiate with a project
   *  JDOPersistenceManagerFactory(Project)
   * @param driverName the driver name for the data store connection.
   */
  public void setConnectionDriverName  (String driverName) {
	  if (getProject() != null) {
		  getProject().getLogin().setDriverClassName(driverName);
	  }
  }      
  /** Set the data store connection factory.  JDO implementations
   * will support specific connection factories.  The connection
   * factory interfaces are not part of the JDO specification.
   * @param connectionFactory the data store connection factory.
   */
  public void setConnectionFactory (Object connectionFactory) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setConnectionFactory").getMessage());
  }  
  /** Set the name for the data store connection factory.
   * @param connectionFactoryName the name of the data store connection factory.
   */
  public void setConnectionFactoryName (String connectionFactoryName) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setConnectionFactoryName").getMessage());
  }  
  /** Set the password for the data store connection.
   * @param password the password for the data store connection.
   */
  public void setConnectionPassword (String password) {
	  if (getProject() != null) {
		  getProject().getLogin().setPassword(password);
	  }
  }    
  /** Set the URL for the data store connection.
   * @param URL the URL for the data store connection.
   */
  public void setConnectionURL (String URL) {
	  if (getProject() != null) {
		  getProject().getLogin().setConnectionString(URL);
	  }
  }    
  /** Set the user name for the data store connection.
   * @param userName the user name for the data store connection.
   */
  public void setConnectionUserName(String userName) {
	  if (getProject() != null) {
		  getProject().getLogin().setUserName(userName);
	  }
  }    
  /** Set the default IgnoreCache setting for all PersistenceManager instances
   * obtained from this factory.
   *
   * @param flag the default IgnoreCache setting.
   */
  public void setIgnoreCache (boolean ignoreCache) {
	  throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setIgnoreCache").getMessage());
	  //this.ignoreCache = ignoreCache;
  }  
/**  
 * PUBLIC: When the nontransactional read flag is set to false the PersistenceManager has a single TopLink UnitOfWork
 * associated with it.  All objects are accessed in the context of this unit of work to preserve clone identity.
 * When the nontransactional read flag is set to true, the PersistenceManager only acquires a unit of work on the begin of the transaction
 * and objects that are to be changed must be first reigstered into the transaction context through re-querying them, or through the getObjectById
 * This enables read to occur on the shared object cache, without the overhead of cloning and change tracking,
 * it also allows for nested units of work to be supported.
 * <p>
 * JDO:
 * Set the default NontransactionalRead setting for all PersistenceManager instances
 * obtained from this factory.  
 *
 * @param flag the default NontransactionalRead setting.
 */
public void setNontransactionalRead (boolean nontransactionalRead) {
	  this.nontransactionalRead = nontransactionalRead;
} 
 /** PUBLIC: This method is not supported
   *
   * <p>Set the default NontransactionalWrite setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @param flag the default NontransactionalWrite setting.
   */
  public void setNontransactionalWrite (boolean flag) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setNontransactionalWrite").getMessage());    
  }  
  
  /** PUBLIC: This method is not supported
   *  <P>Set the default Optimistic setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * @param flag the default Optimistic setting.
   */
  public void setOptimistic (boolean flag) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setOptimistic").getMessage());    
  }  
 /** PUBLIC: This method is not supported
   */
  public void setRetainValues (boolean flag) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setRetainValues").getMessage());    
  }  
 /** PUBLIC: This method is not supported and it always returns null
   */
  public Object getConnectionFactory2 () {
	  return null;
  }          
 /** PUBLIC: This method is not supported and it always returns null 
   * Get the name for the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.
   * @return the name of the data store connection factory.
   */
  public String getConnectionFactory2Name () {
	  return null;
  } 
  
  /** PUBLIC: This method is not supported and it always returns 0
    *Get the MaxPool setting for the PersistenceManager 
	* pool for this factory.
	* @return the MaxPool setting.
	*/
	public int getMaxPool() {
	  return 0;
	}   	
	/** PUBLIC: This method is not supported and it always returns 0
	* Get the MinPool setting for the PersistenceManager 
	* pool for this factory.
	* @return the MinPool setting.
	*/
	public int getMinPool() {
	  return 0;
	}   	
	/** PUBLIC: This method is not supported and it always returns 0
	* Get the MsWait setting for the PersistenceManager 
	* pool for this factory.
	* @return the MsWait setting.
	*/
	public int getMsWait() {
	  return 0;
	}     
   /** PUBLIC: Get the default Multithreaded setting for all PersistenceManager instances
   * obtained from this factory.  
   *
   * Eventhough it is possible to use 
   * @return the default Multithreaded setting.
   */
  public boolean getMultithreaded() {
	  return false;
  }        
/**
 * Get an instance of PersistenceManager from this factory.  The instance has
 * default values for options.  The parameters userid and password are used
 * when obtaining datastore connections from the connection pool.
 *
 * <P>After the first use of getPersistenceManager, no "set" methods will
 * succeed.
 *
 * @return a PersistenceManager instance with default options.
 * @param userid the userid for the connection
 * @param password the password for the connection
 */
public PersistenceManager getPersistenceManager(String userid, String password) {
	if (getProject() != null) {
		getProject().getLogin().setUserName(userid);
		getProject().getLogin().setPassword(password);
	}		
	return getPersistenceManager();
}
/**
 * Return the associated TopLink project if defined.
 */
public Project getProject() {
	return project;
}
/**
 * getProperties method comment.
 */
public Properties getProperties() {
	return properties;
}
/**
 * Return the session-name used to lookup the factories ServerSession through the TopLink SessionManager.
 */
public String getSessionName() {
	return sessionName;
}  

/** Set the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.  JDO implementations
   * will support specific connection factories.  The connection
   * factory interfaces are not part of the JDO specification.
   * @param connectionFactory the data store connection factory.
   */
  public void setConnectionFactory2 (Object connectionFactory) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setConnectionFactory2").getMessage());
  }    /** Set the name for the second data store connection factory.  This is
   * needed for managed environments to get nontransactional connections for
   * optimistic transactions.
   * @param connectionFactoryName the name of the data store connection factory.
   */
  public void setConnectionFactory2Name (String connectionFactoryName) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setConnectionFactory2Name").getMessage());
  }  	/** Set the MaxPool setting for the PersistenceManager 
	* pool for this factory.
   * @param maxPool the MaxPool setting.
	 */
	public void setMaxPool(int maxPool) {
	    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setMaxPool").getMessage());
	}	/** Set the MinPool setting for the PersistenceManager 
	* pool for this factory.
	* @param minPool the MinPool setting.
	*/
	public void setMinPool(int minPool) {
	    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setMinPool").getMessage());
	}	/** Set the MsWait setting for the PersistenceManager 
	* pool for this factory.
	* @param msWait the MsWait setting.
	*/
	public void setMsWait(int msWait) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setMsWait").getMessage());	    
	}
	
/** PUBLIC:
 * <p>
 * JDO:
 * Set the default Multithreaded setting for all PersistenceManager instances
 * obtained from this factory.
 *
 * @param flag the default Multithreaded setting.
 */
public void setMultithreaded (boolean multithreaded) {
    throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setMultithreaded").getMessage());
};


/** The application can determine from the results of this
	 * method which optional features, and which query languages 
	 * are supported by the JDO implementation.
	 * <P>Each supported JDO optional feature is represented by a
	 * String with one of the following values:
	 *
	 * <P>javax.jdo.option.TransientTransactional
	 * <P>javax.jdo.option.NontransactionalRead
	 * <P>javax.jdo.option.NontransactionalWrite
	 * <P>javax.jdo.option.RetainValues
	 * <P>javax.jdo.option.Optimistic
	 * <P>javax.jdo.option.ApplicationIdentity
	 * <P>javax.jdo.option.DatastoreIdentity
	 * <P>javax.jdo.option.NonDatastoreIdentity
	 * <P>javax.jdo.option.ArrayList
	 * <P>javax.jdo.option.HashMap
	 * <P>javax.jdo.option.Hashtable
	 * <P>javax.jdo.option.LinkedList
	 * <P>javax.jdo.option.TreeMap
	 * <P>javax.jdo.option.TreeSet
	 * <P>javax.jdo.option.Vector
	 * <P>javax.jdo.option.Map
	 * <P>javax.jdo.option.List
	 * <P>javax.jdo.option.Array  
	 * <P>javax.jdo.option.NullCollection  
	 *
	 *<P>The standard JDO query language is represented by a String:
	 *<P>javax.jdo.query.JDOQL   
	 * @return the List of String representing the supported Options
	 */    
	public Collection supportedOptions() {
		ArrayList options = new ArrayList();
		options.add("javax.jdo.option.NontransactionalRead");
		//options.add("javax.jdo.option.NontransactionalWrite");
		options.add("javax.jdo.option.ArrayList");
		options.add("javax.jdo.option.HashMap");
		options.add("javax.jdo.option.Hashtable");
		options.add("javax.jdo.option.LinkedList");
		options.add("javax.jdo.option.ArrayList");
		options.add("javax.jdo.option.TreeMap");
		options.add("javax.jdo.option.TreeSet");
		options.add("javax.jdo.option.Vector");
		options.add("javax.jdo.option.Map");
		options.add("javax.jdo.option.List");
		options.add("javax.jdo.option.Array");
		return options;
	}}

