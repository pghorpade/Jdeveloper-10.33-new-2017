// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

import java.util.*;
import javax.jdo.*;
import oracle.toplink.queryframework.*;

/**
 * PUBLIC:<p>
 * JDO wrapper for TopLink query results.
 * JDO:<p>
 * Instances of the Extent class represent the entire collection
 * of instances in the data store of the candidate class
 * possibly including its subclasses.
 * <P>The Extent instance has two possible uses:
 * <ol>
 * <li>to iterate all instances in of a particular class 
 * <li>to execute a Query in the data store over all instances
 * of a particular class
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview. 
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */

public class JDOExtent implements Extent {


/**
 * An Extent contains all instances of a particular Class in the data
 * store; this method returns the Class of the instances
 * @return the Class of instances of this Extent
 */
public Class getCandidateClass() {
	return extentClass;
}
/**
 * An Extent is managed by a PersistenceManager; this method gives access
 * to the owning PersistenceManager.
 * @return the owning PersistenceManager
 */
public PersistenceManager getPersistenceManager() {
	return manager;
}
/**
 * Returns whether this Extent was defined to contain subclasses.
 * @return true if this Extent was defined to contain instances
 * that are of a subclass type
 */
public boolean hasSubclasses() {
	return shouldReadSubclasses;
}

	protected Class extentClass;	protected JDOPersistenceManager manager;	protected Set openCursors;	protected boolean shouldReadSubclasses;
/**
 * INTERNAL: Create a new Extent.
 */
public JDOExtent(JDOPersistenceManager manager, Class extentClass, boolean shouldReadSubclasses) {
	this.manager = manager;
	this.shouldReadSubclasses = shouldReadSubclasses;
	this.extentClass = extentClass;
	this.openCursors = new HashSet(10);
}
/**
 * Close an Iterator associated with this Extent instance.  Iterators closed
 * by this method will return false to hasNext() and will throw
 * NoSuchElementException on next().  The Extent instance can still be used
 * as a parameter of Query.setExtent, and to get an Iterator.
 * @param it an iterator obtained by the method iterator() on this Extent instance.
 */
public void close (Iterator iterator) {
	getOpenCursors().remove(iterator);
	((ScrollableCursor) iterator).close();	
}
/**
 * Close all Iterators associated with this Extent instance.  Iterators closed
 * by this method will return false to hasNext() and will throw
 * NoSuchElementException on next().  The Extent instance can still be used
 * as a parameter of Query.setExtent, and to get an Iterator.
 */    
public void closeAll() {
	for (Iterator iterator = getOpenCursors().iterator(); iterator.hasNext(); ) {
		close((Iterator) iterator.next());
	}
}
/**
 * Return the JDOPersistenceManager.
 */

public JDOPersistenceManager getManager() {
	return manager;
}
/**
 * Return the open scrollable cursors on this extent.
 */
public Set getOpenCursors() {
	return openCursors;
}
/**
 * Execute a read all query and return a scrollable cursor.<p>
 * JDO:<p>
 * Returns an iterator over all the instances in the Extent.
 * @return an iterator over all instances in the Extent
 */
public Iterator iterator() {
	ReadAllQuery query = new ReadAllQuery(extentClass);
	query.useScrollableCursor();
	Iterator iterator = (Iterator) getManager().getActiveSession().executeQuery(query);
	getOpenCursors().add(iterator);
	return iterator;
}protected void setManager(JDOPersistenceManager manager) {
	this.manager = manager;
}protected void setOpenCursors(Set newOpenCursors) {
	openCursors = newOpenCursors;
}protected void setPersistenceManager(JDOPersistenceManager manager) {
	this.manager = manager;
}}

