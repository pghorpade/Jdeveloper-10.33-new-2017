// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jdo;

import javax.jdo.*;
import oracle.toplink.sessions.*;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.exceptions.JDOException;

/**
 * JDO wrapper for a TopLink unit of work.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  TopLink will no longer offer this JDO preview.
 *          Please refer to the best practices content on OTN for recommended abstraction layer development.
 */
public class JDOTransaction implements Transaction {
    protected JDOPersistenceManager manager;
    protected boolean nontransactionalRead;
    protected UnitOfWork unitOfWork;

    /**
     * INTERNAL:
     * Create a new transaction.
     * Transactions should be accessed through currentTransaction.
     */
    public JDOTransaction(JDOPersistenceManager manager) {
        this.manager = manager;
        setNontransactionalRead(manager.getNontransactionalRead());
    }

    /**
     * Begin a transaction.  The type of transaction is determined by the
     * setting of the Optimistic flag.
     * @see #setOptimistic
     * @see #getOptimistic
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is already active.
     */
    public synchronized void begin() {
        if (isActive() && !getNontransactionalRead()) {
            throw new JDOUserException(JDOException.transactionIsAlreadyActive().getMessage());
        }
        if (getUnitOfWork() == null) {
            setUnitOfWork(this.manager.getSession().acquireUnitOfWork());
        } else {
            // If in transactional mode then always in a unit of work to maintain clone identity and avoid registeration.
            if (!getNontransactionalRead()) {
                return;
            }
            setUnitOfWork(getUnitOfWork().acquireUnitOfWork());
        }
    }

    /**
     * Commit the current transaction.
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is not active.
     */
    public synchronized void commit() {
        if (!isActive()) {
            throw new JDOUserException(JDOException.transactionIsNotActive().getMessage());
        }

        // If not in non transactional read mode then always in a unit of work to maintain clone identity and avoid registeration.
        if (!getNontransactionalRead()) {
            getUnitOfWork().commitAndResume();
            return;
        }

        getUnitOfWork().commit();
        if (getUnitOfWork().isNestedUnitOfWork()) {
            setUnitOfWork((UnitOfWork)getUnitOfWork().getParent());
        } else {
            setUnitOfWork(null);
        }
    }

    /**
     * When the nontransactional read flag is set to false the PersistenceManager has a single TopLink UnitOfWork
     * associated with it.  All objects are accessed in the context of this unit of work to preserve clone identity.
     * When the nontransactional read flag is set to true, the PersistenceManager only acquires a unit of work on the begin of the transaction
     * and objects that are to be changed must be first reigstered into the transaction context through re-querying them, or through the getObjectById
     * This enables read to occur on the shared object cache, without the overhead of cloning and change tracking,
     * it also allows for nested units of work to be supported.
     * <p>
     * JDO:
     * If true, allows persistent instances to be read without
     * a transaction active.
     * @return the value of the nontransactionalRead property
     */
    public boolean getNontransactionalRead() {
        return nontransactionalRead;
    }

    /**
     * If true, allows persistent instances to be written without
     * a transaction active.
     * @return the value of the nontransactionalWrite property
     */
    public boolean getNontransactionalWrite() {
        return true;
    }

    /**
     * Optimistic transactions do not hold data store locks until commit time.
     * @return the value of the Optimistic property.
     */
    public boolean getOptimistic() {
        return false;
    }

    /**
     * The Tranansaction instance is always associated with exactly one
     * PersistenceManager.
     *
     * @return the PersistenceManager for this Transaction instance
     */
    public PersistenceManager getPersistenceManager() {
        return manager;
    }

    /**
     * If true, at commit time instances retain their field values.
     * @return the value of the retainValues property
     */
    public boolean getRetainValues() {
        return false;
    }

    /**
     * The user-specified Synchronization instance for this Transaction instance.
     * @return the user-specified Synchronization instance.
     */
    public javax.transaction.Synchronization getSynchronization() {
        return null;
    }

    /**
     * Returns whether there is a transaction currently active.
     * @return true if the transaction is active.
     */
    public boolean isActive() {
        if (getUnitOfWork() == null) {
            return false;
        }
        return getUnitOfWork().isActive();
    }

    /**
     * Roll back the current transaction.
     * @throws JDOUserException if transactions are managed by a container
     * in the managed environment, or if the transaction is not active.
     */
    public void rollback() {
        if (!isActive()) {
            throw new JDOUserException(JDOException.transactionIsNotActive().getMessage());
        }

        // If not in non transactional read mode then always in a unit of work to maintain clone identity and avoid registeration.
        if (!getNontransactionalRead()) {
            getUnitOfWork().revertAndResume();
            return;
        }

        getUnitOfWork().release();
        if (getUnitOfWork().isNestedUnitOfWork()) {
            setUnitOfWork((UnitOfWork)getUnitOfWork().getParent());
        } else {
            setUnitOfWork(null);
        }
    }

    /**
     * When the nontransactional read flag is set to false the PersistenceManager has a single TopLink UnitOfWork
     * associated with it.  All objects are accessed in the context of this unit of work to preserve clone identity.
     * When the nontransactional read flag is set to true, the current transaction is inactivated and the current UnitOfWork
     * is released, the PersistenceManager only acquires a unit of work on the begin of the transaction
     * and objects that are to be changed must be first reigstered into the transaction context through re-querying them, or
     * through the getObjectById. This enables read to occur on the shared object cache, without the overhead of cloning and
     * change tracking, it also allows for nested units of work to be supported.
     * NOTE:
     * <p>
     * JDO:
     * If true, allow persistent instances to be read without
     * a transaction active.
     * If an implementation does not support this option, a
     * JDOUnsupportedOptionException is thrown.
     * @param nontransactionalRead the value of the nontransactionalRead property
     */
    public void setNontransactionalRead(boolean nontransactionalRead) {
        this.nontransactionalRead = nontransactionalRead;
        if (unitOfWork == null) {
            return;
        }

        // commit the current transaction
        if (nontransactionalRead) {
            while (unitOfWork.isActive()) {
                unitOfWork.release();
                if (unitOfWork.isNestedUnitOfWork()) {
                    unitOfWork = (UnitOfWork)unitOfWork.getParent();
                }
            }
            unitOfWork = null;
        }
    }

    /**
     * If true, allow persistent instances to be written without
     * a transaction active.
     * If an implementation does not support this option, a
     * JDOUnsupportedOptionException is thrown.
     * @param nontransactionalWrite the value of the nontransactionalRead property
     */
    public void setNontransactionalWrite(boolean arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setNontransactionalWrite").getMessage());
    }

    /**
     * Optimistic transactions do not hold data store locks until commit time.
     * If an implementation does not support this option, a
     * JDOUnsupportedOptionException is thrown.
     * @param optimistic the value of the Optimistic flag.
     */
    public void setOptimistic(boolean arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setOptimistic").getMessage());
    }

    /**
     * If true, at commit instances retain their values and the instances
     * transition to persistent-nontransactional.
     * If an implementation does not support this option, a
     * JDOUnsupportedOptionException is thrown.
     * @param retainValues the value of the retainValues property
     */
    public void setRetainValues(boolean arg1) {
        throw new JDOUnsupportedOptionException(ValidationException.operationNotSupported("setRetainValues").getMessage());
    }

    /**
     * The user can specify a Synchronization instance to be notified on
     * transaction completions.  The beforeCompletion method is called prior
     * to flushing instances to the data store.
     *
     * <P>The afterCompletion method is called after performing state
     * transitions of persistent and transactional instances, following
     * the data store commit or rollback operation.
     * <P>Only one Synchronization instance can be registered with the
     * Transaction. If the application requires more than one instance to
     * receive synchronization callbacks, then the single application instance
     * is responsible for managing them, and forwarding callbacks to them.
     * @param sync the Synchronization instance to be notified; null for none
     */
    public void setSynchronization(javax.transaction.Synchronization synchronizationListener) {
        final javax.transaction.Synchronization synchronization = synchronizationListener;
        getUnitOfWork().getEventManager().addListener(new SessionEventAdapter() {
                public void preCommitUnitOfWork(SessionEvent event) {
                    synchronization.beforeCompletion();
                }

                public void postCommitUnitOfWork(SessionEvent event) {
                    synchronization.afterCompletion(1);
                }
            });
    }

    /**
     * Return the associated TopLink unit of work.
     */
    public UnitOfWork getUnitOfWork() {
        return unitOfWork;
    }

    /**
     * Set the associate unit of work.
     */
    public void setUnitOfWork(UnitOfWork newUnitOfWork) {
        unitOfWork = newUnitOfWork;
    }
}