// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.remote;

import java.util.Hashtable;
import javax.naming.*;
import oracle.toplink.logging.SessionLog;
import oracle.toplink.sessions.Session;
import oracle.toplink.exceptions.*;

/**
 * <p>
 * <b>Purpose</b>:To Provide a framework for offering customers the ability to automatically
 * connect multiple sessions for synchrnization.
 * <p>
 * <b>Descripton</b>:This thread object will place a remote dispatcher in the specified JNDI space.
 * it will also monitor the specified multicast socket to allow other sessions to connect.
 *
 * @author Gordon Yorke
 * @see oracle.toplink.remote.CacheSynchronizationManager
 * @see oracle.toplink.remote.AbstractClusteringService
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.remotecommand.TransportManager}
 */
public abstract class AbstractJNDIClusteringService extends AbstractClusteringService {

    /**
     * Holds the reference to the context to be used to register the dispatcher object
     */
    protected Context localContext;
    protected String userName;
    protected String password;
    protected Hashtable contextProperties;

    /**
     * PUBLIC:
     * Creates an AbstractJNDIClusteringService
     * @param jndiHostName The host name of the JNDI service.
     */
    public AbstractJNDIClusteringService(Session session) {
        this(DEFAULT_MULTICAST_GROUP, DEFAULT_MULTICAST_PORT, session);
    }

    /**
     * ADVANCED:
     *     Creates an AbstractJNDIClusteringService
     * @param multicastAddress The address of the multicast group
     * @param multicastPort The port the multicast group is listening on.
     */
    public AbstractJNDIClusteringService(String multicastAddress, int multicastPort, Session session) {
        super(multicastAddress, multicastPort, session);
    }

    /**
     * INTERNAL:
     * Returns the active JNDI Context to store the remote service in.
     */
    public Context getLocalContext() {
        if (this.localContext == null) {
            ((oracle.toplink.publicinterface.Session)getSession()).log(SessionLog.FINEST, SessionLog.PROPAGATION, "getting_local_initial_context");
            this.localContext = getContext(getInitialContextProperties());
        }
        return this.localContext;
    }

    /**
     * ADVANCED:
     * Returns the active JNDI Context to store the remote service in
     * @deprecated Since 4.5
     */
    public Context getContext(String jndiHostURL) {
        try {
            Hashtable properties = new Hashtable(2);

            //need to add context properties like context factory name
            properties.put(Context.PROVIDER_URL, jndiHostURL);
            return new javax.naming.InitialContext(properties);
        } catch (NamingException exception) {
            getSession().handleException(SynchronizationException.errorLookingUpController(jndiHostURL, exception));
        }
        return null;
    }

    /**
     * INTERNAL:
     * Returns the active JNDI Context to store the remote service in
     */
    public Context getContext(Hashtable properties) {
        try {
            return new javax.naming.InitialContext(properties);
        } catch (NamingException exception) {
            getSession().handleException(SynchronizationException.errorLookingUpController(properties.toString(), exception));
        }
        return null;
    }

    /**
     * Sets the active JNDI Context to store the remote service in.
      */
    public void setContext(Context context) {
        this.localContext = context;
    }

    public void setLocalHostURL(String url) {
        this.localHostURL = url;
        // For bug 2700794 must insure this is added to initialContextProperties.
        this.getInitialContextProperties().put(Context.PROVIDER_URL, url);
    }

    /**
     * ADVANCED:
     * This method allows the user to get the Context properties that will be used to create the initial context.
     */
    public Hashtable getInitialContextProperties() {
        if (this.contextProperties == null) {
            this.contextProperties = new Hashtable(2);
        }
        return this.contextProperties;
    }

    /**
     * ADVANCED:
     * This method allows the user to set the Context properties for creating the initial context
     * for a JNDI connection if the properties have not allready been set globally.  Usually if
     * TopLink is running within the same VM as this attribute is not required.  Use this method if
     * TopLink is having problems connecting to the JNDI Service, or JMS Service
     */
    public void setInitialContextProperties(Hashtable properties) {
        this.contextProperties = properties;
    }

    /**
     * ADVANCED:
     * returns the Username if one is required to access the JNDI service
     */
    public String getUserName() {
        return this.userName;
    }

    /**
     * Sets the Username if one is required to access the JNDI service
     */
    public void setUserName(String userName) {
        this.userName = userName;
        getInitialContextProperties().put(Context.SECURITY_PRINCIPAL, userName);
    }

    /**
     * ADVANCED:
     * returns the Username if one is required to access the JNDI service
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * Sets the Password if one is required to access the JNDI service
     */
    public void setPassword(String password) {
        this.password = password;
        getInitialContextProperties().put(Context.SECURITY_CREDENTIALS, password);
    }

    /**
     * ADVANCED:
     * Use this method to set the Initial Conext Factory for accessing JNDI.
     * This method is only required if the user is having difficulties getting TopLink
     * to connect to JNDI or JMS
     */
    public void setInitialContextFactoryName(String initialContextFactory) {
        getInitialContextProperties().put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
    }
}