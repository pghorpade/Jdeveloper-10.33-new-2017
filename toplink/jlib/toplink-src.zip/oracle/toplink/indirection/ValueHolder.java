// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.indirection;

import java.io.Serializable;

/**
 * <p>
 * <b>Purpose</b>: Act as a place holder for a variable that required a value holder interface.
 * This class should be used to initialze an objects attributes that are using indirection is their mappings.
 */
public class ValueHolder implements ValueHolderInterface, Cloneable, Serializable {

    /**
     * Stores the wrapped object.
     */
    protected Object value;

    /**
     * PUBLIC:
     * Initialize the holder.
     */
    public ValueHolder() {
        super();
    }

    /**
     * PUBLIC:
     * Initialize the holder with an object.
     */
    public ValueHolder(Object value) {
        this.value = value;
    }

    /**
     * INTERNAL:
     */
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException exception) {
            ;
        }

        return null;
    }

    /**
     * PUBLIC:
     * Return the wrapped object.
     */
    public synchronized Object getValue() {
        return value;
    }

    /**
     * PUBLIC:
     * Return a boolean indicating whether the
     * wrapped object has been set or not.
     */
    public boolean isInstantiated() {
        // Always return true since we consider 
        // null to be a valid wrapped object.
        return true;
    }

    /**
     * PUBLIC:
     * Set the wrapped object.
     */
    public void setValue(Object value) {
        this.value = value;
    }

    /**
     * INTERNAL:
     */
    public String toString() {
        if (getValue() == null) {
            return "{" + null + "}";
        }
        return "{" + getValue().toString() + "}";
    }
}