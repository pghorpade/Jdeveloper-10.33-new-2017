// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ejb.cmp3.persistence;

import java.util.Iterator;
import oracle.toplink.ox.XMLDescriptor;
import oracle.toplink.ox.NamespaceResolver;
import oracle.toplink.ox.mappings.XMLDirectMapping;
import oracle.toplink.ox.mappings.XMLCompositeDirectCollectionMapping;
import oracle.toplink.ox.mappings.XMLCompositeCollectionMapping;
import oracle.toplink.ox.schema.XMLSchemaClassPathReference;
import oracle.toplink.publicinterface.Descriptor;

public class PersistenceProject extends oracle.toplink.sessions.Project {
    public PersistenceProject() {
        setName("persistenceProject");
        addDescriptor(buildPersistenceInfoDescriptor());
        addDescriptor(buildPropertyDescriptor());

        // Set the namespaces on all descriptors.
        NamespaceResolver namespaceResolver = new NamespaceResolver();
        namespaceResolver.put("xsi", "http://www.w3.org/2001/XMLSchema-instance");
        namespaceResolver.put("xsd", "http://www.w3.org/2001/XMLSchema");

        for (Iterator descriptors = getDescriptors().values().iterator(); descriptors.hasNext();) {
            XMLDescriptor descriptor = (XMLDescriptor)descriptors.next();
            descriptor.setNamespaceResolver(namespaceResolver);
        }
    }

    public Descriptor buildPersistenceInfoDescriptor() {
        XMLDescriptor descriptor = new XMLDescriptor();

        descriptor.setDefaultRootElement("entity-manager");
        descriptor.setJavaClass(PersistenceInfo.class);
        descriptor.setSchemaReference(new XMLSchemaClassPathReference("xsd/persistence.xsd"));

        XMLDirectMapping entityManagerNameMapping = new XMLDirectMapping();
        entityManagerNameMapping.setAttributeName("entityManagerName");
        entityManagerNameMapping.setXPath("name/text()");
        entityManagerNameMapping.setSetMethodName("setEntityManagerName");
        entityManagerNameMapping.setGetMethodName("getEntityManagerName");
        descriptor.addMapping(entityManagerNameMapping);

        XMLDirectMapping persistenceProviderClassNameMapping = new XMLDirectMapping();
        persistenceProviderClassNameMapping.setAttributeName("persistenceProviderClassName");
        persistenceProviderClassNameMapping.setXPath("provider/text()");
        persistenceProviderClassNameMapping.setSetMethodName("setPersistenceProviderClassName");
        persistenceProviderClassNameMapping.setGetMethodName("getPersistenceProviderClassName");
        descriptor.addMapping(persistenceProviderClassNameMapping);

        XMLDirectMapping jtaDataSourceJndiNameMapping = new XMLDirectMapping();
        jtaDataSourceJndiNameMapping.setAttributeName("jtaDataSourceJndiName");
        jtaDataSourceJndiNameMapping.setXPath("datasource/text()");
        jtaDataSourceJndiNameMapping.setSetMethodName("setJtaDataSourceJndiName");
        jtaDataSourceJndiNameMapping.setGetMethodName("getJtaDataSourceJndiName");
        descriptor.addMapping(jtaDataSourceJndiNameMapping);

        XMLDirectMapping nonJtaDataSourceJndiNameMapping = new XMLDirectMapping();
        nonJtaDataSourceJndiNameMapping.setAttributeName("nonJtaDataSourceJndiName");
        nonJtaDataSourceJndiNameMapping.setXPath("non-jta-datasource/text()");
        nonJtaDataSourceJndiNameMapping.setSetMethodName("setNonJtaDataSourceJndiName");
        nonJtaDataSourceJndiNameMapping.setGetMethodName("getNonJtaDataSourceJndiName");
        descriptor.addMapping(nonJtaDataSourceJndiNameMapping);

        XMLCompositeDirectCollectionMapping mappingFilesMapping = new XMLCompositeDirectCollectionMapping();
        mappingFilesMapping.setAttributeName("mappingFiles");
        mappingFilesMapping.setXPath("mapping-file/text()");
        mappingFilesMapping.setSetMethodName("setMappingFileNames");
        mappingFilesMapping.setGetMethodName("getMappingFileNames");
        descriptor.addMapping(mappingFilesMapping);

        XMLCompositeDirectCollectionMapping jarFilesMapping = new XMLCompositeDirectCollectionMapping();
        jarFilesMapping.setAttributeName("jarFiles");
        jarFilesMapping.setXPath("jar-file/text()");
        jarFilesMapping.setSetMethodName("setJarFiles");
        jarFilesMapping.setGetMethodName("getJarFiles");
        descriptor.addMapping(jarFilesMapping);

        XMLCompositeDirectCollectionMapping entityClassNamesMapping = new XMLCompositeDirectCollectionMapping();
        entityClassNamesMapping.setAttributeName("entityClassNames");
        entityClassNamesMapping.setXPath("class/text()");
        entityClassNamesMapping.setSetMethodName("setEntityClassNames");
        entityClassNamesMapping.setGetMethodName("getEntityClassNames");
        descriptor.addMapping(entityClassNamesMapping);

        XMLCompositeCollectionMapping properties = new XMLCompositeCollectionMapping();
        properties.setReferenceClass(Property.class);
        properties.setAttributeName("propertiesFromXML");
        properties.setXPath("properties/property");
        properties.setSetMethodName("setPropertiesFromXML");
        properties.setGetMethodName("getPropertiesFromXML");
        descriptor.addMapping(properties);

        return descriptor;
    }

    public Descriptor buildPropertyDescriptor() {
        XMLDescriptor descriptor = new XMLDescriptor();
        descriptor.setJavaClass(Property.class);

        XMLDirectMapping nameMapping = new XMLDirectMapping();
        nameMapping.setAttributeName("name");
        nameMapping.setXPath("@name");
        descriptor.addMapping(nameMapping);

        XMLDirectMapping valueMapping = new XMLDirectMapping();
        valueMapping.setAttributeName("value");
        valueMapping.setXPath("@value");
        descriptor.addMapping(valueMapping);

        return descriptor;
    }
}