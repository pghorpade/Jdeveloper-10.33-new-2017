// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ejb.cmp3.persistence;


/**
 * INTERNAL:
 * Interim holder for a property until DirectMapMapping is available on OX.
 * This is used by PersistenceInfo to hold properties before converting them
 * to an actual properties object
 */
public class Property {
    public String name;
    public String value;
}