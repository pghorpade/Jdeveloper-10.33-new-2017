// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ejb.cmp3.persistence;

import java.io.FileInputStream;
import java.util.*;
import java.io.InputStream;
import java.net.URL;
import javax.sql.DataSource;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.ox.*;

/**
 * INTERNAL:
 * Implementation of the EJB 3.0 spec-required PersistenceInfo class
 */
public class PersistenceInfo {
    protected String entityManagerName;
    protected String persistenceProviderClassName;
    protected String jtaDataSourceJndiName;
    protected String nonJtaDataSourceJndiName;
    protected List mappingFiles;
    protected List jarFiles;
    protected List entityClassNames;
    protected List propertiesFromXML;
    protected Properties properties;

    // Extra stuff
    protected ClassLoader loader;
    protected URL persistenceXmlFileUrl;
    protected URL entityMappingsXmlFileUrl;

    public PersistenceInfo() {
        mappingFiles = new Vector();
        jarFiles = new Vector();
        entityClassNames = new Vector();
        propertiesFromXML = new Vector();
    }

    /**
     * INTERNAL:
     * Read a PersistenceInfo from an XML file.
     */
    public static PersistenceInfo getPersistenceInfo(InputStream readStream) {
        XMLContext context = new XMLContext(new PersistenceProject());
        XMLUnmarshaller xmlUnmarshaller = context.createUnmarshaller();

        PersistenceInfo info = (PersistenceInfo)xmlUnmarshaller.unmarshal(readStream);

        if (!info.getJarFiles().isEmpty()) {
            throw ValidationException.jarFilesInPersistenceXmlNotSupported();
        }

        return info;
    }

    /**
    * @return The name of the EntityManager that is being created.
    * Corresponds to the <name> element in persistence.xml
    */
    public String getEntityManagerName() {
        return entityManagerName;
    }

    /**
    * @returns The name of the persistence provider implementation
    * class.
    * Corresponds to the <provider> element in persistence.xml
    */
    public String getPersistenceProviderClassName() {
        return persistenceProviderClassName;
    }

    /**
    * @return the JTA-enabled data source to be used by the
    * persistence provider.
    * The data source corresponds to the named <jta-data-source>
    * element in persistence.xml
    */
    public DataSource getJtaDataSource() {
        return null;
    }

    /**
     * Get the JNDI name of the JTA datasource
     */
    public String getJtaDataSourceJndiName() {
        return jtaDataSourceJndiName;
    }

    /**
    * @return The non-JTA-enabled data source to be used by the
    * persistence provider when outside the container, or inside
    * the container when accessing data outside the global
    * transaction.
    * The data source corresponds to the named <non-jta-data-source>
    * element in persistence.xml
    */
    public DataSource getNonJtaDataSource() {
        return null;
    }

    /**
     * Set the JNDI name of the JTA datasource
     */
    public String getNonJtaDataSourceJndiName() {
        return nonJtaDataSourceJndiName;
    }

    /**
    * @return The list of mapping file names that the persistence
    * provider must load to determine the mappings for the entity
    * classes. The mapping files must be in the standard XML
    * mapping format, be uniquely named and be resource-loadable
    * from the application classpath. This list will not include
    * the entity-mappings.xml file if one was specified.
    * Each mapping file name corresponds to a <mapping-file>
    * element in persistence.xml
    */
    public List getMappingFileNames() {
        return mappingFiles;
    }

    /**
    * @return The list of JAR file URLs that the persistence
    * provider must look in to find the entity classes that must
    * be managed by EntityManagers of this name. The persistence
    J2EE Container Deployment Enterprise JavaBeans 3.0, Public Draft Container and Provider Contracts for Deploy-
    Sun Microsystems, Inc.
    * archive jar itself will always be the last entry in the
    * list. Each jar file URL corresponds to a named <jar-file>
    * element in persistence.xml
    */
    public List getJarFiles() {
        return jarFiles;
    }

    /**
    * @return The list of class names that the persistence
    * provider must inspect to see if it should add it to its
    * set of managed entity classes that must be managed by
    * EntityManagers of this name.
    * Each class name corresponds to a named <class> element
    * in persistence.xml
    */
    public List getEntityClassNames() {
        return entityClassNames;
    }

    /**
    * @return Properties object that may contain vendor-specific
    * properties contained in the persistence.xml file.
    * Each property corresponds to a <property> element in
    *persistence.xml
    */
    public Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            Iterator i = propertiesFromXML.iterator();
            while (i.hasNext()) {
                Property p = (Property)i.next();
                properties.put(p.name, p.value);
            }
        }
        return properties;
    }

    /**
     * INTERNAL
     * Get a list containing the properties read from XML
     * Since TopLink currently will not read a direct map from XML
     * this datastructure is used in reading from XML before copying the
     * values to the properties variable
     */
    public List getPropertiesFromXML() {
        return propertiesFromXML;
    }

    /**
    * @return ClassLoader that the provider may use to load any
    * classes, resources, or open URLs.
    */
    public ClassLoader getClassLoader() {
        return null;
    }

    /**
    * @return URL object that points to the persistence.xml
    * file; useful for providers that may need to re-read the
    * persistence.xml file. If no persistence.xml
    * file is present in the persistence archive, null is
    * returned.
    */
    public URL getPersistenceXmlFileUrl() {
        return null;
    }

    /**
    * @return URL object that points to the entity-mappings.xml
    * file.
    * If no entity-mappings.xml file was present in the persistence
    * archive,null is returned.
    */
    public URL getEntityMappingsXmlFileUrl() {
        return null;
    }

    public void setEntityManagerName(String entityManagerName) {
        this.entityManagerName = entityManagerName;
    }

    public void setPersistenceProviderClassName(String persistenceProviderClassName) {
        this.persistenceProviderClassName = persistenceProviderClassName;
    }

    public void setJtaDataSource(DataSource jtaDataSource) {
        //this.jtaDataSource = jtaDataSource;
    }

    public void setJtaDataSourceJndiName(String jtaDataSourceJndiName) {
        this.jtaDataSourceJndiName = jtaDataSourceJndiName;
    }

    public void setNonJtaDataSource(DataSource nonJtaDataSource) {
        //this.nonJtaDataSource = nonJtaDataSource;
    }

    public void setNonJtaDataSourceJndiName(String nonJtaDataSourceJndiName) {
        this.nonJtaDataSourceJndiName = nonJtaDataSourceJndiName;
    }

    public void setMappingFileNames(List mappingFiles) {
        this.mappingFiles = mappingFiles;
    }

    public void setJarFiles(List jarFiles) {
        this.jarFiles = jarFiles;
    }

    public void setEntityClassNames(List entityClassNames) {
        this.entityClassNames = entityClassNames;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public void setPropertiesFromXML(List propertiesFromXML) {
        this.propertiesFromXML = propertiesFromXML;
    }

    public void setClassLoader(ClassLoader classLoader) {
        this.loader = classLoader;
    }

    public void setPersistenceXmlFileUrl(URL persistenceXmlFileUrl) {
        this.persistenceXmlFileUrl = persistenceXmlFileUrl;
    }

    public void setEntityMappingsXmlFileUrl(URL entityMappingsXmlFileUrl) {
        this.entityMappingsXmlFileUrl = entityMappingsXmlFileUrl;
    }
}