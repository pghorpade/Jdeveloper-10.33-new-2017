// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ejb.cmp3.jdk14;

import java.util.Map;

import oracle.toplink.internal.ejb.cmp3.jdk14.EntityManagerFactoryImpl;
import oracle.toplink.internal.ejb.cmp3.jdk14.EntityContainer;
import oracle.toplink.sessions.entitymanager.EntityManagerFactory;

public class EntityManagerFactoryProvider 
        extends oracle.toplink.ejb.cmp3.base.EntityManagerFactoryProvider
        implements oracle.toplink.sessions.entitymanager.spi.EntityManagerFactoryProvider 
{

    public EntityManagerFactoryProvider() {
        super();
    }
    
    /**
	 * @see {@link Persistence#createEntityManagerFactory}.
	 */
	public EntityManagerFactory createEntityManagerFactory(Map m){
        return new EntityManagerFactoryImpl(getServerSession(m));
    }

    protected boolean initializeFromMain(Map m) throws Exception {
        return EntityContainer.initializeFromMain(EntityContainer.class, m);        
    }
}
