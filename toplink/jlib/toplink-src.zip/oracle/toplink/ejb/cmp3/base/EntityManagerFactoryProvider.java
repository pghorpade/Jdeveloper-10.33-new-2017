// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ejb.cmp3.base;

import java.util.*;
import java.net.URL;
import java.io.InputStream;
import oracle.toplink.exceptions.EntityManagerSetupException;
import oracle.toplink.threetier.ServerSession;
import oracle.toplink.internal.ejb.cmp3.base.EntityContainer;

public abstract class EntityManagerFactoryProvider {
    public static final String SESSION_NAME_PROPERTY = "toplink.session.name";
    public static final String EJB30_SESSIONS_XML_NAME_PROPERTY = "ejb30.sessions.xml.name";
    public static final String JDBC_DRIVER_PROPERTY = "jdbc.driver";
    public static final String JDBC_CONNECTION_STRING_PROPERTY = "jdbc.connection.string";
    public static final String JDBC_USER_PROPERTY = "jdbc.user";
    public static final String JDBC_PASSWORD_PROPERTY = "jdbc.password";
    public static final String DATASOURCE_NAME_PROPERTY = "datasource.name";
    public static final String DATASOURCE_JNDI_NAME_PROPERTY = "datasource.jndi.name";
    public static final String USE_TOPLINK_JTA_PROPERTY = "use.toplink.jta";
    public static final String TOPLINK_PLATFORM_PROPERTY = "toplink.platform.class.name";
    public static final String TOPLINK_SERVER_PLATFORM_PROPERTY = "toplink.server.platform.class.name";
    public static final String TOPLINK_EXTERNAL_TRANSACTION_CONTROLLER_PROPERTY = "toplink.external.transaction.controller.class.name";
    public static final String CONFIG_FACTORY_NAME_PROPERTY = "java.persistence.setup.config";
    public static final String WRITE_DEPLOYMENT_XML_PROPERTY = "toplink.persistence.deployment.file";

    protected abstract boolean initializeFromMain(Map m) throws Exception;

    public EntityManagerFactoryProvider() {
    }

    /**
     * @see {@link Persistence#createEntityManagerFactory}.
     */
    protected ServerSession getServerSession(Map m) {
        EntityContainer container = EntityContainer.getEntityContainer();

        if (container == null) {
            try {
                if (!initializeFromMain(m)) {
                    throw EntityManagerSetupException.errorInSetupOfEM();
                }
            } catch (Exception exception) {
                throw EntityManagerSetupException.exceptionInSetupOfEM(exception);
            }
            container = EntityContainer.getEntityContainer();
        }
        return container.getServerSession(m);
    }

    public static String getConfigProperty(String propertyName, Map providedProperties) {
        String property = (String)providedProperties.get(propertyName);
        if (property == null) {
            property = System.getProperty(propertyName);
        }
        return property;
    }
}