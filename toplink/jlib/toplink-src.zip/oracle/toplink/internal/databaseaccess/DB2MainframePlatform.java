// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.internal.databaseaccess;

import oracle.toplink.expressions.ExpressionOperator;

/**
 *    <B>Purpose</B>: Provides DB2 Mainframe specific behaviour.<P>
 *    <B>Responsibilities</B>:
 *        <UL>
 *            <LI>Specialized CONCAT syntax
 *        </UL>
 *
 * @since TopLink 3.0.3
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.platform.database.DB2MainframePlatform}
 */
public class DB2MainframePlatform extends DB2Platform {

    /**
     * Initialize any platform-specific operators
     */
    protected void initializePlatformOperators() {
        super.initializePlatformOperators();

        addOperator(ExpressionOperator.simpleLogicalNoParens(ExpressionOperator.Concat, "CONCAT"));
    }
}