// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.oraclespecific;

import oracle.toplink.internal.helper.NoConversion;

/**
 * Class used to reference NCLOB database type.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.platform.database.oracle.NClob}
 */
public class NClob implements NoConversion, Oracle9Specific {
}