// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts;

import oracle.toplink.publicinterface.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Abstract Synchronization Listener class
 *
 * <b>Description</b>: This abstract class is paired with
 * AbstractExternalTransactionController. It contains the implementation
 * logic to handle the synchronization callback notifications with respect
 * to UnitOfWork - commiting changes to the database and merging
 * clones into the parent Session.
 *
 * It also provides two abstract methods that must be overridden in
 * any sub-class. The wasTransactionCommited(int) method contains the logic that
 * checks the return status code from the afterCompletion method. Different
 * implementations of OTS/JTS have different returns codes, so this logic
 * must be 'pluggable'. The other method is rollbackGlobalTransaction() which (again)
 * must be overridden to deal with the various different ways to refer to
 * the external global 'Transaction' object and the calls to roll it back.
 *
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Handle the synchronization callback notifications
 * <li> Provide abstract methods to handle Transaction
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.AbstractSynchronizationListener}
 */
public abstract class AbstractSynchronizationListener {
    protected Session session;
    protected UnitOfWork unitOfWork;

    /**
     * Cannot use the correct 'Transaction' type here since there are
     * numerous implementations of 'Transaction' based on pre 1.0 JTS
     */
    protected Object globalTransaction;

    /**
     * Put in this flag so that if an app server swallows the exception from
     * beforeCompletion or afterCompletion we can dump it out anyway.
      */
    public static boolean dumpExceptionsFromCallbacks = false;

    /**
     * INTERNAL:
     * Return a blank instance.
     */
    public AbstractSynchronizationListener() {
        super();
    }

    protected AbstractSynchronizationListener(UnitOfWork unitOfWork, Session session, Object transaction) {
        this.session = session;
        this.unitOfWork = unitOfWork;
        this.globalTransaction = transaction;
    }

    /**
     * INTERNAL:
     * The afterCompletion method is called by the transaction
     * manager after the transaction is committed or rolled back.
     * This method executes without a transaction context.
     *
     * @param status The status of the transaction completion.
     */
    public void afterCompletion(int status) {
        UnitOfWork unitOfWork = getUnitOfWork();
        if (unitOfWork != null) {
            unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_after_completion");

            // check to see if global TX committed and
            // if the uow is in the correct state
            if (wasTransactionCommitted(status)) {
                // true=="committed"; true=="jts transaction"
                unitOfWork.afterTransaction(true, true);
                if (unitOfWork.isMergePending()) {
                    // uow in in PENDING_MERGE state, merge clones
                    try {
                        unitOfWork.mergeClonesAfterCompletion();
                    } catch (RuntimeException rtEx) {
                        // Option to dump exception stack trace
                        if (shouldDumpExceptionsFromCallbacks()) {
                            rtEx.printStackTrace();
                        }
                        throw rtEx;
                    }
                }
            } else {
                // false=="rolled back"; true=="jts transaction"
                unitOfWork.afterTransaction(false, true);
            }

            // regardless of above state, still must clean-up:
            // release uow, decrement number of outstanding uow's
            // with pending merges.
            unitOfWork.release();
            ((AbstractExternalTransactionController)getSession().getExternalTransactionController()).removeActiveUnitOfWork(this.getGlobalTransaction());

            // null out local fields so that they can be GC'd
            Session sess = getSession();// Save the session to explicitly release later (CR 4081)
            setSession(null);
            setUnitOfWork(null);
            setGlobalTransaction(null);

            /* CR 4081 - Release the session instead of waiting for GC to clean it up */
            if (sess.isClientSession()) {
                sess.release();
            }
        }
    }

    /**
     * INTERNAL:
     * This beforeCompletion method is called by the transaction
     * manager prior to the start of the transaction completion process.
     * This call is executed in the same transaction context of the caller
     * who initiates the TransactionManager.commit, or the call is executed
     * with no transaction context if Transaction.commit is used.
     */
    public void beforeCompletion() {
        UnitOfWork unitOfWork = getUnitOfWork();
        unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_before_completion");

        // only issue SQL to database if uow is alive as it may have been released, in which we need to force a rollback
        if (unitOfWork.isActive()) {
            try {
                // Must force concurrency mgrs active thread if in nested transaction.
                if (getSession().isInTransaction()) {
                    getSession().getTransactionMutex().setActiveThread(Thread.currentThread());
                }
                unitOfWork.issueSQLbeforeCompletion();
                // set state variable of uow to PENDING_MERGE
                unitOfWork.setPendingMerge();
            } catch (RuntimeException exception) {

                /* something went wrong sending SQL to the data-base;
                   tell the Global TX to rollback.
                */

                // no longer necessary as of WLS SP1
                //			notifyClientBeforeRollback(exception);
                //			rollbackGlobalTransaction();
                // Option to dump exception trace
                if (shouldDumpExceptionsFromCallbacks()) {
                    exception.printStackTrace();
                }
                throw exception;
            }
        } else {
            // if in any other state, tell the Global TX to rolback.
            rollbackGlobalTransaction();
        }
    }

    protected Object getGlobalTransaction() {
        return globalTransaction;
    }

    protected Session getSession() {
        return session;
    }

    protected UnitOfWork getUnitOfWork() {
        return unitOfWork;
    }

    /**
     * INTERNAL:
     * Return true if exceptions raised in beforeCompletion or afterCompletion
     * synchronization callbacks should be dumped (to System.err).
     *
     * @return True if exceptions should be dumped, false if they will only be thrown
     */
    public static boolean shouldDumpExceptionsFromCallbacks() {
        return dumpExceptionsFromCallbacks;
    }

    /**
     * INTERNAL:
     * Set whether exceptions raised in beforeCompletion or afterCompletion
     * synchronization callbacks should be dumped (to System.err).
     *
     * @param flag True if exceptions should be dumped, false if they should only be thrown
     */
    public static void setShouldDumpExceptionsFromCallbacks(boolean flag) {
        dumpExceptionsFromCallbacks = flag;
    }

    /**
     * INTERNAL:
     * This method must be re-written for the concrete implementations
     * of XXXSynchronizationListener as the various revisions of JTS
     * that vendors have written their JTS implementations against have
     * different ways of refering to/dealing with the 'Transaction' object
     *
     * At this level, just do nothing
     */
    public abstract void rollbackGlobalTransaction();

    protected void setGlobalTransaction(Object globalTransaction) {
        this.globalTransaction = globalTransaction;
    }

    protected void setSession(Session session) {
        this.session = session;
    }

    protected void setUnitOfWork(UnitOfWork unitOfWork) {
        this.unitOfWork = unitOfWork;
    }

    /**
     * INTERNAL:
     * Examine the status flag to see if the Transaction commited.
     *
     * This method must be re-written for the concrete implementations
     * of XXXSynchronizationListener as the various revisions of JTS
     * that vendors have written their JTS implementations against have
     * different status codes (grr!)
     *
     */
    public abstract boolean wasTransactionCommitted(int status);
}