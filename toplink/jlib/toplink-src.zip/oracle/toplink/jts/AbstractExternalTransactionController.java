// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts;

import java.util.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.sessions.ExternalTransactionController;
import oracle.toplink.exceptions.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Abstract implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registerSynchronizationListener
 * method, satisfying the ExternalTransactionController interface. In order to
 * interface to different transaction services (e.g. OMG OTS service, Java JTS
 * service, etc), the registration of a synchronization object is done in the
 * register method, which is abstract here (i.e. must be overridden in a concrete
 * sub-class).
 * It is also responsible for maintaining the unit of work for the active JTS transactions
 * and allowing it to be created and looked up.
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * <li> Allow lookup of the unit of work for the active JTS transaction.
 * </ul>
 * @see ExternalTransactionController
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.AbstractTransactionController}
 */
public abstract class AbstractExternalTransactionController implements ExternalTransactionController {
    protected Hashtable unitsOfWork;
    protected Session session;

    /**
     * INTERNAL:
     * Return a new controller.
     */
    public AbstractExternalTransactionController() {
        this.unitsOfWork = new Hashtable();
    }

    /**
     * INTERNAL:
     * Return true if there is an active unit of work for the current JTS transaction.
     */
    public boolean hasActiveUnitOfWork() {
        Object transaction = null;
        try {
            transaction = getExternalTransaction();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
        if (transaction == null) {
            return false;
        }

        return getUnitsOfWork().get(transaction) != null;
    }

    /**
     * INTERNAL:
     * Return the active unit of work for the current JTS transaction.
     */
    public UnitOfWork getActiveUnitOfWork() {
        Object transaction = null;
        try {
            transaction = getExternalTransaction();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
        if (transaction == null) {
            return null;
        }

        UnitOfWork activeUnitOfWork = (UnitOfWork)getUnitsOfWork().get(transaction);
        if (activeUnitOfWork == null) {
            activeUnitOfWork = getSession().acquireUnitOfWork();
            addUnitOfWork(transaction, activeUnitOfWork);
        }

        return activeUnitOfWork;
    }

    /**
     * INTERNAL:
     * This method gets the active external transaction.
     */
    public abstract Object getExternalTransaction() throws Exception;

    /**
     * INTERNAL:
     * Return the manager's session.
     */
    public Session getSession() {
        return session;
    }

    /**
     * INTERNAL:
     * Return the hashtable keyed on the JTS transaction value the unit of work.
     */
    public Hashtable getUnitsOfWork() {
        return unitsOfWork;
    }

    /**
     * INTERNAL:
     * This method registers the correct type of SynchronizationListener.
     */
    public abstract void register(UnitOfWork uow, Session session) throws Exception;

    /**
     * INTERNAL:
     * For the given Unit of Work and TopLink session, register an
     * implementation-specific Synchronization object with the global transaction.
     */
    public void registerSynchronizationListener(UnitOfWork unitOfWork, Session session) throws DatabaseException {
        try {
            unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_register");
            register(unitOfWork, session);
            unitOfWork.setSynchronized();
        } catch (Exception exception) {
            // could be RollbackException, SystemException doesn't really matter,
            // something is not right and user should know
            throw DatabaseException.cannotRegisterSynchronizatonListenerForUnitOfWork(exception);
        }
    }

    /**
     * INTERNAL:
     * Return the active unit of work for the current JTS transaction.
     */
    public void removeActiveUnitOfWork(Object transaction) {
        try {
            getUnitsOfWork().remove(transaction);
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * Set the manager's session.
     */
    public void setSession(Session session) {
        this.session = session;
    }

    /**
     * INTERNAL:
     * Set the units of work.
     */
    protected void setUnitsOfWork(Hashtable unitsOfWork) {
        this.unitsOfWork = unitsOfWork;
    }

    /**
     * INTERNAL:
     * Add a UnitOfWork object to the Hashtable.
     */
    protected void addUnitOfWork(Object transaction, UnitOfWork activeUnitOfWork) {
        getUnitsOfWork().put(transaction, activeUnitOfWork);
    }
}