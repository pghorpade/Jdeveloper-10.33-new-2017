// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts;

import javax.transaction.*;
import javax.naming.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.sessions.ExternalTransactionController;
import oracle.toplink.exceptions.DatabaseException;
import oracle.toplink.exceptions.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the JTS 1.0 standard.
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @see AbstractExternalTransactionController
 * @see ExternalTransactionController
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.JTATransactionController}
 */
public class JTSExternalTransactionController extends AbstractExternalTransactionController {

    /**
     * PUBLIC:
     * Return a new controller for use with a JTS 1.0 compliant driver.
     * This must be associated with the TopLink session.
     * The transaction manager must also be set on JTSSynchronizationListener
     *
     * @see JTSSynchronizationListener.setTransactionManager(javax.transaction.TransactionManager)
     * @see oracle.toplink.sessions.DatabaseSession.setExternalTransactionController(ExternalTransactionController)
     */
    public JTSExternalTransactionController() {
    }

    /**
     * INTERNAL:
     * Begin a JTS transaction if there is not one present.
     */
    public void beginTransaction(Session session) {
        try {
            // Bug 2637365: Check txn status for existence to prevent beginning a transaction when
            //              one may already be in progress (but in a state other than ACTIVE)
            if (getTransactionManager().getStatus() == Status.STATUS_NO_TRANSACTION) {
                session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_begin");
                getTransactionManager().begin();
                session.setWasJTSTransactionInternallyStarted(true);
            }
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * Commit the JTS transaction.
     */
    public void commitTransaction(Session session) {
        try {
            if (getTransactionManager().getStatus() == Status.STATUS_ACTIVE) {
                session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_commit");
                session.setWasJTSTransactionInternallyStarted(false);
                getTransactionManager().commit();
            }
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * This method gets the active external transaction.
     */
    public Object getExternalTransaction() throws Exception {
        if (getTransactionManager().getStatus() == Status.STATUS_NO_TRANSACTION) {
            return null;
        }
        return getTransactionManager().getTransaction();
    }

    /**
     * INTERNAL:
     */
    public static Object getFromJNDI(String name) {
        Context context = null;
        Object jndiObject = null;
        try {
            context = new javax.naming.InitialContext();
            jndiObject = context.lookup(name);
        } catch (NamingException exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        } finally {
            try {
                context.close();
            } catch (NamingException exception) {/* ignore */
            }
        }

        return jndiObject;
    }

    /**
     * Marks the external transaction for rollback only.
     */
    public void markTransactionForRollback() {
        try {
            getTransactionManager().setRollbackOnly();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * This method calls the JTSSynchronizationListener's static
     * 'factory' method to register a JTS 1.0 synchronization object
     * with the current 'global' (externally controller) transaction.
     *
     * @param uow oracle.toplink.publicinterface.UnitOfWork
     * @param session oracle.toplink.publicinterface.Session
     */
    public void register(UnitOfWork uow, Session session) throws Exception {
        if (getTransactionManager() == null) {
            // Transaction manager must be set on the listener
            throw DatabaseException.transactionManagerNotSetForJTSDriver();
        }

        JTSSynchronizationListener.register(uow, session);
    }

    /**
     * INTERNAL:
     * Set the JTS transaction to rollback.
     */
    public void rollbackTransaction(Session session) {
        try {
            session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_rollback");
            session.setWasJTSTransactionInternallyStarted(false);

            //BUG 2660471: Make sure there is a transaction to rollback
            if (getTransactionManager().getTransaction() == null) {
                return;
            }

            getTransactionManager().getTransaction().rollback();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * Get the transaction manager.
     *
     * @return The TransactionManager if it has been correctly set (or null if it has not been)
     */
    public TransactionManager getTransactionManager() {
        return JTSSynchronizationListener.getTransactionManager();
    }
}