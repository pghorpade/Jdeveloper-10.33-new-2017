// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts;

import javax.transaction.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.exceptions.*;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of AbstractSynchronizationListener
 * based on JTS 1.0. As such, it uses the 'proper' interfaces
 * javax.transaction.Transaction and javax.transaction.Status.
 *
 * It is important to note that this class must be statically configured with
 * an instance of a class that implements the JTS TransactionManager interface
 * so that the current transaction can be found.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.JTASynchronizationListener}
 */
public class JTSSynchronizationListener extends AbstractSynchronizationListener implements Synchronization {
    protected static TransactionManager transactionManager;
    protected static boolean shouldAlwaysBeginTransaction = false;

    public JTSSynchronizationListener(UnitOfWork unitOfWork, Session session, Object transaction) {
        super(unitOfWork, session, transaction);
    }

    /**
     * INTERNAL:
     * If using a JTS 1.0 compliant driver this must be called to give TopLink access to the transaction manager.
     * This is required because there is no standard way to lookup the transaction manager in JTS 1.0.
     */
    public static TransactionManager getTransactionManager() {
        return transactionManager;
    }

    /**
     * INTERNAL:
     * 'Factory' method used by JTSExternalTransactionController to
     * create an instance of JTSSynchronizationListener.
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        if ((getTransactionManager().getStatus() != Status.STATUS_ACTIVE) || shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        Transaction transaction = getTransactionManager().getTransaction();
        JTSSynchronizationListener listener = new JTSSynchronizationListener(unitOfWork, session, transaction);
        transaction.registerSynchronization(listener);
    }

    /**
     * INTERNAL:
     * Tell globalTx to rollback
     */
    public void rollbackGlobalTransaction() {
        try {
            ((Transaction)getGlobalTransaction()).setRollbackOnly();
        } catch (SystemException exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * REQUIRED:
     * If using a JTS 1.0 compliant driver this must be called to give TopLink access to the transaction manager.
     * This is required because there is no standard way to lookup the transaction manager in JTS 1.0.
     */
    public static void setTransactionManager(TransactionManager theTransactionManager) {
        transactionManager = theTransactionManager;
    }

    /**
     * INTERNAL:
     * Return true if the Global TX committed OK
     */
    public boolean wasTransactionCommitted(int status) {
        return status == Status.STATUS_COMMITTED;
    }

    /**
     * INTERNAL:
     * @deprecated
     * @param boolean alwaysBeginTransaction true if we should always call
     * uow.beginTransaction, regardless of whether the TX state is Active.  This
     * is used primarily by CMP, so that the uow and ClientSession are always
     * aware of the global JTS transaction.
     */
    public static void setShouldAlwaysBeginTransaction(boolean alwaysBeginTransaction) {
        shouldAlwaysBeginTransaction = alwaysBeginTransaction;
    }

    /**
     * INTERNAL:
     * @return true if we should always call uow.beginTransaction, regardless of whether
     * the TX state is Active.  This is used primarily by CMP, so that the uow and ClientSession
     * are always aware of the global JTS transaction.
     */
    public static boolean shouldAlwaysBeginTransaction() {
        return shouldAlwaysBeginTransaction;
    }
}