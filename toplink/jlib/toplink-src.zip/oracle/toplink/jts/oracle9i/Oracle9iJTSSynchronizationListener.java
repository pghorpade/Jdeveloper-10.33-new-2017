// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.oracle9i;

import javax.transaction.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Oracle9iAS Synchronization Listener class
 *
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Handle the synchronization callback notifications
 * <li> Provide abstract methods to handle Transaction
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.oc4j.Oc4jTransactionController}
 */
public class Oracle9iJTSSynchronizationListener extends oracle.toplink.jts.JTSSynchronizationListener {
    public Oracle9iJTSSynchronizationListener(UnitOfWork unitOfWork, Session session, Object transaction) {
        super(unitOfWork, session, transaction);
    }

    /**
     * INTERNAL:
     * This beforeCompletion method is called by the transaction
     * manager prior to the start of the transaction completion process.
     * This call is executed in the same transaction context of the caller
     * who initiates the TransactionManager.commit, or the call is executed
     * with no transaction context if Transaction.commit is used.
     */
    public void beforeCompletion() {
        UnitOfWork unitOfWork = getUnitOfWork();
        unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_before_completion");

        try {
            // The transaction status may be rolledback or other such that commit should not occur.
            // Note that OC4J will still call beforeCompletion if transaction is marked for rollback.
            int status = ((Transaction)getGlobalTransaction()).getStatus();
            boolean statusOK = (status == Status.STATUS_ACTIVE) || (status == Status.STATUS_PREPARING);
            if (!statusOK) {
                return;
            }
        } catch (Exception exception) {
            throw ValidationException.fatalErrorOccurred(exception);
        }

        // only issue SQL to database if uow is alive as it may have been released, in which we need to force a rollback
        if (unitOfWork.isActive()) {
            try {
                // In case jts transaction was internally started but committed or rolled back
                // directly by TransactionManager this flag may still be set to true.
                unitOfWork.getParent().setWasJTSTransactionInternallyStarted(false);

                // Must force concurrency mgrs active thread if in nested transaction.
                if (getSession().isInTransaction()) {
                    getSession().getTransactionMutex().setActiveThread(Thread.currentThread());
                }
                unitOfWork.issueSQLbeforeCompletion();
                // set state variable of uow to PENDING_MERGE
                unitOfWork.setPendingMerge();
            } catch (RuntimeException exception) {

                /* something went wrong sending SQL to the data-base;
                   tell the Global TX to rollback.
                */

                // no longer necessary as of WLS SP1
                // notifyClientBeforeRollback(exception);
                rollbackGlobalTransaction();
                // Option to dump exception trace
                if (shouldDumpExceptionsFromCallbacks()) {
                    exception.printStackTrace();
                }
                throw exception;
            }
        } else {
            // if in any other state, tell the Global TX to rolback.
            rollbackGlobalTransaction();
        }
    }

    /**
     * INTERNAL:
     * 'Factory' method used by TransactionController to
     * create an instance of Oracle9iJTSSynchronizationListener.
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        if ((getTransactionManager().getStatus() != Status.STATUS_ACTIVE) || shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        Transaction transaction = getTransactionManager().getTransaction();
        Oracle9iJTSSynchronizationListener listener = new Oracle9iJTSSynchronizationListener(unitOfWork, session, transaction);
        transaction.registerSynchronization(listener);
    }
}