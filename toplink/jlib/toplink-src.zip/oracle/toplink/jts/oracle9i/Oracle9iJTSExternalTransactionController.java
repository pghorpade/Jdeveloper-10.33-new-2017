// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.oracle9i;

import javax.transaction.*;
import oracle.toplink.jts.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.exceptions.*;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the Oracle 9i implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @see JTSSynchronizationListener
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.oc4j.Oc4jTransactionController}
 */
public class Oracle9iJTSExternalTransactionController extends JTSExternalTransactionController {
    public final static String TX_MANAGER_JNDI_NAME = "java:comp/pm/TransactionManager";


    /**
     * PUBLIC:
     * Return a new controller for use with Oracle 9iAS.
     * This must be associated with the TopLink session.
     */
    public Oracle9iJTSExternalTransactionController() {
        if (JTSSynchronizationListener.getTransactionManager() == null) {
            JTSSynchronizationListener.setTransactionManager((TransactionManager)getFromJNDI(TX_MANAGER_JNDI_NAME));
        }
    }

    /**
     * INTERNAL:
     * 'Factory' method used by TransactionController to
     * register listener for callbacks to UnitOfWork.
     */
    public void register(UnitOfWork uow, Session session) throws Exception {
        if (Oracle9iJTSSynchronizationListener.getTransactionManager() == null) {
            // Transaction manager must be set in the JTS-applicant driver, in order for TopLink to access to the manager
            throw DatabaseException.transactionManagerNotSetForJTSDriver();
        }

        Oracle9iJTSSynchronizationListener.register(uow, session);
    }
}