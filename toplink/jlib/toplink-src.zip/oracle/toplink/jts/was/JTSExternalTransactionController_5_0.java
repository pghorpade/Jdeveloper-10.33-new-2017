// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import java.io.*;
import java.lang.reflect.*;
import javax.transaction.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.jts.*;
import oracle.toplink.internal.security.PrivilegedAccessController;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 5.0 implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @author:  Mike Norman
 * @since: TOPLink for WebSphere 5.0
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was.WebSphereTransactionController_5_0}
 */
public class JTSExternalTransactionController_5_0 extends JTSExternalTransactionController {

    /**
     * INTERNAL:
     * Register the listener.
     */
    public void register(UnitOfWork unitOfWork, Session session) throws Exception {
        // bug # 3067942 - force getTransactionManager() to be called
        getTransactionManager();
        JTSSynchronizationListener.register(unitOfWork, session);
    }

    protected final static String TX_MANAGER_FACTORY_CLASS = "com.ibm.ejs.jts.jta.TransactionManagerFactory";
    protected final static String TX_MANAGER_FACTORY_METHOD = "getTransactionManager";

    /**
     * INTERNAL:
     * Get the transaction manager.
     *
     * @return The TransactionManager if it has been correctly set (or null if it
     * has not been)
     */
    public TransactionManager getTransactionManager() {
        TransactionManager tm = JTSSynchronizationListener.getTransactionManager();
        if (tm == null) {
            try {
                Class jtsxaClass = PrivilegedAccessController.getClassForName(getTxManagerFactoryClassName());
                Method getTMMethod = PrivilegedAccessController.getMethod(jtsxaClass, TX_MANAGER_FACTORY_METHOD, null, false);
                tm = (TransactionManager)(TransactionManager)PrivilegedAccessController.invokeMethod(getTMMethod, null, null);
                JTSSynchronizationListener.setTransactionManager(tm);
            } catch (Exception e) {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                throw new RuntimeException(sw.toString());
            }
        }
        return tm;
    }

    /**
     * INTERNAL: allow subclass to use to use different tx manager by ovewritting this method
     */
    protected String getTxManagerFactoryClassName() {
        return TX_MANAGER_FACTORY_CLASS;
    }
}