// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import java.util.Hashtable;
import java.lang.reflect.*;
import oracle.toplink.internal.security.PrivilegedAccessController;

/**
 * INTERNAL:
 * Used in the TopLink JTS Synchronization Listener classes to display the meaning of the Status
 * int field sent to the afterCompletion method.
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).
 */
public class JTSStatusHelper {
    private static JTSStatusHelper instance;
    private Hashtable classes;

    /**
     * JTSStatusHelper constructor comment.
     */
    protected JTSStatusHelper() {
        this.classes = new Hashtable();
    }

    /**
     * Reflectively create a Hashtable of status values and Strings.
     */
    protected synchronized void buildStatusHashFor(Class aStatusClass) {
        if (getClasses().get(aStatusClass) == null) {
            Hashtable statusHash = new Hashtable();

            Field[] fields = PrivilegedAccessController.getFields(aStatusClass);
            for (int i = 0; i < fields.length; i++) {
                try {
                    if (fields[i].getType().equals(int.class)) {
                        int intVal = PrivilegedAccessController.getIntValueFromField(fields[i], null);
                        statusHash.put(new Integer(intVal), aStatusClass.getName() + "." + fields[i].getName() + "=" + intVal);
                    }
                } catch (Exception ex) {
                    //ignore
                }
            }
            getClasses().put(aStatusClass, statusHash);
        }
    }

    /**
     *
     */
    protected Hashtable getClasses() {
        return classes;
    }

    /**
     * INTERNAL:
     */
    protected static JTSStatusHelper getInstance() {
        if (instance == null) {
            synchronized (JTSStatusHelper.class) {
                if (instance == null) {
                    instance = new JTSStatusHelper();
                }
            }
        }
        return instance;
    }

    /**
     *
     */
    protected String getNameForStatusValue(Class aStatusClass, int statusValue) {
        String returnVal = null;

        try {
            if (getClasses().get(aStatusClass) == null) {
                buildStatusHashFor(aStatusClass);
            }
            returnVal = (String)((Hashtable)getClasses().get(aStatusClass)).get(new Integer(statusValue));
        } catch (Exception ex) {
            // ignore
        }

        //
        if (returnVal == null) {
            return "" + statusValue;
        } else {
            return returnVal;
        }
    }

    /**
     * Return a String representing the meaning of the given statusValue for the given
     * aStatusClass. Used for logging only. If a representational String cannot be determined
     * then the statusValue is returned as a String.
     */
    public static String nameForStatusValue(Class aStatusClass, int statusValue) {
        return getInstance().getNameForStatusValue(aStatusClass, statusValue);

    }
}