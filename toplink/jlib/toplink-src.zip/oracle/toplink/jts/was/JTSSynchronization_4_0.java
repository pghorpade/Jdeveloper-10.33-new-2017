// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.omg.CosTransactions.*;
import oracle.toplink.publicinterface.Session;
import oracle.toplink.publicinterface.UnitOfWork;
import oracle.toplink.exceptions.ValidationException;
import oracle.toplink.jts.JTSSynchronizationListener;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 4.0 implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @author: Steven Vo
 * @since: TOPLink for WebSphere 4.5
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was.WebSphereTransactionController_4_0}
 */
public class JTSSynchronization_4_0 extends WebSphereJTSSynchronization {
    public JTSSynchronization_4_0() {
        super();
    }

    protected JTSSynchronization_4_0(UnitOfWork unitOfWork, Session session, Object transaction) {
        super(unitOfWork, session, transaction);
    }

    /*
     * INTERNAL:
     * Overwite super method to use this initial context.
     */
    protected static InitialContext getInitialContext() {
        if (context == null) {
            // Get the initial context
            Properties properties = new Properties();
            properties.put(javax.naming.Context.PROVIDER_URL, getProviderURL());

            // New context factory in 4.0, 3.x context factory is deprecated
            properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
            try {
                context = new InitialContext(properties);
            } catch (NamingException exception) {
                throw ValidationException.jtsExceptionRaised(exception);
            }
        }
        return context;
    }

    /**
     * INTERNAL:
     * Overwite super static method to use this context setting
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        Context context = null;

        context = getInitialContext();
        javax.transaction.UserTransaction transaction = (javax.transaction.UserTransaction)context.lookup("jta/usertransaction");
        if ((transaction.getStatus() == Status._StatusNoTransaction) || JTSSynchronizationListener.shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        JTSSynchronization_4_0 listener = new JTSSynchronization_4_0(unitOfWork, session, transaction);

        org.omg.CosTransactions.Control control = com.ibm.ejs.jts.jts.Current.getCurrent().get_control();

        control.get_coordinator().register_synchronization((org.omg.CosTransactions.Synchronization)listener);
    }
}