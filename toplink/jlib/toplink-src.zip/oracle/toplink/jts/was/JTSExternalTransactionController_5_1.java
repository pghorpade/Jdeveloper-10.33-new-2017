// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;


/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 5.1 implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @author: Steven Vo
 * @since: TOPLink for WebSphere 5.1
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was.WebSphereTransactionController_5_1}
 */
public class JTSExternalTransactionController_5_1 extends JTSExternalTransactionController_5_0 {
    // Overwrite super value in the scope of this class, i.e JTSExternalTransactionController_5_1.TX_MANAGER_FACTORY_CLASS
    // Reference to the same static attribute returns the value respected to the scope of the class that the calling method is in.
    protected final static String TX_MANAGER_FACTORY_CLASS = "com.ibm.ws.Transaction.TransactionManagerFactory";

    /**
     * INTERNAL: overwrite super method to use different tx manager.
     */
    protected String getTxManagerFactoryClassName() {
        return TX_MANAGER_FACTORY_CLASS;
    }
}