// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import java.util.*;
import javax.naming.*;
import javax.transaction.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.sessions.ExternalTransactionController;
import oracle.toplink.jts.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 *
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 3.0 implementation
 *
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was}
 */
public class WebSphereJTSExternalTransactionController extends AbstractExternalTransactionController implements ExternalTransactionController {
    protected static InitialContext context;

    /**
     * PUBLIC:
     * Return a new controller for use with WebSphere.
     * This must be associated with the TopLink session.
     */
    public WebSphereJTSExternalTransactionController() {
        super();
        this.unitsOfWorkToTransactions = new Hashtable();
    }

    /**
     * INTERNAL:
     * This method looks up the Current transaction, and if it hasn't started it starts it.
     */
    public void beginTransaction(Session session) {
        Context context = null;
        UserTransaction transaction = null;
        try {
            context = getInitialContext();
            transaction = (UserTransaction)context.lookup("jta/usertransaction");
            if (transaction.getStatus() == javax.transaction.Status.STATUS_NO_TRANSACTION) {
                session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_begin");
                session.setWasJTSTransactionInternallyStarted(true);
                transaction.begin();
            }
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * This method looks up the current jts transaction, and if it is active,
     * it commits it.
     */
    public void commitTransaction(Session session) {
        Context context = null;
        UserTransaction transaction = null;

        try {
            context = getInitialContext();
            transaction = (UserTransaction)context.lookup("jta/usertransaction");
            if (transaction.getStatus() == javax.transaction.Status.STATUS_ACTIVE) {
                session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_commit");
                session.setWasJTSTransactionInternallyStarted(false);
                transaction.commit();
            }
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * This method gets the active external transaction.
     */
    public Object getExternalTransaction() throws Exception {
        org.omg.CosTransactions.Control control = com.ibm.ejs.jts.jts.Current.getCurrent().get_control();
        if (control == null) {
            return null;
        }
        return control.get_coordinator().get_transaction_name();
    }

    /**
     * INTERNAL:
     * Return the JNDI initial context for WebSphere.
     */
    protected static InitialContext getInitialContext() {
        return WebSphereJTSSynchronization.getInitialContext();
    }

    /**
     * INTERNAL:
     * Marks the current transaction for rollback only.
     */
    public void markTransactionForRollback() {
        Context context = null;
        UserTransaction transaction = null;
        try {
            context = getInitialContext();
            transaction = (UserTransaction)context.lookup("jta/usertransaction");
            transaction.setRollbackOnly();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * INTERNAL:
     * Register the listener.
     */
    public void register(UnitOfWork unitOfWork, Session session) throws Exception {
        WebSphereJTSSynchronization.register(unitOfWork, session);
    }

    /**
     * INTERNAL:
     * Looks up the current transaction, and tells it to rollback
     */
    public void rollbackTransaction(Session session) {
        Context context = null;
        try {
            context = getInitialContext();
            UserTransaction transaction = (UserTransaction)context.lookup("jta/usertransaction");
            session.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_rollback");
            session.setWasJTSTransactionInternallyStarted(false);
            transaction.rollback();
        } catch (Exception exception) {
            throw ValidationException.jtsExceptionRaised(exception);
        }
    }

    protected java.util.Hashtable unitsOfWorkToTransactions;

    /**
     * INTERNAL:
     * Add a UnitOfWork object to the Hashtable.
     */
    protected void addUnitOfWork(Object transaction, UnitOfWork activeUnitOfWork) {
        super.addUnitOfWork(transaction, activeUnitOfWork);
        getUnitsOfWorkToTransactions().put(activeUnitOfWork, transaction);
    }

    /**
     * INTERNAL:
     */
    public java.util.Hashtable getUnitsOfWorkToTransactions() {
        return unitsOfWorkToTransactions;
    }

    /**
     * INTERNAL:
     * Remove the given unit of work from the HashTable of UnitOfWork objects.
     */
    public void removeActiveUnitOfWork(UnitOfWork aUnitOfWork) {
        Object transaction = getUnitsOfWorkToTransactions().get(aUnitOfWork);
        getUnitsOfWorkToTransactions().remove(aUnitOfWork);
        getUnitsOfWork().remove(transaction);
    }

    /**
     * INTERNAL:
     */
    void setUnitsOfWorkToTransactions(java.util.Hashtable newUnitsOfWorkToTransactions) {
        unitsOfWorkToTransactions = newUnitsOfWorkToTransactions;
    }
}