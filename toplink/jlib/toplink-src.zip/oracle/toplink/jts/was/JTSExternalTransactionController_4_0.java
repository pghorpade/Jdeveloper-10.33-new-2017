// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import javax.naming.InitialContext;
import oracle.toplink.publicinterface.Session;
import oracle.toplink.publicinterface.UnitOfWork;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 4.0 implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @author: Steven Vo
 * @since: TOPLink for WebSphere 4.5
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was.WebSphereTransactionController_4_0}
 */
public class JTSExternalTransactionController_4_0 extends WebSphereJTSExternalTransactionController {

    /**
     * INTERNAL:
     * Return the JNDI initial context for WebSphere.
     */
    protected static InitialContext getInitialContext() {
        return JTSSynchronization_4_0.getInitialContext();
    }

    /**
     * INTERNAL:
     * Register the listener.
     */
    public void register(UnitOfWork unitOfWork, Session session) throws Exception {
        JTSSynchronization_4_0.register(unitOfWork, session);
    }
}