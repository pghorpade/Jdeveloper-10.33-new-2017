// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.was;

import java.util.*;
import javax.naming.*;
import org.omg.CosTransactions.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.jts.*;
import oracle.toplink.logging.SessionLog;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 *
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebSphere 3.0 implementation
 *
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.was}
 */
public class WebSphereJTSSynchronization extends org.omg.CosTransactions._SynchronizationImplBase implements Synchronization {
    protected oracle.toplink.publicinterface.Session session;
    protected oracle.toplink.publicinterface.UnitOfWork unitOfWork;
    protected java.lang.Object globalTransaction;
    protected static InitialContext context;
    private static String providerURL = "iiop:///";

    /**
     * INTERNAL:
     * Require to allow subclasses.
     */
    public WebSphereJTSSynchronization() {
    }

    protected WebSphereJTSSynchronization(UnitOfWork unitOfWork, Session session, Object transaction) {
        this.session = session;
        this.unitOfWork = unitOfWork;
        this.globalTransaction = transaction;
    }

    /**
     * INTERNAL:
     * After the JTS transaction is committed the unit of work must be merged into the session cache,
     * on rollback nothing should be done.
     */
    public void after_completion(org.omg.CosTransactions.Status param1) {
        afterCompletion(param1.value());
    }

    /**
     * INTERNAL:
     * After the JTS transaction is committed the unit of work must be merged into the session cache,
     * on rollback nothing should be done.
     */
    public void afterCompletion(int status) {
        UnitOfWork unitOfWork = getUnitOfWork();
        unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_after_completion_with_argument", JTSStatusHelper.nameForStatusValue(Status.class, status));

        /* check to see if global TX commited and
           if the uow is in the correct state
        */
        if (wasTransactionCommitted(status)) {
            // true=="committed"; true=="jts transaction"
            unitOfWork.afterTransaction(true, true);
            if (unitOfWork.isMergePending()) {
                // uow in in PENDING_MERGE state, merge clones
                unitOfWork.mergeClonesAfterCompletion();
            }
        } else {
            // false=="rolled back"; true=="jts transaction"
            unitOfWork.afterTransaction(false, true);
        }

        /* regardless of above state, still must clean-up:
           release uow, decrement number of outstanding uow's
           with pending merges.
        */
        unitOfWork.release();

        // remove the released UnitOfWork from the Transaction Controller
        WebSphereJTSExternalTransactionController controller = (WebSphereJTSExternalTransactionController)getSession().getExternalTransactionController();
        controller.removeActiveUnitOfWork(getUnitOfWork());

        // null out local fields so that they can be GC'd
        Session sess = getSession();// Save the session to explicitly release later (CR 4081)
        setSession(null);
        setUnitOfWork(null);
        setGlobalTransaction(null);

        /* CR 4081 - Release the session instead of waiting for GC to clean it up */
        if (sess.isClientSession()) {
            sess.release();
        }
    }

    /**
     * INTERNAL:
     * Before the JTS transaction commits the unit of work must commit to the database.
     */
    public void before_completion() {
        beforeCompletion();
    }

    /**
     * INTERNAL:
     * Before the JTS transaction commits the unit of work must commit to the database.
     */
    public void before_completion(org.omg.CosTransactions.Status param1) {
        beforeCompletion();
    }

    /**
     * INTERNAL:
     * Before the JTS transaction commits the unit of work must commit to the database.
     */
    public void beforeCompletion() {
        UnitOfWork unitOfWork = getUnitOfWork();
        unitOfWork.log(SessionLog.FINER, SessionLog.TRANSACTION, "JTS_before_completion");

        // only issue SQL to database if uow is alive as it may have been released, in which we need to force a rollback
        if (unitOfWork.isActive()) {
            try {
                // Must force concurrency mgrs active thread if in nested transaction.
                if (getSession().isInTransaction()) {
                    getSession().getTransactionMutex().setActiveThread(Thread.currentThread());
                }
                unitOfWork.issueSQLbeforeCompletion();
                // set state variable of uow to PENDING_MERGE
                unitOfWork.setPendingMerge();
            } catch (RuntimeException exception) {

                /* something went wrong sending SQL to the data-base;
                   tell the Global TX to rollback.
                */
                rollbackGlobalTransaction();
                throw exception;
            }
        } else {
            // if in any other state, tell the Global TX to rolback.
            rollbackGlobalTransaction();
        }
    }

    /**
     * Return the JTS transaction.
     */
    protected Object getGlobalTransaction() {
        return globalTransaction;
    }

    /**
     * INTERNAL:
     * Return the JNDI initial context for WebSphere.
     */
    protected static InitialContext getInitialContext() {
        if (context == null) {
            // Get the initial context
            Properties properties = new Properties();
            properties.put(javax.naming.Context.PROVIDER_URL, getProviderURL());
            // Use IBM name services
            properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, "com.ibm.ejs.ns.jndi.CNInitialContextFactory");
            try {
                context = new InitialContext(properties);
            } catch (NamingException exception) {
                throw ValidationException.jtsExceptionRaised(exception);
            }
        }
        return context;
    }

    /**
     * Insert the method's description here.
     * Creation date: (6/11/00 6:03:26 PM)
     * @return java.lang.String
     */
    static java.lang.String getProviderURL() {
        return providerURL;
    }

    protected Session getSession() {
        return session;
    }

    protected UnitOfWork getUnitOfWork() {
        return unitOfWork;
    }

    /**
     * INTERNAL:
     * Register the synchronization listener with the JTS/OTS.
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        Context context = null;

        context = getInitialContext();
        javax.transaction.UserTransaction transaction = (javax.transaction.UserTransaction)context.lookup("jta/usertransaction");
        if ((transaction.getStatus() == Status._StatusNoTransaction) || JTSSynchronizationListener.shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        WebSphereJTSSynchronization listener = new WebSphereJTSSynchronization(unitOfWork, session, transaction);

        org.omg.CosTransactions.Control control = com.ibm.ejs.jts.jts.Current.getCurrent().get_control();

        control.get_coordinator().register_synchronization((org.omg.CosTransactions.Synchronization)listener);
    }

    /**
     * INTERNAL:
     * Rollback.
     */
    public void rollbackGlobalTransaction() {
        // UserTransaction currentTransaction = (UserTransaction) getGlobalTransaction();
        try {
            Context context = getInitialContext();
            javax.transaction.UserTransaction currentTransaction = (javax.transaction.UserTransaction)context.lookup("jta/usertransaction");
            if (currentTransaction != null) {
                currentTransaction.setRollbackOnly();
            }
        } catch (javax.transaction.SystemException exception) {
            throw oracle.toplink.exceptions.ValidationException.jtsExceptionRaised(exception);
        } catch (NamingException exception) {
            throw oracle.toplink.exceptions.ValidationException.jtsExceptionRaised(exception);
        }
    }

    /**
     * Set the JTS transaction.
     */
    protected void setGlobalTransaction(Object globalTransaction) {
        this.globalTransaction = globalTransaction;
    }

    /**
     * Set the URL used for the JNDI lookups.
     */
    public static void setProviderURL(java.lang.String newProviderURL) {
        providerURL = newProviderURL;
    }

    protected void setSession(Session session) {
        this.session = session;
    }

    protected void setUnitOfWork(UnitOfWork unitOfWork) {
        this.unitOfWork = unitOfWork;
    }

    /**
     * INTERNAL:
     * Check if committed.
     */
    public boolean wasTransactionCommitted(int status) {
        return status == Status._StatusCommitted;
    }
}