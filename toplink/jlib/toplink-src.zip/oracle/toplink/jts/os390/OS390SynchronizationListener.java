// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.os390;

import javax.transaction.*;
import oracle.toplink.publicinterface.*;

/**
 * <p>
 * <b>Purpose</b>: Provides transaction callback mechanism Listener class
 * <p>
 * <b>Description</b>: This class is paired with
 * OS390ExternalTransactionController. It contains the implementation
 * logic to handle the synchronization callback notifications with respect
 * to UnitOfWork - commiting changes to the database and merging
 * clones into the parent Session.
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Handle the synchronization callback notifications
 * <li> Provide methods to handle Transaction
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.JTASynchronizationListener}
 */
public class OS390SynchronizationListener extends oracle.toplink.jts.JTSSynchronizationListener {
    public OS390SynchronizationListener(UnitOfWork unitOfWork, Session session, Object transaction) {
        super(unitOfWork, session, transaction);
    }

    /**
     * PUBLIC:
     * The afterCompletion method is called by the transaction manager after the transaction is
     * committed or rolled back. This method executes without a transaction context.
     *
     * It also releases the parent session (client session).
     */
    public void afterCompletion(int status) {
        UnitOfWork unitOfWork = getUnitOfWork();
        try {
            super.afterCompletion(status);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        unitOfWork.getParent().release();
    }

    /**
     * INTERNAL:
     * 'Factory' method used by TransactionController to
     * create an instance of OS390SynchronizationListener.
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        if ((getTransactionManager().getStatus() != Status.STATUS_ACTIVE) || shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        Transaction transaction = getTransactionManager().getTransaction();
        OS390SynchronizationListener listener = new OS390SynchronizationListener(unitOfWork, session, transaction);
        transaction.registerSynchronization(listener);
    }
}