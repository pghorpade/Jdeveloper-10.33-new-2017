// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.os390;

import java.lang.reflect.*;
import javax.transaction.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.sessions.ExternalTransactionController;
import oracle.toplink.jts.*;
import oracle.toplink.exceptions.*;
import oracle.toplink.internal.security.PrivilegedAccessController;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to OS390 version of WebSphere
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @see OS390SynchronizationListener
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.JTATransactionController}
 */
public class OS390ExternalTransactionController extends JTSExternalTransactionController implements ExternalTransactionController {

    /**
     * PUBLIC:
     * Return a new controller for use with Websphere on OS390.
     * This must be associated with the TopLink session.
     */
    public OS390ExternalTransactionController() {
        if (OS390SynchronizationListener.getTransactionManager() == null) {
            OS390SynchronizationListener.setTransactionManager(getTxManager());
        }
    }

    private TransactionManager getTxManager() {
        TransactionManager manager = null;
        try {
            Class tximpl = PrivilegedAccessController.getClassForName("com.ibm.ws390.tx.TransactionManagerImpl");
            Method met = PrivilegedAccessController.getMethod(tximpl, "getTransactionManager", new Class[0], false);
            manager = (TransactionManager)PrivilegedAccessController.invokeMethod(met, null, new Object[0]);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        return manager;
    }

    /**
     * INTERNAL:
     */
    public void register(UnitOfWork uow, Session session) throws Exception {
        if (OS390SynchronizationListener.getTransactionManager() == null) {
            // Transaction manager must be set in the JTS-applicant driver, in order for TopLink to access to the manager
            throw DatabaseException.transactionManagerNotSetForJTSDriver();
        }

        OS390SynchronizationListener.register(uow, session);
    }
}