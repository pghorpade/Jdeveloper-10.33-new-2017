// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.wls;

import javax.transaction.*;
import oracle.toplink.publicinterface.*;

/*
 * May-10-2002 MLK - This class can probably go away now because releasing
 *                   the client session in afterCompletion has now been moved
 *                   up to the abstract class. The stack trace printing is
 *                   also now configurable as a flag in the abstract class.
 */

/**
 * <p>
 * <b>Purpose</b>: Provides transaction callback mechanism Listener class
 * <p>
 * <b>Description</b>: This class is paired with
 * WebLogicJTSExternalTransactionController. It contains the implementation
 * logic to handle the synchronization callback notifications with respect
 * to UnitOfWork - commiting changes to the database and merging
 * clones into the parent Session.
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Handle the synchronization callback notifications
 * <li> Provide methods to handle Transaction
 * </ul>
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.wls.WebLogicTransactionController}
 */
public class WebLogicSynchronizationListener extends oracle.toplink.jts.JTSSynchronizationListener {
    public WebLogicSynchronizationListener(UnitOfWork unitOfWork, Session session, Object transaction) {
        super(unitOfWork, session, transaction);
    }

    /**
     * PUBLIC:
     * The afterCompletion method is called by the transaction manager after the transaction is
     * committed or rolled back. This method executes without a transaction context.
     */
    public void afterCompletion(int status) {
        UnitOfWork unitOfWork = getUnitOfWork();
        try {
            super.afterCompletion(status);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    /**
     * INTERNAL:
     * 'Factory' method used by TransactionController to
     * create an instance of WebLogicSynchronizationListener.
     */
    public static void register(UnitOfWork unitOfWork, Session session) throws Exception {
        if ((getTransactionManager().getStatus() != Status.STATUS_ACTIVE) || shouldAlwaysBeginTransaction()) {
            unitOfWork.beginTransaction();
        }
        Transaction transaction = getTransactionManager().getTransaction();
        WebLogicSynchronizationListener listener = new WebLogicSynchronizationListener(unitOfWork, session, transaction);
        transaction.registerSynchronization(listener);
    }
}