// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.jts.wls;

import javax.transaction.*;
import oracle.toplink.publicinterface.*;
import oracle.toplink.sessions.ExternalTransactionController;
import oracle.toplink.jts.*;
import oracle.toplink.exceptions.*;

/**
 * <p>
 * <b>Purpose</b>: Concrete implementation of an ExternalTransactionController.
 * <p>
 * <b>Description</b>: This class implements the registration of a synchronization
 * object according to the WebLogic 5.1 implementation
 * <p>
 * <b>Responsibilities</b>:
 * <ul>
 * <li> Register a listener to the externally controlled transaction.
 * </ul>
 * @see WebLogicJTSSynchronization
 * @deprecated since OracleAS TopLink 10<i>g</i> (10.1.3).  This class is replaced by
 *         {@link oracle.toplink.transaction.wls.WebLogicTransactionController}
 */
public class WebLogicJTSExternalTransactionController extends JTSExternalTransactionController implements ExternalTransactionController {
    public static String transactionManagerJNDIName = "weblogic.transaction.TransactionManager";

    /**
     * PUBLIC:
     * Return a new controller for use with Weblogic.
     * This must be associated with the TopLink session.
     */
    public WebLogicJTSExternalTransactionController() {
        if (JTSSynchronizationListener.getTransactionManager() == null) {
            JTSSynchronizationListener.setTransactionManager((TransactionManager)getFromJNDI(transactionManagerJNDIName));
        }
    }

    /**
     * INTERNAL:
     * 'Factory' method used by TransactionController to
     * register listener for callbacks to UnitOfWork.
     */
    public void register(UnitOfWork uow, Session session) throws Exception {
        if (WebLogicSynchronizationListener.getTransactionManager() == null) {
            // Transaction manager must be set in the JTS-applicant driver, in order for TopLink to access to the manager
            throw DatabaseException.transactionManagerNotSetForJTSDriver();
        }

        WebLogicSynchronizationListener.register(uow, session);
    }
}