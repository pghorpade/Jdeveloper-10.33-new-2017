// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.ox.jaxb;

import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Validator;
import oracle.toplink.ox.XMLContext;
import oracle.toplink.ox.XMLMarshaller;

class JAXBContext extends javax.xml.bind.JAXBContext {
    private XMLContext xmlContext;

    JAXBContext(XMLContext newContext) {
        super();
        xmlContext = newContext;
    }

    public Marshaller createMarshaller() {
        return new JAXBMarshaller(xmlContext.createMarshaller());
    }

    public Unmarshaller createUnmarshaller() {
        return new JAXBUnmarshaller(xmlContext.createUnmarshaller());
    }

    public Validator createValidator() {
        return new JAXBValidator(xmlContext.createValidator());
    }
}