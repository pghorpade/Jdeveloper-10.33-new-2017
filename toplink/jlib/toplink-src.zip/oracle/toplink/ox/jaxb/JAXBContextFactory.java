// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.ox.jaxb;

import javax.xml.bind.JAXBException;
import oracle.toplink.ox.XMLContext;

public class JAXBContextFactory {
    public static JAXBContext createContext(String contextPath, ClassLoader classLoader) throws JAXBException {
        XMLContext xmlContext = new XMLContext(contextPath, classLoader);
        return new JAXBContext(xmlContext);
    }
}