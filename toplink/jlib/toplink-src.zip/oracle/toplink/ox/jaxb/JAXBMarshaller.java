// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.ox.jaxb;

import java.io.OutputStream;
import java.io.Writer;
import javax.xml.bind.JAXBException;
import javax.xml.bind.MarshalException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.helpers.DefaultValidationEventHandler;
import javax.xml.transform.Result;
import oracle.toplink.ox.XMLConstants;
import oracle.toplink.ox.XMLMarshaller;
import org.w3c.dom.Node;
import org.xml.sax.ContentHandler;

public class JAXBMarshaller implements Marshaller {
    
    private ValidationEventHandler validationEventHandler;
    private XMLMarshaller xmlMarshaller;

    public JAXBMarshaller(XMLMarshaller newXMLMarshaller) {
        super();
        validationEventHandler = new DefaultValidationEventHandler();
        xmlMarshaller = newXMLMarshaller;
        xmlMarshaller.setEncoding("UTF-8");
        xmlMarshaller.setFormattedOutput(false);
    }

    public void marshal(Object object, Result result) throws JAXBException {
        if ((object == null) || (result == null)) {
            throw new IllegalArgumentException();
        }
        try {
            xmlMarshaller.marshal(object, result);
        } catch (Exception e) {
            throw new MarshalException(e);
        }
    }

    public void marshal(Object object, OutputStream outputStream) throws JAXBException {
        if ((object == null) || (outputStream == null)) {
            throw new IllegalArgumentException();
        }
        try {
            xmlMarshaller.marshal(object, outputStream);
        } catch (Exception e) {
            throw new MarshalException(e);
        }
    }

    public void marshal(Object object, Writer writer) throws JAXBException {
        if ((object == null) || (writer == null)) {
            throw new IllegalArgumentException();
        }
        try {
            xmlMarshaller.marshal(object, writer);
        } catch (Exception e) {
            throw new MarshalException(e);
        }
    }

    public void marshal(Object object, ContentHandler contentHandler) throws JAXBException {
        if ((object == null) || (contentHandler == null)) {
            throw new IllegalArgumentException();
        }
        try {
            xmlMarshaller.marshal(object, contentHandler);
        } catch (Exception e) {
            throw new MarshalException(e);
        }
    }

    public void marshal(Object object, Node node) throws JAXBException {
        if ((object == null) || (node == null)) {
            throw new IllegalArgumentException();
        }
        try {
            xmlMarshaller.marshal(object, node);
        } catch (Exception e) {
            throw new MarshalException(e);
        }
    }

    public Node getNode(Object object) throws JAXBException {
        throw new UnsupportedOperationException();
    }

    public void setProperty(String key, Object value) throws PropertyException {
        try {
            if (key == null) {
                throw new IllegalArgumentException();
            } else if (JAXB_FORMATTED_OUTPUT.equals(key)) {
                Boolean formattedOutput = (Boolean)value;
                xmlMarshaller.setFormattedOutput(formattedOutput.booleanValue());
            } else if (JAXB_ENCODING.equals(key)) {
                xmlMarshaller.setEncoding((String)value);
            } else if (JAXB_SCHEMA_LOCATION.equals(key)) {
                xmlMarshaller.setSchemaLocation((String)value);
            } else if (JAXB_NO_NAMESPACE_SCHEMA_LOCATION.equals(key)) {
                xmlMarshaller.setNoNamespaceSchemaLocation((String)value);
            } else if (XMLConstants.JAXB_FRAGMENT.equals(key)) {
                Boolean fragment = (Boolean)value;
                xmlMarshaller.setFragment(fragment.booleanValue());
            } else {
                throw new PropertyException(key, value);
            }
        } catch (ClassCastException exception) {
            throw new PropertyException(key, exception);
        }
    }

    public Object getProperty(String key) throws PropertyException {
        if (key == null) {
            throw new IllegalArgumentException();
        } else if (JAXB_FORMATTED_OUTPUT.equals(key)) {
            return new Boolean(xmlMarshaller.isFormattedOutput());
        } else if (JAXB_ENCODING.equals(key)) {
            return xmlMarshaller.getEncoding();
        } else if (JAXB_SCHEMA_LOCATION.equals(key)) {
            return xmlMarshaller.getSchemaLocation();
        } else if (JAXB_NO_NAMESPACE_SCHEMA_LOCATION.equals(key)) {
            return xmlMarshaller.getNoNamespaceSchemaLocation();
        } else if (XMLConstants.JAXB_FRAGMENT.equals(key)) {
            return new Boolean(xmlMarshaller.isFragment());
        }
        throw new PropertyException("Unsupported Property");
    }

    public void setEventHandler(ValidationEventHandler newValidationEventHandler) throws JAXBException {
        if (null == newValidationEventHandler) {
            validationEventHandler = new DefaultValidationEventHandler();
        } else {
            validationEventHandler = newValidationEventHandler;
        }
    }

    public ValidationEventHandler getEventHandler() throws JAXBException {
        return validationEventHandler;
    }
}