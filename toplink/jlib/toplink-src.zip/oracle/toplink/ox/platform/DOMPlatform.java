// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.ox.platform;

import oracle.toplink.internal.ox.record.DOMUnmarshaller;
import oracle.toplink.internal.ox.record.PlatformUnmarshaller;
import oracle.toplink.ox.XMLContext;

/**
 *  @version 1.0
 *  @author  mmacivor
 *  @since   10.1.3
 *  This class indicated that DOM parsing should be used when appropriate in an
 *  XML project to create XMLRecords.
 */
public class DOMPlatform extends XMLPlatform {

    /**
     * INTERNAL:
     */
    public PlatformUnmarshaller newPlatformUnmarshaller(XMLContext xmlContext) {
        return new DOMUnmarshaller(xmlContext);
    }
}