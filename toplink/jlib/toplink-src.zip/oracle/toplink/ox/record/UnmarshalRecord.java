// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.ox.record;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import oracle.toplink.exceptions.TopLinkException;
import oracle.toplink.exceptions.XMLMarshalException;
import oracle.toplink.internal.helper.DatabaseField;
import oracle.toplink.internal.helper.Helper;
import oracle.toplink.internal.ox.ContainerValue;
import oracle.toplink.internal.ox.NodeValue;
import oracle.toplink.internal.ox.NullCapableValue;
import oracle.toplink.internal.ox.StrBuffer;
import oracle.toplink.internal.ox.TreeObjectBuilder;
import oracle.toplink.internal.ox.XPathFragment;
import oracle.toplink.internal.ox.XPathNode;
import oracle.toplink.mappings.foundation.AbstractTransformationMapping;
import oracle.toplink.ox.NamespaceResolver;
import oracle.toplink.ox.XMLField;
import oracle.toplink.publicinterface.DescriptorEventManager;
import oracle.toplink.ox.XMLContext;
import oracle.toplink.ox.XMLUnmarshaller;
import oracle.toplink.queryframework.ReadObjectQuery;
import oracle.toplink.sessions.Session;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;

public class UnmarshalRecord extends XMLRecord implements ContentHandler {
    protected static final String EMPTY_STRING = "";
    private Session session;
    private XMLReader xmlReader;
    private TreeObjectBuilder treeObjectBuilder;
    private XPathFragment xPathFragment;
    private XPathNode xPathNode;
    private int levelIndex;
    private UnmarshalRecord childRecord;
    private UnmarshalRecord parentRecord;
    private DOMRecord transformationRecord;
    private List selfRecords;
    private Map indexMap;
    private Map namespaceMap;
    private List nullCapableValues;
    private Map containersMap;
    private Object object;
    private StrBuffer stringBuffer;
    private Attributes attributes;
    private QName typeQName;
    private XMLUnmarshaller unmarshaller;

    public UnmarshalRecord(TreeObjectBuilder treeObjectBuilder) {
        super();
        this.levelIndex = 0;
        this.xPathFragment = new XPathFragment();
        this.stringBuffer = new StrBuffer();
        this.treeObjectBuilder = treeObjectBuilder;
        if (null != treeObjectBuilder) {
            this.xPathNode = treeObjectBuilder.getRootXPathNode();
            if (null != treeObjectBuilder.getNullCapableValues()) {
                nullCapableValues = new ArrayList();
                nullCapableValues.addAll(treeObjectBuilder.getNullCapableValues());
            }
        }
    }

    public String getLocalName() {
        throw XMLMarshalException.operationNotSupported("getLocalName");
    }

    public String getNamespaceURI() {
        throw XMLMarshalException.operationNotSupported("getNamespaceURI");
    }

    public void clear() {
        throw XMLMarshalException.operationNotSupported("clear");
    }

    public Document getDocument() {
        throw XMLMarshalException.operationNotSupported("getDocument");
    }

    public Element getDOM() {
        throw XMLMarshalException.operationNotSupported("getDOM");
    }

    public String transformToXML() {
        throw XMLMarshalException.operationNotSupported("transformToXML");
    }

    public Session getSession() {
        return this.session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public XMLReader getXMLReader() {
        return this.xmlReader;
    }

    public void setXMLReader(XMLReader xmlReader) {
        this.xmlReader = xmlReader;
    }

    public UnmarshalRecord getChildRecord() {
        return this.childRecord;
    }

    public void setChildRecord(UnmarshalRecord childRecord) {
        this.childRecord = childRecord;
        if (null != childRecord) {
            childRecord.setParentRecord(this);
            childRecord.session = this.session;
            childRecord.xmlReader = this.xmlReader;
        }
    }

    public UnmarshalRecord getParentRecord() {
        return this.parentRecord;
    }

    public void setParentRecord(UnmarshalRecord parentRecord) {
        this.parentRecord = parentRecord;
    }

    public DOMRecord getTransformationRecord() {
        return this.transformationRecord;
    }

    public void setTransformationRecord(DOMRecord transformationRecord) {
        this.transformationRecord = transformationRecord;
    }

    public Map getNamespaceMap() {
        return this.namespaceMap;
    }

    public void setNamespaceMap(Map namespaceMap) {
        this.namespaceMap = namespaceMap;
    }

    public List getNullCapableValues() {
        return this.nullCapableValues;
    }

    public void removeNullCapableValue(NullCapableValue nullCapableValue) {
        if (null == getNullCapableValues()) {
            return;
        }
        getNullCapableValues().remove(nullCapableValue);
    }

    public Object getContainerInstance(ContainerValue containerValue) {
        if (null == containersMap) {
            return null;
        }
        return containersMap.get(containerValue);
    }

    public Object getObject() {
        return this.object;
    }

    public StrBuffer getStringBuffer() {
        return this.stringBuffer;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    public QName getTypeQName() {
        return this.typeQName;
    }

    public void setTypeQName(QName typeQName) {
        this.typeQName = typeQName;
    }

    public void setDocumentLocator(Locator locator) {
    }

    public Object get(DatabaseField key) {
        XMLField xmlField = this.convertToXMLField(key);
        XPathFragment lastFragment = xmlField.getLastXPathFragment();
        NamespaceResolver namespaceResolver = xmlField.getNamespaceResolver();
        String namespaceURI = "";
        if (null != namespaceResolver) {
            namespaceURI = namespaceResolver.resolveNamespacePrefix(lastFragment.getPrefix());
            if (null == namespaceURI) {
                namespaceURI = EMPTY_STRING;
            }
        }
        return attributes.getValue(namespaceURI, lastFragment.getLocalName());
    }

    public void startDocument() throws SAXException {
        try {
            object = treeObjectBuilder.buildNewInstance();

            List containerValues = treeObjectBuilder.getContainerValues();
            if (null != containerValues) {
                containersMap = new HashMap(containerValues.size());
                ContainerValue containerValue;
                Object containerInstance;
                int containerValuesSize = containerValues.size();
                for (int x = 0; x < containerValuesSize; x++) {
                    containerValue = (ContainerValue)containerValues.get(x);
                    containerInstance = containerValue.getContainerInstance();
                    containersMap.put(containerValue, containerInstance);
                }
            }

            if (null != xPathNode.getSelfChildren()) {
                int selfChildrenSize = xPathNode.getSelfChildren().size();
                selfRecords = new ArrayList(selfChildrenSize);
                XPathNode selfNode;
                for (int x = 0; x < selfChildrenSize; x++) {
                    selfNode = (XPathNode)xPathNode.getSelfChildren().get(x);
                    if (null != selfNode.getNodeValue()) {
                        selfRecords.add(selfNode.getNodeValue().buildSelfRecord(this, null));
                    }
                }
            }
        } catch (TopLinkException e) {
            if (null == xmlReader.getErrorHandler()) {
                throw e;
            } else {
                SAXParseException saxParseException = new SAXParseException(null, null, null, 0, 0, e);
                xmlReader.getErrorHandler().error(saxParseException);
            }
        }
    }

    public void endDocument() throws SAXException {
        try {
            // PROCESS COLLECTION MAPPINGS
            if (null != containersMap) {
                Iterator containersMapKeys = containersMap.keySet().iterator();
                ContainerValue containerValue;
                Object containerInstance;
                while (containersMapKeys.hasNext()) {
                    containerValue = (ContainerValue)containersMapKeys.next();
                    containerInstance = containersMap.get(containerValue);
                    containerValue.setContainerInstance(object, containerInstance);
                }
            }

            // PROCESS NULL CAPABLE VALUES
            // This must be done because the node may not have existed to 
            // trigger the mapping.
            if (null != getNullCapableValues()) {
                int nullValuesSize = getNullCapableValues().size();
                NullCapableValue nullCapableValue;
                for (int x = 0; x < nullValuesSize; x++) {
                    nullCapableValue = (NullCapableValue)getNullCapableValues().get(x);
                    nullCapableValue.setNullValue(object, session);
                }
            }

            // PROCESS TRANSFORMATION MAPPINGS
            List transformationMappings = treeObjectBuilder.getTransformationMappings();
            if (null != transformationMappings) {
                ReadObjectQuery query = new ReadObjectQuery();
                query.setSession((oracle.toplink.publicinterface.Session)session);
                int transformationMappingsSize = transformationMappings.size();
                AbstractTransformationMapping transformationMapping;
                for (int x = 0; x < transformationMappingsSize; x++) {
                    transformationMapping = (AbstractTransformationMapping)transformationMappings.get(x);
                    transformationMapping.readFromRowIntoObject(transformationRecord, object, query, (oracle.toplink.publicinterface.Session)session);
                }
            }
            oracle.toplink.publicinterface.Descriptor descriptor = session.getDescriptor(this.object);
            if (null == descriptor) {
                XMLContext xmlContext = getUnmarshaller().getXMLContext();
                Session childSession = xmlContext.getSession(this.object);
                descriptor = childSession.getDescriptor(this.object);
            }
            if (descriptor.getEventManager().hasAnyEventListeners()) {
                oracle.toplink.descriptors.DescriptorEvent event = new oracle.toplink.descriptors.DescriptorEvent(this.object);
                event.setSession((oracle.toplink.publicinterface.Session)this.session);
                event.setRow(this);
                event.setEventCode(oracle.toplink.descriptors.DescriptorEventManager.PostBuildEvent);
                descriptor.getEventManager().executeEvent(event);
            }
        } catch (TopLinkException e) {
            if (null == xmlReader.getErrorHandler()) {
                throw e;
            } else {
                SAXParseException saxParseException = new SAXParseException(null, null, null, 0, 0, e);
                xmlReader.getErrorHandler().error(saxParseException);
            }
        }
    }

    public void startPrefixMapping(String prefix, String uri) throws SAXException {
        if (null == namespaceMap) {
            namespaceMap = new HashMap();
        }
        namespaceMap.put(prefix, uri);
    }

    public void endPrefixMapping(String prefix) throws SAXException {
        if (null == namespaceMap) {
            return;
        }
        namespaceMap.remove(prefix);
    }

    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
        try {
            if (null != selfRecords) {
                int selfRecordsSize = selfRecords.size();
                for (int x = 0; x < selfRecords.size(); x++) {
                    ((UnmarshalRecord)selfRecords.get(x)).startElement(namespaceURI, localName, qName, atts);
                }
            }

            XPathNode node = getNonAttributeXPathNode(namespaceURI, localName, qName);
            levelIndex++;
            if (null == node) {
                NodeValue parentNodeValue = xPathNode.getNodeValue();
                if ((null == xPathNode.getXPathFragment()) && (parentNodeValue != null)) {
                    XPathFragment parentFragment = new XPathFragment();
                    if (EMPTY_STRING.equals(namespaceURI)) {
                        parentFragment.setLocalName(qName);
                        parentFragment.setNamespaceURI(null);
                    } else {
                        parentFragment.setLocalName(localName);
                        parentFragment.setNamespaceURI(namespaceURI);
                    }
                    parentNodeValue.startElement(parentFragment, this, atts);
                }
            } else {
                xPathNode = node;
            }

            if (node != null) {
                NodeValue nodeValue = node.getNodeValue();
                if (null != nodeValue) {
                    nodeValue.startElement(xPathFragment, this, atts);
                }

                List attributeChildrenList = attributeChildrenList = xPathNode.getAttributeChildren();
                if (null != attributeChildrenList) {
                    int attributeChildrenListSize = attributeChildrenList.size();
                    XPathNode attributeNode;
                    for (int x = 0; x < attributeChildrenListSize; x++) {
                        attributeNode = (XPathNode)attributeChildrenList.get(x);
                        attributeNode.getNodeValue().startElement(null, this, atts);
                    }
                }
            }
        } catch (TopLinkException e) {
            if (null == xmlReader.getErrorHandler()) {
                throw e;
            } else {
                SAXParseException saxParseException = new SAXParseException(null, null, null, 0, 0, e);
                xmlReader.getErrorHandler().error(saxParseException);
            }
        }
    }

    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
        try {
            if (null != selfRecords) {
                int selfRecordsSize = selfRecords.size();
                for (int x = 0; x < selfRecords.size(); x++) {
                    ((UnmarshalRecord)selfRecords.get(x)).endElement(namespaceURI, localName, qName);
                }
            }

            if (null != xPathNode.getNodeValue()) {
                xPathNode.getNodeValue().endElement(xPathFragment, this);
                if (xPathNode.getParent() != null) {
                    xPathNode = xPathNode.getParent();
                }
            }

            if (null != xPathNode.getParent()) {
                if (EMPTY_STRING.equals(namespaceURI)) {
                    xPathFragment.setLocalName(qName);
                    xPathFragment.setNamespaceURI(null);
                } else {
                    xPathFragment.setLocalName(localName);
                    xPathFragment.setNamespaceURI(namespaceURI);
                }
                if (xPathFragment.qNameEquals(xPathNode.getXPathFragment())) {
                    if (xPathNode.getParent() != null) {
                        xPathNode = xPathNode.getParent();
                    }
                }
            }

            typeQName = null;
            levelIndex--;
            if ((0 == levelIndex) && (null != getParentRecord())) {
                getParentRecord().endElement(namespaceURI, localName, qName);
                xmlReader.setContentHandler(getParentRecord());
            }
        } catch (TopLinkException e) {
            if (null == xmlReader.getErrorHandler()) {
                throw e;
            } else {
                SAXParseException saxParseException = new SAXParseException(null, null, null, 0, 0, e);
                xmlReader.getErrorHandler().error(saxParseException);
            }
        }
    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        try {
            if (null != selfRecords) {
                int selfRecordsSize = selfRecords.size();
                for (int x = 0; x < selfRecords.size(); x++) {
                    ((UnmarshalRecord)selfRecords.get(x)).characters(ch, start, length);
                }
            }

            XPathNode textNode = null;
            if (null != xPathNode.getNonAttributeChildrenMap()) {
                textNode = (XPathNode)xPathNode.getNonAttributeChildrenMap().get(XPathFragment.TEXT_FRAGMENT);
                if (null == textNode) {
                    textNode = (XPathNode)xPathNode.getNonAttributeChildrenMap().get(XPathFragment.ANY_FRAGMENT);
                }
            }
            if (null != textNode) {
                xPathNode = textNode;
            }
            if (null != xPathNode.getNodeValue()) {
                stringBuffer.append(ch, start, length);
            }
        } catch (TopLinkException e) {
            if (null == xmlReader.getErrorHandler()) {
                throw e;
            } else {
                SAXParseException saxParseException = new SAXParseException(null, null, null, 0, 0, e);
                xmlReader.getErrorHandler().error(saxParseException);
            }
        }
    }

    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    }

    public void processingInstruction(String target, String data) throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }

    protected XPathNode getNonAttributeXPathNode(String namespaceURI, String localName, String qName) {
        if (0 == levelIndex) {
            return xPathNode;
        }
        if (EMPTY_STRING.equals(namespaceURI)) {
            xPathFragment.setLocalName(qName);
            xPathFragment.setNamespaceURI(null);
        } else {
            xPathFragment.setLocalName(localName);
            xPathFragment.setNamespaceURI(namespaceURI);
        }

        XPathNode resultNode = null;
        Map nonAttributeChildrenMap = xPathNode.getNonAttributeChildrenMap();
        if (null != nonAttributeChildrenMap) {
            resultNode = (XPathNode)nonAttributeChildrenMap.get(xPathFragment);
            if (null == resultNode) {
                // POSITIONAL MAPPING
                Integer newIndex;
                if (null == this.indexMap) {
                    this.indexMap = new HashMap();
                    newIndex = new Integer(1);
                } else {
                    Integer oldIndex = (Integer)indexMap.get(xPathFragment);
                    if (null == oldIndex) {
                        newIndex = new Integer(1);
                    } else {
                        newIndex = new Integer(oldIndex.intValue() + 1);
                    }
                }
                indexMap.put(xPathFragment, newIndex);
                XPathFragment positionalFragment = new XPathFragment();
                positionalFragment.setNamespaceURI(xPathFragment.getNamespaceURI());
                positionalFragment.setLocalName(xPathFragment.getLocalName());
                positionalFragment.setIndexValue(newIndex.intValue());
                resultNode = (XPathNode)nonAttributeChildrenMap.get(positionalFragment);
                if (null == resultNode) {
                    // ANY MAPPING
                    resultNode = (XPathNode)nonAttributeChildrenMap.get(XPathFragment.ANY_FRAGMENT);
                }
            }
        }
        return resultNode;
    }

    public String resolveNamespacePrefix(String prefix) {
        String namespaceURI = null;
        if (null != namespaceMap) {
            namespaceURI = (String)namespaceMap.get(prefix);
        }
        if (null == namespaceURI) {
            if (null != getParentRecord()) {
                namespaceURI = getParentRecord().resolveNamespacePrefix(prefix);
            }
        }
        return namespaceURI;
    }

    public String toString() {
        StringWriter writer = new StringWriter();
        writer.write(Helper.getShortClassName(getClass()));
        writer.write("()");
        return writer.toString();
    }

    public XMLUnmarshaller getUnmarshaller() {
        return this.unmarshaller;
    }

    public void setUnmarshaller(XMLUnmarshaller unmarshaller) {
        this.unmarshaller = unmarshaller;
    }
}