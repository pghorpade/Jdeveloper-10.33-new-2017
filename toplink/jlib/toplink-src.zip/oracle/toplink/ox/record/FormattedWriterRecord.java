// Copyright (c) 1998, 2005, Oracle. All rights reserved.
package oracle.toplink.ox.record;

import java.io.IOException;
import oracle.toplink.exceptions.XMLMarshalException;
import oracle.toplink.internal.helper.Helper;
import oracle.toplink.internal.ox.XPathFragment;
import oracle.toplink.ox.NamespaceResolver;

/**
 * <p>Use this type of MarshalRecord when the marshal target is a Writer and the
 * XML should be formatted with carriage returns and indenting.</p>
 * <p><code>
 * XMLContext xmlContext = new XMLContext("session-name");<br>
 * XMLMarshaller xmlMarshaller = xmlContext.createMarshaller();<br>
 * FormattedWriterRecord formattedWriterRecord = new FormattedWriterRecord();<br>
 * formattedWriterRecord.setWriter(myWriter);<br>
 * xmlMarshaller.marshal(myObject, formattedWriterRecord);<br>
 * </code></p>
 * <p>If the marshal(Writer) and setFormattedOutput(true) method is called on
 * XMLMarshaller, then the Writer is automatically wrapped in a
 * FormattedWriterRecord.</p>
 * <p><code>
 * XMLContext xmlContext = new XMLContext("session-name");<br>
 * XMLMarshaller xmlMarshaller = xmlContext.createMarshaller();<br>
 * xmlMarshaller xmlMarshaller.setFormattedOutput(true);<br>
 * xmlMarshaller.marshal(myObject, myWriter);<br>
 * </code></p>
 * @see oracle.toplink.ox.XMLMarshaller
 */
public class FormattedWriterRecord extends WriterRecord {
    private static final char[] TAB = "   ".toCharArray();
    private int numberOfTabs;
    private boolean complexType;

    public FormattedWriterRecord() {
        super();
        numberOfTabs = 0;
        complexType = true;
    }

    /**
     * INTERNAL:
     */
    public void startDocument(String encoding, String version) {
        try {
            getWriter().write("<?xml version=\"");
            getWriter().write(version);
            getWriter().write("\" encoding=\"");
            getWriter().write(encoding);
            getWriter().write("\"?>");
        } catch (IOException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
     * INTERNAL:
     */
    public void endDocument() {
        try {
          getWriter().write(Helper.cr());    
        } catch (IOException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
     * INTERNAL:
     */
    public void openStartElement(XPathFragment xPathFragment, NamespaceResolver namespaceResolver) {
        this.addPositionalNodes(xPathFragment, namespaceResolver);
        try {
            if (isStartElementOpen) {
                getWriter().write('>');
            }
            getWriter().write(Helper.cr());
            isStartElementOpen = true;
            for (int x = 0; x < numberOfTabs; x++) {
                getWriter().write(TAB);
            }
            getWriter().write('<');
            getWriter().write(xPathFragment.getShortName());
            numberOfTabs++;
        } catch (IOException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
     * INTERNAL:
     */
    public void element(String namespaceURI, String localName, String qName) {
        try {
            if (isStartElementOpen) {
                getWriter().write('>');
                isStartElementOpen = false;
            }
            getWriter().write(Helper.cr());
            for (int x = 0; x < numberOfTabs; x++) {
                getWriter().write(TAB);
            }
            super.element(namespaceURI, localName, qName);
        } catch (IOException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
     * INTERNAL:
     */
    public void endElement(XPathFragment xPathFragment, NamespaceResolver namespaceResolver) {
        try {
            numberOfTabs--;
            if (isStartElementOpen) {
                getWriter().write('/');
                getWriter().write('>');
                isStartElementOpen = false;
                return;
            }
            if (complexType) {
                getWriter().write(Helper.cr());
                for (int x = 0; x < numberOfTabs; x++) {
                    getWriter().write(TAB);
                }
            } else {
                complexType = true;
            }
            super.endElement(xPathFragment, namespaceResolver);
        } catch (IOException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
     * INTERNAL:
     */
    public void characters(String value) {
        super.characters(value);
        complexType = false;
    }
}