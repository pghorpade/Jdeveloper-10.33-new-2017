// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.ox;

import java.io.*;
import java.util.Enumeration;
import javax.xml.transform.Result;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import oracle.toplink.exceptions.XMLMarshalException;
import oracle.toplink.internal.ox.FragmentContentHandler;
import oracle.toplink.internal.ox.TreeObjectBuilder;
import oracle.toplink.internal.ox.XMLObjectBuilder;
import oracle.toplink.internal.ox.XPathEngine;
import oracle.toplink.internal.ox.XPathFragment;
import oracle.toplink.ox.NamespaceResolver;
import oracle.toplink.ox.XMLConstants;
import oracle.toplink.ox.XMLField;
import oracle.toplink.ox.record.ContentHandlerRecord;
import oracle.toplink.ox.record.DOMRecord;
import oracle.toplink.ox.record.FormattedWriterRecord;
import oracle.toplink.ox.record.MarshalRecord;
import oracle.toplink.ox.record.NodeRecord;
import oracle.toplink.ox.record.WriterRecord;
import oracle.toplink.ox.record.XMLRecord;
import oracle.toplink.ox.schema.XMLSchemaReference;
import oracle.toplink.ox.schema.XMLSchemaURLReference;
import oracle.toplink.platform.xml.XMLPlatform;
import oracle.toplink.platform.xml.XMLPlatformException;
import oracle.toplink.platform.xml.XMLPlatformFactory;
import oracle.toplink.platform.xml.XMLTransformer;
import oracle.toplink.sessions.DatabaseSession;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.ContentHandler;

/**
 * <p>Class used to marshal object to XML.
 *
 * <p>Create an XMLMarshaller from an XMLContext.<br>
 *  <em>Code Sample</em><br>
 *  <code>
 *  XMLContext context = new XMLContext("mySessionName");<br>
 *  XMLMarshaller marshaller = context.createMarshaller();<br>
 *  <code>
 *
 * <p>Objects can be marshalled to the following outputs:<ul>
 * <li>java.io.OutputStream</li>
 * <li>java.io.Writer</li>
 * <li>javax.xml.transform.Result</li>
 * <li>org.w3c.dom.Node</li>
 * <li>org.xml.sax.ContentHandler</li>
 * </ul>
 *
 * <p>Objects that can be marshalled are those which are mapped in the
 * TopLink project associated with the XMLContext, and which are mapped
 * to an XMLDescriptor that has a default root element specified.
 *
 * @see oracle.toplink.ox.XMLContext
 */
public class XMLMarshaller {
    private final static String DEFAULT_XML_ENCODING = "UTF-8";
    private final static String DEFAULT_XML_VERSION = "1.0";
    private String schemaLocation;
    private String noNamespaceSchemaLocation;
    private XMLTransformer transformer;
    private XMLContext xmlContext;

    /**
    * Create a new XMLMarshaller based on the specified session
    * @param session A single session
    */
    public XMLMarshaller(XMLContext xmlContext) {
        this.xmlContext = xmlContext;
        initialize();
    }

    private void initialize() {
        XMLPlatform xmlPlatform = XMLPlatformFactory.getInstance().getXMLPlatform();
        transformer = xmlPlatform.newXMLTransformer();
        setEncoding(DEFAULT_XML_ENCODING);
        setFormattedOutput(true);
    }

    /**
     * Return the instance of XMLContext that was used to create this instance
     * of XMLMarshaller.
     */
    public XMLContext getXMLContext() {
        return xmlContext;
    }

    /**
    * Returns if this XMLMarshaller should format the XML
    * By default this is set to true and the XML marshalled will be formatted.
    * @return if this XMLMarshaller should format the XML
    */
    public boolean isFormattedOutput() {
        return transformer.isFormattedOutput();
    }

    /**
    * Set if this XMLMarshaller should format the XML
    * By default this is set to true and the XML marshalled will be formatted.
    * @param shouldFormat if this XMLMarshaller should format the XML
    */
    public void setFormattedOutput(boolean shouldFormat) {
        transformer.setFormattedOutput(shouldFormat);
    }

    /**
       * Get the encoding set on this XMLMarshaller
       * If the encoding has not been set the default UTF-8 will be used
       * @return the encoding set on this XMLMarshaller
       */
    public String getEncoding() {
        return transformer.getEncoding();
    }

    /**
       * Set the encoding on this XMLMarshaller
       * If the encoding is not set the default UTF-8 will be used
       * @param newEncoding the encoding to set on this XMLMarshaller
       */
    public void setEncoding(String newEncoding) {
        transformer.setEncoding(newEncoding);
    }

    /**
      * Get the schema location set on this XMLMarshaller
      * @return the schema location specified on this XMLMarshaller
      */
    public String getSchemaLocation() {
        return schemaLocation;
    }

    /**
      * Set the schema location on this XMLMarshaller
      * @param newSchemaLocation the schema location to be seton this XMLMarshaller
      */
    public void setSchemaLocation(String newSchemaLocation) {
        schemaLocation = newSchemaLocation;
    }

    /**
      * Get the no namespace schema location set on this XMLMarshaller
      * @return the no namespace schema location specified on this XMLMarshaller
      */
    public String getNoNamespaceSchemaLocation() {
        return noNamespaceSchemaLocation;
    }

    /**
      * Set the no namespace schema location on this XMLMarshaller
      * @param newNoNamespaceSchemaLocation no namespace schema location to be seton this XMLMarshaller
      */
    public void setNoNamespaceSchemaLocation(String newNoNamespaceSchemaLocation) {
        noNamespaceSchemaLocation = newNoNamespaceSchemaLocation;
    }

    /**
    * PUBLIC:
    * Convert the given object to XML and update the given result with that XML Document
    * @param object the object to marshal
    * @param result the result to marshal the object to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public void marshal(Object object, Result result) throws XMLMarshalException {
        if ((object == null) || (result == null)) {
            throw XMLMarshalException.nullArgumentException();
        }

        XMLDescriptor xmlDescriptor = getDescriptor(object);
        if (!xmlDescriptor.shouldPreserveDocument()) {
            if (result instanceof DOMResult) {
                DOMResult domResult = (DOMResult)result;
                marshal(object, domResult.getNode());
            } else if (result instanceof SAXResult) {
                SAXResult saxResult = (SAXResult)result;
                marshal(object, saxResult.getHandler());
            } else {
                StreamResult streamResult = (StreamResult)result;
                Writer writer = streamResult.getWriter();
                if (null == writer) {
                    marshal(object, streamResult.getOutputStream());
                } else {
                    marshal(object, writer);
                }
            }
            return;
        }
        try {
            Document document = objectToXML(object);
            if ((result instanceof SAXResult) && (isFragment())) {
                FragmentContentHandler fragmentHandler = new FragmentContentHandler(((SAXResult)result).getHandler());
                transformer.transform(document, fragmentHandler);
            } else {
                transformer.transform(document, result);
            }
        } catch (XMLPlatformException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to XML and update the given outputStream with that XML Document
    * @param object the object to marshal
    * @param outputStream the outputStream to marshal the object to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public void marshal(Object object, OutputStream outputStream) throws XMLMarshalException {
        if ((object == null) || (outputStream == null)) {
            throw XMLMarshalException.nullArgumentException();
        }
        try {
            OutputStreamWriter writer = new OutputStreamWriter(outputStream, getEncoding());
            marshal(object, writer);
        } catch (UnsupportedEncodingException exception) {
            throw XMLMarshalException.marshalException(exception);
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to XML and update the given writer with that XML Document
    * @param object the object to marshal
    * @param writer the writer to marshal the object to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public void marshal(Object object, Writer writer) throws XMLMarshalException {
        if ((object == null) || (writer == null)) {
            throw XMLMarshalException.nullArgumentException();
        }

        XMLDescriptor xmlDescriptor = getDescriptor(object);
        if (!xmlDescriptor.shouldPreserveDocument()) {
            WriterRecord writerRecord;
            if (isFormattedOutput()) {
                writerRecord = new FormattedWriterRecord();
            } else {
                writerRecord = new WriterRecord();
            }
            writerRecord.setWriter(writer);
            marshal(object, writerRecord);
            try {
                writer.flush();
            } catch (IOException e) {
                throw XMLMarshalException.marshalException(e);
            }
            return;
        }

        try {
            Document xmlDocument = objectToXML(object);
            transformer.transform(xmlDocument, writer);
        } catch (XMLPlatformException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to XML and update the given contentHandler with that XML Document
    * @param object the object to marshal
    * @param contentHandler the contentHandler which the specified object should be marshalled to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public void marshal(Object object, ContentHandler contentHandler) throws XMLMarshalException {
        if ((object == null) || (contentHandler == null)) {
            throw XMLMarshalException.nullArgumentException();
        }

        XMLDescriptor xmlDescriptor = getDescriptor(object);
        if (!xmlDescriptor.shouldPreserveDocument()) {
            ContentHandlerRecord contentHandlerRecord = new ContentHandlerRecord();
            contentHandlerRecord.setContentHandler(contentHandler);
            marshal(object, contentHandlerRecord);
            return;
        }

        try {
            Document xmlDocument = objectToXML(object);
            if (isFragment()) {
                FragmentContentHandler fragmentHandler = new FragmentContentHandler(contentHandler);
                transformer.transform(xmlDocument, fragmentHandler);
            } else {
                transformer.transform(xmlDocument, contentHandler);
            }
        } catch (XMLPlatformException e) {
            throw XMLMarshalException.marshalException(e);
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to XML and update the given node with that XML Document
    * @param object the object to marshal
    * @param node the node which the specified object should be marshalled to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public void marshal(Object object, Node node) throws XMLMarshalException {
        if ((object == null) || (node == null)) {
            throw XMLMarshalException.nullArgumentException();
        }
        try {
            XMLDescriptor xmlDescriptor = getDescriptor(object);
            if (!xmlDescriptor.shouldPreserveDocument()) {
                NodeRecord nodeRecord = new NodeRecord();
                nodeRecord.setDOM(node);

                if ((null == xmlDescriptor.getDefaultRootElement()) && (node.getNodeType() == Node.ELEMENT_NODE) && (xmlDescriptor.getSchemaReference() != null) && (xmlDescriptor.getSchemaReference().getType() == XMLSchemaReference.COMPLEX_TYPE)) {
                    Attr typeAttr = ((Element)node).getAttributeNodeNS(XMLConstants.SCHEMA_INSTANCE_URL, XMLConstants.SCHEMA_TYPE_ATTRIBUTE);
                    if (typeAttr == null) {
                        NamespaceResolver namespaceRsl = xmlDescriptor.getNamespaceResolver();
                        String xsiPrefix = null;
                        if (null == namespaceRsl) {
                            namespaceRsl = new NamespaceResolver();
                            xmlDescriptor.setNamespaceResolver(namespaceRsl);
                        } else {
                            xsiPrefix = namespaceRsl.resolveNamespaceURI(XMLConstants.SCHEMA_INSTANCE_URL);
                        }

                        if (null == xsiPrefix) {
                            xsiPrefix = namespaceRsl.generatePrefix(XMLConstants.SCHEMA_INSTANCE_PREFIX);
                        }

                        String value = xmlDescriptor.getSchemaReference().getSchemaContext();

                        ((Element)node).setAttributeNS(XMLConstants.XMLNS_URL, XMLConstants.XMLNS + ":" + xsiPrefix, XMLConstants.SCHEMA_INSTANCE_URL);
                        ((Element)node).setAttributeNS(XMLConstants.SCHEMA_INSTANCE_URL, xsiPrefix + ":" + XMLConstants.SCHEMA_TYPE_ATTRIBUTE, value);

                    } else {
                        String value = xmlDescriptor.getSchemaReference().getSchemaContext();
                        typeAttr.setValue(value);
                    }
                }

                marshal(object, nodeRecord);
                return;
            }

            //If preserving document, may return the cached doc. Need to 
            //Copy contents of the cached doc to the supplied node.
            Document doc = objectToXML(object);
            DOMResult result = new DOMResult(node);
            transformer.transform(doc, result);
        } catch (Exception exception) {
            if (exception instanceof XMLMarshalException) {
                throw (XMLMarshalException)exception;
            } else {
                throw XMLMarshalException.marshalException(exception);
            }
        }
    }

    /**
     * Convert the given object to XML and update the given marshal record with
     * that XML Document.
     * @param object the object to marshal
     * @param marshalRecord the marshalRecord to marshal the object to
     */
    public void marshal(Object object, MarshalRecord marshalRecord) {
        XMLDescriptor descriptor = getDescriptor(object);

        String rootName = descriptor.getDefaultRootElement();
        XPathFragment rootFragment = null;
        if (null != rootName) {
            rootFragment = new XPathFragment(rootName);
        }

        TreeObjectBuilder treeObjectBuilder = (TreeObjectBuilder)descriptor.getObjectBuilder();
        NamespaceResolver namespaceResolver = descriptor.getNamespaceResolver();

        String xsiPrefix = null;
        if ((null != getSchemaLocation()) || (null != getNoNamespaceSchemaLocation())) {
            if (null == namespaceResolver) {
                namespaceResolver = new NamespaceResolver();
            }
            xsiPrefix = namespaceResolver.resolveNamespaceURI(XMLConstants.SCHEMA_INSTANCE_URL);
            if (null == xsiPrefix) {
                xsiPrefix = XMLConstants.SCHEMA_INSTANCE_PREFIX;
                namespaceResolver.put(XMLConstants.SCHEMA_INSTANCE_PREFIX, XMLConstants.SCHEMA_INSTANCE_URL);
            }
        }

        if (!isFragment()) {
            marshalRecord.startDocument(getEncoding(), DEFAULT_XML_VERSION);
        }

        DatabaseSession session = xmlContext.getSession(object);

        Enumeration prefixes;
        if (null != rootFragment) {
            if (null != namespaceResolver) {
                prefixes = namespaceResolver.getPrefixes();
                String prefix;
                String uri;
                while (prefixes.hasMoreElements()) {
                    prefix = (String)prefixes.nextElement();
                    uri = namespaceResolver.resolveNamespacePrefix(prefix);
                    marshalRecord.startPrefixMapping(prefix, uri);
                }
            }

            marshalRecord.openStartElement(rootFragment, namespaceResolver);

            if (null != getSchemaLocation()) {
                marshalRecord.attribute(XMLConstants.SCHEMA_INSTANCE_URL, "schemaLocation", xsiPrefix + ":schemaLocation", getSchemaLocation());
            }
            if (null != getNoNamespaceSchemaLocation()) {
                marshalRecord.attribute(XMLConstants.SCHEMA_INSTANCE_URL, "noNamespaceSchemaLocation", xsiPrefix + ":noNamespaceSchemaLocation", getNoNamespaceSchemaLocation());
            }

            treeObjectBuilder.marshalAttributes(marshalRecord, object, session);
            marshalRecord.namespaceDeclarations(namespaceResolver);
            marshalRecord.closeStartElement();
        }

        treeObjectBuilder.buildRow(marshalRecord, object, (oracle.toplink.publicinterface.Session)session, this);

        if (null != rootFragment) {
            marshalRecord.endElement(rootFragment, namespaceResolver);

            if (null != namespaceResolver) {
                prefixes = namespaceResolver.getPrefixes();
                while (prefixes.hasMoreElements()) {
                    marshalRecord.endPrefixMapping((String)prefixes.nextElement());
                }
            }
        }
        if (!isFragment()) {
            marshalRecord.endDocument();
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to an XML Document
    * @param object the object to marshal
    * @return the document which the specified object has been marshalled to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public Document objectToXML(Object object) throws XMLMarshalException {
        XMLDescriptor descriptor = getDescriptor(object);

        String rootName = descriptor.getDefaultRootElement();
        if (null == rootName) {
            throw XMLMarshalException.defaultRootElementNotSpecified(descriptor);
        }

        if (descriptor.shouldPreserveDocument()) {
            XMLRecord xmlRow = (XMLRecord)descriptor.getObjectBuilder().createRecord();
            return objectToXML(object, descriptor, xmlRow);
        } else {
            MarshalRecord marshalRecord = new NodeRecord();
            marshal(object, marshalRecord);
            return marshalRecord.getDocument();
        }
    }

    /**
    * PUBLIC:
    * Convert the given object to descendants of the parent element
    * @param object the object to marshal
    * @param parent the node to marshal the object to
    * @return the document which the specified object has been marshalled to
    * @throws XMLMarshalException if an error occurred during marshalling
    */
    public Document objectToXML(Object object, Node parent) throws XMLMarshalException {
        XMLDescriptor descriptor = getDescriptor(object);

        String localRootName = descriptor.getDefaultRootElement();
        if (null == localRootName) {
            throw XMLMarshalException.defaultRootElementNotSpecified(descriptor);
        }

        if (descriptor.shouldPreserveDocument()) {
            XMLRecord xmlRow = (XMLRecord)((XMLObjectBuilder)descriptor.getObjectBuilder()).createRecord(localRootName, parent);
            return objectToXML(object, descriptor, xmlRow);
        } else {
            MarshalRecord marshalRecord = new NodeRecord(localRootName, parent);
            marshal(object, marshalRecord);
            return marshalRecord.getDocument();
        }
    }

    /**
    * INTERNAL:
    * Convert the given object to an XML Document
    */
    public Document objectToXML(Object object, XMLDescriptor descriptor, XMLRecord xmlRow) {
        xmlRow = (XMLRecord)descriptor.getObjectBuilder().buildRow(xmlRow, object, (oracle.toplink.publicinterface.Session)xmlContext.getSession(object));
        Document document = xmlRow.getDocument();
        addSchemaLocations(document);
        return document;
    }

    public void addSchemaLocations(Document document) {
        Element docElement = document.getDocumentElement();

        NamespaceResolver resolver = new NamespaceResolver();
        resolver.put(XMLConstants.XMLNS, XMLConstants.XMLNS_URL);
        resolver.put(XMLConstants.SCHEMA_INSTANCE_PREFIX, XMLConstants.SCHEMA_INSTANCE_URL);

        if ((getSchemaLocation() != null) || (getNoNamespaceSchemaLocation() != null)) {
            XMLField field = new XMLField("@xmlns:xsi");
            field.setNamespaceResolver(resolver);
            XPathEngine.getInstance().create(field, docElement, XMLConstants.SCHEMA_INSTANCE_URL);
        }
        if (getSchemaLocation() != null) {
            XMLField field = new XMLField("@xsi:schemaLocation");
            field.setNamespaceResolver(resolver);
            XPathEngine.getInstance().create(field, docElement, getSchemaLocation());
        }
        if (getNoNamespaceSchemaLocation() != null) {
            XMLField field = new XMLField("@xsi:noNamespaceSchemaLocation");
            field.setNamespaceResolver(resolver);
            XPathEngine.getInstance().create(field, docElement, getNoNamespaceSchemaLocation());
        }
    }

    /**
    * INTERNAL:
    * Return the descriptor for the root object.
    */
    protected XMLDescriptor getDescriptor(Object object) throws XMLMarshalException {
        XMLDescriptor descriptor = (XMLDescriptor)xmlContext.getSession(object).getDescriptor(object);

        if (descriptor == null) {
            throw XMLMarshalException.descriptorNotFoundInProject(object.getClass().getName());
        }

        return descriptor;
    }

    /**
    * PUBLIC:
    * Set if this should marshal to a fragment.  If true an XML header string is not written out.
    * @param fragment if this should marshal to a fragment or not
    */
    public void setFragment(boolean fragment) {
        transformer.setFragment(fragment);
    }

    /**
    * PUBLIC:
    * Returns if this should marshal to a fragment.  If true an XML header string is not written out.
    * @return if this should marshal to a fragment or not
    */
    public boolean isFragment() {
        return transformer.isFragment();
    }
}