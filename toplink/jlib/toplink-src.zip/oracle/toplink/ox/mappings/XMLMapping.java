// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.ox.mappings;


/**
 * INTERNAL
 * All mappings which can be added to oracle.toplink.ox.XMLDescriptor must
 * implement this interface.
 *
 *@see oracle.toplink.ox.mappings
 */
public interface XMLMapping {
}