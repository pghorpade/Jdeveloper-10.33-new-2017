package oracle.adf.controller.jsp.taglib;

import java.util.HashMap;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletContext;

import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.context.ServletFactoryFinder;
import oracle.adf.controller.v2.lifecycle.LifecycleProcessor;
import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.controller.v2.lifecycle.PageLifecycleFactory;


/**
 * JSP tag use to support the ADF Lifecycle in a "Model 1" application.
 * This tag is typically placed at the top of a JSP using ADFm bindings and 
 * execute the ADF Lifecycle before the rest of the page is rendered.
 * 
 * @since 10.1.3
 */
public class PageDefinitionTag extends TagSupport 
{
   public PageDefinitionTag()
   {
   }

   public int doStartTag() throws JspException
   {
      ServletContext servletContext = (ServletContext) pageContext.getServletContext();

      try
      {
         // Retrieve the default PageLifecycle factory using the Servlet finder.
         // Depending on the environment the PageLifecycle could be for Model 1,
         // Struts or JSF.
         PageLifecycleFactory pageLifecycleFactory = (PageLifecycleFactory)
            ServletFactoryFinder.PAGELIFECYCLE_FACTORY.getFactory(servletContext);
         
         // Instanciate the PageLifecycle
         PageLifecycle pageLifecycle = pageLifecycleFactory.getPageLifecycle();

         // Initialize the environment map.
         // The Lifecycle context will be created during the execute of the 
         // Lifecycle
         HashMap envMap = new HashMap();
         envMap.put(LifecycleContext.PAGE_LIFECYCLE_KEY,
                    pageLifecycle);

         // Here we go...
         LifecycleProcessor.getInstance().execute(envMap);
      }
      catch (Exception e)
      {
         pageContext.getServletContext().log("Error during lifecycle", e);
         throw new JspTagException(e);
      }
      
     return TagSupport.EVAL_PAGE;
   }
}

