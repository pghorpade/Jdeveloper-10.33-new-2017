package oracle.adf.controller.lifecycle;

import javax.servlet.ServletContext;

import oracle.jbo.common.JBOClass;

/**
 * A factory to create PageLifecycle instances.
 * <p>Subclass PageLifecycleFactory to create your own PageLifecycleFactory and
 * provide alternate {@link PageLifecycle} instance to all web page.
 * Specify your PageLifecycleFactory subclass in the web-xml file using the
 * ADFPageLifecycleFactory init param:</p>
 * <pre>
 * &lt;web-app&gt;
 * &nbsp;&nbsp;&lt;context-param&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-name&gt;ADFPageLifecycleFactory&lt;/param-name&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-value&gt;mypackage.myLifecycleFactory&lt;/param-value&gt;
 * &nbsp;&nbsp;&lt;/context-param&gt;
 * &nbsp;&nbsp;...
 * &lt;/web-app&gt;
 * </pre>
 * 
 * <p>If no alternate PageLifecycleFactory is defined in the web-xml, the
 * default is to use {@link DefaultPageLifecycleFactory}.
 * 
 * @since 9.0.5
 */
public abstract class PageLifecycleFactory 
{
   /**
    * Name of the servlet context init parameter used to defined a customize
    * PageLifecycleFactory. The value of this parameter is the fully qualified
    * class name of the new factory.
    */
   public static final String INIT_PARAM = "ADFPageLifecycleFactory";
   
   /**
    * Name of the servlet context attribute used to save the instance of the
    * LifecycleFactory for this web application.
    */
   public static final String LIFECYCLE_FACTORY_ATTR = "oracle.adf.controller.PageLifecycleFactory";
   
   protected PageLifecycleFactory()
   {
      
   }
   
   /**
    * Helper method to instanciate the factory given the ServletContext. The
    * ServletContext possibly contain the class name of a sustitued factory as
    * the value an init parameter named "ADFPageLifecycleFactory". Once the 
    * factory class is determined, the instance is cached as a parameter of the
    * servlet context.
    * 
    * @param servletContext
    * @return the instance
    */
   public static PageLifecycleFactory getInstance(ServletContext servletContext)
   {
      if (servletContext == null)
      {
         return null;
      }
      
      // Default PageLifecycleFactory instance is store in the application
      // context.
      PageLifecycleFactory instance = (PageLifecycleFactory) 
                           servletContext.getAttribute(LIFECYCLE_FACTORY_ATTR);
      if (instance != null)
      {
         return instance;
      }
      
      // Retrieve the default instance class name from the web.xml initparam
      String factoryClassName = servletContext.getInitParameter(PageLifecycleFactory.INIT_PARAM);

      if (factoryClassName != null && factoryClassName.trim().length() > 0)
      {
         try
         {
            Class cls = JBOClass.forName(factoryClassName);
            instance = (PageLifecycleFactory) cls.newInstance();
         }
         catch (Exception ex)
         {
            servletContext.log("Error instanciating custom PageLifecycleFactory. Using default...", ex);
         }
      }

      // Last resort, use the default instance
      if (instance == null)
      {
         instance = new DefaultPageLifecycleFactory();
      }

      // Store it in the application context
      servletContext.setAttribute(LIFECYCLE_FACTORY_ATTR, instance);
      
      return instance;
   }
   
   /**
    * Return a PageLifecycle for given a page path.
    * The customized lifecycle should subclass PageLifecycle to support the
    * base functionality.
    * The page path give the flexibility of returning a different lifecycle for
    * different type of web page like jsp, xml or uix.
    * 
    * @param path the web page path
    * @return     a customized PageLifecycle 
    */
   public abstract PageLifecycle getPageLifecycle(String path);

}
