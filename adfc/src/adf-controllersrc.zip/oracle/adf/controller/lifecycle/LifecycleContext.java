package oracle.adf.controller.lifecycle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCCachingErrorHandler;
import oracle.adf.model.binding.DCErrorHandler;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.uicli.binding.JUCtrlActionBinding;

/**
 * <CODE>LifecycleContext</CODE> contains all the state information that will
 * be kept during the Lifecycle. It is passed as a method parameter to each
 * of the phases of the {@link oracle.adf.controller.lifecycle.Lifecycle}.
 * Since it extends the HashMap class it can be use to append additional user
 * data.
 * 
 * <p>This context object lives for the duration of the current lifecycle.
 * 
 * <p><b>NOTE:</b> Implementations of 
 * {@link oracle.adf.controller.lifecycle.Lifecycle} should be thread-safe
 * and use the <CODE>LifecycleContext</CODE> object as the place
 * to store any per-request state they may need.
 * 
 * @since 9.0.5
 */
public class LifecycleContext extends HashMap 
{
   /**
    * The default value to be used by the lifecycle to reconize
    * an event in a parameter name.
    */
   public static final String EVENT_PREFIX = "event";
   
   /**
    * Prefix used for each event method.
    */
   public static final String EVENT_METHOD_PREFIX = "on";
   
   private static final String LIFECYCLE_KEY = "lifecycle";
   private static final String MODEL_REFERENCE_KEY = "modelref";
   private static final String BINDING_CONTEXT_KEY = "bindingContext";
   private static final String BINDING_CONTAINER_KEY = "bindingContainer";
   private static final String CUSTOM_METHOD_KEY = "customMethod";
   private static final String CONTROL_ACTION_BINDINGS_KEY = "controlActionBindings";
   private static final String ACTION_BINDING_KEY = "actionBinding";
   private static final String EVENT_PREFIX_KEY = "event";
   private static final String EVENTS_KEY = "events";
   private static final String FORWARD_PATH_BINDINGS_KEY = "forwardPath";
   private static final String REDIRECT_BINDINGS_KEY = "redirect";
   private static final String REQUEST_KEY = "request";
   private static final String RESPONSE_KEY = "response";

   public LifecycleContext()
   {
   }
   
   /**
    * Initialize the context with the Lifecycle it is going to be use with and
    * the request and response information.
    * @param lifecycle the lifecycle
    * @param request the current HttpServletRequest
    * @param response the current HttpServletResponse
    */
   public void initialize(Lifecycle           lifecycle,
                          HttpServletRequest  request,
                          HttpServletResponse response)
   {
      initialize(lifecycle, null, request, response);   
   }
   
   /**
    * Initialize the context with the name of the model reference to be use
    * during this Lifecycle.
    * 
    * @param lifecycle The lifecycle object in use for the current request.
    * @param modelRef The name of the UIModel to use for the binding container
    * @param request The current HTTP request object
    * @param response The current HTTP response object
    */
   public void initialize(Lifecycle           lifecycle,
                          String              modelRef,
                          HttpServletRequest  request,
                          HttpServletResponse response)
   {
      setLifecycle(lifecycle);
      
      if (modelRef != null)
      {
         setModelReference(modelRef);
      }
      
      setHttpServletRequest(request);
      setHttpServletResponse(response);
      
      // Set default value for the event prefix
      setEventPrefix(EVENT_PREFIX);
      
      /* Retrieve the Model binding context of the current application
       * from the Session.
       */ 
      final BindingContext bctx = DCUtil.getBindingContext(request);
      if (bctx == null)
      {
         throw new RuntimeException("Model binding context not initialized");
      }
      // Store it in the context
      setBindingContext(bctx);
      
      final String model = getModelReference();
      if (model != null && model.length() > 0)
      {
         DCBindingContainer bindings = DCUtil.findBindingContainer(bctx, model);
         // Store in context for later use.
         setBindingContainer(bindings);
      }
      
      // Tell the Model error handler to go in caching mode
      setErrorHandlerCachingMode(bctx, true);
   }
   
   /**
    * Store a Lifecycle object in the context.
    * @param lifeCycle Lifecycle object to use for the current request.
    */
   public void setLifecycle(Lifecycle lifeCycle)
   {
      put(LIFECYCLE_KEY, lifeCycle);
   }
   
   /**
    * Retrieve the Lifecycle from the context.
    * @return Lifecycle object in use for the current request.
    */
   public Lifecycle getLifecycle()
   {
      return (Lifecycle) get(LIFECYCLE_KEY);
   }

   /**
    * Store the HttpServletRequest in the context.
    * @param request Current HTTP Request object.
    */
   public void setHttpServletRequest(HttpServletRequest request)
   {
      put(REQUEST_KEY, request);
   }
   
   /**
    * Retrieve the HttpServletRequest from the context.
    * @return the HttpServletRequest
    */
   public HttpServletRequest getHttpServletRequest()
   {
      return (HttpServletRequest) get(REQUEST_KEY);
   }

   /**
    * Store the HttpServletResponse in the context.
    * @param response Current HTTP response object.
    */
   public void setHttpServletResponse(HttpServletResponse response)
   {
      put(RESPONSE_KEY, response);
   }
   
   /**
    * Retrieve the HttpServletResponse from the context.
    * @return the HttpServletResponse
    */
   public HttpServletResponse getHttpServletResponse()
   {
      return (HttpServletResponse) get(RESPONSE_KEY);
   }

   /**
    * Store the BindingContext in the context.
    * @param bindingContext BindingContext in use for the current request.
    */
   public void setBindingContext(BindingContext bindingContext)
   {
      put(BINDING_CONTEXT_KEY, bindingContext);
   }
   
   /**
    * Retrieve the BindingContext from the context.
    * @return the BindingContext object
    */
   public BindingContext getBindingContext()
   {
      return (BindingContext) get(BINDING_CONTEXT_KEY);
   }
   
   /**
    * Store the Model Reference name in the context.
    * @param modelRef the model reference
    */
   public void setModelReference(String modelRef)
   {
      put(MODEL_REFERENCE_KEY, modelRef);
   }
   
   /**
    * Retrieve the ModelReference name property from the context.
    * @return the modelReference
    */
   public String getModelReference()
   {
      return (String) get(MODEL_REFERENCE_KEY);
   }
   
   /**
    * Store the Model binding container in the context.
    * @param bindings Binding container to use for the current request.
    */
   public void setBindingContainer(DCBindingContainer bindings)
   {
      put(BINDING_CONTAINER_KEY, bindings);
   }
   
   /**
    * Retrieve the Model binding container from the context.
    * @return Binding container in use by the current request.
    */
   public DCBindingContainer getBindingContainer()
   {
      return (DCBindingContainer) get(BINDING_CONTAINER_KEY);
   }

   /**
    * Set the custom method Action binding in the context.
    * @param actionBinding Action binding object to call during current request.
    */
   public void setCustomMethod(JUCtrlActionBinding actionBinding)
   {
      put(CUSTOM_METHOD_KEY, actionBinding);
   }
   
   /**
    * Retrieve the custom method Action binding from the context.
    * @return Action binding to be called during current request.
    */
   public JUCtrlActionBinding getCustomMethod()
   {
      return (JUCtrlActionBinding) get(CUSTOM_METHOD_KEY);
   }
   
   /**
    * Set the ActionBinding for the current event. This is used internally to
    * prepare the context before calling the event handler.
    * @param action Action binding to invoke as the event's default action.
    */
   public void setEventActionBinding(JUCtrlActionBinding action)
   {
      put(ACTION_BINDING_KEY, action);
   }

   /**
    * Retrieve the ActionBinding associated with the current event. This is
    * usefull when you overide the handler for a specific event because it
    * allows you to execute the associated ActionBinding. The default handler
    * always execute the ActionBinding.
    * <p>
    * Here is an example for an event named Commit:
    * <pre>
    * public void onCommit(LifecycleContext ctx)
    * {
    *    // write pre-execution logic here
    *    
    *    ctx.getEventActionBinding().doit();
    *    
    *    // write post-execution logic here
    * }
    * </pre>
    * <p>
    * Return null is no ActionBinding is associated with this event.
    * 
    * @return a JUCtrlActionBinding
    */
   public JUCtrlActionBinding getEventActionBinding()
   {
      return (JUCtrlActionBinding) get(ACTION_BINDING_KEY);
   }

   /**
    * <p>Set the prefix that will be used to reconize event request parameters.
    * To change the default prefix "event", call this method with a different 
    * prefix every time the lifecycle context is initialized.</p>
    * 
    * <p>?event=xxx
    * <p>name="event_xxx"
    * 
    * @param prefix  the new prefix string 
    * @see           #EVENT_PREFIX
    */
   public void setEventPrefix(String prefix)
   {
      put(EVENT_PREFIX_KEY, prefix);
   }
   
   /**
    * Retrieve the event prefix from the context.
    * @return  the prefix string
    * @see     #EVENT_PREFIX
    */
   public String getEventPrefix()
   {
      return (String) get(EVENT_PREFIX_KEY);
   }
   
   /**
    * This method add an action binding to the collection of action being
    * executed. Each action binding is keyed by an event name.
    * 
    * @param event an event name
    * @param actionBinding the action binding to be associated with the event
    */
   public void addControlActionBinding(String event, 
                                       JUCtrlActionBinding actionBinding)
   {
      Map actionBindings = getControlActionBindings();
      
      if (actionBindings == null)
      {
         actionBindings = new HashMap();
         put(CONTROL_ACTION_BINDINGS_KEY, actionBindings);
      }

      actionBindings.put(event, actionBinding);
   }

   /**
    * Retrieve a list of all action binding keyed by event name.
    * @return Map of control action bindings 
    */
   public Map getControlActionBindings()
   {
      return (Map) get(CONTROL_ACTION_BINDINGS_KEY);
   }
   
   /**
    * Add an event name to the list of event to be handled during this
    * lifecycle.
    * 
    * @param event an event name
    */
   public void addEvent(String event)
   {
      List events = getEvents();
      
      if (events == null)
      {
         events = new ArrayList();
         put(EVENTS_KEY, events);
      }
      
      events.add(event);
   }
   
   /**
    * Retrieve the list of event names to be handled during this lifecycle.
    * @return List of event names to be handled.
    * @see     PageLifecycle#buildEventList(LifecycleContext)
    */
   public List getEvents()
   {
      return (List) get(EVENTS_KEY);
   }

   /**
    * Set the path of the page to which the Lifecycle should forward.
    * @param path Relative path of next page.
    * @see        PageLifecycle#findForward(LifecycleContext)
    * @see        #setRedirect
    */
   public void setForwardPath(String path)
   {
      if (path != null)
      {
         path = path.trim();
      }
      put(FORWARD_PATH_BINDINGS_KEY, path);
   }
   
   /**
    * Retrieve the path of the page that the Lifecycle will forward to.
    * @return Path of next page
    * @see     PageLifecycle#findForward(LifecycleContext)
    */
   public String getForwardPath()
   {
      return (String) get(FORWARD_PATH_BINDINGS_KEY);
   }

   /**
    * Specify if the page path information defined using the setForwardPath
    * should be use to forward the request or redirect the response.
    * @param redirect   a boolean
    * @see              #setForwardPath
    * @see              PageLifecycle#findForward(LifecycleContext)
    */
   public void setRedirect(boolean redirect)
   {
      put(REDIRECT_BINDINGS_KEY, redirect ? "true" : "false");
   }

   /**
    * Retrieve the redirect setting from the context.
    * @return  the value of the redirect flag.
    * @see     #setRedirect
    */
   public boolean getRedirect()
   {
      String redirect = (String)get(REDIRECT_BINDINGS_KEY);
      if (redirect != null && redirect.equalsIgnoreCase("true"))
      {
         return true;
      }
      
      return false;
   }
   
   /**
    * Set the Model error handler caching mode. When the caching mode is true
    * Any error ocurring on the model is cached instead of being thrown. The
    * error can be later treated.
    */
   private void setErrorHandlerCachingMode(BindingContext bctx, boolean mode)
   {
      DCErrorHandler handler = bctx.getErrorHandler();
      if (handler instanceof DCCachingErrorHandler)
      {
         ((DCCachingErrorHandler) handler).setThrowFlag(!mode);
      }
      
   }

}