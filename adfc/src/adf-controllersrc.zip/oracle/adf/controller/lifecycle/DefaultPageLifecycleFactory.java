package oracle.adf.controller.lifecycle;

/**
 * The default factory for PageLifecycle.
 * Always return an instance of {@link PageLifecycle}.
 * 
 * @since 9.0.5
 */
public class DefaultPageLifecycleFactory extends PageLifecycleFactory 
{
   /** Singleton PageLifecycle instance */
   private static PageLifecycle DEFAULT_JSP_LIFECYCLE;
   
   // Static block to instanciate the singleton in a threadsafe way
   static
   {
      DEFAULT_JSP_LIFECYCLE = new PageLifecycle();
   }
   
   
  /**
   * Always return an instance of PageLifecycle no mater the content of the page
   * path.
   */
   public PageLifecycle getPageLifecycle(String path)
   {
      return DEFAULT_JSP_LIFECYCLE;
   }
}