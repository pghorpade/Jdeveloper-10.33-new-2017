package oracle.adf.controller.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.JboException;
import oracle.jbo.common.Diagnostic;
import oracle.jbo.mom.PropertyNameValueDef;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

import oracle.jbo.uicli.binding.JUCtrlValueDef;
import oracle.ord.im.OrdHttpUploadFile;
import oracle.ord.im.OrdMultipartWrapper;

/**
 * <p>Implementation of the Lifecycle for web pages.
 * It provide the base functionality that is extended when used with a
 * controller like Jakarta Struts.
 * See {@link oracle.adf.controller.struts.actions.StrutsPageLifecycle
 * StrutsPageLifecycle}.</p>
 * <p>When used without a controller, each JSP require to add a tag 
 * <pre>&lt;adf:uimodelreference model="pageUIModel" /&gt;</pre> at the top
 * of the page to bootstrap the page lifecycle and define the binding
 * container associated with the page.</p>
 *
 * @since 9.0.5
 */
public class PageLifecycle implements Lifecycle
{
   /**
    * Cache the set of event methods as they are introspected.
    */
   protected Map events = new HashMap();
   
   /**
    * The Class instance for this class (PageLifecycle).
    */
   protected Class clazz = this.getClass();
   
   /**
    * The set of argument type classes for the reflected event method call.
    */
   protected Class eventParam[] = { LifecycleContext.class };
   
   /**
    * A custom input handler used by bindings dealing with ord domain type
    */
   public static final String ordDomainInputHandlerName = "OrdDomainInputHandler";
   
   /**
    * A request-level property used to disable the token validation. token validation 
    * should only occur once per http request.
    */
   public static final String DISABLE_VALIDATE_TOKENS = "ADFDisableValidateTokens";
   
   /**{@inheritDoc}.
    * This is the entry point to execute the all the phases of the lifecycle.<br>
    * Overide this method to add logic before or after the lifecycle execution.
    * <p>
    * Define the steps of the PageLifecycle processing:
    * <ul>
    *   <li>prepares the context and build the event list</li>
    *   <li>prepare the model for updates</li>
    *   <li>process model updates</li>
    *   <li>performs validation</li>
    *   <li>process component event</li>
    *   <li>process custom method</li>
    *   <li>handles errors</li>
    * </ul>
    */
   public void handleLifecycle(LifecycleContext lcContext)
      throws Exception
   {
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      final Lifecycle lifecycle = lcContext.getLifecycle();

      // Prepare SPEL engine to evaluate expressions
      Evaluator.prepareContext(lcContext);

      try
      {
         // Build the list of event from the request parameters
         lifecycle.buildEventList(lcContext);

         // Give the model the opportunity to prepare.
         lifecycle.prepareModel(lcContext);

         if (bindings != null)
         {
            if (lifecycle.shouldAllowModelUpdate(lcContext))
            {
               // Invoke model updates
               lifecycle.processUpdateModel(lcContext);
               
               // Force model-level validation
               lifecycle.validateModelUpdates(lcContext);
            }
         } //endif (bindings != null)         

         // if there are errors in the bindingContext, then return.
         if (!lifecycle.hasErrors(lcContext))
         {
           // Handle any component events from the request.  this step calls
           // any model methods that were invoked.  It also calls any UI event
           // methods (for UIX); therefore, this method must be called even if
           // there is no bindingContainer:
           lifecycle.processComponentEvents(lcContext);
         }

         if (bindings != null)
         {
            if (!lifecycle.hasErrors(lcContext))
            {
               // Invoke any action that this action
               lifecycle.invokeCustomMethod(lcContext);
            }

            if (!lifecycle.hasErrors(lcContext))
            {
               // Last, notify the model update are over with.
               lifecycle.refreshModel(lcContext);
            }
         }
      }
      catch (Exception ex)
      {
         lifecycle.handleError(lcContext, ex);
      }
      finally
      {
         lifecycle.reportErrors(lcContext);
      }
      
      if (bindings != null)
      {
         // publish the binding container as 'bindings' via the request object
         // this has now been removed from the page.
         DCUtil.setBindingContainer(lcContext.getHttpServletRequest(),
                                    bindings);
      }
            
      // The findForward need to be executed after the binding container is
      // published because in the model 1 case, the findForward possibly
      // forwards the request or redirect the response.
      lifecycle.findForward(lcContext);

      // Cleanup SPEL context
      Evaluator.destroy(lcContext);
   }

   /**{@inheritDoc}
    * 
    * <p>If you need to set bind variable values on query objects in
    * the business services layer in order to properly prepare the model,
    * then you can set them by overriding this method and doing it 
    * <b>before</b> calling the superclass.
    * 
    * <p>If you need to reference prepared model values and/or update
    * the values of any bindings in the binding container, then you
    * can do it by overriding this method and doing it <b>after</b>
    * calling the superclass.
    */
   public void prepareModel(LifecycleContext lcContext)
      throws Exception
   {
      // Register input handler to the binding context.
      final BindingContext bctx = lcContext.getBindingContext();  
      JUCtrlInputValueHandler inputHandler = (JUCtrlInputValueHandler)
         bctx.getBindingInputHandler(ordDomainInputHandlerName);
      if (inputHandler == null)
      {
         inputHandler = new OrdDomainInputHandler();

         // Initialize default InputHandler here
         HashMap inputHandlerMap = new HashMap(2);
         inputHandlerMap.put(ordDomainInputHandlerName, inputHandler);
         bctx.setBindingInputHandlers(inputHandlerMap);
      }
      
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      
      if (bindings != null)
      {
         final HttpServletRequest request = lcContext.getHttpServletRequest();  
   
         bindings.refreshControl();
                  
         if (shouldValidateToken(request, bindings))
         {
            disableTokenValidationForRequest(request);
            
            bindings.validateToken(request.getParameter(bindings.getStateTokenId()));
         }
      }
   }

   /**
    * Token validation will only occur once-per-request. This function will disable token
    * validation for the given request.
    * @param request
    */
   protected void disableTokenValidationForRequest(HttpServletRequest request)
   {
      request.setAttribute(DISABLE_VALIDATE_TOKENS, "notnull"); //NOTRANS
   }
   
   /**
    * Checks the request object to see if token validation should occur. 
    * 
    * @param request
    * @param bindings
    * @return true if token validation should occur
    */
   protected boolean shouldValidateToken(HttpServletRequest request, DCBindingContainer bindings)
   {
      if(request.getAttribute(DISABLE_VALIDATE_TOKENS) != null)
         return false;
         
      String state = request.getParameter(bindings.getStateTokenId());
      
      if (state != null && bindings.isTokenValidationEnabled())  
         return true;
         
      return false;
   }
   
   /**{@inheritDoc}
    * <p>
    * Collect the new values from request parameters and update the model with
    * them. Only new values are set to the bindings.
    */
   public void processUpdateModel(LifecycleContext lcContext)
   {
      Map values = getRequestValues(lcContext);
      updateModel(lcContext, values);
   }
   
   
   /**
    * Apply each new values to the binding. The values are coming from a Map of
    * values keyed by property name.
    * In case of error the method setInputValue will not throw but instead the
    * errors will be collected in the binding container.
    * 
    * @param lcContext     the lifecycle context
    * @param updatedValues the map of values keyed by property name
    * @see                 #getRequestValues
    */
   protected void updateModel(LifecycleContext lcContext, Map updatedValues)
   {
      if (updatedValues == null || updatedValues.size() == 0)
      {
         return;
      }
      
      final HttpServletRequest request = lcContext.getHttpServletRequest();
      final DCBindingContainer bindings = lcContext.getBindingContainer();

      // In case of multipart request, the inputHandler need to be set
      String contentType = request.getContentType();
      if ((contentType != null) && 
          contentType.startsWith("multipart/form-data") &&
          request.getMethod().equalsIgnoreCase("POST")) 
      {
         final Iterator iter = updatedValues.keySet().iterator();
         while(iter.hasNext())
         {
            String propertyName = (String) iter.next();
   
            JUCtrlValueBinding binding = (JUCtrlValueBinding)
               bindings.findCtrlBinding(propertyName);
   
            // For backward compatibility with 9.0.5.x we need to handle
            // the case where custom handler are not set at design time
            // through a property of the binding.
            JUCtrlValueDef def = (JUCtrlValueDef) binding.getDef();
            if (!def.hasCustomInputHandler())
            {
               // Set the inputHandler dynamically based on the type of the
               // value.
               if (updatedValues.get(propertyName) instanceof OrdHttpUploadFile)
               {
                  final BindingContext bctx = lcContext.getBindingContext();  
  
                  binding.setInputValueHandler((JUCtrlInputValueHandler)
                    bctx.getBindingInputHandler(ordDomainInputHandlerName));
               }
            }
         }
      }

      bindings.processInputValues(updatedValues);
   }
  
   /**
    * Return <code>true</code> if the value is different from the current value
    * of the binding.
    * @param binding the value binding to test
    * @param value   the new value for this binding
    * @return <code>true</code> if the value is new
    * @deprecated Use InputHandler.
    */
   protected boolean isNewValueForBinding(JUCtrlValueBinding binding,
                                          Object value)
   {
      return false;
   }
   
   /**
    * Sets the value to the binding.
    * @param binding the binding that will receive the value
    * @param value   the value to set to the binding
    * @deprecated Use InputHandler.
    */
   protected void setInputValue(JUCtrlValueBinding binding, Object value)
   {
   }
   
   /**
    * Returns all the submited ADF values from the request parameters. The
    * result is a Map of values keyed by property names.<br>
    * Only the request parameters with a specific syntax are reconized as
    * property name for a value binding (see {@link DCUtil#isValueBindingPath}).
    * 
    * @param lcContext  the lifecycle context
    * @return           a Map of binding names and their new values
    */
   protected Map getRequestValues(LifecycleContext lcContext)
   {
      HttpServletRequest request    = lcContext.getHttpServletRequest();
      boolean            isMultipart = (request instanceof OrdMultipartWrapper);
      Enumeration        paramNames;
      Map                pendingValues = null;
      
      // If the request is multipart, process all the file type parameters 
      if (isMultipart)
      {
         paramNames = ((OrdMultipartWrapper) request).getFileParameterNames();
         pendingValues = getRequestValues(request, paramNames, true,
                                          pendingValues);
      }
      
      // In either case, the non file type parameter need to be processed
      paramNames = request.getParameterNames();
      pendingValues = getRequestValues(request, paramNames, false,
                                       pendingValues);
      
      return pendingValues;
   }
   
   private Map getRequestValues(HttpServletRequest request, 
                                Enumeration paramNames,
                                boolean isFile,
                                Map pendingValues)
   {
      // Iterate through all parameters.
      while (paramNames.hasMoreElements())
      {
         final String name = (String) paramNames.nextElement();
         // Make sure the parameter name has the correct syntax.
         if (!DCUtil.isValueBindingPath(name))
         {
            continue;
         }

         Object[] paramValues;
         
         if (isFile)
         {
            paramValues =
                   ((OrdMultipartWrapper) request).getFileParameterValues(name);   
         }
         else
         {
            paramValues = request.getParameterValues(name);   
         }

         if (paramValues != null && paramValues.length > 0)
         {
            if (pendingValues == null)
            {
               pendingValues = new HashMap();
            }

            // Store new value keyed by binding name.
            pendingValues.put(DCUtil.getValueBindingNameFromPath(name),
                              paramValues[0]);
         }
      }
      
      return pendingValues;
   }
   
   /**{@inheritDoc}.
    * <p>
    * Disable data model updates in two cases:
    * <ul>
    *   <li>When specific action like 'rollback' will be executed during the
    *   lifecycle. This is done by calling the ignoreUpdates method or each 
    *   action in the event list. The custom method ignoreUpdates is also
    *   called.</li>
    *   <li>When the binding container of the previous page does not match.
    *   This is to get around the case where updates from the previous page in
    *   the forward chain are applied.</li>
    * </ul>
    * Bypassing update might be necessary for operations such as rollback or
    * custom methods that want to veto the change.<br>
    * Overide this method if you need to add logic to skip data model updates.
    * @see JUCtrlActionBinding#ignoreUpdates
    */
   public boolean shouldAllowModelUpdate(LifecycleContext lcContext)
   {
      // Treat the built-in method coming in through the request parameters first
      final Map actionBindings = lcContext.getControlActionBindings();
      if (actionBindings != null)
      {
         for (Iterator iter = actionBindings.values().iterator(); iter.hasNext(); )
         {
            JUCtrlActionBinding action = (JUCtrlActionBinding) iter.next();
            if (action.ignoreUpdates())
               return false;
         }
      }

      // Only allow update if the binding container is the same.
      DCBindingContainer previousBinding = DCUtil.getBindingContainer(
                                             lcContext.getHttpServletRequest());
      if ( previousBinding != null)
      {
         final DCBindingContainer bindings = lcContext.getBindingContainer();
         if (!previousBinding.getName().equals(bindings.getName()))
         {
            return false;
         }
      }
      
      return true;
   }
   
   /**{@inheritDoc}
    * To delay model-level validation until Commit, override this method
    * and replace it with a no-op.
    */
   public void validateModelUpdates(LifecycleContext lcContext)
   {
      lcContext.getBindingContainer().validateInputValues();
   }

   // Inherit javadoc from interface.
   public void processComponentEvents(LifecycleContext lcContext)
      throws Exception
   {
      final List events = lcContext.getEvents();
      if (events != null)
      {
         for (Iterator iter = events.iterator(); iter.hasNext(); )
         {
            handleEvent(lcContext, (String) iter.next());
         }
      }
   }
   
   /**
    * Handle an event.
    * An event handler can be a method defined in a subclass of this
    * PageLifecycle. To be recognized as an event handle the method need to
    * have the following syntax:
    * <pre>
    * public void on<b>Event</b>(LifecycleContext ctx)
    * {
    *    // Use the following method to execute the possible
    *    // action binding associated with this event
    *    ctx.getEventActionBinding().doit();
    * }
    * </pre>
    * Where <b>Event</b> is the name of the event.
    * <p>
    * An event can also be an action binding with the same name of the event
    * present in the current binding container.
    * @param lcContext  the lifecycle context
    * @param event      the name of the event to handle
    * @return <code>true</code> if the event was mapped to an action binding
    * @throws java.lang.Exception
    * @see              #buildEventList buildEventList
    * @see              LifecycleContext#EVENT_METHOD_PREFIX
    */
   protected boolean handleEvent(LifecycleContext lcContext, String event)
      throws Exception
   {
      final HttpServletRequest request = lcContext.getHttpServletRequest();
      final HttpServletResponse response = lcContext.getHttpServletResponse();
      
      // Always uppercase the first letter. Format is "onEvent"
      String eventName = LifecycleContext.EVENT_METHOD_PREFIX +
                         event.substring(0, 1).toUpperCase() +
                         event.substring(1);
      
      // Identify the method object of the event to call
      Method eventMethod = lcContext.getLifecycle().getEventMethod(lcContext, eventName);
      if (eventMethod == null)
      {
         boolean isOk = invokeActionBinding(lcContext, event);
         
         if (!isOk)
         {
            if (Diagnostic.isOn())
            {
               Diagnostic.println("Warning: No Method " + eventName +
                                  " and no actionBinding " + event + " found.");
            }
         }
         
         return isOk;
      }

      try
      {
         Map actions = lcContext.getControlActionBindings();
         if (actions != null)
         {
            lcContext.setEventActionBinding((JUCtrlActionBinding) actions.get(event));
         }

         Object args[] = { lcContext };
         eventMethod.invoke(lcContext.getLifecycle(), args);
      }
      catch (ClassCastException e)
      {
         String message = "Invalid return type for method " + eventName;

         request.getSession().getServletContext().log(message);
         response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                            message);

         return false;
      }
      catch (IllegalAccessException e)
      {
         String message = "Exception return from method " + eventName;

         request.getSession().getServletContext().log(message);
         response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                            message);

         return false;
      }
      catch (InvocationTargetException e)
      {
         Throwable t = e.getTargetException();
         if (t instanceof Exception)
         {
            // Re-throw the original exception to be catch using the
            // existing framework.
            throw ((Exception) t);
         }
         else
         {
            String message = "Exception running method " + eventName;
            request.getSession().getServletContext().log(message);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                               message);
         }

         return false;
      }

      return true;
   }
   
   /**{@inheritDoc}
    */
   public Method getEventMethod(LifecycleContext lcContext, String name)
   {
      return PageLifecycle.getEventMethodFromCache(events, clazz, eventParam, name);
   }
   
   /**
    * In model 1 we do not have a way to initialize method parameters.
    * In the action binding the user can change the name of the parameters.
    * This function will iterate through the parameter names in the action
    * binding and look for request parameters that match those names.
    * This transfer of values allows us to pass in request parameters that
    * match the action binding's parameter names.
    * 
    * @param lcContext     the lifecycle context
    * @param actionBinding the action binding to initialize
    */
   protected void initializeParameterValuesUsingRequestObject(
                                          LifecycleContext lcContext,
                                          JUCtrlActionBinding actionBinding)
   {
      final DCInvokeMethodDef methodDef = actionBinding.getInvokeMethodDef();

      if (methodDef == null || methodDef.getParameters() == null)
         return;
      
      final int numParams = methodDef.getParameters().length;
      
      // see if we have request parameters that match method parameters
      OperationParameter paramDefs[] = methodDef.getParameters();
      
      ArrayList params = new ArrayList();
      
      for(int i = 0; i < paramDefs.length; i++)
      {
         String sParamName = paramDefs[i].getName();
         String sValue = lcContext.getHttpServletRequest().getParameter(sParamName);
         
         if(sValue != null)
         {
            params.add(sValue);
         }
      }
      
      if ( params.size() == numParams)
      {
         actionBinding.setParams(params);
      }      
   }
   
   // Inherit javadoc from interface.
   public void initializeMethodParameters(LifecycleContext lcContext,
                                          JUCtrlActionBinding actionBinding)
   {
      initializeParameterValuesUsingRequestObject(lcContext, actionBinding);
   }

   /**
    * Invoke the action binding associated with the event name. An action
    * binding is associated with an event if an action binding with the same
    * name as the event exist in the current binding container. If the action
    * binding exist, the method parameters are initialized using the 
    * {@link #initializeMethodParameters initializeMethodParameters} method on
    * the lifecycle before executing the action binding.<br>
    * If the action binding exist the method return <code>true</code>
    * @param lcContext  the lifecycle context
    * @param event      the name of the event
    * @return           <code>true</code> if an action binding is associated
    *                    with the event
    */
   public boolean invokeActionBinding(LifecycleContext lcContext,
                                      String event)
   {
      Map actions = lcContext.getControlActionBindings();
      if (actions == null)
      {
         return false;
      }

      JUCtrlActionBinding action = (JUCtrlActionBinding) actions.get(event);
      if (action != null)
      {
         // Call the initializeMethodParameters through the dataAction
         // class to give the opportunity to the user to overwrite it...
         lcContext.getLifecycle().initializeMethodParameters(lcContext, action);

         // Execute the action.
         action.doIt();
         
         return true;
      }
      
      return false;
   }

   // Inherit javadoc from interface.
   public void invokeCustomMethod(LifecycleContext lcContext)
   {
      // No-op
   }
   
   // Inherit javadoc from interface.
   public boolean hasErrors(LifecycleContext lcContext)
   {
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      boolean hasErrors = false;
      
      if (bindings != null)
         hasErrors = hasErrors(bindings);

      return hasErrors;
   }
   
   // Inherit javadoc from interface.
   public void refreshModel(LifecycleContext lcContext)
   {
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      // Last, notify the bindingContainer that model update are over with.
      bindings.refreshControl();
   }
   
   /**{@inheritDoc}.
    * Clients have an opportunity to merge the exception with the model
    * errors stored in the binding container.
    */
   public void handleError(LifecycleContext lcContext, Exception ex)
   {
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      
      if (bindings != null)
      {
         JboException jboEx;
         if (ex instanceof JboException)
         {
            jboEx = (JboException) ex;
         }
         else
         {
            jboEx = new JboException(ex);
         }
             
         bindings.processException(jboEx);
      }
   }

   // Inherit javadoc from interface.
   public void reportErrors(LifecycleContext lcContext)
   {
      // No-op
   }

   /**{@inheritDoc}
    * Possible events are request parameters named "event" or which name are
    * prefixed with "event_". If there are parameters named "event" each of
    * their values are event names. If the parameter name starts with "event_",
    * the following part of  the name is the event name. (i.e "event_Next" will
    * add the event called "Next").
    * <p>The "event" prefix can be modified using
    * {@link LifecycleContext#setEventPrefix setEventPrefix}
    * 
    * <p>By doing this once and storing the result in the lifecycle context we
    * don't have to walk through the request parameter list multiple time during
    * the lifecycle.</p>
    * 
    * @see LifecycleContext#addControlActionBinding addControlActionBinding
    * @see LifecycleContext#getControlActionBindings getControlActionBindings
    * @see LifecycleContext#addEvent addEvent
    * @see LifecycleContext#getEvents getEvents
    */
    public void buildEventList(LifecycleContext lcContext)
    {
      final HttpServletRequest request = lcContext.getHttpServletRequest();
      final Enumeration paramNames = request.getParameterNames();
      final String eventPrefix = lcContext.getEventPrefix();
      final String eventPrefixUnder = eventPrefix + "_";

      // Iterate through all parameters.
      while (paramNames.hasMoreElements())
      {
         final String param = (String)paramNames.nextElement();

         // Check if param is an event
         if (eventPrefix.equals(param))
         {
            String[] values = request.getParameterValues(param);
            for (int i = 0; i < values.length; i++)
            {
               processEvent(lcContext, values[i]);
            }
         }
         // Check the second possible syntax for events: "event_xxx"
         else if (param.startsWith(eventPrefixUnder))
         {
            processEvent(lcContext, param.substring(eventPrefixUnder.length()));
         }
         // This is for backward compatibility wih old syntax
         else if (DCUtil.isActionBindingPath(param))
         {
            final BindingContext data = lcContext.getBindingContext();

            String[] values = request.getParameterValues(param);
            // Fix 2994755
            // ensure parameter has a value before invoking the method
            // otherwise empty parameters will incorrectly trigger method invocation
            if (values != null && values.length > 0 &&
                values[0] != null && values[0].length() > 0)
            {
               JUCtrlActionBinding actionBinding =
                  DCUtil.getActionBinding(data, param, DCUtil.SEP_SLASH_CHAR);

               if (actionBinding == null)
               {
                  if (Diagnostic.isOn())
                  {
                     Diagnostic.println("Warning: Method with path:\n" + param +
                    "\ncannot be executed because binding container does not match.");
                  }
               }
               else
               {
                  String event = actionBinding.getName();
                  // Add the action binding to the list of executed actions
                  lcContext.addControlActionBinding(event, actionBinding);
                  lcContext.addEvent(event);
               }
            }
         }
      }
   }
   
   /**
    * Process a possible raw event coming as a request parameter.
    * This method handle the case where the request parameter is produced
    * from an image control where the parameter name represent the coordinate
    * of the mouse when clicked on the image.
    * This also make sure an event is not executed multiple time when the
    * request is forwarded.
    * @param lcContext  the lifecycle context
    * @param event      the event name
    */
   protected void processEvent(LifecycleContext lcContext, String event)
   {
      final HttpServletRequest request = lcContext.getHttpServletRequest();
      
      // Event name is empty, that's a dud.
      if (event.length() == 0)
      {
         return;
      }

      // Image type control returns coordinate parameters 
      if (event.endsWith(".x") || event.endsWith(".y"))
      {
         event = event.substring(0, event.length() - 2);
         List events = lcContext.getEvents();
         // Do not add the event twice when dealing with image (.x and .y)
         if (events != null && events.contains(event))
         {
            return;
         }
      }
      
      // If this event is marked as already being executed from a previous
      // forward, don't add it to the list.
      if (request.getAttribute("adf_handled_"+event) != null)
      {
         return;
      }
      
      // Add this event to the list
      lcContext.addEvent(event);
      
      // Add the event to the request to know not to execute them again
      request.setAttribute("adf_handled_"+event, event);
      
      // Look if there is a binding associated with the event
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      if (bindings != null)
      {
         DCControlBinding actionBinding = findCtrlBinding(bindings, event);
         if (actionBinding != null)
         {
            lcContext.addControlActionBinding(event,
                                           (JUCtrlActionBinding)actionBinding);
         }
      }
   }

   /**
    * Look action binding with the name 'name' or 'Name'
    *
    * @param bindings the binding container
    * @param event    the event name
    * @return the databinding for event, null if not found
    */
   protected DCControlBinding findCtrlBinding(DCBindingContainer bindings,
                                              String event)
   {
      DCControlBinding actionBinding = bindings.findCtrlBinding(event);
      
      // If we did not find a binding with this name try the same name with 
      // the opposite case for the first letter.
      if (actionBinding == null ||
          !(actionBinding instanceof JUCtrlActionBinding))
      {
         char letter = event.charAt(0);
         String newEvent;
         
         // Switch the case of the first letter 
         if (Character.isUpperCase(letter))
         {
            newEvent = event.substring(0, 1).toLowerCase();
         }
         else if (Character.isLowerCase(letter))
         {
            newEvent = event.substring(0, 1).toUpperCase();
         }
         else
         {
            return null;
         }

         newEvent += event.substring(1);

         // and try it again
         actionBinding = bindings.findCtrlBinding(newEvent);

         if (actionBinding == null ||
             !(actionBinding instanceof JUCtrlActionBinding))
         {
            return null;
         }
      }

      return actionBinding;
   }

   /**{@inheritDoc}.
    * The path of the next web page is identified using the forwardPath
    * property on the LifecycleContext.
    * If the redirect property on the LifecycleContext is true, the response
    * will be redirected to the specified path.
    * Otherwise, the request will be forwarded to the specified path.
    */
   public void findForward(LifecycleContext lcContext)
      throws Exception
   {
      String path = lcContext.getForwardPath();
      if (path != null)
      {
         HttpServletRequest request = lcContext.getHttpServletRequest();
         HttpServletResponse response = lcContext.getHttpServletResponse();

         if (lcContext.getRedirect())
         {
            if (path.charAt(0) == '/')
            {
               path = request.getContextPath() + path;
            }
            
            response.sendRedirect(response.encodeRedirectURL(path));
         }
         else
         {
            RequestDispatcher rd = request.getSession().getServletContext().
                                                        getRequestDispatcher(path);
                                                        
            if (rd == null)
            {
               response.sendError(
                   HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                   "No request dispatcher for " + path);
               return;
            }
   
            rd.forward(request, response);
         }
         
      }
   }
   
   private boolean hasErrors(DCBindingContainer container)
   {
      if (container == null)
      {
         return false;
      }
      
      List runtimeErrors = container.getExceptionsList();
      if(runtimeErrors != null && runtimeErrors.size() > 0)
      {
         return true;
      }
         
      return false;
   }

   /**
    * <b>Internal</b>
    */
   public static final Method getEventMethodFromCache(Map events,
                                                      Class clazz,
                                                      Class eventParams[],
                                                      String eventName)
   {
      synchronized (events)
      {
         Method event;
         
         // To differentiate between entry in the table and entry with null
         // value, look if the key is there first
         if (events.containsKey(eventName))
         {
            // The key is there, return the method (that possibly is null)
            event = (Method) events.get(eventName);
         }
         else
         {
            try
            {
               event = clazz.getMethod(eventName, eventParams);
            }
            catch (NoSuchMethodException ex)
            {
               // Store the fact that the method does not exist so we don't
               // introspect again.
               event = null;
            }

            events.put(eventName, event);
         }
         
         return event;
      }
   }
}
