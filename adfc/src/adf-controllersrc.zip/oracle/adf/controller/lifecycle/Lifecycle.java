package oracle.adf.controller.lifecycle;

import java.lang.reflect.Method;

import oracle.jbo.uicli.binding.JUCtrlActionBinding;

/**
 * The ADF Lifecycle provides support allowing a web page to interact with
 * ADF Model data bindings. The lifecycle calls the correct binding container
 * needed for a JSP or UIX page, updates values in the binding container's
 * bindings if necessary, and prepares the data to be rendered. The binding
 * container stores this data locally before rendering the page. 
 * 
 * <p><b>NOTE:</b> Implementations of <CODE>Lifecycle</CODE> should be
 * thread-safe and use the 
 * {@link oracle.adf.controller.lifecycle.LifecycleContext} object as the place
 * to store any per-request state they may need.
 * 
 * @since 9.0.5
 */

public interface Lifecycle 
{
   /**
    * Define all the phases of the lifecycle and the order they are executed.
    * 
    * @param lcContext  the lifecycle context
    * @throws Exception
    */
   void handleLifecycle(LifecycleContext lcContext)
      throws Exception;

   /**
    * Builds the list of events with their possible associated action binding
    * from the request parameters.
    * @param lcContext  the lifecycle context
    */
   void buildEventList(LifecycleContext lcContext);

   /**
    * Give the opportunity for the data model to prepare and initialize.
    * This method will throw if the data model cannot be prepared. 
    * @param lcContext  the lifecycle context
    */
   void prepareModel(LifecycleContext lcContext)
      throws Exception;

   /**
    * Allows clients to determine whether the model should be updated.
    * @param lcContext  the lifecycle context.
    * @return           <code>true</code>, if the model should be updated
    *                   during this lifecycle
    */  
   boolean shouldAllowModelUpdate(LifecycleContext lcContext);

   /**
    * Update the data model with values submitted in the request.
    * @param lcContext  the lifecycle context
    */
   void processUpdateModel(LifecycleContext lcContext);

   /**
    * Forces model-level validation to occur.
    * @param lcContext  the lifecycle context
    */
   void validateModelUpdates(LifecycleContext lcContext);
      
   /**
    * Ask the context if any errors have been recorded during this lifecycle.
    * @param lcContext  the lifecycle context
    * @return           <code>true</code>, if any validation errors have been
    *                   stored in the LifecycleContext.
    */
   boolean hasErrors(LifecycleContext lcContext);
      
   /**
    * Handle any events in the action binding list previously built in
    * processUpdateModel using the buildEventList method.
    * 
    * @param lcContext  the lifecycle context
    * @throws Exception
    */
   void processComponentEvents(LifecycleContext lcContext)
      throws Exception;
      
   /**
    * This method is invoked before any ControlBinding or custom method is
    * being executed. Overriding this method gives an opportunity to set the
    * parameters.
    * 
    * @param lcContext     the lifecycle context
    * @param actionBinding the action binding object to initialize
    */
   void initializeMethodParameters(LifecycleContext lcContext,
                                   JUCtrlActionBinding actionBinding);

   /**
    * Invokes the custom method associated with the binding container.
    * @param lcContext  the lifecycle context
    */
   void invokeCustomMethod(LifecycleContext lcContext);

   /**
    * Used to notify the model when updates are over with.
    * @param lcContext  the lifecycle context
    */
   void refreshModel(LifecycleContext lcContext);

   /**
    * Handles any exceptions that occurred during the Lifecycle processing.
    * @param lcContext  the lifecycle context
    * @param ex         the exception to record
    */
   void handleError(LifecycleContext lcContext, Exception ex);

   /**
    * Report the error list to the view layer.
    * @param lcContext  the lifecycle context
    */
   void reportErrors(LifecycleContext lcContext);
   
   /**
    * Forwards the request or redirects the response to the next web page
    * in the flow.
    * @param lcContext  the lifecycle context
    * @throws Exception
    */
   void findForward(LifecycleContext lcContext)
      throws Exception;
      
   /**
    * Retrieve the Method class for an event name.
    * @param lcContext  the lifecycle context
    * @param name       name of the event
    * @return           the Method object for this event if exist
    */
   Method getEventMethod(LifecycleContext lcContext, String name);
}
