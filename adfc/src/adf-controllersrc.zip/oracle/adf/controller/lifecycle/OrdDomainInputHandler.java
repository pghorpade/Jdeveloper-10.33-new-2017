package oracle.adf.controller.lifecycle;

import java.io.IOException;

import oracle.adf.model.binding.DCUtil;

import oracle.jbo.JboException;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

import oracle.ord.im.OrdHttpUploadFile;


public class OrdDomainInputHandler implements  JUCtrlInputValueHandler
{
   public OrdDomainInputHandler(){}

   public void setInputValue(JUCtrlValueBinding binding, int index, Object value)
   {
      OrdHttpUploadFile fileValue  = (OrdHttpUploadFile)value;
      value = getOrdObject(fileValue , binding);
      if (value == null)
      {
         return;
      }

      binding.setInputValue(binding, index, value);
   }

   private Object getOrdObject(OrdHttpUploadFile file,
                               JUCtrlValueBinding binding)
   {
      if (file != null)
      {
         String filename = file.getOriginalFileName();
      
         if (filename.length() > 0 && file.getContentLength() >= 0)
         {
            try
            {
               return DCUtil.getOrdObject(file.getInputStream(),
                                          file.getMimeType(),
                                          binding);
            }
            catch (IOException e)
            {
               throw new JboException(e);
            }
         }
      }

      return null;
   }

   public boolean isNewInputValue(JUCtrlValueBinding binding, int index, Object value)
   {
      if (binding != null)
      {
         return true;
      }
      return false;
   }
}

