package oracle.adf.controller.lifecycle;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.el.ELException;
import javax.servlet.jsp.el.VariableResolver;

import oracle.jsp.el.OracleExpression;
import oracle.jsp.el.OracleExpressionEvaluator;

/**
 * Helper class used by the PageLifecycle to initialize SPEL expression engine.
 * The following scopes are made available:
 * <UL>
 *  <LI><b>data</b>: the top binding context to access all the binding 
 *      containers.</LI>
 *  <LI><b>bindings</b>: the current binding container for this lifecycle to
 *      access all of its bindings.</LI>
 *  <LI><b>requestScope</b>: [Same as JSTL], request attributes.</LI>
 *  <LI><b>param</b>: [Same as JSTL], request parameters.</LI>
 *  <LI><b>paramValues</b>: [Same as JSTL], request parameter values.</LI>
 *  <LI><b>sessionScope</b>: [Same as JSTL], session attributes.</LI>
 * </UL>
 *
 * This is used for evaluating custom method's parameters and results.
 * 
 *  @since 9.0.5
 */
public class Evaluator
{
   private static final String EVALUATOR = "evaluator";
   private OracleExpressionEvaluator mEvaluator;
   private Map                       mMap;
   private MapResolver               mMapResolver;
   private LifecycleContext          lcContext;
   private boolean                   isInitialized;


   private Evaluator(LifecycleContext lcContext)
   {
      // Lazy context initialization
      // Only initialize member variable but defer the creation of the context
      // until it is really needed.
      this.lcContext = lcContext;
      isInitialized = false;
   }
   
   private void init()
   {
      mEvaluator = new OracleExpressionEvaluator();
      mMap = new HashMap();
   
      mMap.put("data", lcContext.getBindingContext());
      //TODO: do we need to create session here?
      final HttpServletRequest request = lcContext.getHttpServletRequest();  
      
      mMap.put("sessionScope", new SessionMap(request.getSession(true)));
      // Updates Evaluator with the latest request scope maps.
      mMap.put("bindings", lcContext.getBindingContainer());
      mMap.put("requestScope", new RequestMap(request));
      mMap.put("param", new RequestParameterMap(request));
      mMap.put("paramValues", new RequestParameterValuesMap(request));

      mMapResolver = new MapResolver();
      isInitialized = true;
   }

   /*
   * Initializes SPEL engine.
   * <CEG> We do not want to initialize the context here, just prepare it
   * for a later possible initialization. This is because initialization is
   * time consumming and only necessary if there is something to evaluate
   */
   public static final void prepareContext(LifecycleContext lcContext)
   {
      lcContext.put(EVALUATOR, new Evaluator(lcContext));
   }


   public static final Evaluator getEvaluator(LifecycleContext lcContext)
   {
      Evaluator se = (Evaluator)lcContext.get(EVALUATOR);
      
      if ( se != null && !se.isInitialized )
      {
         se.init();
      }

      return se;
   }

   public static final void destroy(LifecycleContext lcContext)
   {
      Evaluator se = (Evaluator)lcContext.get(EVALUATOR);

      if ( se != null )
      {
         se.isInitialized = false;
      }
   }

   public Object getValue(String expression)
   {
      if ( expression == null )
      {
         return null;
      }

      Object value = null;
      
      try
      {
         OracleExpression expr = (OracleExpression)mEvaluator.
            parseExpression(expression, Object.class, null);
         value = expr.evaluate(mMapResolver);
      }
      catch ( ELException ex )
      {
         //TODO: report exception
      }
      return value;
   }
   

   public void setValue(String expression, Object value)
   {
      try
      {
         OracleExpression expr = (OracleExpression)mEvaluator.
            parseExpression(expression, Object.class, null);
         expr.setValue(mMapResolver, value);
      }
      catch ( ELException ex )
      {
         //TODO: report exception
      }
   }


   private class MapResolver implements VariableResolver
   {
      /*
      * Resolves the specified variable within the given context.
      * Returns null if the variable is not found.
      * @param   name  variable name
      * @return  Object the object corresponding to the variable name, or
      * null if no object was found.
      */
      public Object resolveVariable(String name) throws ELException
      {
         return mMap.get(name);
      }
   }

   class RequestMap implements Map
   {
      private HttpServletRequest request = null;
      
      public RequestMap(HttpServletRequest request)
      {
         this.request = request;
      }
      
      public void clear()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsKey(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsValue(Object value)
      {
         throw new UnsupportedOperationException();
      }
      
      public Set entrySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object get(Object key)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         return request.getAttribute(key.toString());
      }
      
      public int hashCode()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean isEmpty()
      {
         throw new UnsupportedOperationException();
      }
      
      public Set keySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object put(Object key, Object value)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         String keyString = key.toString();
         Object result = request.getAttribute(keyString);
         request.setAttribute(keyString, value);
         return (result);
      }
      
      public void putAll(Map map)
      {
         throw new UnsupportedOperationException();
      }
      
      public Object remove(Object key)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         String keyString = key.toString();
         Object result = request.getAttribute(keyString);
         request.removeAttribute(keyString);
         return (result);
      }
      
      public int size()
      {
         throw new UnsupportedOperationException();
      }

      public Collection values()
      {
         throw new UnsupportedOperationException();
      }
   }

   class SessionMap implements Map
   {
      private HttpSession session = null;
      
      public SessionMap(HttpSession session)
      {
         this.session = session;
      }
      
      public void clear()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsKey(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsValue(Object value)
      {
         throw new UnsupportedOperationException();
      }
      
      public Set entrySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object get(Object key)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         return session.getAttribute(key.toString());
      }
      
      public int hashCode()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean isEmpty()
      {
         throw new UnsupportedOperationException();
      }
      
      public Set keySet()
      {
         throw new UnsupportedOperationException();
      }

      public Object put(Object key, Object value)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         String keyString = key.toString();
         Object result = session.getAttribute(keyString);
         session.setAttribute(keyString, value);
         return (result);
      }
      
      public void putAll(Map map)
      {
         throw new UnsupportedOperationException();
      }
      
      public Object remove(Object key)
      {
         if (key == null) {
            throw new NullPointerException();
         }
         String keyString = key.toString();
         Object result = session.getAttribute(keyString);
         session.removeAttribute(keyString);
         return (result);
      }

      public int size()
      {
         throw new UnsupportedOperationException();
      }
      
      public Collection values()
      {
         throw new UnsupportedOperationException();
      }
   }

   class RequestParameterMap implements Map
   {
      private HttpServletRequest request = null;
      
      public RequestParameterMap(HttpServletRequest request)
      {
         this.request = request;
      }
      
      public void clear()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsKey(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsValue(Object value)
      {
         throw new UnsupportedOperationException();
      }
      
      public Set entrySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object get(Object key)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         return request.getParameter(key.toString());
      }
      
      public int hashCode()
      {
         throw new UnsupportedOperationException();
      }

      public boolean isEmpty()
      {
         throw new UnsupportedOperationException();
      }
      
      public Set keySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object put(Object key, Object value)
      {
        throw new UnsupportedOperationException();
      }
      
      public void putAll(Map map)
      {
         throw new UnsupportedOperationException();
      }
      
      public Object remove(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public int size()
      {
         throw new UnsupportedOperationException();
      }
      
      public Collection values()
      {
         throw new UnsupportedOperationException();
      }
   }
   
   class RequestParameterValuesMap implements Map
   {
      private HttpServletRequest request = null;
      
      public RequestParameterValuesMap(HttpServletRequest request)
      {
         this.request = request;
      }
      
      public void clear()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsKey(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean containsValue(Object value)
      {
         throw new UnsupportedOperationException();
      }
      
      public Set entrySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object get(Object key)
      {
         if (key == null)
         {
            throw new NullPointerException();
         }
         return request.getParameterValues(key.toString());
      }
      
      public int hashCode()
      {
         throw new UnsupportedOperationException();
      }
      
      public boolean isEmpty()
      {
        throw new UnsupportedOperationException();
      }
      
      public Set keySet()
      {
         throw new UnsupportedOperationException();
      }
      
      public Object put(Object key, Object value)
      {
         throw new UnsupportedOperationException();
      }

      public void putAll(Map map)
      {
         throw new UnsupportedOperationException();
      }
      
      public Object remove(Object key)
      {
         throw new UnsupportedOperationException();
      }
      
      public int size()
      {
         throw new UnsupportedOperationException();
      }
      
      public Collection values()
      {
         throw new UnsupportedOperationException();
      }
   }  
}

