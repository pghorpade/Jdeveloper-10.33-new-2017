package oracle.adf.controller.struts.forms;

import java.io.Serializable;

import java.util.HashMap;
import java.util.List;

import oracle.adf.model.binding.DCBindingContainer;

import oracle.binding.AttributeBinding;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.commons.beanutils.DynaProperty;

/**
 * A Struts DynaClass specialized in exposing all the value bindings of the 
 * associated binding container as dynamic properties.
 * 
 * @since 9.0.5
 */
public class ADFDynaClass implements DynaClass, Serializable
{
   private String    bindingContainerName;
   private HashMap   properties = new HashMap();
   
   public ADFDynaClass(DCBindingContainer container)
   {
      if (container == null)
         return;
         
      bindingContainerName = container.getName();
      
      List attrBindings = container.getAttributeBindings();
      for(int i = 0; i < attrBindings.size(); i++)
      {
         AttributeBinding attrBinding = (AttributeBinding) attrBindings.get(i); 
         DynaProperty property = new DynaProperty(attrBinding.getName(), attrBinding.getClass());
         properties.put(property.getName(), property);
         
         // Get the VB_<name> to also be valid. This is to handle adf:Render and 
         // adf:InputRender tags placed inside a Struts form.
         property = new DynaProperty(attrBinding.getPath(), attrBinding.getClass());
         properties.put(property.getName(), property);
      }
   }

   public String getName()
   {
      return bindingContainerName;
   }

   public DynaProperty getDynaProperty(String sName)
   {
      return (DynaProperty) properties.get(sName);
   }

   public DynaProperty[] getDynaProperties()
   {
      DynaProperty props[] = new DynaProperty[properties.size()];
      
      return (DynaProperty[]) properties.values().toArray(props);
   }

   public DynaBean newInstance()
      throws IllegalAccessException, InstantiationException
   {
      // Not supported
      return null;
   }
}
