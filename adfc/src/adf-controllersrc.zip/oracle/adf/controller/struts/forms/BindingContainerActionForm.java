package oracle.adf.controller.struts.forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.struts.actions.DataActionMapping;
import oracle.adf.controller.struts.forms.ADFStrutsForm;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCUtil;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * ActionForm exposing all the binding values of a binding container as the
 * properties of a JavaBeans.
 * 
 * @since 9.0.5
 */
public class BindingContainerActionForm extends ActionForm
   implements DynaBean, ADFStrutsForm
{
   /**
    * The name of the current binding container this class is exposing.
    */
   protected String bindingContainerName;

   /**
    * The ADFDynaClass with which we are associated.
    */
   transient protected ADFDynaClass     dynaClass;
   protected final Map dynaValues = new HashMap();
   
   /**
    * The bindingcontext in the session
    */
   transient protected BindingContext bindingContext;
   
   /**
    * A flag used to determine if the updates should be applied
    */
   boolean ignoreUpdate;
   
   public BindingContainerActionForm()
   {   
   }
   
   /**
    * @deprecated The BindingContainer is now deduced from the action mapping
    * modelRef property.
    */
   public void setBindingContainer(DCBindingContainer container)
   {
   }
   
   protected DCBindingContainer getBindingContainer()
   {
      if (bindingContainerName == null || bindingContext == null)
      {
         return null;
      }
      
      return bindingContext.findBindingContainer(bindingContainerName);
   }
   
   // ADFStrutsForm interface implementation
   public Map getPendingValues()
   {
      return dynaValues;   
   }
   
   public void resetPendingValues()
   {
      dynaValues.clear();   
   }
   
   public Object get(String name)
   {
      if (dynaValues.containsKey(name))
      {
         return dynaValues.get(name);
      }
      
      final DCBindingContainer bindings = getBindingContainer();
      if (bindings == null)
         return "##error##" + name;

      if (name.equals("bindings"))
         return bindings;
      
      DCControlBinding binding = bindings.findCtrlBinding(name);
      if (binding == null)
      {
        if (DCUtil.isValueBindingPath(name))
        {
           name = DCUtil.getValueBindingNameFromPath(name);
           binding = bindings.findCtrlBinding(name);
        }
        if (binding == null)
           return "Unknown binding name:" + name;
      }  
      return binding;
   }
   
   public boolean contains(String name, String key)
   {
      return false;
   }

   public Object get(String name, int index)
   {
      //Not supported
      return null;
   }

   public Object get(String name, String key)
   {
      //Not supported
      return null;
   }

   public DynaClass getDynaClass()
   {
      if (dynaClass == null)
      {
         dynaClass = new ADFDynaClass(getBindingContainer());
      }
      return dynaClass;
   }

   public void remove(String p0, String p1)
   {
      //Not supported
   }
   
   public void set(String name, Object value)
   {
      if (ignoreUpdate)
         return;
      
      if (DCUtil.isValueBindingPath(name))
      {
         name = DCUtil.getValueBindingNameFromPath(name);
      }

      dynaValues.put(name, value);
   }
   
   public void set(String name, int index, Object value)
   {
      //Not supported
   }

   public void set(String name, String attribute, Object value)
   {
      //Not supported
   }

   public void reset(ActionMapping mapping, HttpServletRequest request)
   {
      super.reset(mapping, request);

      // Initialize the bindingContext variable that will be used to
      // retrieve the bindingContainer instance from the name
      bindingContext = DCUtil.getBindingContext(request);
    
      // Reset the input state on the previous form if defined.
      final DCBindingContainer bindings = getBindingContainer();
      if (bindings != null)
      {
         bindings.resetInputState();
      }
      
      // Initialize the binding container name using the modelRef property.
      // The name is kept to retrieve the bindingContainer instance.
      bindingContainerName = DataActionMapping.getModelReference(mapping);

      // Find out if the current bindingContainer should accept updates. The
      // rule is, only updates coming from the same binding container are
      // legitimate.
      DCBindingContainer oldBinding = DCUtil.getBindingContainer(request);
      if (oldBinding != null && bindingContainerName != null &&
          !bindingContainerName.equals(oldBinding.getName()))
      {
         ignoreUpdate = true;   
      }
      else
      {
         ignoreUpdate = false;
      }

      // Reset the dynaclass so that it will be rebuild using the new binding
      // container name.
      dynaClass = null;
      resetPendingValues();
   }
}