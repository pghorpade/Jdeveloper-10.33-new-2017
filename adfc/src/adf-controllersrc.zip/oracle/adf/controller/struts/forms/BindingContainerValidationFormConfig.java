package oracle.adf.controller.struts.forms;
import org.apache.struts.action.ActionFormBean;

public class BindingContainerValidationFormConfig extends ActionFormBean 
{
   private String modelReference;
   
   public BindingContainerValidationFormConfig()
   {

   }
  
   public void setModelReference(String value)
   {
      this.modelReference = value;
   }

   public String getModelReference()
   {
      return modelReference;
   }


}