package oracle.adf.controller.struts.forms;

import java.util.Map;
import oracle.adf.model.binding.DCBindingContainer;

/**
 * Expose additional methods needed for an ActionForm to work with a
 * StrutsPageLifecycle.
 * 
 * @since 9.0.5
 */
public interface ADFStrutsForm 
{
   /**
    * @deprecated Not needed since the binding container is now figured out
    * from the modelRef property of the action mapping.
    */
   public void setBindingContainer(DCBindingContainer container);
   
   /**
    * Return pendings values currently store in the form bean.
    * @return a Map of values keyed by value binding name
    */
   public Map getPendingValues();
  
   /**
    * Reset all pending values temporary stored in the form bean.
    */
   public void resetPendingValues();
}