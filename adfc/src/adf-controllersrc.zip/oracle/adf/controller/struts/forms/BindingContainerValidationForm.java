package oracle.adf.controller.struts.forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.struts.forms.ADFStrutsForm;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.uicli.binding.JUCtrlListBinding;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.config.FormBeanConfig;
import org.apache.struts.validator.ValidatorForm;

/**
 * A BindingContainerActionForm to use with Struts validation framework.
 * 
 * @since 9.0.5
 */
public class BindingContainerValidationForm extends ValidatorForm
   implements DynaBean, ADFStrutsForm
{
   /**
    * Because this class need to be serializable, hold a copy of the context
    * and the binding name to retrieve the binding container instance.
    */
   protected BindingContext   bindingContext;
   
   /**
    * The name of the current binding container this class is exposing.
    */
   protected                  String bindingContainerName;
   
   /**
    * The ADFDynaClass with which we are associated.
    */
   protected ADFDynaClass       dynaClass;
   protected Map                dynaValues = new HashMap();
   
   /**
    * @deprecated Not needed since the binding container is now figured out
    * from the modelRef property of the action mapping.
    */
   public void setBindingContainer(DCBindingContainer container)
   {
      // no-op because we use the modelReference property on the formbean to
      // know our binding container.
   }
   
   protected DCBindingContainer getBindingContainer()
   {
      if (bindingContainerName == null || bindingContext == null)
      {
         return null;
      }
      
      return bindingContext.findBindingContainer(bindingContainerName);
   }
   
   // ADFStrutsForm interface implementation
   public Map getPendingValues()
   {
      return dynaValues;   
   }
   
   // ADFStrutsForm interface implementation
   public void resetPendingValues()
   {
      dynaValues.clear();   
   }
   
   public Object get(String name)
   {
      final DCBindingContainer bindings = getBindingContainer();

      if (name.equals("bindings"))
         return bindings;
      
      DCControlBinding binding = getBinding(bindings, name);

      if (! (binding instanceof JUCtrlListBinding) &&
          dynaValues.containsKey(name))
      {
         return dynaValues.get(name);
      }
      
      if (binding == null)
      {
         return "Unknown binding name:" + name;
      }

      return binding;
   }
   
   protected DCControlBinding getBinding(DCBindingContainer bindings,
                                         String name)
   {
      DCControlBinding binding = bindings.findCtrlBinding(name);
      if (binding == null)
      {
         if (DCUtil.isValueBindingPath(name))
         {
            name = DCUtil.getValueBindingNameFromPath(name);
            binding = bindings.findCtrlBinding(name);
         }
      }
      
      return binding;
   }
   
   public boolean contains(String name, String key)
   {
      return false;
   }

   public Object get(String name, int index)
   {
      return null;
   }

   public Object get(String name, String key)
   {
      //Not supported
      return null;
   }

   public DynaClass getDynaClass()
   {
      return dynaClass;
   }

   public void remove(String p0, String p1)
   {
   }
   
   public void set(String name, Object value)
   {
      dynaValues.put(name, value);
   }


   public void set(String name, int index, Object value)
   {
      //Not supported
   }

   public void set(String name, String attribute, Object value)
   {
      //Not supported
   }

   public void reset(ActionMapping mapping, HttpServletRequest request)
   {
      super.reset(mapping, request);
    
      DCBindingContainer bindings = getBindingContainer();
      if (bindings == null)
      {
         final BindingContext bctx = DCUtil.getBindingContext(request);
         if (bctx != null)
         {
            String name = mapping.getName();
            FormBeanConfig config = mapping.getModuleConfig().findFormBeanConfig(name);

            if (config != null &&
                config instanceof BindingContainerValidationFormConfig)
            {
               final String model = ((BindingContainerValidationFormConfig)config).getModelReference();
               if (model != null || model.length() > 0)
               {
                  bindings = DCUtil.findBindingContainer(bctx, model);
                  if (bindings != null)
                  {
                     bindingContext = bindings.getBindingContext();
                     bindingContainerName = bindings.getName();
                  }
                  dynaClass = new ADFDynaClass(bindings);
               }
            }
         }
      }
      else
      {
         bindings.resetInputState();
      }
      
      if (bindings != null)
      {
         DCUtil.setBindingContainer(request, bindings);
      }
   }

  public ActionErrors validate(ActionMapping mapping, HttpServletRequest request)
  {
     if (dynaValues == null || dynaValues.isEmpty())
     {
        return null;
     }

     return super.validate(mapping, request);
  }
   
}