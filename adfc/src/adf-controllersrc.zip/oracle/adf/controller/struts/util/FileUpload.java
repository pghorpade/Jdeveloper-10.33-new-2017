package oracle.adf.controller.struts.util;

import java.io.InputStream;
import java.io.IOException;

import oracle.adf.model.binding.DCUtil;
import oracle.jbo.JboException;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

import org.apache.struts.upload.FormFile;

/**
 * Helper class to support oracle interMedia object.
 * 
 * @since 9.0.5
 */
public class FileUpload 
{ 
  /**
   * Get an interMedia object for the browser uploaded file. 
   */
  public static Object getOrdObject(FormFile file, JUCtrlValueBinding binding)
  {
    if (file != null)
    {
      String contentType = file.getContentType();
      int size = file.getFileSize();
      String filename = file.getFileName();

      if ((! filename.equals("")) &&
          (size >= 0))
      {
        try
        {
          InputStream inStream = file.getInputStream();
          return DCUtil.getOrdObject(inStream, contentType, binding);
        }
        catch (IOException e)
        {
          throw new JboException(e);
        }
      }
    }

    return null;
  }
}
