package oracle.adf.controller.struts.util;

import java.util.ArrayList;

import oracle.adf.model.binding.DCBindingContainer;

import oracle.jbo.AttrValException;
import oracle.jbo.JboException;

import oracle.jdeveloper.html.HTMLElement;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;

/**
 * Helper class to transform exceptions thrown by the ADF model into Struts 
 * ActionErrors.
 * 
 * @since 9.0.5
 */
public class ErrorReporting 
{
   public ErrorReporting()
   {
   }
   
   /**
    * Transfer binding container runtime errors to the Struts ActionErrors
    * collection.
    * @param container the binding container
    * @param errors the ActionErrors object where new errors will be added.
    */
   public static void transferErrorsToStrutsCollection(
                                                DCBindingContainer container, 
                                                ActionErrors errors)
   {
      if (container == null || errors == null)
      {
         return;
      }
      
      ArrayList runtimeErrors = container.getExceptionsList();
      if (runtimeErrors != null)
      {
         for (int i = 0; i < runtimeErrors.size(); i++)
         {
            ErrorReporting.addError(errors, i, 0,
                                    (Throwable)runtimeErrors.get(i));
         }
      }         
   }
      
   /**
    * Adds an exception to the ActionErrors collection.
    * Recursive routine traversing the exception tree.
    * 
    * @param errors the collection of errors
    * @param num the error index
    * @param lev the current level of recursion
    * @param ex the exception node being treated
    */
   public static void addError(ActionErrors errors, int num, int lev,
                               Throwable ex)
   {
      String property = ActionErrors.GLOBAL_ERROR;

      if (ex instanceof AttrValException)
      {
         // In the case of AttrValException, use the attribute name
         // as the error property name to map the error to the
         // particular input field on the corresponding form.
         AttrValException ave = (AttrValException) ex;
         property = ave.getAttrName();
      }
      else if (!(ex instanceof JboException))
      {
         // Not a JboException, add the error message and return
         String message = ex.getMessage();
         if (message == null || message.length() == 0)
         {
            message = ex.getClass().getName();
         }
         errors.add(ActionErrors.GLOBAL_ERROR,
                    new ActionError("error.Validate" + lev,
                                    HTMLElement.quote(message)));
         return;
      }

      JboException jex = (JboException)ex;
      
      Object[] nextLevDetails = jex.getDetails();
      
      if (jex.hasPeerExceptions())
      {
         if (nextLevDetails != null && nextLevDetails.length == 1)
         {
            //only one exception in next level. 
            //skip this exception and add the next one at the same level.
            addError(errors, num, lev, (Throwable)nextLevDetails[0]);
            return;
         }
      }

      String message = ex.getMessage();
      if (message == null || message.length() == 0)
      {
         message = ex.getClass().getName();
      }
      errors.add(property,
                 new ActionError("error.Validate" + lev,
                                 HTMLElement.quote(message)));
   
      if (nextLevDetails != null)
      {
         for (int j = 0; j < nextLevDetails.length; j++)
         {
            addError(errors, j, lev + 1,  (Throwable) nextLevDetails[j]);
         }
      }
   }
}
