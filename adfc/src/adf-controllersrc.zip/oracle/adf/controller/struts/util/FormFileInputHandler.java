package oracle.adf.controller.struts.util;

import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

import org.apache.struts.upload.FormFile;


public class FormFileInputHandler implements  JUCtrlInputValueHandler
{
   public FormFileInputHandler(){}

   public void setInputValue(JUCtrlValueBinding binding, int index, Object value)
   {
      FormFile formFile = (FormFile)value;
      value = FileUpload.getOrdObject(formFile , binding);
      if (value == null)
      {
         return;
      }

      binding.setInputValue(binding, index, value);
   }

   public boolean isNewInputValue(JUCtrlValueBinding binding, int index, Object value)
   {
      if (binding != null)
      {
         return true;
      }
      return false;
   }
}

