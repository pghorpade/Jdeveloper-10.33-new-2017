package oracle.adf.controller.struts.actions;

import java.util.Map;

import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.PlugInConfig;

/**
 * Abstract class providing base support to a StrutsPageLifecycle factory.
 * Implement getPageLifecycle method to provide the factory functionality. See
 * {@link DefaultStrutsPageLifecycleFactory} for an example.<br>
 * 
 * @since 9.0.5
 */
public abstract class StrutsPageLifecycleFactory
{
   /**
    * 
    */
   public static final String factoryPlugInClassName = 
             "oracle.adf.controller.struts.actions.PageLifecycleFactoryPlugin";

   private static StrutsPageLifecycleFactory defaultInstance;

   /**
    * Helper method to instanciate the factory given the ModuleConfig. The
    * ModuleConfig possibly contain the class name of a sustitued factory as
    * the value of a property named "lifecycleFactory". 
    * 
    * @param config the module config
    * @return a StrutsPageLifecycleFactory instance
    */
   public static StrutsPageLifecycleFactory getInstance(ModuleConfig config)
   {
      PlugInConfig plugInConfigs[] = config.findPlugInConfigs();
      StrutsPageLifecycleFactory instance = null;
      
      for (int i = 0; i < plugInConfigs.length; i++)
      {
         String className = plugInConfigs[i].getClassName();
         if (factoryPlugInClassName.equals(className))
         {
            Map properties = plugInConfigs[i].getProperties();
            String factoryclassName =
               (String) properties.get(
                          PageLifecycleFactoryPlugin.LIFECYCLEFACTORY_PROPERTY);
            instance = 
               (StrutsPageLifecycleFactory) properties.get(factoryclassName);
            
            break;
         }
      }
      
      if (instance == null)
      {
         instance = getDefaultInstance();
      }
      
      return instance;
   }
   
   private static StrutsPageLifecycleFactory getDefaultInstance()
   {
      if (defaultInstance == null)
      {
         defaultInstance = new DefaultStrutsPageLifecycleFactory();
      }
      
      return defaultInstance;
   }
   
   /**
    * Return a StrutsPageLifecycle for given a page path.
    * The customized lifecycle should subclass StrutsPageLifecycle to support
    * the base functionality.
    * The page path give the flexibility of returning a different lifecycle for
    * different type of web page like jsp, xml or uix.
    * <p>See {@link DefaultStrutsPageLifecycleFactory} for an example 
    * implementation of this method.
    * 
    * @param path the web page path
    * @return     a customized StrutsPageLifecycle
    */
   public abstract StrutsPageLifecycle getPageLifecycle(String path);

}
