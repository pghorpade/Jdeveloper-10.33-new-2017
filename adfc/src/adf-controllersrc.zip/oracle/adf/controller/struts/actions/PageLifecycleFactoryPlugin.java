package oracle.adf.controller.struts.actions;

import java.util.Map;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.PlugInConfig;
import org.apache.struts.util.RequestUtils;

/**
 * PlugIn used to define an alternate {@link StrutsPageLifecycleFactory}.
 * <p>This class name should be used in the struts-config file to define a plug-in
 * element. The property "lifecycleFactory" should be used to define the class
 * name of the custom factory:
 * <pre>
 * &lt;plug-in className="oracle.adf.controller.struts.actions.PageLifecycleFactoryPlugin"&gt;
 *   &lt;set-property property="lifecycleFactory" value="view.myStrutsLifecycleFactory"/&gt;
 * &lt;/plug-in&gt;
 * </pre>
 * 
 * @since 9.0.5
 */
public class PageLifecycleFactoryPlugin implements PlugIn 
{
   /**
    * Name of the property used to defined a customized
    * StrutsPageLifecycleFactory. The value of this property is the fully
    * qualified class name of the new factory.
    */
   public static final String LIFECYCLEFACTORY_PROPERTY = "lifecycleFactory";
   
   /** 
    *  The plugin config object provided by the ActionServlet initializing
    *  this plugin.
    */
   protected PlugInConfig currentPlugInConfigObject;
   
   
   public void destroy()
   {
   }
   
   public void init(ActionServlet servlet, ModuleConfig config)
      throws ServletException
   {
      Map properties = currentPlugInConfigObject.getProperties();
      String factoryClassName = 
                             (String) properties.get(LIFECYCLEFACTORY_PROPERTY);
      Object instance = null;                       
                             

      if (factoryClassName != null && factoryClassName.trim().length() > 0)
      {
         try
         {
            instance = RequestUtils.applicationInstance(factoryClassName);
         }
         catch (Exception ex)
         {
            throw new ServletException(ex);
         }
         
         // Store the lifecycleFactory instance in the plugIn property. It will
         // be retrieve by the action mapping to get the lifecycle.
         if (instance != null)
         {
            properties.put(factoryClassName, instance);   
         }
      }
   }
   
   /**
    * Method used by the ActionServlet initializing this plugin.
    * Set the plugin config object read from module config.
    * @param plugInConfigObject PlugInConfig.
    */
   public void setCurrentPlugInConfigObject(PlugInConfig plugInConfigObject)
   {
      this.currentPlugInConfigObject = plugInConfigObject;
   }
   
}