package oracle.adf.controller.struts.actions;

/**
 * DataForwardAction implements an easy-to-override
 * {@link oracle.adf.controller.lifecycle.Lifecycle}
 * for a "data page", which is the logical pairing of a page that 
 * <i>renders</i> information from the model, and a "companion"
 * <CODE>DataForwardAction</CODE> that forwards to that page. Since by
 * convention a "data page" always posts/links back to <i>itself</i>, its
 * companion <CODE>DataForwardAction</CODE> both prepares the model
 * for rendering as well as <i>handles events</i> submitted
 * by that page.
 * 
 * <p>Following after the default Struts
 * <CODE>PageForwardAction</CODE>, the page to which the 
 * <CODE>DataForwardAction</CODE> forwards is noted in the
 * <CODE>parameter</CODE> property of the Struts <CODE>ActionMapping</CODE>.
 * 
 * <p>Currently <CODE>DataForwardAction</CODE> is used as a marker class
 * so the Struts design time can properly maintain the <CODE>parameter</CODE>
 * property for the companion page. Actions implemented by classes that are
 * an instance of {@link oracle.adf.controller.struts.actions.DataAction} but
 * <b>not</b> an instance of <CODE>DataForwardAction</CODE> will not have their
 * <CODE>parameter</CODE> property set.  In the future, there may be
 * new functionality that is <CODE>DataForwardAction</CODE> specific.
 */
public class DataForwardAction extends DataAction
{
}