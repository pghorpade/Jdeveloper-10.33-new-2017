package oracle.adf.controller.struts.actions;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.controller.lifecycle.Lifecycle;
import oracle.adf.controller.lifecycle.LifecycleContext;
import oracle.adf.controller.lifecycle.PageLifecycle;

import oracle.jbo.uicli.binding.JUCtrlActionBinding;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * DataAction simplifies implementing Struts-based web applications that use
 * the ADF binding layer by implementing the ADF page handling
 * {@link oracle.adf.controller.lifecycle.Lifecycle} interface in
 * an easy-to-customize Struts action. By default, it implements 
 * <CODE>Lifecycle</CODE> by delegating to a default lifecycle implementation
 * object so that for each request it can handle:
 * 
 * <ul>
 *    <li>
 *      Setting up the appropriate 
 *      {@link oracle.adf.model.binding.DCBindingContainer} based on 
 *      the XML binding definition for the UI model whose name is specified by
 *      the <CODE>modelReference</CODE> property in your Struts 
 *      {@link oracle.adf.controller.struts.actions.DataActionMapping}
 *    </li>
 *    <li>
 *      Retrieving data from the model layer based on the iterator
 *      bindings in the binding container for subsequent
 *      manipulation by the controller layer and/or rendering by
 *      the view layer.
 *    </li>
 *    <li>
 *      Applying submitted data from the browser client to update the
 *      values of appropriate bindings in the binding container, if
 *      appropriate.
 *    </li>
 *    <li>
 *      Handling named events triggered by the client through a combination
 *      of declarative action binding invocation and/or programmatic event
 *      handler code.
 *    </li>
 *    <li>
 *      Auto-selecting a Struts ActionForward based on the name of
 *      the current event being handled, if one has not been set by
 *      the developer programmatically.
 *    </li>
 *    <li>
 *      Reporting of any errors encountered during the lifecycle as
 *      Struts ActionError objects in the standard ActionErrors collection.
 *    </li>
 * </ul>
 * There are two ways to extend the Lifecycle functionality for your
 * application-specific needs:
 * <p>
 * <ol>
 *    <li>
 *      By extending the DataAction class (and using the fully-qualified
 *      name of that subclass as the value of the <CODE>type</CODE> attribute
 *      in your respective Struts action mapping definition).</li>
 *    <li>
 *      By extending the Struts lifecycle base class and the lifecycle 
 *      factory. This allows you to globally customize the behavior of every
 *      DataAction without having to have each one extend a common base class.
 *      See
 *      {@link oracle.adf.controller.struts.actions.StrutsPageLifecycleFactory}
 *    </li>
 * </ol>
 *
 * <p>By default, all of the DataAction's lifecycle method implementations
 * delegate to the default <CODE>Lifecycle</CODE> object created by the
 * {@link oracle.adf.controller.struts.actions.StrutsPageLifecycleFactory}
 * for each web page request. The Lifecycle instance aggregated by the
 * DataAction is defined when the DataAction is configured
 * (see {@link DataActionMapping#freeze} and
 * {@link #getPageLifecycle getPageLifecycle}).
 * 
 * <p>You can override any of the lifecycle methods in a DataAction subclass
 * to modify the default lifecycle handling behavior. The entry point for 
 * the coordination of the sequence and handling of the lifecycle methods
 * is the {@link #handleLifecycle handleLifecycle} method. Specifically, see
 * {@link oracle.adf.controller.lifecycle.PageLifecycle#handleLifecycle 
 * PageLifecycle.handleLifecycle} for the default implementation of how the
 * lifecycle methods are called and in what order.
 *
 * <p>You can also extend the DataAction by implementing an event handler. An
 * event handler is a method in your DataAction subclass with a specific
 * signature that will be executed if an event of the same name is found
 * in the request parameters 
 * (see {@link StrutsPageLifecycle#handleEvent handleEvent}). This is similar
 * to the behavior of the Struts
 * <CODE>org.apache.struts.actions.DispatchAction</CODE>.
 * 
 *
 * @since 9.0.5
 */
public class DataAction extends Action implements Lifecycle
{
   /**
    * Cache the set of event methods as they are introspected.
    */
   protected Map events = new HashMap();
   
   /**
    * The Class instance for this class (DataAction).
    */
   protected Class clazz = this.getClass();
   
   /**
    * The set of argument type classes for the reflected event method call.
    */
   protected Class eventParam[] = { DataActionContext.class };

   /**
    * This is the entry point for the execution of an action from the Struts
    * framework.
    * <p>This method initializes the context class and bootstraps the
    * lifecycle by calling handleLifecycle method.
    * <p>Since the customization of the DataAction behavior should be achieved
    * by extending the lifecycle functionality, this method is declared final.
    * 
    * @param mapping    the ActionMapping used to select this instance.
    * @param form       the optional ActionForm bean for this request.
    * @param request    the HTTP Request we are processing.
    * @param response   the HTTP Response we are processing.
    * @throws Exception
    */
   public final ActionForward execute(ActionMapping       mapping,
                                      ActionForm          form,
                                      HttpServletRequest  request,
                                      HttpServletResponse response)
      throws Exception
   {
      // Configure the context for this DataAction
      final DataActionContext actionContext = new DataActionContext();
      
      actionContext.initialize(this, mapping, form, request, response);

      // Start the execution of the lifecycle
      handleLifecycle(actionContext);
      
      return actionContext.getActionForward();
   }

   /**
    * This is another entry point for the execution of an action from the
    * Struts framework using ServletRequest and ServletResponse.
    * <p>This method simply delegate to the other {@link #execute(ActionMapping,
    * ActionForm, HttpServletRequest, HttpServletResponse) execute} method.
    * <p>Since the customization of the DataAction behavior should be achieved
    * by extending the lifecycle functionality, this method is declared final.
    * 
    * @param mapping    the ActionMapping used to select this instance.
    * @param form       the optional ActionForm bean for this request.
    * @param request    the Servlet Request we are processing.
    * @param response   the Servlet Response we are processing.
    * @throws Exception
    * @see              #execute(ActionMapping, ActionForm, HttpServletRequest,
    *                   HttpServletResponse) execute
    */
   public final ActionForward execute(ActionMapping   mapping,
                                      ActionForm      form,
                                      ServletRequest  request,
                                      ServletResponse response)
      throws Exception
   {
      try
      {
         return (execute(mapping, form,
                         (HttpServletRequest) request,
                         (HttpServletResponse) response));
      }
      catch (ClassCastException e)
      {
         return (null);
      }
   }

   /**
    * Retrieves the page lifecycle instance for this data action.
    * The page lifecycle instance is determined when the 
    * {@link oracle.adf.controller.struts.actions.DataActionMapping} is configured.
    * The implementation of the lifecycle differ based on the type of web page
    * that this action will service.
    * @param   actionContext the lifecycle context for the DataAction
    * @see     StrutsPageLifecycle
    * @see     StrutsUixLifecycle
    */
   protected final Lifecycle getPageLifecycle(DataActionContext actionContext)
   {
      return actionContext.getActionMapping().getPageLifecycle();
   }

   /**
    * Coordinates the sequence and handling of the phases of the ADF page
    * lifecycle.
    * Delegates to the default implementation in the current Lifecycle object
    * for the current request. This will typically be 
    * {@link StrutsJspLifecycle#handleLifecycle handleLifecycle} for JSP pages
    * and {@link StrutsUixLifecycle#handleLifecycle handleLifecycle} for UIX
    * pages.
    * @param actionContext the lifecycle context for the DataAction
    * @throws Exception
    */
   protected void handleLifecycle(DataActionContext actionContext)
      throws Exception
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.handleLifecycle(actionContext);
   }
   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#processComponentEvents processComponentEvents}
    * @param actionContext the lifecycle context for the DataAction
    * @throws Exception
    */
   protected void processComponentEvents(DataActionContext actionContext)
      throws Exception
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.processComponentEvents(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#hasErrors hasErrors}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected boolean hasErrors(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      return cycle.hasErrors(actionContext);
   }
   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#handleError handleError}
    * @param actionContext the lifecycle context for the DataAction
    * @param ex            the exception being thrown
    */
   protected void handleError(DataActionContext actionContext, Exception ex)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.handleError(actionContext, ex);
   }
   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#reportErrors reportErrors}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void reportErrors(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.reportErrors(actionContext);
   }
   

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#buildEventList buildEventList}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void buildEventList(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.buildEventList(actionContext);
   }
   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#prepareModel prepareModel}
    * @param actionContext the lifecycle context for the DataAction
    * @throws Exception
    */
   protected void prepareModel(DataActionContext actionContext)
      throws Exception
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.prepareModel(actionContext);
   }
   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#shouldAllowModelUpdate shouldAllowModelUpdate}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected boolean shouldAllowModelUpdate(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      return cycle.shouldAllowModelUpdate(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#processUpdateModel processUpdateModel}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void processUpdateModel(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.processUpdateModel(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#validateModelUpdates validateModelUpdates}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void validateModelUpdates(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.validateModelUpdates(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#initializeMethodParameters 
    *        initializeMethodParameters}
    * @param actionContext the lifecycle context for the DataAction
    * @param actionBinding the action binding object
    */
   protected void initializeMethodParameters(DataActionContext actionContext,
                                             JUCtrlActionBinding actionBinding)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.initializeMethodParameters(actionContext, actionBinding);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#invokeCustomMethod invokeCustomMethod}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void invokeCustomMethod(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.invokeCustomMethod(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#refreshModel refreshModel}
    * @param actionContext the lifecycle context for the DataAction
    */
   protected void refreshModel(DataActionContext actionContext)
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.refreshModel(actionContext);
   }

   
   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#findForward findForward}
    * @param actionContext the lifecycle context for the DataAction
    * @throws Exception
    */
   protected void findForward(DataActionContext actionContext)
      throws Exception
   {
      Lifecycle cycle = getPageLifecycle(actionContext);
      cycle.findForward(actionContext);
   }

   /**
    * Delegate to the Struts page lifecycle implementation
    * {@link StrutsJspLifecycle#getEventMethod getEventMethod}
    * @param actionContext the lifecycle context for the DataAction
    * @param eventName name of the event
    * @return          the Method object for this event if exist
    */
   protected Method getEventMethod(DataActionContext actionContext,
                                   String eventName)
   {
      return PageLifecycle.getEventMethodFromCache(events, clazz, eventParam,
                                                   eventName);
   }
   
   /**
    * Save all the error message from the lifecycle context to the request
    * attribute.
    * 
    * @param actionContext
    */
   protected void saveErrors(DataActionContext actionContext)
   {
      saveErrors(actionContext.getHttpServletRequest(),
                 actionContext.getActionErrors());
   }

   /*-------------------------------------------------------------------------
    * Support implementation of the lifecycle interface
    *-----------------------------------------------------------------------*/
   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #handleLifecycle(DataActionContext)
    */
   public final void handleLifecycle(LifecycleContext lcContext)
      throws Exception
   {
      handleLifecycle((DataActionContext) lcContext);   
   }
   
   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #processComponentEvents(DataActionContext)
    */
   public final void processComponentEvents(LifecycleContext lcContext)
      throws Exception
   {
      processComponentEvents((DataActionContext) lcContext);   
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #hasErrors(DataActionContext)
    */
   public final boolean hasErrors(LifecycleContext lcContext)
   {
      return hasErrors((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #handleError(DataActionContext, Exception)
    */
   public final void handleError(LifecycleContext lcContext, Exception ex)
   {
      handleError((DataActionContext) lcContext, ex);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #reportErrors(DataActionContext)
    */
   public final void reportErrors(LifecycleContext lcContext)
   {
      reportErrors((DataActionContext) lcContext);   
   }
   
   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #buildEventList(DataActionContext)
    */
   public final void buildEventList(LifecycleContext lcContext)
   {
      buildEventList((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #prepareModel(DataActionContext)
    */
   public final void prepareModel(LifecycleContext lcContext)
      throws Exception
   {
      prepareModel((DataActionContext) lcContext);
   }
   
   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #shouldAllowModelUpdate(DataActionContext)
    */
   public final boolean shouldAllowModelUpdate(LifecycleContext lcContext)
   {
      return shouldAllowModelUpdate((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #processUpdateModel(DataActionContext)
    */
   public final void processUpdateModel(LifecycleContext lcContext)
   {
      processUpdateModel((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #validateModelUpdates(DataActionContext)
    */
   public final void validateModelUpdates(LifecycleContext lcContext)
   {
      validateModelUpdates((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #initializeMethodParameters(DataActionContext, JUCtrlActionBinding)
    */
   public final void initializeMethodParameters(LifecycleContext lcContext,
                                          JUCtrlActionBinding actionBinding)
   {
      initializeMethodParameters((DataActionContext) lcContext, actionBinding);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #invokeCustomMethod(DataActionContext)
    */
   public final void invokeCustomMethod(LifecycleContext lcContext)
   {
      invokeCustomMethod((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #refreshModel(DataActionContext)
    */
   public final void refreshModel(LifecycleContext lcContext)
   {
      refreshModel((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #findForward(DataActionContext)
    */
   public final void findForward(LifecycleContext lcContext)
      throws Exception
   {
      findForward((DataActionContext) lcContext);
   }

   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #saveErrors(DataActionContext)
    */
   public final void saveErrors(LifecycleContext lcContext)
   {
      saveErrors((DataActionContext) lcContext);
   }
   
   /**
    * <b>Internal</b>.
    * Implement the Lifecycle interface and delegate to the DataAction with 
    * the proper DataActionContext parameter.
    * @see #getEventMethod(DataActionContext, String)
    */
   public final Method getEventMethod(LifecycleContext lcContext,
                                      String eventName)
   {
      return getEventMethod((DataActionContext) lcContext, eventName);   
   }
   
}
