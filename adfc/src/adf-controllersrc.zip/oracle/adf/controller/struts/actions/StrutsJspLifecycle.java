package oracle.adf.controller.struts.actions;

/**
 * Customized Struts lifecycle to support JSP.
 * This subclass of the StrutsPageLifecycle does not add any customization to
 * the base support.
 * 
 * @since 9.0.5
 */
public class StrutsJspLifecycle extends StrutsPageLifecycle
{

}
