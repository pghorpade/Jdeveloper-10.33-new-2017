package oracle.adf.controller.struts.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.controller.lifecycle.Lifecycle;
import oracle.adf.controller.lifecycle.LifecycleContext;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Lifecycle Context customized to work with DataAction.
 * @since 9.0.5
 */
public final class DataActionContext extends LifecycleContext 
{
   /**
    * Name of the special forward used to combine a DataAction with a web page.
    */
   public static final String SUCCESS_FORWARD = "success";

   private static final String ACTION_MAPPING_KEY = "actionMapping";
   private static final String ACTION_FORM_KEY = "actionForm";
   private static final String ACTION_ERRORS_KEY = "actionErrors";
   private static final String ACTION_FORWARD_KEY = "actionForward";

   public DataActionContext()
   {
   }
   
   /**
    * Initialize the context with the DataAction parameters.
    * @param lifeCycle
    * @param mapping DataAction ActionMapping
    * @param form DataAction ActionForm
    * @param request DataAction HttpServletRequest
    * @param response DataAction HttpServletResponse
    */
   public void initialize(Lifecycle           lifeCycle,
                          ActionMapping       mapping,
                          ActionForm          form,
                          HttpServletRequest  request,
                          HttpServletResponse response)
   {
      setActionMapping((DataActionMapping) mapping);
      setActionForm(form);

      super.initialize(lifeCycle, request, response);
   }
   
   /**
    * Store the DataActionMapping in the context.
    * @param mapping
    */
   public void setActionMapping(DataActionMapping mapping)
   {
      put(ACTION_MAPPING_KEY, mapping);
   }
   
   /**
    * Retrieve the DataActionMapping from the context.
    * @return the DataActionMapping
    */
   public DataActionMapping getActionMapping()
   {
      return (DataActionMapping) get(ACTION_MAPPING_KEY);
   }

   /**
    * Store the ActionForm in the context.
    * @param form
    */
   public void setActionForm(ActionForm form)
   {
      put(ACTION_FORM_KEY, form);
   }
   
   /**
    * Retrieve the ActionForm from the context.
    * @return ActionForm
    */
   public ActionForm getActionForm()
   {
      return (ActionForm) get(ACTION_FORM_KEY);
   }

   /**
    * Store the ActionForward in the context.<p>
    * This is the ActionForward that will be returned by the DataAction execute
    * method.
    * @param forward
    */
   public void setActionForward(ActionForward forward)
   {
      put(ACTION_FORWARD_KEY, forward);
   }

   /**
    * Store the ActionForward in the context using the name of forward. The
    * ActionForward will be retrieve using <code>findForward(forwardName)</code>
    * <p>
    * This is the ActionForward that will be returned by the DataAction execute
    * method.
    *
    * Utility method to set the action forward by name
    */
   public void setActionForward(String forwardName)
   {
      setActionForward(getActionMapping().findForward(forwardName));
   }
   
   /**
    * Retrieve the ActionForward from the context.
    * @return ActionForward
    */
   public ActionForward getActionForward()
   {
      return (ActionForward) get(ACTION_FORWARD_KEY);
   }

   /**
    * Store the ActionErrors in the context
    * @param errors
    */
   public void setActionErrors(ActionErrors errors)
   {
      put(ACTION_ERRORS_KEY, errors);   
   }
   
   /**
    * Retrieve the ActionErrors from the context.
    * @return ActionErrors
    */
   public ActionErrors getActionErrors()
   {
      ActionErrors errors = (ActionErrors) get(ACTION_ERRORS_KEY);
      if (errors == null)
      {
         errors = new ActionErrors();
         setActionErrors(errors);
      }
      
      return errors;
   }
   
   // Overide getModelReference method
   /**
    * Retrieve the modelReference from the action mapping.
    * 
    * @return the modelReference
    */
   public String getModelReference()
   {
      return DataActionMapping.getModelReference(getActionMapping());
   }
}
