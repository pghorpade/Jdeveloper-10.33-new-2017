package oracle.adf.controller.struts.actions;

import java.util.ArrayList;

import oracle.adf.controller.struts.actions.StrutsPageLifecycle;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.config.ActionConfig;
import org.apache.struts.config.ForwardConfig;
import org.apache.struts.config.ModuleConfig;

/**
 * An extend action mapping to define and handle additional properties for the
 * DataAction.
 * <ul>
 *   <li><b>modelReference</b>: the name of the binding container the DataAction
 *       should use.</li>
 *   <li><b>methodName</b>: the name of an action binding with a custom method that 
 *       will be executed in the DataAction during the 
 *       {@link StrutsPageLifecycle#invokeCustomMethod invokeCustomMethod}
 *       lifecycle phase.</li>
 *   <li><b>numParams</b>: the number of parameters of the custom method.</li>
 *   <li><b>paramNames</b>: the EL expression to retrieve the value for each
 *       method parameter. See {@link oracle.adf.controller.lifecycle.Evaluator}
 *       for a list of available scopes.</li>
 *   <li>resultLocation</b>: the EL expression representing the location of the
 *       method result. See {@link oracle.adf.controller.lifecycle.Evaluator} 
 *       for a list of available scopes.</li>
 * </ul>
 * @since 9.0.5
 */
public class DataActionMapping extends ActionMapping
{
   private String         pagePath;
   private StrutsPageLifecycle  lifecycle;
   private String         methodName;
   private String         modelReference;
   private ArrayList      paramNames = new ArrayList();
   private Integer        numParams = new Integer(0);
   private String         resultLocation;

   /**
    * Helper method to return the page path of a DataAction mapping.
    * @param mapping the DataAction mapping
    * @return        the page path for the mapping
    */
   static public String getPagePath(ActionMapping mapping)
   {
      if (mapping instanceof DataActionMapping)
      {
         return ((DataActionMapping)mapping).getPagePath();
      }

      return null;
   }

   /**
    * Helper method to return the model reference of a DataAction mapping.
    * @param mapping the DataAction mapping
    * @return        the model reference for the mapping
    */
   static public String getModelReference(ActionMapping mapping)
   {
      if (mapping instanceof DataActionMapping)
      {
         return ((DataActionMapping)mapping).getModelReference();
      }

      return null;
   }

   /**
    * paramNames properties
    */
   public void setParamNames(int index, String value)
   {
      this.paramNames.add(index, value);
   }

   /**
    * paramNames properties
    * @return paramnames for the given index
    */
   public String getParamNames(int index)
   {
      return (String)paramNames.get(index);
   }

   /**
    * numParams property
    */
   public void setNumParams(Integer value)
   {
      if ( value != null )
      {
         this.numParams = value;
      }
   }

   /**
    * numParams property
    * @return the number of method parameters
    */
   public Integer getNumParams()
   {
      return numParams;
   }

   /**
    * methodName property
    */
   public void setMethodName(String value)
   {
      this.methodName = value;
   }

   /**
    * methodName property
    * @return the method name
    */
   public String getMethodName()
   {
      return methodName;
   }

   /**
    * modelReference property
    */
   public void setModelReference(String value)
   {
      this.modelReference = value;
   }

   /**
    * modelReference property
    * @return the model reference
    */
   public String getModelReference()
   {
      return modelReference;
   }

   /**
    * resultLocation property
    */
   public void setResultLocation(String value)
   {
      this.resultLocation = value;
   }

   /**
    * resultLocation property
    * @return the EL expression for the method result
    */
   public String getResultLocation()
   {
      return resultLocation;
   }
   
   /**
    * 
    * @return the page path
    */
   public String getPagePath()
   {
      return pagePath;
   }

   /**
    * 
    * @return StrutsPageLifecycle
    */
   public StrutsPageLifecycle getPageLifecycle()
   {
      return lifecycle;
   }

   /**
    * Figure out which lifecycle to use and fix up the some of the action
    * property before the config get frozen.
    * The decide which lifecycle to use we need to discover the page that we
    * will render. This could be a UIX or something else. To discover the page
    * we walk the chain of "success" forward or look at the parameter property
    * when we are dealing with a DataPage.
    * Once we have the lifecycle, call its processActionConfig to give the
    * lifecycle a chance to update the configuration.
    */
   public void freeze()
   {
      String pagePath = null;
      StrutsPageLifecycle lifecycle = null;

      // Use parameter first, still give a change to the "success" forward
      // if the parameter property is not defined.
      pagePath = this.getParameter();

      if (pagePath == null)
      {
         ForwardConfig success = findForwardConfig(
                                             DataActionContext.SUCCESS_FORWARD);

         // only process if "success" has been added  
         if (success != null)
         {
            pagePath = getForwardPath(success);
         }
      }
      
      StrutsPageLifecycleFactory pageLifecycleFactory = 
                   StrutsPageLifecycleFactory.getInstance(getModuleConfig());
      lifecycle = pageLifecycleFactory.getPageLifecycle(pagePath);
      
      // only process if lifecycle is determined
      if (lifecycle != null)
      {
         // Give the opportunity to the lifecyle to handle and possibly
         // modify the config of the mapping.
         lifecycle.processActionConfig(this);
      }

      this.pagePath = pagePath;
      this.lifecycle = lifecycle;

      super.freeze();
   }

   protected String getForwardPath(ForwardConfig forward)
   {
      ModuleConfig moduleConfig = getModuleConfig();

      String forwardPath = null;

      if (forward != null)
      {
         forwardPath = forward.getPath();
         int doIndex;

         // walk through all any forward configs
         while (forwardPath != null &&
                // Without the servlet context, we can't get to the current 
                // servlet mapping. Use ".do", hikes.
                (doIndex = forwardPath.lastIndexOf(".do")) != -1)
         {
            forwardPath = forwardPath.substring(0, doIndex);
            ActionConfig action = moduleConfig.findActionConfig(forwardPath);
            if (action != null)
            {
               forwardPath = getForwardPath(action);
            }
         }
      }

      return forwardPath;
   }

   private String getForwardPath(ActionConfig action)
   {
      String forwardPath = action.getForward();

      if (forwardPath == null && action instanceof DataActionMapping)
      {
         DataActionMapping mapping = (DataActionMapping) action;

         // Use parameter first, still give a change to the "success" forward
         // if the parameter property is not defined.
         forwardPath = mapping.getParameter();
         if (forwardPath == null)
         {
            ActionForward success = mapping.findForward(
                                            DataActionContext.SUCCESS_FORWARD);
            if (success != null)
               forwardPath = success.getPath();
         }
      }

      return forwardPath;
   }

}
