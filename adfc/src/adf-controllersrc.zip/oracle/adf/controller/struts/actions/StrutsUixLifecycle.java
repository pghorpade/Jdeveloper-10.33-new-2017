package oracle.adf.controller.struts.actions;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.controller.lifecycle.LifecycleContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCUtil;

import oracle.cabo.servlet.BajaContext;
import oracle.cabo.servlet.BaseBajaContext;
import oracle.cabo.servlet.Page;
import oracle.cabo.servlet.PageBroker;
import oracle.cabo.servlet.PageBrokerHandler;
import oracle.cabo.servlet.event.EventResult;
import oracle.cabo.servlet.event.PageEvent;
import oracle.cabo.servlet.event.PageEventException;
import oracle.cabo.servlet.event._private.PageFlowUtils;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Customized Struts lifecycle to support UIX.
 * 
 * @since 9.0.5
 */
public class StrutsUixLifecycle extends StrutsPageLifecycle
{
   public void processActionConfig(DataActionMapping mapping)
   {
      if (false)
      {
        // perform a compile time check to make sure the super method is not changed.
        // if it is changed, we need to change this method to match the new signature:
        super.processActionConfig(mapping);
      }
      String formBeanName = mapping.getName();

      // UIX does not use formbean
      if (formBeanName != null /*&& formBeanName.equals("DataForm" */)
      {
         mapping.setName(null);
      }
   }
 
  
  public void handleLifecycle(LifecycleContext lcContext)
    throws Exception
  {
    // before we do any rendering, we need to tell the UIX servlet what to
    // use as the default destination for forms. This is so that subsequent
    // requests will come to the action servlet instead of the uix servlet:
    HttpServletRequest  request = lcContext.getHttpServletRequest();
    //ystem.out.println("[UixLifecycle] defaultURL=" + request.getRequestURI());
    request.setAttribute("oracle.cabo.servlet.url.defaultURL",
                         request.getRequestURI());

    // when we run via the struts pageflow, we don't want the UIX servlet
    // throwing UnhandledEventExceptions:
    PageFlowUtils.setHandlerCheckingEnabled(request, false /*isEnabled*/);

    super.handleLifecycle(lcContext);
  }

  public void processUpdateModel(LifecycleContext lcContext)
  {
    // uix needs to support model 1 updates as well. 
    // So model updates are no longer handled by
    // struts controller. They are handled by InitModelListener (Cabo VOB).
    // InitModelListener also does extra stuff like handling checkBoxes.

    // the order for the uix-struts lifecycle is:
    // 1. uix controller handles the postback and updates the model.
    // 2. uix controller validates the model.
    // 3. uix controller called uix event handler.
    // 4.1. if no uix event handler was called, then strutsUixLifecycle will
    // call struts event handler.
    // 4.2. if there was a uix event handler, the event result will be used
    // to find a struts forward.

    // we have to do uix event handler before struts event handlers
    // because of bug 3855611


    if (false)
    {
      // perform a compile time check to make sure the super method is not changed.
      // if it is changed, we need to change this method to match the new signature:
      super.processUpdateModel(lcContext);
    }

    HttpServletRequest request = lcContext.getHttpServletRequest();
    DataActionContext actionContext = (DataActionContext) lcContext;
    
    try
    {
      // do model update. followed by calling any uix event handlers:
      EventResult result = _runUixController(actionContext);
      // store the eventResult so that event handlers will not be called
      // a second time:
      PageFlowUtils.setEventResult(request, result);
    }
    catch (IOException e)
    {
      handleError(lcContext, e);
    }
    catch (ServletException e)
    {
      handleError(lcContext, e);
    }
  }

  public void validateModelUpdates(LifecycleContext lcContext)
  {
    if (false)
    {
      // compile time check to make sure correct method is overridden.
      super.validateModelUpdates(lcContext);
    }
    // model validation is done inside InitModelListener.
  }

  protected boolean shouldValidateToken(HttpServletRequest request, DCBindingContainer bindings)
  {
    if (false)
    {
      // compile time check to make sure correct super class method is overwritten:
      super.shouldValidateToken(request, bindings);
    }

    // the state token ID must be validated in InitModelListener.
    // see bug 3925923:
    return false;
  }

  public void processComponentEvents(LifecycleContext lcContext)
    throws Exception
  {
    HttpServletRequest request = lcContext.getHttpServletRequest();
    EventResult eventResult = PageFlowUtils.getEventResult(request);
    // make sure we don't run both uix and struts event handlers.
    // if there was a uix event handler, then 
    // most of the time, the eventResult will be non-null:
    if (eventResult != null)
    {
      DataActionContext actionContext = (DataActionContext) lcContext;
      // use the result in the EventResult to find a forward:
      // bug 3902041:
      _setForward(actionContext, eventResult);
      return;
    }

    // call the super method so that any model methods are called:
    // this was bug 3082924:
    super.processComponentEvents(lcContext);

    // Create a bogus EvenResult. This is
    // just to avoid calling uix event handlers twice on the same request:
    eventResult = new EventResult();

    // <CEG> Not sure if we could use the actionContext here instead
    // of the request...
    // <ACW> No, we have to use the request because the UIX RT needs this
    // property and has no access to the actionContext:
    // see oracle.cabo.servlet.event.BasePageFlowEngine:
    PageFlowUtils.setEventResult(request, eventResult);
  }

  private EventResult _runUixController(DataActionContext actionContext)
    throws IOException, ServletException
  {
    final ActionMapping mapping = actionContext.getActionMapping();
    final String pagePath = DataActionMapping.getPagePath(mapping);

    //ystem.out.println("[UixLifecycle] pagePath=" + pagePath);

    if (pagePath != null)
    {
      final DataAction action = _getDataAction(actionContext);
      final HttpServletResponse response = actionContext.getHttpServletResponse();
  
      // obtain PageBroker from servlet context
      ServletContext application = action.getServlet().getServletContext();
  
      PageBroker broker = (PageBroker)
        application.getAttribute("oracle.cabo.servlet.PageBroker");
  
      //ystem.out.println("[UixLifecycle] broker=" + broker);
  
      if (broker != null)
      {
        broker = new NonRenderingPageBroker(broker);
        PageBrokerHandler handler = PageBrokerHandler.sharedInstance();
        HttpServletRequest request = actionContext.getHttpServletRequest();
        request = new PathRequest(request, pagePath);
        // FIXME: this is the wrong servlet
        BajaContext context = new BaseBajaContext(action.getServlet(), broker, 
                                                  request, response);
  
        // set the binding container on the request so that the "bindings" EL
        // variable works during UIX event handling. It is also required
        // for the InitModelListener class to get at the bindingContainer
        // for postback:
        DCUtil.setBindingContainer(request, 
                                   actionContext.getBindingContainer());
  
        Page page = handler.handleRequest(context);
        EventResult result = EventResult.getEventResult(context);
        return result;
      }
    }
    return null;
  }

  public void reportErrors(LifecycleContext lcContext)
  {
    // no need to report errors, since this is handled by InitModelListener

    // compile time check to make sure method exists on super class:
    if (false)
    {
      super.reportErrors(lcContext);
    }
  }

  protected boolean handleEvent(LifecycleContext lcContext, String event)
    throws Exception
  {
    boolean isHandled = super.handleEvent(lcContext, event);
    if (isHandled)
    {
      // the struts life cycle has handled the event. we have to prevent the
      // UIX servlet from also trying to handle the event. by setting an
      // _EVENT_RESULT_ATTR property, we tell the uix servlet not to handle
      // the event:
      HttpServletRequest request = lcContext.getHttpServletRequest();
      EventResult result = new EventResult();
      PageFlowUtils.setEventResult(request, result);
    }

    return isHandled;
  }

  private DataAction _getDataAction(LifecycleContext lcContext)
  {
    DataAction action = (DataAction) lcContext.getLifecycle();
    return action;
  }
   
  private void _setForward(DataActionContext actionContext, EventResult result)
  {
    // do not navigate if there were errors:
    if (hasErrors(actionContext))
      return;

    Object token = result.getResult();

    // fixme, propagate page properties
    if (token instanceof Page)
    {
      token = ((Page)token).getName();
      // we must clear the result, otherwise the UIX RT will try to
      // render a page with the same name as the forward:
      result.setResult(null);

      final DataActionMapping mapping = actionContext.getActionMapping();
      String forwardName = token.toString();
      ActionForward forward = mapping.findForward(forwardName);
      if (forward==null)
      {
        System.err.println("forward:"+forwardName+
                           " not found on action:"+mapping.getPath());
      }
      else
      {
        actionContext.setActionForward(forward);
      }
    }
  }
   

  private static class NonRenderingPageBroker implements PageBroker
  {
    public NonRenderingPageBroker(PageBroker delegate)
    {
      _delegate = delegate;
    }
    
    public PageBroker getPageBroker()
    { 
      return _delegate;
    }
    
    public void requestStarted(BajaContext context)
      throws ServletException
    {
      getPageBroker().requestStarted(context);
    }

    public void requestEnded(BajaContext context)
      throws ServletException
    {
      getPageBroker().requestEnded(context);
    }

    public Page handleRequest(BajaContext context, 
                              Page        page, 
                              PageEvent   event)
      throws PageEventException
    {
      // set the current page as the initial page that was requested:
      // this is used over in the UIX RT:
      context.getServletRequest().setAttribute
        ("oracle.cabo.servlet.page.initialPage", page);

      return getPageBroker().handleRequest(context, page, event);
    }

    public PageEvent decodeMultipartRequest(BajaContext context, 
                                            Page        page)
      throws IOException, ServletException
    {
      return getPageBroker().decodeMultipartRequest(context, page);
    }

    public void renderPage(BajaContext context, 
                           Page        page)
      throws IOException, ServletException
    {
      // no-op
    }

    public void renderError(BajaContext context, 
                            Throwable   error)
      throws IOException, ServletException
    {
      throw new ServletException(error);
    }

    public Object getService(BajaContext context, 
                             Class       serviceClass,
                             Object      serviceSelector)
    {
      return getPageBroker().getService(context, serviceClass, serviceSelector);
    }

    public void init(Servlet servlet, ServletConfig config)
      throws ServletException
    {
      getPageBroker().init(servlet, config);
    }

    public void destroy()
    {
      getPageBroker().destroy();
    }
    
    private PageBroker _delegate;
  }

  private static class PathRequest extends HttpServletRequestWrapper
  {
    public PathRequest(HttpServletRequest request, String path)
    {
      super(request);
      _path = path;
    }
    
    public String getServletPath()
    {
      return (_path != null) ? _path : super.getServletPath();
    }
    
    private String _path;
  }
}
