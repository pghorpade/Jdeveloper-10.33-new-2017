package oracle.adf.controller.struts.actions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.lifecycle.Evaluator;
import oracle.adf.controller.lifecycle.LifecycleContext;
import oracle.adf.controller.lifecycle.PageLifecycle;
import oracle.adf.controller.struts.forms.ADFStrutsForm;
import oracle.adf.controller.struts.forms.BindingContainerActionForm;
import oracle.adf.controller.struts.util.ErrorReporting;
import oracle.adf.controller.struts.util.FormFileInputHandler;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.model.generic.BeanUtils;

import oracle.jbo.NoObjException;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jbo.uicli.binding.JUCtrlValueDef;
import oracle.jbo.uicli.mom.JUMetaObjectBase;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.upload.FormFile;

/**
 * Base class for any Lifecycle running with the Struts controller.
 * This is an adapted {@link oracle.adf.controller.lifecycle.PageLifecycle
 * PageLifecycle} to work with specific Struts feature like error reporting, 
 * named forward and form bean.
 * 
 * @since 9.0.5
 */
public class StrutsPageLifecycle extends PageLifecycle
{
   /**
    * A custom input handler used by bindings dealing with FormFile type
    */
   public static final String formFileInputHandlerName = "FormFileInputHandler";
   
   
   /**
    * Give the opportunity to the lifecyle to handle and possibly
    * modify the config of the mapping.
    * @param mapping the action mapping
    * @see           DataActionMapping#freeze
    */
   public void processActionConfig(DataActionMapping mapping)
   {
      // No-op
   }
   
   /**{@inheritDoc}
    * In the Struts case, prepare the ADF formBean (ADFStrutsForm) with the
    * current binding container. Also if the token validation fails, clean the
    * pending values in the formbean because they belongs to the wrong iterator.
    */
   public void prepareModel(LifecycleContext lcContext)
      throws Exception
   {
      try
      {
         super.prepareModel(lcContext);
         
         // Register input handler that we might use
         final BindingContext bctx = lcContext.getBindingContext();  
         JUCtrlInputValueHandler inputHandler = (JUCtrlInputValueHandler)
            bctx.getBindingInputHandler(formFileInputHandlerName);
         if (inputHandler == null)
         {
            inputHandler = new FormFileInputHandler();

            // Initialize default InputHandler here
            HashMap inputHandlerMap = new HashMap(2);
            inputHandlerMap.put(formFileInputHandlerName, inputHandler);
            bctx.setBindingInputHandlers(inputHandlerMap);
         }
      }
      catch (Exception ex)
      {
         // If you have a ADFStrutsForm, set the binding container for the bean
         // to be populated.
         final ActionForm form = ((DataActionContext) lcContext).getActionForm();
         ADFStrutsForm adfForm = null;

         if (form instanceof ADFStrutsForm)
         {
            adfForm = (ADFStrutsForm) form;
            // If the model preparation fails (mostly because of a failing token
            // validation), cleans the pending values.
            if (adfForm != null)
               adfForm.resetPendingValues();
         }

         throw ex;
      }
   }

   /**{@inheritDoc}
    * <p>This is the stuff needed to bypass update on some method like rollback.
    * Also give a chance to the custom method to veto the change.
    */  
   public boolean shouldAllowModelUpdate(LifecycleContext lcContext)
   {
      boolean bAllow = super.shouldAllowModelUpdate(lcContext);
      
      if (bAllow)
      {
         // Treat the custom method case so that it also has a chance to veto
         // the update.
         final DataActionMapping adfMapping = ((DataActionContext) lcContext).getActionMapping();
         final String methodName = adfMapping.getMethodName();
   
         if (methodName != null)
         {
            JUCtrlActionBinding action = (JUCtrlActionBinding)
                 BeanUtils.findContextObject(lcContext.getBindingContext(), methodName);
            if (action != null && action.ignoreUpdates())
               bAllow = false;
         }
      }

      // If we are not going to update the model, make sure to clean up the
      // pending values so that they won't be rendered in the page.
      if (!bAllow)
      {
         ActionForm form = ((DataActionContext) lcContext).getActionForm();
         if ((form instanceof ADFStrutsForm))
         {
            ((ADFStrutsForm) form).resetPendingValues();
         }
      }

      return bAllow;      
   }
   
   /**
    * Handle update using a Struts formbean
    * In case of error the method setInputValue will not throw but instead
    * the errors will be collected in the binding container.
    */
   public void processUpdateModel(LifecycleContext lcContext)
   {
      final ActionForm form = ((DataActionContext) lcContext).getActionForm();

      // This is to make sure v2 BindingContainerActionForm don't execute
      // super.
      if (form == null || form instanceof BindingContainerActionForm)
      {
         super.processUpdateModel(lcContext);
      }
      
      // Only deal with ADFStrutsForm. Don't know how to support others.
      if (! (form instanceof ADFStrutsForm))
      {
         return;
      }
      
      final ADFStrutsForm adfForm = (ADFStrutsForm) form;

      // Collect the pending values from the formbean and update 
      // the model with them
      updateModel(lcContext, adfForm.getPendingValues());

      // Since the model has been updated, clear pending values so that 
      // next time the values are pulled from the model.
      adfForm.resetPendingValues();
   }
   
   protected void updateModel(LifecycleContext lcContext, Map updatedValues)

   {
      if (updatedValues == null || updatedValues.size() == 0)
      {
         return;
      }
      
      final HttpServletRequest request = lcContext.getHttpServletRequest();
      final DCBindingContainer bindings = lcContext.getBindingContainer();

      String contentType = request.getContentType();
      if ((contentType != null) && 
          contentType.startsWith("multipart/form-data") &&
          request.getMethod().equalsIgnoreCase("POST")) 
      {
         // Iterate through all the values from the form and ony push the
         // the new ones to the model
         final Iterator iter = updatedValues.keySet().iterator();
         while(iter.hasNext())
         {
            String propertyName = (String) iter.next();
   
            JUCtrlValueBinding binding = (JUCtrlValueBinding)
               bindings.findCtrlBinding(propertyName);
   
            // For backward compatibility with 9.0.5.x we need to handle
            // the case where custom handler are not set at design time
            // through a property of the binding.
            JUCtrlValueDef def = (JUCtrlValueDef) binding.getDef();
            if (!def.hasCustomInputHandler())
            {
               // Set the inputHandler dynamically based on the type of the
               // value.
               if (updatedValues.get(propertyName) instanceof FormFile)
               {
                  final BindingContext bctx = lcContext.getBindingContext();  
      
                  binding.setInputValueHandler((JUCtrlInputValueHandler)
                     bctx.getBindingInputHandler(formFileInputHandlerName));
               }
            }
         }
      }

      bindings.processInputValues(updatedValues);
   }

  
   /**
    * Handle an event.
    * An event handler can be a method defined in a subclass of this
    * PageLifecycle. To be recognized as an event handler the method signature
    * need to be similar to:
    * <pre>
    * public void on<b>Event</b>(DataActionContext ctx)
    * {
    *    // Use the following method to execute the possible
    *    // action binding associated with this event
    *    ctx.getEventActionBinding().doit();
    * }
    * </pre>
    * Where <b>Event</b> is the name of the event.
    * <p>
    * An event can also be an action binding with the same name of the event
    * present in the current binding container.
    * <p>  
    * In addition to the super class behavior, the event name is used as a
    * automatic forward mechanism. If it exist an action forward of the same
    * name of the event, this action forward is set to the context to be the 
    * return value of the DataAction execute method.
    *
    * @see LifecycleContext#getEventActionBinding getEventActionBinding
    */
   protected boolean handleEvent(LifecycleContext lcContext, String event)
      throws Exception
   {
      final DataActionContext actionContext = (DataActionContext) lcContext;
      boolean isHandled = true; 

      isHandled = super.handleEvent(lcContext, event);

      // If the user has not already set the forward value and if there are
      // no error, look for a forward name matching the name of the event
      if (actionContext.getActionForward() == null &&
          ! lcContext.getLifecycle().hasErrors(lcContext))
      {
         final DataActionMapping mapping = actionContext.getActionMapping();
   
         // Try to dispatch to the forward matching the event name.
         ActionForward forward = mapping.findForward(event);  
         
         if (forward != null)
         {
            actionContext.setActionForward(forward);
         }
      }

      return isHandled;
   }
   
   /**
    * This method allows for initialization of the action binding's parameters by evaluating 
    * the expression values stored in the action definition. This will only be invoked for the 
    * action binding that represents the default method dropped on the action via the data control palette.
    * 
    * @param lcContext     the lifecycle context
    * @param actionBinding the action bindings to be initialized
    */
   protected void initializeParameterValuesUsingExpressions(LifecycleContext lcContext,
                                          JUCtrlActionBinding actionBinding)
   {
      final DataActionMapping adfMapping = 
                            ((DataActionContext) lcContext).getActionMapping();
      final int numParams = adfMapping.getNumParams().intValue();

      if (numParams > 0)
      {
         ArrayList params = new ArrayList();
         Evaluator se = Evaluator.getEvaluator(lcContext);

         for ( int i = 0; i < numParams; i ++ )
         {
            // evaluate SPEL expression corresponding to this parameter:
            final String param = adfMapping.getParamNames(i);
            final Object value = se.getValue(param);
            params.add(value);
         }

         if ( params.size() == numParams)
         {
            actionBinding.setParams(params);
         }
      }      
   }
   
   // Inherit javadoc from superclass.
   public void initializeMethodParameters(LifecycleContext lcContext,
                                          JUCtrlActionBinding actionBinding)
   {
      final DataActionMapping adfMapping = 
                            ((DataActionContext) lcContext).getActionMapping();
      String            methodName = adfMapping.getMethodName();
      DCInvokeMethodDef methodDef = actionBinding.getInvokeMethodDef();
      String            actionMethodName = null;

      // Check if the method is define and retrieve its name
      if ( methodDef != null )
      {
         actionMethodName = actionBinding.getName();
      }

      if ( methodName != null && actionMethodName != null &&
           methodName.endsWith(actionMethodName) )
      {
         initializeParameterValuesUsingExpressions(lcContext , actionBinding);
      }
      else if ( methodDef != null )
      {
         initializeParameterValuesUsingRequestObject(lcContext, actionBinding);
      }
   }

   /**
    * Invoke custom method if one is defined in the {@link DataActionMapping 
    * mapping} of the DataAction.
    * @see DataActionMapping
    */
   public void invokeCustomMethod(LifecycleContext lcContext)
   {
      final DataActionMapping adfMapping =
                            ((DataActionContext) lcContext).getActionMapping();
      String methodName = adfMapping.getMethodName();

      if ( methodName != null )
      {
         final BindingContext bctx = lcContext.getBindingContext();  
         JUCtrlActionBinding actionBinding = (JUCtrlActionBinding)
                                  BeanUtils.findContextObject(bctx, methodName);
                                  
         if (actionBinding == null)
         {
           throw new NoObjException(JUMetaObjectBase.TYP_CONTROL_BINDING,
                                    methodName);
         }

         // hook for providing method parameters
         lcContext.setCustomMethod(actionBinding);
         // Call the initializeMethodParameters throw the dataAction class to
         // give the opportunity to the user to overwrite it...
         lcContext.getLifecycle().initializeMethodParameters(lcContext,
                                                                 actionBinding);
         actionBinding.doIt();

         // store result of a method by evaluating SPEL expression:
         String resultLocation = adfMapping.getResultLocation();
         if ( resultLocation != null && !resultLocation.equals("") )
         {
            Evaluator se = Evaluator.getEvaluator(lcContext);
            se.setValue(resultLocation, actionBinding.getResult());
         }
      }
   }

   // Inherit javadoc from interface.
   public void refreshModel(LifecycleContext lcContext)
   {
      final DCBindingContainer bindings = lcContext.getBindingContainer();
      final DataActionContext actionContext = (DataActionContext) lcContext;
      
      // Last, notify the bindingContainer that model update are over with.
      // Only call refreshControl if no navigation occurs.
      if (actionContext.getActionForward() == null)
      {
         bindings.refreshControl();
      }
   }

   /**{@inheritDoc}
    * <p>This method retrieve the list of error from the dataControl and treat
    * them as fit for the PageLifeCycle implementation.
    * Retrieves the errors from the data control and reports then to the user.
    */
   public void reportErrors(LifecycleContext lcContext)
   {
      final DataActionContext actionContext = (DataActionContext) lcContext;
      ActionErrors errors = null;
      
      // transfer any errors to the ActionError list
      try
      {
         if (lcContext.getLifecycle().hasErrors(lcContext))
         {
            errors = actionContext.getActionErrors();
            ErrorReporting.transferErrorsToStrutsCollection(
                                      lcContext.getBindingContainer(), errors);
         } 
      }
      catch (Throwable t)
      {
         errors = actionContext.getActionErrors();
         ErrorReporting.addError(errors, 0, 0, t);
      }
         
      if (errors != null && !errors.isEmpty())
      {
         // Store the action error using the standard action mechanism.
         ((DataAction) lcContext.getLifecycle()).saveErrors(actionContext);
      }
   }

   /**
    * Determine the ActionForward that will be returned by the Struts action
    * executing the Lifecycle.
    * This method only set the ActionForward object in the actionForward 
    * property of the DataActionContext. The DataAction executing the Lifecycle
    * will return this value from the execute method.
    * <p>
    * If the actionForward property has already being set during a previous step
    * of the Lifecycle, it respect this value and return.
    * If there was errors during the Lifecycle, it uses the inputForward 
    * property of the action.
    * The normal behavior for a DataForwardAction is to use the parameter
    * property. For a DataAction it is to use the forward called "success".
    * <p>
    * Clients should override this method to select a forward based on the
    * result of a custom method invocation.
    * Since this method is called when the Lifecycle successfully executed or 
    * when an error was encountered, the user has to pay extra attention to
    * always check for the error case using the hasError property. 
    * <pre>
    *    // Set my custom Action only when no error occured
    *    if ( ! actionContext.hasErrors())
    *    {
    *       actionContext.setActionForward(myActionForward);
    *    }
    *    else
    *    {
    *       super.findForward(actionContext);
    *    }
    * </pre>
    *
    */
   public void findForward(LifecycleContext lcContext)
      throws Exception
   {
      final DataActionContext actionContext = (DataActionContext) lcContext;
      final DataActionMapping mapping = actionContext.getActionMapping();
      ActionForward forward = null;
      
      // Respect user setting
      if (actionContext.getActionForward() != null)
      {
         return;
      }

      // In case of error directly go back to the page
      if (lcContext.getLifecycle().hasErrors(actionContext))
      {
         forward = mapping.getInputForward();
      }
      
      if (forward == null || forward.getPath() == null)
      {
         // Single dataForward case
         String path = mapping.getParameter();
         if (path != null)
         {
            // Let the controller handle the request
            forward = new ActionForward(path);
            forward.setContextRelative(true);
         }
         else
         {
            forward = mapping.findForward(DataActionContext.SUCCESS_FORWARD);
         }
      }
      
      actionContext.setActionForward(forward);
   }

}
