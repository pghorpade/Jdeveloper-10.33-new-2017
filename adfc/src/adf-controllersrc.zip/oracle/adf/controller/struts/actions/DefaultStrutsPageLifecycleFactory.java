package oracle.adf.controller.struts.actions;

/**
 * Default implementation of the StrutsPageLifecycleFactory.
 * This implementation is used to create {@link StrutsPageLifecycle} instance
 * for a DataAction.
 * To use a different factory use the {@link PageLifecycleFactoryPlugin}.
 * @since 9.0.5
 */
public class DefaultStrutsPageLifecycleFactory extends StrutsPageLifecycleFactory
{
   /**
    * Return a StrutsPageLifecycle for given a page path.
    */
   public StrutsPageLifecycle getPageLifecycle(String path)
   {
      if (path != null)
      {
         int queryIndex = path.indexOf('?');
         if (queryIndex != -1)
            path = path.substring(0, queryIndex);

         if (path.endsWith(".uix") || path.indexOf("/uix/") >= 0)
            return getUIXLifeCycle();
      }

      return getJSPLifeCycle();
   }

   private static StrutsPageLifecycle getJSPLifeCycle()
   {
      if (JSP_LIFECYCLE == null)
      {
         JSP_LIFECYCLE = new StrutsJspLifecycle();
      }

      return JSP_LIFECYCLE;
   }

   private static StrutsPageLifecycle getUIXLifeCycle()
   {
      if (UIX_LIFECYCLE == null)
      {
         UIX_LIFECYCLE = new StrutsUixLifecycle();
      }

      return UIX_LIFECYCLE;
   }

   private static StrutsPageLifecycle JSP_LIFECYCLE;
   private static StrutsPageLifecycle UIX_LIFECYCLE;
   
}