package oracle.adf.controller.faces.context;

import java.io.IOException;

import java.util.Map;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.faces.lifecycle.ADFPhaseListener;
import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.share.Environment;

/**
 * Custom implementation of the PageLifecycleContext to suit the
 * {@link oracle.adf.controller.faces.lifecycle.FacesPageLifecycle}.
 *
 * @since 10.1.3
 */
public class FacesPageLifecycleContext extends PageLifecycleContext
{
   /** Key used to store the FacesContext instance in the context map.
    *  @see #getFacesContext
    */
   public static final String FACES_CONTEXT_KEY = "facesContext";
   
   /** Key used to store the ActionEvent instance in the context map.
    *  @see #getActionEvent
    */  
   public static final String ACTION_EVENT_KEY = "actionEvent";
   
   private Environment env;
   
   public FacesPageLifecycleContext(Map envMap)
   {
      super(envMap);
   }

   /**
    * Retrieve the current page path using page viewId of the current viewRoot.
    */
   protected String getPath()
   {
      // Retrieve the current viewRoot for the current Lifecycle. We can't
      // directly use the FacesContext viewRoot because it might had change
      // during navigation.
      final UIViewRoot viewRoot = (UIViewRoot) getFacesContext().
         getExternalContext().getRequestMap().
         get(ADFPhaseListener.CurrentViewRootRequestParam);

      String path = null;
      if (viewRoot != null)
      {
         path = viewRoot.getViewId();
      }

      return path;
   }

   /**
    * Retrieve the anonymous environment using the FacesContext.
    */
   public Environment getEnvironment()
   {
      if (env == null)
      {
         env = new FacesEnvironment();
      }
      return env;
   }

   /**
    * Return the FacesContext.
    */
   public FacesContext getFacesContext()
   {
      return (FacesContext) envMap.get(FACES_CONTEXT_KEY);
   }
   
   /**
    * Set the current ActionEvent.
    */
   public void setActionEvent(ActionEvent actionEvent)
   {
      envMap.put(ACTION_EVENT_KEY, actionEvent);
   }
   
   /**
    * Return the current ActionEvent.
    */
   public ActionEvent getActionEvent()
   {
      return (ActionEvent) envMap.get(ACTION_EVENT_KEY);
   }
   
   /**
    * Provide a Faces implementation of the Environment class.
    * Simply delegate to the Faces external context.
    */
   final class FacesEnvironment extends  Environment
   {
      public FacesEnvironment()
      {
      }
      
      public Object getRequest()
      {
         return getFacesContext().getExternalContext().getRequest();   
      }
      
      public Object getResponse()
      {
         return getFacesContext().getExternalContext().getResponse();   
      }

      public Object getContext()
      {
         return getFacesContext().getExternalContext().getContext();   
      }

      public java.util.Locale getRequestLocale()
      {
         return getFacesContext().getExternalContext().getRequestLocale();
      }

      public String getRequestServletPath()
      {
         return getFacesContext().getExternalContext().getRequestServletPath();
      }

      public String getRequestPathInfo()
      {
         return getFacesContext().getExternalContext().getRequestPathInfo();
      }

      public String encodeResourceURL(String url)
      {
         return getFacesContext().getExternalContext().encodeResourceURL(url);
      }

      public void redirect(String url) throws java.io.IOException
      {
         getFacesContext().getExternalContext().redirect(url);
      }

      public String getRequestContextPath()
      {
         return getFacesContext().getExternalContext().getRequestContextPath();
      }

      public String getRequestCharacterEncoding()
      {
         return null;
      }

      public void setRequestCharacterEncoding(String encoding) throws java.io.IOException
      {
      }

      public String getRequestURI()
      {
         return null;
      }
      
      public Map getRequestParameterMap()
      {
         return getFacesContext().getExternalContext().getRequestParameterMap();   
      }
      
      public void dispatch(String requestURI)
         throws IOException
      {
         getFacesContext().getExternalContext().dispatch(requestURI); 
      }
    
   }
}
