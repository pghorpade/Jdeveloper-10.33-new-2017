package oracle.adf.controller.faces.lifecycle;

import java.beans.Beans;

import java.util.HashMap;
import java.util.Map;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import oracle.adf.controller.faces.context.FacesPageLifecycleContext;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.lifecycle.Lifecycle;
import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.model.BindingContext;

/**
 * A Faces phase listener use to bootstrap and execute the ADF PageLifecycle.
 * <p>This is also a factory to create the FacesPageLifecycle instances. Subclass
 * ADFPhaseListener to provide alternate {@link FacesPageLifecycle} instance to
 * all web page. Specify your ADFPhaseListener subclass in the faces-config file
 * to replace the oracle.adf.controller.faces.lifecycle.ADFPhaseListener entry.
 * 
 * @since 10.1.3
 */
public class ADFPhaseListener extends Lifecycle implements PhaseListener
{
   /**
    * Used to store the LifecycleContext on the request map.
    */
   public static final String LifecycleContextRequestParam = "ADFLifecycleContext";

   /**
    * Use to store the current viewRoot on the request map. This is used
    * internaly to detect navigation.
    */
   public static final String CurrentViewRootRequestParam = "ADFCurrentViewRoot";

   /** Singleton PageLifecycle instance */
   private transient PageLifecycle pageLifecycleInstance = null;
   
   // A PhaseInvoker doing nothing that is used as a place holder when nothing
   // need to be done.
   private final PhaseInvoker noop = new PhaseInvoker();
   
   /**
    * Array of PhaseInvoker, one for each phase of the Faces Lifecycle.
    */
   protected final PhaseInvoker phases[];
   
   public ADFPhaseListener()
   {
      phases = new PhaseInvoker[]
      {
         null, // ANY_PHASE placeholder, not a real Phase
         RestoreViewPhase,
         noop,
         noop,
         UpdateModelValuesPhase,
         InvokeApplicationPhase,
         RenderResponsePhase,
      };
   }

   /**
    * Delegate to the PhaseInvoker beforePhase method for each phase based on
    * the phaseId.
    */
   public final void beforePhase(PhaseEvent event)
   {
      if (!isDesignTime())
      {
         final PhaseId phaseId = event.getPhaseId();
         phases[phaseId.getOrdinal()].before(event.getFacesContext());
      }
   }

   /**
    * Delegate to the PhaseInvoker afterPhase method for each phase based on
    * the phaseId.
    */
   public final void afterPhase(PhaseEvent event)
   {
      if (!isDesignTime())
      {
         final PhaseId phaseId = event.getPhaseId();
         phases[phaseId.getOrdinal()].after(event.getFacesContext());
      }
   }

   /**
    * Return the fact that we want to listen to each phase.
    */
   public PhaseId getPhaseId()
   {
      return PhaseId.ANY_PHASE;
   }
   
   /**
    * Utility method to know when we are being used at design time in an IDE.
    */
   protected boolean isDesignTime()
   {
      return Beans.isDesignTime();
   }
   
   /**
    * <p>Create and return the default instance of the ADF PageLifecycle
    * to be used with this web application.</p>
    * The base implementation creates an instance of {@link FacesPageLifecycle}.
    * This method is only called once the first time FacesPageLifecycle is
    * needed, instance is then cached for the lifetime of the application.
    */
   protected PageLifecycle createPageLifecycle()
   {
      return new FacesPageLifecycle();   
   }
   
   /**
    * Internal method used to call the factory only once.
    */
   private PageLifecycle getInternalPageLifecycle()
   {
      if (pageLifecycleInstance == null)
      {
         pageLifecycleInstance = createPageLifecycle();
      }
      
      return pageLifecycleInstance;
   }
   
   /**
    * Execute does not do anything in the Faces case since the phases of the 
    * ADFLifecycle are triggered by the JSF phases.
    */
   public void execute(Map envMap) throws Exception
   {
      // No-op
   }

   /**
    * Our base class for all phase implementation. By default, nothing extra
    * is done.
    */
   class PhaseInvoker
   {
      public void before(FacesContext context)
      {
         // No-op by default
      }
   
      public void after(FacesContext context)
      {
         // No-op by default
      }
      
      /**
       * Utility method to store an object on the requestMap.
       */
      final protected void requestMapPut(FacesContext context, String key,
                                         Object value)
      {
         context.getExternalContext().getRequestMap().put(key, value);
      }
      
      /**
       * Utility method to retrieve an object from the requestMap.
       */ 
      final protected Object requestMapGet(FacesContext context, String key)
      {
         return context.getExternalContext().getRequestMap().get(key);
      }

      /**
       * Store a LifecycleContext on the requestMap.
       * @see #LifecycleContextRequestParam
       */
      final protected void putLifecycleContext(FacesContext context,
                                               LifecycleContext lfContext)
      {
         requestMapPut(context, LifecycleContextRequestParam, lfContext);
      }
      
      /**
       * Retrieve a LifecycleContext from the requestMap.
       * @see #LifecycleContextRequestParam
       */
      final protected LifecycleContext getLifecycleContext(FacesContext context)
      {
         return (LifecycleContext) requestMapGet(context,
                                                 LifecycleContextRequestParam);
      }
      
      /**
       * Store a viewRoot from the requestMap.
       * @see #CurrentViewRootRequestParam
       */
      final protected void putViewRoot(FacesContext context, UIViewRoot viewRoot)
      {
         requestMapPut(context, CurrentViewRootRequestParam, viewRoot);
      }
      
      /**
       * Retrieve a viewRoot from the requestMap.
       * @see #CurrentViewRootRequestParam
       */
      final protected UIViewRoot getViewRoot(FacesContext context)
      {
         return (UIViewRoot) requestMapGet(context, CurrentViewRootRequestParam);
      }
      
   }
   
   /**
    * Implement the beforePhase and afterPhase for the RestoreViewPhase.
    * Register the proper PageLifecycleListener, prepare the LifecycleContext
    * and call the prepareModelPhase of the ADF Lifecycle.
    */
   final PhaseInvoker RestoreViewPhase = new PhaseInvoker()
   {
      // In the beforeRestoreView, we need to set the bindings top level EL
      // variable so that backing bean with a managed-property using bindings
      // can evaluate it.
      public void before(FacesContext context)
      {
         String viewId;

         Map requestMap = context.getExternalContext().getRequestMap();
         
         UIViewRoot viewRoot = context.getViewRoot();
         if (viewRoot != null)
         {
            viewId = viewRoot.getViewId();
         }
         else
         {
            viewId = (String) requestMap.get("javax.servlet.include.path_info");
            if (viewId == null)
            {
               viewId = context.getExternalContext().getRequestPathInfo();
            }
            
            if (viewId == null)
            {
               viewId = (String)
                  requestMap.get("javax.servlet.include.servlet_path");
            }

            if (viewId == null)
            {
               viewId = context.getExternalContext().getRequestServletPath();
            }
         }

         // Lost cause, return
         if (viewId == null)
         {
            return;
         }

         // No session means no bindings.
         if (context.getExternalContext().getSession(false) == null)
         {
            return;
         }

         Map sessionMap = context.getExternalContext().getSessionMap();

         // The sessionScope should had been created by the binding filter. 
         // If it's not it mean we are not dealing with a databound page.
         if (sessionMap == null)
         {
            return;
         }
         
         final BindingContext bctx = (BindingContext)
            sessionMap.get(BindingContext.CONTEXT_ID);
         if (bctx == null)
         {
            return;
         }
         
         // Use the path info to retrieve the RegionBinding and
         // publish the binding container as 'bindings' via the request map.
         requestMap.put(BindingContext.RESERVED_BINDINGS,
                        bctx.findBindingContainerByPath(viewId));
      }
      
      /**
       * after RestoreView phase.
       */
      public void after(FacesContext context)
      {
         UIViewRoot viewRoot = context.getViewRoot();
         String viewId = (viewRoot != null) ? viewRoot.getViewId() : null;
      
         if (viewId == null)
         {
            return;
         }
      
         // No session means no bindings.
         if (context.getExternalContext().getSession(false) == null)
         {
            return;
         }

         // Store the current view root so that we can detect if navigation
         // occured when we execute the before RenderResponse.
         putViewRoot(context, viewRoot);

         Map envMap = ADFPhaseListener.this.getEnvMap(context);
         
         try
         {
            LifecycleContext lfContext = LifecycleContext.getInstance(envMap);

            putLifecycleContext(context, lfContext);         
            
            // Execute the INIT_CONTEXT phase
            executePhase(INIT_CONTEXT, lfContext);
            
            // Execute the PREPARE_MODEL phase
            executePhase(PREPARE_MODEL, lfContext);
         }
         catch (Exception ex)
         {
            
         }
         
      }  // End of after method
   };
   
   final PhaseInvoker UpdateModelValuesPhase = new PhaseInvoker()
   {
      /**
       * after UpdateModelValue phase.
       * Process Model validation
       */
      public void after(FacesContext context)
      {
         LifecycleContext lfContext = getLifecycleContext(context);
   
         if (lfContext != null)
         {
            // Execute the VALIDATE_MODEL_UPDATES phase
            executePhase(VALIDATE_MODEL_UPDATES, lfContext);
            
            // Propagate the skiping of phase to the JSF Lifecycle.
            if (lfContext.getPrepareRender())
            {
               context.renderResponse();
            }
         }
      } // End of after method
   };
   
   final PhaseInvoker InvokeApplicationPhase = new PhaseInvoker()
   {
      /**
       * after InvokeApplication phase.
       * Produced to auto commit any DT@RT changes.
       */
      public void after(FacesContext context)
      {
         LifecycleContext lfContext = getLifecycleContext(context);
         
         if (lfContext != null)
         {
            // Execute the METADATA_COMMIT phase
            executePhase(METADATA_COMMIT, lfContext);
         }
      }
   };

   final PhaseInvoker RenderResponsePhase = new PhaseInvoker()
   {
      /**
       * before RenderResponse phase.
       */
      public void before(FacesContext context)
      {
         UIViewRoot newViewRoot = context.getViewRoot();
         UIViewRoot viewRoot = getViewRoot(context);
         LifecycleContext lfContext = getLifecycleContext(context);

         // Detect if nagivation occured
         // If the view going to be rendered is different from the one that
         // has being prepared, refreshed the old one.
         if (newViewRoot != viewRoot)
         {
            if (lfContext != null)
            {
               putViewRoot(context, newViewRoot);

               // Create a new context for the new view
               Map envMap = ADFPhaseListener.this.getEnvMap(context);
         
               try
               {
                  lfContext = LifecycleContext.getInstance(envMap);

                  putLifecycleContext(context, lfContext);         
                  
                  // Execute the INIT_CONTEXT phase
                  executePhase(INIT_CONTEXT, lfContext);
                  
                  // Execute the PREPARE_MODEL phase of the new view.
                  executePhase(PREPARE_MODEL, lfContext);
               }
               catch (Exception ex)
               {
                  
               }

            }
         }
   
         // Event might had been updated in case of navigation.
         if (lfContext != null)
         {
            // Execute the PREPARE_RENDER phase.
            executePhase(PREPARE_RENDER, lfContext);
         }
      } // End of before method
   };
   
     
   /**
    * Initialize the environment map that will be use to create a new
    * LifecycleContext.
    * The Lifecycle context instance itself will not be created until the 
    * {@link oracle.adf.controller.v2.lifecycle.Phases#initContext INIT_CONTEXT}
    * phase of the Lifecycle.
    */
   protected Map getEnvMap(FacesContext context)
   {
      final HashMap envMap = new HashMap();
      
      // We need the Faces context
      envMap.put(FacesPageLifecycleContext.FACES_CONTEXT_KEY, context);
 
      // And the Lifecycle impl.
      envMap.put(LifecycleContext.PAGE_LIFECYCLE_KEY,
                 getInternalPageLifecycle());
 
      return envMap;
   }
}
