package oracle.adf.controller.faces.lifecycle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import oracle.adf.controller.faces.context.FacesPageLifecycleContext;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.controller.v2.lifecycle.PageLifecycleImpl;
import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCControlBinding;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.faces.util.LabeledFacesMessage;

import oracle.adfinternal.view.faces.model.binding.OrdDomainValueHandler;

import oracle.binding.AttributeBinding;

import oracle.jbo.JboException;
import oracle.jbo.LocaleContext;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;


/**
 * Custom implementation of the PageLifecycle tailored to Faces applications
 * needs.
 *
 * @since 10.1.3
 */
public class FacesPageLifecycle extends PageLifecycleImpl
{
   /** The handlerId for OrdDomainValueHandler. */
   public static final String ordDomainValueHandlerName = "OrdDomainValueHandler";
   
   private static final ADFLogger logger =
      ADFLogger.createADFLogger(FacesPageLifecycle.class.getName());
   
   /**
    * Return the custom Lifecycle context class to use with this PageLifecycle.
    */
   public Class getLifecycleContextClass()
   {
      return FacesPageLifecycleContext.class;
   }

   public void prepareModel(LifecycleContext lfContext)
   {
      final FacesContext facesContext = ((FacesPageLifecycleContext) lfContext).getFacesContext();
      final BindingContext bindingContext = lfContext.getBindingContext();
      // Override the LocaleContext on the Model that was set in the
      // ADFBindingFilter using the request setting. The LocaleContext need to
      // match the Faces one.

      bindingContext.setLocaleContext(new LocaleContext()
         {
            public Locale getLocale()
            {
               return facesContext.getViewRoot().getLocale();
            }
         }
      );       

      super.prepareModel(lfContext);
   }

   /**
    * Retrieve the token from the UIViewRoot. In Faces, the token is persisted
    * between requests using a viewRoot attribute.
    */
   protected String getToken(PageLifecycleContext plContext,
                             RegionBinding bindings)
   {
      FacesContext facesContext = ((FacesPageLifecycleContext) plContext).getFacesContext();
      String stateId = ((DCBindingContainer)bindings).getStateTokenId();

      UIViewRoot viewRoot = facesContext.getViewRoot();
      String token = null;
      if (viewRoot != null)
      {
         Map viewAttributes = viewRoot.getAttributes();
         token = (String) viewAttributes.get(stateId);
      }

      return token;
   }

   public void prepareRender(LifecycleContext lfContext)
   {
      super.prepareRender(lfContext);

      DCBindingContainer bindings = (DCBindingContainer) lfContext.getBindingContainer();
      if (bindings == null)
      {
         return;
      }

      FacesPageLifecycleContext context = (FacesPageLifecycleContext) lfContext;

      // Save the ReginBinding state token in the UIViewRoot attributes
      UIViewRoot viewRoot = context.getFacesContext().getViewRoot();
      if (viewRoot != null)
      {
         Map viewAttributes = viewRoot.getAttributes();
         viewAttributes.put(bindings.getStateTokenId(), bindings.getStateToken());
      }
   }


   protected void registerCustomInputHandler(PageLifecycleContext context)
   {
       super.registerCustomInputHandler(context);

       final BindingContext bctx = context.getBindingContext();
       if (bctx == null)
       {
          return;
       }

       JUCtrlInputValueHandler inputHandler = (JUCtrlInputValueHandler)
           bctx.getBindingInputHandler(ordDomainValueHandlerName);
       if (inputHandler == null)
       {
           inputHandler = new OrdDomainValueHandler();

           // Initialize default InputHandler here
           HashMap inputHandlerMap =
                 (HashMap)bctx.get(bctx.INPUT_VALUE_HANDLERS);
           if ( inputHandlerMap == null )
           {
              inputHandlerMap = new HashMap(2);
           }

           inputHandlerMap.put(ordDomainValueHandlerName, inputHandler);
       }
   }



   /**
    * Build an error list in a format appropriate for Faces.
    */
   public void reportErrors(PageLifecycleContext context)
   {
      if (context.getPageController().hasErrors(context))
      {
         RegionBinding bindings = context.getBindingContainer();
         FacesContext facesContext = ((FacesPageLifecycleContext) context).getFacesContext();
         
         List addedErrors = new ArrayList();
         processBindingErrors(facesContext, bindings, addedErrors);

         List runtimeErrors = ((DCBindingContainer) bindings).getExceptionsList();
         if (runtimeErrors != null)
         {
            for (int i = 0; i < runtimeErrors.size(); i++)
            {
               addError(facesContext, addedErrors,
                        i, 0, (Throwable)runtimeErrors.get(i));
            }
         }
      }
   }

   /**
    * Add error messages for each attribute binding with an error.
    * Walk the list of {@link oracle.binding.AttributeBinding} and call the
    * {@link #addMessage addMessage} method when the binding has an error.
    */
   protected void processBindingErrors(FacesContext context,
                                       RegionBinding bindings,
                                       List addedErrors)
   {
      List attributeBindings = bindings.getAttributeBindings();
      
      for (int i=0; i < attributeBindings.size(); i++)
      {
         AttributeBinding binding = (AttributeBinding) attributeBindings.get(i);
         
         List errors = binding.getErrors();
         if (errors == null)
         {
            continue;
         }
         
         for (int errIndex = 0; errIndex < errors.size(); errIndex++)
         {
            Throwable error = (Throwable) errors.get(errIndex);
            addedErrors.add(error);
            addMessage(context, binding, error);
         }
      }
   }
   
   /**
    * This base class method is overriden to fix the 
    * Bug 5630740
    * This method ensured the error message getting
    * reported to the UI.
    * 
    * @param context the FacesContext
    */
    public void processComponentEvents(LifecycleContext context)
    {
        super.processComponentEvents(context);
        if (hasErrors((PageLifecycleContext)context))
        {
            super.prepareRender(context);
        } 
    }

   /**
    * This method is called for each error that need to be reported to the page.
    * It creates a new FacesMessage given the exception passed as a parameter.
    * If the binding parameter is defined, the Faces message is added using the
    * clientId associated with the binding.
    * 
    * Overide this method to customize the appearance of the message.
    * 
    * @param context the FacesContext
    * @param binding the AttributeBinding associated with this error if any
    * @param error the exception being thrown
    */
   protected void addMessage(FacesContext context, AttributeBinding binding,
                             Throwable error)
   {
      FacesMessage facesMessage;
      String clientId = null;
      String summary = error.getLocalizedMessage();

      // In some case the message is empty, try to get some sort of meaning to
      // the message, using the class name of the error.
      if (summary == null || summary.length() == 0)
      {
         summary = error.getClass().getName();
      }

      if (binding != null)
      {
         String detail = summary;
         String label = binding.getLabel();
         clientId = (String) ((DCControlBinding) binding).get("componentClientId");

         facesMessage = new LabeledFacesMessage(FacesMessage.SEVERITY_ERROR,
                                             summary, detail, label);
         logger.log(ADFLogger.TRACE, label + ": " + summary);
      }
      else
      {
         facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, null);
         logger.log(ADFLogger.WARNING, summary);
      }
      
      context.addMessage(clientId, facesMessage);
   }
   
   /**
    * Recursive method to walk through the tree of error reported by the
    * BindingContainer. For each error not yet reported for the page, the
    * {@link #addMessage addMessage} method will be called.
    */
   protected void addError(FacesContext context, List addedErrors,
                           int num, int lev, Throwable ex)
   {
      logger.fine(ex);

      if (!(ex instanceof JboException))
      {
         // Not a JboException, add the error message and return
         addMessage(context, null, ex);
         return;
      }

      JboException jex = (JboException)ex;
      Object[] nextLevDetails = jex.getDetails();

      if (jex.hasPeerExceptions())
      {
         if (nextLevDetails != null && nextLevDetails.length == 1)
         {
            //only one exception in next level.
            //skip this exception and add the next one at the same level.
            addError(context, addedErrors, num, lev, (Throwable)nextLevDetails[0]);
            return;
         }
      }

      // Make sure to not duplicate the errors already added by processBindingErrors
      if (!addedErrors.contains(ex))
      {
         addMessage(context, null, ex);

         if (nextLevDetails != null)
         {
            for (int j = 0; j < nextLevDetails.length; j++)
            {
               addError(context, addedErrors,
                        j, lev + 1,  (Throwable) nextLevDetails[j]);
            }
         }
      }
   }

}
