package oracle.adf.controller.v2.context;
import javax.servlet.ServletContext;

import oracle.adf.controller.v2.lifecycle.DefaultPageLifecycleFactory;
import oracle.jbo.common.JBOClass;

/**
 * Retrieve a factory from the servlet context.
 * 
 * <p>Subclass 
 * {@link oracle.adf.controller.v2.lifecycle.PageLifecycleFactory PageLifecycleFactory}
 * to create your own PageLifecycleFactory and provide alternate
 * {@link oracle.adf.controller.v2.lifecycle.PageLifecycle PageLifecycle}
 * instance to all web page.
 * Specify your PageLifecycleFactory subclass in the web-xml file using the
 * ADFPageLifecycleFactory init param:</p>
 * <pre>
 * &lt;web-app&gt;
 * &nbsp;&nbsp;&lt;context-param&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-name&gt;ADFPageLifecycleFactory&lt;/param-name&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param-value&gt;mypackage.myLifecycleFactory&lt;/param-value&gt;
 * &nbsp;&nbsp;&lt;/context-param&gt;
 * &nbsp;&nbsp;...
 * &lt;/web-app&gt;
 * </pre>
 * 
 * <p>If no alternate PageLifecycleFactory is defined in the web-xml, the
 * default is to use 
 * {@link oracle.adf.controller.v2.lifecycle.DefaultPageLifecycleFactory DefaultPageLifecycleFactory}.
 * 
 * @since 10.1.3
 */
public abstract class ServletFactoryFinder 
{
   /**
    * Name of this factory
    */
   private final String factoryName;
   
   /**
    * Name of the servlet context init parameter used to defined a custom
    * factory. The value of this parameter is the fully qualified
    * class name of the new factory.
    */
   private final String initParamName;
   
   /**
    * Name of the servlet context attribute used to save the instance of the
    * factory for this web application.
    */
   private final String contextAttributeName;
   
   public ServletFactoryFinder(String factoryName,
                               String initParamName,
                               String contextAttributeName)
   {
      this.factoryName = factoryName;
      this.initParamName = initParamName;
      this.contextAttributeName = contextAttributeName;
   }
   
   /**
    * Helper method to instanciate the factory given the ServletContext. The
    * ServletContext possibly contain the class name of a sustitued factory as
    * the value an init parameter. Once the factory class is determined, the
    * instance is cached as a parameter of the servlet context.
    * 
    * @param servletContext
    * @return the factory 
    */
   public final Object getFactory(ServletContext servletContext)
   {
      if (servletContext == null)
      {
         return null;
      }
      
      // Default factory instance is stored in the application context.
      Object  instance = servletContext.getAttribute(contextAttributeName);
      if (instance != null)
      {
         return instance;
      }
      
      // Retrieve the default instance class name from the web.xml initparam
      String factoryClassName =
         servletContext.getInitParameter(initParamName);

      if (factoryClassName != null && factoryClassName.trim().length() > 0)
      {
         try
         {
            Class cls = JBOClass.forName(factoryClassName);
            instance = cls.newInstance();
         }
         catch (Exception ex)
         {
            servletContext.log("Error instanciating custom" + factoryName +
                               ". Using default...", ex);
         }
      }

      // Last resort, use the default instance
      if (instance == null)
      {
         instance = getDefaultFactory();
      }

      // Store it in the application context
      servletContext.setAttribute(contextAttributeName, instance);
      
      return instance;
   }
   
   public String getFactoryName()
   {
      return factoryName;
   }
   
   /**
    * Return the servlet context init parameter name used to defined a custom
    * factory
    */
   public String getInitParamName()
   {
      return initParamName;
   }
   
   /**
    * Return the servlet context attribute name used to save the instance of the
    * factory for this web application.
    */
   public String getContextAttributeName()
   {
      return contextAttributeName;
   }
   
   /**
    * Return the default factory instance
    */
   protected abstract Object getDefaultFactory();
   
   /**
    * Retrieve from the ServletContext a PageLifecycleFactory using the
    * initParam ADFPageLifecycleFactory and of type
    * {@link oracle.adf.controller.v2.lifecycle.PageLifecycleFactory PageLifecycleFactory}
    * This is used by the 
    * {@link oracle.adf.controller.jsp.taglib.PageDefinitionTag PageDefinitionTag}
    * in the Model 1 environment.
    */
   public static final ServletFactoryFinder PAGELIFECYCLE_FACTORY =
      new ServletFactoryFinder("PageLifecycleFactory",
                               "ADFPageLifecycleFactory",
                               "oracle.adf.controller.v2.lifecycle.PageLifecycleFactory" )
      {
         public Object getDefaultFactory()
         {
            return new DefaultPageLifecycleFactory();
         }
      };
      
   
}
