package oracle.adf.controller.v2.context;

import java.util.Map;

import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.controller.v2.lifecycle.PagePhaseListener;
import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCUtil;
import oracle.adf.share.ADFContext;
import oracle.adf.share.Environment;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.common.JBOClass;


/**
 * <p><CODE>LifecycleContext</CODE> is the base class for all context classes
 * used in the ADF Lifecycle. It contains all the state information that will
 * be kept during the execution of the ADF Lifecycle. It is passed as a 
 * parameter of each phase execution.</p>
 *
 * <p>This context object lives for the duration of the current Lifecycle.</p>
 * 
 * @since 10.1.3
 */
public class LifecycleContext
{
   /**
    * The map used to store the context.
    */
   protected final Map envMap;
   
   /**
    * Key used to store the PageLifecycle instance in the context map.
    */
   public static final String PAGE_LIFECYCLE_KEY      = "pageLifecycle";
   private static final String PAGE_CONTROLLER_KEY    = "pageController";
   private static final String PAGE_PHASELISTENER_KEY = "pagePhaseListener";
   private static final String PREPARE_RENDER_KEY     = "prepareRender";
   
   private static final ADFLogger logger =
      ADFLogger.createADFLogger(LifecycleContext.class.getName());
   

   /**
    * Constructor using a Map.
    */
   public LifecycleContext(Map envMap)
   {
      this.envMap = envMap;
      initControllerClass();
   }
   
   /**
    * Instanciate the LifecycleContext associated with a PageLifecycle. The
    * PageLifecycle is stored in the map using the PAGE_LIFECYCLE_KEY key.
    * @param envMap map containing the lifecycle object
    * @return the LifecycleContext
    */
   public static LifecycleContext getInstance(Map envMap)
      throws Exception
   {
      return getInstance(envMap, (PageLifecycle) envMap.get(PAGE_LIFECYCLE_KEY));
   }
   
   /**
    * Instanciate the LifecycleContext associated with a PageLifecycle. The
    * LifecycleContext class to instanciate is retrieve from the Lifecycle
    * using getLifecycleContextClass().
    * @param envMap The map of properties that will be used to initialize the
    *               context.
    * @param lifecycle The PageLifecycle instance.
    * @return the LifecycleContext
    */
   public static LifecycleContext getInstance(Map envMap,
                                              PageLifecycle lifecycle)
      throws Exception
   {
      // The context class is always stored with the Lifecycle using it.
      Class cls = lifecycle.getLifecycleContextClass();

      if (cls != null)
      {
         Object obj = cls.getConstructor(new Class[]{Map.class}).newInstance(new Object[]{envMap});
         return (LifecycleContext) obj;
      }

      // Last resort, create the default context
      return new LifecycleContext(envMap);
   }
   
   /**
    * Retrieve the anonymous environment.
    * Simply delegate to the ADFContext routine.
    * @see oracle.adf.share.ADFContext#getEnvironment()
    */
   public Environment getEnvironment()
   {
      return ADFContext.getCurrent().getEnvironment();
   }
   
   /**
    * Retrieve the BindingContext object for the current session.
    */
   public BindingContext getBindingContext()
   {
      Map sessionScope = null;
      
      // When the ADFBindingFilter is missing, the Web environment is not
      // initialized so getEnvironment throws.
      try
      {
         sessionScope = ADFContext.getCurrent().getSessionScope();
      }
      catch (UnsupportedOperationException ex)
      {
         return null;
      }

      // The sessionScope should had been created by the binding filter. 
      // If it's not it mean we are not dealing with a databound page.
      if (sessionScope == null)
      {
         return null;
      }
      return (BindingContext) sessionScope.get(BindingContext.CONTEXT_ID);
   }

   /**
    * Retrieve the RegionBinding instance for the current page.
    */
   public RegionBinding getBindingContainer()
   {
      final BindingContext bctx = getBindingContext();
      if (bctx == null)
      {
         return null;
      }
      
      // Retrieve the path
      final String path = getPath();
      if (path == null || path.length() == 0)
      {
         return null;
      }
      
      // Use the path info to retrieve the RegionBinding
      return bctx.findBindingContainerByPath(path);
   }
   
   /**
    * Retrieve the path info for the current page.
    * Currently using the pathInfo or the servletPath from the request.
    * @return the path for the current page.
    */
   protected String getPath()
   {
      // First retrieve the current path
      String path = getEnvironment().getRequestPathInfo();
      if (path == null || path.length() == 0)
      {
         path = getEnvironment().getRequestServletPath();
      }
      
      return path;
   }
   
   /**
    * Retrieve the PageLifecycle object from the context map.
    * @return Lifecycle object in use for the current request.
    */
   public PageLifecycle getPageLifecycle()
   {
      return (PageLifecycle) envMap.get(PAGE_LIFECYCLE_KEY);
   }

   /**
    * Store a PageLifecycle object in the context map.
    * @param lifeCycle Lifecycle object to use for the current request.
    */
   public void setPageLifecycle(PageLifecycle lifeCycle)
   {
      envMap.put(PAGE_LIFECYCLE_KEY, lifeCycle);
   }
   
   /**
    * Retrieve the PageController from the context map.
    * @return PageController object in use for the current request.
    */
   public PageLifecycle getPageController()
   {
      return (PageLifecycle) envMap.get(PAGE_CONTROLLER_KEY);
   }
   
   /**
    * Store the PageController Object in the Lifecycle context map.
    * @param lifeCycle PageLifecycle object to use for the current request.
    */
   public void setPageController(PageLifecycle lifeCycle)
   {
      envMap.put(PAGE_CONTROLLER_KEY, lifeCycle);
   }

   /**
    * Retrieve the PagePhaseListener from the context map.
    * @return PagePhaseListener object in use for the current request.
    */
   public PagePhaseListener getPagePhaseListener()
   {
      return (PagePhaseListener) envMap.get(PAGE_PHASELISTENER_KEY);
   }
   
   /**
    * Store the PagePhaseListener Object in the Lifecycle context map.
    * @param pagePhaseListener PagePhaseListener object to use for the current request.
    */
   public void setPagePhaseListener(PagePhaseListener pagePhaseListener)
   {
      envMap.put(PAGE_PHASELISTENER_KEY, pagePhaseListener);
   }

   /**
    * <p>Return <code>true</code> if the {@link #prepareRender prepareRender}
    * method has been called.</p>
    */
   public boolean getPrepareRender()
   {
      final Boolean prepareRender = (Boolean) envMap.get(PREPARE_RENDER_KEY);
      
      if (prepareRender == null)
      {
         return false;
      }
      
      return prepareRender.booleanValue();
   }
   
   /**
    * <p>Indicate to the Lifecycle that the next phase to be executed should be
    * PREPARE_RENDER, by-passing any other phase left in the lifecycle.</p>
    */
   public void prepareRender()
   {
      envMap.put(PREPARE_RENDER_KEY, Boolean.valueOf(true));
   }
   
   /**
    * Initialize the
    * {@link oracle.adf.controller.v2.lifecycle.PageController PageController}
    * instance that will be used during this PageLifecycle. First retrieve the
    * instance, then store it in the context map.
    * The object to use is specified using the ControllerClass property of the 
    * PageDefinition xml file. This object can be specified in one of two ways:
    * <ul>
    *   <li>
    *   By using the className of the PageController in which case the object
    *   will be created.
    *   </li>
    *   <li>
    *   Using an EL expression pointing to an existing instance of the
    *   PageController.  
    *   </li>
    * </ul>
    * If the ControllerClass property of the PageDefinition is empty or not of
    * correct type, uses the default PageLifecycle for PageController.
    * The PageController instance is stored in the context using PageController
    * property.
    * If the ControllerClass property is a 
    * {@link oracle.adf.controller.v2.lifecycle.PagePhaseListener PagePhaseListener},
    * instanciate it and store it in the PagePhaseListener property of the context.
    */
   protected void initControllerClass()
   {
      PageLifecycle page = null;

      try
      {
         DCBindingContainer bindings = (DCBindingContainer) getBindingContainer();
         String className = null;
         
         if (bindings != null)
         {
            className = bindings.getDef().getControllerClassName();
         }

         if (className != null && className.length() > 0)
         {
            Object obj;
            if (DCUtil.isElExpr(className))
            {
               obj = DCUtil.elEvaluate(getBindingContext(), null, className);
            }
            else
            {
               Class cls = JBOClass.forName(className);
               obj = cls.newInstance();
            }
            
            if (obj instanceof PageLifecycle)
            {
               logger.log(ADFLogger.TRACE,
                  "[ADFc] Using a custom PageController: " + obj.getClass().getName());
               page = (PageLifecycle) obj;
            }
            
            if (obj instanceof PagePhaseListener)
            {
               logger.log(ADFLogger.TRACE,
                  "[ADFc] Using a PagePhaseListener: " + obj.getClass().getName());
               setPagePhaseListener((PagePhaseListener) obj);
            }
         }
      }
      catch (Exception e)
      {
         logger.log(ADFLogger.TRACE, "[ADFc] Error creating ControllerClass, using the default implementation " + e.getMessage(), e);
      }
      
      if (page == null)
      {
         // When no custom implementation of the PageController is defined,
         // uses the default PageLifecycle.
         page = getPageLifecycle();
      }

      // Store page controller in the context
      setPageController(page);
   }
   
}
