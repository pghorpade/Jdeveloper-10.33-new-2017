package oracle.adf.controller.v2.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.adf.model.OperationBinding;


/**
 * <p><CODE>PageLifecycleContext</CODE> contains all the state information that
 * will be kept during the PageLifecycle. It is passed as a parameter of each
 * phase execution.</p>
 * <p>Since it extends the HashMap class it can be use to append additional user
 * data.</p>
 *
 * <p>This context object lives for the duration of the current Lifecycle.</p>
 *
 * @since 10.1.3
 */
public class PageLifecycleContext extends LifecycleContext
{
   /**
    * The default value to be used by the lifecycle to reconize
    * an event in a parameter name.
    */
   public static final String EVENT_PREFIX = "event";
   
   /**
    * Prefix used for each event method.
    */
   public static final String EVENT_METHOD_PREFIX = "on";
   
   protected static final String UPDATED_VALUES_KEY           = "updatedValues";
   protected static final String VALIDATE_ERROR_KEY           = "validateError";
   protected static final String CONTROL_ACTION_BINDINGS_KEY  = "actionBindings";
   protected static final String EVENT_PREFIX_KEY             = "event";
   protected static final String EVENTS_KEY                   = "events";
   protected static final String ACTION_BINDING_KEY           = "actionBinding";
   protected static final String ALLOW_MODEL_UPDATE_KEY       = "allowModelUpdate";
   protected static final String FORWARD_PATH_BINDINGS_KEY    = "forwardPath";
   protected static final String REDIRECT_BINDINGS_KEY        = "redirect";

   
   public PageLifecycleContext(Map envMap)
   {
      super(envMap);
      
      // Set default value for the event prefix
      setEventPrefix(EVENT_PREFIX);
   }
   
   /**
    * Retrieve a map of the parameters for the current request.
    * @return the map
    */
   public Map getParameterMap()
   {
      return getEnvironment().getRequestParameterMap();
   }
      
   public void setUpdatedValues(Map updatedValues)
   {
      envMap.put(UPDATED_VALUES_KEY, updatedValues);
   }
   
   public Map getUpdatedValues()
   {
      return (Map) envMap.get(UPDATED_VALUES_KEY);
   }
   
   /**
    * Cache errors occuring during validateInputValues phase
    */
   public void setInputValidationErrors(Map errors)
   {
      envMap.put(VALIDATE_ERROR_KEY, errors);
   }
   
   /**
    * Retrieve errors that occured during validateInputValues phase
    */
   public Map getInputValidationErrors()
   {
      return (Map) envMap.get(VALIDATE_ERROR_KEY);
   }
   
   /**
    * This method add an action binding to the collection of action being
    * executed. Each action binding is keyed by an event name.
    * 
    * @param event an event name
    * @param actionBinding the action binding to be associated with the event
    */
   public void addControlActionBinding(String event, 
                                       OperationBinding actionBinding)
   {
      Map actionBindings = getControlActionBindings();
      
      if (actionBindings == null)
      {
         actionBindings = new HashMap();
         envMap.put(CONTROL_ACTION_BINDINGS_KEY, actionBindings);
      }

      actionBindings.put(event, actionBinding);
   }

   /**
    * Retrieve a list of all action binding keyed by event name.
    * @return Map of control action bindings 
    */
   public Map getControlActionBindings()
   {
      return (Map) envMap.get(CONTROL_ACTION_BINDINGS_KEY);
   }
   
   /**
    * Add an event name to the list of event to be handled during this
    * lifecycle.
    * 
    * @param event an event name
    */
   public void addEvent(String event)
   {
      List events = getEvents();
      
      if (events == null)
      {
         events = new ArrayList();
         envMap.put(EVENTS_KEY, events);
      }
      
      events.add(event);
   }
   
   /**
    * Retrieve the list of event names to be handled during this lifecycle.
    * @return List of event names to be handled.
    * @see     oracle.adf.controller.v2.lifecycle.PageLifecycle#applyInputValues
    */
   public List getEvents()
   {
      return (List) envMap.get(EVENTS_KEY);
   }

   /**
    * Set the ActionBinding for the current event. This is used internally to
    * prepare the context before calling the event handler.
    * @param action Action binding to invoke as the event's default action.
    */
   public void setEventActionBinding(OperationBinding action)
   {
      envMap.put(ACTION_BINDING_KEY, action);
   }

   /**
    * Retrieve the ActionBinding associated with the current event. This is
    * usefull when you overide the handler for a specific event because it
    * allows you to execute the associated ActionBinding. The default handler
    * always execute the ActionBinding.
    * <p>
    * Here is an example for an event named Commit:
    * <pre>
    * public void onCommit(PageLifecycleContext ctx)
    * {
    *    // write pre-execution logic here
    *    
    *    ctx.getEventActionBinding().invoke();
    *    
    *    // write post-execution logic here
    * }
    * </pre>
    * <p>
    * Return null is no ActionBinding is associated with this event.
    * 
    * @return an OperationBinding
    */
   public OperationBinding getEventActionBinding()
   {
      return (OperationBinding) envMap.get(ACTION_BINDING_KEY);
   }


   /**
    * <p>Set the prefix that will be used to reconize event request parameters.
    * To change the default prefix "event", call this method with a different 
    * prefix every time the lifecycle context is initialized.</p>
    * 
    * <p>?event=xxx
    * <p>name="event_xxx"
    * 
    * @param prefix  the new prefix string 
    * @see           #EVENT_PREFIX
    */
   public void setEventPrefix(String prefix)
   {
      envMap.put(EVENT_PREFIX_KEY, prefix);
   }
   
   /**
    * Retrieve the event prefix from the context.
    * @return  the prefix string
    * @see     #EVENT_PREFIX
    */
   public String getEventPrefix()
   {
      return (String) envMap.get(EVENT_PREFIX_KEY);
   }
   
   /**
    * Set the path of the page to which the Lifecycle should forward.
    * @param path Relative path of next page.
    * @see        oracle.adf.controller.v2.lifecycle.PageLifecycle#findForward
    * @see        #setRedirect
    */
   public void setForwardPath(String path)
   {
      if (path != null)
      {
         path = path.trim();
      }
      envMap.put(FORWARD_PATH_BINDINGS_KEY, path);
   }
   
   /**
    * Retrieve the path of the page that the Lifecycle will forward to.
    * @return Path of next page
    * @see    oracle.adf.controller.v2.lifecycle.PageLifecycle#findForward
    */
   public String getForwardPath()
   {
      return (String) envMap.get(FORWARD_PATH_BINDINGS_KEY);
   }

   /**
    * Specify if the page path information defined using the setForwardPath
    * should be use to forward the request or redirect the response.
    * @param redirect   a boolean
    * @see              #setForwardPath
    * @see              oracle.adf.controller.v2.lifecycle.PageLifecycle#findForward
    */
   public void setRedirect(boolean redirect)
   {
      envMap.put(REDIRECT_BINDINGS_KEY, redirect ? "true" : "false");
   }

   /**
    * Retrieve the redirect setting from the context.
    * @return  the value of the redirect flag.
    * @see     #setRedirect
    */
   public boolean getRedirect()
   {
      String redirect = (String) envMap.get(REDIRECT_BINDINGS_KEY);
      if (redirect != null && redirect.equalsIgnoreCase("true"))
      {
         return true;
      }
      
      return false;
   }
 
}
