package oracle.adf.controller.v2.struts.forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.struts.forms.ADFDynaClass;
import oracle.adf.controller.struts.forms.ADFStrutsForm;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.lifecycle.LifecycleProcessor;
import oracle.adf.controller.v2.struts.actions.DataActionMapping;
import oracle.adf.controller.v2.struts.context.StrutsPageLifecycleContext;
import oracle.adf.model.BindingContext;
import oracle.adf.model.ControlBinding;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.uicli.binding.JUCtrlListBinding;

import oracle.jdeveloper.html.HTMLElement;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;


/**
 * A BindingContainerActionForm to use with Struts validation framework.
 * 
 * @since 10.1.3
 */
public class BindingContainerValidationForm extends ValidatorForm
   implements DynaBean, ADFStrutsForm
{
   /**
    * The name of the current binding container this class is exposing.
    */
   protected String bindingContainerPath;

   /**
    * The ADFDynaClass with which we are associated.
    */
   transient protected ADFDynaClass     dynaClass;
   protected final Map dynaValues = new HashMap();
   
   /**
    * The bindingcontext in the session
    */
   transient protected BindingContext bindingContext;
   
   /**
    * A flag used to determine if the updates should be applied
    */
   boolean ignoreUpdate;
   
   /**
    * @deprecated Not needed since the binding container is now figured out
    * from the modelRef property of the action mapping.
    */
   public void setBindingContainer(DCBindingContainer container)
   {
      //No-op
   }
   
   /**
    * Retrieve the BindingContainer currently associated with this form.
    */
   protected RegionBinding getBindingContainer()
   {
      if (bindingContainerPath == null || bindingContext == null)
      {
         return null;
      }
      
      return bindingContext.findBindingContainerByPath(bindingContainerPath);
   }
   
   // ADFStrutsForm interface implementation
   public Map getPendingValues()
   {
      return dynaValues;   
   }
   
   public void resetPendingValues()
   {
      dynaValues.clear();   
   }
   
   public Object get(String name)
   {
      final RegionBinding bindings = getBindingContainer();

      if (name.equals("bindings"))
         return bindings;
      
      ControlBinding binding = (ControlBinding) bindings.getControlBinding(name);
      if (binding == null)
      {
         if (DCUtil.isValueBindingPath(name))
         {
            name = DCUtil.getValueBindingNameFromPath(name);
            name = name.replace('#', DCUtil.SEP_DOT_CHAR);
            binding = (ControlBinding) bindings.getControlBinding(name);
         }
      }
      
      if (! (binding instanceof JUCtrlListBinding) &&
          dynaValues.containsKey(name))
      {
         return dynaValues.get(name);
      }
      
      if (binding == null)
      {
         if (binding == null)
            return "Unknown binding name:" + name;
      }

      return binding;
   }
   
   public boolean contains(String name, String key)
   {
      return false;
   }

   public Object get(String name, int index)
   {
      //Not supported
      return null;
   }

   public Object get(String name, String key)
   {
      //Not supported
      return null;
   }

   public DynaClass getDynaClass()
   {
      if (dynaClass == null)
      {
         dynaClass = new ADFDynaClass((DCBindingContainer) getBindingContainer());
      }
      return dynaClass;
   }

   public void remove(String p0, String p1)
   {
      //Not supported
   }
   
   public void set(String name, Object value)
   {
      if (ignoreUpdate)
         return;
      
      if (DCUtil.isValueBindingPath(name))
      {
         name = DCUtil.getValueBindingNameFromPath(name);
         name = name.replace('#', DCUtil.SEP_DOT_CHAR);
      }

      dynaValues.put(name, value);
   }
   
   public void set(String name, int index, Object value)
   {
      //Not supported
   }

   public void set(String name, String attribute, Object value)
   {
      //Not supported
   }

   public void reset(ActionMapping mapping, HttpServletRequest request)
   {
      super.reset(mapping, request);

      // Initialize the member variable that will be used to
      // retrieve the bindingContainer instance from the name
      bindingContext = DCUtil.getBindingContext(request);
    
      // Reset the input state on the previous form if defined.
      final RegionBinding bindings = getBindingContainer();
      if (bindings != null)
      {
         //TODO: Shailesh should move this method up one notch
         ((DCBindingContainer) bindings).resetInputState();
      }
      
      // Initialize the binding container path using the request URI
      // The name is kept to retrieve the bindingContainer instance.
      //TODO: Deal with Struts module and parameterized path
      String path = request.getPathInfo();
      if (path == null || path.length() == 0)
      {
         path = request.getServletPath();
      }

      bindingContainerPath = path;

      // Find out if the current bindingContainer should accept updates. The
      // rule is, only updates coming from the same binding container are
      // legitimate.
      ignoreUpdate = false;
      RegionBinding oldBinding = DCUtil.getBindingContainer(request);
      if (oldBinding != null && bindingContainerPath != null)
      {
         RegionBinding newBinding = getBindingContainer();
         if (newBinding != null && 
             !newBinding.getName().equals(oldBinding.getName()))
         {
            ignoreUpdate = true;   
         }
      }

      // Reset the dynaclass so that it will be rebuild using the new binding
      // container name.
      dynaClass = null;
   }
   
   public ActionErrors validate(ActionMapping mapping, HttpServletRequest request)
   {
      if (dynaValues == null || dynaValues.isEmpty())
      {
         return null;
      }

      // In case of error, Struts directly forward to the jsp without executing
      // the action. In this case we still need to execute the PageLifecycle.
      ActionErrors errors = super.validate(mapping, request);
      if ((errors != null) && !errors.isEmpty())
      {
         // Initialize the environment map.
         // The Lifecycle context will be created during the execute of the 
         // LifecycleProcessor.
         HashMap envMap = new HashMap();
         // Set the Lifecycle class
         envMap.put(LifecycleContext.PAGE_LIFECYCLE_KEY,
                    ((DataActionMapping) mapping).getPageLifecycle());
         envMap.put(StrutsPageLifecycleContext.ACTION_REQUEST_KEY, request);
         envMap.put(StrutsPageLifecycleContext.ACTION_MAPPING_KEY, mapping);
         envMap.put(StrutsPageLifecycleContext.ACTION_FORM_KEY, this);

         // Here we go...Execute each of the Lifecycle phase in the order
         // defined in the LifecycleProcessor class.
         try
         {
            LifecycleProcessor.getInstance().execute(envMap);
         }
         catch (Exception ex)
         {
            errors.add(ActionErrors.GLOBAL_ERROR,
                       new ActionError("error.Validate0",
                                       HTMLElement.quote(ex.getMessage())));
         }
      }

     return errors;
   }
   
   
}