package oracle.adf.controller.v2.struts.context;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.controller.v2.struts.actions.DataActionMapping;
import oracle.adf.share.Environment;
import oracle.adf.share.http.ServletEnvironment;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.upload.MultipartRequestWrapper;

/**
 * Lifecycle Context customized to work with Struts PageLifecycle.
 * @since 10.1.3
 */
public class StrutsPageLifecycleContext extends PageLifecycleContext
{
   /**
    * Name of the special forward used to combine a DataAction with a web page.
    */
   public static final String SUCCESS_FORWARD = "success";

   public static final String ACTION_REQUEST_KEY = "actionRequest";
   public static final String ACTION_RESPONSE_KEY = "actionResponse";
   public static final String ACTION_MAPPING_KEY = "actionMapping";
   public static final String ACTION_FORM_KEY = "actionForm";
   public static final String ACTION_ERRORS_KEY = "actionErrors";
   public static final String ACTION_FORWARD_KEY = "actionForward";
   public static final String ACTION_KEY = "action";
   
   // Use to expose Struts request and response.
   private final Environment strutsEnv; 
   
   public StrutsPageLifecycleContext(Map envMap)
   {
      super(envMap);
      
      Environment env;
      try
      {
         env = super.getEnvironment();
      }
      catch (UnsupportedOperationException ex)
      {
         env = null;
      }
      
      // We need to replace the environment class becaude Struts wraps the
      // servletRequest in the multipart case. We need to use the wrapped
      // request. Same idea with the response object.
      Object request = envMap.get(ACTION_REQUEST_KEY);
      if (request == null)
      {
         if (env != null)
         {
            request = env.getRequest();
         }
      }
      
      Object response = envMap.get(ACTION_RESPONSE_KEY);
      if (response == null)
      {
         if (env != null)
         {
            response = env.getResponse();
         }
      }

      strutsEnv = new ServletEnvironment(
                        (ServletContext)((env != null) ? env.getContext() : null),
                        (ServletRequest) request,
                        (ServletResponse) response);
   }

   public Environment getEnvironment()
   {
      // This method can be called before strutsEnv has been initialized. In 
      // that case returning the superclass environment is good enough.
      if (strutsEnv != null)
      {
         return strutsEnv;
      }
      else
      {
         return super.getEnvironment();
      }
   }

   /**
    * Retrieve a map of the parameters for the current request.
    * @return the map
    */
   public Map getParameterMap()
   {
      final HttpServletRequest request =
         (HttpServletRequest) getEnvironment().getRequest();
         
      Map parameters;
      
      // Cannot use request.getParameterMap() because this is not implemented
      // for the multipart case by Struts MultipartRequestWrapper.
      if (request instanceof MultipartRequestWrapper)
      {
         parameters = new HashMap();

         final Enumeration paramNames = request.getParameterNames();
         // Iterate through all parameters and build the parameters map
         while (paramNames.hasMoreElements())
         {
            final String param = (String)paramNames.nextElement();
            parameters.put(param, request.getParameterValues(param));
         }
      }
      else
      {
         parameters = request.getParameterMap();
      }
      
      return parameters;
   }

   /**
    * Retrieve the DataActionMapping from the context.
    * @return the DataActionMapping
    */
   public DataActionMapping getActionMapping()
   {
      return (DataActionMapping) envMap.get(ACTION_MAPPING_KEY);
   }

   /**
    * Retrieve the ActionForm from the context.
    */
   public ActionForm getActionForm()
   {
      return (ActionForm) envMap.get(ACTION_FORM_KEY);
   }

   /**
    * Store the ActionForward in the context.
    * This is the ActionForward that will be returned by the DataAction execute
    * method.
    */
   public void setActionForward(ActionForward forward)
   {
      envMap.put(ACTION_FORWARD_KEY, forward);
   }

   /**
    * Store the ActionForward in the context using the name of forward. The
    * ActionForward will be retrieve using <code>findForward(forwardName)</code>
    * <p>
    * This is the ActionForward that will be returned by the DataAction execute
    * method.
    *
    * Utility method to set the action forward by name.
    */
   public void setActionForward(String forwardName)
   {
      setActionForward(getActionMapping().findForward(forwardName));
   }
   
   /**
    * Retrieve the ActionForward from the context.
    */
   public ActionForward getActionForward()
   {
      return (ActionForward) envMap.get(ACTION_FORWARD_KEY);
   }

   /**
    * Store the ActionErrors in the context
    */
   public void setActionErrors(ActionErrors errors)
   {
      envMap.put(ACTION_ERRORS_KEY, errors);   
   }
   
   /**
    * Retrieve the ActionErrors from the context.
    */
   public ActionErrors getActionErrors()
   {
      ActionErrors errors = (ActionErrors) envMap.get(ACTION_ERRORS_KEY);
      if (errors == null)
      {
         errors = new ActionErrors();
         setActionErrors(errors);
      }
      
      return errors;
   }
   
   /**
    * Retrieve the Action class.
    */
    public Action getAction()
    {
       return (Action) envMap.get(ACTION_KEY);
    }
}
