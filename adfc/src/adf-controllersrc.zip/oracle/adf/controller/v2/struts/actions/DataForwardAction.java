package oracle.adf.controller.v2.struts.actions;

/**
 * <p>Currently <CODE>DataForwardAction</CODE> is used as a marker class
 * so the Struts design time can properly maintain the <CODE>parameter</CODE>
 * property for the companion page. Actions implemented by classes that are
 * an instance of {@link DataAction}
 * but <b>not</b> an instance of <CODE>DataForwardAction</CODE> will not have
 * their <CODE>parameter</CODE> property set.  In the future, there may be
 * new functionality that is <CODE>DataForwardAction</CODE> specific.
 * 
 * @since 10.1.3
 */
public class DataForwardAction extends DataAction
{
}