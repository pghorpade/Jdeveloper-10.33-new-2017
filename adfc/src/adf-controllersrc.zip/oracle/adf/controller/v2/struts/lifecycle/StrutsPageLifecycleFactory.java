package oracle.adf.controller.v2.struts.lifecycle;

import java.util.Map;

import oracle.adf.controller.struts.actions.PageLifecycleFactoryPlugin;
import oracle.adf.controller.v2.lifecycle.PageLifecycleFactory;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.PlugInConfig;

/**
 * Abstract class providing base support to a StrutsPageLifecycle factory.
 * Implement getPageLifecycle method to provide the factory functionality. See
 * {@link DefaultStrutsPageLifecycleFactory} for an example.<br>
 *
 * @since 10.1.3
 */
public abstract class StrutsPageLifecycleFactory extends PageLifecycleFactory
{
   /**
    * 
    */
   public static final String factoryPlugInClassName = 
             "oracle.adf.controller.struts.actions.PageLifecycleFactoryPlugin";

   private static PageLifecycleFactory defaultInstance;

   /**
    * Helper method to instanciate the factory given the ModuleConfig. The
    * ModuleConfig possibly contain the class name of a sustitued factory as
    * the value of a property named "lifecycleFactory". 
    * 
    * @param config the module config
    * @return a StrutsPageLifecycleFactory instance
    */
   public static PageLifecycleFactory getInstance(ModuleConfig config)
   {
      PlugInConfig plugInConfigs[] = config.findPlugInConfigs();
      PageLifecycleFactory instance = null;
      
      for (int i = 0; i < plugInConfigs.length; i++)
      {
         String className = plugInConfigs[i].getClassName();
         if (factoryPlugInClassName.equals(className))
         {
            Map properties = plugInConfigs[i].getProperties();
            String factoryclassName =
               (String) properties.get(
                          PageLifecycleFactoryPlugin.LIFECYCLEFACTORY_PROPERTY);
            instance = 
               (PageLifecycleFactory) properties.get(factoryclassName);
            
            break;
         }
      }
      
      if (instance == null)
      {
         instance = getDefaultInstance();
      }
      
      return instance;
   }
   
   private static PageLifecycleFactory getDefaultInstance()
   {
      if (defaultInstance == null)
      {
         defaultInstance = new DefaultStrutsPageLifecycleFactory();
      }
      
      return defaultInstance;
   }
   
}
