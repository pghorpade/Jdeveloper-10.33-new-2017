package oracle.adf.controller.v2.struts.actions;

import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.controller.v2.lifecycle.PageLifecycleFactory;
import oracle.adf.controller.v2.struts.lifecycle.StrutsPageLifecycleFactory;

import org.apache.struts.action.ActionMapping;

/**
 * An extended action mapping to define and handle additional properties for the
 * DataAction.
 * <ul>
 *   <li><b>v1ActionClass</b>: the class name of the migrated 9.0.5 DataAction</li>
 * </ul>
 *
 * @since 10.1.3
 */

public class DataActionMapping extends ActionMapping
{   
   private PageLifecycle lifecycle;
   private String        v1ActionClass;
   // Cache v1 DataActionMapping here
   private oracle.adf.controller.struts.actions.DataActionMapping v1Mapping;
   
   /**
    * Return the PageLifecycle listener instance to use with this DataAction.
    */
   public PageLifecycle getPageLifecycle()
   {
      return lifecycle;
   }
   
   /**
    * v1ActionClass property
    * Old action custom class for migration purposes.
    * @return v1 version of ActionClass
    */
   public String getV1ActionClass()
   {
      return v1ActionClass;   
   }
   
   /**
    * v1ActionClass property
    */
   public void setV1ActionClass(String value)
   {
      this.v1ActionClass = value;   
   }
   
   /**
    * Retrieve the instance of the v1 mapping
    */
   public oracle.adf.controller.struts.actions.DataActionMapping getV1DataActionMapping()
   {
      return v1Mapping;
   }
   
   /**
    * Store the instance of the v1 mapping
    */
   public void setV1DataActionMapping(oracle.adf.controller.struts.actions.DataActionMapping value)
   {
      v1Mapping = value;
   }
   
   /**
    * Figure out which lifecycle to use before the config get frozen.
    */
   public void freeze()
   {
      PageLifecycleFactory pageLifecycleFactory = 
                   StrutsPageLifecycleFactory.getInstance(getModuleConfig());
      
      lifecycle = pageLifecycleFactory.getPageLifecycle();
      
      super.freeze();
   }
   
}
