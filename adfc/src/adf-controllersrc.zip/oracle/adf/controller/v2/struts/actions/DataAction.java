package oracle.adf.controller.v2.struts.actions;

import java.io.IOException;

import java.util.HashMap;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.lifecycle.LifecycleProcessor;
import oracle.adf.controller.v2.struts.context.StrutsPageLifecycleContext;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCUtil;

import oracle.jbo.common.JBOClass;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.config.ExceptionConfig;
import org.apache.struts.config.ForwardConfig;

/**
 * Bootstrap the execution of the ADF PageLifecycle.
 * 
 * @since 10.1.3
 */
public class DataAction extends Action
{
   /**
    * This is the entry point for the execution of an action from the Struts
    * framework.
    * <p>This method initializes the environment map and bootstraps the
    * lifecycle by calling execute on the
    * {@link oracle.adf.controller.v2.lifecycle.LifecycleProcessor LifecycleProcessor}.</p>
    * <p>Since the customization of the DataAction behavior should be achieved
    * by extending the
    * {@link oracle.adf.controller.v2.lifecycle.PageController PageController} 
    * functionality, this method is declared final.</p>
    * <p>If this action is a migrated v1 action, execute it using the v1 
    * Lifecycle.</p>
    * 
    * @param mapping    the ActionMapping used to select this instance.
    * @param form       the optional ActionForm bean for this request.
    * @param request    the HTTP Request we are processing.
    * @param response   the HTTP Response we are processing.
    * @throws Exception
    */
   public final ActionForward execute(ActionMapping       mapping,
                                      ActionForm          form,
                                      HttpServletRequest  request,
                                      HttpServletResponse response)
      throws Exception
   {
      DataActionMapping daMapping = (DataActionMapping) mapping;

      // bug4491153 - keep track of the action path in a request attribute.
      // The request attribute is used when enabling actionRef execution in
      // page definition.
      final String path = daMapping.getPath();
      
      // Store an anonymous inner class in the request that will be call when
      // following EL is evaluated: ${requestScope['/dataAction1'].execute}
      request.setAttribute(path, new Object()
         {
            private Boolean mExecute = Boolean.TRUE;
            
            public Boolean getExecute()
            {
               if ( mExecute == Boolean.TRUE )
               {
                  mExecute = Boolean.FALSE;
                  return Boolean.TRUE;
               }
               return mExecute;
            }
            
            public void setExecute(Boolean execute)
            {
               mExecute = execute;
            }
         });
      
      try
      {
         // Check if this is migrated v1 action that has a custom action class,
         // in which case it use the old Lifecycle implementation.
         if (daMapping.getV1ActionClass() != null)
         {
            Action action = actionCreate(request, response, daMapping);
            if (action == null)
            {
               return null;
            }
   
            ActionMapping oldMapping = mappingCreate(request, response, daMapping);
   
            // Execute the v1 action.
            return action.execute(oldMapping, form, request, response);
         }
         else
         {
            // Initialize the environment map.
            // The Lifecycle context will be created during the execute of the 
            // LifecycleProcessor.
            HashMap envMap = new HashMap();
            // Set the Lifecycle class
            envMap.put(LifecycleContext.PAGE_LIFECYCLE_KEY,
                       ((DataActionMapping) mapping).getPageLifecycle());
            envMap.put(StrutsPageLifecycleContext.ACTION_REQUEST_KEY, request);
            envMap.put(StrutsPageLifecycleContext.ACTION_RESPONSE_KEY, response);
            envMap.put(StrutsPageLifecycleContext.ACTION_MAPPING_KEY, mapping);
            envMap.put(StrutsPageLifecycleContext.ACTION_FORM_KEY, form);
            envMap.put(StrutsPageLifecycleContext.ACTION_KEY, this);
            
            // Here we go...Execute each of the Lifecycle phase in the order
            // defined in the LifecycleProcessor class.
            LifecycleProcessor.getInstance().execute(envMap);
            
            return (ActionForward) envMap.get(StrutsPageLifecycleContext.ACTION_FORWARD_KEY);
         }
      }      
      finally
      {
         // after refresh is called on actionRef, remove the attribute from the
         // request
         request.removeAttribute(path);
      }
      
   }

   /**
    * This is another entry point for the execution of an action from the
    * Struts framework using ServletRequest and ServletResponse.
    * <p>This method simply delegate to the other {@link #execute(ActionMapping,
    * ActionForm, HttpServletRequest, HttpServletResponse) execute} method.
    * <p>Since the customization of the DataAction behavior should be achieved
    * by extending the lifecycle functionality, this method is declared final.
    * 
    * @param mapping    the ActionMapping used to select this instance.
    * @param form       the optional ActionForm bean for this request.
    * @param request    the Servlet Request we are processing.
    * @param response   the Servlet Response we are processing.
    * @throws Exception
    * @see              #execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) execute
    */
   public final ActionForward execute(ActionMapping   mapping,
                                      ActionForm      form,
                                      ServletRequest  request,
                                      ServletResponse response)
      throws Exception
   {
      try
      {
         return (execute(mapping, form,
                         (HttpServletRequest) request,
                         (HttpServletResponse) response));
      }
      catch (ClassCastException e)
      {
         return (null);
      }
   }
   
   /**
    * Save all the error message from the lifecycle context to the request
    * attribute. Delegate to the base class saveError method using parameters
    * from the StrutsPageLifecycleContext.
    */
   public void saveErrors(StrutsPageLifecycleContext context)
   {
      saveErrors((HttpServletRequest) context.getEnvironment().getRequest(),
                 context.getActionErrors());
   }
   
   /**
    * Call the action saveMessages protected method.
    */
   public void saveMessages(HttpServletRequest request, ActionMessages messages)
   {
      saveMessages(request, messages);
   }
   
   /**
    * <p>Creates a v1 {@link oracle.adf.controller.struts.actions.DataAction DataAction}.</p>
    * Create a DataAction of the type specified in the <code>V1ActionClass</code>
    * property.
    * @return an Action instance
    */
   protected Action actionCreate(HttpServletRequest  request,
                                 HttpServletResponse response,
                                 DataActionMapping   mapping)
      throws IOException                               
   {
      String className = mapping.getV1ActionClass();
      
      //TODO Might want to cache the instance.
      Action instance = null;

      try
      {
         Class cls = JBOClass.forName(className);
         Object obj = cls.newInstance();
         
         instance = (Action) obj;
      } catch (Exception e)
      {
         return null;
      }
          
      instance.setServlet(this.servlet);

      return instance;
   }
   
   /**
    *  Create a v1 DataActionMapping and transfer the content of the current
    *  mapping to it.
    */
   protected ActionMapping mappingCreate(HttpServletRequest  request,
                                         HttpServletResponse response,
                                         DataActionMapping   mapping)
   {
      oracle.adf.controller.struts.actions.DataActionMapping v1Mapping =
         mapping.getV1DataActionMapping();
      
      // Create the mapping only once and store it on the v2mapping.
      if (v1Mapping != null)
      {
         return v1Mapping;
      }
      
      v1Mapping = new oracle.adf.controller.struts.actions.DataActionMapping();
      
      // Transfer the content of the current mapping.
      v1Mapping.setModuleConfig(mapping.getModuleConfig());
      v1Mapping.setAttribute(mapping.getAttribute());
      v1Mapping.setForward(mapping.getForward());
      v1Mapping.setInclude(mapping.getInclude());
      v1Mapping.setInput(mapping.getInput());
      v1Mapping.setMultipartClass(mapping.getMultipartClass());
      v1Mapping.setName(mapping.getName());
      v1Mapping.setParameter(mapping.getParameter());
      v1Mapping.setPath(mapping.getPath());
      v1Mapping.setPrefix(mapping.getPrefix());
      v1Mapping.setRoles(mapping.getRoles());
      v1Mapping.setScope(mapping.getScope());
      v1Mapping.setSuffix(mapping.getSuffix());
      v1Mapping.setType(mapping.getV1ActionClass());
      v1Mapping.setUnknown(mapping.getUnknown());
      v1Mapping.setValidate(mapping.getValidate());
      
      ForwardConfig[] forwards = mapping.findForwardConfigs();
      for (int i=0; i < forwards.length; i++)
      {
         v1Mapping.addForwardConfig(forwards[i]);
      }

      ExceptionConfig[] exceptions = mapping.findExceptionConfigs();
      for (int i=0; i < exceptions.length; i++)
      {
         v1Mapping.addExceptionConfig(exceptions[i]);
      }
     
      /*
       * In this section we retrieve the pageDefinition and store it in the
       * old modelRef property.
       */
      final BindingContext bctx = DCUtil.getBindingContext(request);
      if (bctx != null)
      {
         // First retrieve the current path
         String path = request.getPathInfo();
         if (path == null || path.length() == 0)
         {
            path = request.getServletPath();
         }  
         
         final String modelRef = bctx.findBindingContainerIdByPath(path);
         v1Mapping.setModelReference(modelRef);
      }

      // Required step once the mapping is configured.
      v1Mapping.freeze();
      
      // Cache the mapping
      mapping.setV1DataActionMapping(v1Mapping);
      
      return v1Mapping;
   }

}
