package oracle.adf.controller.v2.struts.lifecycle;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.controller.struts.forms.ADFStrutsForm;
import oracle.adf.controller.struts.util.ErrorReporting;
import oracle.adf.controller.struts.util.FormFileInputHandler;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.controller.v2.lifecycle.PageLifecycleImpl;
import oracle.adf.controller.v2.struts.actions.DataAction;
import oracle.adf.controller.v2.struts.actions.DataActionMapping;
import oracle.adf.controller.v2.struts.context.StrutsPageLifecycleContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.RegionBinding;

import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jbo.uicli.binding.JUCtrlValueDef;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.upload.FormFile;
import org.apache.struts.action.Action;
import org.apache.struts.Globals;

/**
 * Base class for any Lifecycle running with the Struts controller.
 * This is an adapted {@link oracle.adf.controller.v2.lifecycle.PageLifecycleImpl
 * PageLifecycleImpl} to work with specific Struts feature like error reporting, 
 * named forward and form bean.
 * 
 * @since 10.1.3
 */
 public class StrutsPageLifecycle extends PageLifecycleImpl
{
   /**
    * {@inheritDoc}
    * The StrutsPageLifecycle uses the custom LifecycleContext called
    * {@link oracle.adf.controller.v2.struts.context.StrutsPageLifecycleContext StrutsPageLifecycleContext}
    * @return the Class object
    */
   public Class getLifecycleContextClass()
   {
      return StrutsPageLifecycleContext.class;
   }
   
   /**
    * A custom input handler used by bindings dealing with FormFile type
    */
   public static final String formFileInputHandlerName = "FormFileInputHandler";
   
   /**
    * Register formFileInputHandlerName custom input handler to the binding
    * context.
    */
   protected void registerCustomInputHandler(PageLifecycleContext context)
   {
      final BindingContext bctx = context.getBindingContext();
      if (bctx == null)
      {
         return;
      }
      
      JUCtrlInputValueHandler inputHandler = (JUCtrlInputValueHandler)
         bctx.getBindingInputHandler(formFileInputHandlerName);
      if (inputHandler == null)
      {
         inputHandler = new FormFileInputHandler();

         // Initialize default InputHandler here
         HashMap inputHandlerMap = new HashMap(2);
         inputHandlerMap.put(formFileInputHandlerName, inputHandler);
         bctx.setBindingInputHandlers(inputHandlerMap);
      }
   }
   
   public void prepareModel(LifecycleContext context)
   {
      try
      {
         super.prepareModel(context);
      }
      catch (RuntimeException ex)
      {
         // If the model preparation fails (mostly because of a failing token
         // validation), cleans the pending values.
         final ActionForm form = 
            ((StrutsPageLifecycleContext) context).getActionForm();

         if (form != null && form instanceof ADFStrutsForm)
         {
            ((ADFStrutsForm) form).resetPendingValues();
         }
         throw ex;
      }
   }
   
   public boolean shouldAllowModelUpdate(PageLifecycleContext plcContext)
   {
      boolean bAllow = super.shouldAllowModelUpdate(plcContext);
      
      // If we are not going to update the model, make sure to clean up the
      // pending values so that they won't be rendered in the page.
      if (!bAllow)
      {
         final ActionForm form =
            ((StrutsPageLifecycleContext) plcContext).getActionForm();
         if (form != null && form instanceof ADFStrutsForm)
         {
            ((ADFStrutsForm) form).resetPendingValues();
         }
      }

      return bAllow;      
   }
   
   //  Inherit javadoc from Phases abstract class
   public void processUpdateModel(LifecycleContext context)
   {
      super.processUpdateModel(context);

      // Since the model has been updated, clear pending values so that 
      // next time the values are pulled from the model.
      // Only deal with ADFStrutsForm. Don't know how to support others.
      final ActionForm form =
         ((StrutsPageLifecycleContext) context).getActionForm();
      if (form != null && form instanceof ADFStrutsForm)
      {
         ((ADFStrutsForm) form).resetPendingValues();
      }
   }
   
   
   //  Inherit javadoc from Phases abstract class
   public void prepareRender(LifecycleContext lfContext)
   {
      final StrutsPageLifecycleContext context =
         (StrutsPageLifecycleContext) lfContext;
      
      try
      {
         // Only call refreshControl if no navigation occurs.
         if (context.getActionForward() == null)
         {
            // BindingContainer should not be refresh in case of error because
            // otherwise we loose the exception state.
            if (!context.getPageController().hasErrors(context))
            {
               final RegionBinding bindings = context.getBindingContainer();
               
               if (bindings != null)
               {
                  bindings.refresh(RegionBinding.RENDER_MODEL);
               }
            }
         }
         
         context.getPageController().findForward(context);
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }

      context.getPageController().reportErrors(context);
   }
   
   /**
    * {@inheritDoc}
    * Retrieves the errors and convert them to Struts errors.
    */
   public void reportErrors(PageLifecycleContext plcContext)
   {
      final StrutsPageLifecycleContext context =
         (StrutsPageLifecycleContext) plcContext;
      ActionErrors errors = null;
      
      // transfer any errors to the ActionError list
      try
      {
         if (context.getPageController().hasErrors(plcContext))
         {
            errors = context.getActionErrors();
            ErrorReporting.transferErrorsToStrutsCollection(
               (DCBindingContainer) context.getBindingContainer(),
               errors);
         } 
      }
      catch (Throwable t)
      {
         errors = context.getActionErrors();
         ErrorReporting.addError(errors, 0, 0, t);
      }
         
      if (errors != null && !errors.isEmpty())
      {
         // Store the action error using the standard action mechanism.
         Action action = context.getAction();
         if (action != null && action instanceof DataAction)
         {
            ((DataAction) action).saveErrors(context);
         }
         else
         {
            final HttpServletRequest request =
               (HttpServletRequest) context.getEnvironment().getRequest();
            
            // Save the error messages we need
            request.setAttribute(Globals.ERROR_KEY, errors);
         }
      }
   }
   
   /**
    * {@inheritDoc}
    * In addition to the super class behavior, the event name is used as a
    * automatic forward mechanism. If it exist an action forward of the same
    * name of the event, this action forward is set to the context to be the 
    * return value of the DataAction execute method.
    *
    * @see PageLifecycleContext#getEventActionBinding getEventActionBinding
    */
   protected boolean handleEvent(PageLifecycleContext plcContext, String event)
      throws Exception
   {
      final StrutsPageLifecycleContext context = 
         (StrutsPageLifecycleContext) plcContext;
      boolean isHandled = true; 

      isHandled = super.handleEvent(plcContext, event);

      // If the user has not already set the forward value and if there are
      // no error, look for a forward name matching the name of the event
      if (context.getActionForward() == null &&
          ! context.getPageController().hasErrors(context))
      {
         final DataActionMapping mapping = context.getActionMapping();
   
         // Try to dispatch to the forward matching the event name.
         ActionForward forward = mapping.findForward(event);  
         
         if (forward != null)
         {
            context.setActionForward(forward);
         }
      }

      return isHandled;
   }
   
   /**
    * Determine the ActionForward that will be returned by the Struts action
    * executing the Lifecycle.
    * This method only set the ActionForward object in the actionForward 
    * property of the StrutsLifecycleContext. The DataAction executing the 
    * Lifecycle will return this value from the execute method.
    * <p>
    * If the actionForward property has already being set during a previous step
    * of the Lifecycle, it respect this value and return.
    * If there was errors during the Lifecycle, it uses the inputForward 
    * property of the action.
    * The normal behavior for a DataForwardAction is to use the parameter
    * property. For a DataAction it is to use the forward called "success".
    * <p>
    * Clients should override this method to select a forward based on the
    * result of a custom method invocation.
    * Since this method is called when the Lifecycle successfully executed or 
    * when an error was encountered, the user has to pay extra attention to
    * always check for the error case using the hasError property. 
    * <pre>
    *    // Set my custom Action only when no error occured
    *    if ( ! hasErrors() )
    *    {
    *       context.setActionForward(myActionForward);
    *    }
    *    else
    *    {
    *       super.findForward(context);
    *    }
    * </pre>
    *
    */
   public void findForward(PageLifecycleContext plcContext)
      throws Exception
   {
      final StrutsPageLifecycleContext context =
         (StrutsPageLifecycleContext) plcContext;
      final DataActionMapping mapping = context.getActionMapping();
      ActionForward forward = null;
      
      // Respect user setting
      if (context.getActionForward() != null)
      {
         return;
      }

      // In case of error directly go back to the page
      if (context.getPageController().hasErrors(context))
      {
         forward = mapping.getInputForward();
      }
      
      if (forward == null || forward.getPath() == null)
      {
         // Single dataForward case
         String path = mapping.getParameter();
         if (path != null)
         {
            // Let the controller handle the request
            forward = new ActionForward(path);
            forward.setContextRelative(true);
         }
         else
         {
            forward = mapping.findForward(StrutsPageLifecycleContext.SUCCESS_FORWARD);
         }
      }
      
      context.setActionForward(forward);
   }
   
   /**
    * A Struts specific implementation that only deals with values coming from
    * the ADFStrutsForm.
    */
   protected void buildInputValues(PageLifecycleContext plcContext)
   {
      // Only deal with ADFStrutsForm. Don't know how to support others.
      final ActionForm form =
         ((StrutsPageLifecycleContext) plcContext).getActionForm();
      final RegionBinding regionBinding = plcContext.getBindingContainer();

      if (regionBinding != null && form != null && form instanceof ADFStrutsForm)
      {
         Map formPendingValues = ((ADFStrutsForm) form).getPendingValues();
         Map pendingValues = plcContext.getUpdatedValues();
         if (pendingValues == null)
         {
            pendingValues = new HashMap();
            plcContext.setUpdatedValues(pendingValues);
         }
        
         final HttpServletRequest request =
                  (HttpServletRequest) plcContext.getEnvironment().getRequest();

         final String contentType = request.getContentType();
         boolean isMultipartPostRequest = ((contentType != null) && 
                    contentType.startsWith("multipart/form-data") &&
                    request.getMethod().equalsIgnoreCase("POST"));
    
         // Collect the pending values from the formbean and store them in the 
         // context
         for (Iterator iter = formPendingValues.keySet().iterator();
              iter.hasNext();)
         {
            String attribute = (String) iter.next();
            Object value = formPendingValues.get(attribute);
            JUCtrlValueBinding binding = (JUCtrlValueBinding) regionBinding.getControlBinding(attribute);
            if (binding != null)
            {
               // For backward compatibility with 9.0.5.x we need to handle
               // the case where custom handler are not set at design time
               // through a property of the binding.
               // This only need to be done for formFileInputHandlerName which 
               // are only used in a multiparts post request.
               if (isMultipartPostRequest)
               {
                  JUCtrlValueDef def = (JUCtrlValueDef) binding.getDef();
                  if (!def.hasCustomInputHandler())
                  {
                     // Set the inputHandler dynamically based on the type of
                     // the value.
                     if (value instanceof FormFile)
                     {
                        final BindingContext bctx = plcContext.getBindingContext();  
                  
                        binding.setInputValueHandler((JUCtrlInputValueHandler)
                          bctx.getBindingInputHandler(formFileInputHandlerName));
                     }
                  }
               }
            
               if (binding.processNewInputValue(value))
               {
                  DCIteratorBinding dcIter = binding.getIteratorBinding();
                  if (dcIter != null)
                  {
                     dcIter.internalReserveCurrentRow();
                  }
                  pendingValues.put(binding, value);
               }
            }
         }
      }
   }
   
}
