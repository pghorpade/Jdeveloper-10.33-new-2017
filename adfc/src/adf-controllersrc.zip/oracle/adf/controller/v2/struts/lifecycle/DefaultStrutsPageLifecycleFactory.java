package oracle.adf.controller.v2.struts.lifecycle;

import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.controller.v2.lifecycle.PageLifecycleFactory;

/**
 * Default factory for StrutsPageLifecycle
 * This implementation is used to create {@link StrutsPageLifecycle} instance.
 * To use a different factory use the 
 * {@link oracle.adf.controller.struts.actions.PageLifecycleFactoryPlugin PageLifecycleFactoryPlugin}.
 * 
 * @since 10.1.3
 */
public class DefaultStrutsPageLifecycleFactory extends PageLifecycleFactory
{
   /** Singleton PageLifecycle instance */
   private static StrutsPageLifecycle DEFAULT_PAGELIFECYCLE;
   
   // Static block to instanciate the singleton in a threadsafe way
   static
   {
      DEFAULT_PAGELIFECYCLE = new StrutsPageLifecycle();
   }
   
   
   public PageLifecycle getPageLifecycle()
   {
      return DEFAULT_PAGELIFECYCLE;
   }
}
