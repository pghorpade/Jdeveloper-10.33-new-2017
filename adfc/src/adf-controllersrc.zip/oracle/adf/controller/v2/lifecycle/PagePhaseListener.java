package oracle.adf.controller.v2.lifecycle;

import java.util.EventListener;

/**
 * <p>An interface implemented by objects that wish to be notified before and 
 * after the processing of each of the ADF PageLifecycle phase.</p>
 * 
 * @since 10.1.3
 */
public interface PagePhaseListener extends EventListener
{
    /**
     * <p>Notify the listener after the execution of a specific phase of the 
     * ADF PageLifecycle.</p>
     */
    public void afterPhase(PagePhaseEvent event);


    /**
     * <p>Notify the listener before the execution of a specific phase of the 
     * ADF PageLifecycle.</p>
     */
    public void beforePhase(PagePhaseEvent event);
   
}