package oracle.adf.controller.v2.lifecycle;

import java.lang.reflect.Method;

import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.controller.v2.lifecycle.PageLifecycle;
import oracle.adf.model.OperationBinding;


/**
 * Implement the PageLifecycle functionality by delegating to the current
 * PageLifecycle implementation stored in the PageLifecycle property of the
 * {@link oracle.adf.controller.v2.context.LifecycleContext LifecycleContext}.
 * @since 10.1.3
 */
public class PageController extends PageLifecycle
{
/* -- Implements abstract Phases here
 * -----------------------------------------------------------------------------
 */
   public void initContext(LifecycleContext context)
   {
      context.getPageLifecycle().initContext(context);
   }

   public void prepareModel(LifecycleContext context)
   {
      context.getPageLifecycle().prepareModel(context);
   }
   
   public void applyInputValues(LifecycleContext context)
   {
      context.getPageLifecycle().applyInputValues(context);
   }

   public void validateInputValues(LifecycleContext context)
   {
      context.getPageLifecycle().validateInputValues(context);
   }

   public void processUpdateModel(LifecycleContext context)
   {
      context.getPageLifecycle().processUpdateModel(context);
   }

   public void validateModelUpdates(LifecycleContext context)
   {
      context.getPageLifecycle().validateModelUpdates(context);
   }
   
   public void processComponentEvents(LifecycleContext context)
   {
      context.getPageLifecycle().processComponentEvents(context);
   }   
   
   public void metadataCommit(LifecycleContext context)
   {
      context.getPageLifecycle().metadataCommit(context);
   }

   public void prepareRender(LifecycleContext context)
   {
      context.getPageLifecycle().prepareRender(context);
   }
   
/* -- Implements abstract PageLifecycle here
 * -----------------------------------------------------------------------------
 */ 
   public boolean shouldAllowModelUpdate(PageLifecycleContext context)
   {
      return context.getPageLifecycle().shouldAllowModelUpdate(context);
   }
   
   public boolean hasErrors(PageLifecycleContext context)
   {
      return context.getPageLifecycle().hasErrors(context);
   }
   
   public void handleError(PageLifecycleContext context, Exception ex)
   {
      context.getPageLifecycle().handleError(context, ex);
   }

   public void reportErrors(PageLifecycleContext context)
   {
      context.getPageLifecycle().reportErrors(context);
   }
   
   public Method getEventMethod(PageLifecycleContext lcContext,
                                String eventName)
   {
      return PageLifecycle.getEventMethodFromCache(events, clazz, eventParam,
                                                   eventName);
   }

   public boolean invokeEventMethod(PageLifecycleContext context,
                                    String eventName)
      throws Exception                                    
   {
      boolean isOk;
                                                      
      // Try to find the method locally first
      Method event = getEventMethod(context, eventName);

      // Found it, so invoke it.
      if (event != null)
      {
         Object args[] = { context };
         event.invoke(this, args);
         isOk = true;
      }
      // If not, try the application level Lifecycle
      else
      {
         isOk = context.getPageLifecycle().invokeEventMethod(context, eventName);
      }

      return isOk;
   }
   
   public boolean invokeActionBinding(PageLifecycleContext context,
                                      String event)
   {
      return context.getPageLifecycle().invokeActionBinding(
                                          context,
                                          event);
   }
   
   public void findForward(PageLifecycleContext context)
      throws Exception
   {
      context.getPageLifecycle().findForward(context);
   }
   
   public void executeEvent(PageLifecycleContext context, String event,
                            OperationBinding actionBinding)
   {
      context.getPageLifecycle().executeEvent(context, event, actionBinding);
   }
   
   public void initializeMethodParameters(PageLifecycleContext context,
                                          OperationBinding actionBinding)
   {
      context.getPageLifecycle().initializeMethodParameters(
                                    context,
                                    actionBinding);
   }
   
   
}
