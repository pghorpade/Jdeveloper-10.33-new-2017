package oracle.adf.controller.v2.lifecycle;

import java.util.EventObject;

import oracle.adf.controller.v2.context.LifecycleContext;

/**
 * <p>PagePhaseEvent happend before and after each of the phase of the ADF 
 * PageLifecycle being listened.</p>
 * 
 * @since 10.1.3
 */
public class PagePhaseEvent extends EventObject
{
   private LifecycleContext  context;
   private int               phaseId;
   
   /**
    * Construct a new event object.The source of the event is the
    * {@link Lifecycle} from the specified parameter.
    */
   public PagePhaseEvent(LifecycleContext context, int phaseId,
                         Lifecycle lifecycle)
   {
      super(lifecycle);

      if ( context == null || lifecycle == null)
      {
         throw new NullPointerException();
      }
      
      this.phaseId = phaseId;
      this.context = context;
   }
   
   /**
    * Return the {@link LifecycleContext} to the listener of the phase event.
    */
   public LifecycleContext getLifecycleContext()
   {
      return context;
   }

   /**
    * Return the phase id of the phase.
    * Can only be one of the following:
    * <ul>
    *   <li>{@link Lifecycle#INIT_CONTEXT_ID}</li>
    *   <li>{@link Lifecycle#PREPARE_MODEL_ID}</li>
    *   <li>{@link Lifecycle#APPLY_INPUT_VALUES_ID}</li>
    *   <li>{@link Lifecycle#VALIDATE_INPUT_VALUES_ID}</li>
    *   <li>{@link Lifecycle#PROCESS_UPDATE_MODEL_ID}</li>
    *   <li>{@link Lifecycle#VALIDATE_MODEL_UPDATES_ID}</li>
    *   <li>{@link Lifecycle#PROCESS_COMPONENT_EVENTS_ID}</li>
    *   <li>{@link Lifecycle#PREPARE_RENDER_ID}</li>
    * </ul>
    */
   public int getPhaseId()
   {
      return phaseId;
   }

   
}