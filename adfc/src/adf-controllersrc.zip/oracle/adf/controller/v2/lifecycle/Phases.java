package oracle.adf.controller.v2.lifecycle;

import oracle.adf.controller.v2.context.LifecycleContext;

/**
 * Define each of the phase of a standard ADF PageLifecycle.
 *
 * @since 10.1.3
 */
public abstract class Phases
{
   /**
    * During this phase the listener is able to initialize the 
    * {@link oracle.adf.controller.v2.context.LifecycleContext LifecycleContext}
    * with additional information that will be persisted during the Lifecycle.
    */
   public abstract void initContext(LifecycleContext context);
      
   /**
    * Give the opportunity for the data model to prepare and initialize.
    */
   public abstract void prepareModel(LifecycleContext context);
   
   /**
    * Builds the list of events with their possible associated action binding
    * from the request parameters.
    */
   public abstract void applyInputValues(LifecycleContext context);

   /**
    * Validate input values.
    */
   public abstract void validateInputValues(LifecycleContext context);

   /**
    * Update the data model with new and validated input values.
    */
   public abstract void processUpdateModel(LifecycleContext context);
      
   /**
    * Forces model-level validation to occur.
    */
   public abstract void validateModelUpdates(LifecycleContext context);
   
   /**
    * Process each event accumulated during the previous phases.
    */
   public abstract void processComponentEvents(LifecycleContext context);
 
   /**
    * Used to commit Runtime changes to the metadata. This phase is
    * always called before prepareRender even in case of navigation.
    */
   public abstract void metadataCommit(LifecycleContext context);
   
   /**
    * Last phase before rendering a page. This can be used to notify
    * a binding that rendering is about to happen and allow them to optimize data
    * preparation or processing before the rendering begins.
    * <p>During this phase the model is refreshed.</p>
    */
   public abstract void prepareRender(LifecycleContext context);
}
