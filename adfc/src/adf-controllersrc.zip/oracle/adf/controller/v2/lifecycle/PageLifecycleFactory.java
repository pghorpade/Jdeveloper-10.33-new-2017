package oracle.adf.controller.v2.lifecycle;

/**
 * A factory to retrieve PageLifecycle instances.
 *
 * @since 10.1.3
 */
public abstract class PageLifecycleFactory 
{
   protected PageLifecycleFactory()
   {
   }
   
   /**
    * Return a PageLifecycle instance.
    */
   public abstract PageLifecycle getPageLifecycle();
}