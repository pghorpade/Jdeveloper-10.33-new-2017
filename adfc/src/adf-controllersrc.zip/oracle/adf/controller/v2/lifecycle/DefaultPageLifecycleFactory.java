package oracle.adf.controller.v2.lifecycle;

/**
 * Stock implementation of the PageLifecycleFactory.
 * 
 * @since 10.1.3
 */
public class DefaultPageLifecycleFactory extends PageLifecycleFactory
{
   /** Singleton PageLifecycle instance */
   private static PageLifecycle DEFAULT_PAGELIFECYCLE;
   
   // Static block to instanciate the singleton in a threadsafe way
   static
   {
      DEFAULT_PAGELIFECYCLE = new PageLifecycleImpl();
   }
   
   
   // Inherit javadoc from PageLifecycleFactory
   public PageLifecycle getPageLifecycle()
   {
      return DEFAULT_PAGELIFECYCLE;
   }
}