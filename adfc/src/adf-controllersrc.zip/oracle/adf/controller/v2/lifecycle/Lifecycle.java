package oracle.adf.controller.v2.lifecycle;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.JboException;

/**
 * <p>Processing of the Lifecycle.</p> It handle the registration of 
 * PagePhaseListener and make sure that during execution the listeners are
 * notified of the beforePhase and afterPhase event.
 * This class also delegate the implementation of each of the phase to the
 * PageController.
 * 
 * @since 10.1.3
 */
public abstract class Lifecycle
{
   /**
    * The set of PagePhaseListener registered with this Lifecycle instance
    */
   protected List listeners = new ArrayList();
   
   /**
    * <p>Add a new {@link PagePhaseListener PagePhaseListener} to the set of
    * registered listeners.</p>
    * <p>The {@link PagePhaseListener PagePhaseListener} will be notified of
    * each phase with an event before and an event after the execution of the
    * phase.</p>
    */
   public void addPagePhaseListener(PagePhaseListener listener)
   {
      if (listener == null)
      {
         throw new JboException("Null PagePhaseListener");
      }

      synchronized (listeners)
      {
         listeners.add(listener);
      }
   }
   
   /**
    * Deregister an existing {@link PagePhaseListener} instance.
    */
   public void removePagePhaseListener(PagePhaseListener listener)
   {
      if (listener == null)
      {
         throw new JboException("Null PagePhaseListener");
      }
      synchronized (listeners)
      {
         listeners.remove(listener);
      }
   }

   /**
    * <p>Return the array of registred {@link PagePhaseListener} for this
    * instance of the {@link Lifecycle}.</p>
    */
   public PagePhaseListener[] getPagePhaseListeners()
   {
      synchronized (listeners)
      {
         PagePhaseListener results[] = new PagePhaseListener[listeners.size()];
         return ((PagePhaseListener[]) listeners.toArray(results));
      }
    }
    
   /**
    * <p>Execute all the phases of the Lifecycle and define the order in which 
    * each phase is going to be executed.</p>
    * <p>The current environment is passed anonymously, it contain data the
    * Lifecycle will use to build the 
    * {@link oracle.adf.controller.v2.context.LifecycleContext LifecycleContext}.</p>
    */
   public abstract void execute(Map envMap) throws Exception;
   
   /**
    * Helper method to execute a phase. For each listener registered, a
    * beforePhase and afterPhase event is propagated.
    * @param phase the phase to execute
    * @param context the LifecycleContext that will use to call the phase.
    */
   protected void executePhase(Phase phase, LifecycleContext context)
   {
      PagePhaseListener phaseListener = context.getPagePhaseListener();
      
      if (phaseListener != null)
      {
         phaseListener.beforePhase(new PagePhaseEvent(context, phase.id, this));
      }

      // Propagate before PagePhase event for each listener
      synchronized (listeners)
      {
         if (listeners.size() > 0)
         {
            PagePhaseEvent event = new PagePhaseEvent(context, phase.id, this);
            for (int i = 0; i < listeners.size(); i++)
            {
               PagePhaseListener listener = 
                  (PagePhaseListener) listeners.get(i);
               listener.beforePhase(event);
            }
         }
      }
    
      logger.log(ADFLogger.TRACE, "[ADFc] Execute:" + phase.getName());
      phase.execute(context);
      
      // Propagate after PagePhase event for each listener
      synchronized (listeners)
      {
         if (listeners.size() > 0)
         {
            PagePhaseEvent event = new PagePhaseEvent(context, phase.id, this);
            for (int i = 0; i < listeners.size(); i++)
            {
               PagePhaseListener listener = 
                  (PagePhaseListener) listeners.get(i);
               listener.afterPhase(event);
            }
         }
      }
      
      if (phaseListener != null)
      {
         phaseListener.afterPhase(new PagePhaseEvent(context, phase.id, this));
      }
   }
   
   /**
    * <p>Typesafe enumeration of all existing phases of the Lifecycle.</p>
    * See {@link Phases} for a complete description of each of the
    * phase.
    */
   protected static abstract class Phase 
   {
      private String    name;
      private final int id = phaseCount++;
      
      /**
       * <p>Private constructor to disable the creation of new instances.</p>
       */
      private Phase(String name)
      {
         this.name = name;
      }
      
      public abstract void execute(LifecycleContext context);
      
      public String getName()
      {
         return name;
      }
      
      public int id()
      {
         return id;
      }
      
      public String toString()
      {
         if (name == null)
         {
            return "<null> (" + id + ")";
         }
         
         return "" + name + " (" + id + ")";
      }
   
   }   

   private static final ADFLogger logger =
      ADFLogger.createADFLogger(Lifecycle.class.getName());

   /**
    * <p>Static counter returning the id id to be assigned to the next instance
    * that is created.</p>
    */
   private static int phaseCount = 0;

   /**
    * The {@link Phases#initContext(LifecycleContext) initContext} phase.
    */
   protected static final Phase INIT_CONTEXT = new Phase("initContext")
      {
         public void execute(LifecycleContext context)
         {
            context.getPageController().initContext(context);
         }
      };

   /**
    * The {@link Phases#prepareModel(LifecycleContext) prepareModel} phase.
    */
   protected static final Phase PREPARE_MODEL = new Phase("prepareModel")
      {
         public void execute(LifecycleContext context)
         {
            if (context.getBindingContainer() != null)
            {
               context.getPageController().prepareModel(context);
            }
         }
      };
      
   /**
    * The {@link Phases#applyInputValues(LifecycleContext) applyInputValues} phase.
    */
   protected static final Phase APPLY_INPUT_VALUES = new Phase("applyInputValues")
      {
         public void execute(LifecycleContext context)
         {
            context.getPageController().applyInputValues(context);
         }
      };

   /**
    * The {@link Phases#validateInputValues(LifecycleContext) validateInputValues} phase.
    */
   protected static final Phase VALIDATE_INPUT_VALUES = new Phase("validateInputValues")
      {
         public void execute(LifecycleContext context)
         {
            if (context.getBindingContainer() != null)
            {
               context.getPageController().validateInputValues(context);
            }
         }
      };

   /**
    * The {@link Phases#processUpdateModel(LifecycleContext) processUpdateModel} phase.
    */
   protected static final Phase PROCESS_UPDATE_MODEL = new Phase("processUpdateModel")
      {
         public void execute(LifecycleContext context)
         {
            if (context.getBindingContainer() != null)
            {
               context.getPageController().processUpdateModel(context);
            }
         }
      };
      
   /**
    * The {@link Phases#validateModelUpdates(LifecycleContext) validateModelUpdates} phase.
    */
   protected static final Phase VALIDATE_MODEL_UPDATES = new Phase("validateModelUpdates")
      {
         public void execute(LifecycleContext context)
         {
            if (context.getBindingContainer() != null)
            {
               context.getPageController().validateModelUpdates(context);
            }
         }
      };

   /**
    * The {@link Phases#processComponentEvents(LifecycleContext) processComponentEvents} phase.
    */
   protected static final Phase PROCESS_COMPONENT_EVENTS = new Phase("processComponentEvents")
      {
         public void execute(LifecycleContext context)
         {
            context.getPageController().processComponentEvents(context);
         }
      };

   /**
    * The {@link Phases#metadataCommit(LifecycleContext) metadataCommit} phase.
    */
   protected static final Phase METADATA_COMMIT = new Phase("metadataCommit")
      {
         public void execute(LifecycleContext context)
         {
            context.getPageController().metadataCommit(context);
         }
      };

   /**
    * The {@link Phases#prepareRender(LifecycleContext) prepareRender} phase.
    */
   protected static final Phase PREPARE_RENDER = new Phase("prepareRender")
      {
         public void execute(LifecycleContext context)
         {
            context.getPageController().prepareRender(context);
         }
      };
      
   /** id of the {@link #INIT_CONTEXT} phase. */
   public static final int INIT_CONTEXT_ID = INIT_CONTEXT.id();
   /** id of the {@link #PREPARE_MODEL} phase. */
   public static final int PREPARE_MODEL_ID = PREPARE_MODEL.id();
   /** id of the {@link #APPLY_INPUT_VALUES} phase. */
   public static final int APPLY_INPUT_VALUES_ID = APPLY_INPUT_VALUES.id();
   /** id of the {@link #VALIDATE_INPUT_VALUES} phase. */
   public static final int VALIDATE_INPUT_VALUES_ID = VALIDATE_INPUT_VALUES.id();
   /** id of the {@link #PROCESS_UPDATE_MODEL} phase. */
   public static final int PROCESS_UPDATE_MODEL_ID = PROCESS_UPDATE_MODEL.id();
   /** id of the {@link #VALIDATE_MODEL_UPDATES} phase. */
   public static final int VALIDATE_MODEL_UPDATES_ID = VALIDATE_MODEL_UPDATES.id();
   /** id of the {@link #PROCESS_COMPONENT_EVENTS} phase. */
   public static final int PROCESS_COMPONENT_EVENTS_ID = PROCESS_COMPONENT_EVENTS.id();
   /** id of the {@link #PREPARE_RENDER} phase. */
   public static final int PREPARE_RENDER_ID = PREPARE_RENDER.id();
}
