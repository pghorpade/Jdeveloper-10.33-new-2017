package oracle.adf.controller.v2.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import oracle.adf.controller.lifecycle.OrdDomainInputHandler;
import oracle.adf.controller.v2.context.LifecycleContext;
import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.model.AttributeBinding;
import oracle.adf.model.BindingContext;
import oracle.adf.model.ControlBinding;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.OperationParameter;
import oracle.adf.model.RegionBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCCachingErrorHandler;
import oracle.adf.model.binding.DCErrorHandler;
import oracle.adf.model.binding.DCInvokeMethodDef;
import oracle.adf.share.ADFContext;
import oracle.adf.share.Environment;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.JboException;
import oracle.jbo.uicli.binding.JUCtrlActionBinding;
import oracle.jbo.uicli.binding.JUCtrlInputValueHandler;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;
import oracle.jbo.uicli.binding.JUCtrlValueDef;
import oracle.jbo.uicli.mom.JUMetaObjectManager;

import oracle.mds.core.MDSSession;

import oracle.ord.im.OrdHttpUploadFile;
import oracle.ord.im.OrdMultipartWrapper;

/**
 * <p>Implementation of the {@link PageLifecycle} abstract class.</p>
 * This contain the base implementation of the {@link Phases} of the ADF
 * Lifecycle.
 * 
 * @since 10.1.3
 */
public class PageLifecycleImpl extends PageLifecycle
{
   /**
    * A request-level property used to disable the token validation.
    * Token validation should only occur once per http request.
    */
   public static final String DISABLE_VALIDATE_TOKENS = "ADFDisableValidateTokens";

   /**
    * A custom input handler used by bindings dealing with ord domain type.
    */
   public static final String ordDomainInputHandlerName = "OrdDomainInputHandler";
   
   private static final ADFLogger logger =
      ADFLogger.createADFLogger(PageLifecycleImpl.class.getName());
   

   public PageLifecycleImpl()
   {
   }

   //  Inherit javadoc from Phases abstract class.
   public void initContext(LifecycleContext lfContext)
   {
      registerCustomInputHandler((PageLifecycleContext) lfContext);
         
      // Tell the Model error handler to go in caching mode
      setErrorHandlerCachingMode(lfContext, true);
   }

   /**
    * {@inheritDoc}
    * <p>If you need to reference prepared model values and/or update
    * the values of any bindings in the binding container, then you
    * can do it by overriding this method and doing it <b>after</b>
    * calling the superclass.
    * 
    */
   public void prepareModel(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;
         
      try
      {
         final RegionBinding bindings = context.getBindingContainer();
                  
         // publish the binding container as 'bindings' via the request object
         // this has now been removed from the page.
         ADFContext.getCurrent().getRequestScope().put(BindingContext.RESERVED_BINDINGS, bindings);
    
         bindings.refresh(RegionBinding.PREPARE_MODEL);
   
         if (shouldValidateToken(context, bindings))
         {
            disableTokenValidationForRequest(context);
            bindings.validateToken(getToken(context, bindings));
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }
   
   /**
    * {@inheritDoc}
    * In this method, the input values list and the event list are built.
    */
   public void applyInputValues(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;

      try
      {
         // Deal with input value
         buildInputValues(context);

         buildEventList(context);
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }

   //  Inherit javadoc from Phases abstract class.
   public void validateInputValues(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;
      HashMap errors = null;
      
      try
      {
         Map updatedValues = context.getUpdatedValues();
         
         if (updatedValues == null || updatedValues.size() == 0)
         {
            return;
         }
   
         for (Iterator iter = updatedValues.keySet().iterator();
              iter.hasNext();)
         {
            final AttributeBinding binding = (AttributeBinding) iter.next();
            // This validation only happen if ApplyValidation property is set to
            // true on the binding.
            final Object ex = binding.validateInputValue(updatedValues.get(binding));
            if (ex!= null)
            {
               if (errors == null)
               {
                  errors = new HashMap();
               }
               errors.put(binding, ex);
            }
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
      
      // Cache any errors for later phase
      if (errors != null && errors.size() > 0)
      {
         context.setInputValidationErrors(errors);
      }
      
   }

   /**
    * {@inheritDoc}
    * <p>This phase is executed only if the 
    * {@link #shouldAllowModelUpdate shouldAllowModelUpdate} method returns
    * true.</p>
    * <p>In case of error when setting the value to the model the errors will
    * not be thrown but collected in the binding container.</p>
    */
   public void processUpdateModel(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;
      
      try
      {
         // Fake the v1 'shouldAllowModelUpdate' phase.
         if (!context.getPageController().shouldAllowModelUpdate(context))
         {
            return;
         }

         Map updatedValues = context.getUpdatedValues();
         if (updatedValues == null || updatedValues.size() == 0)
         {
            return;
         }
         
         final Map inputValidationErrors = context.getInputValidationErrors();
         /*
          * Apply each new values to the binding. The values are coming from a
          * Map of values keyed by property name.
          * In case of error the method setInputValue will not throw but instead
          * the errors will be collected in the binding container.
          */
         for (Iterator iter = updatedValues.keySet().iterator();
              iter.hasNext();)
         {
            final AttributeBinding binding = (AttributeBinding) iter.next();
            // Only update values that passed the inputValidation phase
            if (inputValidationErrors == null || 
                inputValidationErrors.get(binding) == null)
            {  
               binding.setInputValue(updatedValues.get(binding));
            }
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public boolean shouldAllowModelUpdate(PageLifecycleContext context)
   {
      // Treat the built-in method coming in through the request parameters first
      final Map actionBindings = context.getControlActionBindings();
      if (actionBindings != null)
      {
         for (Iterator iter = actionBindings.values().iterator(); iter.hasNext(); )
         {
            JUCtrlActionBinding action = (JUCtrlActionBinding) iter.next();
            if (action.ignoreUpdates())
               return false;
         }
      }
      
      return true;
   }
   
   /**
    * {@inheritDoc}
    * <p>This phase is executed only if the 
    * {@link #shouldAllowModelUpdate shouldAllowModelUpdate} method returns
    * true.</p>
    * To delay model-level validation until Commit, override this method
    * and replace it with a no-op.
    */
   public void validateModelUpdates(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;

      try
      {
         // Fake the v1 'shouldAllowModelUpdate' phase.
         if (!context.getPageController().shouldAllowModelUpdate(context))
         {
            return;
         }

         // Add the input validation errors 
         final Map inputValidationErrors = context.getInputValidationErrors();
         if (inputValidationErrors != null)
         {
            final DCBindingContainer bindingContainer = (DCBindingContainer)
                                                context.getBindingContainer();

            for (Iterator iter = inputValidationErrors.keySet().iterator();
                 iter.hasNext();)
            {
               final AttributeBinding binding = (AttributeBinding) iter.next();
               JboException jboEx = (JboException) inputValidationErrors.get(binding);
               bindingContainer.processException(jboEx);
            }
         }

         context.getBindingContainer().validate();
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
      
      // In case of error, bypass the next phases and go directly to
      // prepareRender.
      if (context.getPageController().hasErrors(context))
      {
         context.prepareRender();  
      }
   }
   
   /**
    * {@inheritDoc}
    * Handle any events in the
    * {@link oracle.adf.controller.v2.context.PageLifecycleContext#getEvents Events}
    * list previously built during the {@link #applyInputValues applyInputValues}
    * phase.
    */
   public void processComponentEvents(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;

      try
      {
         final List events = context.getEvents();
         if (events != null)
         {
            for (Iterator iter = events.iterator(); iter.hasNext(); )
            {
               handleEvent(context, (String) iter.next());
            }
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public void executeEvent(PageLifecycleContext context, String event,
                            OperationBinding actionBinding)
   {
      if (actionBinding == null || event == null || event.length() == 0)
      {
         return;
      }

      try
      {
         String eventName = PageLifecycleContext.EVENT_METHOD_PREFIX +
                            event.substring(0, 1).toUpperCase() +
                            event.substring(1);
         
         // Set the EventActionBinidng so that the user custom code can get it
         // from the context.
         context.setEventActionBinding(actionBinding);

         boolean isOk = false;
         try
         {
            isOk = context.getPageController().invokeEventMethod(context, eventName);
         }
         catch (ClassCastException e)
         {
            logger.log(ADFLogger.INTERNAL_ERROR,
               "[ADFc] Invalid return type for method " + eventName);
         }
         catch (IllegalAccessException e)
         {
            logger.log(ADFLogger.INTERNAL_ERROR,
               "[ADFc] Exception return from method " + eventName);
         }
         catch (InvocationTargetException e)
         {
            Throwable t = e.getTargetException();
            if (t instanceof Exception)
            {
               context.getPageController().handleError(context, e);
               return;
            }
            else
            {
               logger.log(ADFLogger.INTERNAL_ERROR,
                  "[ADFc] Exception running method " + eventName);
            }
         }
         
         if (!isOk)
         {
            actionBinding.invoke();
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }
   
   /**
    * {@inheritDoc}
    * The default implementation looks at the content of the ExceptionList of
    * the {@link oracle.adf.model.BindingContainer BindingContainer} to
    * determine if an error occured.
    */
   public boolean hasErrors(PageLifecycleContext context)
   {
      final DCBindingContainer bindings =
                  (DCBindingContainer) context.getBindingContainer();
      
      // No bindings, no way to know if there are errors.
      if (bindings == null)
      {
         return false;
      }
      
      List runtimeErrors = bindings.getExceptionsList();
      if (runtimeErrors != null && runtimeErrors.size() > 0)
      {
         return true;
      }
            
      return false;
   }
   
   /**
    * In model 1 we do not have a way to initialize method parameters.
    * In the action binding the user can change the name of the parameters.
    * This function will iterate through the parameter names in the action
    * binding and look for request parameters that match those names.
    * This transfer of values allows us to pass in request parameters that
    * match the action binding's parameter names.
    * 
    * @param context       the Pagelifecycle context
    * @param actionBinding the action binding to initialize
    */
   protected void initializeParameterValuesUsingRequestObject(
                                          PageLifecycleContext context,
                                          OperationBinding actionBinding)
   {
      JUCtrlActionBinding action = (JUCtrlActionBinding) actionBinding;
      final DCInvokeMethodDef methodDef = action.getInvokeMethodDef();

      if (methodDef == null || methodDef.getParameters() == null)
         return;
      
      final int numParams = methodDef.getParameters().length;
      
      // see if we have request parameters that match method parameters
      OperationParameter paramDefs[] = methodDef.getParameters();
      
      ArrayList params = new ArrayList();
      
      final Map requestParameters = context.getEnvironment().getRequestParameterMap();
      if (requestParameters != null && requestParameters.size() > 0)
      {
         for (int i = 0; i < paramDefs.length; i++)
         {
            String sParamName = paramDefs[i].getName();
            Object value = requestParameters.get(sParamName);
            if (value != null)
            {
               params.add(((Object[]) value)[0]);
            }
         }
      }
      
      if (params.size() == numParams)
      {
         action.setParams(params);
      }      
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public void initializeMethodParameters(PageLifecycleContext context,
                                          OperationBinding actionBinding)
   {
      initializeParameterValuesUsingRequestObject(context, actionBinding);
   }
   
   //  Inherit javadoc from Phases abstract class.
   public void metadataCommit(LifecycleContext lfContext)
   {
      ADFContext adfContext = ADFContext.getCurrent();

      if (!adfContext.hasMDSSession())
      {
         return;
      }
      
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;

      // Commit any DT@RT changes
      try
      {
         MDSSession mdsSession = (MDSSession)adfContext.getMDSSessionAsObject();
         if (mdsSession != null)
         {
            if (mdsSession.hasChanges())
            {
               mdsSession.flushChanges();
               BindingContext bctx = context.getBindingContext();
               if (bctx != null)
               {
                  DCBindingContainer bindings = 
                     (DCBindingContainer) context.getBindingContainer();
         
                  if (bindings != null)
                  {
                     // Refresh BindingContainer def
                     JUMetaObjectManager.getJUMom().invalidateBindingContainerDef(
                        bctx,
                        bindings.getDef().getFullName());
                     //prepare again since this def has been removed.
                     
                     bindings = (DCBindingContainer) context.getBindingContainer();
                     // publish the binding container as 'bindings' via the request object
                     // this has now been removed from the page.
                     ADFContext.getCurrent().getRequestScope().put(BindingContext.RESERVED_BINDINGS, bindings);
                     bindings.refresh(RegionBinding.PREPARE_MODEL);
                  }
               }
            }
         }
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }
   }

   //  Inherit javadoc from Phases abstract class.
   public void prepareRender(LifecycleContext lfContext)
   {
      final PageLifecycleContext context = (PageLifecycleContext) lfContext;

      try
      {
         // BindingContainer should not be refresh in case of error because
         // otherwise we loose the exception state.
         if (!context.getPageController().hasErrors(context))
         {
            final RegionBinding bindings = context.getBindingContainer();
      
            if (bindings != null)
            {
               bindings.refresh(RegionBinding.RENDER_MODEL);
            }
         }
         
         // The findForward need to be executed after the binding container is
         // published because in the model 1 case, the findForward possibly
         // forwards the request or redirect the response.
         context.getPageController().findForward(context);
      }
      catch (Exception ex)
      {
         context.getPageController().handleError(context, ex);
      }

      context.getPageController().reportErrors(context);
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public void handleError(PageLifecycleContext context, Exception ex)
   {
      DCBindingContainer bindingContainer =
                           (DCBindingContainer) context.getBindingContainer();
      if (bindingContainer != null)
      {
          JboException jboEx;
          if (ex instanceof JboException)
          {
             jboEx = (JboException) ex;
          }
          else
          {
             jboEx = new JboException(ex);
          }
          
         bindingContainer.processException(jboEx);
      }
   }

   //  Inherit javadoc from PageLifecycle abstract class.
   public void reportErrors(PageLifecycleContext context)
   {
      // No-op
   }
   
//------------------------
//
//------------------------
   
   /**
    * Retrieve the token from the request
    */
   protected String getToken(PageLifecycleContext context,
                             RegionBinding bindings)
   {
      final Map requestParameters = context.getEnvironment().getRequestParameterMap();
      if (requestParameters == null)
      {
         return null;    
      }

      final String stateId = ((DCBindingContainer)bindings).getStateTokenId();
      Object values = requestParameters.get(stateId);
      if (values == null)
      {
         return null;    
      }
      return (String) ((Object[])values)[0];
   }

   /**
    * Checks the request object to see if token validation should occur. 
    */
   protected boolean shouldValidateToken(PageLifecycleContext context,
                                         RegionBinding bindings)
   {
      // Check that the token validation has not been disable. This is to
      // enforce the only once-per-request rule.
      
      if (ADFContext.getCurrent().getRequestScope().get(DISABLE_VALIDATE_TOKENS) != null)
      {
         return false;
      }

      if (getToken(context, bindings) != null &&
          bindings.isTokenValidationEnabled())
      {
         return true;
      }
         
      return false;
   }
   
   /**
    * Token validation will only occur once-per-request. This function will
    * disable token validation for the given request.
    * @see #DISABLE_VALIDATE_TOKENS
    */
   protected void disableTokenValidationForRequest(PageLifecycleContext context)
   {
      ADFContext.getCurrent().getRequestScope().put(DISABLE_VALIDATE_TOKENS, "notnull"); //NOTRANS
   }
   
   /**
    * Process a possible raw event coming as a request parameter.
    * This method handle the case where the request parameter is produced
    * from an image control where the parameter name represent the coordinate
    * of the mouse when clicked on the image.
    * This also make sure an event is not executed multiple time when the
    * request is forwarded.
    * @param context  the Pagelifecycle context
    * @param event    the event name
    */
   protected void processEvent(PageLifecycleContext context, String event)
   {
      // Event name is empty, that's a dud.
      if (event.length() == 0)
      {
         return;
      }

      // Image type control returns coordinate parameters 
      if (event.endsWith(".x") || event.endsWith(".y"))
      {
         event = event.substring(0, event.length() - 2);
         List events = context.getEvents();
         // Do not add the event twice when dealing with image (.x and .y)
         if (events != null && events.contains(event))
         {
            return;
         }
      }
      
      Map requestScope = ADFContext.getCurrent().getRequestScope();

      // If this event is marked as already being executed from a previous
      // forward, don't add it to the list.
      if (requestScope.get("adf_handled_"+event) != null)
      {
         return;
      }

      // Look if there is a binding associated with the event
      ControlBinding actionBinding = null;
      final RegionBinding regionBinding = context.getBindingContainer();
      if (regionBinding != null)
      {
         actionBinding = findCtrlBinding(regionBinding, event);
      }
      
      if (actionBinding != null)
      {
         // Do not add the event twice.
         Map actionBindings = context.getControlActionBindings();
         if (actionBindings != null &&
             actionBindings.containsValue(actionBinding))
         {
            return;
         }

         context.addControlActionBinding(event, (OperationBinding)actionBinding);
      }

      // Add this event to the list
      context.addEvent(event);
      
      // Add the event to the request to know not to execute them again
      requestScope.put("adf_handled_"+event, event);
   }
   
   /**
    * Look action binding with the name 'name' or 'Name'
    *
    * @param bindings the binding container
    * @param event    the event name
    */
   protected ControlBinding findCtrlBinding(RegionBinding bindings,
                                            String event)
   {
      ControlBinding actionBinding = (ControlBinding) bindings.getControlBinding(event);
      
      // If we did not find a binding with this name try the same name with 
      // the opposite case for the first letter.
      if (actionBinding == null ||
          !(actionBinding instanceof JUCtrlActionBinding))
      {
         char letter = event.charAt(0);
         String newEvent;
         
         // Switch the case of the first letter 
         if (Character.isUpperCase(letter))
         {
            newEvent = event.substring(0, 1).toLowerCase();
         }
         else if (Character.isLowerCase(letter))
         {
            newEvent = event.substring(0, 1).toUpperCase();
         }
         else
         {
            return null;
         }

         newEvent += event.substring(1);

         // and try it again
         actionBinding = (ControlBinding) bindings.getControlBinding(newEvent);

         if (actionBinding == null ||
             !(actionBinding instanceof JUCtrlActionBinding))
         {
            return null;
         }
      }

      return actionBinding;
   }
 
   /**
    * <p>Build a list of all the new submited ADF values from the request parameters.</p>
    * The result is a Map of values keyed by binding instance stored in the
    * {@link oracle.adf.controller.v2.context.PageLifecycleContext#setUpdatedValues UpdatedValues} property.<br>
    * Only new values are kept in the UpdatedValues list. 
    * 
    * @param context  the Pagelifecycle context
    */
   protected void buildInputValues(PageLifecycleContext context)
   {
      final RegionBinding regionBinding = context.getBindingContainer();
      if (regionBinding == null)
      {
         return;
      }

      final Object request = context.getEnvironment().getRequest();
      Map   parametersMap = null;
      Map   pendingValues = new HashMap();
      
      // If the request is multipart, process all the file type parameters.
      // We cannot use the map returned by getParameterMap, because it does not
      // work for multipart request, so build it ourself.
      if (request instanceof OrdMultipartWrapper)
      {
         OrdMultipartWrapper ordRequest = (OrdMultipartWrapper) request;
         parametersMap = new HashMap();
         
         Enumeration paramNames = ordRequest.getFileParameterNames();
         while (paramNames.hasMoreElements())
         {
            final String name = (String) paramNames.nextElement();
            Object[] paramValues = ordRequest.getFileParameterValues(name);   

            if (paramValues != null && paramValues.length > 0)
            {
               parametersMap.put(name, paramValues);
            }
         }
         
         List attributeBindings = regionBinding.getAttributeBindings();

         // Iterate through every binding in the RegionBinding, and ask
         // each binding, if it can resolve any of the path in the parameters
         // map. If it does, store the binding and the posted value.
         for (Iterator iter = attributeBindings.iterator();
              iter.hasNext();)
         {
            AttributeBinding binding = (AttributeBinding) iter.next();

            // For backward compatibility with 9.0.5.x we need to handle
            // the case where custom handler are not set at design time
            // through a property of the binding.
            // This only need to be done for formFileInputHandlerName which 
            // are only used in a multiparts post request.
            try
            {
               JUCtrlValueBinding valueBinding = (JUCtrlValueBinding) binding;
               JUCtrlValueDef def = (JUCtrlValueDef) valueBinding.getDef();
               if (!def.hasCustomInputHandler())
               {
                  // Set the inputHandler dynamically based on the type of the
                  // value.
                  String paramName = binding.getPath();
                  Object[] paramValues = (Object[]) parametersMap.get(paramName);
      
                  if (paramValues != null && /* param might not exist */
                      paramValues[0] instanceof OrdHttpUploadFile)
                  {
                     final BindingContext bctx = context.getBindingContext();  
            
                     valueBinding.setInputValueHandler((JUCtrlInputValueHandler)
                        bctx.getBindingInputHandler(ordDomainInputHandlerName));
                  }
               }
            }
            catch (ClassCastException ex)
            {
               // In case of cast exception because binding is not a
               // JUCtrlValueBinding, simply drop the towel.
            }
         }

         // Process file type parameters
         getRequestValues(regionBinding, parametersMap, pendingValues);
      }

      // We always need to process the non file type parameter.
      parametersMap = context.getParameterMap();
      getRequestValues(regionBinding, parametersMap, pendingValues);
      
      // Store the updatedValues in the context
      context.setUpdatedValues(pendingValues);
   }
   
   private void getRequestValues(RegionBinding regionBinding,
                                 Map parametersMap,
                                 Map pendingValues)
   {
      List attributeBindings = regionBinding.getAttributeBindings();

      // Iterate through every binding in the RegionBinding, and ask
      // each binding, if it can resolve any of the path in the parameters
      // map. If it does, store the binding and the posted value.
      for (Iterator iter = attributeBindings.iterator();
           iter.hasNext();)
      {
         AttributeBinding binding = (AttributeBinding) iter.next();

         if (binding.resolvePath(parametersMap))
         {
            String paramName = binding.getPath();
            Object[] paramValues = (Object[]) parametersMap.get(paramName);
            pendingValues.put(binding, paramValues[0]);
         }
      }
   }
 
   /**
    * Possible events are request parameters named "event" or which name are
    * prefixed with "event_". If there are parameters named "event" each of
    * their values are event names. If the parameter name starts with "event_",
    * the following part of  the name is the event name. (i.e "event_Next" will
    * add the event called "Next").
    * <p>The "event" prefix can be modified using
    * {@link PageLifecycleContext#setEventPrefix setEventPrefix}
    * 
    * <p>By doing this once and storing the result in the lifecycle context we
    * don't have to walk through the request parameter list multiple time during
    * the lifecycle.</p>
    * 
    * @see PageLifecycleContext#addControlActionBinding addControlActionBinding
    * @see PageLifecycleContext#getControlActionBindings getControlActionBindings
    * @see PageLifecycleContext#addEvent addEvent
    * @see PageLifecycleContext#getEvents getEvents
    */
   protected void buildEventList(PageLifecycleContext context)
   {
      final RegionBinding regionBinding = context.getBindingContainer();
      final Map parametersMap = context.getParameterMap();

      // Treat the action binding here
      if (regionBinding != null)
      {
         List actionBindings = regionBinding.getOperationBindings();
         for (Iterator iter = actionBindings.iterator();
              iter.hasNext();)
         {
            final OperationBinding binding = (OperationBinding) iter.next();
            if (binding.resolvePath(parametersMap))
            {
               final String name = ((JUCtrlActionBinding) binding).getName();
               context.addControlActionBinding(name, binding);
               // Add this event to the list
               context.addEvent(name);
            }
         }
      }

      // Treat the event here.
      // Iterate through all parameters.
      final String eventPrefix = context.getEventPrefix();
      final String eventPrefixUnder = eventPrefix + "_";

      for (Iterator iter = parametersMap.keySet().iterator();
           iter.hasNext();)
      {
         final String param = (String) iter.next();

         // Check if param is an event
         if (eventPrefix.equals(param))
         {
            String[] values = (String[]) parametersMap.get(param);
            for (int i = 0; i < values.length; i++)
            {
               processEvent(context, values[i]);
            }
         }
         // Check the second possible syntax for events: "event_xxx"
         else if (param.startsWith(eventPrefixUnder))
         {
            processEvent(context, param.substring(eventPrefixUnder.length()));
         }
      }
   }
 
   /**
    * Register OrdDomainInputHandler custom input handler to the binding
    * context.
    */
   protected void registerCustomInputHandler(PageLifecycleContext context)
   {
      final BindingContext bctx = context.getBindingContext();
      if (bctx == null)
      {
         return;
      }
      
      JUCtrlInputValueHandler inputHandler = (JUCtrlInputValueHandler)
         bctx.getBindingInputHandler(ordDomainInputHandlerName);
      if (inputHandler == null)
      {
         inputHandler = new OrdDomainInputHandler();

         // Initialize default InputHandler here
         HashMap inputHandlerMap = new HashMap(2);
         inputHandlerMap.put(ordDomainInputHandlerName, inputHandler);
         bctx.setBindingInputHandlers(inputHandlerMap);
      }
   }
   
   /**
    * Handle an event.
    * An event handler can be a method defined in a subclass of this
    * PageLifecycle. To be recognized as an event handle the method need to
    * have the following syntax:
    * <pre>
    * public void on<b>Event</b>(LifecycleContext ctx)
    * {
    *    // Use the following method to execute the possible
    *    // action binding associated with this event
    *    ctx.getEventActionBinding().invoke();
    * }
    * </pre>
    * Where <b>Event</b> is the name of the event.
    * <p>
    * An event can also be an action binding with the same name of the event
    * present in the current binding container.
    * @param context  the PageLifecycle context
    * @param event    the name of the event to handle
    * @return <code>true</code> if the event was mapped to an action binding
    * @throws java.lang.Exception
    * @see            #buildEventList buildEventList
    * @see            PageLifecycleContext#EVENT_METHOD_PREFIX
    */
   protected boolean handleEvent(PageLifecycleContext context, String event)
      throws Exception
   {
      // Always uppercase the first letter. Format is "onEvent"
      String eventName = PageLifecycleContext.EVENT_METHOD_PREFIX +
                         event.substring(0, 1).toUpperCase() +
                         event.substring(1);
      
      // Set the EventActionBinding as a convenience to the user writing the
      // event handler.
      Map actions = context.getControlActionBindings();
      if (actions != null)
      {
         context.setEventActionBinding((OperationBinding) actions.get(event));
      }

      boolean isOk = false;
      try
      {
         isOk = context.getPageController().invokeEventMethod(context, eventName);
      }
      catch (ClassCastException e)
      {
         String message = "[ADFc] Invalid return type for method " + eventName + ".\n";
         logger.log(ADFLogger.ERROR, message + e.getMessage(), e);
      }
      catch (IllegalAccessException e)
      {
         String message = "[ADFc] Exception returned from method " + eventName + ".\n";
         logger.log(ADFLogger.ERROR, message + e.getMessage(), e);
      }
      catch (InvocationTargetException e)
      {
         Throwable t = e.getTargetException();
         if (t instanceof Exception)
         {
            // Re-throw the original exception to be catch using the
            // existing framework.
            throw ((Exception) t);
         }
         else
         {
            String message = "[ADFc] Exception running method " + eventName + ".\n";
            logger.log(ADFLogger.ERROR, message + e.getMessage(), e);
         }
      }
      
      if (!isOk)
      {
         isOk = invokeActionBinding(context, event);
         
         if (!isOk)
         {
            logger.log(ADFLogger.TRACE,
                  "[ADFc] No Method " + eventName +
                                  " and no actionBinding " + event + " found.");
         }
      }

      return isOk;
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public Method getEventMethod(PageLifecycleContext lcContext,
                                String eventName)
   {
      return PageLifecycle.getEventMethodFromCache(events, clazz, eventParam,
                                                   eventName);
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public boolean invokeEventMethod(PageLifecycleContext lcContext,
                                    String eventName)
      throws Exception
   {
      boolean isOk = false;
                                                      
      Method event = getEventMethod(lcContext, eventName);

      // Found it, so invoke it.
      if (event != null)
      {
         Object args[] = { lcContext };
         event.invoke(this, args);
         isOk = true;
      }

      return isOk;
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public boolean invokeActionBinding(PageLifecycleContext context,
                                      String event)
   {
      Map actions = context.getControlActionBindings();
      if (actions == null)
      {
         return false;
      }

      OperationBinding action = (OperationBinding) actions.get(event);
      if (action != null)
      {
         // Call the initializeMethodParameters through the PageController
         // class to give the opportunity to the user to overwrite it...
         context.getPageController().initializeMethodParameters(context, action);

         // Execute the action.
         action.invoke();
         
         return true;
      }
      
      return false;
   }
   
   //  Inherit javadoc from PageLifecycle abstract class.
   public void findForward(PageLifecycleContext context)
      throws Exception
   {
      String path = context.getForwardPath();
      if (path != null)
      {
         final Environment environment = context.getEnvironment();

         if (context.getRedirect())
         {
            if (path.charAt(0) == '/')
            {
               path = environment.getRequestContextPath() + path;
            }
            
            environment.redirect(environment.encodeResourceURL(path));
         }
         else
         {
            context.getEnvironment().dispatch(path);
         }
      }
   }
   
   /**
    * Set the Model error handler caching mode. When the caching mode is true
    * Any error ocurring on the model is cached instead of being thrown. The
    * error can be later treated.
    */
   private void setErrorHandlerCachingMode(LifecycleContext lfContext, boolean mode)
   {
      final BindingContext bctx = lfContext.getBindingContext();
      if (bctx == null)
      {
         return;
      }
      
      DCErrorHandler handler = bctx.getErrorHandler();
      if (handler instanceof DCCachingErrorHandler)
      {
         ((DCCachingErrorHandler) handler).setThrowFlag(!mode);
      }
      
   }


}
