package oracle.adf.controller.v2.lifecycle;

import java.util.Map;

import oracle.adf.controller.v2.context.LifecycleContext;

/**
 * <p>Default implementation of the standard ADF Lifecycle processing.</p>
 * <pre>
      final LifecycleContext context = LifecycleContext.getInstance(envMap);

      executePhase(INIT_CONTEXT, context);
      
      executePhase(PREPARE_MODEL, context);

      executePhase(APPLY_INPUT_VALUES, context);

      if (!context.getPrepareRender())
      {
         executePhase(VALIDATE_INPUT_VALUES, context);
      }
      
      if (!context.getPrepareRender())
      {
         executePhase(PROCESS_UPDATE_MODEL, context);
      }

      if (!context.getPrepareRender())
      {
         executePhase(VALIDATE_MODEL_UPDATES, context);
      }
      
      if (!context.getPrepareRender())
      {
         executePhase(PROCESS_COMPONENT_EVENTS, context);
      }

      if (!context.getPrepareRender())
      {
         executePhase(METADATA_COMMIT, context);
      }
      
      executePhase(PREPARE_RENDER, context);
   </pre>
 *
 * @since 10.1.3 
 */
public class LifecycleProcessor extends Lifecycle 
{
   /** Singleton LifecycleProcessor instance */
   private static LifecycleProcessor defaultInstance;
   
   // Static block to instanciate the singleton in a threadsafe way
   static
   {
      defaultInstance = new LifecycleProcessor();
   }
   
   /**
    * Return the singleton LifecycleProcessor instance
    */
   public static LifecycleProcessor getInstance()
   {
      return defaultInstance;
   }

   /**
    * Define the order in which all the phases of the PageLifecycle are
    * executed.
    * @param envMap Map used to instanciate the LifecycleContext
    * @throws Exception 
    */
   public void execute(Map envMap) throws Exception
   {
      final LifecycleContext context = LifecycleContext.getInstance(envMap);

      executePhase(INIT_CONTEXT, context);
      
      executePhase(PREPARE_MODEL, context);

      executePhase(APPLY_INPUT_VALUES, context);

      if (!context.getPrepareRender())
      {
         executePhase(VALIDATE_INPUT_VALUES, context);
      }
      
      if (!context.getPrepareRender())
      {
         executePhase(PROCESS_UPDATE_MODEL, context);
      }

      if (!context.getPrepareRender())
      {
         executePhase(VALIDATE_MODEL_UPDATES, context);
      }
      
      if (!context.getPrepareRender())
      {
         executePhase(PROCESS_COMPONENT_EVENTS, context);
      }

      if (!context.getPrepareRender())
      {
         executePhase(METADATA_COMMIT, context);
      }
      
      executePhase(PREPARE_RENDER, context);
   }
   
}