package oracle.adf.controller.v2.lifecycle;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

import oracle.adf.controller.v2.context.PageLifecycleContext;
import oracle.adf.model.OperationBinding;

/**
 * The PageLifecycle class is the base class for any ADF Lifecycle. It defines
 * a set of behavior that an ADF Lifecycle needs in addition to the Phases.
 * 
 * @since 10.1.3
 */
public abstract class PageLifecycle extends Phases
{
   /**
    * Cache the set of event methods as they are introspected.
    */
   protected Map events = new HashMap();
   
   /**
    * The Class instance for this class (PageLifecycle).
    */
   protected Class clazz = this.getClass();
   
   /**
    * The set of argument type classes for the reflected event method call.
    */
   protected Class eventParam[] = { getLifecycleContextClass() };
   
   /**
    * Returns the LifecycleContext class used by this PageLifecycle.
    * Any PageLifecycle subclass can have their own context by subclassing 
    * PageLifecycleContext.
    */
   public Class getLifecycleContextClass()
   {
      return PageLifecycleContext.class;
   }
   
   /**
    * Execute a single event.
    * @see PageLifecycleImpl#handleEvent handleEvent.
    */
   abstract public void executeEvent(PageLifecycleContext context, String event,
                                     OperationBinding actionBinding);
   
   /**
    * Handles any exceptions that occurred during the PageLifecycle processing.
    * Clients have an opportunity to merge the exception with the model
    * errors stored in the 
    * {@link oracle.adf.model.BindingContainer BindingContainer}.
    */
   abstract public void handleError(PageLifecycleContext context, Exception ex);
   
   /**
    * Return true if an error occured during validation.
    */
   abstract public boolean hasErrors(PageLifecycleContext context);
   
   /**
    * Provide the opportunity to build an error list in a format appropriate
    * to the view layer.
    */
   abstract public void reportErrors(PageLifecycleContext context);

   /**
    * This method is called during the processUpdateModel phase. It provides a
    * way to programmatically by-pass model updates.
    * The data model updates are disabled when specific action like 'rollback'
    * will be executed during the lifecycle. This is done by calling the
    * ignoreUpdates method or each action in the event list. The custom method
    * ignoreUpdates is also called.
    *
    * Bypassing update might be necessary for operations such as rollback or
    * custom methods that want to veto the change.<br>
    * Overide this method if you need to add logic to skip data model updates.
    * @see oracle.jbo.uicli.binding.JUCtrlActionBinding#ignoreUpdates()
    */
   abstract public boolean shouldAllowModelUpdate(PageLifecycleContext context);
   
   /**
    * This method is invoked before any ControlBinding or custom method is
    * being executed. Overriding this method gives an opportunity to set the
    * parameters.
    * 
    * @param context       the PageLifecycle context
    * @param actionBinding the action binding object to initialize
    */
   abstract public void initializeMethodParameters(PageLifecycleContext context,
                                                   OperationBinding actionBinding);
                                            
   /**
    * Retrieve the Method class for a given an event name.
    * 
    * @param context    the PageLifecycle context
    * @param eventName  name of the event
    * @return           the Method object for this event if exist
    */
   abstract Method getEventMethod(PageLifecycleContext context,
                                  String eventName);
   
   /**
    * Execute the Method class for a given an event name.
    * 
    * @param context    the PageLifecycle context
    * @param eventName  name of the event
    * @return           the Method object for this event if exist
    */
   abstract boolean invokeEventMethod(PageLifecycleContext context,
                                      String eventName)
      throws Exception;
   
   /**
    * Invoke the action binding associated with the event name.
    * <p>An action binding is associated with an event if an action binding with
    * the same name as the event exist in the current binding container. If the
    * action binding exist, the method parameters are initialized using the 
    * {@link #initializeMethodParameters initializeMethodParameters} method on
    * the PageLifecycle before executing the action binding.</p><br>
    * If the action binding exist the method return <code>true</code>
    * @param context   the lifecycle context
    * @param event     the name of the event
    * @return          <code>true</code> if an action binding is associated
    *                   with the event
    */
   abstract boolean invokeActionBinding(PageLifecycleContext context,
                                        String event);
   
   /**
    * The path of the next web page is identified using the forwardPath
    * property on the PageLifecycleContext.
    * If the redirect property on the PageLifecycleContext is true, the response
    * will be redirected to the specified path.
    * Otherwise, the request will be forwarded to the specified path.
    */ 
   abstract public void findForward(PageLifecycleContext context)
      throws Exception;

   /**
    * <b>Internal</b>
    * Event methods are cached so that introspection is only done once.
    */
   protected static final Method getEventMethodFromCache(Map events,
                                                         Class clazz,
                                                         Class eventParams[],
                                                         String eventName)
   {
      synchronized (events)
      {
         Method event;
         
         // To differentiate between entry in the table and entry with null
         // value, look if the key is there first
         if (events.containsKey(eventName))
         {
            // The key is there, return the method (that possibly is null)
            event = (Method) events.get(eventName);
         }
         else
         {
            try
            {
               event = clazz.getMethod(eventName, eventParams);
            }
            catch (NoSuchMethodException ex)
            {
               // Store the fact that the method does not exist so we don't
               // introspect again.
               event = null;
            }

            events.put(eventName, event);
         }
         
         return event;
      }
   }
   

}
