package aegaron.service;

public interface ILog {
    public static final boolean ENABLED = false;
}
