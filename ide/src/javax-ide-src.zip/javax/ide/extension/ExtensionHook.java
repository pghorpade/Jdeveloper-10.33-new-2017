/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension;

import java.net.URI;

import javax.ide.extension.spi.ExtensionSource;
import javax.ide.extension.spi.ExtensionVisitor;

/**
 * An extension hook is responsible for processing information from the 
 * extension manifest for a particular feature and making this information
 * available to the service responsible for managing the functionality 
 * provided by the hook.<p>
 */
public abstract class ExtensionHook extends ElementVisitor 
{
  public static final String KEY_EXTENSION = "extension";
  public static final String KEY_RSBUNDLE_CLASS = "rsbundleclass";
  
  private String _schemaLocation;
  
  /**
   * The XML namespace for a JSR-198 extension manifest.
   */
  public static final String MANIFEST_XMLNS = 
    "http://jcp.org/jsr/198/extension-manifest";
  
  /**
   * Set the location of the schema for this hook. This method is called by
   * the extension registry when processing hooks.
   * 
   * @param schemaLocation the schema location.
   */
  public final void setSchemaLocation( String schemaLocation )
  {
    _schemaLocation = schemaLocation;
  }
  
  /**
   * Get the location of the schema for this hook.
   * 
   * @return the location of the schema for this hook.
   */
  public final String getSchemaLocation()
  {
    return _schemaLocation;
  }

  /**
   * Get the resource bundle class name.
   * 
   * @param context the current context.
   * @return the fully qualified class name of the resource bundle for the
   *    current context.
   */
  protected final String getRSBundleClass( ElementContext context )
  {
    return (String) context.getScopeData().get( KEY_RSBUNDLE_CLASS );
  }

  /**
   * Get the extension that is currently being processed.
   * 
   * @param context the current context.
   * @return the extension being processed.
   */
  protected final Extension getExtension( ElementContext context )
  {
    return (Extension) context.getScopeData().get( KEY_EXTENSION );
  }
  
  /**
   * Resolve a path in the manifest. Paths depend on the source of the 
   * extension being processed. For JAR files, if the path starts with a 
   * forward slash (/), it is a path inside the JAR file. Otherwise, it is a 
   * path relative to the physical location of the JAR file.
   * 
   * @param context the xml processing context.
   * @param path a path to resolve. Must not be null.
   * @return the absolute path a resource. This may or may not exist.
   */
  protected final URI resolvePath( ElementContext context, String path )
  {
    if ( path == null )
    {
      throw new NullPointerException( "path is null" );
    }
    
    ExtensionSource source = (ExtensionSource) context.getScopeData().get( 
      ExtensionVisitor.KEY_EXTENSION_SOURCE
    );
    Extension extension = (Extension) context.getScopeData().get( 
      ExtensionHook.KEY_EXTENSION
    );
    
    return source.resolvePath( extension, path );
  }
}
