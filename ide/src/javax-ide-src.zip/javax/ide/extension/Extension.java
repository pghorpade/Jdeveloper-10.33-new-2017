/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension;

import java.util.Collection;
import javax.ide.Identifiable;
import javax.ide.net.URIPath;
import javax.ide.util.Version;
 
/**
 * Information gathered from the Extension Deployment Descriptor is stored by 
 * implementations of this interface.  Such information include the extension's 
 * id, owner, version information, etc.
 */
public interface Extension extends Identifiable
{
  //---------------------------------------------------------------------------
  // Public methods.
  //---------------------------------------------------------------------------

  /**
   * Get the name of this extension. The name should not include
   * the extension version label.
   *
   * @return A short name for this extension.
   */
  public String getName();

  /**
   * Get the extension owner name.
   *
   * @return A label identifying the extension writer.
   */
  public String getOwner();

  /**
   * Get the extension version information.
   *
   * @return A the extension version specification. 
   */
  public Version getVersion();

  /**
   * This method is called by an IDE to inquire about the version of the 
   * Extenstion Development Kit (EDK) used in its implementation.
   * An IDE can decide not to load this extension if they don't yet support 
   * the EDK version returned. If <code>null</code> is returned, the IDE
   * will not load the extension.
   *
   * @return The version of the EDK used to implement this extension.
   */
  public Version getEDKVersion();

  /**
   * This method is called by an IDE to inquire about platform specific
   * information that must be supported by the IDE for this extension to
   * work. For example, the extension platform information may indicate
   * the it requires swing to work.
   */
  public PlatformInfo getPlatformInfo();

  /**
   * Gets a collection of {@link ExtensionDependency} objects, one for each 
   * dependency this extension has on another extension.
   * 
   * @return a collection of {@link ExtensionDependency} objects. May be empty.
   */
  public Collection getDependencies();

  /**
   * Get an additional classpath where classes used by this extension 
   * can be found.
   */
  public URIPath getClassPath();
}
