/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension.spi;

import java.util.ArrayList;
import java.util.Collection;

import javax.ide.extension.ElementContext;
import javax.ide.extension.ElementEndContext;
import javax.ide.extension.ElementName;
import javax.ide.extension.ElementStartContext;
import javax.ide.extension.ElementVisitor;
import javax.ide.extension.ElementVisitorFactory;
import javax.ide.extension.Extension;
import javax.ide.extension.ExtensionHook;
import javax.ide.extension.I18NStringVisitor;

/**
 * Visitor for the root JSR-198 extension element. This is the "entry point"
 * for all manifest processing.
 */
public abstract class ExtensionVisitor extends BaseExtensionVisitor
{

  private static final ElementName NAME = 
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "name" );
  private static final ElementName OWNER =
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "owner" );
  private static final ElementName HOOKS =
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "hooks" );
  private static final ElementName CLASSPATHS = 
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "classpaths" );


  private ElementVisitor _nameVisitor = createNameVisitor();
  private ElementVisitor _ownerVisitor = createOwnerVisitor();
  private ElementVisitor _hooksVisitor = createHooksVisitor();
  private ElementVisitor _classpathsVisitor = createClasspathsVisitor();

  private ElementVisitor _dependenciesVisitor = createDependenciesVisitor();
 

  
  /**
   * The key for the <tt>ClassLoader</tt> to be used to when looking up classes
   * for the current extension. This is used by I18NStringVisitor / 
   * I18NCharVisitor. If no classloader is in the scope map, the context
   * classloader of the current thread is used.
   */
  public static final String KEY_CLASSLOADER = "classLoader";
  
  private Collection _extensions = new ArrayList();
  
  private final ElementVisitorFactory _hookVisitorFactory;
  
  protected ExtensionVisitor( ElementVisitorFactory hookFactory )
  {
    _hookVisitorFactory = hookFactory;
  }
  
  public final Collection getExtensions()
  {
    return _extensions;
  }
    
  public final void start( ElementStartContext context )
  {
    Extension ext = processExtension( context );
    if ( ext == null )
    {
      return;
    }
    
    context.getScopeData().put( ExtensionVisitor.KEY_CLASSLOADER, 
      getClassLoader( ext ) );
    
    String rsbundleClass = context.getAttributeValue( "rsbundle-class" );
    if ( rsbundleClass != null && 
      ( rsbundleClass = rsbundleClass.trim()) != "" )
    {
      context.getScopeData().put( ExtensionHook.KEY_RSBUNDLE_CLASS, 
        rsbundleClass );
    }
    
    context.registerChildVisitor( NAME, _nameVisitor );
    context.registerChildVisitor( OWNER, _ownerVisitor );
    context.registerChildVisitor( HOOKS, _hooksVisitor );
    context.registerChildVisitor( CLASSPATHS, _classpathsVisitor );
    context.registerChildVisitor( DependenciesVisitor.ELEMENT, 
      _dependenciesVisitor );
  }
  
  public final void end( ElementEndContext end )
  {
    _extensions.add( (Extension) end.getScopeData().get( ExtensionHook.KEY_EXTENSION ));
  }
  
  

  

  
  protected ElementVisitor createNameVisitor()
  {
    return new I18NStringVisitor() 
    {
      public void string( ElementContext context, String value )
      {
        getExtension( context ).setName( value );
      }
    };
  }
  
  protected ElementVisitor createOwnerVisitor()
  {
    return new I18NStringVisitor()
    {
      public void string( ElementContext context, String value )
      {
        getExtension( context ).setOwner( value );
      }
    };
  }

  protected ElementVisitor createClasspathsVisitor()
  {
    return new ClasspathsVisitor();
  }
  
  protected ElementVisitor createHooksVisitor()
  {
    return new HooksVisitor();
  }
  
  protected ElementVisitor createDependenciesVisitor()
  {
    return new DependenciesVisitor();
  }
  

  
  private final class HooksVisitor extends ElementVisitor
  {
    public void start( ElementStartContext context )
    {
      context.registerVisitorFactory( _hookVisitorFactory );
    }
  }
  
  /**
   * Get the class loader that should be used by default to load an 
   * extension.<p>
   * 
   * This implementation returns Thread.currentThread().getContextClassLoader().
   * 
   * @param extension the extension being processed.
   * @return the classloader to use to load resources for the specified 
   *    extension.
   */
  protected ClassLoader getClassLoader( Extension extension )
  {
    return Thread.currentThread().getContextClassLoader();
  }
}
