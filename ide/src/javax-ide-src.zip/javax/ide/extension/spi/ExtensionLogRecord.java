package javax.ide.extension.spi;

import java.util.logging.Level;
import java.util.logging.LogRecord;

import javax.ide.extension.ElementContext;

import javax.ide.extension.ElementVisitor;

import org.xml.sax.Locator;

/**
 * Extension log records hold positional information about the location where
 * log messages occurred while processing the extension manifest.
 */
public final class ExtensionLogRecord extends LogRecord
{
  private final Locator _locator;

  /**
   * Creates a log record.
   * 
   * @param context the current procesing context.
   * @param level the message log level.
   * @param msg the message to log.
   */
  public ExtensionLogRecord( ElementContext context, Level level, String msg )
  {
    super( level, msg );
    _locator = (Locator) context.getScopeData().get( ElementVisitor.KEY_LOCATOR );
  
    // For backwards compatibility (early versions of the API used the
    // parameters array to store the locator)
    if ( _locator != null )
    {
      setParameters( new Object[] { _locator } );
    }
  }
  
  /**
   * Gets the locator.
   * 
   * @return the locator.
   */
  public Locator getLocator()
  {
    return _locator;
  }
}
