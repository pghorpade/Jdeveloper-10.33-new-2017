/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension.spi;

import java.net.URI;

import java.net.URL;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import javax.ide.extension.ElementContext;
import javax.ide.extension.ElementEndContext;
import javax.ide.extension.ElementName;
import javax.ide.extension.ElementStartContext;
import javax.ide.extension.ElementVisitor;
import javax.ide.extension.ElementVisitorFactory;
import javax.ide.extension.Extension;
import javax.ide.extension.ExtensionHook;

import javax.ide.net.URIFactory;

import org.xml.sax.Attributes;


/**
 * A default XML context implementation. This provides access to methods that
 * change the context and should only be used by ExtensibleSAXHandler.
 */
public class DefaultElementContext
  implements ElementContext, ElementStartContext, ElementEndContext
{
  private Attributes _attributes;
  private ElementName _name;
  private final Stack _elementPathStack = new Stack();
  private final ScopedMap _contextMap = new ScopedMap();
  private final Stack _elementText = new Stack();

  private final Stack _childHandlers = new Stack();
  private Map _ceChildHandlers = null;

  private Logger _logger;

  private final Stack _visitorFactoryStack = new Stack();

  public DefaultElementContext()
  {
    // Initialize the "global" value map.
    _childHandlers.push( null );
    _visitorFactoryStack.push( new ArrayList() );
  }

  /**
   * Get the local name of the current element.
   *
   * @return the local name of the current element.
   */
  public ElementName getElementName()
  {
    return _name;
  }

  /**
   * Get the text contained in this element. It's only valid to call this from
   * EDDElementHandler.handleEndElement.
   */
  public String getText()
  {
    StringBuffer buffer = (StringBuffer) _elementText.peek();

    if ( buffer == null )
    {
      return null;
    }

    return processText( buffer.toString() );
  }

  /**
   * Get the value of an attribute for this element. It's only valid to call
   * this from EDDElementHandler.handleStartElement.
   *
   * @param attributeName the local name of an XML attribute, must not be
   *    null.
   * @return the value of the specified attribute, or null if not present.
   */
  public String getAttributeValue( String attributeName )
  {
    if ( _attributes == null )
    {
      throw new IllegalStateException(
        "Cannot call from handleEndElement"
      );
    }

    if ( attributeName == null )
    {
      throw new IllegalArgumentException( "attributeName must not be null" );
    }

    return processText( _attributes.getValue( attributeName ) );
  }

  public Collection getAttributeNames()
  {
    if (_attributes == null)
    {
      throw new IllegalStateException();
    }
    ArrayList al = new ArrayList( _attributes.getLength() );
    for ( int i=0; i < _attributes.getLength(); i++ )
    {
      al.add( _attributes.getLocalName( i ) );
    }

    return Collections.unmodifiableCollection( al );
  }

  public Map getScopeData()
  {
    return _contextMap;
  }

  /**
   * Register a handler that will be used only for immediate children of the
   * current element.
   *
   * @param name the element name.
   * @param visitor the {@link ElementVisitor}.
   */
  public void registerChildVisitor( ElementName name, ElementVisitor visitor )
  {
    if ( _ceChildHandlers == null )
    {
      _ceChildHandlers = new HashMap();
    }
    _ceChildHandlers.put( name, visitor );
  }


  public void registerVisitorFactory( ElementVisitorFactory factory )
  {
    List visitorFactories = (List)_visitorFactoryStack.peek();
    visitorFactories.add( factory );
  }

  /**
   * Get a scoped handler for the current element (if any)
   */
  public ElementVisitor getScopedHandler()
  {
    ElementName qualified = _name;
    ElementName unqualified = new ElementName( null, _name.getLocalName() );
    ElementVisitor handler = null;

    // Look for child-only handlers first.
    Map childHandlerMap = (Map) _childHandlers.peek();
    if ( childHandlerMap != null )
    {
      handler = (ElementVisitor) childHandlerMap.get( qualified );
      if ( handler == null )
      {
        handler = (ElementVisitor) childHandlerMap.get( unqualified );
      }

      if ( handler != null )
      {
        return handler;
      }

    }

    // Visitor factories are scoped. We have to iterate the whole
    // stack looking for a visitor.

    for ( Iterator si = _visitorFactoryStack.iterator(); si.hasNext(); )
    {
      List visitorFactories = (List) si.next();
      if ( visitorFactories != null )
      {
        for ( Iterator i = visitorFactories.iterator(); i.hasNext(); )
        {
          ElementVisitorFactory factory = (ElementVisitorFactory) i.next();

          ElementVisitor visitor = factory.getVisitor( _name );
          if ( visitor != null )
          {
            return visitor;
          }
        }

      }

    }


    return handler;
  }

  private void setElement( String uri, String name )
  {
    _name = new ElementName( uri, name );
  }

  void beginElement( String uri, String name, Attributes attributes )
  {
    setElement( uri, name );
    _attributes = attributes;

    _contextMap.enterScope();

    _childHandlers.push( _ceChildHandlers );
    _visitorFactoryStack.push( new ArrayList() );
    _ceChildHandlers = null;
  }

  void appendCharacters( char[] characters, int start, int length )
  {
    if ( _elementText.isEmpty() )
    {
      throw new IllegalStateException();
    }

    StringBuffer buffer = (StringBuffer) _elementText.peek();
    if ( buffer == null )
    {
      buffer = new StringBuffer();
      _elementText.replace( buffer );
    }

    buffer.append( characters, start, length );
  }

  void postEndElement()
  {
    _contextMap.exitScope();
    _elementText.pop();
    _ceChildHandlers = (Map) _childHandlers.peek();
    _childHandlers.pop();

    _visitorFactoryStack.pop();


    _name = null;
    _attributes = null;
  }

  void endElement( String uri, String name )
  {
    setElement( uri, name );
    _attributes = null;
    _elementPathStack.pop();
  }

  /**
   * Push the current element onto the element stack.
   */
  void postBeginElement()
  {
    _elementPathStack.push( _name );
    _elementText.push( null );    // StringBuffer is created lazily.
  }

  public Logger getLogger()
  {
    if ( _logger == null )
    {
      _logger = new NullLogger();
    }
    return _logger;
  }

  public void setMessageReporter( Logger logger )
  {
    _logger = logger;
  }

  /**
   * Get the extension currently being processed.
   *
   * @return the exetnsion currently being processed.
   */
  public Extension getExtension()
  {
    return (Extension) getScopeData().get( ExtensionHook.KEY_EXTENSION );
  }


  /**
   * Get the URI of the source of the extension. For extensions packaged in
   * JAR files, this is the URI of the JAR file.
   *
   * @return the URI of the exension source.
   */
  public URI getExtensionSourceURI()
  {
    ExtensionSource source = (ExtensionSource) getScopeData().get(
      ExtensionVisitor.KEY_EXTENSION_SOURCE
    );
    return source.getURI();
  }

  /**
   * Process the text of either an attribute value or a text node.
   * The default implementation calls substituteMacros(), then
   * handles the prefixes res: and url:.
   *
   * @param text the text to process.
   * @return the processed text.
   */
  protected String processText( String text )
  {
    if ( text == null ) return null;

    String newText = substituteMacros( text );

    if ( newText.startsWith( "res:" )  )
    {
      return resolveResource( newText );
    }
    else if ( newText.startsWith( "uri:" ) )
    {
      return resolveUri( newText );
    }

    return newText;
  }

  private String resolveUri( String text )
  {
    if ( text.length() > 4 )
    {
      String uriString = text.substring( 4 );
      Extension ext = (Extension) getScopeData().get(
        ExtensionHook.KEY_EXTENSION );
      ExtensionSource source = (ExtensionSource) getScopeData().get(
        ExtensionVisitor.KEY_EXTENSION_SOURCE );

      URI resolved = source.resolvePath( ext, uriString );
      if ( resolved == null )
      {
        getLogger().log( new ExtensionLogRecord( this, Level.WARNING,
          "Unresolved uri: '" + uriString + "'." ) );
        return text;
      }
      return "uri:" + resolved.toString();
    }
    getLogger().log( new ExtensionLogRecord( this, Level.SEVERE,
      "No uri specified."  ) );
    return text;
  }

  private String resolveResource(String text)
  {
    if ( text.length() > 4 )
    {
      String resString = text.substring( 4 );
      if ( resString.charAt( 0 ) == '/' && resString.length() > 1 )
      {
        // Load a resource relative to the context classloader.
        final ClassLoader cl = getContextClassLoader();
        final URL resUrl = cl.getResource( resString.substring( 1 ) );
        if ( resUrl != null )
        {
          URI uri = URIFactory.newURI( resUrl );
          return "uri:" + uri.toString();
        }
      }
      else
      {
        // Load resource relative to the resource bundle class.
        ResourceBundle bundle = getContextResourceBundle();
        if ( bundle != null )
        {
          final URL resUrl = bundle.getClass().getResource( resString );
          if ( resUrl != null )
          {
            URI uri = URIFactory.newURI( resUrl );
            return "uri:" + uri.toString();
          }
        }
      }
      getLogger().log( new ExtensionLogRecord( this, Level.SEVERE,
        "Resource not found: '" + resString + "'."));
      return text;
    }
    else
    {
      getLogger().log( new ExtensionLogRecord( this, Level.SEVERE,
        "No resource specified" ) );
      return text;
    }
  }

  /**
   * Perform macro substitutions on the specified string.
   *
   * @param s a string
   */
  protected final String substituteMacros( String s )
  {
    if ( s == null )
    {
      return null;
    }

    StringBuffer result = new StringBuffer();

    int start = 0;
    int pos;
    while ( (pos = s.indexOf( '$', start )) != -1 )
    {
      result.append( s.substring( start, pos ) );
      if ( pos == s.length() - 1)
      {
        break;
      }
      if ( s.charAt( pos + 1 ) == '{' )
      {
        int fin = s.indexOf( '}', pos+1 );
        if ( fin == -1 )
        {
          // OK we have an unterminated macro string.
          result.append( "$" );
          start = pos + 1;
          continue;
        }
        String macro = s.substring( pos+2, fin );
        String value = getMacroValue( macro );
        if ( value == null )
        {
          result.append( "${" + macro + "}" );
        }
        else
        {
          result.append( value );
        }
        start = fin+1;
      }
      else
      {
       // OK, append the command char
       result.append( s.substring( pos, pos+1 ) );
       // then continue on from that point.
       start = pos+1;
//        // OK, append what we have ($ plus one other character)
//        result.append( s.substring( pos, pos+2 ) );
//        // then continue on from that point.
//        start+=2;
      }
    }
    if ( start < s.length() )
    {
      result.append( s.substring( start ) );
    }

    return result.toString();
  }


  /**
   * Get the value of the specified macro.<p>
   *
   * This implementation looks up resource keys from the scope resource bundle.
   *
   * @param macroName the name of the macro
   * @return the value of the macro. If you return null, the macro is undefined
   *    and the original unsubstituted macro string will be used.
   */
  protected String getMacroValue( String macroName )
  {
    ResourceBundle bundle = getContextResourceBundle();
    if ( bundle != null )
    {
      try
      {
        return bundle.getString( macroName );
      }
      catch ( MissingResourceException mre )
      {
        // No errors, just return literal string...
        return null;
      }
    }
    return null;
  }

  private ResourceBundle getContextResourceBundle()
  {
    ClassLoader classLoader = getContextClassLoader();

    String resClass = (String) getScopeData().get(
      ExtensionHook.KEY_RSBUNDLE_CLASS );
    if ( resClass == null )
    {
      return null;
    }
    try
    {
      ResourceBundle bundle = ResourceBundle.getBundle(
        resClass, Locale.getDefault(), classLoader
      );
      return bundle;
    }
    catch ( MissingResourceException mre )
    {
      return null;
    }
  }

  private ClassLoader getContextClassLoader()
  {
    ClassLoader classLoader = (ClassLoader) getScopeData().get(
      ExtensionVisitor.KEY_CLASSLOADER
    );
    if ( classLoader == null )
    {
      classLoader = Thread.currentThread().getContextClassLoader();
    }
    return classLoader;
  }

  private class NullLogger extends Logger
  {
    public NullLogger( )
    {
      super( null, null );
    }

    public void log( LogRecord logRecord )
    {
      // NO-OP
    }
  }

}
