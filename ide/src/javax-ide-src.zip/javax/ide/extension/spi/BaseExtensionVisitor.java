/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension.spi;

import javax.ide.extension.ElementVisitor;
import javax.ide.util.Version;
import javax.ide.extension.ExtensionHook;
import java.util.logging.Level;
import javax.ide.extension.ElementStartContext;
import javax.ide.extension.ElementName;
import javax.ide.extension.Extension;
import java.net.URI;
import javax.ide.extension.ElementContext;
import javax.ide.extension.ElementEndContext;

/**
 * A base class for ExtensionVisitor which processes the attributes of the 
 * extension tag. This is also used by a minimal processor in DependencyTree.
 */
public abstract class BaseExtensionVisitor extends ElementVisitor
{
  /**
   * The xml element name for the extension element.
   */
  public static final ElementName ELEMENT = 
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "extension" );
      
  /**
   * The xml element name for the classpath element.
   */
  protected static final ElementName CLASSPATH_ELEMENT =
    new ElementName( ExtensionHook.MANIFEST_XMLNS, "classpath" );      
   
  /**
   * The key for the current <tt>ExtensionSource</tt> instance in the scope
   * data map.
   */
  public static final String KEY_EXTENSION_SOURCE = "extSource";   
      
  /**
   * The max ESDK version that this processor will accept. Any
   * version greater than this will result in an error (earlier versions
   * are OK).
   */
  private static final Version MAX_ESDK_VERSION = 
    new Version( "1.0" );

  /**
   * Process an extension.
   * 
   * @param context a processing context.
   * @return a default extension implementation.
   */
  protected DefaultExtension processExtension( ElementStartContext context )
  {
    String id = context.getAttributeValue( "id" );
    if ( id == null || (id = id.trim()) == "" )
    {
      log( context, Level.SEVERE, "Missing required attribute 'id'" );
      return null;
    }
    
    String version = context.getAttributeValue( "version" );
    if ( version == null || ( version = version.trim()) == "" )
    {
      log( context, Level.SEVERE, "Missing required attribute 'version'" );
      return null;
    }
    
    Version parsedVersion;
    try
    {
      parsedVersion = new Version( version );
    }
    catch ( NumberFormatException nfe )
    {
      log( context, Level.SEVERE, "Incorrectly formed version: " + version );
      return null;
    }
    
    
    String esdkversion = context.getAttributeValue( "esdk-version" );
    if ( esdkversion == null || ( esdkversion = esdkversion.trim()) == "" )
    {
      log( context, Level.SEVERE, "Missing required attribute 'esdk-version'" );
      return null;
    }
    
    Version parsedESDKVersion;
    try
    {
      parsedESDKVersion = new Version( esdkversion );
    }
    catch ( NumberFormatException nfe )
    {
      log( context, Level.SEVERE, "Incorrectly formed version: " + esdkversion );
      return null;
    }
    
    if ( parsedESDKVersion.compareTo( MAX_ESDK_VERSION ) > 0 )
    {
      log( context, Level.SEVERE,  
        "ESDK version "+esdkversion+" is too high. Maximum supported version is "+MAX_ESDK_VERSION );
      return null;
    }
    
    DefaultExtension theExtension = new DefaultExtension( id );
    theExtension.setVersion( parsedVersion );
    theExtension.setEDKVersion( parsedESDKVersion );
    theExtension.setSource( (ExtensionSource)
      context.getScopeData().get( ExtensionVisitor.KEY_EXTENSION_SOURCE )
    );
    
    context.getScopeData().put( ExtensionHook.KEY_EXTENSION, theExtension );  
    
    return theExtension;
  }

  /**
   * Get the extension being processed.
   * 
   * @param context a processing context.
   * @return the extension being processed in this context.
   */
  protected final DefaultExtension getExtension( ElementContext context )
  {
    return (DefaultExtension) context.getScopeData().get( 
      ExtensionHook.KEY_EXTENSION );
  }
  
  /**
   * Get the source for the extension being processed.
   * 
   * @param context a processing context.
   * @return the extension source for this context.
   */
  protected final ExtensionSource getSource( ElementContext context )
  {
    return (ExtensionSource) context.getScopeData().get(
      KEY_EXTENSION_SOURCE );
  }  

  /**
   * Add the specified entry to the classpath of the class loader which is
   * loading this extension and its dependent classes.
   * 
   * @param context the current processing context.
   * @param ext the extension being processed. This may be in a partially
   *    initialized state.
   * @param entry a classpath entry used by the current extension.
   */
  protected abstract void addToClasspath( ElementContext context, 
    Extension ext, URI entry );
    
  /**
   * A visitor for the classpaths element. This is not registered by default
   * by this implementation, however the implementation class is available
   * so that subclasses can easily register it.
   */
  public final class ClasspathsVisitor extends ElementVisitor
  {
    private final ClasspathVisitor _cpVisitor = new ClasspathVisitor();
  
    public void start( ElementStartContext context )
    {
      context.registerChildVisitor( CLASSPATH_ELEMENT, _cpVisitor );
    }
  }
  
  /**
   * A visitor for the classpath element.
   */
  private final class ClasspathVisitor extends ElementVisitor
  {
    public void end( ElementEndContext context )
    {
      String text = context.getText().trim();
      if ( text.length() == 0 )
      {
        log( context, Level.WARNING,
          "Empty classpath definition"
        );
      }

      Extension ext = getExtension( context );
      URI uri = getSource( context ).resolvePath( ext, text );
      
      if ( ext instanceof DefaultExtension )
      {
        ((DefaultExtension)ext).getClassPath().add( uri );
      }
      addToClasspath( context, ext, uri );
    }
  }    
}
