/*
 * @(#)AssignmentExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression performing an assignment operation. The assignment
 * operators are: <p/>
 *
 * <pre>
 *   = *= /= %= += -= <<= >>= >>>= &= ^= |=
 * </pre>
 *
 * @author Andy Yu
 * */
public interface AssignmentExpressionT
  extends OperatorExpressionT
{
}
