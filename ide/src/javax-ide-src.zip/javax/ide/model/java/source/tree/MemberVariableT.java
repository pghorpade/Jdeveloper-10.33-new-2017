/*
 * @(#)FieldVariableT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A field (or enum constant) variable. <p/>
 *
 * @author Andy Yu
 * */
public interface MemberVariableT
  extends MemberT, VariableT
{
  // ----------------------------------------------------------------------

  static final MemberVariableT[] EMPTY_ARRAY = new MemberVariableT[ 0 ];


  // ----------------------------------------------------------------------
}
