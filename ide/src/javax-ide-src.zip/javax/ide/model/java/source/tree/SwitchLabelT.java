/*
 * @(#)SwitchLabelT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A switch label, default or case.
 *
 * @author Andy Yu
 * */
public interface SwitchLabelT
  extends Tree, BlockElementT
{
  // ----------------------------------------------------------------------

  /**
   * @return The switch label expression. Null if this is a default
   * label.
   */
  public ExpressionT getExpression();

  /**
   * @return The owning switch statement. Null if none (i.e. deformed tree).
   */
  public SwitchStatementT getOwningSwitch();


  // ----------------------------------------------------------------------
}
