/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.util;

/**
 * Exception thrown when IconDescription fails to find an icon.
 */
public final class MissingIconException extends Exception
{
  public MissingIconException( String message )
  {
    super( message );
  }
  
  public MissingIconException( String message, Throwable cause )
  {
    super( message, cause );
  }
}
