/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide;

import java.util.HashMap;
import java.util.Map;
import javax.ide.spi.LookupProvider;
import javax.ide.spi.ProviderNotFoundException;

/**
 * Services provide access to distinct areas of functionality in the IDE for
 * an extension developer.
 */
public abstract class Service 
{
  private boolean _initialized = false;
  private static final Map _loadedServices = new HashMap();
  
  /**
   * Initialize this manager. This is called the first time a manager is 
   * retrieved programmatically. The manager should process necessary
   * information from the extension manifest to initialize itself.
   * <p>
   * This implementation does nothing.
   */
  protected void initialize()
  {
    
  }
  
  private static Service findService( Class serviceClass )
    throws ProviderNotFoundException
  {
    Service service = (Service) _loadedServices.get( serviceClass );
    if ( service == null )
    {
      service = (Service) LookupProvider.lookup( 
        Thread.currentThread().getContextClassLoader(), serviceClass );
      _loadedServices.put( serviceClass, service );
    }
    return service;
  }
  
  /**
   * Get a service. 
   * 
   * This implementation looks for a META-INF/services/className resource on
   * the classpath of the context classloader. If such a resource exists, it
   * must contain the fully qualified class name of an implementation class
   * of the specified class.
   * 
   * @param serviceClass the class of the service.
   * @return the service.
   * @throws ProviderNotFoundException if an implementation of the service could not
   *    be located.
   */
  protected static Service getService( Class serviceClass )
    throws ProviderNotFoundException
  {
    Service service = findService( serviceClass );
    
    if ( !service._initialized )
    {
      service._initialized = true;
      service.initialize();
    }

    return service;
  }
}
